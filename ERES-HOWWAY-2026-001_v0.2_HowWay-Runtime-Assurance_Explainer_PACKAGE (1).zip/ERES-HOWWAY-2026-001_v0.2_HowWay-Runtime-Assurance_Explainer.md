# HowWay = ERES @: Runtime Assurance for AI Governance

*Six questions a governance control must answer while it runs, not six weeks later. A technical-to-plain-language account of the ERES finding, as it stands at v0.2.*

**ERES-HOWWAY-2026-001 v0.2** | Explainer edition, 2026-10-09 | As-is account of v0.2 PROPOSED: pre-canonical, not MIEVM-rated, canonical ID pending JAS confirmation | CCAL v2.1 / CC BY 4.0

**Author:** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221.

## Keywords

runtime assurance; AI governance; continuous controls monitoring; tamper-evident logging; runtime enforcement; human oversight; automated evidence collection; drift detection; sybil resistance; effective independence (n_eff); provenance; non-punitive remediation; ERES; PlayNAC; HowWay; GEAR x DERR + ERES; Doctrine of Verifiable Claims.

## Abstract

Most AI governance is evidenced at assessment time: a sample of policies, tickets and screenshots shows that a control existed on the day someone looked. Runtime governance asks whether the control is operating now, can be seen operating, produces its own evidence, notices change, can stop or escalate an action as it happens, and works inside the workflow rather than in a later review. This paper presents the ERES finding that one architecture answers all six questions by design. HowWay is the Method term (M) of C = R x P / M; 'HowWay = ERES @' means ERES applied as method. The mechanism is GEAR x DERR + ERES: record (a hash-chained log), diagnose (telemetry, drift detection and an Independence Gate that refuses agreement from correlated reviewers), and remediate (a conjunctive Proof-of-Resonance gate, live authorisation, autonomy tiers and non-punitive remediation). A standard-library test instrument runs 38 tests: 31 pass and 7 are skipped by design, one for each open item. This is the limit of what the author can establish alone. The six answers are design properties checked against a simulated adversary, written and tested by a single author. Every item that would change the work's standing now requires independent examination: peer review of the specification and the tests, calibration of the asserted thresholds, a regulatory reading, and an external red-team of a running system. The paper is released for that review. It makes no claim of live operation or compliance, and bio-electric inputs remain conjecture and are excluded. Its contribution is to state exactly what is shown, what is not, and what evidence from others would confirm or refute it.

> **In plain terms.** Today most organisations prove their AI is governed the way a restaurant passes inspection: someone visits, checks, and leaves. This work describes a system in which the checks are built into every action, like a kitchen where every dish is logged, monitored and can be stopped before it leaves the pass. It has been specified and tested on paper and in code. It has not yet been tested on a real, running system, and the paper says so.

## How to read this paper

Each technical section is followed by a shaded **In plain terms** note for a non-specialist reader. Claims carry the tags of the ERES Doctrine of Verifiable Claims: **[STATED]** (written in an ERES source), **[DERIVED]** (follows logically), **[CONSTRUCTED]** (a reading built for this paper), **[VALIDATED]** (supported by outside literature), and **[CONJECTURE]** (unproven and excluded from every claim). This is an as-is account of v0.2: nothing is upgraded beyond what that version established.

## 1. Introduction

### 1.1 The problem: assessment-time assurance

A conventional governance control is evidenced by sampling. An assessor collects policies, screenshots, change tickets and interviews, then concludes that the control was designed and, on the sampled day, operating. The weakness is timing. A control that fails the week after sampling stays invisible until the next assessment. The interval between failure and discovery is the organisation's exposure, and for autonomous AI agents acting thousands of times a day that interval is large.

Regulation is moving the same way. Record-keeping, human-oversight and post-market-monitoring obligations in the EU AI Act, continuous-monitoring practice in NIST guidance, and AI management-system standards all ask, in different words, whether controls work continuously rather than whether they existed once [E1-E4]. This paper claims resemblance to those aims, not conformity with them.

### 1.2 The six questions

The finding is organised around six questions that an assessor or a buyer increasingly asks of an AI-governance control:

- **Q1** Can you prove the control is actually operating?
- **Q2** Can I see the telemetry?
- **Q3** Can I automatically collect the evidence?
- **Q4** Can the control detect when something changes?
- **Q5** Can it stop or escalate an action at runtime?
- **Q6** Can governance happen inside the workflow instead of six weeks later during an assessment?

### 1.3 What HowWay means

Three ERES sources fix the term. In the identity **C = R x P / M** (Cybernetics = Resource x Purpose / Method), M is Method, and HowWay is the Method term [STATED: I1, I2]. In the PlayNAC governance table, the right-hand columns sit under IT, MyWay (Purpose) and HowWay (Method) [STATED: I1]. In the ERES nomenclature, '@' marks methodology or process inquiry [STATED: I2]. So **HowWay = ERES @** says that the method by which ERES is applied is itself an inquiry that can be posed, recorded and answered. The six questions are that inquiry, put to a control rather than a person [CONSTRUCTED]. Because the inquiry lives in the Method column of a workflow, the mechanism that answers it sits in the path of each action rather than beside it [DERIVED].

> **In plain terms.** 'HowWay' is the ERES word for *how* something gets done. The paper's point is that if you build the 'how' correctly, the proof that you are governing well is produced automatically as you work, instead of being assembled later for an auditor.

![Figure 1. Assessment-time versus runtime assurance, and the GEAR x DERR + ERES loop](ERES-HOWWAY-2026-001_v0.2_Figure-1_Assessment-vs-Runtime.svg)

## 2. Body of Evidence

### 2.1 The mechanism: GEAR x DERR + ERES

At the systemic level HowWay is a three-step cycle: **GEAR records**, **DERR diagnoses**, **ERES remediates**, and remediation is written back into GEAR [STATED: I2]. The formula multiplies before it adds: recording and diagnosis form one product, so if either is zero nothing can be remediated [STATED: I2]. In assurance terms, a control that cannot be evidenced or cannot notice change cannot be corrected at runtime [CONSTRUCTED].

**DERR** expands as **Diagnostic Equipment for Relational References**. In the source paper the full form is **$IT = GEAR x DERR + ERES**, and its terms sit on the Triune identity C = R x P / M: GEAR is Resource (the recorded substrate), DERR is Purpose (diagnostic meaning), and ERES is Method [STATED: I2]. DERR's semantic-mediation role is to translate a reading into the language of the 72 Key Domains so that one Community of Interest (for example, health) can read a result produced in another (for example, governance) [STATED: I2].

**Scope limit.** In its source paper DERR is also described through Kirlianography and community semantic interpretation. This paper uses only DERR's role, diagnosis, with ordinary inputs (logs, control states, metrics). Kirlianography, Schumann-resonance coupling and bio-electric readings are [CONJECTURE], are not needed by any answer, and are excluded (open item H7).

> **In plain terms.** Write everything down, notice when something looks wrong, then fix it, and write the fix down too. Because noticing depends on having written things down, the two are multiplied: skip either one and you cannot fix anything.

### 2.2 The six questions mapped to mechanisms

| Q | Term | ERES mechanism | Evidence produced | Status at v0.2 |
|---|---|---|---|---|
| Q1 Operating? | GEAR | SOMT append-only hash-chained log; CPROV provenance chain | Every gated action is a log entry; the log is the proof of operation | MODELED; edit, deletion and reorder detected in tests |
| Q2 Telemetry? | DERR | BERA health signal computed from the log | Telemetry that is a pure function of the log (tested) | MODELED; thresholds asserted (H2) |
| Q3 Auto evidence? | GEAR | Log entry written by the act of governing; sha256 manifests | No separate collection step (tested: one entry per action) | MODELED; live pipeline not built (H3) |
| Q4 Detect change? | DERR | RHC drift vs baseline; Independence Gate (n_eff) | Logged drift event; independence score | MODELED; k and tau asserted (H2) |
| Q5 Stop/escalate? | ERES | PoR = A x R x P x F (any zero blocks); RCR live-state authorisation; RAEC four tiers; Paineology remediation | Block, escalate and remediation entries tied to the action | MODELED; completeness open (H1); red-team open (H5) |
| Q6 In workflow? | PlayNAC | 12-step HowWay sequence; CHALLENGE/RESPONSE columns; ratification gate | Decision, log, challenge and ratification are steps of the run | ARCHITECTURAL; latency unmeasured (H4) |

### 2.3 Evidence by construction (Q1, Q3)

Each governed action is decided and logged in the same step. Each log entry stores the hash of the previous entry, so editing, deleting or reordering any entry breaks the chain at that point. Hash-chained and append-only logs are an established tamper-evidence technique [VALIDATED: E7, E8]; the test instrument reproduces the property in miniature and locates the first broken entry.

**The limit, stated in the evidence itself.** A log cannot show what bypassed it. The instrument demonstrates this: with one ungated effect added, the log still verifies as intact and says nothing. v0.2 therefore adds requirement **R-EL** [CONSTRUCTED]: keep an effect ledger independent of the gate and reconcile it against the log, so every real-world effect must trace to a logged 'execute' decision. In the model the ledger is not truly independent, so this test demonstrates the mechanism, not the guarantee (H1, H3). Runtime enforcement has known theoretical limits on what it can enforce [VALIDATED: E5, E6].

> **In plain terms.** Every entry in the record is sealed to the one before it, like numbered pages glued into a binding: tear one out and the gap shows. But a perfect diary still misses what happened behind the diarist's back, so the design also needs a second, independent count of what actually happened.

### 2.4 Telemetry and change detection (Q2, Q4)

Telemetry (counts of executed, blocked and escalated actions, challenges, remediations, and an intervention rate) is computed only from the log, so it cannot disagree with the record [tested]. Drift detection (RHC) flags a value more than k standard deviations from its baseline. The corpus sets k = 1. The instrument shows that on ordinary stationary noise this would raise a false alarm about 32 percent of the time (erfc(1/sqrt 2) = 0.3173), so k = 1 is treated as a return target, not a usable alarm level (H2).

> **In plain terms.** The dashboard is drawn straight from the record, so it cannot tell a different story. The current alarm setting would cry wolf about one time in three, and the paper flags that rather than hiding it.

### 2.5 The Independence Gate (Q4, Q6)

A change to the control set ratifies only if two conditions hold together: mean MIEVM score >= 8.5 **and** n_eff >= tau [STATED: I4]. Here n_eff = (sum of sqrt(lambda_i))^2 / (sum of lambda_i) over the eigenvalues of the reviewers' correlation matrix [STATED: I4, I5]. It equals n for fully independent reviewers, 1 for fully correlated reviewers, and 1 + sqrt(1 - r^2) for two reviewers with correlation r [DERIVED; tested]. In the instrument, five reviewers of whom four are near-duplicates give a high mean score of 9.5 but fall below tau = 3.0 and are refused; five independent reviewers at 9.0 ratify; five independent reviewers at 7.0 are refused. This closes the sybil route in the model [E9]. Two caveats are carried forward: tau = 3.0 is asserted (H2), and n_eff is computed on correlation of verdicts, not of errors.

> **In plain terms.** Agreement only counts if it comes from people who are genuinely thinking for themselves. Five sock-puppets saying 'yes' count as about one voice, so their vote does not pass. The rule is 'independence before agreement'.

### 2.6 Stopping and escalating at runtime (Q5)

Before execution, every action passes four gates in order: (1) an isolated agent is blocked; (2) without fresh live-state authorisation (RCR) the action is blocked; (3) Proof-of-Resonance scores Alignment, Resonance, Proportionality and Finality-Risk and multiplies them, so any zero blocks [STATED: I7]; (4) if the action needs a higher autonomy tier than the agent holds (RAEC, tiers 0-3), it escalates to a human. On breach, remediation is non-punitive and logged: isolate, downgrade from level 3 to level 1, audit. The instrument tests each path and confirms that a blocked action leaves no effect. What is not shown is completeness: there is no proof that these gates block every malicious action (H1).

> **In plain terms.** Four checkpoints sit in front of every action. Fail any one and the action stops or goes to a person. When something goes wrong the response is to contain and retrain, not to punish, and that response is recorded too.

### 2.7 Governance inside the workflow (Q6)

The 2018 PlayNAC HowWay page lists twelve steps from a User-GROUP service agreement being opened to its being updated [STATED: I1]. Read as an assurance workflow, the steps carry the control functions: an accountable contact path (step 1), the request recorded as a question (2), scope declared (3), definitions fixed before scoring (4), authorisation level set (5), the affected group notified (6), an escalation path assigned (7), the decision rendered (8), reviewed with evidence keys (9), provenance closed (10), a ledger of record updated (11), and the agreement updated (12) [CONSTRUCTED]. Contestation (CHALLENGE/RESPONSE) and ratification happen as steps of the run, so there is no deferred assessment queue (tested). The cost of gating every action, in latency and throughput, has not been measured (H4).

> **In plain terms.** The review happens as part of the job, not as a separate audit months later. Whether that stays fast enough at real-world scale is still unknown.

### 2.8 Test results

| Instrument | Tests | Pass | Skipped by design | Exit | Source |
|---|---|---|---|---|---|
| eres_howway_test_instrument.py (HowWay v0.2; included in this package) | 38 | 31 | 7 (H1-H7) | 0 | Re-run for this edition from a fresh extract, 2026-10-09 |
| eres_arh_test_instrument.py (ARH v0.1; not included) | 24 | 19 | 5 (O1-O5) | 0 | Reported from the ARH v0.1 package; not re-run |

Both instruments use the Python standard library only and expose no is_safe, is_secure or is_compliant verdict. The HowWay instrument ships in this package and was re-run from a fresh extract for this edition with the same result as v0.2 (run log: RUN.txt). Coverage: Q1 four tests, Q2 two, Q3 two, Q4 eight, Q5 eight, Q6 three, three documented-limit tests, and one package-integrity check that verifies MANIFEST.json.

### 2.9 Open items

| ID | Open item | What would close it |
|---|---|---|
| H1 | No proof PoR + RCR + RAEC block all malicious actions; gate bypass is the central risk | Independent effect ledger (R-EL) plus adversarial testing |
| H2 | RHC k, tau and BERA thresholds are asserted, not derived | Calibration against real governance-failure data |
| H3 | Log tamper-evidence and external anchoring not realised outside the model | Deployed log with external anchoring |
| H4 | Latency and throughput cost of gating every action unmeasured | Measured prototype under load |
| H5 | External red-team of a running system | Cannot be simulated; requires an outside team and a live runtime |
| H6 | Regulatory fit (EU AI Act, GDPR, eIDAS) not established | Clause-level review (see RRH) |
| H7 | Bio-electric, Kirlianographic and Schumann inputs unvalidated | Independent validation; excluded until then |

## 3. Conclusions

**What is established, at its actual strength.** Within one architecture, each of the six runtime-assurance questions has a named mechanism, a specified behaviour, and a passing test against a modeled adversary. Evidence is produced by the act of governing, telemetry cannot disagree with the record, correlated reviewers cannot ratify a change, and any zero-scored factor stops an action.

**What is not established.** Operation in a live deployment; completeness against novel attacks; calibrated thresholds; acceptable inline cost; regulatory conformity. The paper claims none of these.

**Why it is significant.** It converts a broad governance claim ('ERES prevents malicious activity') into a bounded, testable one, and names the single experiment that would most change its standing: an external red-team of a running implementation (H5). That is the practical meaning of elevating empirics in AI governance: say exactly what is shown, what is not, and what evidence would decide it.

**Next steps.** (1) A two-round Delphi MIEVM on v0.2, run blind-first with the Independence Gate applied to the round itself, as an adversarial-completeness probe of the six-question mapping rather than a ratification. (2) Close H2 and H4 with a measured prototype and build R-EL. (3) Hold H5 as the empirical gate. Each of these now depends on independent reviewers; the author has taken the work as far as a single researcher can, and releases it for peer review.

> **In plain terms.** The design answers all six questions on paper and in test code. It has not yet faced a real attacker on a real system. The paper says exactly that, and says what test would settle it.

## 4. Historical Notes

- **4 Feb 2012.** ERES Institute for New Age Cybernetics established in Bella Vista, Arkansas; CCAL v1.0 released.
- **25 Jul 2018.** ERES PlayNAC "HowWay" page published (revised 26 Jul 2018 and 6 Jul 2025): HowWay as the Method column and the twelve-step User-GROUP sequence [I1].
- **2024.** CCAL v2.0 introduces the Care Clause and the Three Governing Principles.
- **Mar 2026.** "What / With / Why and HowWay" defines GEAR x DERR + ERES and the '@' operator [I2].
- **26 Apr 2026.** CCAL v2.1 takes effect [I11].
- **17 Jul 2026.** ERES-VOTING-2026-001 v0.2 Addendum 13, Divine HowWay [I3].
- **Sep 2026.** ERES-ARH-2026-001 v0.1 Adversarial Root Hardening: threat model T1-T7, Independence Gate, 24-test harness [I4]. Regulatory Root Hardening (RRH) drafting approved 24 Sep [I9].
- **28 Sep 2026.** HowWay v0.1 maps the six questions to ERES mechanisms (open items H1-H6) [I8]; v0.2 corrects the '@' reading, adds GEAR x DERR + ERES, the PlayNAC spine, R-EL, H7 and the 38-test instrument.
- **9 Oct 2026.** This explainer edition: as-is technical-to-plain-language account of v0.2; no change to its claims.

## 4a. Record Completeness

This edition states what its record does and does not include, so a reader can judge the gaps.

- **Included:** the full v0.2 text basis (six-question mapping, PlayNAC spine, R-EL, Independence Gate, H1-H7), the DERR definition, the v0.2 test instrument (re-run), the full CCAL v2.1 text, and the v0.1 to v0.2 history.
- **Not included, by consent:** the VORN-ERES HowWay Framework. It is marked confidential (VORN/ERES leadership only) and is excluded until its holder gives written consent. Its author line also reads 'Joseph E. Gredler', which should be corrected at source.
- **Not included, not available to this edition:** the original v0.2 PDF and its four source uploads (the 2025 PlayNAC HowWay PDF, the March 2026 What/With/Why docx, the VOTING Addendum 13, the VORN framework). This edition was rebuilt from the recorded v0.2 text, not from those files.
- **Not included, separate instrument:** the ARH v0.1 harness; its result is reported, not reproduced.
- **Unverified:** external references E1-E9 have not been checked against their sources; the CCAL v2.1 text has not been compared with the Zenodo canonical.
- **Selection basis:** HowWay was chosen as the most significant item from 19 linked sessions. Eight were read (several only in part), two could not be opened, and eleven session links could not be read with the available tools. The ranking is therefore provisional.

## 5. Credits

- **Author of record.** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221. Sole author.
- **Corpus lineage.** PlayNAC HowWay page [I1]; What / With / Why and HowWay [I2]; VOTING Addendum 13 [I3]; ARH [I4]; CDFE v1.1 [I5], used only as a general effective-independence scorer; CPROV [I6]; the PlayNAC governance stack [I7]; HowWay v0.1 and v0.2 [I8].
- **Drafting and validation node.** Claude (Anthropic), working under the H2C2H method. Claude is a drafting node, not an author. No MIEVM rating has been applied.
- **External literature.** Authors of E1-E9 are credited through the References. None has reviewed or endorsed this work.
- **No endorsement.** No third party has reviewed, approved or endorsed this paper.

## 6. References

**Internal (ERES)**

- [I1] Sprute, J. A. ERES PlayNAC "HowWay": Organizer for User/GROUP Pedagogy and EMCI Game Theory. 2018-07-25; rev. 2018-07-26, 2025-07-06. ERES Institute.
- [I2] Sprute, J. A. (2026, March). What / With / Why and HowWay: AnswerQuestion.IT.MyWay, GEAR x DERR + ERES. ERES Institute. CCAL v2.1.
- [I3] Sprute, J. A. (2026, July 17). ERES-VOTING-2026-001 v0.2, Addendum 13: Divine HowWay. ERES Institute.
- [I4] Sprute, J. A. (2026, September). ERES-ARH-2026-001 v0.1: Adversarial Root Hardening. ERES Institute.
- [I5] ERES-CDFE-2026-001 v1.1: Covariance-Discounted Floor Engine. ERES Institute.
- [I6] ERES-CPROV-2026-001: Constitutional Provenance. ERES Institute.
- [I7] ERES-PLAYNAC-GOVERNANCE-2026-001: PlayNAC resonance-governance stack (BERA, RHC, SOMT, MIEVM, PoR, CBGMODD, RCR, RAEC). ERES Institute.
- [I8] Sprute, J. A. (2026, September 28). ERES-HOWWAY-2026-001 v0.1 and v0.2 (HowWay WP v2). ERES Institute.
- [I9] ERES-RRH-2026-001: Regulatory Root Hardening. Drafting approved 2026-09-24.
- [I10] ERES-LEGAL-2026-001: Doctrine of Verifiable Claims. ERES Institute.
- [I11] CARE Commons Attribution License v2.1 (CCAL v2.1). ERES Institute. Effective 2026-04-26.

**External**

- [E1] Regulation (EU) 2024/1689 (Artificial Intelligence Act), esp. Arts. 12, 14, 72. Official Journal of the EU, 12 July 2024.
- [E2] NIST. AI Risk Management Framework (AI RMF 1.0). NIST AI 100-1, January 2023.
- [E3] NIST. Information Security Continuous Monitoring (ISCM). SP 800-137, September 2011.
- [E4] ISO/IEC 42001:2023. Artificial intelligence - Management system.
- [E5] Schneider, F. B. (2000). Enforceable security policies. ACM TISSEC, 3(1), 30-50.
- [E6] Leucker, M., and Schallhart, C. (2009). A brief account of runtime verification. J. Logic and Algebraic Programming, 78(5), 293-303.
- [E7] Crosby, S. A., and Wallach, D. S. (2009). Efficient data structures for tamper-evident logging. USENIX Security Symposium, 317-334.
- [E8] Laurie, B., Langley, A., and Kasper, E. (2013). Certificate Transparency. RFC 6962, IETF.
- [E9] Douceur, J. R. (2002). The Sybil attack. IPTPS 2002, LNCS 2429, 251-260.

*External references are carried from v0.2, where they were supplied from the drafting node's training knowledge. Verify volume, page and clause details before deposit.*

## 7. License

Released under **CCAL v2.1 / CC BY 4.0**. You may share, adapt, cite, implement and offer services on this work, including commercially, provided that attribution is kept intact, adaptations are marked and shared forward under CCAL v2.1 or a compatible license, the work is not enclosed, and use conforms to the Three Governing Principles. The full CCAL v2.1 text ships as LICENSE.md in this package; the canonical deposit is at Zenodo, which governs if copies differ. CC BY 4.0 legal code: https://creativecommons.org/licenses/by/4.0/legalcode. The work is provided as is, without warranty.

**Required attribution:** Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1. ORCID 0000-0001-9946-3221.

*Don't hurt yourself. Don't hurt others. Build for generations to come.*
