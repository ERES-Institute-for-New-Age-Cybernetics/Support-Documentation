#!/usr/bin/env python3
"""Structural test suite for ERES-NAC-SYMBOLS-2026-001 v3.0 (NAC Symbol Register with TALONICS).

Standard library only. Run:  python3 test_nac_symbols.py
Exit code 0 = every structural invariant holds.

These tests check that the register is internally consistent: counts, homes,
chain order, Trinity ownership, collision rules, glyph integrity and package
integrity. They also execute every DERIVED TALONICS claim (TALONICS-MATH v2.0,
folded in from ERES-TALONICS-TEST-2026-001 v2.0). The three TALONICS empirical
tests (T-2, T-3, T-9) need outside data: they are reported as SKIPPED with the
reason, never as passed. No test validates a physical or empirical claim.
License: CCAL v2.1 / CC-BY 4.0.
"""
import glob, hashlib, itertools, json, math, os, re, sys, unicodedata, unittest

HERE = os.path.dirname(os.path.abspath(__file__))


def _exactly_one(pattern, exclude=()):
    hits = [p for p in glob.glob(os.path.join(HERE, pattern)) if os.path.basename(p) not in exclude]
    if len(hits) != 1:
        sys.exit(f"Expected exactly one file matching {pattern} beside this test, found {len(hits)}: "
                 f"{[os.path.basename(h) for h in hits]}. Run the suite from the unzipped package folder.")
    return hits[0]


REG_PATH = _exactly_one("*_register.json")
MD_PATH = _exactly_one("ERES-*.md", exclude=("README.md", "NOTICE_Advanced-ERES-Governors.md"))
with open(REG_PATH, encoding="utf-8") as f:
    R = json.load(f)
with open(MD_PATH, encoding="utf-8") as f:
    MD = f.read()

RING = ["L1", "L2", "L3", "L4", "L5", "L6"]
CHAIN = ["Emotion", "Utterance", "Sound", "Word (spoken)", "Symbol", "Glyph",
         "Letter", "Word (written)", "Character", "Semantic"]
LICENSE = "CCAL v2.1 / CC-BY 4.0"
DOM = {d["id"]: d for d in R["domains"]}
STAGES = R["stages"]
SYMS = R["symbols"]
BY_SYMBOL = {s["symbol"]: s for s in SYMS}
T = R["talonics"]
TAL = [s for s in SYMS if s["layer"] == "TALONICS"]


class TestChain(unittest.TestCase):
    def test_ten_stages_in_order(self):
        self.assertEqual([s["n"] for s in STAGES], list(range(1, 11)))

    def test_stage_names_match_author_chain(self):
        self.assertEqual([s["name"] for s in STAGES], CHAIN)

    def test_word_appears_twice_spoken_then_written(self):
        self.assertEqual([s["n"] for s in STAGES if s["name"].startswith("Word")], [4, 8])

    def test_chain_runs_once_round_the_ring_from_L2_to_L1(self):
        order = ["L2", "L3", "L4", "L5", "L6", "L1"]
        idx = [order.index(s["domain"]) for s in STAGES]
        self.assertEqual(idx, sorted(idx), "chain must not step backwards round the ring")
        self.assertEqual((STAGES[0]["domain"], STAGES[-1]["domain"]), ("L2", "L1"))
        self.assertEqual(set(s["domain"] for s in STAGES), set(RING), "every Domain is visited")

    def test_stage_counts_per_domain(self):
        counts = {d: sum(1 for s in STAGES if s["domain"] == d) for d in RING}
        self.assertEqual(counts, {"L1": 1, "L2": 2, "L3": 2, "L4": 2, "L5": 2, "L6": 1})

    def test_loop_closes_through_aura_after(self):
        self.assertEqual(R["loop"], {"from": 10, "to": 1, "via": "Aura After"})

    def test_privacy_line_is_K_c_between_emotion_and_utterance(self):
        pl = R["privacy_line"]
        self.assertEqual((pl["symbol"], pl["between_stages"]), ("K_c", [1, 2]))
        self.assertIn("K_c", STAGES[1]["symbols"])
        self.assertNotIn("K_c", STAGES[0]["symbols"])
        self.assertIn("never surveilled", pl["rule"])

    def test_every_stage_has_an_instrument_binding(self):
        for s in STAGES:
            self.assertTrue(s["binding"].strip(), f"stage {s['n']} has no instrument binding")

    def test_placement_status_is_separate_and_all_proposed(self):
        self.assertEqual({s["placement_status"] for s in STAGES}, {"Proposed"})


class TestTrinity(unittest.TestCase):
    def test_ownership(self):
        self.assertEqual({d: DOM[d]["owner"] for d in RING},
                         {"L1": "GOOD", "L6": "GOOD", "L2": "SOUND", "L3": "SOUND", "L4": "BEST", "L5": "BEST"})

    def test_movements_are_contiguous_voice_inscription_meaning(self):
        owners = [DOM[s["domain"]]["owner"] for s in STAGES]
        self.assertEqual(owners, ["SOUND"] * 4 + ["BEST"] * 4 + ["GOOD"] * 2)
        self.assertEqual([m["name"] for m in R["movements"]], ["Voice", "Inscription", "Meaning"])

    def test_movement_domain_ranges(self):
        want = {"Voice": {"L2", "L3"}, "Inscription": {"L4", "L5"}, "Meaning": {"L6", "L1"}}
        name_of = {m["owner"]: m["name"] for m in R["movements"]}
        got = {}
        for s in STAGES:
            got.setdefault(name_of[DOM[s["domain"]]["owner"]], set()).add(s["domain"])
        self.assertEqual(got, want)


class TestRegister(unittest.TestCase):
    def test_counts(self):
        on_file = [s for s in SYMS if s["status"].startswith("On file")]
        proposed = [s for s in SYMS if s["status"].startswith("Proposed")]
        self.assertEqual((len(SYMS), len(on_file), len(proposed)), (43, 39, 4))
        self.assertEqual((len(SYMS) - len(TAL), len(TAL)), (27, 16))
        self.assertEqual({s["symbol"] for s in proposed}, {"☉", "𓋹", "⇄", "≈"})

    def test_status_values_are_valid(self):
        for s in SYMS:
            self.assertRegex(s["status"], r"^(On file|Proposed)\b", s["symbol"])

    def test_every_symbol_has_a_valid_home_name_binding_and_source(self):
        for s in SYMS:
            self.assertIn(s["home"], DOM, s["symbol"])
            for field in ("name", "binding", "source", "stage"):
                self.assertTrue(str(s[field]).strip(), f"{s['symbol']} has no {field}")

    def test_symbols_are_unique(self):
        self.assertEqual(len(BY_SYMBOL), len(SYMS))

    def test_hub_holds_exactly_the_binding_symbols(self):
        hub = {s["symbol"] for s in SYMS if s["home"] == "HUB"}
        self.assertEqual(hub, {"☉", "◈ ✦ ⬡", "× + → ÷", "== · ===", "≈", "≙"})
        for s in SYMS:
            if s["home"] == "HUB":
                self.assertIn(s["stage"], {"Loop", "Movements", "All"}, s["symbol"])

    def test_every_domain_owns_at_least_one_symbol(self):
        for d in RING:
            self.assertTrue([s for s in SYMS if s["home"] == d], f"{d} owns no symbol")

    def test_every_stage_symbol_is_registered_at_that_stage_domain(self):
        for st in STAGES:
            for sym in st["symbols"]:
                self.assertIn(sym, BY_SYMBOL, f"stage {st['n']} symbol {sym} not registered")
                self.assertEqual(BY_SYMBOL[sym]["home"], st["domain"], sym)

    def test_numeric_stage_tags_agree_with_home(self):
        stage_dom = {s["n"]: s["domain"] for s in STAGES}
        for s in SYMS:
            for n in (int(x) for x in re.findall(r"\d+", s["stage"])):
                self.assertEqual(stage_dom[n], s["home"], f"{s['symbol']} stage {n}")

    def test_gamma_and_pi_each_have_one_home(self):
        self.assertEqual([s["symbol"] for s in SYMS if "Γ" in s["symbol"]], ["Γ"])
        self.assertEqual(BY_SYMBOL["Γ"]["home"], "L2")
        self.assertEqual([st["n"] for st in STAGES if "π" in st["symbols"]], [3])

    def test_five_named_keys_present_and_consistent(self):
        keys = {k["symbol"]: k for k in R["named_keys"]}
        self.assertEqual(set(keys), {"☉", "𓋹", "Δ", "∞", "Φ"})
        for sym, k in keys.items():
            self.assertEqual(k["home"], BY_SYMBOL[sym]["home"], sym)
            for field in ("reading", "binding", "stage", "status"):
                self.assertTrue(k[field].strip(), f"named key {sym} has no {field}")
            self.assertEqual(k["status"].split()[0], BY_SYMBOL[sym]["status"].split()[0], sym)


class TestGlyphIntegrity(unittest.TestCase):
    def test_every_symbol_has_a_unique_ascii_handle(self):
        handles = [s["alias"] for s in SYMS]
        self.assertEqual(len(set(handles)), len(handles))
        for h in handles:
            self.assertRegex(h, r"^[A-Z][A-Z0-9_]*$")

    def test_code_points_and_names_match_the_glyphs(self):
        for s in SYMS:
            chars = []
            for c in s["symbol"]:
                if not c.isspace() and not c.isascii() and c not in chars:
                    chars.append(c)
            self.assertEqual(s["codepoints"], [f"U+{ord(c):04X}" for c in chars], s["symbol"])
            self.assertEqual(s["unicode_names"], [unicodedata.name(c) for c in chars], s["symbol"])

    def test_proposed_glyphs_are_the_exact_code_points(self):
        want = {"SUN": "U+2609", "ANKH": "U+132F9", "FLIP": "U+21C4", "MAPS_ONTO": "U+2248"}
        by_alias = {s["alias"]: s for s in SYMS}
        for alias, cp in want.items():
            self.assertEqual(by_alias[alias]["codepoints"], [cp], alias)

    def test_no_lookalike_glyph_in_any_symbol(self):
        bad = set(R["lookalikes_excluded"])
        self.assertEqual(bad, {"○", "⊙", "⇌"})
        for s in SYMS:
            self.assertFalse(bad & set(s["symbol"]), f"lookalike in {s['symbol']}")
        for st in STAGES:
            self.assertFalse(bad & set("".join(st["symbols"])), f"lookalike in stage {st['n']}")

    def test_up_arrow_only_in_the_talonics_state_glyphs(self):
        rule = R["restricted_glyphs"]["↑"]
        self.assertEqual((rule["code_point"], rule["only_in"], rule["meaning"]), ("U+2191", "— ↑ ↓", "extended"))
        holders = [s["symbol"] for s in SYMS if "↑" in s["symbol"]]
        self.assertEqual(holders, ["— ↑ ↓"])
        self.assertEqual(BY_SYMBOL["— ↑ ↓"]["layer"], "TALONICS")


class TestCollisionRules(unittest.TestCase):
    def test_lowercase_phi_only_as_latitude(self):
        for s in SYMS:
            if "φ" in s["symbol"]:
                self.assertEqual(s["symbol"], "G(φ, λ)")

    def test_capital_phi_only_as_golden_ratio_and_held_as_conjecture(self):
        phi = BY_SYMBOL["Φ"]
        self.assertEqual(phi["name"], "Golden ratio")
        self.assertIn("conjecture", phi["status"].lower())

    def test_spectral_lambda_carries_its_operator(self):
        for s in SYMS:
            if "λ" in s["symbol"] and s["symbol"] != "G(φ, λ)":
                self.assertTrue(s["symbol"].startswith("Δλ"), s["symbol"])

    def test_sigma_cases_are_distinct_quantities(self):
        self.assertIn("1σ", BY_SYMBOL["σ"]["binding"])
        self.assertIn("HARMONY", BY_SYMBOL["Σ"]["binding"])

    def test_delta_collision_writes_the_triangle_as_open_triangle(self):
        d = [c for c in R["collisions"] if c["symbol"] == "Δ"]
        self.assertEqual(len(d), 1)
        self.assertIn("Triangle", d[0]["reading_b"])
        self.assertIn("△", d[0]["rule"])

    def test_four_collisions_each_with_a_rule(self):
        self.assertEqual([c["symbol"] for c in R["collisions"]], ["φ / Φ", "λ", "Δ", "σ / Σ", "A", "B", "L", "M", "H", "↑"])
        for c in R["collisions"]:
            self.assertTrue(c["rule"].strip())

    def test_four_usage_rules_with_relation_ladder(self):
        self.assertEqual([r["name"] for r in R["rules"]],
                         ["Maps-onto, not identity", "Constants are earned", "One home, many uses", "Relation ladder"])
        self.assertIn("≡", R["rules"][0]["text"])
        ladder = R["rules"][3]["text"]
        self.assertTrue(ladder.index("≡") < ladder.index("≙") < ladder.index("≈"), "ladder order ≡ > ≙ > ≈")

    def test_domain_ids_never_collide_with_melody(self):
        for d in DOM:
            self.assertTrue(d == "HUB" or re.fullmatch(r"L[1-6]", d), d)
        self.assertEqual(BY_SYMBOL["L"]["name"], "MELODY")

    def test_golden_ratio_identity(self):
        phi = (1 + math.sqrt(5)) / 2
        self.assertAlmostEqual(phi, 1.6180339887, places=9)
        self.assertAlmostEqual(phi * phi, phi + 1, places=12)


class TestRecord(unittest.TestCase):
    def test_review_reconciliation_counts(self):
        disp = [r["disposition"] for r in R["review"]]
        self.assertEqual((disp.count("Adopted"), disp.count("Not adopted"), disp.count("Noted")), (13, 6, 2))
        for r in R["review"]:
            self.assertTrue(r["action"].strip())

    def test_changelog_newest_first_and_current(self):
        vs = [c["version"] for c in R["changelog"]]
        self.assertEqual(vs[0], "v" + R["version"])
        key = [tuple(int(x) for x in v[1:].split(".")) for v in vs]
        self.assertEqual(key, sorted(key, reverse=True))

    def test_parent_instrument_named(self):
        self.assertIn("ERES-PIVOT-VSIM-2026-001", R["parent"])
        self.assertIn("ERES-PIVOT-VSIM-2026-001", MD)

    def test_open_items_and_references(self):
        self.assertGreaterEqual(len(R["open_items"]), 7)
        self.assertGreaterEqual(len(R["references"]), 15)

    def test_license_is_exact(self):
        self.assertEqual(R["license"], LICENSE)


class TestTextAgreesWithRegister(unittest.TestCase):
    def test_master_text_states_the_same_counts(self):
        m = re.search(r"\*\*(\d+) symbols: (\d+) on file in corpus instruments, (\d+) proposed\.\*\*", MD)
        self.assertIsNotNone(m)
        self.assertEqual(tuple(int(x) for x in m.groups()), (43, 39, 4))

    def test_master_text_carries_version_and_license(self):
        self.assertIn(f"v{R['version']} Proposed", MD)
        self.assertIn(LICENSE, MD)

    def test_master_text_has_every_section(self):
        for h in ("## Thesis", "## Stage register", "## TALONICS layer", "### Row 18 crosswalk", "### Five-finger key",
                  "### Derived numbers", "### Empirical tests still pending", "## Glyph integrity", "## Review reconciliation",
                  "## Collisions and usage rules", "## Change log", "## Open items", "## Credits",
                  "## References", "## License"):
            self.assertIn(h, MD)

    def test_master_text_keeps_the_doctrine_statements(self):
        for phrase in ("only externalized signal", "Carry Rule", "never absorbed into ERES",
                       "derivation or measured fit", f"ORCID {R['author']['orcid']}"):
            self.assertIn(phrase, MD)

    def test_every_ascii_handle_appears_in_the_master_text(self):
        for s in SYMS:
            self.assertIn(s["alias"], MD, s["alias"])


# ----------------------------------------------------------------------------------------------
# TALONICS layer (v3.0). Structural proofs from TALONICS-MATH v2.0, executed on the register data.
# ----------------------------------------------------------------------------------------------
STATES = ("flat", "extended", "flexed")
GLYPH = T["state_glyphs"]
UNGLYPH = {v: k for k, v in GLYPH.items()}


def rank(seg):
    return sum(1 for x in seg if x != "flat")


class TestTalonicsPlacement(unittest.TestCase):
    def test_sixteen_talonics_symbols_all_on_file(self):
        self.assertEqual(len(TAL), 16)
        for s in TAL:
            self.assertTrue(s["status"].startswith("On file"), s["symbol"])
        self.assertIn("conjecture", BY_SYMBOL["ρ_k"]["status"])

    def test_no_talonics_symbol_and_no_row18_element_on_stage_1(self):
        self.assertFalse([x for x in STAGES[0]["symbols"] if BY_SYMBOL[x]["layer"] == "TALONICS"])
        self.assertNotIn(1, [e["stage"] for e in T["row18"]])

    def test_row18_has_seven_elements_on_the_stated_stages(self):
        got = {e["element"]: e["stage"] for e in T["row18"]}
        self.assertEqual(got, {"PERFORMANCE": 2, "RHYTHM": 3, "EXPRESSION": 3, "COMPOSITION": 6,
                               "MELODY": 8, "HARMONY": 8, "TIMBRE": 9})
        self.assertEqual({e["placement_status"] for e in T["row18"]}, {"Proposed"})

    def test_performance_shares_the_privacy_line(self):
        perf = [e for e in T["row18"] if e["element"] == "PERFORMANCE"][0]
        self.assertEqual(perf["stage"], R["privacy_line"]["between_stages"][1])
        self.assertIn("K_c", STAGES[perf["stage"] - 1]["symbols"])

    def test_melody_and_harmony_sit_with_their_symbols(self):
        st8 = STAGES[7]["symbols"]
        self.assertIn("Σ", st8)
        self.assertIn("L", st8)

    def test_timbre_is_an_index_only(self):
        timbre = [e for e in T["row18"] if e["element"] == "TIMBRE"][0]
        self.assertIn("index only", timbre["function"])

    def test_five_finger_key(self):
        self.assertEqual([(f["finger"], f["pillar"]) for f in T["fingers"]],
                         [("Thumb", "Health"), ("Index", "Law"), ("Middle", "Protection"),
                          ("Ring", "Love/Water"), ("Pinky", "Trades/Cybernetics")])

    def test_grammatical_units(self):
        self.assertEqual({u["unit"]: u["stage"] for u in T["units"]}, {"Apparition": 7, "Condition": 6, "Notion": 8})


class TestTalonicsProofs(unittest.TestCase):
    def test_census_rank_counts(self):
        """MATH Thm 2.3: |A_k| = C(5,k)·2^k; brute force over 3^5 agrees."""
        formula = [math.comb(5, k) * 2 ** k for k in range(6)]
        brute = [0] * 6
        for seg in itertools.product(STATES, repeat=5):
            brute[rank(seg)] += 1
        self.assertEqual(formula, [1, 10, 40, 80, 80, 32])
        self.assertEqual(brute, formula)
        self.assertEqual(sum(formula), 3 ** 5)
        self.assertEqual(2 ** 5, 32)

    def test_apparitions_are_ten(self):
        self.assertEqual(math.comb(5, 1) * 2, 10)

    def test_T1_orthogonality(self):
        """T-1: varying manner over a fixed segment leaves identity and count unchanged."""
        seg = ("flat", "extended", "flat", "flat", "flat")
        signs = [(seg, b) for b in range(1, T["manner_bands"] + 1)]
        self.assertEqual({s[0] for s in signs}, {seg})
        self.assertEqual({1 for _ in signs}, {1})

    def test_T4_count_invariance_through_cast(self):
        """T-4 / Cor 6.5: CAST saturates manner, never touches identity or count."""
        def cast(sign):
            return (sign[0], T["manner_bands"])
        sign = (("flexed",) * 5, 1)
        after = cast(sign)
        self.assertEqual(after[0], sign[0])
        self.assertEqual(after[1], 4)

    def test_T5_roll_call(self):
        """T-5 / Thm 7.2: Σ forgets order; the stored MELODY recovers attribution."""
        contribs = [("a", (1, 0, 1, 0)), ("b", (0, 1, 1, 0)), ("c", (1, 1, 0, 1))]
        def harmony(seq):
            return tuple(sum(v[j] for _w, v in seq) for j in range(4))
        self.assertEqual(harmony(contribs), harmony(list(reversed(contribs))))
        melody = list(contribs)
        self.assertEqual(dict(melody), {"a": (1, 0, 1, 0), "b": (0, 1, 1, 0), "c": (1, 1, 0, 1)})
        distinct = [("a", (1, 0, 1, 0)), ("b", (1, 1, 0, 1)), ("c", (0, 1, 1, 0))]
        self.assertEqual(harmony(distinct), harmony(contribs), "two attributions, one chord: Σ alone is not injective")

    def test_T6_boundary_reads_only_externalized_signal(self):
        """T-6: measured features come from segment and manner only; no thought tier exists."""
        def features(sign):
            seg, band = sign
            return {"segment": seg, "rank": rank(seg), "manner_band": band}
        f = features((("extended", "flat", "flexed", "flat", "flat"), 2))
        self.assertLessEqual(set(f), {"segment", "rank", "manner_band"})

    def test_T7_glyph_round_trip_all_243(self):
        """T-7: every posture writes as five state glyphs and reads back exactly."""
        for seg in itertools.product(STATES, repeat=5):
            g = "".join(GLYPH[x] for x in seg)
            self.assertEqual(tuple(UNGLYPH[c] for c in g), seg)
        self.assertEqual("".join(GLYPH[x] for x in ("extended", "flat", "flexed", "extended", "flat")), "↑—↓↑—")

    def test_T8_contestability_append_only(self):
        """T-8 (DVC 2.4): a challenge after execution appends; the record is never sealed or overwritten."""
        somt = [("CAST", "t0")]
        somt.append(("CHALLENGE", "t1"))
        self.assertEqual([e[0] for e in somt], ["CAST", "CHALLENGE"])

    def test_P3_sufficiency_with_explicit_injection(self):
        """Thm 7b.2: |𝕋| ≈ 400 > 126 cells; an injective address map exists and is built."""
        rows, cols = T["playnac_cells"]
        cells = rows * cols
        size = T["licensed_postures_estimate"] * T["manner_bands"]
        self.assertEqual((cells, size), (126, 400))
        self.assertAlmostEqual(size / cells, 3.17, places=2)
        pool = [(a, b) for a in range(T["licensed_postures_estimate"]) for b in range(T["manner_bands"])]
        f = {cell: pool[i] for i, cell in enumerate(range(cells))}
        self.assertEqual(len(set(f.values())), cells)

    def test_P3_sufficiency_floor(self):
        """MATH §7b caveat: 32 licensed postures at |B| = 4 still exceed 126 cells; 31 do not."""
        self.assertGreater(32 * 4, 126)
        self.assertLess(31 * 4, 126)

    def test_capacity(self):
        """Prop 10.1: H_sym = log2 400 ≈ 8.64 bits, above Latin log2 26 ≈ 4.70."""
        h = math.log2(400)
        self.assertTrue(8.6 < h < 8.7)
        self.assertGreater(h, math.log2(26))

    def test_chord_dimension(self):
        self.assertEqual(T["chord_dimension"], 7 * 9)


class TestTalonicsEmpiricalPending(unittest.TestCase):
    """These need outside data. Each skips with its reason: pending, never passed."""

    def _pending(self, tid):
        need = {p["test"]: p["needs"] for p in T["pending_empirical"]}[tid]
        self.skipTest(f"PENDING {tid}: {need}")

    def test_T2_timbre_enneagram(self):
        self._pending("T-2")

    def test_T3_expression_synchrony(self):
        self._pending("T-3")

    def test_T9_kc_coincidence(self):
        self._pending("T-9")


class TestPackageIntegrity(unittest.TestCase):
    def test_checksums_verify(self):
        path = os.path.join(HERE, "SHA256SUMS")
        if not os.path.exists(path):
            self.skipTest("SHA256SUMS not present (running outside the sealed package)")
        with open(path, encoding="utf-8") as f:
            lines = [l.split("  ", 1) for l in f.read().splitlines() if l.strip()]
        self.assertTrue(lines)
        for digest, name in lines:
            with open(os.path.join(HERE, name), "rb") as g:
                self.assertEqual(hashlib.sha256(g.read()).hexdigest(), digest, name)


if __name__ == "__main__":
    result = unittest.main(exit=False, verbosity=2).result
    sys.exit(0 if result.wasSuccessful() else 1)
