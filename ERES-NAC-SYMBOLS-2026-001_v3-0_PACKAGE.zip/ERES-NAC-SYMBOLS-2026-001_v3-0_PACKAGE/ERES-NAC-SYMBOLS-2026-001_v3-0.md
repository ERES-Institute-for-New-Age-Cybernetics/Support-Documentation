# NAC Symbol Register v3.0: The Expression Chain with TALONICS

**ERES-NAC-SYMBOLS-2026-001 · v3.0 Proposed** · 2026-10-05 · Joseph Allen Sprute (ORCID 0000-0001-9946-3221)

*Child app of ERES-PIVOT-VSIM-2026-001 v0.2 (App-Parent: VERTECA PlayNAC Simulator). Supersedes v2.2 and every earlier version in full.*

## Thesis

**NAC symbols live along one chain: emotion → utterance → sound → word → symbol → glyph → letter → word → character → semantic.** The chain runs once around the six Domains, from L2 VERTECA · Gate to L1 ERES · Proof, and returns to emotion. Each symbol is homed at the stage, and so the Domain, where its quantity is produced.

The chain falls into three movements, one per Trinity owner. **Voice** (✦ SOUND, L2–L3) carries a feeling out as sound. **Inscription** (⬡ BEST, L4–L5) fixes it as marks. **Meaning** (◈ GOOD, L6 and L1) settles it as standing and proven sense.

v0.1 registered the symbols by Domain. v2 orders them by what they do to meaning as it travels. Entries are tagged **On file** (already in a corpus instrument) or **Proposed** (awaiting the author's ruling).

**v3.0 adds the TALONICS layer.** TALONICS is the five-finger gestural notation in which the HPE readout is written. Its 16 mathematical symbols join the register at the stages where their quantities are produced, from manner space M at Sound to the identity readout ι at Semantic. Its Row 18 measurement elements land on stages 2 through 9; none lands on stage 1, so emotion stays unread.

## At a glance

**Voice, then Inscription, then Meaning, then back to feeling.**

![Figure 1. The expression chain: 10 stages, 3 movements, 6 Domains](fig1_expression_chain.svg)

*Figure 1. Read each column top down, then cross to the next. The dashed return is Aura After.*

## Stage register

**Ten stages, six Domains, two stages per Domain except L6 and L1, which hold one each.** All placements are Proposed; the instruments in the last column are on file.

| # | Stage | Domain | Owner | Symbols | What happens here | Instrument binding |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Emotion | L2 VERTECA · Gate | ✦ SOUND | ψ | Felt amplitude, not yet expressed. Unpriced and never read directly | PlayNAC Row 16 (emotions); HPE stress = color; infinance below K_c |
| 2 | Utterance | L2 VERTECA · Gate | ✦ SOUND | K_c · Γ | The first externalized signal crosses K_c and is admitted, never refused | ECVS thought → utterance → ARE; SUBMIT at a number anyone can call |
| 3 | Sound | L3 SECUIR · Wheel | ✦ SOUND | r · σ · π · M · C_dim | The carrier: periodic, entrainable, held in the band | Sound Holds the Band; Row 18 MUSIC |
| 4 | Word (spoken) | L3 SECUIR · Wheel | ✦ SOUND | ∞ · B | Sound given repeatable shape; the voice movement closes | HFVN UTTERANCE-SOUND resolver |
| 5 | Symbol | L4 CyberRAVE · Light | ⬡ BEST | K_cond · (a, m) | The spoken word fixed as a visible sign. Over-lock (one sign for everything) is condensation | TALONICS Symbol Matrix (452 elements); a TALONIC = (a, m) |
| 6 | Glyph | L4 CyberRAVE · Light | ⬡ BEST | Φ · Δλ(t) · A · C(5,k)·2ᵏ · ρ_k | The drawn form of the symbol: proportion and spectrum | TALONICS 18 × 7 featural alphabet; rank census over A = 𝕊₃⁵ |
| 7 | Letter | L5 GunnySack · Harvest | ⬡ BEST | ⇄ · 𝕊₃ · — ↑ ↓ | The unit a glyph settles into; letters can be permuted | IDIPITIS ⇄ IPIDITIS permutation; Semantic Spiral A–Z; TALONICS state glyphs — ↑ ↓ |
| 8 | Word (written) | L5 GunnySack · Harvest | ⬡ BEST | Σ · 𓋹 · L · Sₙ · 𝕋 · H_sym | Letters summed in order. A sum alone loses the order, so the sequence must be stored | Roll-Call Theorem (HARMONY = Σ, MELODY stored); Spiral cipher |
| 9 | Character | L6 SaleBuilders · Market | ◈ GOOD | μ · K_∞ · $ | The written mark and the person's standing at once: what the Market reads and values | EarnedPath ascent; RATE |
| 10 | Semantic | L1 ERES · Proof | ◈ GOOD | Δ · ε · ρ_R · ι · (I, X, G) | Meaning proven: it survives a change of form, never stated as an absolute | Semantic Spiral rung 4 (context); ΔForm ≠ ΔLineage; TERMS #48; G-invariant identity ι (count invariance) |

**The loop closes through Aura After**, how one feels about having signed. That feeling becomes the next turn's emotion, and the Carry Rule keeps each turn a descent rather than a reset.

**K_c is the privacy line.** Under ECVS §11 and the TALONICS boundary doctrine, only externalized signal (stage 2 onward) is read. Emotion itself is never surveilled.

**"Word" appears twice on purpose.** A spoken word drifts; a written word can lose its order. They are different objects with different failure modes.

## Domain map and full symbol register

**43 symbols: 39 on file in corpus instruments, 4 proposed.** That is 27 NAC core symbols and 16 TALONICS symbols. The hub holds the operators, the Trinity marks and the relation ≙; each Domain holds the symbols its stages produce.

![Figure 2. Domain map: Trinity hub, 6 Domains, chain stages](fig2_domain_map.svg)

*Figure 2. Each Domain owns the symbols it produces; the hub holds what binds all six.*

| Symbol | Name | NAC binding | Home | Stage | Layer | Status | Source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ☉ | Sun | Single source, shared center; the PiVOT hub | Hub | Loop | NAC core | Proposed | Lantern essay (SUN pole) |
| ◈ ✦ ⬡ | Trinity marks | ◈ owns L1, L6 · ✦ owns L2, L3 · ⬡ owns L4, L5. ◈ × ⬡ = 72; 72 × 3 = 216 = ✦ | Hub | Movements | NAC core | On file | ERES-NAC-Dual-Axis |
| × + → ÷ | Triad operators | Earned · Given · Aimed · Regulative (÷ = GAIA) | Hub | All | NAC core | On file | ERES-TRIAD-2026-001 |
| == · === | Evaluates-to · why-is | Result level and causal-ground level | Hub | All | NAC core | On file | Framework notation |
| ≈ | Maps onto | Replaces ≡ for borrowed physics | Hub | All | NAC core | Proposed | SHB MIEVM blocker |
| ψ | Psi | Infinance: unpriced amplitude below K_c | L2 Gate | 1 | NAC core | On file | ERES-TRIAD v0.5 §6.5 |
| K_c | Critical coupling | Lower band edge; the privacy line | L2 Gate | 2 | NAC core | On file | ERES-GAIA-GRID-2026-001 |
| Γ | Gamma | Admission certainty: Γ = 0 iff refusal is possible | L2 Gate | 2 | NAC core | On file | ERES-ENDHOME-2026-001 |
| r | Order parameter | Kuramoto coherence, in-band between the walls | L3 Wheel | 3 | NAC core | On file | ERES-PELLIS-SHB-001 |
| σ | Sigma (lower) | RHC returns drift to within 1σ | L3 Wheel | 3 | NAC core | On file | PlayNAC stack |
| π | Pi | The circle that never terminates; PiVOT | L3 Wheel | 3 | NAC core | On file | PiVOT (homepage) |
| ∞ | Infinity | 6F = ∞P(t); SECUIR Infinite Rotation | L3 Wheel | 4 | NAC core | On file | ERES-6F-2026-001 |
| K_cond | Condensation coupling | Upper band edge; one sign for everything | L4 Light | 5 | NAC core | On file | ERES-GAIA-GRID-2026-001 |
| Φ | Golden ratio | Conjecture F-6, outside the theorems | L4 Light | 6 | NAC core | On file (conjecture) | ERES-TALONICS-MATH v2.0 |
| Δλ(t) | Spectral abscissa | Early warning at the collapse boundary | L4 Light | 6 | NAC core | On file | ERES-CERTKPI-2026-001 (A1) |
| ⇄ | FLIP | IPIDITIS ⇄ IDIPITIS, consent-directional | L5 Harvest | 7 | NAC core | Proposed (glyph) | ERES-IPIDITIS-FLIP-2026-001 |
| Σ | Sigma (upper) | HARMONY = Σ; order recoverable only if MELODY is stored | L5 Harvest | 8 | NAC core | On file | ERES-TALONICS-MATH v2.0 |
| 𓋹 | Ankh | BEST = Bio-Electric Signature Time | L5 Harvest | 8 | NAC core | Proposed | This register |
| m* = v·τ | Margin law | Drift rate × damping latency; 98/2 | L5 Harvest | 7–8 | NAC core | On file | GAIA grid Appendix B |
| μ | Mu | TheMall's drift rate | L6 Market | 9 | NAC core | On file | GAIA grid Appendix B |
| K_∞ | Ascent ceiling | EarnedPath plateaus at K_∞ ≤ K_cond − m | L6 Market | 9 | NAC core | On file | GAIA grid Appendix B |
| R(t) | Ramp-UP | Economy = GDP + R(t)(NBERS − GDP) | L6 Market | 9 | NAC core | On file | Spaceship Economics v2.0 |
| $ | $ELF / value face | The $ in /S/$ | L6 Market | 9 | NAC core | On file | HPE frame |
| Δ | Delta | ΔRG; ΔForm ≠ ΔLineage; ΔK | L1 Proof | 10 | NAC core | On file | ERES-PELLIS-SHB-001; CPROV; GAIA grid |
| ε | Epsilon | 10−ε everywhere but the empirical 10-10 | L1 Proof | 10 | NAC core | On file | Floor Register ruling |
| ρ_R | Resonance correlation | Registry-wide coherence; 0.969 vs 0.85 | L1 Proof | 10 | NAC core | On file | EIGEN-PIPELINE v0.2 |
| G(φ, λ) | Thermal Gauge | The one place 10-10 is earned | L1 Proof | 10 | NAC core | On file | ERES-VX-THERMAL-GAUGE |
| ≙ | Structurally the same as | Pattern identity inside a stated model; weaker than ≡, stronger than ≈ | Hub | All | TALONICS | On file | ERES-TALONICS-MATH v2.0 notation |
| M | Manner space | M ⊆ ℝᵏ: velocity, pressure, dwell, latency, tremor; the continuous how that carries affect | L3 Wheel | 3 | TALONICS | On file | TALONICS-MATH v2.0 Def 1.4 |
| C_dim | Sensor ceiling | ½·log₂(1 + SNR) bits per manner dimension; the sensor carries more than the glyph | L3 Wheel | 3 | TALONICS | On file | TALONICS-MATH v2.0 Prop 10.2 |
| B | Manner bands | \|B\| = 4 quantized bands of manner (attack, dwell): sound given repeatable shape | L3 Wheel | 4 | TALONICS | On file | TALONICS-WP v2.0 §16.1; TALONICS-TEST v2.0 |
| (a, m) | TALONIC | One written sign = segment a (what) × manner m (how); the same a with a different m is a different TALONIC | L4 Light | 5 | TALONICS | On file | TALONICS-MATH v2.0 Def 1.5 |
| A | Segment space | A = 𝕊₃⁵: five fingers × three states = 243 postures; the identity of a sign | L4 Light | 6 | TALONICS | On file | TALONICS-MATH v2.0 Def 1.3 |
| C(5,k)·2ᵏ | Rank census | Postures with k engaged fingers: 1, 10, 40, 80, 80, 32; sum 3⁵ = 243 | L4 Light | 6 | TALONICS | On file | TALONICS-MATH v2.0 Thm 2.3 |
| ρ_k | Survival fraction | Share of rank-k postures licensed by ergonomics; sets \|A_licensed\| ≈ 80–120 | L4 Light | 6 | TALONICS | On file (conjecture) | TALONICS-MATH v2.0 Def 2.5, F-4 |
| 𝕊₃ | State set | {flat, extended, flexed} per finger; flat = rest. The letter-level unit | L5 Harvest | 7 | TALONICS | On file | TALONICS-TEST v2.0; TALONICS-MATH v2.0 Def 1.2 |
| — ↑ ↓ | TALONICS state glyphs | — flat · ↑ extended · ↓ flexed; one column per finger, thumb to pinky. ↑—↓↑— = Health active, Middle withdrawn, Ring active | L5 Harvest | 7 | TALONICS | On file | TALONICS-WP v2.0 §16.4; TALONICS-TEST v2.0 T-7 |
| L | MELODY | The ordered sequence (v₁, …, vₙ) stored to Gracechain/SOMT; injective, so the roll-call survives | L5 Harvest | 8 | TALONICS | On file | TALONICS-MATH v2.0 Def 7.1, Cor 7.3 |
| Sₙ | Symmetric group | All re-orderings of n contributions; HARMONY Σ is Sₙ-invariant, so the sum alone forgets who | L5 Harvest | 8 | TALONICS | On file | TALONICS-MATH v2.0 Thm 7.2 |
| 𝕋 | Written symbol set | 𝕋 = A_licensed × B ≈ 400 signs > 126 PlayNAC cells, so an injective address map exists (3.17×) | L5 Harvest | 8 | TALONICS | On file | TALONICS-MATH v2.0 Thm 7b.2; TALONICS-TEST v2.0 |
| H_sym | Symbol entropy | log₂\|𝕋\| ≈ 8.6 bits per sign (Latin ≈ 4.7) | L5 Harvest | 8 | TALONICS | On file | TALONICS-MATH v2.0 Prop 10.1 |
| ι | Identity readout | G-invariant: no manner or weight operation changes the identity or the count. The FLOOR is the invariant of the action | L1 Proof | 10 | TALONICS | On file | TALONICS-MATH v2.0 Def 6.1, Cor 6.5 |
| (I, X, G) | Channel-separated structure | Identity set I, state X, monoid G acting on X only. Segment : manner ≙ count : weight | L1 Proof | 10 | TALONICS | On file | TALONICS-MATH v2.0 Def 6.1, Thm 6.3 |

## TALONICS layer

**TALONICS rides the chain from utterance to character, and nothing in it reads emotion.** A TALONIC is one written sign (a, m): a posture a from the segment space A = 𝕊₃⁵ (what) carrying a manner m from M ⊆ ℝᵏ (how). Its seven Row 18 elements measure the externalized signal at stages 2 to 9. Stage 1 carries none, which is the boundary doctrine stated as structure.

![Figure 3. TALONICS on the expression chain: five-finger key and Row 18 crosswalk](fig3_talonics_crosswalk.svg)

*Figure 3. Five fingers carry five pillars; each Row 18 element sits at the stage it measures.*

### Five-finger key

| Finger | Pillar | SCALULAR code |
| --- | --- | --- |
| Thumb | Health | SSHP |
| Index | Law | SSLA |
| Middle | Protection | SSPS |
| Ring | Love/Water | — |
| Pinky | Trades/Cybernetics | SSST |

State glyphs, one column per finger from thumb to pinky: **↑ extended · — flat · ↓ flexed**. Example ↑—↓↑— reads Health active, Middle withdrawn, Ring active. In the binary model, 11111 (open palm) is the full system and 00000 (fist) is reset or silence.

### Row 18 crosswalk

| Element | Function | Chain stage | Domain | Placement |
| --- | --- | --- | --- | --- |
| PERFORMANCE | Enacted output: the CAST, a priced act crossing K_c | 2 · Utterance | L2 VERTECA · Gate | Proposed |
| RHYTHM | Temporal marking; baseline and artifact separation | 3 · Sound | L3 SECUIR · Wheel | Proposed |
| EXPRESSION | Phase coherence, measured as the Kuramoto order parameter r | 3 · Sound | L3 SECUIR · Wheel | Proposed |
| COMPOSITION | Grammar: 3D × 7 columns × 18 rows; the one segment-carrier | 6 · Glyph | L4 CyberRAVE · Light | Proposed |
| MELODY | Sequential progression; the EarnedPath record deposited to Gracechain | 8 · Word (written) | L5 GunnySack · Harvest | Proposed |
| HARMONY | Simultaneous combination; the 63-position governance chord (Σ) | 8 · Word (written) | L5 GunnySack · Harvest | Proposed |
| TIMBRE | Gestural quality; Enneagram-type signature, an index only (F-1) | 9 · Character | L6 SaleBuilders · Market | Proposed |

PERFORMANCE sits on the K_c crossing at stage 2, where the CAST becomes a priced act. MELODY and HARMONY share stage 8 with Σ and L, which is the Roll-Call Theorem in place: the chord forgets who, the stored sequence remembers. TIMBRE reaches Character only as an index, never as a reading of type.

### Grammatical units

| Unit | What it is | Chain stage |
| --- | --- | --- |
| Apparition | Single-finger gesture; rank 1, \|A₁\| = 10 | 7 · Letter |
| Condition | Hand position and orientation | 6 · Glyph |
| Notion | Temporal sequence of gestures | 8 · Word (written) |

### Derived numbers

| Claim | Value | Tag | Source |
| --- | --- | --- | --- |
| Binary posture count | 2⁵ = 32 | DERIVED | MATH Prop 2.1 |
| Ternary posture count | 3⁵ = 243 | DERIVED | MATH Prop 2.1 |
| Rank census, k = 0…5 | 1 · 10 · 40 · 80 · 80 · 32 | DERIVED | MATH Thm 2.3 |
| Apparitions | \|A₁\| = C(5,1)·2 = 10 | DERIVED | MATH Cor 2.4 |
| Licensed postures | \|A_licensed\| ≈ 80–120 | CONJECTURE (values, F-4) | MATH Def 2.5 |
| Written signs vs PlayNAC cells | \|𝕋\| ≈ 400 > 126 = 18 × 7; ratio 3.17× | DERIVED (conditional on F-4) | MATH Thm 7b.2 |
| Sufficiency floor | ≥ 32 licensed postures at \|B\| = 4 gives 128 > 126 | DERIVED | MATH §7b caveat |
| Symbol entropy | H_sym = log₂ 400 ≈ 8.64 bits; Latin log₂ 26 ≈ 4.70 | DERIVED (approximate) | MATH Prop 10.1 |
| Chord dimension | d = 63 = 7 CBGMODD seats × 9 Enneagram types | DERIVED | MATH §7 |
| Complexity | Every governance operation is O(n) in participants | DERIVED | MATH §10b |

### Empirical tests still pending

The test suite runs every derived TALONICS claim above. These three need outside data and are carried as pending, never passed:

- **T-2.** TIMBRE → Enneagram: blind agreement against an independently validated affect baseline (F-1). Reclassify TIMBRE as decorative on failure.
- **T-3.** EXPRESSION: Kuramoto order parameter r measured under real entrainment versus control (F-2).
- **T-9.** K_c coincidence: pre-registered K_c(Φ) = K_c(6) spectral test (F-6). Retract the buckle on failure.

## The five named keys

**Δ, ∞ and Φ already carry corpus math. ☉ has a corpus meaning but no math yet. 𓋹 is new.**

| Key | Reading | NAC binding | Home | Chain stage | Status |
| --- | --- | --- | --- | --- | --- |
| **☉** Sun | A circle with its center marked | The SUN pole of "A Lantern for the Lost Believer": the source that gives freely. Geometry of the PiVOT wheel: one hub, six Domains on the rim | Trinity hub | The whole loop | Proposed |
| **𓋹** Ankh | Life; a loop set on a cross | BEST = Bio-Electric Signature Time. A closed loop (RHC return) set on the KOL cross-hairs. Harvest gathers what a life carries: EPIR-Q, IDIPITIS, SOMT | L5 Harvest | 8 · Word (written) | Proposed (new) |
| **Δ** Delta | Measured change | ΔRG spectral gap; ΔForm ≠ ΔLineage; ΔK band width | L1 Proof | 10 · Semantic | On file |
| **∞** Infinity | Unbounded continuation | 6F = ∞P(t); SECUIR Infinite Rotation | L3 Wheel | 4 · Word (spoken) | On file |
| **Φ** Golden ratio | Φ = (1 + √5) / 2 ≈ 1.618 | TALONICS-MATH conjecture F-6, kept out of the theorems | L4 Light | 6 · Glyph | On file as a conjecture |

Φ stays a conjecture until a derivation or measured fit promotes it, per the Doctrine of Verifiable Claims. Dr. Pellis's Golden-Fractal operator G is cited as his own work, never absorbed into ERES.

## Collisions and usage rules

**10 symbols carry two readings. Each gets one rule.**

| Symbol | Reading A | Reading B | Rule |
| --- | --- | --- | --- |
| φ / Φ | Latitude in G(φ, λ) | Golden ratio | Lowercase φ = latitude only. Capital Φ = golden ratio only. F-6 is written Φ ↔ 6 |
| λ | Longitude in G(φ, λ) | Spectral eigenvalue | Bare λ = longitude. Spectral uses carry their operator: Δλ(t), λ_max |
| Δ | Measured change | The Triangle (WHO · HOW · LEGACY) | Δ = change. The Triangle is drawn △ or named in words |
| σ / Σ | RHC tolerance, 1σ | HARMONY sum | Lowercase σ = spread. Capital Σ = sum |
| A | Segment space 𝕊₃⁵ (TALONICS) | Alignment factor in PoR = A × R × P × F | In TALONICS text A is the segment space; PoR factors appear only inside the product A × R × P × F |
| B | Manner bands, \|B\| = 4 | Backlog stock B(t) in The TREND | Bands are written B or \|B\|; the backlog always carries its time argument B(t) |
| L | MELODY sequence L(v₁, …, vₙ) | Domain identifiers L1–L6 | A Domain is always L plus a digit; MELODY is written L(·) or named MELODY |
| M | Manner space M ⊆ ℝᵏ | M in the Triune Math (C = R × P / M; M × E + C = R) | Inside a Triune formula M keeps its formula meaning; in TALONICS text write M ⊆ ℝᵏ on first use |
| H | HARMONY H(v) = Σvᵢ (TALONICS-MATH) | H_sym entropy; H(t) stock in ENDHOME | The register writes HARMONY as Σ; entropy is always H_sym; a stock always carries (t) |
| ↑ | TALONICS state glyph: extended | Lookalike a lossy PDF reader substituted for 𓋹 | ↑ appears only in the TALONICS state-glyph set and means extended; it never stands for ANKH |

1. **Maps-onto, not identity.** Borrowed physics takes ≈ or "maps onto"; ≡ is reserved for proven identity. This settles the objection four MIEVM nodes raised on "Sound Holds the Band".
2. **Constants are earned.** A symbol becomes a NAC constant only with a derivation or a measured fit.
3. **One home, many uses.** Any Domain may use any symbol; only its home Domain may redefine it, by a register version cut (N.EXT).
4. **Relation ladder.** ≡ is proven identity; ≙ is structural sameness inside a stated model (segment : manner ≙ count : weight); ≈ is analogy, maps onto. A relation is never upgraded without the proof the higher rung needs.

## Glyph integrity

**Every symbol has a code point, a Unicode name and an ASCII handle, so any reader, human or machine, recovers the exact glyph.** Cite a symbol by its handle when a renderer or text extractor might substitute a lookalike. None of the lookalikes ○ (U+25CB), ⊙ (U+2299) or ⇌ (U+21CC) is a register symbol. ↑ (U+2191) is restricted: it appears only in the TALONICS state-glyph set, where it means extended.

| Symbol | ASCII handle | Code points | Unicode names |
| --- | --- | --- | --- |
| ☉ | SUN | U+2609 | SUN |
| ◈ ✦ ⬡ | TRINITY | U+25C8 U+2726 U+2B21 | WHITE DIAMOND CONTAINING BLACK SMALL DIAMOND; BLACK FOUR POINTED STAR; WHITE HEXAGON |
| × + → ÷ | TRIAD_OPS | U+00D7 U+2192 U+00F7 | MULTIPLICATION SIGN; RIGHTWARDS ARROW; DIVISION SIGN |
| == · === | EVAL_WHYIS | U+00B7 | MIDDLE DOT |
| ≈ | MAPS_ONTO | U+2248 | ALMOST EQUAL TO |
| ψ | PSI | U+03C8 | GREEK SMALL LETTER PSI |
| K_c | K_C | ASCII only | — |
| Γ | GAMMA | U+0393 | GREEK CAPITAL LETTER GAMMA |
| r | R_ORDER | ASCII only | — |
| σ | SIGMA_LOWER | U+03C3 | GREEK SMALL LETTER SIGMA |
| π | PI | U+03C0 | GREEK SMALL LETTER PI |
| ∞ | INFINITY | U+221E | INFINITY |
| K_cond | K_COND | ASCII only | — |
| Φ | PHI_GOLDEN | U+03A6 | GREEK CAPITAL LETTER PHI |
| Δλ(t) | DELTA_LAMBDA_T | U+0394 U+03BB | GREEK CAPITAL LETTER DELTA; GREEK SMALL LETTER LAMDA |
| ⇄ | FLIP | U+21C4 | RIGHTWARDS ARROW OVER LEFTWARDS ARROW |
| Σ | SIGMA_UPPER | U+03A3 | GREEK CAPITAL LETTER SIGMA |
| 𓋹 | ANKH | U+132F9 | EGYPTIAN HIEROGLYPH S034 |
| m* = v·τ | MARGIN_LAW | U+00B7 U+03C4 | MIDDLE DOT; GREEK SMALL LETTER TAU |
| μ | MU | U+03BC | GREEK SMALL LETTER MU |
| K_∞ | K_INF | U+221E | INFINITY |
| R(t) | RAMP_R | ASCII only | — |
| $ | SELF_VALUE | ASCII only | — |
| Δ | DELTA | U+0394 | GREEK CAPITAL LETTER DELTA |
| ε | EPSILON | U+03B5 | GREEK SMALL LETTER EPSILON |
| ρ_R | RHO_R | U+03C1 | GREEK SMALL LETTER RHO |
| G(φ, λ) | G_PHI_LAMBDA | U+03C6 U+03BB | GREEK SMALL LETTER PHI; GREEK SMALL LETTER LAMDA |
| ≙ | STRUCT_SAME | U+2259 | ESTIMATES |
| M | MANNER_SPACE | ASCII only | — |
| C_dim | C_DIM | ASCII only | — |
| B | MANNER_BANDS | ASCII only | — |
| (a, m) | TALONIC | ASCII only | — |
| A | SEGMENT_SPACE | ASCII only | — |
| C(5,k)·2ᵏ | RANK_CENSUS | U+00B7 U+1D4F | MIDDLE DOT; MODIFIER LETTER SMALL K |
| ρ_k | RHO_K | U+03C1 | GREEK SMALL LETTER RHO |
| 𝕊₃ | STATE_SET | U+1D54A U+2083 | MATHEMATICAL DOUBLE-STRUCK CAPITAL S; SUBSCRIPT THREE |
| — ↑ ↓ | STATE_GLYPHS | U+2014 U+2191 U+2193 | EM DASH; UPWARDS ARROW; DOWNWARDS ARROW |
| L | MELODY_L | ASCII only | — |
| Sₙ | SYM_GROUP | U+2099 | LATIN SUBSCRIPT SMALL LETTER N |
| 𝕋 | WRITTEN_SET | U+1D54B | MATHEMATICAL DOUBLE-STRUCK CAPITAL T |
| H_sym | H_SYM | ASCII only | — |
| ι | IOTA | U+03B9 | GREEK SMALL LETTER IOTA |
| (I, X, G) | CHANNEL_SEP | ASCII only | — |

## Review reconciliation

**13 findings adopted, 6 not adopted, 2 noted, across the v2.2 DeepSeek review and the v3.0 integration checks.** The DeepSeek single-node review (5 Oct 2026) rated the v2.1 test suite 7.5/10 for structural design and 6/10 for robustness. Its glyph findings were checked against the PDF text layer and the JSON register: the source glyphs are correct, and the mismatches came from the reviewer's text extraction. Those findings still pointed at a real weakness for machine readers, which the Glyph integrity table now closes.

| Finding | Source | Disposition | Action |
| --- | --- | --- | --- |
| File discovery crashes on zero or several matching files | DeepSeek | Adopted | Tests now require exactly one register and one master text, with a clear message |
| Status values not validated | DeepSeek | Adopted | Every status must start with On file or Proposed |
| Placement status and symbol status conflated | DeepSeek | Adopted | Stages carry their own placement_status (all Proposed); tested |
| Δ collision rule untested | DeepSeek | Adopted | Test requires the Triangle to be written △ |
| Three usage rules untested | DeepSeek | Adopted | Test checks all three rules are present |
| Movement-to-Domain ranges implicit | DeepSeek | Adopted | Voice = L2–L3, Inscription = L4–L5, Meaning = L6 + L1, tested |
| Hub contents unchecked | DeepSeek | Adopted | Hub must hold exactly ☉, Trinity marks, triad operators, ==/===, ≈ |
| Named-key fields unchecked | DeepSeek | Adopted | Reading, binding, stage and status required and matched to the register |
| Change log, open items, credits, references, license unchecked | DeepSeek | Adopted | Section and exact-license tests added |
| Glyphs fragile for machine readers | DeepSeek (implied) | Adopted | New Glyph integrity table: code point, Unicode name and ASCII handle for every symbol; lookalike guard test |
| Instrument IDs lose hyphens at PDF line breaks | Claude verification | Adopted | IDs kept on one line in the PDF |
| ☉ read as ○ or ⊙ | DeepSeek | Not adopted | Extraction artifact. Source glyph is ☉ U+2609; PDF text layer reads ☉ |
| 𓋹 read as Γ or ↑ | DeepSeek | Not adopted | Extraction artifact. Source glyph is 𓋹 U+132F9; Γ is Gamma only |
| ⇄ read as π, πFLIP or ⇌ | DeepSeek | Not adopted | Extraction artifact. Source glyph is ⇄ U+21C4; π is stage 3 only |
| Duplicate Γ and duplicate π | DeepSeek | Not adopted | Not present in the register; uniqueness test passes |
| # shown at Letter | DeepSeek | Not adopted | Not present; stage 7 symbol is ⇄ |
| License reads CC- BY | DeepSeek | Not adopted | Line-wrap artifact; text layer reads CC-BY 4.0 |
| ECVS §11, Carry Rule, Pellis non-absorption, Φ promotion rule | DeepSeek | Noted | Text-presence checks only; their truth needs outside review |
| TALONIC unit and channel-separated-structure glyphs did not survive text extraction in TALONICS-MATH v2.0 | Claude verification (v3.0) | Adopted | Registered by their tuples (a, m) and (I, X, G) with handles TALONIC and CHANNEL_SEP; author to supply the glyphs |
| ↑ excluded in v2.2 but used by TALONICS for extended | Claude verification (v3.0) | Adopted | ↑ restricted, not excluded: admitted only in the state-glyph set, never for ANKH |
| TALONICS-WP v2.0 §2 lists CBGMODD with Media and Organisation seats | Claude verification (v3.0) | Noted | Pre-TERMS-48 form; this register follows the TERMS #48 lock |

## Change log

| Version | Date | Change |
| --- | --- | --- |
| v3.0 | 5 Oct 2026 | Extended the register with the TALONICS layer: 16 symbols from TALONICS-WP, MATH and TEST v2.0 homed on the chain (43 in all); Row 18 crosswalk (seven elements on stages 2–9, none on stage 1); five-finger key; grammatical units; derived numbers; six new collision rules and the relation ladder. TALONICS structural tests folded into the suite; T-2, T-3 and T-9 carried as pending empirical tests. No v2.2 symbol, placement or rule changed except ↑, now admitted only as the TALONICS extended glyph |
| v2.2 | 5 Oct 2026 | Assimilated the DeepSeek single-node review: 11 findings adopted, 6 not adopted as PDF-extraction artifacts, 1 noted. Added Glyph integrity table (code points, Unicode names, ASCII handles), placement status per stage, Review reconciliation, parent link to the App-Parent, expanded test suite. No symbol, placement or rule changed |
| v2.1 | 5 Oct 2026 | Restored four v0.1 details: per-symbol Source column, two open items (𓋹 placement; further symbols), the 𓋹 Harvest rationale, and the SHB note on ≈. Fully supersedes v0.1. Released as a package |
| v2.0 | 5 Oct 2026 | Reorganized around the ten-stage expression chain; three movements (Voice, Inscription, Meaning) tied to the Trinity owners; K_c named as the privacy line; Aura After closes the loop |
| v0.1 | 5 Oct 2026 | 27 symbols homed in the 6 Domains plus the Trinity hub; five named keys; four collision rules |

## Open items

- [ ] Rule on the ten stage placements.
- [ ] Character: L6 Market (a person's standing) or L1 Proof (meaning)?
- [ ] Rule on the four proposed symbols: ☉ at the hub, 𓋹 at L5 Harvest, ⇄ as the FLIP glyph, ≈ replacing ≡ for analogies.
- [ ] Confirm or move 𓋹: L5 Harvest (life carried) or L4 Light (both are ⬡ BEST).
- [ ] Φ: keep as a conjecture or design a test, run by someone other than the author.
- [ ] Add any further symbols you want registered (for example Ω, ω, ∇) with the quantity each one names.
- [ ] Fold the register into TERMS #49 so symbols and words share one lexicon.
- [ ] Adopt the ASCII handles (SUN, ANKH, FLIP, …) as the canonical machine keys for every symbol.
- [ ] Drop the App-Parent v0.2 cross-child item on "duplicate Γ and π"; the review reconciliation shows it was an extraction artifact.
- [ ] Supply the source glyphs for the TALONIC unit (a, m) and the channel-separated structure (I, X, G).
- [ ] Rule on the Row 18 crosswalk: seven elements placed on stages 2, 3, 6, 8 and 9.
- [ ] Run the empirical tests T-2, T-3 and T-9 with outside data; retract or reclassify on failure.
- [ ] Fund the ergonomic study that sets ρ_k and |A_licensed|.
- [ ] Build the explicit 126-row address map f: Cells ↪ 𝕋 (TALONICS-WP §14, row 16).
- [ ] Confirm the TALONIC / TALONICS term-lock (F-8).
- [ ] Name the SCALULAR code for the fifth finger pillar, Love/Water.

## Credits

Author: Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221. Drafting assistance: Claude (Anthropic), under the ERES Sentience convention, not co-authorship. Dr. Stergios Pellis's Golden-Fractal operator and spectral-gap work are cited as his own; no endorsement is implied. The v2.1 review by DeepSeek (single node, 5 Oct 2026) is credited for the findings adopted in v2.2; it is recorded, not counted toward the MIEVM gate. The TALONICS instruments (WP, MATH and TEST v2.0) are the author's own, drafted with Claude under the Credit Protocol.

## References

1. ERES-PIVOT-VSIM-2026-001 v0.2, App-Parent: VERTECA PlayNAC Simulator (parent instrument of this register).
2. DeepSeek single-node review of v2.1 and its test suite, 5 Oct 2026 (recorded; not gate-eligible).
3. ERES-NAC-Dual-Axis Stack: the 6 NAC Nodes and Trinity ownership. https://eresinstitute.org/ERES-NAC-Dual-Axis.html
4. ERES TERMS #48, Talonic NAC Lexicon. https://eresinstitute.org/eresmaestro/download/ERES-TERMS-48.pdf
5. ERES-TRIAD-2026-001: × + → ÷ operator law; ψ at §6.5.
6. ERES-PELLIS-SHB-001, "Sound Holds the Band": ΔRG, r, K_c, K_cond.
7. ERES-GAIA-GRID-2026-001, Appendix B: m* = v·τ, μ, K_∞.
8. ERES-TALONICS-WP-2026-001 v2.0, Complete Description: Row 18, featural glyph, worked example, boundary doctrine.
9. ERES-TALONICS-MATH-2026-001 v2.0: rank census, channel-separation isomorphism, Roll-Call Theorem, P³ sufficiency, capacity, conjecture F-6.
10. ERES-TALONICS-TEST-2026-001 v2.0 (eres_talonics_v2_test.py): structural suite folded into this package.
11. TALONICS 5-finger symbol index (finger–pillar key; open palm 11111, fist 00000).
12. Y. Kuramoto, Chemical Oscillations, Waves, and Turbulence, 1984; C. E. Shannon, "A Mathematical Theory of Communication," 1948 (external results cited by TALONICS-MATH).
13. ERES Semantic Spiral (3-Tier Semantics, 29 Mar 2024) and cipher harness v0.2.
14. ECVS §11: no thought surveillance.
15. ERES-HFVN UTTERANCE-SOUND framework.
16. ERES-ENDHOME-2026-001: Γ.
17. ERES-VX-THERMAL-GAUGE-2026-001: G(φ, λ).
18. ERES-CERTKPI-2026-001, amendment A1: Δλ(t).
19. ERES-IPIDITIS-FLIP-2026-001.
20. "A Lantern for the Lost Believer" (25 Jul 2026).
21. Spaceship Economics, Book Edition v2.0. DOI 10.6084/m9.figshare.32975624.

## License

CCAL v2.1 / CC-BY 4.0
