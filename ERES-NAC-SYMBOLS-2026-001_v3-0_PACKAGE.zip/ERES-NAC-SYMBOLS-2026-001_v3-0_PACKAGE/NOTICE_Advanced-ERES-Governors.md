# NOTICE to Advanced ERES Governors

**Release:** ERES-NAC-SYMBOLS-2026-001 v3.0, NAC Symbol Register: The Expression Chain with TALONICS
**Date:** 2026-10-05
**From:** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221
**Parent instrument:** ERES-PIVOT-VSIM-2026-001 v0.2 (App-Parent: VERTECA PlayNAC Simulator)
**Status:** Proposed, pre-MIEVM · License CCAL v2.1 / CC-BY 4.0

## What this is

The NAC Symbol Register gives every mathematical symbol used in New Age Cybernetics one home among the six NAC Domains (L1 ERES · Proof through L6 SaleBuilders · Market), with binding operators at the Trinity hub. It orders the symbols along a ten-stage expression chain, from emotion through utterance, sound, word, symbol, glyph, letter, written word and character to semantic, and back through Aura After. It is the lexicon layer of the VERTECA PlayNAC Simulator.

## What changed in v3.0

- **TALONICS joins the register.** The five-finger gestural notation adds 16 symbols, from manner space M to the identity readout ι, each homed at the stage where its quantity is produced. The register now holds 43 symbols: 39 on file, 4 proposed.
- **Row 18 lands on the chain.** PERFORMANCE, RHYTHM, EXPRESSION, COMPOSITION, MELODY, HARMONY and TIMBRE sit on stages 2 to 9. None sits on stage 1, so emotion stays unread by construction.
- **New usage rules.** Six new collision rules (A, B, L, M, H, ↑) and a relation ladder: ≡ proven identity, ≙ structural sameness inside a model, ≈ analogy.
- **The TALONICS proofs now run.** The test suite folds in the TALONICS structural tests (rank census, orthogonality, count invariance, Roll-Call, boundary, glyph round-trip, contestability, P³ sufficiency, capacity). It now has 70 tests: all structural tests pass, and the three empirical tests (T-2, T-3, T-9) are reported as pending, never as passed.
- **No v2.2 symbol, placement or rule changed**, except that ↑ is now admitted as the TALONICS "extended" glyph and nowhere else.

## What we ask of you

1. **Run the tests.** Unzip the package and run `python3 test_nac_symbols.py` (Python 3.8+, standard library only). Exit code 0 means every structural invariant holds; "skipped" marks the pending empirical tests.
2. **Rule or rate the open items.** These are the four proposed symbols (☉ SUN, 𓋹 ANKH, ⇄ FLIP, ≈ MAPS_ONTO), the ten stage placements, the Row 18 crosswalk, and whether Character belongs at L6 Market or L1 Proof.
3. **Return a rating in MIEVM form.** Give a composite score out of 10, itemized deductions keyed to section names, and any finding with its file and line. When you cite a symbol, use its ASCII handle.

Ratings are recorded and credited by name. They count toward the MIEVM gate only as independent nodes, and they are never described as peer review unless they are formal peer review. Canonization requires at least five nodes with a mean of 9.0 or higher.

## Package

`ERES-NAC-SYMBOLS-2026-001_v3-0_PACKAGE.zip` contains the master text (MD and PDF), the JSON register, three SVG figures, the test suite, README, META, CITATION.cff, this Notice and SHA256SUMS. DOI pending.

Joseph Allen Sprute · ERES Institute for New Age Cybernetics · Bella Vista, Arkansas · https://eresinstitute.org
