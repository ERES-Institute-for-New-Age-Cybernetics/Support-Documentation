# NAC Symbol Register v3.0: The Expression Chain with TALONICS

**ERES-NAC-SYMBOLS-2026-001 · v3.0 · Proposed (pre-MIEVM) · 2026-10-05**

A register that gives every mathematical symbol used in ERES New Age Cybernetics one home among the six NAC Domains (L1 ERES · Proof, L2 VERTECA · Gate, L3 SECUIR · Wheel, L4 CyberRAVE · Light, L5 GunnySack · Harvest, L6 SaleBuilders · Market), ordered along a ten-stage expression chain from emotion to semantic, with the TALONICS five-finger gesture notation as its second layer.

## Contents

| File | What it is |
| --- | --- |
| `ERES-NAC-SYMBOLS-2026-001_v3-0.md` | Master text (source of truth for humans and machines) |
| `ERES-NAC-SYMBOLS-2026-001_v3-0.pdf` | Rendered companion of the master text, with all three figures |
| `ERES-NAC-SYMBOLS-2026-001_v3-0_register.json` | Machine-readable register: domains, stages, symbols (with layer, code points, ASCII handles), TALONICS block, collisions, rules |
| `fig1_expression_chain.svg` | Figure 1: the chain in three movements |
| `fig2_domain_map.svg` | Figure 2: Trinity hub and the six Domains, NAC core and TALONICS |
| `fig3_talonics_crosswalk.svg` | Figure 3: five-finger key and the Row 18 crosswalk |
| `test_nac_symbols.py` | Test suite: register invariants, TALONICS proofs, pending empirical tests, package checksums |
| `CITATION.cff` | Citation metadata |
| `META.txt` | Title, abstract, keywords, license, citation line |
| `NOTICE_Advanced-ERES-Governors.md` | General Notice to Advanced ERES Governors announcing this release |
| `SHA256SUMS` | Checksums for every file above |

## Run the tests

Python 3.8 or later, standard library only:

```
python3 test_nac_symbols.py
```

Exit code 0 means every structural invariant holds. The tests check structure, not truth: they confirm the register is internally consistent (counts, homes, chain order, ownership, collision rules). They also run every derived TALONICS claim (rank census, orthogonality, count invariance, Roll-Call, boundary, glyph round-trip, contestability, P³ sufficiency, capacity). The three TALONICS empirical tests (T-2, T-3, T-9) need outside data and are reported as skipped with the reason, never as passed. No test validates a physical or empirical claim.

## Status

v3.0 is Proposed and a child app of ERES-PIVOT-VSIM-2026-001 v0.2 (App-Parent: VERTECA PlayNAC Simulator). It extends v2.2 with the TALONICS layer (16 symbols, the Row 18 crosswalk, the five-finger key) and keeps the v2.2 review record. Thirty-nine of 43 symbols are on file in prior corpus instruments; four are proposed (☉, 𓋹, ⇄, ≈). All stage and Row 18 placements await the author's ruling. Canonization requires an MIEVM pass of at least five nodes with mean ≥ 9.0. Φ and the ρ_k values are held as conjectures.

## License

CCAL v2.1 / CC-BY 4.0. Author: Joseph Allen Sprute, ORCID 0000-0001-9946-3221. ERES Institute for New Age Cybernetics, https://eresinstitute.org
