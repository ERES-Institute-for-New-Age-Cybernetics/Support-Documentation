#!/usr/bin/env python3
"""
ERES-JPN-FUSION-ADOPTION-2026-001 v0.1 — Test Kit / テストキット
"Semiconduction to Fusion" — companion test suite.

Author : Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221
License: CC BY 4.0 (text and code). No patent or trademark rights licensed
         (CC BY 4.0 s.2(b)(2)). See paper s.10.
Python : 3.8+, standard library only. Deterministic. Exit code = verdict
         (0 = all non-SKIP tests PASS, 1 = any FAIL).

Usage:   python3 eres_jpn_fusion_testkit.py [--dir PATH] [--json]
         --dir  folder holding the EN/JA papers (default: this file's folder)
         --json also print a machine-readable result record

Tests confirm each structural rule AND falsify its null (a wrong model must
fail). Empirical claims (S1-S3) report SKIP until real data are supplied.
各構造ルールを確認し、その帰無仮説を反証します。経験的主張は実データ提供まで SKIP。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
from typing import Callable, Dict, List, Optional, Tuple

INSTRUMENT = "ERES-JPN-FUSION-ADOPTION-2026-001"
VERSION = "v0.1"
EN_FILE = INSTRUMENT + "_v0_1_EN.md"
JA_FILE = INSTRUMENT + "_v0_1_JA.md"
TOL = 1e-9

# ---------------------------------------------------------------- core model
def hazard(p: float) -> float:
    """Proposition 1: p = exp(-H)  ->  H = -ln p   (p in (0,1])."""
    if not (0.0 < p <= 1.0):
        raise ValueError("probability must be in (0, 1]")
    return -math.log(p)


def survival(h: float) -> float:
    if h < 0:
        raise ValueError("hazard must be >= 0")
    return math.exp(-h)


def poisson_yield(area_cm2: float, d0_per_cm2: float) -> float:
    """S-model: Y = exp(-A * D0)."""
    return math.exp(-area_cm2 * d0_per_cm2)


# Reference phase-transition rates (BIO/Informa/QLS 2021, 2011-2020 aggregate).
PHARMA_REF = (0.520, 0.289, 0.578, 0.906)

BANDS: Tuple[Tuple[str, float], ...] = (  # (grade, upper bound on h) CONSTRUCTED
    ("BEST", 0.50), ("SOUND", 0.80), ("GOOD", 1.00))
ORDER = {"BELOW": 0, "GOOD": 1, "SOUND": 2, "BEST": 3}


def normalized(h_obs: float, h_ref: float) -> float:
    if h_ref <= 0:
        raise ValueError("reference hazard must be > 0")
    return h_obs / h_ref


def grade(h_norm: float, empirical: bool = False) -> str:
    """Grade band; epistemic cap: illustrative inputs can never reach BEST."""
    for g, ub in BANDS:
        if h_norm <= ub:
            if g == "BEST" and not empirical:
                return "SOUND"
            return g
    return "BELOW"


def fuse_min(g_s: str, g_p: str) -> str:
    """F2 Non-Collapse: fused grade = meet (minimum)."""
    return g_s if ORDER[g_s] <= ORDER[g_p] else g_p


def fuse_mean_NULL(g_s: str, g_p: str) -> str:
    """Rejected null model: averaging (allows masking)."""
    inv = {v: k for k, v in ORDER.items()}
    return inv[round((ORDER[g_s] + ORDER[g_p]) / 2 + 1e-9)]


def rate(cbgmodd: float, bera: float, favors: float) -> float:
    """F3: RATE = CBGMODD x BERA + FAVORS  (inputs in [0,1])."""
    return cbgmodd * bera + favors


def rate_NULL(cbgmodd: float, bera: float, favors: float) -> float:
    """Rejected null: floor enters multiplicatively (can be zeroed)."""
    return cbgmodd * bera * favors


def apply_shock(merit: float, floor_n: float, h: float) -> Tuple[float, float]:
    """Humane invariant: hazard decrements merit M only, never floor N."""
    return merit * survival(h), floor_n


LADDER = ("A0", "A1", "A2", "A3", "A4", "A5")


def ladder_valid(evidence: Dict[str, bool]) -> Tuple[bool, str]:
    """Highest claimable stage = longest evidenced prefix; gaps invalidate."""
    reached = "NONE"
    gap = False
    for st in LADDER:
        if evidence.get(st, False):
            if gap:
                return False, st
            reached = st
        else:
            gap = True
    return True, reached


CURRENT_EVIDENCE = {"A0": True}  # contact made; proposal transmitted

# Withheld names are matched by SHA-256 of lowercase word tokens, so this kit
# never itself carries the names it guards against. 匿名ガードはハッシュ照合。
WITHHELD_SHA256 = {
    "50f6fc53987a49cfdf440aea249999fc166574a88eaa6f078b9fef1b41c5093c",
    "e41546cc56ecb5fa5e7fcbdb5c9add950e8c7589da3b9d4d65cfc0ac397879f9",
    "9328b082a7756ed365fbc4f0c4bdaf76e54b8ab53705acff399f57153570878a",
}

LOCKED_TERMS = ("GAIA", "RATE", "CBGMODD", "BERA", "FAVORS", "UBIMIA",
                "BEST", "SOUND", "GOOD", "BELOW", "F1", "F2", "F3",
                "A0", "A5", "CCAL v2.1", "CC BY 4.0", INSTRUMENT,
                "0000-0001-9946-3221")

NON_ENDORSE = {"EN": ("NON-ENDORSEMENT", "Nothing here is offered", "no endorsement"),
               "JA": ("非承認", "代表して", "承認を意味するものではありません")}


# ---------------------------------------------------------------- harness
class Result:
    def __init__(self) -> None:
        self.rows: List[Tuple[str, str, str]] = []

    def add(self, tid: str, status: str, note: str) -> None:
        self.rows.append((tid, status, note))
        print(f"  [{status:4}] {tid:3}  {note}")


def check(cond: bool) -> str:
    return "PASS" if cond else "FAIL"


def t1(r: Result) -> None:
    ps = [0.9, 0.5, 0.25]
    prod = math.prod(ps)
    ok = abs(hazard(prod) - sum(hazard(p) for p in ps)) < TOL
    ok &= abs(survival(hazard(0.37)) - 0.37) < TOL
    try:
        hazard(0.0)
        ok = False  # falsify: p=0 must be rejected
    except ValueError:
        pass
    r.add("T1", check(ok), "survival identity + additive composition (Prop.1); p=0 rejected")


def t2(r: Result) -> Dict[str, float]:
    y = poisson_yield(1.0, 0.10)
    h_s = hazard(y)
    ok = abs(h_s - 0.10) < TOL and abs(y - math.exp(-0.1)) < TOL
    r.add("T2", check(ok), f"S-model Poisson yield Y={y:.4f} -> H_S={h_s:.4f} (=A*D0)")
    return {"Y": y, "H_S": h_s}


def t3(r: Result) -> Dict[str, float]:
    loa = math.prod(PHARMA_REF)
    h_p = sum(hazard(p) for p in PHARMA_REF)
    ok = abs(loa - 0.0787) < 0.001 and abs(h_p - hazard(loa)) < TOL
    r.add("T3", check(ok), f"P-model phase product LOA={loa:.4f} (~7.9%) -> H_P={h_p:.3f}")
    return {"LOA": loa, "H_P": h_p}


def t4(r: Result) -> None:
    grid = [i / 100 for i in range(0, 201)]
    gs = [ORDER[grade(h, empirical=True)] for h in grid]
    monotone = all(a >= b for a, b in zip(gs, gs[1:]))
    total = all(grade(h, True) in ORDER for h in grid)
    edges = (grade(0.5, True) == "BEST" and grade(0.8, True) == "SOUND"
             and grade(1.0, True) == "GOOD" and grade(1.0001, True) == "BELOW")
    r.add("T4", check(monotone and total and edges), "grade bands monotone, total, edges exact")


def t5(r: Result) -> None:
    g_s, g_p = "BEST", "BELOW"          # strong silicon, failing carbon
    fused = fuse_min(g_s, g_p)
    masked = fuse_mean_NULL(g_s, g_p)   # null model
    ok = fused == "BELOW" and ORDER[masked] >= ORDER["GOOD"]
    ok &= fuse_min("SOUND", "GOOD") == "GOOD" and fuse_min("GOOD", "SOUND") == "GOOD"
    r.add("T5", check(ok), f"F2 non-collapse: min -> {fused}; mean-null masks to {masked} (rejected)")


def t6(r: Result) -> None:
    ok = True
    for c in (0.0, 0.3, 1.0):
        for b in (0.0, 0.5, 1.0):
            for f in (0.1, 0.4):
                ok &= rate(c, b, f) >= f - TOL
    greenwash_null = rate_NULL(1.0, 1.0, 0.0)   # perfect institution, zero floor
    ok &= rate(0.0, 0.0, 0.2) == 0.2 and rate_NULL(0.0, 0.0, 0.2) == 0.0
    m, n = apply_shock(1.0, 1.0, 2.54)
    ok &= n == 1.0 and m < 1.0
    r.add("T6", check(ok), f"F3 floor supremacy RATE>=FAVORS; null zeroes floor; N intact under shock (M={m:.3f})")
    _ = greenwash_null


def t7(r: Result) -> None:
    ok = grade(0.2, empirical=False) != "BEST" and grade(0.2, empirical=True) == "BEST"
    r.add("T7", check(ok), "epistemic cap: illustrative inputs cannot reach BEST")


def t8(r: Result) -> None:
    v_cur, st = ladder_valid(CURRENT_EVIDENCE)
    v_skip, _ = ladder_valid({"A0": True, "A2": True})          # skips A1 consent
    v_adopt, _ = ladder_valid({"A0": True, "A5": True})         # claims adoption
    ok = v_cur and st == "A0" and not v_skip and not v_adopt
    r.add("T8", check(ok), f"adoption ladder: current={st}; skipping A1 / claiming A5 rejected")


def _read(path: str) -> Optional[str]:
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return None


def t9(r: Result, en: Optional[str], ja: Optional[str]) -> None:
    if en is None or ja is None:
        r.add("T9", "SKIP", "papers not found (use --dir)")
        return
    hits = 0
    for text in (en, ja):
        for tok in re.findall(r"[A-Za-z]+", text):
            if hashlib.sha256(tok.lower().encode()).hexdigest() in WITHHELD_SHA256:
                hits += 1
    r.add("T9", check(hits == 0), f"no-names guard: {hits} withheld-name token(s) found in EN+JA")


def t10(r: Result, en: Optional[str], ja: Optional[str]) -> None:
    if en is None or ja is None:
        r.add("T10", "SKIP", "papers not found (use --dir)")
        return
    missing = [t for t in LOCKED_TERMS if t not in en or t not in ja]
    r.add("T10", check(not missing), f"bilingual term lock ({len(LOCKED_TERMS)} terms); missing={missing}")


def t11(r: Result, en: Optional[str], ja: Optional[str]) -> None:
    if en is None or ja is None:
        r.add("T11", "SKIP", "papers not found (use --dir)")
        return
    ok = all(k in en for k in NON_ENDORSE["EN"]) and all(k in ja for k in NON_ENDORSE["JA"])
    r.add("T11", check(ok), "non-endorsement clause present in EN and JA")


def skips(r: Result) -> None:
    r.add("S1", "SKIP", "P1 calibration: real fab yield history (supply CSV) — empirical")
    r.add("S2", "SKIP", "P2 cross-domain h comparability: real pipeline data — empirical")
    r.add("S3", "SKIP", "P3 floor supremacy vs retention: real GAIA ledger — empirical")


def self_hash() -> str:
    with open(os.path.abspath(__file__), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=INSTRUMENT + " test kit")
    ap.add_argument("--dir", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)

    print(f"{INSTRUMENT} {VERSION} — Test Kit / テストキット")
    print(f"self SHA-256: {self_hash()}")
    en = _read(os.path.join(a.dir, EN_FILE))
    ja = _read(os.path.join(a.dir, JA_FILE))
    r = Result()
    t1(r); s = t2(r); p = t3(r); t4(r); t5(r); t6(r); t7(r); t8(r)
    t9(r, en, ja); t10(r, en, ja); t11(r, en, ja); skips(r)

    # Worked example (illustrative; reference baselines are declared parameters)
    h_s = normalized(s["H_S"], hazard(0.80))          # baseline: 80% yield
    h_p = normalized(p["H_P"], p["H_P"])              # at industry baseline
    g_s, g_p = grade(h_s), grade(h_p)
    print(f"\n  Worked example: h_S={h_s:.3f} -> {g_s}; h_P={h_p:.3f} -> {g_p}; "
          f"fused Φ = {fuse_min(g_s, g_p)} (illustrative, capped below BEST)")

    n_pass = sum(1 for _, st, _ in r.rows if st == "PASS")
    n_fail = sum(1 for _, st, _ in r.rows if st == "FAIL")
    n_skip = sum(1 for _, st, _ in r.rows if st == "SKIP")
    verdict = "PASS" if n_fail == 0 else "FAIL"
    print(f"\n  RESULT: {n_pass} PASS / {n_fail} FAIL / {n_skip} SKIP  ->  {verdict}")
    print("  PASS = evidence, not proof. SKIPs are empirical claims awaiting data.")
    if a.json:
        print(json.dumps({"instrument": INSTRUMENT, "version": VERSION,
                          "pass": n_pass, "fail": n_fail, "skip": n_skip,
                          "verdict": verdict,
                          "rows": [{"id": i, "status": st, "note": nt} for i, st, nt in r.rows]},
                         ensure_ascii=False, indent=2))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
