# ERES-AICON-GCS-2026-001 v0.1 — Work Package

**A Granular Classification Schema for Rating AI Constitutions**
J. A. Sprute · ERES Institute for New Age Cybernetics · Bella Vista, AR · ORCID 0000-0001-9946-3221 · 3 Oct 2026
Status: DRAFT · HOUSE-format v0.4 conformant · below the 9.0 gate (MIEVM not yet run) · CCAL v2.1 / CC BY 4.0

## Contents
| File | Role |
|---|---|
| `…_SPECIFICATION.md` | DETAIL master: the full white paper (Markdown) |
| `…_SPECIFICATION.pdf` | DETAIL companion: the rendered PDF, with Figure 1 embedded |
| `…_FIGURE-1.svg` | Schema figure: Layer 1 classify → Layer 2 rate → L3 tier |
| `…_TESTKIT.py` | Executable rating engine and testkit (stdlib only) |
| `…_RUN.txt` | Captured testkit run: 15/15 PASS, exit 0 |
| `…_RATING-TEMPLATE.json` | Blank rating sheet: 60 indicators |
| `…_EXEMPLARS.json` | CANDIDATE classifications of 9 public constitutions (axes only, no ratings) |
| `…_REGISTRAR.json` | REGISTRAR entry: P³, resourceImpact, operator instructions |
| `…_META.txt` | Deposit metadata: title, abstract, keywords |
| `MANIFEST.json` | SHA-256 for each file |
| `LICENSE.md`, `CITATION.cff` | License and citation |

## Verify (fresh extract → kit PASS → checksums match)
```
python3 ERES-AICON-GCS-2026-001_v0_1_TESTKIT.py        # expect VERDICT: PASS 15/15, exit 0
sha256sum -c <(python3 -c "import json;[print(v+'  '+k) for k,v in json.load(open('MANIFEST.json'))['files'].items()]")
```

## Rate a constitution
```
python3 ERES-AICON-GCS-2026-001_v0_1_TESTKIT.py --template > subject.json
# fill classification K/B/A/R/S, rater (declare conflicts of interest), and each indicator:
#   level 0-4 (ABSENT/STATED/SPECIFIED/INSTRUMENTED/VERIFIED) + evidence (quote+location or URL)
python3 ERES-AICON-GCS-2026-001_v0_1_TESTKIT.py --rate subject.json
```
Scoring rules:

- An uncited level is scored as 0.
- VEILED evidence is scored as 1.
- If any D0 Floor indicator is below 2, the result is BELOW-FLOOR.
- The tier is the minimum across domains D1–D9.
- A breach of either D9 wall caps the tier at GOOD.

Every published tier must carry its rating status: SINGLE, DUAL, or MIEVM.

## Traceability (claim → test)
Floor Supremacy T2 · greenwash null T3 · two-sided band T4/T5 · nothing verified ⇒ no BEST T6/T7 · min-composition T8 · evidence rule T9 · VEILED T10 · code round-trip T11 · monotonicity T12 · Layer Doctrine T13 · no person rated T14 · regression T15.

## What the PASS means
The PASS means the scoring logic behaves as specified. It is **not** a rating of any real constitution, and it is **not** evidence that the indicators are valid measures. Validity depends on the pre-registered P1–P3 (spec §9), which require independent raters.

## Open
- Human sign-off (H2C2H)
- MIEVM round
- P1–P3 runs
- CCAL tier
- TERMS-48 registration of "GCS"
- Reconciliation with *ERES Framework Assimilation and Rating.md*
