# License

© 2026 Joseph A. Sprute / ERES Institute for New Age Cybernetics.

This work package (ERES-AICON-GCS-2026-001 v0.1, all files) is licensed under the
**CARE Commons Attribution License v2.1 (CCAL)**, compatible with and expressed through the
**Creative Commons Attribution 4.0 International License (CC BY 4.0)**.

## CC BY 4.0: summary
You are free to:

- **Share:** copy and redistribute the material in any medium or format.
- **Adapt:** remix, transform, and build upon the material, for any purpose, including commercially.

Under the following terms:

- **Attribution:** give appropriate credit, provide a link to the license, and indicate whether changes were made.
- **No additional restrictions:** you may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

Full legal code: https://creativecommons.org/licenses/by/4.0/legalcode

## CCAL v2.1: ERES conditions carried with reuse
1. Preserve the Foundational Attribution (J. A. Sprute, ERES Institute; ORCID 0000-0001-9946-3221).
2. Preserve the Layer Doctrine (measurement layer read-only toward the governance layer).
3. Do not alter any LOCKED term, including the Three Governing Principles and the Triune Math.
4. No use for oppressive purposes; net-positive outcomes intended.
5. CCAL tier: OPEN (to be assigned by the author).

The software (TESTKIT.py) is provided "as is", without warranty of any kind.
