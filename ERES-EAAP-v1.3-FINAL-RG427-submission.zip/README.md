# ERES EAAP v1.3-FINAL — Submission Package

**ResearchGate submission:** RG #427
**Author:** Joseph Allen Sprute, ERES Institute for New Age Cybernetics
**Contact:** eresmaestro@gmail.com
**ORCID:** 0000-0001-9946-3221
**License:** CCAL v2.1 (document layer: CC BY-SA 4.0; code layer: MIT)
**Date:** April 24, 2026

---

## Package Contents

This package contains the EAAP v1.3-FINAL standards-track release. Provenance of the work is recorded in each document's own front matter, Document Provenance section, and Revision History; file timestamps are the submission-assembly moment and are not work-history markers.

| File | Role | Lines |
|---|---|---|
| `ERES-EAAP-STD-2026-001-v1.3-FINAL.md` | Primary specification | 833 |
| `ERES-SEPARATRIX-MATH-2026-001-v2.md` | Normative mathematical companion (DSAP-PRE) | 492 |
| `ERES-GRACECHAIN-NOTES-2026-001-v1.md` | Ledger substrate companion | 198 |
| `ERES-ATTRIBUTION-PROTOCOL-2026-001-v1.md` | Governance companion (external contribution admission) | 114 |
| `test_vector_verify.py` | Byte-normative test vector verification script | 350 |

## Recommended Reading Order

1. Start with **`ERES-EAAP-STD-2026-001-v1.3-FINAL.md`** — the specification itself.
   - Sections 1–2 establish scope and stack placement.
   - Sections 3–8 are the normative architecture (PoR, DSAP, RT, DSAP-PRE, RCR, Three Governing Principles correspondence).
   - Section 9 covers MIEVM ensemble validation.
   - Section 10 contains the byte-normative test vectors.
   - Section 11 is the worked DOFA USE-CASE.
   - Sections 12–14 cover security, protocol/governance separation, and conformance.
2. Read **`ERES-SEPARATRIX-MATH-2026-001-v2.md`** for the full mathematical scaffolding of DSAP-PRE.
3. Read **`ERES-GRACECHAIN-NOTES-2026-001-v1.md`** for the ledger substrate.
4. Read **`ERES-ATTRIBUTION-PROTOCOL-2026-001-v1.md`** for the governance layer that admits external contributions.
5. Run **`test_vector_verify.py`** to verify the byte-normative test vectors from EAAP §10.1 (which inherits from ERES-CRYPTO-STD-2026-001-v1.1.1 §20).

## Running the Verification Script

```
python3 test_vector_verify.py
```

Requires Python 3.8+ and the `cryptography` package:

```
pip install cryptography
```

Expected output: 8 checks PASS. If `cryptography` is not installed, Check 2 (Ed25519 public key derivation) will SKIP; the remaining 7 checks will still run and pass.

The script verifies:

1. Test keypair seed derivation via SHA-256
2. Ed25519 public key derivation from the seed
3. BERA canonical encoding
4. Sigma derivation via HKDF-SHA256
5. GCF polysemantic primitive resolution (default selector)
6. PoR factor arithmetic (Vectors PoR-1 and PoR-2)
7. DSAP-PRE composite (regime-transition case)
8. Weighted selector integer cross-multiplication (Test Vector F from §20.6)

All eight checks reproduce values from ERES-CRYPTO-STD-2026-001-v1.1.1 §20 byte-for-byte.

## Cross-References to Companion Documents

- **ERES-CRYPTO-STD-2026-001-v1.1.1** — source of Test Vector A (§20); published separately, not included in this package
- **ERES-RECKON-WP-2026-002** — Seven Resonance Anchors (foundational)
- **ERES-BODY-SPEC-2026-001** — BODY Consolidation Pipeline
- **ERES-BRAINS-SPEC-2026-001** — BRAINS Trifecta Protocol
- **ERES-DOFA-WP-2026-001-C** — DOFA Unified Architecture (source of §11 USE-CASE)
- **ERES-MPAM-2026-001** — Melting Pot Assimilation Method (MIEVM governance)

## About the MIEVM Validation Status

v1.3-FINAL has been validated at the idea and structural level through peer review correspondence (April 22–24, 2026, cited at the LinkedIn-correspondence tier per the Attribution Protocol). Full MIEVM ensemble concurrence across Claude, ChatGPT, Grok, and DeepSeek is queued as follow-on work toward v1.4.

## License

- Document layer: CC BY-SA 4.0 (attribution, share-alike)
- Code layer (`test_vector_verify.py`): MIT
- Overall governance: CCAL v2.1 (CARE Commons Attribution License)

Joseph Allen Sprute
Founder and Director, ERES Institute for New Age Cybernetics
33 Westbury Drive, Bella Vista, Arkansas 72714

*Don't hurt yourself. Don't hurt others. Build for generations to come.*
