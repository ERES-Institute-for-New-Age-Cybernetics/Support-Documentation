#!/usr/bin/env python3
"""
ERES-OBSERVATION-LEGITIMACY-TEST-2026-001 v3 -- Combined Test (Test 3 of 3)
Stdlib only. Deterministic. Exit 0 iff all structural tests pass.

The unified test the four MIEVM nodes converged on: fold Paper 1 (reciprocity)
and Paper 2 (spatial restraint) into ONE graded evaluation of a full observation
scenario. Reciprocity is carried by the Community-of-Interest (COI): the set of
parties who share a stake in a coordinate and can hold the observer to account.

Ten dimensions (Qwen's matrix, made runnable):
    authority, reciprocity, spatial, temporal, resolution, aggregation,
    interference, jurisdiction, auditability, remedy

Each dimension is graded BEST(3)/SOUND(2)/GOOD(1)/FLOOR-FAIL(0). The scenario
grade is the MIN across dimensions (binding-constraint / M x E + C = R):
a scenario is only as legitimate as its weakest necessary condition. This is
the HONEST rule -- thin reciprocity caps the whole scenario at GOOD (tolerated),
and COI raises reciprocity toward SOUND without pretending asymmetry is cured.
"""

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Dict
import sys


class Tier(IntEnum):
    FLOOR_FAIL = 0
    GOOD = 1
    SOUND = 2
    BEST = 3


TIER_NAME = {t: t.name for t in Tier}

DIMENSIONS = [
    "authority", "reciprocity", "spatial", "temporal", "resolution",
    "aggregation", "interference", "jurisdiction", "auditability", "remedy",
]


@dataclass
class Scenario:
    name: str
    # authority
    authority: bool
    # reciprocity inputs
    mutual_capability: bool          # thin
    mutual_accountability: bool      # thick (data-share / escort / reverse-feed)
    coi_audit_standing: bool         # community-of-interest can audit / demand access
    # spatial restraint (Paper 2)
    resolves_to_extent: bool         # cadastral overlay: coordinate -> legal parcel
    # bound presence
    temporal_bound: bool
    resolution_bound: bool
    aggregation_bound: bool
    # protections
    interference_protected: bool
    auditable: bool
    remedy: bool


def _tri(flag_best, flag_sound, flag_good) -> Tier:
    if flag_best:
        return Tier.BEST
    if flag_sound:
        return Tier.SOUND
    if flag_good:
        return Tier.GOOD
    return Tier.FLOOR_FAIL


def score_dimensions(s: Scenario) -> Dict[str, Tier]:
    d: Dict[str, Tier] = {}

    # authority: present or not (binary -> BEST if present, else FLOOR-FAIL)
    d["authority"] = Tier.BEST if s.authority else Tier.FLOOR_FAIL

    # reciprocity: the graded core.
    #   thick accountability            -> SOUND (protected)
    #   thick + COI audit standing      -> BEST
    #   thin capability only            -> GOOD (tolerated)  [COI lifts within GOOD]
    #   none                            -> FLOOR-FAIL
    if s.mutual_accountability:
        d["reciprocity"] = Tier.BEST if s.coi_audit_standing else Tier.SOUND
    elif s.mutual_capability or s.coi_audit_standing:
        # COI standing WITHOUT full accountability is still only tolerated:
        # it organizes the asymmetry, does not cure it. Honest-mode cap: GOOD.
        d["reciprocity"] = Tier.GOOD
    else:
        d["reciprocity"] = Tier.FLOOR_FAIL

    # spatial: registry must resolve to a legal extent, else floor-fail (Sec 6).
    #   resolves + auditable -> BEST; resolves only -> SOUND; else FLOOR-FAIL.
    if s.resolves_to_extent:
        d["spatial"] = Tier.BEST if s.auditable else Tier.SOUND
    else:
        d["spatial"] = Tier.FLOOR_FAIL

    # the three composable bounds: absent -> GOOD floor; present -> SOUND;
    # present AND auditable -> BEST (a bound you can independently verify is
    # best-in-class, an unverifiable promise is merely SOUND).
    def bound_tier(present):
        if not present:
            return Tier.GOOD
        return Tier.BEST if s.auditable else Tier.SOUND
    d["temporal"] = bound_tier(s.temporal_bound)
    d["resolution"] = bound_tier(s.resolution_bound)
    d["aggregation"] = bound_tier(s.aggregation_bound)

    # interference protection: BEST if protected, GOOD floor if not
    d["interference"] = Tier.BEST if s.interference_protected else Tier.GOOD

    # jurisdiction: does the coordinate bind to a real authority.
    #   resolves + remedy -> BEST; resolves only -> SOUND; else FLOOR-FAIL.
    if s.resolves_to_extent:
        d["jurisdiction"] = Tier.BEST if s.remedy else Tier.SOUND
    else:
        d["jurisdiction"] = Tier.FLOOR_FAIL

    # auditability
    d["auditability"] = Tier.BEST if s.auditable else Tier.GOOD

    # remedy: consequence for exceeding bounds -> BEST if present, else FLOOR-FAIL
    d["remedy"] = Tier.BEST if s.remedy else Tier.FLOOR_FAIL

    return d


def grade(s: Scenario) -> Tier:
    dims = score_dimensions(s)
    return Tier(min(int(t) for t in dims.values()))  # binding constraint


def binding_dimension(s: Scenario) -> str:
    dims = score_dimensions(s)
    m = min(int(t) for t in dims.values())
    for name in DIMENSIONS:
        if int(dims[name]) == m:
            return name
    return "?"


# --------------------------------- Fixtures ---------------------------------

FIXTURES = {
    # The unsolved gap: powerful operator, subject cannot watch back, no COI,
    # even with good bounds. Reciprocity floor-fails -> whole scenario floor-fails.
    "asymmetric_no_coi": Scenario(
        "Asymmetric operator, no accountability, no COI",
        authority=True, mutual_capability=False, mutual_accountability=False,
        coi_audit_standing=False, resolves_to_extent=True,
        temporal_bound=True, resolution_bound=True, aggregation_bound=True,
        interference_protected=True, auditable=True, remedy=True,
    ),
    # COI added: community can audit but observer still doesn't fully account.
    # Reciprocity lifts to GOOD -> scenario caps at GOOD (tolerated, not cured).
    "asymmetric_with_coi": Scenario(
        "Asymmetric operator + COI audit standing",
        authority=True, mutual_capability=False, mutual_accountability=False,
        coi_audit_standing=True, resolves_to_extent=True,
        temporal_bound=True, resolution_bound=True, aggregation_bound=True,
        interference_protected=True, auditable=True, remedy=True,
    ),
    # Thick reciprocity + full bounds + COI + audit + interference protection:
    # the BEST target.
    "thick_full": Scenario(
        "Thick reciprocity, full bounds, COI, audited, protected",
        authority=True, mutual_capability=True, mutual_accountability=True,
        coi_audit_standing=True, resolves_to_extent=True,
        temporal_bound=True, resolution_bound=True, aggregation_bound=True,
        interference_protected=True, auditable=True, remedy=True,
    ),
    # Thick reciprocity but missing a bound (no aggregation limit) -> the missing
    # bound is the binding constraint, capping at GOOD on that dimension.
    "thick_missing_bound": Scenario(
        "Thick reciprocity but no aggregation limit",
        authority=True, mutual_capability=True, mutual_accountability=True,
        coi_audit_standing=True, resolves_to_extent=True,
        temporal_bound=True, resolution_bound=True, aggregation_bound=False,
        interference_protected=True, auditable=True, remedy=True,
    ),
    # Raw grid, no cadastral resolution: spatial + jurisdiction floor-fail.
    "raw_grid": Scenario(
        "Raw grid, no cadastral overlay",
        authority=True, mutual_capability=True, mutual_accountability=True,
        coi_audit_standing=True, resolves_to_extent=False,
        temporal_bound=True, resolution_bound=True, aggregation_bound=True,
        interference_protected=True, auditable=True, remedy=True,
    ),
}


def run_tests():
    results = []

    def check(desc, cond):
        results.append((desc, bool(cond)))

    g = {k: grade(v) for k, v in FIXTURES.items()}

    # T1 HONEST RULE: asymmetric with no COI and no accountability -> FLOOR-FAIL,
    #    even with perfect bounds. The test refuses to certify the unsolved gap.
    check("T1 asymmetric/no-COI FLOOR-FAILs despite perfect bounds",
          g["asymmetric_no_coi"] == Tier.FLOOR_FAIL)

    # T2 COI credit WITHOUT overselling: adding COI lifts the scenario off the
    #    floor to GOOD (tolerated) but NOT to SOUND -- asymmetry organized, not cured.
    check("T2 COI lifts asymmetric to GOOD but not SOUND",
          g["asymmetric_with_coi"] == Tier.GOOD)

    # T3 The lift is real: COI strictly improves the grade.
    check("T3 COI strictly improves grade vs no-COI",
          g["asymmetric_with_coi"] > g["asymmetric_no_coi"])

    # T4 Thick + full stack reaches BEST.
    check("T4 thick reciprocity + full bounds reaches BEST", g["thick_full"] == Tier.BEST)

    # T5 Binding constraint: one missing bound caps the whole scenario at that
    #    dimension's grade (min-composition working).
    check("T5 missing aggregation bound caps scenario below BEST",
          g["thick_missing_bound"] < Tier.BEST)
    check("T5b binding dimension is 'aggregation'",
          binding_dimension(FIXTURES["thick_missing_bound"]) == "aggregation")

    # T6 Raw grid floor-fails on spatial/jurisdiction (Paper 2 Section 6).
    check("T6 raw grid FLOOR-FAILs (no cadastral resolution)",
          g["raw_grid"] == Tier.FLOOR_FAIL)
    check("T6b binding dimension is spatial or jurisdiction",
          binding_dimension(FIXTURES["raw_grid"]) in ("spatial", "jurisdiction"))

    # T7 Cross-paper coupling: reciprocity (Paper 1) AND spatial (Paper 2) are
    #    BOTH necessary -- killing either one alone drops the grade.
    base = FIXTURES["thick_full"]
    kill_recip = Scenario(**{**base.__dict__, "name": "k1",
                             "mutual_accountability": False, "mutual_capability": False,
                             "coi_audit_standing": False})
    kill_spatial = Scenario(**{**base.__dict__, "name": "k2", "resolves_to_extent": False})
    check("T7 killing reciprocity alone drops BEST scenario", grade(kill_recip) < Tier.BEST)
    check("T7b killing spatial alone drops BEST scenario", grade(kill_spatial) < Tier.BEST)

    # T8 Monotonicity across the combined test.
    worse = Scenario(**{**base.__dict__, "name": "w", "temporal_bound": False,
                        "resolution_bound": False})
    check("T8 monotonicity: removing bounds never raises grade", grade(worse) <= grade(base))

    # T9 Authority necessary: remove it, everything floor-fails.
    no_auth = Scenario(**{**base.__dict__, "name": "na", "authority": False})
    check("T9 authority necessary: BEST scenario w/o authority FLOOR-FAILs",
          grade(no_auth) == Tier.FLOOR_FAIL)

    return results


def main():
    results = run_tests()
    width = max(len(d) for d, _ in results)
    print("=" * (width + 8))
    print("ERES Observation Legitimacy Test -- COMBINED (Test 3/3)")
    print("Paper 1 (reciprocity) x Paper 2 (spatial restraint), min-composition")
    print("=" * (width + 8))
    for name, fx in FIXTURES.items():
        gr = grade(fx)
        bd = binding_dimension(fx)
        print(f"  [{TIER_NAME[gr]:>10}]  {fx.name}")
        print(f"               binding constraint: {bd}")
    print("-" * (width + 8))
    passed = 0
    for desc, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {desc}")
        passed += ok
    print("-" * (width + 8))
    print(f"  {passed}/{len(results)} structural tests passed")
    print("=" * (width + 8))
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
