#!/usr/bin/env python3
"""
ERES-OBSERVATION-LEGITIMACY-2026-001 v3 -- Graded Test Suite (Test 1 of 3)
Stdlib only. Seed-free (deterministic). Exit 0 iff all structural tests pass.

Encodes the CLAIMS of the paper as executable checks. It does NOT test whether
the history is true (that is cited, not computed). It tests that the paper's
own legitimacy grammar is internally consistent and discriminates the cases the
paper says it discriminates.

Grading tiers (BEST/SOUND/GOOD), per ERES corpus convention:
    FLOOR-FAIL : lacks authority or a resolvable observed party -> not on the ladder
    GOOD       : tolerated. authority + some bound, but only THIN reciprocity
    SOUND      : protected. THICK reciprocity (mutual accountability) + bounds + remedy
    BEST       : SOUND + full auditability + interference protection (bounded optimum)

Composition is min-based (binding-constraint / M x E + C = R): a regime is only
as legitimate as its weakest necessary condition.
"""

from dataclasses import dataclass, field
from enum import IntEnum
import sys


class Tier(IntEnum):
    FLOOR_FAIL = 0
    GOOD = 1
    SOUND = 2
    BEST = 3


TIER_NAME = {t: t.name for t in Tier}


@dataclass
class Regime:
    """A historical or hypothetical observation regime."""
    name: str
    has_authority: bool          # legal/political basis to observe at all
    observed_resolvable: bool    # is there an identifiable observed party
    # reciprocity
    mutual_capability: bool      # both sides CAN observe (thin)
    mutual_accountability: bool  # observer must account to observed: data-share/escort/audit (thick)
    # bounds
    bounded: bool                # spatial/temporal/scope limits present
    remedy: bool                 # consequence if observer exceeds bounds
    # top tier
    auditable: bool = False      # compliance independently verifiable
    interference_protected: bool = False  # tamper/destruction of verification prevented


def grade(r: Regime) -> Tier:
    # Floor: without authority or a resolvable observed party, the regime is not
    # even a candidate for legitimacy -- it is power in a vacuum.
    if not (r.has_authority and r.observed_resolvable):
        return Tier.FLOOR_FAIL

    # GOOD requires at least thin reciprocity AND a bound. Pure one-sided
    # observation with no bound stays at the floor (tolerated-in-vacuum).
    if not (r.mutual_capability and r.bounded):
        return Tier.FLOOR_FAIL

    good = True  # authority + observed + thin reciprocity + bounded

    # SOUND requires THICK reciprocity (accountability, not just capability)
    # plus remedy. This is the tolerated -> protected transition.
    sound = r.mutual_accountability and r.remedy

    # BEST requires SOUND plus auditability and interference protection.
    best = sound and r.auditable and r.interference_protected

    if best:
        return Tier.BEST
    if sound:
        return Tier.SOUND
    if good:
        return Tier.GOOD
    return Tier.FLOOR_FAIL


# ---- Canonical fixtures drawn from the paper's five episodes + counter-case ----

FIXTURES = {
    # NTM: mutual capability + affirmative right + non-interference, but the US
    # never had to SHARE imagery -> thin reciprocity only. Tolerated->protected
    # partially: it has non-interference (a remedy) but not full accountability.
    "NTM_verification": Regime(
        name="NTM verification (SALT/ABM)",
        has_authority=True, observed_resolvable=True,
        mutual_capability=True, mutual_accountability=False,  # counted missiles, didn't share grain
        bounded=True, remedy=True,  # interference with NTM is itself a violation
    ),
    # Open Skies: escorts + flight plans + quotas = the observed sees what is
    # collected. Thick reciprocity. This is the SOUND exemplar.
    "Open_Skies": Regime(
        name="Open Skies Treaty",
        has_authority=True, observed_resolvable=True,
        mutual_capability=True, mutual_accountability=True,  # escorts aboard, plans filed
        bounded=True, remedy=True,
        auditable=True, interference_protected=False,  # not tamper-proof-logged
    ),
    # Lop Nor: US observing Chinese program. No reciprocity, no treaty. Tolerated
    # because freedom-of-space, but never LEGITIMATED. Must NOT reach GOOD-protected.
    "Lop_Nor": Regime(
        name="Lop Nor monitoring",
        has_authority=False,  # no accepted right the observed could invoke
        observed_resolvable=True,
        mutual_capability=False, mutual_accountability=False,
        bounded=False, remedy=False,
    ),
    # Hypothetical modern persistent civilian surveillance, one-directional:
    # capable operator, subject cannot watch back. The unsolved gap.
    "persistent_asymmetric": Regime(
        name="Persistent asymmetric civilian sensing",
        has_authority=True, observed_resolvable=True,
        mutual_capability=False, mutual_accountability=False,  # subject cannot observe back
        bounded=True, remedy=False,
    ),
    # Hypothetical thick-reciprocity persistent regime (the target Paper 1 extrapolates):
    "persistent_thick": Regime(
        name="Persistent sensing w/ mutual data-sharing + audit log",
        has_authority=True, observed_resolvable=True,
        mutual_capability=True, mutual_accountability=True,
        bounded=True, remedy=True,
        auditable=True, interference_protected=True,  # tamper-evident on-orbit log
    ),
}


def run_tests():
    results = []

    def check(desc, cond):
        results.append((desc, bool(cond)))

    g = {k: grade(v) for k, v in FIXTURES.items()}

    # T1: Open Skies is the SOUND exemplar (thick reciprocity => protected).
    check("T1 Open Skies reaches SOUND (thick reciprocity)", g["Open_Skies"] >= Tier.SOUND)

    # T2: NTM is legitimate but only GOOD -- thin reciprocity caps it below SOUND.
    check("T2 NTM is GOOD but NOT SOUND (thin reciprocity caps it)",
          g["NTM_verification"] == Tier.GOOD)

    # T3: THE CORE DISCRIMINATOR. Lop Nor was tolerated but never legitimated.
    #     It must sit at FLOOR-FAIL: no authority the observed could invoke.
    check("T3 Lop Nor is FLOOR-FAIL (tolerated != legitimated)",
          g["Lop_Nor"] == Tier.FLOOR_FAIL)

    # T4: Lop Nor must score strictly below NTM -- the counter-case must not
    #     accidentally outrank a genuinely reciprocal regime.
    check("T4 Lop Nor < NTM (counter-case ranks below protected observation)",
          g["Lop_Nor"] < g["NTM_verification"])

    # T5: Asymmetric persistent sensing cannot reach SOUND -- this is the
    #     unsolved reciprocity gap, and the test must refuse to certify it.
    check("T5 Asymmetric persistent sensing cannot reach SOUND",
          g["persistent_asymmetric"] < Tier.SOUND)

    # T6: Thin vs thick is the hinge: identical regimes differing ONLY in
    #     accountability must land in different tiers.
    thin = Regime("thin", True, True, True, False, True, True)
    thick = Regime("thick", True, True, True, True, True, True)
    check("T6 thick reciprocity outranks thin, all else equal",
          grade(thick) > grade(thin))

    # T7: Authority is necessary -- remove it and any regime drops to FLOOR-FAIL
    #     (this is what makes Lop Nor fail even with a resolvable target).
    no_auth = Regime("no_auth", False, True, True, True, True, True, True, True)
    check("T7 authority is necessary (BEST-shaped regime w/o authority -> FLOOR-FAIL)",
          grade(no_auth) == Tier.FLOOR_FAIL)

    # T8: BEST requires auditability AND interference protection on top of SOUND.
    check("T8 persistent_thick reaches BEST (auditable + interference-protected)",
          g["persistent_thick"] == Tier.BEST)

    # T9: Monotonicity -- adding a legitimacy property never lowers the grade.
    base = Regime("base", True, True, True, False, True, False)
    better = Regime("better", True, True, True, True, True, True, True, True)
    check("T9 monotonicity: adding properties never lowers grade",
          grade(better) >= grade(base))

    return results


def main():
    results = run_tests()
    width = max(len(d) for d, _ in results)
    print("=" * (width + 8))
    print("ERES Observation Legitimacy -- Graded Test Suite (Test 1/3)")
    print("=" * (width + 8))
    for name, fx in FIXTURES.items():
        print(f"  [{TIER_NAME[grade(fx)]:>10}]  {fx.name}")
    print("-" * (width + 8))
    passed = 0
    for desc, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {desc}")
        passed += ok
    print("-" * (width + 8))
    print(f"  {passed}/{len(results)} structural tests passed")
    print("=" * (width + 8))
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
