#!/usr/bin/env python3
"""
ERES-COORDINATE-RESTRAINT-2026-001 v3 -- Graded Test Suite (Test 2 of 3)
Stdlib only. Deterministic. Exit 0 iff all structural tests pass.

Encodes the gauge's DESIGN RULES as executable guards, mirroring the corpus
"Gauge Sings" suite:
    - Separation Principle: G is static climate-normals only; no time argument.
    - Non-transfer: "a hymn cannot move a decimal" -- symbolic annotation must
      never alter a number the gauge outputs.
    - Registry-not-source: a coordinate resolves to a parcel/jurisdiction and
      alone grants no right.
    - Rival units: coordinate is SPATIAL; time/resolution/aggregation are
      distinct, composable bounds.

Grading (BEST/SOUND/GOOD) for a proposed coordinate-restraint deployment:
    FLOOR-FAIL : coordinate does not resolve to a legal extent (raw grid only)
    GOOD       : resolves to a parcel/jurisdiction (registry works) + spatial bound
    SOUND      : GOOD + composes with >=1 non-spatial bound (time/res/aggregation)
    BEST       : SOUND + all three non-spatial bounds present and auditable
"""

from dataclasses import dataclass
from enum import IntEnum
import sys


class Tier(IntEnum):
    FLOOR_FAIL = 0
    GOOD = 1
    SOUND = 2
    BEST = 3


TIER_NAME = {t: t.name for t in Tier}


# --------------------------- The gauge itself ---------------------------

class Gauge:
    """
    G(phi, lambda): static climate-normal field. Fixed mathematical register.
    Deliberately trivial climate model (interior is decorative per Homotopy
    Reduction Lemma; only well-boundaries are load-bearing). What matters for
    the tests is the *behaviour*: staticness, non-transfer, boundary-only.
    """
    def __init__(self):
        self._annotations = []  # symbolic/interpretive register (the "hymn")

    def annotate(self, text: str):
        """Add symbolic interpretation. MUST NOT affect any output number."""
        self._annotations.append(text)

    def value(self, phi: float, lam: float) -> float:
        """
        Static thermal normal at a coordinate. No time argument by construction
        (Separation Principle). Deterministic in (phi, lam) only. Annotations are
        never read here -- that is the non-transfer guarantee, enforced by the
        fact that self._annotations is not in scope of this computation.
        """
        # crude latitude-driven normal (deg C), longitude as static interpolation
        # coordinate over a precomputed correction; purely illustrative.
        base = 30.0 - 0.5 * abs(phi)              # hotter at equator
        corr = 2.0 * ((int(lam) % 7) - 3) / 3.0   # static longitudinal correction
        return round(base + corr, 4)

    def comfort_floor_gap(self, phi: float, lam: float,
                          floor_c: float = 18.0) -> float:
        """
        Comfort-floor gap: distance between the coordinate's thermal normal and
        a habitability floor. MEASURABLE definition (addresses reviewer note):
        gap = |normal - floor|. Larger => more intervention needed.
        """
        return round(abs(self.value(phi, lam) - floor_c), 4)


# --------------------------- Deployment model ---------------------------

@dataclass
class Deployment:
    name: str
    resolves_to_extent: bool     # coordinate -> legal parcel/jurisdiction (cadastral overlay)
    spatial_bound: bool          # a spatial restraint is expressed at the coordinate
    time_bound: bool             # retention limit
    resolution_bound: bool       # max resolution limit
    aggregation_bound: bool      # combination-of-observations limit
    auditable: bool = False


def grade(d: Deployment) -> Tier:
    # A raw grid that never resolves to a real legal extent is impractical to
    # absurdity (Section 6): floor-fail.
    if not (d.resolves_to_extent and d.spatial_bound):
        return Tier.FLOOR_FAIL
    good = True
    nonspatial = sum([d.time_bound, d.resolution_bound, d.aggregation_bound])
    sound = nonspatial >= 1
    best = (nonspatial == 3) and d.auditable
    if best:
        return Tier.BEST
    if sound:
        return Tier.SOUND
    if good:
        return Tier.GOOD
    return Tier.FLOOR_FAIL


FIXTURES = {
    # Raw geodetic grid, no cadastral overlay -> the "absurd" case.
    "raw_grid": Deployment("Raw lat/long grid (no overlay)",
                           resolves_to_extent=False, spatial_bound=True,
                           time_bound=False, resolution_bound=False, aggregation_bound=False),
    # Registry works but spatial only -> GOOD (Paper 2's honest floor).
    "registry_only": Deployment("Coordinate registry + cadastral overlay",
                                resolves_to_extent=True, spatial_bound=True,
                                time_bound=False, resolution_bound=False, aggregation_bound=False),
    # Registry + retention limit -> SOUND (composes with a Paper-1 bound).
    "registry_plus_time": Deployment("Registry + retention limit",
                                     resolves_to_extent=True, spatial_bound=True,
                                     time_bound=True, resolution_bound=False, aggregation_bound=False),
    # Full stack -> BEST.
    "full_stack": Deployment("Registry + time + resolution + aggregation + audit",
                             resolves_to_extent=True, spatial_bound=True,
                             time_bound=True, resolution_bound=True, aggregation_bound=True,
                             auditable=True),
}


def run_tests():
    results = []

    def check(desc, cond):
        results.append((desc, bool(cond)))

    g = Gauge()

    # --- Design-rule guards on the gauge ---

    # T1 Separation Principle: value() takes no time argument. Same coordinate,
    #    any number of calls, identical output (no dynamics leak in).
    v1 = g.value(35.0, -94.0)
    v2 = g.value(35.0, -94.0)
    check("T1 Separation Principle: gauge is static (no time dependence)", v1 == v2)

    # T2 Non-transfer: "a hymn cannot move a decimal". Adding 100 symbolic
    #    annotations must not change a single output value.
    before = g.value(35.0, -94.0)
    for i in range(100):
        g.annotate(f"symbolic reading #{i}: the coordinate sings")
    after = g.value(35.0, -94.0)
    check("T2 Non-transfer: 100 annotations move zero decimals", before == after)

    # T3 Comfort-floor gap is measurable and non-negative.
    gap = g.comfort_floor_gap(70.0, 10.0)  # high latitude -> large gap
    check("T3 comfort-floor gap is a measurable non-negative number", gap >= 0)

    # T4 Boundary sensitivity: a harsher coordinate has a >= gap than a mild one.
    harsh = g.comfort_floor_gap(80.0, 0.0)
    mild = g.comfort_floor_gap(24.0, 0.0)
    check("T4 harsher coordinate has >= comfort-floor gap than mild one", harsh >= mild)

    # --- Grading guards on deployments ---

    grades = {k: grade(v) for k, v in FIXTURES.items()}

    # T5 Registry-not-source / Section 6: raw grid floor-fails.
    check("T5 raw grid (no cadastral overlay) is FLOOR-FAIL", grades["raw_grid"] == Tier.FLOOR_FAIL)

    # T6 Registry alone is GOOD but not SOUND (spatial-only, honest floor).
    check("T6 registry-only is GOOD, not SOUND", grades["registry_only"] == Tier.GOOD)

    # T7 Composing with a non-spatial bound reaches SOUND.
    check("T7 registry + retention reaches SOUND", grades["registry_plus_time"] == Tier.SOUND)

    # T8 Full stack reaches BEST.
    check("T8 full stack reaches BEST", grades["full_stack"] == Tier.BEST)

    # T9 Rival-unit independence: spatial bound alone cannot substitute for the
    #    non-spatial bounds -- a deployment with spatial-only stays capped at GOOD
    #    no matter how "good" the coordinate resolution is.
    spatial_only = Deployment("spatial only", True, True, False, False, False, auditable=True)
    check("T9 spatial bound cannot substitute for temporal/res/aggregation (capped at GOOD)",
          grade(spatial_only) == Tier.GOOD)

    # T10 Monotonicity: adding a bound never lowers the grade.
    a = Deployment("a", True, True, True, False, False)
    b = Deployment("b", True, True, True, True, False)
    check("T10 monotonicity: adding a bound never lowers grade", grade(b) >= grade(a))

    return results


def main():
    results = run_tests()
    width = max(len(d) for d, _ in results)
    print("=" * (width + 8))
    print("ERES Coordinate Restraint -- Graded Test Suite (Test 2/3)")
    print("=" * (width + 8))
    g = Gauge()
    for name, fx in FIXTURES.items():
        print(f"  [{TIER_NAME[grade(fx)]:>10}]  {fx.name}")
    print("-" * (width + 8))
    passed = 0
    for desc, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {desc}")
        passed += ok
    print("-" * (width + 8))
    print(f"  {passed}/{len(results)} structural tests passed")
    print("=" * (width + 8))
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
