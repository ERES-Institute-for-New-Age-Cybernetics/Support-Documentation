#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-TALONICS v2 Companion Test Suite
=====================================
Tracks: ERES-TALONICS-WP-2026-001 v2.0 (Complete Description) + ERES-TALONICS-MATH-2026-001 v2.0
Registry: ERES-TALONICS-TEST-2026-001 v2.0 (PROPOSED)
License: CC BY 4.0 / CCAL v2.1

Scope & honesty (per the Derivation-Honesty Rule):
  - This suite verifies the STRUCTURAL / MATHEMATICAL claims that are DERIVED in the corpus.
  - It does NOT (and cannot, in stdlib) verify EMPIRICAL claims (T-2 TIMBRE/Enneagram,
    T-3 EXPRESSION synchrony, T-9 K_c coincidence). Those are marked PENDING, not passed.
  - A green structural run is evidence about the SPECIFICATION, not about the world-claims.

Stdlib only. Exits 0. Prints a structural/empirical split report.
"""

import math
import itertools

# ----------------------------------------------------------------------
# Primitives (WP §3, MATH §1-2)
# ----------------------------------------------------------------------
STATES = ("flat", "extended", "flexed")            # ternary 𝕊₃ ; flat == rest
PILLARS = ("Health", "Law", "Protection", "Love/Water", "Trades")
GLYPH = {"flat": "—", "extended": "↑", "flexed": "↓"}
UNGLYPH = {v: k for k, v in GLYPH.items()}
MANNER_BANDS = (1, 2, 3, 4)                          # |B| = 4 (attack/dwell quantization)

def rank(segment):
    """Number of engaged (non-flat) fingers."""
    return sum(1 for s in segment if s != "flat")

def encode_glyph(segment):
    return "".join(GLYPH[s] for s in segment)

def decode_glyph(g):
    return tuple(UNGLYPH[ch] for ch in g)

def count_of(_symbol):
    """ECVS count channel: unconditional, always 1 (the FLOOR). WP §9.4 / MATH Cor 6.5."""
    return 1

def cast(symbol):
    """CAST op: saturate manner to the priced band (b=4). Must NOT touch identity/count."""
    seg, _b = symbol
    return (seg, 4)

def measurable_features(symbol):
    """
    Boundary Doctrine (WP §9): every measured quantity must trace to an EXTERNALIZED
    signal (segment + manner). No 'thought' tier is readable, by construction.
    """
    seg, band = symbol
    return {
        "segment": seg,          # externalized posture
        "rank": rank(seg),       # derived from posture
        "manner_band": band,     # externalized kinematics
        # NOTE: intentionally NO 'thought' key -> un-externalized content is not readable.
    }

# ----------------------------------------------------------------------
# Test harness (stdlib; structural vs empirical split)
# ----------------------------------------------------------------------
RESULTS = []  # (id, kind, status, detail)

def check(tid, kind, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    RESULTS.append((tid, kind, status, detail))
    return cond

def pending(tid, reason):
    RESULTS.append((tid, "empirical", "PENDING", reason))

# ----------------------------------------------------------------------
# STRUCTURAL TESTS
# ----------------------------------------------------------------------

def test_rank_census():
    """MATH Thm 2.3: |A_k| = C(5,k)*2^k ; sum = 3^5 = 243."""
    expected = [1, 10, 40, 80, 80, 32]
    got = [math.comb(5, k) * (2 ** k) for k in range(6)]
    check("CENSUS-a", "structural", got == expected, f"per-rank {got}")
    check("CENSUS-b", "structural", sum(got) == 243 == 3 ** 5, f"sum={sum(got)}")
    # brute-force confirmation over the actual ternary space
    brute = [0] * 6
    for seg in itertools.product(STATES, repeat=5):
        brute[rank(seg)] += 1
    check("CENSUS-c", "structural", brute == expected, f"brute {brute}")

def test_T1_orthogonality():
    """T-1: permuting manner over a fixed segment leaves segment identity + count fixed."""
    seg = ("flat", "extended", "flat", "flat", "flat")   # Law apparition
    ids = {(_seg := s[0]) for s in [(seg, b) for b in MANNER_BANDS]}
    counts = {count_of((seg, b)) for b in MANNER_BANDS}
    check("T-1", "structural",
          ids == {seg} and counts == {1},
          f"identity stable across bands; counts={counts}")

def test_T4_count_invariance():
    """T-4: no weight/CAST operation alters the count (FLOOR stays 1)."""
    sym = (("flexed",) * 5, 1)
    after = cast(sym)
    check("T-4", "structural",
          count_of(sym) == 1 and count_of(after) == 1 and after[0] == sym[0],
          "count fixed at 1 through CAST; segment identity unchanged")

def test_T5_rollcall():
    """
    T-5 / MATH Thm 7.2: HARMONY = Σ vᵢ is symmetric (non-injective);
    attribution recoverable IFF the MELODY sequence is stored.
    """
    d = 4
    contribs = [("Alice", (1, 0, 1, 0)),
                ("Bob",   (0, 1, 1, 0)),
                ("Charlie", (1, 1, 0, 1))]

    def harmony(seq):  # symmetric aggregation
        acc = [0] * d
        for _who, v in seq:
            for j in range(d):
                acc[j] += v[j]
        return tuple(acc)

    H1 = harmony(contribs)
    H2 = harmony(list(reversed(contribs)))
    non_injective = (H1 == H2)                      # permutation discarded
    # MELODY = stored ordered sequence -> reconstruct attribution
    melody = list(contribs)
    recovered = {who: v for who, v in melody}
    recoverable = (recovered ==
                   {"Alice": (1, 0, 1, 0), "Bob": (0, 1, 1, 0), "Charlie": (1, 1, 0, 1)})
    check("T-5a", "structural", non_injective, "HARMONY(Σ) invariant under permutation")
    check("T-5b", "structural", recoverable, "roll-call recovered from stored MELODY")

def test_T6_boundary():
    """T-6: every measured quantity traces to an externalized signal; no 'thought' tier."""
    feats = measurable_features((("extended", "flat", "flexed", "flat", "flat"), 2))
    externalized = set(feats.keys()) <= {"segment", "rank", "manner_band"}
    check("T-6", "structural", externalized and "thought" not in feats,
          "features trace only to externalized (segment, manner); no thought read")

def test_T7_featural_legibility():
    """T-7: glyph round-trips to the segment without a lookup table."""
    ok = True
    for seg in itertools.islice(itertools.product(STATES, repeat=5), 0, 243, 7):
        if decode_glyph(encode_glyph(seg)) != seg:
            ok = False
            break
    check("T-7", "structural", ok, "glyph<->segment round-trip exact (seismograph contour)")

def test_T8_contestability():
    """T-8 (DVC 2.4): an append-only log stays challengeable post-execution."""
    somt = []                                        # append-only provenance
    somt.append(("CAST", (("flexed",) * 5, 4), "t0"))
    sealed = False                                   # not a one-time gate
    # a post-execution challenge appends, does not overwrite
    somt.append(("CHALLENGE", (("flat", "flat", "flat", "extended", "flat"), 3), "t1"))
    reopened = (len(somt) == 2 and not sealed and somt[0][0] == "CAST"
                and somt[1][0] == "CHALLENGE")
    check("T-8", "structural", reopened, "post-execution CHALLENGE appended; record not sealed")

def test_P3_sufficiency():
    """MATH Thm 7b.2: |𝕋| = |A_licensed|*|B| > |Cells| ⇒ injection f: Cells ↪ 𝕋 exists."""
    A_licensed = 100                                 # estimate (F-4); conditional on ergonomic study
    B = len(MANNER_BANDS)
    T = A_licensed * B                               # ~400
    cells = 18 * 7                                   # 126
    exists = T > cells
    # construct an explicit injective sample map for all 126 cells
    pool = [(a, b) for a in range(A_licensed) for b in range(B)]
    f = {cell: pool[i] for i, cell in enumerate(range(cells))}
    injective = len(set(f.values())) == cells
    check("P3-a", "structural", exists, f"|T|={T} > |Cells|={cells} (ratio {T/cells:.2f}x)")
    check("P3-b", "structural", injective, "explicit injective f built for all 126 cells")

def test_capacity():
    """MATH Prop 10.1: H_sym = log2(|A_licensed|*B) ≈ 8.6 bits (Latin ≈ 4.7)."""
    H = math.log2(100 * 4)
    check("CAP", "structural", 8.4 <= H <= 8.7 and H > math.log2(26),
          f"H_sym={H:.2f} bits > Latin {math.log2(26):.2f}")

# ----------------------------------------------------------------------
# EMPIRICAL TESTS (cannot pass in stdlib -> PENDING, per §11 honesty)
# ----------------------------------------------------------------------

def register_pending():
    pending("T-2", "TIMBRE->Enneagram: needs blind agreement vs an independently VALIDATED "
                    "affect baseline (F-1). Reclassify TIMBRE decorative on failure.")
    pending("T-3", "EXPRESSION: needs Kuramoto order parameter r measured under real "
                    "entrainment vs control (F-2).")
    pending("T-9", "K_c coincidence: needs pre-registered K_c(phi)=K_c(6) spectral test (F-6). "
                    "Retract buckle on failure.")

# ----------------------------------------------------------------------
# Runner
# ----------------------------------------------------------------------

def main():
    for t in (test_rank_census, test_T1_orthogonality, test_T4_count_invariance,
              test_T5_rollcall, test_T6_boundary, test_T7_featural_legibility,
              test_T8_contestability, test_P3_sufficiency, test_capacity):
        t()
    register_pending()

    struct = [r for r in RESULTS if r[1] == "structural"]
    emp = [r for r in RESULTS if r[1] == "empirical"]
    s_pass = sum(1 for r in struct if r[2] == "PASS")
    s_fail = sum(1 for r in struct if r[2] == "FAIL")

    print("=" * 70)
    print("ERES-TALONICS v2 — Companion Test Report")
    print("=" * 70)
    print("\n[STRUCTURAL / DERIVED]  (verifies the specification, not the world)")
    for tid, _k, status, detail in struct:
        print(f"  {status:7} {tid:10} {detail}")
    print("\n[EMPIRICAL]  (require physical data; PENDING by construction — §11)")
    for tid, _k, status, detail in emp:
        print(f"  {status:7} {tid:10} {detail}")

    print("\n" + "-" * 70)
    print(f"Structural: {s_pass} pass / {s_fail} fail / {len(struct)} total")
    print(f"Empirical:  {len(emp)} pending (T-2, T-3, T-9)")
    print("-" * 70)
    print("Amplitude (structural): "
          f"{'10/10' if s_fail == 0 else f'{s_pass}/{len(struct)}'} "
          "| Canonical gate: NOT met (0 gate-eligible nodes; empirical tests pending).")
    print("Disposition: pre-canonical — a green structural run is evidence about the "
          "SPECIFICATION, not certification of its world-claims.")
    print("=" * 70)
    # Exit 0 regardless: pending empirical tests are expected, not failures.
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
