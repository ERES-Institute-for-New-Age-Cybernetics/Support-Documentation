#!/usr/bin/env python3
"""
eres_sroc_bera_sla_testkit.py  --  ERES-SROC-BERA-SLA-MAP-2026-001 v0.1 DRAFT

Enumerates the universe of SROC options against BERA (measurement) and the
S3C User-GROUP SLA (who is bound, where), then prunes it with the Reverse X
N/M rule and the corpus person-lock. Python 3.8+, standard library only,
deterministic, no network.

Structural rules only. Nothing here is a measurement of any real system.
Skips are deliberate and load-bearing: the suite goes fully green only when
the items they name are closed by the author or by outside evidence.

Run:  python3 eres_sroc_bera_sla_testkit.py         (tests)
      python3 eres_sroc_bera_sla_testkit.py --cells (print the cell table)
"""
import itertools
import math
import sys
import unittest

INSTRUMENT = "ERES-SROC-BERA-SLA-MAP-2026-001"
VERSION = "v0.1"
TESTS_SPEC_VERSION = (0, 1)

PHI = (1 + 5 ** 0.5) / 2

# ---------------------------------------------------------------- parameters
# Band labels: S5 = Planet is corpus-stated (GAIA GEAR). S1-S4 labels are a
# CANDIDATE assignment awaiting author ratification (see SKIP s3).
BANDS = {
    "S1": "Body (person)",            # CANDIDATE label
    "S2": "Device / asset",           # CANDIDATE label
    "S3": "Infrastructure tile (EMCI)",  # CANDIDATE label
    "S4": "Community (S3C User-GROUP)",  # CANDIDATE label
    "S5": "Planet (GAIA)",            # STATED; closure OPEN
}
P3 = ("Personal", "Public", "Private")          # STATED (HOW-ILO stewardship classes)
TARGETS = ("N", "M")                             # STATED (ENDHOME Survival/Merit)
DISPOSITIONS = ("token", "held", "retired")      # STATED (SROC token mechanic)

ADMISSIBLE = "ADMISSIBLE"
CONDITIONAL = "CONDITIONAL"   # admissible only with floor provision continuing
REFUSED = "REFUSED"
OPEN = "OPEN"


def classify(band, p3, target, disp):
    """Return (status, reason) for one cell of the SROC option universe."""
    if band not in BANDS or p3 not in P3 or target not in TARGETS or disp not in DISPOSITIONS:
        raise ValueError("unknown parameter")
    if band == "S5":
        return OPEN, "S5 cascade closure is OPEN; no path selected"
    if target == "N" and disp == "retired":
        return REFUSED, "retiring an N element abandons the floor (N never decremented)"
    if band == "S1" and target == "M":
        return REFUSED, "an S1 SROC is indexed to a person's resonance; resonance may never gate or price a person"
    if target == "N" and disp == "held":
        return CONDITIONAL, "element may be HELD; floor provision must continue meanwhile"
    return ADMISSIBLE, "within N/M rule and person-lock"


def universe():
    return list(itertools.product(BANDS, P3, TARGETS, DISPOSITIONS))


def tally():
    t = {ADMISSIBLE: 0, CONDITIONAL: 0, REFUSED: 0, OPEN: 0}
    for cell in universe():
        t[classify(*cell)[0]] += 1
    return t


# -------------------------------------------------------- structural refusals
class Refused(Exception):
    pass


class Field:
    """One SROC field: x^2 = g*x + b with g guards and b bindings."""

    def __init__(self):
        self.guards = 1
        self.bindings = 1
        self.floor = {"shelter": 1, "water": 1, "food": 1,
                      "sanitation": 1, "warmth": 1, "call": 1}
        self.m_layer = {}

    def add_guard(self):
        raise Refused("second guard: floor would be settled by conflict")

    def add_binding(self):
        raise Refused("second binding: market context would reach the floor")

    def market_write(self, layer, key, value):
        if layer == "N":
            raise Refused("market context may not define the N-floor")
        self.m_layer[key] = value

    def bera_adjust(self, key, delta):
        """A BERA reading may raise floor provision, never lower it."""
        if key in self.floor:
            if delta < 0:
                raise Refused("a BERA reading may never decrement the N-floor")
            self.floor[key] += delta
        else:
            self.m_layer[key] = self.m_layer.get(key, 0) + delta


def contract_valid(contact_of_record):
    """SROC §1: a contract begins with a number anyone can call."""
    return bool(contact_of_record) and contact_of_record.get("channel_live") is True \
        and bool(contact_of_record.get("answerable_party"))


# ------------------------------------------- BERA admissibility (four tests)
ADMISSIBILITY_TESTS = ("persistent", "distinguishable", "stable", "accessible")


def reading_admissible(reading):
    """A BERA reading may trigger an SROC only if it passes all four tests
    (structure borrowed from the physicality criteria in Pellis, Spectral
    Principle of Physical Reality, 2026; ANALOGICAL transfer)."""
    return all(reading.get(k) is True for k in ADMISSIBILITY_TESTS)


# ------------------------------------------------ three-regime band and HELD
def regime(abscissa, warn_margin):
    """stable / metastable / unstable by spectral abscissa (max Re lambda).
    Structure after the stable/metastable/unstable regimes of the Pellis
    Stability Operator (smart grids, 2026); ANALOGICAL transfer."""
    if abscissa >= 0:
        return "unstable"
    if abscissa >= -warn_margin:
        return "metastable"
    return "stable"


REGIME_BAND = {"stable": "GREEN", "metastable": "YELLOW", "unstable": "RED"}


def eig2(a, b, c, d):
    """Eigenvalues of [[a, b], [c, d]] (complex-safe, stdlib only)."""
    tr, det = a + d, a * d - b * c
    disc = tr * tr - 4 * det
    if disc >= 0:
        r = math.sqrt(disc)
        return complex((tr + r) / 2), complex((tr - r) / 2)
    r = math.sqrt(-disc)
    return complex(tr / 2, r / 2), complex(tr / 2, -r / 2)


def abscissa_of(mu, k=4.0, c=1.0):
    """Toy damped resonator x'' + (c - mu) x' + k x = 0 as a 2x2 operator.
    The abscissa is COMPUTED from the matrix, not stipulated."""
    lam = eig2(0.0, 1.0, -k, mu - c)
    return max(z.real for z in lam)


def first_crossing(pred, lo=0.0, hi=4.0, steps=40000):
    for i in range(steps + 1):
        mu = lo + (hi - lo) * i / steps
        if pred(mu):
            return mu
    return None


def lead_time(warn_margin=0.125):
    mu_warn = first_crossing(lambda m: regime(abscissa_of(m), warn_margin) != "stable")
    mu_fail = first_crossing(lambda m: regime(abscissa_of(m), warn_margin) == "unstable")
    return mu_warn, mu_fail


# ------------------------------------------------------ phi weighting guard
def weight(value, golden_advantage_registered=False):
    """Reverse X F5 and Pellis' own golden-scale falsification rule: phi may
    not enter any weight unless a registered test shows a predictive
    advantage over non-golden alternatives. No such test exists, so the
    flag is never set inside ERES."""
    if abs(value - PHI) < 1e-9 and not golden_advantage_registered:
        raise Refused("phi weighting without a registered golden-advantage test")
    return value


# ------------------------------------------------------------------- tests
TRACEABILITY = {
    "t01": "§3 universe has 90 cells",
    "t02": "§3 tally: admissible / conditional / refused / open",
    "t03": "§4.1 N + retired refused at every band S1-S4",
    "t04": "§4.2 S1 + M refused (person-lock)",
    "t05": "§4.3 N + held conditional; provision continues",
    "t06": "§4.4 every S5 cell OPEN, none admissible",
    "t07": "§5 second guard refused",
    "t08": "§5 second binding refused",
    "t09": "§5 market write at N refused; at M allowed",
    "t10": "§5 BERA reading may raise, never lower, the floor",
    "t11": "§5 dead channel voids the contract",
    "t12": "§6.1 BERA admissibility: all four tests required",
    "t13": "§6.2 regime map stable/metastable/unstable -> GREEN/YELLOW/RED",
    "t14": "§6.2 computed lead time > 0 on toy operator (could be null)",
    "t15": "§6.3 phi weighting refused without registered test",
    "t16": "§3 every cell has exactly one status and a reason",
    "s1": "F1 real multi-scale telemetry for any band (OPEN)",
    "s2": "S5 closure (OPEN)",
    "s3": "Author ratification of S1-S4 labels and the S1+M rule",
    "s4": "Disposition of cited author on use of references",
    "s5": "Independent >=5-node MIEVM round",
    "s6": "EMCI green-band metric set and SROC offset thresholds",
}


class T(unittest.TestCase):
    def test_t01_universe_size(self):
        self.assertEqual(len(universe()), 5 * 3 * 2 * 3)

    def test_t02_tally(self):
        self.assertEqual(tally(), {ADMISSIBLE: 39, CONDITIONAL: 12, REFUSED: 21, OPEN: 18})

    def test_t03_n_retired_refused(self):
        for b in ("S1", "S2", "S3", "S4"):
            for p in P3:
                self.assertEqual(classify(b, p, "N", "retired")[0], REFUSED)

    def test_t04_person_lock(self):
        for p in P3:
            for d in DISPOSITIONS:
                self.assertEqual(classify("S1", p, "M", d)[0], REFUSED)
        self.assertEqual(classify("S2", "Private", "M", "token")[0], ADMISSIBLE)

    def test_t05_n_held_conditional(self):
        for b in ("S1", "S2", "S3", "S4"):
            st, why = classify(b, "Public", "N", "held")
            self.assertEqual(st, CONDITIONAL)
            self.assertIn("provision must continue", why)

    def test_t06_s5_open(self):
        for p, t, d in itertools.product(P3, TARGETS, DISPOSITIONS):
            self.assertEqual(classify("S5", p, t, d)[0], OPEN)

    def test_t07_second_guard(self):
        with self.assertRaises(Refused):
            Field().add_guard()

    def test_t08_second_binding(self):
        with self.assertRaises(Refused):
            Field().add_binding()

    def test_t09_market_write(self):
        f = Field()
        with self.assertRaises(Refused):
            f.market_write("N", "water", 0)
        f.market_write("M", "credential_price", 3)
        self.assertEqual(f.m_layer["credential_price"], 3)

    def test_t10_bera_floor_monotone(self):
        f = Field()
        f.bera_adjust("water", 1)
        self.assertEqual(f.floor["water"], 2)
        with self.assertRaises(Refused):
            f.bera_adjust("water", -1)

    def test_t11_contact_of_record(self):
        self.assertTrue(contract_valid({"channel_live": True, "answerable_party": "steward"}))
        self.assertFalse(contract_valid({"channel_live": False, "answerable_party": "steward"}))
        self.assertFalse(contract_valid({"channel_live": True, "answerable_party": ""}))

    def test_t12_admissibility(self):
        ok = dict.fromkeys(ADMISSIBILITY_TESTS, True)
        self.assertTrue(reading_admissible(ok))
        for k in ADMISSIBILITY_TESTS:
            bad = dict(ok)
            bad[k] = False
            self.assertFalse(reading_admissible(bad))

    def test_t13_regimes(self):
        self.assertEqual(REGIME_BAND[regime(-1.0, 0.1)], "GREEN")
        self.assertEqual(REGIME_BAND[regime(-0.05, 0.1)], "YELLOW")
        self.assertEqual(REGIME_BAND[regime(0.0, 0.1)], "RED")

    def test_t14_lead_time(self):
        mu_warn, mu_fail = lead_time()
        self.assertIsNotNone(mu_warn)
        self.assertIsNotNone(mu_fail)
        self.assertGreater(mu_fail - mu_warn, 0.0)

    def test_t15_phi_guard(self):
        with self.assertRaises(Refused):
            weight(PHI)
        self.assertEqual(weight(1.5), 1.5)

    def test_t16_one_status_each(self):
        statuses = {ADMISSIBLE, CONDITIONAL, REFUSED, OPEN}
        for cell in universe():
            st, why = classify(*cell)
            self.assertIn(st, statuses)
            self.assertTrue(why)

    @unittest.skip("s1 F1: no real multi-scale telemetry yet (lifts ANALOGICAL)")
    def test_s1(self):
        pass

    @unittest.skip("s2 S5 closure OPEN: 18 cells stay OPEN until a path is selected")
    def test_s2(self):
        pass

    @unittest.skip("s3 author ratification of S1-S4 labels and the S1+M rule")
    def test_s3(self):
        pass

    @unittest.skip("s4 cited author's disposition on use of references; HOLD")
    def test_s4(self):
        pass

    @unittest.skip("s5 independent >=5-node MIEVM round not run")
    def test_s5(self):
        pass

    @unittest.skip("s6 EMCI green-band metric set and offset thresholds OPEN")
    def test_s6(self):
        pass


def print_cells():
    print(f"{'band':4} {'P3':9} {'tgt':3} {'disp':8} status")
    for cell in universe():
        st, why = classify(*cell)
        print(f"{cell[0]:4} {cell[1]:9} {cell[2]:3} {cell[3]:8} {st:11} {why}")


if __name__ == "__main__":
    if "--cells" in sys.argv:
        print_cells()
        sys.exit(0)
    mw, mf = lead_time()
    print(f"{INSTRUMENT} {VERSION}  tally={tally()}  toy lead: mu_warn={mw:.4f} mu_fail={mf:.4f} lead={mf-mw:.4f}")
    res = unittest.main(exit=False, verbosity=2).result
    print("\nTRACEABILITY")
    for k, v in TRACEABILITY.items():
        print(f"  {k}: {v}")
    sys.exit(0 if res.wasSuccessful() else 1)
