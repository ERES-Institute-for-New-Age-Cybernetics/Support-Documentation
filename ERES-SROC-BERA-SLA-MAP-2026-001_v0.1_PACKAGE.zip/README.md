# ERES-SROC-BERA-SLA-MAP-2026-001 v0.1 (DRAFT, HOLD)

Maps the universe of SROC (Smart-Resonant Offset Contract) options to BERA and S³C User-GROUP SLAs, then prunes it with the Reverse X N/M rule.

Status: DRAFT, single-node, pre-MIEVM. HOLD: do not post until the cited external author's disposition on use of his references is received.

## Files
- `ERES-SROC-BERA-SLA-MAP-2026-001_v0.1.md`: the instrument
- `eres_sroc_bera_sla_testkit.py`: stdlib-only testkit (Python 3.8+)
- `RUN.txt`: captured test run and full cell table
- `MANIFEST.json`: SHA-256 of each file

## Run
    python3 eres_sroc_bera_sla_testkit.py          # 22 tests: 16 pass, 6 skip, exit 0
    python3 eres_sroc_bera_sla_testkit.py --cells  # all 90 cells with status and reason

## Result
90 cells: 39 admissible, 12 conditional, 21 refused, 18 open (S5).

## Claim → test
| Claim | Test |
|---|---|
| 90-cell universe; tally | t01, t02, t16 |
| N + retired refused | t03 |
| S1 + M refused (person-lock) | t04 |
| N + held conditional | t05 |
| S5 open | t06 |
| One guard, one binding; market and BERA limits; Contact of Record | t07-t11 |
| Four-test admissibility | t12 |
| Three regimes; computed toy lead time | t13, t14 |
| No φ weighting | t15 |
| Load-bearing skips | s1-s6 |

License: CCAL v2.1 / CC BY 4.0. Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. ORCID 0000-0001-9946-3221.
