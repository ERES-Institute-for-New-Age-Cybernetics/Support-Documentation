# ERES-IPIDITIS-FLIP-2026-001 — The IPIDITIS FLIP (v0.1 PROVISIONAL)

**Authentication as the reverse-direction face of IDIPITIS — consent-directional access-privilege for identity-without-surveillance.**

Author: Joseph A. Sprute (ERES Maestro), ORCID 0000-0001-9946-3221, with Claude (Anthropic) as drafting node.
Publisher: ERES Institute for New Age Cybernetics · Bella Vista, Arkansas.
License: CARE Commons Attribution License (CCAL) v2.1 / CC BY-SA 4.0.
Status: **PROVISIONAL v0.1 — pre-canonical, pre-MIEVM, not peer-reviewed.**

---

## What this is

IDIPITIS is the ERES *bidirectional* security architecture for identity-without-surveillance. Because it is bidirectional, it has a forward read and a reverse read. This instrument gives the reverse read a name and a duty:

- **IDIPITIS** (forward) = **settlement identity** — *who owes / owns / receives* (the receipts→DOFA ledger).
- **IPIDITIS** (reverse) = **authentication** — *who may do what* (access privilege: Rights · Roles · Rules).

The transition between them is the **FLIP**, governed by one safety invariant — **I-FLIP: consent-directionality** — access never silently promotes into settlement-identity. This is what lets an ERES front door (e.g. the "number anyone can call for real help") authenticate access *without recording identity*.

## Contents (manifest)

| File | What it is |
|------|-----------|
| `ERES-IPIDITIS-FLIP-2026-001_v0-1_PROVISIONAL.md` | The whitepaper — **MD master, sole source of record**. |
| `ERES-IPIDITIS-FLIP-2026-001_v0-1_PROVISIONAL.pdf` | Rendered PDF of the whitepaper (derived; regenerate from the MD, never hand-edit). |
| `ERES-IPIDITIS-FLIP-2026-001_TESTBENCH_v0-1.html` | Interactive test bench — exercise the FLIP by hand and run the invariants live in a browser. |
| `test_ipiditis_flip.py` | Stdlib-only reference implementation + `unittest` suite making the invariants falsifiable. |
| `ERES-IPIDITIS-FLIP-2026-001_FIGURE_the-flip.svg` | Architecture figure (Figure 1). |
| `META.txt` | Title / SEO title / abstract / keywords / license / DOI slot / ORCID / instrument-kin. |
| `README.md` | This file. |

## Run it

**Interactive bench** — open the HTML in any modern browser (double-click works; no server, no network, no build):

```
ERES-IPIDITIS-FLIP-2026-001_TESTBENCH_v0-1.html
```

Engage IPIDITIS, watch identity stay veiled, let Δτ lapse to Floor, attempt a silent promotion (refused), then perform a consented flip. Press **Run invariants** for a live pass/fail readout.

**Falsifiable suite** — Python 3.8+, standard library only:

```
python3 test_ipiditis_flip.py         # runs 7 invariants (expect: OK)
python3 test_ipiditis_flip.py --demo  # prints a short traversal + SOMT log
```

The seven invariants: **I-FLIP.a** (no silent promotion), **I-FLIP.b** (event, not identity), **I-FLIP.c** (reversion to Floor), **Veil** (access ⇒ identity veiled), **Duration** (duration, not magnitude), **PoR** (zero factor blocks), **Consent** (consent required). The bench and the Python kit assert the *same* invariants against the *same* state-machine shape.

## Honest status — read before citing

- **PROVISIONAL v0.1.** Not peer-reviewed; no MIEVM ensemble return incorporated. Canonization gate is an explicit **≥5-node MIEVM convergent mean ≥ 9.0** (unmet at v0.1).
- **The cryptography is not implemented.** The one-way, consent-gated I-FLIP crypto — the whitepaper's hardest open item (§9) — is **stubbed as a plain guard** in both the bench and the Python kit. These artifacts verify **state-machine invariants**, not cryptographic guarantees. Do not deploy the reference as a security control.
- **No fabricated data.** The opaque event id is a non-cryptographic hash for the reference only.
- **Person-protection spine.** The design records *access as a veiled resonance-seed*, never whereabouts; a flip into settlement is an explicit, auditable User-GROUP act written to the provenance log as an **event, not an identity**. This is the same person-VEIL discipline as the POSTERITY Ledger (ERES-LLPM-2026-001).
- The canonical Document ID is reserved to JAS; `ERES-IPIDITIS-FLIP-2026-001` is a working ID.

## Cite as

Sprute, J. A., with Claude (Anthropic). (2026). *The IPIDITIS FLIP: Authentication as the Reverse-Direction Face of IDIPITIS — Consent-Directional Access-Privilege for Identity-Without-Surveillance* (ERES-IPIDITIS-FLIP-2026-001, v0.1 PROVISIONAL). ERES Institute for New Age Cybernetics. CC BY-SA 4.0. ORCID 0000-0001-9946-3221. DOI: pending.

---

*ERES Institute for New Age Cybernetics — "We build not for today alone, but for generations to inherit harmony between Earth and civilization."*
