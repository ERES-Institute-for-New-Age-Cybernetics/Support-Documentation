# ABOUT — ERES-IPIDITIS-FLIP-2026-001 · The IPIDITIS FLIP

*A companion to this Zenodo record. Part 1 is specific to this deposit; Part 2 is standing context about the ERES Institute and is reused across ERES deposits.*

---

## Part 1 — About this record

**What it is.** IDIPITIS is the ERES *bidirectional* security architecture for **identity without surveillance**. Because it is bidirectional, it has a forward read and a reverse read. This instrument gives the reverse read a name and a duty:

- **IDIPITIS** (forward) = **settlement identity** — *who owes / owns / receives* (the receipts→DOFA ledger).
- **IPIDITIS** (reverse) = **authentication** — *who may do what* (access privilege: Rights · Roles · Rules).

The hinge between them is the **FLIP**, governed by one safety invariant — **I-FLIP: consent-directionality**. Access never *silently* becomes settlement-identity; promotion happens only on an explicit, auditable act of the User-GROUP, logged as an **event, not an identity**, with a default bias reverting to the commons Floor. That is what lets an ERES front door — including a public "number anyone can call for real help" — authenticate access *without recording who you are*.

**What's in the download** (`ERES-IPIDITIS-FLIP-2026-001_v0-1_RG-SUBMISSION.zip`):

| File | What it is |
|------|-----------|
| `…_v0-1_PROVISIONAL.md` | The whitepaper — **MD master, source of record**. |
| `…_v0-1_PROVISIONAL.pdf` | Rendered PDF (derived; regenerate from the MD, don't hand-edit). |
| `…_TESTBENCH_v0-1.html` | Interactive test bench — exercise the FLIP and run its invariants live in a browser. |
| `test_ipiditis_flip.py` | Stdlib-only reference implementation + `unittest` suite (the invariants, falsifiable). |
| `…_FIGURE_the-flip.svg` | Architecture figure. |
| `README.md`, `META.txt` | Manifest / run notes, and title·abstract·keywords·license·IDs. |

**How to read it, fastest first:**
1. Open the **HTML test bench** (double-click; no install, no network). Engage IPIDITIS, watch identity stay *veiled*, let Δτ lapse to Floor, attempt a *silent promotion* (refused), then do a *consented flip*. Press **Run invariants**.
2. Run the **Python suite**: `python3 test_ipiditis_flip.py` (expect `OK`, 7/7).
3. Read the **PDF / MD** for the argument and the open items.

**Honest status — read before citing.** This is **PROVISIONAL v0.1**: pre-canonical, not peer-reviewed, no MIEVM ensemble return incorporated (canonization gate is an explicit ≥5-node MIEVM mean ≥ 9.0). The one-way, consent-gated **I-FLIP cryptography is specified, not implemented** — it is stubbed as a plain guard in both the bench and the Python kit, which verify **state-machine invariants, not cryptographic guarantees**. Do not deploy the reference as a security control. No fabricated data. The canonical Document ID is reserved to the author; `ERES-IPIDITIS-FLIP-2026-001` is a working ID.

**Where it sits in the corpus.** It extends **IDIPITIS** (Trilogy Book Two, "Security-Clearance"), the root it reads in reverse; it secures **NBERS**; its inversion is the access-domain instance of the **Economic FLIP** (ERES-FLIP-2026-001, *magnitude→duration*); its person-VEIL discipline is shared with the **POSTERITY Ledger** (ERES-LLPM-2026-001); and its settlement face is the **DOFA** receipts ledger (ERES-DOFA-WP-2026-001-C). Governance rides the PlayNAC / CBGMODD / BERA / PoR / SOMT stack.

---

## Part 2 — About the ERES Institute

The **ERES Institute for New Age Cybernetics** is an open-source research institute working toward an **Empirical Realtime Education System** — a Personal · Public · Private framework for planetary coordination that treats sustainability as a self-regulating, measurable engine rather than an external compliance burden. Founded **February 2012** in **Bella Vista, Arkansas**, by **Joseph Allen Sprute (ERES Maestro)**, Founder & Director (U.S. Army veteran; ORCID 0000-0001-9946-3221).

The corpus is organized around a moral-vectoring principle — *Personal / Public-Private Graceful Evolution* — and a small set of identities, including **C = R × P / M** (Cybernetics = Resource × Purpose ÷ Method). Its instruments span economics (UBIMIA, Meritcoin Proof-of-Resonance, EarnedPath), institutional trust (IDIPITIS, NBERS, GSSG, SCALULAR, SROC), and governance (PlayNAC, CBGMODD, GAIA, BERA, SOMT) within a 1000-Year Future Map.

- **Web:** https://eresinstitute.org
- **Code & corpus:** https://github.com/ERES-Institute-for-New-Age-Cybernetics
- **ORCID:** 0000-0001-9946-3221
- **License across the corpus:** CARE Commons Attribution License (CCAL) v2.1 / CC BY-SA 4.0.

---

## Cite this record

Sprute, J. A., with Claude (Anthropic). (2026). *The IPIDITIS FLIP: Authentication as the Reverse-Direction Face of IDIPITIS — Consent-Directional Access-Privilege for Identity-Without-Surveillance* (ERES-IPIDITIS-FLIP-2026-001, v0.1 PROVISIONAL). ERES Institute for New Age Cybernetics. CC BY-SA 4.0. ORCID 0000-0001-9946-3221. DOI: *(this Zenodo DOI)*.

---

*ERES Institute for New Age Cybernetics — "We build not for today alone, but for generations to inherit harmony between Earth and civilization."*
