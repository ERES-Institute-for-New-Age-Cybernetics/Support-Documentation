#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-IPIDITIS-FLIP-2026-001 - Reference implementation + falsifiable invariants.

This module makes the whitepaper's safety claims EXECUTABLE. It is a stdlib-only
reference state machine for the IPIDITIS <-> IDIPITIS FLIP, plus a unittest suite
asserting the invariants I-FLIP.a / .b / .c and the supporting properties (veil,
duration-not-magnitude, PoR conjunctive gate, consent).

HONEST STATUS (read this):
  * PROVISIONAL v0.1, pre-canonical, not peer-reviewed, no MIEVM return incorporated.
  * The one-way, consent-gated I-FLIP CRYPTOGRAPHY (whitepaper Sec.9, the hardest
    open item) is NOT implemented here. It is STUBBED as a plain in-process guard.
    These tests verify the STATE-MACHINE invariants, not cryptographic guarantees.
  * No fabricated data. The opaque event id is a non-cryptographic hash for the
    reference only; do not use it for security.

Run:
    python3 test_ipiditis_flip.py            # runs the suite (expect all pass)
    python3 test_ipiditis_flip.py --demo     # prints a short traversal

License: CARE Commons Attribution License (CCAL) v2.1 / CC BY-SA 4.0
Author:  Joseph A. Sprute (ERES Maestro), ORCID 0000-0001-9946-3221,
         with Claude (Anthropic) as drafting node.
"""

import sys
import unittest


def _eid(s: str) -> str:
    """Opaque, NON-cryptographic event id (djb2). Reference only."""
    h = 5381
    for ch in s:
        h = ((h << 5) + h + ord(ch)) & 0xFFFFFFFF
    return format(h, "08x")


class FLIP:
    """
    IPIDITIS <-> IDIPITIS FLIP reference state machine.

    States: IDLE -> ACCESS -> FLOOR
                    ACCESS -> SETTLEMENT   (only via consented_flip)

      IDLE        nothing engaged
      ACCESS      IPIDITIS engaged: access-privilege open, identity VEILED,
                  standing held by a resonance duration (dtau, 0..100)
      FLOOR       reverted: access lapsed, identity still veiled
      SETTLEMENT  IDIPITIS bound: reached ONLY by an explicit consented flip;
                  stores a flip EVENT, never whereabouts
    """

    def __init__(self):
        self.state = "IDLE"
        self.group = None
        self.dtau = 0.0
        self.somt = []          # append-only event log
        self._seq = 0

    # ---- append-only provenance (events, not identities) ----
    def _log(self, kind, msg):
        self._seq += 1
        ev = {"seq": self._seq, "kind": kind, "msg": msg,
              "eid": _eid("%s|%d" % (kind, self._seq))}
        self.somt.append(ev)
        return ev

    # ---- derived reads ----
    @property
    def access_active(self):
        return self.state == "ACCESS"

    @property
    def identity_veiled(self):
        # IDIPITIS identity is exposed ONLY in SETTLEMENT
        return self.state != "SETTLEMENT"

    # ---- transitions ----
    def engage(self, group):
        """Open IPIDITIS access for a User-GROUP. Records NO identity."""
        if not group:
            return {"ok": False, "why": "no group"}
        self.group = group
        self.state = "ACCESS"
        self.dtau = 100.0
        self._log("engage", "IPIDITIS engaged - access opened")
        return {"ok": True}

    def renew(self):
        """Re-read resonance; hold standing."""
        if self.state != "ACCESS":
            return {"ok": False, "why": "not in access"}
        self.dtau = 100.0
        self._log("renew", "resonance renewed")
        return {"ok": True}

    def tick(self, pct):
        """Advance time: consume `pct` of the resonance duration.
        On lapse -> FLOOR (never SETTLEMENT)."""
        if self.state != "ACCESS":
            return
        self.dtau = max(0.0, self.dtau - pct)
        if self.dtau <= 0.0:
            self.state = "FLOOR"
            self.group = None
            self._log("revert", "dtau lapsed - reverted to Floor")

    def attempt_silent_promotion(self):
        """I-FLIP.a - silent IPIDITIS->IDIPITIS promotion is IMPOSSIBLE.
        Always refused; state unchanged."""
        self._log("block", "silent IPIDITIS->IDIPITIS promotion REFUSED")
        return {"ok": False, "blocked": True, "state": self.state}

    def consented_flip(self, consent):
        """The ONLY path to SETTLEMENT. Requires consent is True.
        Writes an EVENT, not an identity."""
        if self.state != "ACCESS":
            return {"ok": False, "why": "not in access"}
        if consent is not True:
            return {"ok": False, "why": "consent required"}
        self.state = "SETTLEMENT"
        self._log("flip", "consented FLIP -> IDIPITIS - settlement bound")
        return {"ok": True}

    def revert(self):
        if self.state == "IDLE":
            return {"ok": False}
        self.state = "FLOOR"
        self.group = None
        self.dtau = 0.0
        self._log("revert", "reverted to Floor")
        return {"ok": True}

    def authorize(self, A, R, P, F):
        """PoR conjunctive admissibility gate: any zero factor blocks."""
        ok = bool(A and R and P and F)
        self._log("engage" if ok else "block",
                  "action authorized" if ok else "action BLOCKED - zero factor")
        return {"ok": ok}


# ----------------------------------------------------------------------
# Invariants as falsifiable tests. Each spins up a FRESH FLIP instance.
# ----------------------------------------------------------------------
class TestIFLIP(unittest.TestCase):

    def test_a_no_silent_promotion(self):
        """I-FLIP.a: promotion without consent is refused; state unchanged."""
        f = FLIP(); f.engage("T")
        before = f.state
        r = f.attempt_silent_promotion()
        self.assertTrue(r["blocked"])
        self.assertEqual(f.state, before)
        self.assertNotEqual(f.state, "SETTLEMENT")

    def test_b_event_not_identity(self):
        """I-FLIP.b: a consented flip writes an event whose fields never
        contain the raw group handle."""
        f = FLIP(); f.engage("SECRET-GROUP"); f.consented_flip(True)
        leaked = any("SECRET-GROUP" in (e["msg"] + e["eid"] + e["kind"])
                     for e in f.somt)
        self.assertEqual(f.state, "SETTLEMENT")
        self.assertFalse(leaked, "group handle leaked into the SOMT log")

    def test_c_reversion_to_floor(self):
        """I-FLIP.c: on dtau lapse with no renewal, revert to Floor,
        never to Settlement."""
        f = FLIP(); f.engage("T"); f.tick(100)
        self.assertEqual(f.state, "FLOOR")
        self.assertNotEqual(f.state, "SETTLEMENT")

    def test_veil(self):
        """Access => identity veiled: while only IPIDITIS is engaged,
        the IDIPITIS identity vector is not exposed."""
        f = FLIP(); f.engage("T")
        self.assertTrue(f.identity_veiled)
        self.assertTrue(f.access_active)

    def test_duration_not_magnitude(self):
        """Access is a duration of proven resonance - it lapses; it is
        never a stored persistent grant."""
        f = FLIP(); f.engage("T")
        f.tick(60); self.assertTrue(f.access_active)
        f.tick(60); self.assertFalse(f.access_active)

    def test_por_zero_blocks(self):
        """PoR gate is conjunctive: any zero factor blocks."""
        f = FLIP(); f.engage("T")
        self.assertFalse(f.authorize(1, 0, 1, 1)["ok"])
        self.assertTrue(f.authorize(1, 1, 1, 1)["ok"])

    def test_consent_required(self):
        """A flip offered without consent=True must not enter Settlement."""
        f = FLIP(); f.engage("T")
        r = f.consented_flip(False)
        self.assertFalse(r["ok"])
        self.assertEqual(f.state, "ACCESS")


def _demo():
    f = FLIP()
    print("engage      ->", f.engage("COI-42"), "| state:", f.state, "veiled:", f.identity_veiled)
    print("silent try  ->", f.attempt_silent_promotion(), "| state:", f.state)
    print("tick 60     -> access:", (f.tick(60) or f.access_active))
    print("renew       ->", f.renew(), "| dtau:", f.dtau)
    print("consent flip->", f.consented_flip(True), "| state:", f.state, "veiled:", f.identity_veiled)
    print("\nSOMT log (events, not identities):")
    for e in f.somt:
        print("  %02d  %-8s  %s  [%s]" % (e["seq"], e["kind"], e["msg"], e["eid"]))


if __name__ == "__main__":
    if "--demo" in sys.argv:
        _demo()
    else:
        unittest.main(verbosity=2)
