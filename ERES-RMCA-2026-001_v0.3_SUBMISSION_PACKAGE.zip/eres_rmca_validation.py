#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-RMCA-2026-001 — Validation Suite
From Extraction to Tuning: The Resonance-Model Family and the
SUBMIT-Sentry Conversion Architecture.

Companion to ERES-RMCA-2026-001_v0.3_DRAFT.md
Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics
Drafting: AI instruments under author direction (Sentience convention); drafting
instruments recused from full MIEVM. License: CCAL v2.1 / CC-BY 4.0.

v0.2: KT-6 Civigen sealed and verified in t01 (Civic x Citizen + Generation);
former Civigen skip retired; S4 narrowed to SBRM@S6.
v0.3: D.I.D. glossed = Defense-in-Depth (=/~) -- layered independent validation,
no single load-bearing validator (author read = layer 1; one instrument >= 9.2
= layer 2; full MIEVM = greater depth). No test-logic change.

Instrument is D.I.D.-cleared (author-strong read + Gemini 9.3/9.6), NOT a
completed MIEVM.

SCOPE / ANTI-FABRICATION
------------------------
This suite exercises the STRUCTURAL and LOGICAL rules of the architecture as
assertions (a state machine, four discriminations, and two invariants) over
SYNTHETIC constructs. It does NOT claim that any Sentry, token, or eigenvalue
exists or has been measured, and it does NOT close S5, define any ERES-SROC
Author-Definition-Register term, or modify any SROC specification.

Confirm/falsify separation: well-formed cases must PASS; malformed cases
(frozen extractor, over-locked population, self-identical AVATAR, unframed
fusion) must be REJECTED by the same rule. The exit code is the verdict:
0 iff every executed (non-skipped) test passes.

SKIP states are LOAD-BEARING: they map to the §7 OPEN items and to the
scope-firewalled formula-level questions. The suite goes fully green only
when those items close upstream. A green-with-no-skips result today would be
a false signal.

DVC tags in comments: [STATED] author-ruled; [DERIVED] follows by
construction; [CONSTRUCTED] scaffolding, not forced.
"""

import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List

# ----------------------------------------------------------------------
# Test harness
# ----------------------------------------------------------------------
_RESULTS = []  # (name, status, detail)

def check(name, fn):
    try:
        detail = fn()
        _RESULTS.append((name, "PASS", detail or ""))
    except AssertionError as e:
        _RESULTS.append((name, "FAIL", str(e)))
    except Exception as e:  # pragma: no cover
        _RESULTS.append((name, "ERROR", f"{type(e).__name__}: {e}"))

def skip(name, reason):
    _RESULTS.append((name, "SKIP", reason))

def rejects(callable_, exc=Exception):
    """Assert that a malformed input is refused (raises)."""
    try:
        callable_()
    except exc:
        return True
    raise AssertionError("malformed case was NOT rejected")


# ----------------------------------------------------------------------
# Minimal model of the architecture
# ----------------------------------------------------------------------
class Axis1(Enum):          # scope ceiling
    BIOLOGICAL = "planet-bounded"
    SUPER = "beyond-planet"

class Axis2(Enum):          # position relative to RM
    IS_RM = "owns-field"
    RESIDES = "resident-artifact"

class Disposition(Enum):
    RECYCLABLE = "in-loop"       # token present
    HELD = "veiled"              # AUTH=no, under investigation
    RETIRED = "terminal"         # no token

@dataclass
class RMToken:
    """A member of the Resonance-Model family, placed by the two axes."""
    name: str
    axis1: Axis1
    axis2: Axis2
    @property
    def is_resonance_model(self) -> bool:      # [STATED KT-2]
        return self.axis2 is Axis2.IS_RM
    @property
    def is_extraction_pole(self) -> bool:      # [STATED KT-5]
        # SBM: super-biological AND resident = the extraction pole
        return self.axis1 is Axis1.SUPER and self.axis2 is Axis2.RESIDES

# canonical family placement [STATED]
RM   = "RM (container/field)"
BRM  = RMToken("BRM",  Axis1.BIOLOGICAL, Axis2.IS_RM)
SBRM = RMToken("SBRM", Axis1.SUPER,      Axis2.IS_RM)
SBM  = RMToken("SBM",  Axis1.SUPER,      Axis2.RESIDES)
FAMILY = [BRM, SBRM, SBM]

# KT-6 Civigen Initialization Matrix (sealed v0.2; closes former open item 1).
# BRM instantiates via Civic x Citizen + Generation. [STATED decomposition;
# DERIVED operator-law reading: x = conjunctive/Earned, + = Given/unconditional]
CIVIGEN = {
    "Civic":      "systemic field/space (RM-owned substrate)",
    "Citizen":    "agent node; consenting SUBMIT participant",
    "Generation": "inf-P(t) time-vector; FOCUS->FUSION driver",
}
CIVIGEN_OP = {"Civic": "x", "Citizen": "x", "Generation": "+"}


@dataclass
class Element:
    """A thing submitted for conversion; carries its eigenvalue IT when live."""
    name: str
    resonant_load: float          # contribution to registry resonance
    IT: Optional[float] = None    # the Token Eigenvalue = "WHAT"; None if retired
    disposition: Optional[Disposition] = None
    frozen_extractor: bool = False  # malformed: claims to be a permanent extractor

@dataclass
class Caller:
    admitted: bool = False

@dataclass
class Sentry:
    role: str                     # "spawn" or "receive"
    origin: str                   # which AVATAR position

class Avatar:
    """MIND surface. Straddles: spawns AND receives the Sentry, as two
    DISTINCT realizations (spawn-role ~/= receive-role). [STATED]"""
    def spawn(self, element: Element) -> Sentry:
        return Sentry(role="spawn", origin="AVATAR@spawn")
    def receive(self, s: Sentry) -> Sentry:
        # receive is a DISTINCT position; refuse a self-identical straddle
        if s.role == "receive":                        # [DERIVED]
            raise ValueError("spawn-role must not equal receive-role")
        return Sentry(role="receive", origin="AVATAR@receive")


def sprt_auth(element: Element) -> bool:
    """SPRT = AUTH=yes/no. The only surface carrying a real NO. [STATED]
    A frozen-extractor element fails authorization (cannot be tuned)."""
    if element.frozen_extractor:
        return False
    return element.resonant_load > 0.0


def submit(element: Element, caller: Caller, avatar: Avatar):
    """The gated arc: SUBMIT -> SPRT(AUTH?) -> [yes] AVATAR manifests Sentry
    -> BODY handoff, token minted, recyclable. [STATED]
    KOL non-refusal: the caller is ADMITTED regardless of AUTH; only the
    ELEMENT can be held. [STATED]"""
    caller.admitted = True                              # never turned away
    if not sprt_auth(element):
        element.disposition = Disposition.HELD          # VEILED / under investigation
        return None
    s_spawn = avatar.spawn(element)
    s_recv = avatar.receive(s_spawn)                    # handoff, not a loop
    # token minted => IT (eigenvalue) defined; recyclable
    if element.IT is None:
        element.IT = element.resonant_load              # eigenvalue realized
    element.disposition = Disposition.RECYCLABLE
    return (s_spawn, s_recv)


def recycle(element: Element, n: int) -> List[float]:
    """FOCUS->FUSION feedback: re-apply the operator n times. The eigenvalue
    IT is the conserved quantity. [DERIVED]"""
    assert element.disposition is Disposition.RECYCLABLE, "only tokens recycle"
    trace = []
    for _ in range(n):
        # eigen-iteration: operator returns lambda*v; IT invariant
        trace.append(element.IT)
    return trace


def retire(element: Element):
    """No token => retired => no eigenvector => IT undefined. [STATED]"""
    element.IT = None
    element.disposition = Disposition.RETIRED


def lean_sim(registry: List[Element], threshold: float = 0.85) -> List[Element]:
    """Retirement = greedy backward elimination: iteratively remove the
    element whose removal does NOT reduce the population resonance below
    threshold (i.e. carries no resonant load). Mirrors the EIGEN-PIPELINE
    Lean-SIM. [CONSTRUCTED bridge, grounded in stated Lean-SIM def]"""
    keep = list(registry)
    changed = True
    while changed:
        changed = False
        for e in list(keep):
            trial = [x for x in keep if x is not e]
            if not trial:
                continue
            if rho_R(trial) >= rho_R(keep) - 1e-12:     # removal preserves rho
                keep = trial
                retire(e)
                changed = True
                break
    return keep


def rho_R(registry: List[Element]) -> float:
    """Population resonance = mean normalized resonant load of live elements.
    Certification gate rho_R >= 0.85. Synthetic. [CONSTRUCTED]"""
    live = [e for e in registry if e.IT is not None]
    if not live:
        return 0.0
    return sum(min(1.0, e.resonant_load) for e in live) / len(live)


# ----------------------------------------------------------------------
# Tests  (confirm + falsify)
# ----------------------------------------------------------------------
def t01_family_grid():
    # two axes -> four cells; the three named tokens are pairwise distinct
    coords = {(m.axis1, m.axis2) for m in FAMILY}
    assert len(coords) == 3, "named tokens must occupy distinct cells"
    assert BRM.is_resonance_model and SBRM.is_resonance_model, "BRM/SBRM are RMs"
    assert not SBM.is_resonance_model, "SBM is NOT an RM (resides inside one)"
    # KT-6: BRM initializes via Civic x Citizen + Generation
    assert set(CIVIGEN) == {"Civic", "Citizen", "Generation"}, "Civigen = three vectors"
    assert [CIVIGEN_OP["Civic"], CIVIGEN_OP["Citizen"]] == ["x", "x"], \
        "Civic x Citizen is conjunctive (Earned)"
    assert CIVIGEN_OP["Generation"] == "+", "Generation is the Given/additive driver"
    return "4-cell grid; BRM/SBRM=RM, SBM=resident; Civigen KT-6 verified"

def t02_extraction_pole_convertible():
    # SBM is the extraction pole, and it is CONVERTIBLE (not frozen)
    assert SBM.is_extraction_pole, "SBM must be the extraction pole"
    assert not (BRM.is_extraction_pole or SBRM.is_extraction_pole)
    e = Element("sbm-instance", resonant_load=0.9)
    caller, av = Caller(), Avatar()
    submit(e, caller, av)
    assert e.disposition is Disposition.RECYCLABLE, "SBM must be convertible"
    # falsify: a FROZEN extractor must be refused (no permanent extractor)
    ez = Element("frozen", resonant_load=0.9, frozen_extractor=True)
    submit(ez, Caller(), Avatar())
    assert ez.disposition is Disposition.HELD, "frozen extractor must not convert"
    return "SBM converts; frozen extractor rejected"

def t03_auth_binary():
    assert sprt_auth(Element("a", 0.5)) in (True, False)
    assert sprt_auth(Element("b", 0.0)) is False
    return "SPRT returns yes/no only"

def t04_held_not_turned_away():
    # KOL non-refusal absolute: caller admitted even on AUTH=no
    e = Element("held", resonant_load=0.0)     # AUTH=no
    caller = Caller()
    submit(e, caller, Avatar())
    assert caller.admitted is True, "caller must NEVER be turned away"
    assert e.disposition is Disposition.HELD, "element is held, not rejected"
    return "caller admitted; element VEILED"

def t05_disposition_set():
    states = {Disposition.RECYCLABLE, Disposition.HELD, Disposition.RETIRED}
    assert len(states) == 3, "exactly three dispositions"
    # held is non-terminal: can later recycle or retire
    e = Element("h", resonant_load=0.0)
    submit(e, Caller(), Avatar())
    assert e.disposition is Disposition.HELD
    retire(e)                                   # unresolved -> terminal
    assert e.disposition is Disposition.RETIRED and e.IT is None
    return "recyclable/held/retired; held is non-terminal"

def t06_avatar_straddle_nonidentity():
    av = Avatar()
    e = Element("x", resonant_load=0.7)
    s_spawn = av.spawn(e)
    s_recv = av.receive(s_spawn)
    assert s_spawn.role != s_recv.role, "spawn-role ~/= receive-role"
    assert s_spawn.origin != s_recv.origin, "distinct AVATAR positions"
    # falsify: a self-identical straddle (receive a receive) must be refused
    rejects(lambda: av.receive(s_recv), ValueError)
    return "handoff, not self-referential collapse"

def t07_eigen_invariance():
    e = Element("eig", resonant_load=0.6)
    submit(e, Caller(), Avatar())
    trace = recycle(e, 5)
    assert len(set(trace)) == 1, "IT must be conserved across recycles"
    assert trace[0] == e.IT, "conserved value is the eigenvalue IT"
    retire(e)
    assert e.IT is None, "retired => no eigenvector => IT undefined"
    return "IT invariant under recycling; undefined on retirement"

def t08_fair_before_fusion():
    # fused => fair ONLY if the FAIR frame was defined first
    def fused_is_fair(frame_defined_first: bool):
        if not frame_defined_first:
            raise ValueError("no frame: fusion cannot confer fair")
        return True
    assert fused_is_fair(True) is True
    rejects(lambda: fused_is_fair(False), ValueError)  # circularity guard
    return "FAIR-def -> FUSION -> FAIR-verified; unframed fusion rejected"

def t09_veiled_exception():
    # element under investigation suspends the precedence; stays HELD
    e = Element("inv", resonant_load=0.0)      # AUTH=no => under investigation
    submit(e, Caller(), Avatar())
    assert e.disposition is Disposition.HELD
    # neither fused=>fair nor fair-def may close it while held
    can_close = e.disposition is Disposition.RECYCLABLE
    assert not can_close, "held element must not be closed"
    return "investigation suspends precedence"

def t10_lean_sim_retirement():
    reg = [Element("load-a", 0.95, IT=0.95),
           Element("load-b", 0.90, IT=0.90),
           Element("dead",  0.00, IT=0.00)]   # carries no resonant load
    kept = lean_sim(reg, threshold=0.85)
    names = {e.name for e in kept}
    assert "dead" not in names, "zero-load element must be retired (Lean-SIM)"
    assert rho_R(kept) >= 0.85, "kept population certifies in-band"
    return "greedy backward elimination retires no-load element"

def t11_aggregation_bridge():
    # rho_R = ensemble stat over token eigenvalues; certify at >= 0.85
    in_band = [Element(f"i{i}", 0.9, IT=0.9) for i in range(5)]
    assert rho_R(in_band) >= 0.85, "in-band population must certify"
    # falsify: an incoherent population must FAIL certification
    out_band = [Element(f"o{i}", 0.3, IT=0.3) for i in range(5)]
    assert rho_R(out_band) < 0.85, "out-of-band population must fail"
    return "population certification tracks the 0.85 gate"


def main():
    check("T01 RM-family grid + KT-6 Civigen [STATED KT-2/KT-6]", t01_family_grid)
    check("T02 extraction pole convertible, frozen rejected [STATED KT-5]", t02_extraction_pole_convertible)
    check("T03 SPRT AUTH is binary [STATED]", t03_auth_binary)
    check("T04 held != turned away (KOL non-refusal) [STATED]", t04_held_not_turned_away)
    check("T05 disposition set {recyclable,held,retired} [STATED]", t05_disposition_set)
    check("T06 AVATAR straddle non-identity handoff [STATED]", t06_avatar_straddle_nonidentity)
    check("T07 eigen-iteration invariance of IT [DERIVED]", t07_eigen_invariance)
    check("T08 FAIR-def before FUSION [STATED]", t08_fair_before_fusion)
    check("T09 VEILED investigation exception [STATED]", t09_veiled_exception)
    check("T10 retirement = Lean-SIM elimination [CONSTRUCTED]", t10_lean_sim_retirement)
    check("T11 aggregation bridge / rho_R gate [CONSTRUCTED]", t11_aggregation_bridge)

    # LOAD-BEARING SKIPS -> the §7 OPEN items and firewalled questions
    skip("S1 SPRT<->Gamma literal identity", "OPEN §7.4: isomorphic vs identical unruled")
    skip("S2 formula-level EIGEN-PIPELINE operator identity", "OPEN §7.5: needs the actual MATH doc / .py")
    skip("S3 KT-3 / KT-4 ratification", "OPEN §7.6: inherits-vs-owns, consumes-vs-provisions are CONSTRUCTED")
    skip("S4 SBRM@S6 occupy-vs-close", "OPEN §7.1: S6 Beyond boundary behavior unresolved (Civigen retired to KT-6)")

    # report
    width = max(len(n) for n, _, _ in _RESULTS)
    n_pass = n_fail = n_skip = n_err = 0
    print("=" * (width + 12))
    print("ERES-RMCA-2026-001 Validation Suite")
    print("=" * (width + 12))
    for name, status, detail in _RESULTS:
        print(f"[{status:4}] {name:<{width}}  {detail}")
        n_pass += status == "PASS"
        n_fail += status == "FAIL"
        n_skip += status == "SKIP"
        n_err  += status == "ERROR"
    print("-" * (width + 12))
    print(f"PASS={n_pass}  FAIL={n_fail}  ERROR={n_err}  SKIP={n_skip} (load-bearing)")
    verdict = 0 if (n_fail == 0 and n_err == 0) else 1
    print(f"VERDICT: exit {verdict}  "
          f"({'all executed tests pass; skips remain OPEN' if verdict == 0 else 'failure'})")
    print("NOTE: PASS is evidence, not proof. Skips stay until §7 closes upstream.")
    return verdict


if __name__ == "__main__":
    sys.exit(main())
