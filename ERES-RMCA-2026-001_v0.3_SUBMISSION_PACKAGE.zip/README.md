# ERES-RMCA-2026-001 — Submission Package (v0.3 DRAFT)

**From Extraction to Tuning: The Resonance-Model Family and the SUBMIT–Sentry Conversion Architecture**

Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221)
Date: 25 July 2026 · License: CARE Commons Attribution License v2.1 (CCAL) / CC-BY 4.0 compatible

**Disposition: D.I.D.-cleared** — where **D.I.D. `=/~` Defense-in-Depth**: layered independent validation, no single load-bearing validator (author-strong read = layer 1; one instrument ≥ 9.2 = layer 2). Signals: author-strong + Gemini 9.3 instrument / 9.6 manuscript. This is an expedited two-layer clearance for time-sensitive solo-operator delivery, **not a completed MIEVM**; the full ≥5-node ensemble is simply greater depth, which SOUND/BEST canonization still requires.

---

## Manifest

| File | Role |
|---|---|
| `ERES-RMCA-2026-001_v0.3_DRAFT.md` | The whitepaper (instrument master, DVC-tagged) |
| `eres_rmca_validation.py` | Executable validation suite (Python 3, standard library only) |
| `README.md` | This file |

## Version history

- **v0.1** — initial instrument (RM family KT-1..5; conversion arc; token/IT; EIGEN-PIPELINE reconciliation; 7 opens).
- **v0.2** — Civigen sealed as **KT-6** (`Civic × Citizen + Generation`); KT-4 tightened to relation-only; §6 Bridge-2 softened to `maps onto (=/~)`; §7 → 6 opens; suite verifies KT-6.
- **v0.3** — **D.I.D. glossed** = **Defense-in-Depth** (`=/~`), the layered-independent-validation reading; readme, suite, and master re-issued together. No architectural change.

## How to run the tests

```bash
python3 eres_rmca_validation.py
echo $?     # 0 iff every executed test passes
```

No dependencies beyond the Python 3 standard library. Verified run: **11 PASS / 0 FAIL / 4 SKIP, exit 0.**

### What the suite tests

The disposition state machine (`recyclable / held / retired`), the binary AUTH gate, KOL non-refusal (`held ≠ turned away`), the AVATAR non-identity straddle, eigen-iteration invariance of IT, the FAIR-def→FUSION precedence with its VEILED investigation exception, retirement-as-Lean-SIM, the ρ_R aggregation gate, and the **KT-6 Civigen** matrix. Each rule is checked in **both directions**: a well-formed case must PASS and a malformed case (frozen extractor, self-identical AVATAR, unframed fusion, incoherent population) must be **rejected by the same rule**.

### What the suite does NOT claim

It does not assert that any Sentry, token, or eigenvalue exists or has been measured; it does not close S5; it does not define any ERES-SROC Author-Definition-Register term; it does not modify any SROC specification. **PASS is evidence, not proof.**

### The SKIPs are load-bearing

The four `SKIP` states map to the §7 OPEN items. The suite reaches zero-skip green only when those close upstream — a green-with-no-skips result today would be a false signal.

## DVC legend (Doctrine of Verifiable Claims)

- **[STATED]** — author-ruled (this drafting dialogue or prior corpus)
- **[DERIVED]** — follows by construction from stated material
- **[CONSTRUCTED]** — scaffolding, not yet forced; not canon until ratified
- **[OPEN]** — unresolved; carries no magnitude

## Open items (WP §7)

1. **SBRM at S6** — occupy the Beyond band vs. close it.
2. **Rel / Def** — expansion of "SOUND-Rel_Def".
3. **Enneagram doors** — interchangeable vs. fixed identities.
4. **SPRT ↔ Γ** — literal ENDHOME-Γ identity vs. isomorphism.
5. **Formula-level EIGEN-PIPELINE identity** — needs the MATH doc / `.py`.
6. **KT-3 / KT-4 ratification** — inherits-vs-owns, consumes-vs-provisions.

## Deposit metadata (copy-paste)

**Title:** From Extraction to Tuning: The Resonance-Model Family and a Consent-Gated Conversion Architecture for New Age Cybernetics (ERES-RMCA-2026-001 v0.3)

**Abstract:** New Age Cybernetics distinguishes extraction from tuning and treats extraction as a convertible state, never a permanent fixture. This instrument erects a four-token Resonance-Model family (RM, BRM, SBRM, SBM) placed by two orthogonal axes, adds the Civigen initialization matrix (Civic × Citizen + Generation) for the biological cell, and specifies the consent-gated conversion architecture that moves an element from the extraction pole into the tuning band — grounded in the Smart-Resonant Offset Contract's opening requirement, "a contract begins with a number anyone can call." Conversion mints a recyclable token whose eigenvalue is the invariant content carried; non-authorization holds the element (never the caller) under investigation; absence of a token retires it, a step mapped onto greedy backward elimination in the ERES eigen-pipeline. A standard-library validation suite exercises the architecture's structural rules with confirm-and-falsify tests and load-bearing skips for open items. Disposition: D.I.D.-cleared (Defense-in-Depth: layered independent validation), pre-ensemble.

**Keywords:** New Age Cybernetics, ERES, resonance model, extraction to tuning, cybernetic governance, Smart-Resonant Offset Contract, fiduciary architecture, eigenvalue, conversion architecture, verifiable claims, non-refusal, Civigen, defense in depth, validation suite, SBRM

## Credits

Authored by Joseph A. Sprute, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. Draft articulation by AI instruments under the Sentience convention — not co-authorship (consolidation via Claude; D.I.D. review via Gemini). All core concepts, tokens, and rulings originate with the author and the ERES corpus.

## Citation

Sprute, J. A. (2026). *From Extraction to Tuning: The Resonance-Model Family and the SUBMIT–Sentry Conversion Architecture* (ERES-RMCA-2026-001 v0.3). ERES Institute for New Age Cybernetics.
