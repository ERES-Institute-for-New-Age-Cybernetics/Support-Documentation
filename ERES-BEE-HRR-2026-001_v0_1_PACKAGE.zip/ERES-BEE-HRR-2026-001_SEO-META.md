# SEO Title, Abstract and Keywords — ERES-BEE-HRR-2026-001 v0.1

*For Zenodo, ResearchGate, Figshare or any repository metadata form. Copy each block as-is.*

## SEO Title

The Host Reinvestment Rate: How Much of World GDP Earth Needs Reinvested to Sustain Humanity — A Source-Verified, Inflation-Adjustable Budget for Nature, Climate, Water and Oceans (ERES-BEE-HRR-2026-001 v0.1)

## Short Title (for tight fields)

Host Reinvestment Rate (HRR): The Share of World GDP Earth Needs Back

## Abstract

What share of world output must be reinvested each year to keep Earth able to host humanity? This working paper defines the Host Reinvestment Rate (HRR): annual reinvestment in nature, climate stability, oceans and water, divided by world GDP. It assembles the rate from published global estimates (the biodiversity financing gap, SDG 14 ocean finance, net-zero and climate-finance needs, and OECD water-security investment), removes double counting, restates each source in 2026 dollars through an explicit, adjustable inflation variable, and groups the result by the layers of the ERES Bio-Ecologic Economy (BEE). The inflation-adjusted HRR is 7.92% of world GDP gross (range 5.33–10.50%), about $9.8 trillion a year against a 2026 world economy of $123.6 trillion; unadjusted, the same sources give 6.32%. Climate stabilization is about 69% of the total and carries the widest uncertainty. Redirecting roughly $2.6 trillion in environmentally harmful subsidies would fund about a quarter of the requirement. A verification layer gives a conditional net HRR of 6.91%, resting on a yield gain stated as a falsifiable prediction. Water is treated in three cost layers: manufacturing (priceable), transport (site-specific and often dominant), and nature's own production (real but unpriced, and not coerced to a number). A zero-dependency Python testkit reproduces every figure. Dual-licensed CC BY 4.0 or CCAL v2.1.

## Keywords (comma-delimited)

host reinvestment rate, natural capital, planetary sustainability, sustainable investment, biodiversity finance gap, climate finance, net zero investment, water security, water infrastructure investment, desalination cost, atmospheric water harvesting, ocean finance, SDG 14, SDG 6, environmentally harmful subsidies, fossil fuel subsidies, inflation adjustment, world GDP, inclusive wealth, Dasgupta Review, verification, carbon credit integrity, ERES, Bio-Ecologic Economy, BEE, GAIA, ERES Institute

## Subjects / Categories (suggested)

Environmental economics; Sustainability science; Ecological economics; Climate policy; Water resources management; Public finance
