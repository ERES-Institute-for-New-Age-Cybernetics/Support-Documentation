#!/usr/bin/env python3
"""Render the whitepaper Markdown to PDF (pandoc -> HTML -> WeasyPrint)."""
import os
import subprocess

from weasyprint import HTML

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "ERES-BEE-HRR-2026-001_v0_1.md")
OUT = os.path.join(HERE, "ERES-BEE-HRR-2026-001_v0_1.pdf")

CSS = """
@page { size: Letter; margin: 0.8in 0.8in 0.85in 0.8in;
  @bottom-left { content: "ERES-BEE-HRR-2026-001 v0.1 · CC BY 4.0 or CCAL v2.1"; font: 8pt Helvetica, Arial, sans-serif; color: #6b757d; }
  @bottom-right { content: "Page " counter(page) " of " counter(pages); font: 8pt Helvetica, Arial, sans-serif; color: #6b757d; } }
body { font-family: "DejaVu Serif", Georgia, serif; font-size: 10pt; line-height: 1.45; color: #1d2329; }
h1 { font-family: Helvetica, Arial, sans-serif; font-size: 22pt; margin: 0 0 4pt 0; color: #14324a; }
h2 { font-family: Helvetica, Arial, sans-serif; font-size: 14pt; color: #14324a; margin-top: 18pt;
     border-bottom: 1.5pt solid #c9792b; padding-bottom: 3pt; page-break-after: avoid; }
h3 { font-family: Helvetica, Arial, sans-serif; font-size: 11pt; color: #14324a; page-break-after: avoid; }
p { margin: 5pt 0; }
table { border-collapse: collapse; width: 100%; margin: 8pt 0; font-size: 8.6pt; page-break-inside: avoid; }
th { background: #14324a; color: #fff; font-family: Helvetica, Arial, sans-serif; text-align: left; padding: 4pt 5pt; }
td { border-bottom: 0.5pt solid #d5dbe0; padding: 3.5pt 5pt; vertical-align: top; }
tr:nth-child(even) td { background: #f5f7f9; }
code { font-family: "DejaVu Sans Mono", monospace; font-size: 8.5pt; background: #f1f3f5; padding: 0 2pt; }
blockquote { border-left: 3pt solid #c9792b; margin: 6pt 0; padding: 2pt 10pt; color: #333; }
img { width: 100%; margin: 6pt 0; }
hr { border: 0; border-top: 0.5pt solid #c8cfd5; margin: 12pt 0; }
li { margin: 2pt 0; }
"""


def main():
    html_body = subprocess.run(
        ["pandoc", SRC, "-f", "markdown+yaml_metadata_block+pipe_tables", "-t", "html5"],
        check=True, capture_output=True, text=True).stdout
    html = (f"<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>The Host Reinvestment Rate (HRR) — ERES-BEE-HRR-2026-001 v0.1</title>"
            f"<meta name='author' content='Joseph Allen Sprute'>"
            f"<style>{CSS}</style></head><body>{html_body}</body></html>")
    HTML(string=html, base_url=HERE).write_pdf(OUT)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
