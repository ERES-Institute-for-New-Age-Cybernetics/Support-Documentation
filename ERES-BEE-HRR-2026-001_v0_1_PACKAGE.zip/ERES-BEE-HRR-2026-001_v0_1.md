---
title: "The Host Reinvestment Rate (HRR): How Much of World Output Earth Needs Reinvested to Keep Humanity Hosted"
subtitle: "A Source-Verified, Inflation-Adjustable, BEE-Layered Budget for Nature, Climate, Water and Oceans"
instrument_id: ERES-BEE-HRR-2026-001
version: "0.1"
status: "PROPOSED — pre-MIEVM, author-side; released for peer review"
date: 2026-10-17
author: "Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221"
institution: "ERES Institute for New Age Cybernetics, Bella Vista, Arkansas, USA"
license: "CC BY 4.0 or CCAL v2.1, at the licensee's option (see LICENSE.md)"
---

# The Host Reinvestment Rate (HRR)

**How Much of World Output Earth Needs Reinvested to Keep Humanity Hosted**
*A Source-Verified, Inflation-Adjustable, BEE-Layered Budget for Nature, Climate, Water and Oceans*

| | |
|---|---|
| **Instrument** | ERES-BEE-HRR-2026-001 |
| **Version / Status** | v0.1 — PROPOSED, pre-MIEVM, released for peer review |
| **Date** | 17 October 2026 |
| **Author** | Joseph Allen Sprute (ERES Maestro) · ORCID 0000-0001-9946-3221 |
| **Institution** | ERES Institute for New Age Cybernetics · Bella Vista, Arkansas |
| **License** | CC BY 4.0 **or** CCAL v2.1, at the licensee's option (LICENSE.md) |
| **Executable companion** | `eres_hrr_testkit.py` (stdlib only; 17 tests; exit 0 = PASS) |
| **Data** | `ERES-BEE-HRR-2026-001_data.json` (every number in this paper derives from it) |

---

## Abstract

Humanity lives on a single host. This paper asks what share of world output must be reinvested each year in that host's productive and protective capacity for it to keep hosting us: for as long as Earth itself endures, or until a second home is built. We define the **Host Reinvestment Rate (HRR)** as annual reinvestment in nature, climate stability, oceans and water, divided by world GDP. We assemble it from published global estimates, remove double counting, restate each source in 2026 dollars through an explicit, adjustable inflation variable, and group the result by the layers of the ERES Bio-Ecologic Economy (BEE).

The inflation-adjusted HRR is **7.92% of world GDP gross** (range **5.33–10.50%**), about **$9.8 trillion a year** against a 2026 world economy of $123.6 trillion. Before inflation adjustment, the same sources give 6.32%. Adding a verification layer that protects the yield of the spending gives a conditional **net HRR of 6.91%**; the yield gain behind that figure is an untested conjecture, stated as a falsifiable prediction. Climate stabilization is about 69% of the total and carries the widest uncertainty. Redirecting today's roughly $2.6 trillion in environmentally harmful subsidies would fund about a quarter of the gross requirement.

Water receives separate treatment because its true cost resists a single number. Manufacturing water is priceable at the plant gate; moving it dominates cost inland. Nature's own production — the solar-driven water cycle — has no price at all, and is carried here as an unpriced substrate rather than an invented figure. Every number is reproducible from the companion data file and testkit.

**Keywords:** host reinvestment rate; natural capital; planetary sustainability; biodiversity finance gap; climate finance; water security; desalination cost; environmentally harmful subsidies; inflation adjustment; ERES; Bio-Ecologic Economy; GAIA.

---

## 0. How to Read This Instrument — Doctrine of Verifiable Claims

Every claim carries its evidential status under the ERES **Doctrine of Verifiable Claims (DVC)**:

| Tag | Meaning in this paper |
|---|---|
| **SOURCED** | Taken from a named published estimate (see References) |
| **DERIVED** | Follows by arithmetic or physics from SOURCED inputs; checked by the testkit |
| **CONSTRUCTED** | A declared policy parameter chosen by the author, not an empirical value |
| **CONJECTURE** | A hypothesis offered for testing; stated as a Prediction with a reject criterion |
| **VEILED** | Real but unpriced; deliberately not coerced to a number |
| **OPEN** | Unresolved; listed in Open Items |

**Data-Integrity rule.** No figure appears in this paper that the testkit cannot reproduce from the data file, and no unpriced quantity is given a placeholder number.

---

## 1. The Question

*What healthy percentage of world output must Earth receive back, as investment, to keep humanity hosted?*

"Hosted" is used precisely. A host is a system whose continued capacity keeps a dependent population alive. Two quantities describe the relationship:

- **The stock:** the host's natural capital (ecosystems, a stable climate, oceans, freshwater, soils).
- **The flow:** what the dependent population reinvests in that stock each year.

**Definition 1 (HRR).** The Host Reinvestment Rate is the annual reinvestment, above current levels, required to keep the host's productive and protective capacity from declining, expressed as a share of world GDP. *[CONSTRUCTED definition]*

**Definition 2 (Healthy).** An HRR is *healthy* when it holds per-capita natural capital non-declining. *[CONSTRUCTED criterion; tested by Prediction P2]*

The rate is the **input instrument**; per-capita natural capital is the **outcome instrument**. A budget can be met while the stock still falls, so the rate is never self-certifying.

---

## 2. Why a Rate, Not a Sum

Between 1992 and 2014, produced capital per person roughly doubled while the stock of natural capital per person fell by nearly 40%. *[SOURCED: Dasgupta 2021]* Measured by GDP alone, that period looks like growth. Measured as a balance sheet, it was partly the drawdown of the host.

A one-time sum cannot correct a continuing drawdown. A rate can, because it is sized against the same economy that produces the depletion. Expressing the requirement as a share of world GDP also makes it comparable across years, currencies and scales of governance.

---

## 3. The Budget

Each line is the best-documented global estimate for its domain, restated to 2026 dollars (Section 4) and divided by a 2026 world GDP of **$123.6 trillion** (IMF). *[SOURCED]* Values are USD trillions per year.

| ID | Line | BEE layer | 2026 USD T/yr | % of world GDP | DVC |
|----|------------------------------------|--------------|--------------|-------------|------------|
| L1 | Nature and food-land transition (biodiversity finance gap) | Land / Region | 0.777–1.071 | 0.63–0.87% | SOURCED |
| L1a | Food-system transition (FOLU) — **excluded, subsumed in L1** | Body | (0.390–0.455) | (0.32–0.37%) | SOURCED |
| L2 | Ocean health (SDG 14) | Land / Region | 0.192–0.224 | 0.16–0.18% | SOURCED |
| L3 | Climate stabilization and adaptation (incremental) | Planet (GAIA) | 4.305–9.225 | 3.48–7.46% | SOURCED |
| L4 | Water infrastructure, access and irrigation | Body | 0.657–0.935 | 0.53–0.76% | SOURCED + DERIVED |
| L5 | Resilience reserve — 10% of L1–L4 | Resilience | 0.593–1.146 | 0.48–0.93% | CONSTRUCTED |
| L6 | Verification layer — 1–3% of L1–L5 | Governance | 0.065–0.378 | 0.05–0.31% | CONSTRUCTED |
| | **Gross HRR** | | **6.589–12.979** | **5.33–10.50%** | DERIVED |

**Line notes.**

- **L1** is the $598–824 billion annual biodiversity financing gap (2019 dollars). Its needs include protected areas ($149–192 B), sustainable agriculture ($315–420 B) and ecosystem restoration ($27–37 B). *[SOURCED: Deutz et al. 2020]*
- **L1a** is shown only as a cross-check. FOLU's $300–350 billion food and land-use transition falls inside L1's sustainable-agriculture component, so counting both would double-count. *[SOURCED: FOLU 2019; exclusion enforced by testkit T4]*
- **L2** uses the roughly $175 billion annual need to achieve SDG 14; the low end (~$150 B) is the gap after current flows. *[SOURCED: WEF Friends of Ocean Action 2022]* Partial overlap with L1's marine protected areas is unresolved (O3).
- **L3** low end: net-zero requires about $9.2 trillion a year in physical-asset spending, about $3.5 trillion more than current levels. *[SOURCED: McKinsey Global Institute 2022]* High end: average need near $9 trillion a year by 2030, less roughly $1.5 trillion in tracked climate finance. *[SOURCED: Climate Policy Initiative 2023, 2024]*
- **L4** annualizes the OECD/World Water Council estimate of water-security investment needs ($6.7 trillion cumulative by 2030; $22.6 trillion by 2050), plus FAO irrigation needs ($960 billion to 2050). It contains the SDG 6.1/6.2 water-and-sanitation capital need (~$114 B/yr). *[SOURCED; annualization DERIVED]* These are total needs, not gaps, so L4 errs high.
- **L5** implements the ERES design axiom *Mission Critical = able to return to base*: a reserve against overlap error, overrun and maintenance decay. The 10% is a policy choice. *[CONSTRUCTED]*
- **L6** funds measurement, reporting and verification at a declared 1–3% of program spend, pending measured cost (O5). *[CONSTRUCTED]*

**Midpoint gross HRR: 7.92% of world GDP, about $9.78 trillion per year.** *[DERIVED; testkit T2]*

---

## 4. Inflation — An Adjustable Variable

The sources were priced in 2015–2021 dollars; the denominator is 2026 GDP. Mixing them understates the requirement, because the physical needs (pipe, plant, hectares) track prices, not output. This paper therefore carries inflation as an explicit variable that any reviewer can change.

**Rule.** Each source amount A(v), priced in vintage year v, is restated as A(2026) = A(v) × m(v).

| Mode | Vintage factor m(v) | Gross midpoint |
|---|---|---|
| `cpi_table` (**default**) | Measured US CPI ratio to 2026: 2015 ×1.40; 2019 ×1.30; 2020 ×1.28; 2021 ×1.23 | **7.92%** |
| `rate` | (1 + π)^(2026 − v), with π = 3.3%, the long-run US average since 1913 | 7.62% |
| `none` | 1 (nominal, unadjusted) | 6.32% |

*[SOURCED (secondary): US CPI via chartrow; replacement by the BLS CPI-U series is O2]*

To change it, edit `inflation` in the data file or run, for example, `python3 eres_hrr_testkit.py --compute --rate 0.025`. Reserve and verification inherit the adjustment because they are proportional.

**Choice of measuring instruments.**

- **Denominator: nominal world GDP at market exchange rates.** The investments are priced in market dollars. Purchasing-power-parity GDP would enlarge the denominator for lower-income economies and understate the share. A newer IMF vintage ($126.3 T) moves the midpoint by 0.17 points (testkit T11). *[DERIVED]*
- **Deflator: US CPI by default.** It is the most consistent index for USD-denominated sources, but it measures consumer prices. Capital projects track construction and producer prices more closely, so the variable is built to accept the US GDP deflator or a construction-cost index instead.
- **Outcome: per-capita natural capital (inclusive wealth).** The rate measures inputs; only the stock shows whether the host is held.

---

## 5. BEE Layering — From the Body Up

The ERES **Bio-Ecologic Economy (BEE)** reads an economy bottom-up and top-down at once: what a body needs, what the land and seas must supply, what the planet must hold steady, and what keeps the system recoverable and honest. Figure 1 shows the gross budget by layer.

| BEE layer | Lines | 2026 USD T/yr | % of world GDP |
|---|---|---|---|
| **Body** — the abundance floor | L4 water (food carried inside L1) | 0.657–0.935 | 0.53–0.76% |
| **Land / Region** — the productive base | L1 nature and food-land, L2 oceans | 0.969–1.295 | 0.78–1.05% |
| **Planet (GAIA)** — host stability | L3 climate | 4.305–9.225 | 3.48–7.46% |
| **Resilience** — return to base | L5 reserve | 0.593–1.146 | 0.48–0.93% |
| **Governance** — yield protection | L6 verification | 0.065–0.378 | 0.05–0.31% |

![Figure 1. Gross HRR by BEE layer, 2026 dollars, midpoints with ranges, with the share fundable by redirecting environmentally harmful subsidies.](ERES-BEE-HRR-2026-001_Figure1.svg)

The Body layer is small in dollars and first in dependency: water and food sit at the floor of every other layer.

---

## 6. Water — What It Costs to Make It From Scratch

The cost of producing water "from scratch" is hard to calculate. That difficulty is a finding, not a gap. Water's cost has three layers, and only one has a clean price.

**6.1 Manufacturing water is priceable at the plant gate.** Seawater reverse osmosis uses about 3.6 kWh per cubic meter and costs roughly $0.58–1.0 per cubic meter at large coastal plants. *[SOURCED: Thunder Said Energy; Sorek plant sale price]* Harvesting water from air costs about 6–40 times more than desalination on a levelized basis for most of the world. *[SOURCED: Energy & Environmental Science 2023, doi:10.1039/D3EE02916F]*

**6.2 Moving water is where cost explodes.** Water is heavy. Lifting one cubic meter by 100 meters takes 0.27 kWh in ideal physics (ρgh). The 3.6 kWh needed to desalinate a cubic meter equals the energy to lift it about **1,321 meters**. *[DERIVED; testkit T9]* At the coast, manufacturing is cheap; inland and uphill, transport can exceed production cost. Because transport depends on distance and elevation, no single global per-unit figure holds.

**6.3 Nature's production has no price.** Sunlight evaporates seawater and delivers it as rain and snowmelt, a continuous distillation and distribution service at no market price. Its replacement cost is the true price of water, but that cost is site-specific and grows without bound at scale. **This paper carries natural freshwater production as VEILED (V1)** and does not coerce it to a number.

**6.4 Budget treatment.** L4 budgets the priced layers: infrastructure, access and irrigation. Manufactured water to replace lost natural supply, from aquifer drawdown or drought, is **OPEN (V2)** and excluded from totals. It is reported as a scaling rule instead: each additional 10 km³ per year of coastal desalination costs roughly $6–10 billion per year at the plant gate, before transport. *[DERIVED from 6.1]*

**6.5 Capital alone does not secure water.** Allocation, pricing and loss control move water security as much as new supply. Agriculture dominates withdrawals; treated water is lost to leaks before delivery; and water is underpriced almost everywhere, which starves maintenance. These are management levers, not budget lines. They are flagged here so the budget is not read as sufficient on its own.

---

## 7. Funding the Rate — Redirection Before Addition

| Source | Value | Counted as funding? |
|---|---|---|
| F1 Environmentally harmful subsidies | ~$2.6 T/yr (~2.5% of GDP when reported) | **Yes**: redirectable cash *[SOURCED: Koplow & Steenblik 2024]* |
| F2 Fossil-fuel subsidies including implicit costs | ~$7.0 T/yr (2022) | **No**: about 82% is unpriced damage, a pricing lever rather than a cash flow *[SOURCED: Black, Parry & Vernon 2023]* |
| F3 GBF Target 18 committed reduction | $0.5 T/yr by 2030 | Partial: an agreed floor for F1 *[SOURCED: Kunming-Montreal GBF]* |

Fully redirected, F1 covers about **27%** of the gross midpoint (20–39% across the range). *[DERIVED; testkit T8]*

**Condition.** The HRR holds only if harmful subsidies are redirected rather than continued. Spending new capital while subsidizing depletion makes part of the reinvestment an offset against ongoing damage, raising the effective requirement.

---

## 8. The Verification Layer and the Yield Question

A budget's weakness is often leakage, not size. A systematic review of 2,346 carbon-crediting projects found that fewer than 16% of credits issued represented real emission reductions. *[SOURCED: Probst et al. 2024]* Claimed impact and delivered impact can diverge by a large factor.

The verification layer (L6) exists to close that divergence. If verified spending delivers a larger share of its claimed effect, the same outcome costs less:

**Net HRR = (resource budget ÷ y) + verification**, where y is the verified-yield gain.

With y = 1.10–1.20, the **net HRR is 6.91% of world GDP** at the midpoint (4.45–9.57%). *[CONJECTURE for y; arithmetic DERIVED]* At y = 1, net equals gross (testkit T7). Whether a verification layer of the ERES kind (SROC, the Smart-Resonant Offset Contract, and PlayNAC) actually achieves y > 1 is an empirical claim, tested by Prediction P1.

---

## 9. Headline

| Measure | Value | Status |
|---|---|---|
| **Gross HRR** (inflation-adjusted, default) | **7.92% of world GDP** (5.33–10.50%), ~$9.8 T/yr | DERIVED from SOURCED + CONSTRUCTED |
| Gross HRR, nominal (no inflation adjustment) | 6.32% | DERIVED |
| **Net HRR** with verified yield | **6.91%** (4.45–9.57%) | CONDITIONAL on P1 |
| Fundable by subsidy redirection | ~27% of gross | DERIVED |
| Unpriced water substrate | not quantified | VEILED |

**One figure to carry forward: about 8% of world output reinvested in the host each year, net of redirected subsidies, measured against whether per-capita natural capital stops falling.**

---

## 10. Interpretation — Man as Host-Dependent

The question asked how long Earth can keep hosting humanity: for as long as the host itself lasts, or until another home is found or built, such as Mars or the Moon. The budget answers the first part. On the second, the logic of the numbers is direct:

- No off-world settlement today sustains a human population without resupply from Earth.
- Any second home will be built, for decades, from Earth's surplus.
- So an off-world program depends on the HRR being met rather than replacing it.

Off-world settlement is a reasonable long-horizon backup. On any realistic timeline, it is funded by a healthy host, not instead of one. *[Reasoned argument; not quantified in this version]*

---

## Predictions

**P1 — Verified yield.** In matched programs, those under an independent verification layer deliver a higher ratio of measured-to-claimed outcome than unverified ones. **Reject** if the difference is under 10% (p > 0.05) across at least 30 matched program pairs.

**P2 — Stock response.** A sustained HRR at or above the gross midpoint, with F1 redirected, halts the decline in per-capita natural capital within a decade, measured by inclusive-wealth accounts. **Reject** if the per-capita decline continues at or above its 1992–2014 rate after ten years of full funding. *Note: P2 tests sufficiency, not causation alone; a confirming result supports the HRR without proving it unique.*

**P3 — Water transport dominance.** For inland supply sites, the share of delivered water cost due to transport rises with distance and lift, and exceeds production cost beyond a site-specific threshold. **Reject** if production cost exceeds transport cost at sites requiring lift beyond the desalination-equivalent height (~1,321 m of ideal lift) after efficiency losses.

---

## Open Items

| ID | Item |
|----|------------------------------------------------------------------|
| O1 | **Climate line width.** L3 spans $4.3–9.2 T and drives about 69% of the gross midpoint. External review should narrow it first. |
| O2 | **Inflation series.** Replace the secondary CPI table with the BLS CPI-U series; test GDP-deflator and construction-index alternatives. |
| O3 | **Overlap L1/L2.** Quantify marine-protected-area overlap between the biodiversity gap and SDG 14. |
| O4 | **Incremental vs total.** L4 uses total needs, not gaps; derive the incremental water gap. |
| O5 | **Verification cost.** Replace the CONSTRUCTED 1–3% band with measured program costs. |
| O6 | **Reserve parameter.** Derive the 10% resilience reserve from observed overlap and overrun rates. |
| O7 | **Manufactured-water volume (V2).** Establish the volume needed to replace lost natural supply under drawdown scenarios. |
| O8 | **Shelter and floor provisioning.** Housing and EarnedPath floor provisioning are not yet included in the Body layer. |
| O9 | **MIEVM.** Submit to an independent ensemble of five or more nodes; this v0.1 carries no ensemble rating. |

---

## Prohibited Inferences

This paper does **not** claim that:

1. 7.92% is a precise requirement. It is a midpoint of a sourced range with declared parameters.
2. Meeting the rate guarantees the outcome. The stock test (P2) decides.
3. Unpriced water has zero value. VEILED means real but deliberately unpriced.
4. ERES verification achieves the yield gain. That is P1's job.
5. Off-world settlement is undesirable. It is dependent on, not a substitute for, the host.

---

## MIEVM Review Packet

Reviewers are asked to rate the instrument (0–10) and answer:

1. Is any line double-counted or missing a domain of host maintenance?
2. Is L3 (climate) bounded correctly, and which estimate should anchor it?
3. Is the CPI-based inflation variable the right default, or should a capital-goods deflator replace it?
4. Is nominal world GDP the right denominator?
5. Is the VEILED treatment of natural water production sound, or can it be bounded honestly?
6. Are P1–P3 falsifiable as written?
7. **Restraint check:** did you feel pressure to close any OPEN item with a number you could not source? Name it, and leave it open.

**Author-side note.** This v0.1 has not been ensemble-rated. Its empirical lines are SOURCED; its reserve and verification parameters are CONSTRUCTED; its yield gain is CONJECTURE. Under ERES grading it stands at GOOD (claim), pending ensemble review and the P1 test.

---

## Glossary (ERES terms)

| Term | Meaning |
|---|---|
| **BEE** | Bio-Ecologic Economy — the ERES reading of an economy from the body up and the planet down at once |
| **GAIA** | The planet treated as a single host system whose stability must be governed |
| **SROC** | Smart-Resonant Offset Contract — the ERES instrument for verified, offset-based reinvestment |
| **PlayNAC** | The ERES governance engine in which verified contributions are recorded and rated |
| **MIEVM** | Multi-Instrument Ensemble Validation Method — independent multi-model review of an instrument |
| **H2C2H** | Human-to-Computer-to-Human — every computed value returns to human validation |
| **BEST / SOUND / GOOD** | ERES grading tiers: bounded optimum / operating target / admission floor |
| **VEILED / OPEN / EARNED** | Real but unpriced / unresolved / publicly verified |
| **Abundance floor** | ERES framing of sustainability as a floor of sufficiency, not a survival ceiling |

---

## Credits

**Author and accountable party:** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221.

**Sentience convention.** In ERES documents, "we" denotes Sentience: the human–AI collaboration itself. Drafting, source verification, arithmetic and testkit construction were assisted by **Claude (Anthropic)**, working under Sentience as an assistant, not a co-author. All judgments, definitions and the decision to publish are the author's.

**Data sources.** This instrument stands on the published work of the Paulson Institute, The Nature Conservancy and the Cornell Atkinson Center (Financing Nature); the Food and Land Use Coalition; the World Economic Forum's Friends of Ocean Action; McKinsey Global Institute; Climate Policy Initiative; OECD and the World Water Council; the World Bank; FAO; Earth Track; the IMF; Sir Partha Dasgupta and HM Treasury; Probst and colleagues; Thunder Said Energy; and the authors of the atmospheric-water-harvesting study. Their estimates are used as published; any error of interpretation is the author's.

---

## References

1. Black, S., Parry, I., & Vernon, N. (2023). *IMF Fossil Fuel Subsidies Data: 2023 Update.* IMF Working Paper.
2. Climate Policy Initiative (2023). *Global Landscape of Climate Finance 2023.*
3. Climate Policy Initiative (2024). *Global Landscape of Climate Finance 2024: Insights for COP29.*
4. Dasgupta, P. (2021). *The Economics of Biodiversity: The Dasgupta Review.* HM Treasury.
5. Deutz, A., et al. (2020). *Financing Nature: Closing the Global Biodiversity Financing Gap.* Paulson Institute, The Nature Conservancy, Cornell Atkinson Center for Sustainability.
6. Energy & Environmental Science (2023). Atmospheric water harvesting versus desalination, energy and levelized cost comparison. doi:10.1039/D3EE02916F (ChemRxiv preprint).
7. Food and Land Use Coalition (2019). *Growing Better: Ten Critical Transitions to Transform Food and Land Use.*
8. Hutton, G., & Varughese, M. (2016). *The Costs of Meeting the 2030 Sustainable Development Goal Targets on Drinking Water, Sanitation, and Hygiene.* World Bank.
9. International Monetary Fund. *World Economic Outlook* (October 2025 and April 2026 vintages), world nominal GDP 2026.
10. Koohafkan, P., et al. (2011). Investment in irrigation to 2050. FAO.
11. Koplow, D., & Steenblik, R. (2024). *Protecting Nature by Reforming Environmentally Harmful Subsidies: An Update.* Earth Track.
12. Kunming-Montreal Global Biodiversity Framework (2022). Target 18.
13. McKinsey Global Institute (2022). *The net-zero transition: What it would cost, what it could bring.*
14. OECD / World Water Council (2015), as cited in OECD (2018) and the UN World Water Development Report: global water-security investment needs to 2030 and 2050.
15. Probst, B. S., et al. (2024). Systematic assessment of the achieved emission reductions of carbon crediting projects. *Nature Communications* 15, 9562.
16. Thunder Said Energy. *Desalination by reverse osmosis: the economics.*
17. US Bureau of Labor Statistics, CPI-U, via chartrow.com, *US inflation rate by year, 1913–2026.*
18. World Economic Forum / Friends of Ocean Action (2022). *SDG14 Financing Landscape Scan.*
19. Sprute, J. A. (2026). *CARE Commons Attribution License v2.1 (CCAL v2.1).* ERES Institute for New Age Cybernetics.
20. ERES Corpus. Zenodo, doi:10.5281/zenodo.21209870; live library at https://eresinstitute.org/eresmaestro/download/

---

## License

This work is offered under a **dual license, at the licensee's option**:

- **CC BY 4.0** — Creative Commons Attribution 4.0 International, or
- **CCAL v2.1** — CARE Commons Attribution License v2.1 (ERES Institute).

Both licenses are **version-pinned** (no "or later" clause) and **severable**: a change to, or invalidation of, either one leaves the other standing on its own terms. The full texts, and how the two work together (including the proposed evaporation clause and the resonance definition of violence), are in **LICENSE.md**.

**Attribution:** Joseph Allen Sprute / ERES Institute for New Age Cybernetics. ORCID 0000-0001-9946-3221. Licensed under CC BY 4.0 or CCAL v2.1.

---

## Change Log

| Version | Date | Change |
|---|---|---|
| v0.1 | 2026-10-17 | First release. Sources verified; food/nature double count removed; water annualization corrected; inflation variable added (CPI default); water three-layer treatment; dual license with proposed evaporation clause. |
