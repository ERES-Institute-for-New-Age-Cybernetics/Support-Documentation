# LICENSE — ERES-BEE-HRR-2026-001

**The Host Reinvestment Rate (HRR), v0.1** · Joseph Allen Sprute / ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221

This work, including the whitepaper, data file, figure, testkit and all package files, is offered under a **dual license, at the licensee's option**:

- **Part A — Creative Commons Attribution 4.0 International (CC BY 4.0)**, or
- **Part B — CARE Commons Attribution License v2.1 (CCAL v2.1).**

**Part C** explains how the two work together: independence, severability, the author's stated intent, and the proposed (peer-review) evaporation clause.

---

## Part A — Creative Commons Attribution 4.0 International (CC BY 4.0)

*Official legal code, reproduced verbatim from the SPDX License List (identifier `CC-BY-4.0`). Canonical source: https://creativecommons.org/licenses/by/4.0/legalcode*

```text
Creative Commons Attribution 4.0 International

 Creative Commons Corporation (“Creative Commons”) is not a law firm and does not provide legal services or legal advice. Distribution of Creative Commons public licenses does not create a lawyer-client or other relationship. Creative Commons makes its licenses and related information available on an “as-is” basis. Creative Commons gives no warranties regarding its licenses, any material licensed under their terms and conditions, or any related information. Creative Commons disclaims all liability for damages resulting from their use to the fullest extent possible.

Using Creative Commons Public Licenses

Creative Commons public licenses provide a standard set of terms and conditions that creators and other rights holders may use to share original works of authorship and other material subject to copyright and certain other rights specified in the public license below. The following considerations are for informational purposes only, are not exhaustive, and do not form part of our licenses.

Considerations for licensors: Our public licenses are intended for use by those authorized to give the public permission to use material in ways otherwise restricted by copyright and certain other rights. Our licenses are irrevocable. Licensors should read and understand the terms and conditions of the license they choose before applying it. Licensors should also secure all rights necessary before applying our licenses so that the public can reuse the material as expected. Licensors should clearly mark any material not subject to the license. This includes other CC-licensed material, or material used under an exception or limitation to copyright. More considerations for licensors.

Considerations for the public: By using one of our public licenses, a licensor grants the public permission to use the licensed material under specified terms and conditions. If the licensor’s permission is not necessary for any reason–for example, because of any applicable exception or limitation to copyright–then that use is not regulated by the license. Our licenses grant only permissions under copyright and certain other rights that a licensor has authority to grant. Use of the licensed material may still be restricted for other reasons, including because others have copyright or other rights in the material. A licensor may make special requests, such as asking that all changes be marked or described. Although not required by our licenses, you are encouraged to respect those requests where reasonable. More considerations for the public.

Creative Commons Attribution 4.0 International Public License

By exercising the Licensed Rights (defined below), You accept and agree to be bound by the terms and conditions of this Creative Commons Attribution 4.0 International Public License ("Public License"). To the extent this Public License may be interpreted as a contract, You are granted the Licensed Rights in consideration of Your acceptance of these terms and conditions, and the Licensor grants You such rights in consideration of benefits the Licensor receives from making the Licensed Material available under these terms and conditions.

Section 1 – Definitions.

     a.	Adapted Material means material subject to Copyright and Similar Rights that is derived from or based upon the Licensed Material and in which the Licensed Material is translated, altered, arranged, transformed, or otherwise modified in a manner requiring permission under the Copyright and Similar Rights held by the Licensor. For purposes of this Public License, where the Licensed Material is a musical work, performance, or sound recording, Adapted Material is always produced where the Licensed Material is synched in timed relation with a moving image.

     b.	Adapter's License means the license You apply to Your Copyright and Similar Rights in Your contributions to Adapted Material in accordance with the terms and conditions of this Public License.

     c.	Copyright and Similar Rights means copyright and/or similar rights closely related to copyright including, without limitation, performance, broadcast, sound recording, and Sui Generis Database Rights, without regard to how the rights are labeled or categorized. For purposes of this Public License, the rights specified in Section 2(b)(1)-(2) are not Copyright and Similar Rights.

     d.	Effective Technological Measures means those measures that, in the absence of proper authority, may not be circumvented under laws fulfilling obligations under Article 11 of the WIPO Copyright Treaty adopted on December 20, 1996, and/or similar international agreements.

     e.	Exceptions and Limitations means fair use, fair dealing, and/or any other exception or limitation to Copyright and Similar Rights that applies to Your use of the Licensed Material.

     f.	Licensed Material means the artistic or literary work, database, or other material to which the Licensor applied this Public License.

     g.	Licensed Rights means the rights granted to You subject to the terms and conditions of this Public License, which are limited to all Copyright and Similar Rights that apply to Your use of the Licensed Material and that the Licensor has authority to license.

     h.	Licensor means the individual(s) or entity(ies) granting rights under this Public License.

     i.	Share means to provide material to the public by any means or process that requires permission under the Licensed Rights, such as reproduction, public display, public performance, distribution, dissemination, communication, or importation, and to make material available to the public including in ways that members of the public may access the material from a place and at a time individually chosen by them.

     j.	Sui Generis Database Rights means rights other than copyright resulting from Directive 96/9/EC of the European Parliament and of the Council of 11 March 1996 on the legal protection of databases, as amended and/or succeeded, as well as other essentially equivalent rights anywhere in the world.

     k.	You means the individual or entity exercising the Licensed Rights under this Public License. Your has a corresponding meaning.

Section 2 – Scope.

     a.	License grant.

          1. Subject to the terms and conditions of this Public License, the Licensor hereby grants You a worldwide, royalty-free, non-sublicensable, non-exclusive, irrevocable license to exercise the Licensed Rights in the Licensed Material to:

               A. reproduce and Share the Licensed Material, in whole or in part; and

               B. produce, reproduce, and Share Adapted Material.

          2. Exceptions and Limitations. For the avoidance of doubt, where Exceptions and Limitations apply to Your use, this Public License does not apply, and You do not need to comply with its terms and conditions.

          3. Term. The term of this Public License is specified in Section 6(a).

          4. Media and formats; technical modifications allowed. The Licensor authorizes You to exercise the Licensed Rights in all media and formats whether now known or hereafter created, and to make technical modifications necessary to do so. The Licensor waives and/or agrees not to assert any right or authority to forbid You from making technical modifications necessary to exercise the Licensed Rights, including technical modifications necessary to circumvent Effective Technological Measures. For purposes of this Public License, simply making modifications authorized by this Section 2(a)(4) never produces Adapted Material.

          5. Downstream recipients.

               A. Offer from the Licensor – Licensed Material. Every recipient of the Licensed Material automatically receives an offer from the Licensor to exercise the Licensed Rights under the terms and conditions of this Public License.

               B. No downstream restrictions. You may not offer or impose any additional or different terms or conditions on, or apply any Effective Technological Measures to, the Licensed Material if doing so restricts exercise of the Licensed Rights by any recipient of the Licensed Material.

          6.  No endorsement. Nothing in this Public License constitutes or may be construed as permission to assert or imply that You are, or that Your use of the Licensed Material is, connected with, or sponsored, endorsed, or granted official status by, the Licensor or others designated to receive attribution as provided in Section 3(a)(1)(A)(i).

b. Other rights.

          1. Moral rights, such as the right of integrity, are not licensed under this Public License, nor are publicity, privacy, and/or other similar personality rights; however, to the extent possible, the Licensor waives and/or agrees not to assert any such rights held by the Licensor to the limited extent necessary to allow You to exercise the Licensed Rights, but not otherwise.

          2. Patent and trademark rights are not licensed under this Public License.

          3. To the extent possible, the Licensor waives any right to collect royalties from You for the exercise of the Licensed Rights, whether directly or through a collecting society under any voluntary or waivable statutory or compulsory licensing scheme. In all other cases the Licensor expressly reserves any right to collect such royalties.

Section 3 – License Conditions.

Your exercise of the Licensed Rights is expressly made subject to the following conditions.

     a.	Attribution.

          1. If You Share the Licensed Material (including in modified form), You must:

               A. retain the following if it is supplied by the Licensor with the Licensed Material:

                    i. identification of the creator(s) of the Licensed Material and any others designated to receive attribution, in any reasonable manner requested by the Licensor (including by pseudonym if designated);

                    ii. a copyright notice;

                    iii. a notice that refers to this Public License;

                    iv.	a notice that refers to the disclaimer of warranties;

                    v. a URI or hyperlink to the Licensed Material to the extent reasonably practicable;

               B. indicate if You modified the Licensed Material and retain an indication of any previous modifications; and

               C. indicate the Licensed Material is licensed under this Public License, and include the text of, or the URI or hyperlink to, this Public License.

          2. You may satisfy the conditions in Section 3(a)(1) in any reasonable manner based on the medium, means, and context in which You Share the Licensed Material. For example, it may be reasonable to satisfy the conditions by providing a URI or hyperlink to a resource that includes the required information.

          3. If requested by the Licensor, You must remove any of the information required by Section 3(a)(1)(A) to the extent reasonably practicable.

          4. If You Share Adapted Material You produce, the Adapter's License You apply must not prevent recipients of the Adapted Material from complying with this Public License.

Section 4 – Sui Generis Database Rights.

Where the Licensed Rights include Sui Generis Database Rights that apply to Your use of the Licensed Material:

     a.	for the avoidance of doubt, Section 2(a)(1) grants You the right to extract, reuse, reproduce, and Share all or a substantial portion of the contents of the database;

     b.	if You include all or a substantial portion of the database contents in a database in which You have Sui Generis Database Rights, then the database in which You have Sui Generis Database Rights (but not its individual contents) is Adapted Material; and

     c.	You must comply with the conditions in Section 3(a) if You Share all or a substantial portion of the contents of the database.
For the avoidance of doubt, this Section 4 supplements and does not replace Your obligations under this Public License where the Licensed Rights include other Copyright and Similar Rights.

Section 5 – Disclaimer of Warranties and Limitation of Liability.

     a.	Unless otherwise separately undertaken by the Licensor, to the extent possible, the Licensor offers the Licensed Material as-is and as-available, and makes no representations or warranties of any kind concerning the Licensed Material, whether express, implied, statutory, or other. This includes, without limitation, warranties of title, merchantability, fitness for a particular purpose, non-infringement, absence of latent or other defects, accuracy, or the presence or absence of errors, whether or not known or discoverable. Where disclaimers of warranties are not allowed in full or in part, this disclaimer may not apply to You.

     b.	To the extent possible, in no event will the Licensor be liable to You on any legal theory (including, without limitation, negligence) or otherwise for any direct, special, indirect, incidental, consequential, punitive, exemplary, or other losses, costs, expenses, or damages arising out of this Public License or use of the Licensed Material, even if the Licensor has been advised of the possibility of such losses, costs, expenses, or damages. Where a limitation of liability is not allowed in full or in part, this limitation may not apply to You.

     c.	The disclaimer of warranties and limitation of liability provided above shall be interpreted in a manner that, to the extent possible, most closely approximates an absolute disclaimer and waiver of all liability.

Section 6 – Term and Termination.

     a.	This Public License applies for the term of the Copyright and Similar Rights licensed here. However, if You fail to comply with this Public License, then Your rights under this Public License terminate automatically.

     b.	Where Your right to use the Licensed Material has terminated under Section 6(a), it reinstates:

          1. automatically as of the date the violation is cured, provided it is cured within 30 days of Your discovery of the violation; or

          2. upon express reinstatement by the Licensor.

     c.	For the avoidance of doubt, this Section 6(b) does not affect any right the Licensor may have to seek remedies for Your violations of this Public License.

     d.	For the avoidance of doubt, the Licensor may also offer the Licensed Material under separate terms or conditions or stop distributing the Licensed Material at any time; however, doing so will not terminate this Public License.

     e.	Sections 1, 5, 6, 7, and 8 survive termination of this Public License.

Section 7 – Other Terms and Conditions.

     a.	The Licensor shall not be bound by any additional or different terms or conditions communicated by You unless expressly agreed.

     b.	Any arrangements, understandings, or agreements regarding the Licensed Material not stated herein are separate from and independent of the terms and conditions of this Public License.

Section 8 – Interpretation.

     a.	For the avoidance of doubt, this Public License does not, and shall not be interpreted to, reduce, limit, restrict, or impose conditions on any use of the Licensed Material that could lawfully be made without permission under this Public License.

     b.	To the extent possible, if any provision of this Public License is deemed unenforceable, it shall be automatically reformed to the minimum extent necessary to make it enforceable. If the provision cannot be reformed, it shall be severed from this Public License without affecting the enforceability of the remaining terms and conditions.

     c.	No term or condition of this Public License will be waived and no failure to comply consented to unless expressly agreed to by the Licensor.

     d.	Nothing in this Public License constitutes or may be interpreted as a limitation upon, or waiver of, any privileges and immunities that apply to the Licensor or You, including from the legal processes of any jurisdiction or authority.

Creative Commons is not a party to its public licenses. Notwithstanding, Creative Commons may elect to apply one of its public licenses to material it publishes and in those instances will be considered the “Licensor.” Except for the limited purpose of indicating that material is shared under a Creative Commons public license or as otherwise permitted by the Creative Commons policies published at creativecommons.org/policies, Creative Commons does not authorize the use of the trademark “Creative Commons” or any other trademark or logo of Creative Commons without its prior written consent including, without limitation, in connection with any unauthorized modifications to any of its public licenses or any other arrangements, understandings, or agreements concerning use of licensed material. For the avoidance of doubt, this paragraph does not form part of the public licenses.

Creative Commons may be contacted at creativecommons.org.
```

---

## Part B — CARE Commons Attribution License v2.1 (CCAL v2.1)

*Reproduced verbatim from the author's file `CCAL_v2.1_LICENSE.md.pdf` (included in this package as the reference copy). Line breaks have been reflowed for Markdown; wording is unchanged. Under its own Section 13, a Zenodo deposit of CCAL v2.1, once assigned a DOI, governs over any mirror, including this one.*

---

# CARE Commons Attribution License v2.1 (CCAL v2.1)

**Version:** 2.1 **Effective Date:** April 26, 2026 **Steward:** ERES Institute for New Age Cybernetics
**Author of Record:** Joseph Allen Sprute (ORCID: 0000-0001-9946-3221) **Successor to:** CCAL v2.0 (2024), CCAL v1.0 (2012) **Compatibility Statement:** Functionally compatible with Creative Commons Attribution 4.0 International (CC-BY 4.0) in its attribution requirements; adds provisions specific to the ERES corpus governing the continuity of attribution across derivative works, ensemble-validated outputs, and long-horizon governance instruments.

## Preamble

The CARE Commons Attribution License v2.1 ("CCAL v2.1" or "this License") is the governing open-licensing framework for works produced by, deposited within, or derived from the ERES Institute for New Age Cybernetics ("the Institute"). The Institute is an independent research body established in February 2012 in Bella Vista, Arkansas; it is not constituted as a business. Its outputs include peer-reviewed publications, architectural specifications, governance instruments, simulation environments, attestation protocols, and educational materials, accumulated over fourteen years and continuing.

CCAL v2.1 exists because the works it covers are intended to function as civilizational infrastructure on multi-generational timescales. Standard licenses optimized for software, prose, or media each cover part of what is needed, but none alone covers the full surface: durable attribution across ensemble-validated outputs; non-enclosure of derivative governance instruments; alignment with the Three Governing Principles; protection of good-faith use; and a defensible posture against extractive use at planetary cost.

This License grants broad freedoms to share, adapt, study, teach, build upon, and commercialize services around the covered works. In exchange, the License asks that you keep attribution intact, leave the commons more open than you found it, and act in conformity with the Three Governing Principles. Nothing more is asked. Nothing less is sufficient.

## Definitions

For the purposes of this License:

"Work" means any text, image, data, source code, schematic, specification, recording, model output, derivative composition, or other expression to which this License has been applied by the Author or by the Institute.

"Author" means Joseph Allen Sprute and any co-authors named in the Work, acting under the auspices of the Institute.

"Institute" means the ERES Institute for New Age Cybernetics, the License Steward and the source institution for the corpus.

"Licensee" means any natural or legal person who exercises any right granted under this License.

"Adaptation" / "Derivative Work" means a work derived from, translated from, transformed from, or built upon the Work, including ensemble-validated outputs that incorporate the Work as a substantive input.

"Three Governing Principles" means the three rules upon which CCAL v2.1 rests, stated in their exact and locked form:

1. Don't hurt yourself.
2. Don't hurt others.
3. Build for generations to come.

"Care Clause" means the operative requirement, set forth in Section 2 below, that all use of the Work conform to the Three Governing Principles.

"Grace Protocol" means the Institute's stated commitment to shield good-faith licensees acting in conformity with the Care Clause from retaliatory enforcement.

"Earth-First Constraint" means the requirement, set forth in Section 3 below, that the Work be used in service of planetary integrity rather than in service of extractive, sectarian, or self-only logic at planetary cost.

## Grant of Rights

Subject to the Conditions set forth in Sections 1 through 8 below, the Institute hereby grants to every Licensee a worldwide, royalty-free, non-exclusive, perpetual (for the duration of applicable copyright) license to:

- **Share** — reproduce the Work, in whole or in part, in any medium or format.
- **Adapt** — translate, transform, remix, and build upon the Work for any purpose, including commercial purposes.
- **Cite and Quote** — quote, cite, paraphrase, and reference the Work in academic, journalistic, governmental, and enterprise contexts.
- **Implement** — implement the architectures, protocols, and methods described in the Work in software, hardware, governance, or institutional form.
- **Distribute Derivative Works** — distribute Adaptations and Derivative Works under the conditions of Section 5 (Share-Forward).
- **Charge for Services** — offer paid services, implementation, training, consulting, or support based on the Work, provided that the Work itself remains freely available under this License.

These rights are granted to all Licensees on equal terms. No additional permission, royalty payment, or registration is required.

## Conditions of the License

The grant above is conditioned on continuing observance of the following.

### 1. Attribution (Required)

Every public use, redistribution, or Adaptation of the Work must include the following attribution, in a form reasonable to the medium:

> Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1.

Where space permits, attribution should additionally include the ORCID identifier ( 0000-0001-9946-3221 ) and a link to the License text. Where space is severely limited (social media, headers, footers), the shortened form "JAS / ERES — CCAL v2.1" is acceptable.

Attribution must be continuous: Adaptations and Derivative Works carry forward the original attribution alongside any attribution to the adapter. Removal of upstream attribution is a license violation.

### 2. Care Clause — The Three Governing Principles

All use of the Work must conform to the Three Governing Principles:

1. Don't hurt yourself.
2. Don't hurt others.
3. Build for generations to come.

Use that violates the Care Clause — including use to facilitate self-harm, harm to third parties, or the foreclosure of options for future generations — is outside the scope of the License grant. Such use is not licensed and constitutes infringement.

The Care Clause is not a guideline. It is an operative condition of the grant.

### 3. Earth-First Constraint

Use of the Work must serve planetary integrity. Use that serves self-only logic, sectarian logic, or extractive logic at planetary cost is outside the scope of the License grant.

In its canonical ERES formulation: Use must serve the One Master (FEE_MALE == Semantic === Earth First). In plain operational terms: where a use would foreseeably degrade planetary life-support systems, biospheric integrity, or the conditions for multi-generational human flourishing, that use is not licensed regardless of any other apparent compliance with this License.

### 4. Transparency

Adaptations and Derivative Works that are publicly distributed must:

- Clearly mark what has been changed relative to the source Work;
- Document material modifications in a form discoverable by downstream Licensees (a CHANGELOG, version history, or equivalent);
- Make the source materials of the Adaptation publicly available where doing so is feasible and consistent with the Adaptation's lawful purpose.

### 5. Share-Forward (Share-Alike)

Adaptations and Derivative Works that are publicly distributed must be released under this License (CCAL v2.1) or a Compatible License as defined in Section 11. The terms of this License — including Attribution, the Care Clause, the Earth-First Constraint, Transparency, Share-Forward, Non-Enclosure, Patent Non-Assertion, and the Grace Provision — must propagate to Adaptations and Derivative Works.

No party may use this License to establish proprietary enclosure over a Derivative Work, nor to restrict downstream Licensees' access to the same Work or its derivatives.

### 6. Non-Enclosure

No Licensee may take any action — including but not limited to assertion of trademark, patent, contractual lock-in, technical protection measures (DRM), or platform-exclusive distribution — that has the effect of enclosing the Work or its derivatives such that other Licensees cannot exercise the rights granted in this License.

This Condition does not prohibit charging for services (which is expressly permitted under the Grant of Rights), nor does it prohibit the creation of proprietary tools that interface with CCAL-licensed systems (APIs, plugins, integrations). It prohibits enclosure of the underlying Work itself.

### 7. Patent Non-Assertion

By exercising rights under this License, Licensee agrees:

- Not to assert patent claims against any party using the Work as licensed;
- To grant a royalty-free, worldwide, non-exclusive patent license to any patents Licensee holds that are necessarily infringed by implementations of the Work, for the purpose of those implementations;
- To contribute patent improvements that build on the Work back to the commons under this License or a Compatible License.

**Defensive Termination.** If Licensee initiates patent litigation against any party alleging that the Work, or any implementation of the Work, infringes Licensee's patents, then Licensee's rights under this License terminate automatically on the date such litigation is filed.

### 8. Grace Provision

Good-faith use of the Work, by a Licensee acting in conformity with the Care Clause and the Earth-First Constraint, is shielded from retaliatory enforcement by the Institute. The Grace Protocol's Anti-Retaliation Shield extends to such Licensees.

Good faith is presumed unless a clear pattern of bad-faith conduct is established. A Licensee who has made a reasonable effort to comply, who corrects deficiencies on notice, and whose use is not extractive or harmful, is shielded.

## Disclaimers

### 9. No Warranty

The Work is provided "AS IS," without warranty of any kind, express or implied. The Institute and the Author make no representations:

- That the Work is fit for any particular purpose;
- That the Work is free of errors, omissions, or inaccuracies;
- That implementations of the Work will achieve any specific outcome;
- That the Work does not infringe any third party's rights (though the Author warrants original authorship to the best of their knowledge);
- That ongoing support, updates, or maintenance will be provided.

The Institute commits in good faith to correct identified errors and to publish updates via its public channels (GitHub, ResearchGate, pCloud, and Zenodo), but no such commitment is enforceable as a warranty.

### 10. Limitation of Liability

To the maximum extent permitted by applicable law, neither the Institute nor the Author shall be liable for any direct, indirect, incidental, consequential, special, or exemplary damages arising from the Licensee's use of the Work, regardless of the theory of liability.

## Administration

### 11. Termination and Reinstatement

A Licensee's rights under this License terminate automatically upon material violation, including:

- Failure to comply with the Attribution requirement (Section 1);
- Violation of the Care Clause (Section 2);
- Violation of the Earth-First Constraint (Section 3);
- Failure of Transparency for publicly distributed Adaptations (Section 4);
- Breach of Share-Forward (Section 5);
- Enclosure of the Work or its derivatives (Section 6);
- Initiation of patent litigation against a Licensee (Section 7);
- Unauthorized use of the ERES Institute name or marks in a manner suggesting endorsement of a work the Institute has not endorsed.

**Reinstatement.** Where the violation is cured within thirty (30) days of the Licensee receiving notice of the violation, the License is automatically reinstated for that Licensee. A second material violation by the same Licensee may, at the Institute's discretion, result in permanent termination. Intentional, malicious, or extractive violations are not subject to automatic reinstatement.

Termination of one Licensee's rights does not affect the rights of any other Licensee acting in good faith.

### 12. Compatibility

This License is compatible with (i.e., a Derivative Work may be released under) the following licenses, which carry equivalent or stronger commitments to attribution and the commons:

- Creative Commons Attribution 4.0 International (CC-BY 4.0)
- Creative Commons Attribution-ShareAlike 4.0 International (CC-BY-SA 4.0)
- GNU Free Documentation License (GFDL)
- Open Publication License
- Academic Free License v3.0
- MIT License (for source code components)
- Apache License 2.0 (for source code components)
- Open Data Commons Attribution License (ODC-BY) (for datasets)
- CERN Open Hardware License v2 Strongly Reciprocal (CERN-OHL-S v2) (for hardware schematics)

This License is incompatible with (i.e., a Derivative Work may not be released under) the following classes of license:

- Proprietary or closed-source licenses;
- Licenses permitting digital rights management (DRM) or technical restrictions on the Work;
- Licenses that grant exclusive rights or permit sublicensing in derogation of CCAL terms;
- Licenses that prohibit commercial use entirely (CCAL permits commercial use of services and implementations; a license that forbids this is too restrictive to receive a CCAL-licensed input).

For complex deposits combining code, documentation, datasets, and hardware schematics, the layered-component pattern established under ERES-TCL v1.0 is permitted: MIT for code, CC-BY-SA 4.0 for documentation, ODC-BY for datasets, CERN-OHL-S v2 for hardware schematics — all unified under the CCAL v2.1 framework as the umbrella License Steward.

### 13. Governance and Stewardship

**License Steward.** The ERES Institute for New Age Cybernetics is the License Steward, with sole authority to issue authoritative interpretations of this License and to publish successor versions.

**Version Updates.** Proposals for amendments to CCAL may be submitted to the Steward by any Licensee or member of the public. Adoption of a new version requires supermajority consensus of the Institute's standing review process (sixty-seven percent, 67%). Backward compatibility with prior versions is maintained where consistent with the Three Governing Principles. Prior versions of CCAL remain valid licenses for Works originally released under those versions.

**Canonical Text.** The canonical text of CCAL v2.1 is deposited at Zenodo with its own Digital Object Identifier (DOI) and mirrored at the ERES Institute GitHub organization ( https://github.com/ERES-Institute-for-New-Age-Cybernetics ). In the event of discrepancy between mirrors, the Zenodo deposit governs.

### 14. Dispute Resolution

Disputes arising under this License shall be resolved in the following sequence, with each stage to be exhausted before progressing to the next:

1. Good-faith dialogue (thirty days). Direct communication between the disputing parties, with the Institute available as a neutral consultant on questions of CCAL interpretation.
2. Community mediation (sixty days). Mediation conducted under the auspices of the Institute or a mutually agreed mediator drawn from the CCAL Licensee community.
3. Arbitration. Binding arbitration by a mutually agreed expert panel, conducted on principles consistent with the Three Governing Principles and the Care Clause.

Litigation is the last resort. Any party who initiates litigation in violation of this sequence forfeits the Grace Provision (Section 8) with respect to the dispute in question.

### 15. Severability and Construction

If any provision of this License is held to be unenforceable under applicable law, the remaining provisions shall continue in full force and effect. Where a provision can be partially enforced, it shall be partially enforced to the maximum extent permitted.

This License shall be construed in accordance with its plain meaning and with the manifest intent of the Three Governing Principles. In any case of ambiguity, the construction more consistent with the Care Clause and the Earth-First Constraint shall prevail.

## Effective Date and Lineage

This License (CCAL v2.1) became effective on April 26, 2026.

Version Lineage:

| Version | Effective Date | Key Additions |
|---|---|---|
| CCAL v1.0 | February 2012 | Initial release: attribution, transparency, share-alike, no-warranty |
| CCAL v2.0 | 2024 | Care Clause introduced; alignment with the Three Governing Principles formalized |
| CCAL v2.1 | April 26, 2026 | Earth-First Constraint, Grace Provision, Patent Non-Assertion with Defensive Termination, formal compatibility table, layered-component pattern (ERES-TCL v1.0), Zenodo canonical deposit |

## Suggested Citation for Works under CCAL v2.1

> Sprute, J. A. (Year). Title of Work. ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1. ORCID: 0000-0001-9946-3221. [DOI or URL]

## Suggested Citation for the License Itself

> Sprute, J. A. (2026). CARE Commons Attribution License v2.1 (CCAL v2.1). ERES Institute for New Age Cybernetics. Effective April 26, 2026. [Zenodo DOI to be assigned upon deposit]

## Closing

CCAL v2.1 is one instrument among many. It is offered in good faith, to be used in good faith, in service of work that may outlast all of us. Read it once. Then build.

"Don't hurt yourself. Don't hurt others. Build for generations to come."

End of CCAL v2.1 Steward: ERES Institute for New Age Cybernetics Contact: eresmaestro@gmail.com Canonical mirror: https://github.com/ERES-Institute-for-New-Age-Cybernetics

---

## Part C — How CC BY 4.0 and CCAL v2.1 Work Together

### C.1 The arrangement: a dual license

This package is offered under **CC BY 4.0 or CCAL v2.1, at the licensee's option.** A licensee chooses one route and follows that license's terms.

| Route | What binds the licensee |
|---|---|
| **CC BY 4.0** | Attribution, indication of changes, a link to the license. Nothing else. CC BY 4.0, Section 2(a)(5)(B), forbids anyone from adding terms that restrict the rights it grants. |
| **CCAL v2.1** | Attribution (continuous), the Care Clause (the Three Governing Principles), the Earth-First Constraint, Transparency, Share-Forward, Non-Enclosure, Patent Non-Assertion, and the Grace Provision. |

On the CCAL route, the Three Governing Principles are an **operative condition** of the grant. On the CC BY route, they stand as the **author's stated expectation**: published, attributable, and morally binding on the reader who accepts them, but not a legal condition, because CC BY 4.0 does not permit one.

### C.2 Side by side

| Provision | CC BY 4.0 | CCAL v2.1 |
|---|---|---|
| Share, adapt, commercial use | Yes | Yes (services and implementations) |
| Attribution | Required | Required, and must carry forward through every derivative |
| Mark changes | Required | Required, with discoverable change log |
| Share-alike | No | Yes (Share-Forward) |
| Ethical use condition | No | Yes (Care Clause; Earth-First Constraint) |
| Anti-enclosure / anti-DRM | Limited (no technological measures that restrict rights) | Yes (Non-Enclosure) |
| Patent terms | Not licensed | Non-assertion with defensive termination |
| Good-faith shield | No | Yes (Grace Provision) |
| Cure period after violation | 30 days (automatic reinstatement) | 30 days (automatic reinstatement for the first violation) |
| Steward | Creative Commons (license author only) | ERES Institute (License Steward) |

### C.3 Independence: each license stands alone

Both licenses are **version-pinned**: the work is licensed under CC BY **4.0** and CCAL **v2.1** exactly, with **no "or later" clause**.

- **If CC BY changes, CCAL v2.1 does not.** Creative Commons never edits a published license version; any change would be issued as a new version (for example, 5.0), and this work remains under 4.0. CCAL v2.1 names "CC-BY 4.0" specifically in its Section 12, so no future Creative Commons version reaches into it.
- **If CCAL changes, CC BY 4.0 does not.** A CCAL v2.2 or later would apply only to works released under it. CCAL v2.1, Section 13, keeps prior versions valid for works originally released under them.
- **Severability.** If either license, or any provision of either, is changed, challenged or held unenforceable, the other license remains available on its own terms.

### C.4 The author's stated intent

*Stated by Joseph Allen Sprute, 17 October 2026:*

> Both licenses are non-violent. If CC BY 4.0 changes, that must not change CCAL v2.1. And CCAL v2.1 must evaporate if it tries to become violent. What "evaporate" does needs peer review.

C.5 and C.6 record how that intent is proposed to operate. **They are PROPOSED for peer review and are not operative legal terms of either license in this version.**

### C.5 What "violent" means: the resonance definition

**Author's definition (stated).** Resonance defines violence as contrast: a decision is violent when its **computer-generated** number and its **human-validated** number contrast beyond the resonance band. This follows the ERES H2C2H loop (Human-to-Computer-to-Human), in which every computed value returns to human validation.

**Operational sketch (PROPOSED).**

- For a decision taken under the license (for example, a termination or enforcement action), let **C** be the computer-generated value and **H** the human-validated value of the same decision.
- **Contrast:** K = |C − H| / scale.
- **Resonant:** K inside the band.
- **Violent:** K above the band's upper edge, sustained rather than momentary. This is the evaporation trigger.
- **Captured:** K persistently near zero. Under the ERES band principle both ends fail: perfect agreement on every decision can mean the humans are rubber-stamping the machine rather than validating it. Capture flags that review has stopped being independent; it does not trigger evaporation.

The companion testkit implements this test as `contrast_state()`. It deliberately **refuses to run without peer-reviewed thresholds**, so no threshold can be invented silently.

**OPEN for peer review:** the scale; the band thresholds; which decisions are measured; how many independent humans constitute "validated"; how long "sustained" is.

### C.6 What "evaporate" does: the proposed evaporation clause

**Design rule (PROPOSED).** Evaporation is one-directional: **conditions may vanish; rights already granted may not.** Withdrawing granted rights from good-faith licensees would itself be a coercive act, the very thing evaporation exists to prevent.

**Candidate meanings, for peer review:**

| Option | Effect when triggered | Trade-off |
|---|---|---|
| **E1 — Fall back to CC BY 4.0** *(proposed default)* | CCAL v2.1's added conditions dissolve; the work continues under CC BY 4.0 alone | Keeps attribution and openness; the Care Clause stops binding |
| **E2 — Dissolve to the public domain** | All conditions dissolve, including attribution | Most purely non-violent; author credit is lost |
| **E3 — Disarm enforcement only** | Termination and dispute provisions become void; the grant and the Grace Provision remain | Softest change; the Care Clause remains as a stated norm |

**Trigger (PROPOSED).** Sustained violent contrast (C.5) in decisions taken under CCAL v2.1, including any successor text or enforcement practice that would make the license itself coercive.

**Who decides (PROPOSED).** The contrast measurement decides, not the License Steward alone, because the Steward is the party whose conduct is being judged. An independent reviewer or panel reads the measurement.

### C.7 Notes for a future CCAL v2.2 (observations; nothing here amends v2.1)

1. **The CC BY route sheds CCAL conditions.** Section 12 lists CC BY 4.0 as a compatible license for derivatives, while Section 5 requires all CCAL terms to propagate. A derivative released under CC BY 4.0 cannot carry the Care Clause as a condition. Consider whether Section 12 should list CC BY 4.0 only for attribution-only components.
2. **Cross-reference.** Section 5 refers to "a Compatible License as defined in Section 11"; compatible licenses are defined in Section 12.
3. **Canonical deposit.** The license's own citation line still reads "[Zenodo DOI to be assigned upon deposit]." Under Section 13 the Zenodo deposit governs, so depositing CCAL v2.1 with its own DOI would settle which text is canonical.
4. **Evaporation.** If adopted after peer review, C.5 and C.6 would enter as a new section of CCAL v2.2.

### C.8 Status of this Part

This Part explains how the two licenses relate and records the author's intent. It is **not legal advice**. Review by intellectual-property counsel is recommended before any of C.5–C.7 is adopted into a license text.

### How to attribute this work (either route)

> Joseph Allen Sprute / ERES Institute for New Age Cybernetics. *The Host Reinvestment Rate (HRR)*, ERES-BEE-HRR-2026-001 v0.1 (2026). ORCID 0000-0001-9946-3221. Licensed under CC BY 4.0 or CCAL v2.1, at the licensee's option.
