#!/usr/bin/env python3
"""
ERES-BEE-HRR-2026-001 — Host Reinvestment Rate (HRR) testkit, v0.1
Zero-dependency (Python 3.8+ standard library only).
License: CC BY 4.0 or CCAL v2.1, at the licensee's option (see LICENSE.md).
Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics.
ORCID: 0000-0001-9946-3221

The testkit is the single source of truth for every number in the whitepaper.
It recomputes the budget from the data file, checks the printed figures
against that recomputation, and enforces the instrument's own rules:
no double counting, VEILED lines carry no point value, CONSTRUCTED
parameters are declared as such, and OPEN thresholds are never defaulted.

Usage:
    python3 eres_hrr_testkit.py                       # run all tests (exit 0 = PASS)
    python3 eres_hrr_testkit.py --compute             # print the budget (default inflation)
    python3 eres_hrr_testkit.py --compute --rate 0.033 # inflation as a flat annual rate
    python3 eres_hrr_testkit.py --compute --no-inflation
    python3 eres_hrr_testkit.py --compute --gdp 126.3  # alternative world GDP (USD T)
    python3 eres_hrr_testkit.py --compute --yield 1.10 # alternative verified-yield gain
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "ERES-BEE-HRR-2026-001_data.json")
WP = os.path.join(HERE, "ERES-BEE-HRR-2026-001_v0_1.md")
LICENSE = os.path.join(HERE, "LICENSE.md")
TOL = 0.005  # tolerance for rounded printed figures
CORE = ("L1", "L2", "L3", "L4")


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def line(d, lid):
    for x in d["budget_lines"]:
        if x["id"] == lid:
            return x
    raise KeyError(lid)


# ------------------------------------------------------------ inflation
def vintage_factor(d, vintage, mode=None, rate=None):
    """Multiplier that restates a vintage-year amount in base-year dollars."""
    inf = d["inflation"]
    mode = mode or inf["mode"]
    if mode == "none":
        return 1.0
    if mode == "rate":
        r = inf["rate"] if rate is None else rate
        return (1.0 + r) ** (inf["base_year"] - vintage)
    if mode == "cpi_table":
        return inf["cpi_factor_to_base"][str(vintage)]
    raise ValueError("inflation mode must be cpi_table, rate or none")


# ------------------------------------------------------------ budget
def compute(d, gdp=None, y=None, mode=None, rate=None):
    """Recompute the HRR budget. Returns lo / mid / hi dictionaries."""
    gdp = gdp or d["basis"]["world_gdp_2026_usd_t"]
    out = {}
    for b in ("lo", "hi"):
        core = 0.0
        for x in d["budget_lines"]:
            if x["counted"] and x["id"] in CORE:
                core += x[b] * vintage_factor(d, x["vintage_usd"], mode, rate)
        reserve = 0.10 * core                      # L5, CONSTRUCTED
        resource = core + reserve
        ver_rate = 0.01 if b == "lo" else 0.03     # L6, CONSTRUCTED
        verification = ver_rate * resource
        gross = resource + verification
        yb = y if y is not None else (d["yield"]["hi"] if b == "lo" else d["yield"]["lo"])
        net = resource / yb + verification
        out[b] = dict(core=core, reserve=reserve, resource=resource,
                      verification=verification, gross=gross, net=net,
                      gross_pct=100 * gross / gdp, net_pct=100 * net / gdp)
    mid = {k: (out["lo"][k] + out["hi"][k]) / 2 for k in out["lo"] if not k.endswith("_pct")}
    ymid = y if y is not None else d["yield"]["mid"]
    mid["net"] = mid["resource"] / ymid + mid["verification"]
    mid["gross_pct"] = 100 * mid["gross"] / gdp
    mid["net_pct"] = 100 * mid["net"] / gdp
    out["mid"] = mid
    return out


def line_table(d, mode=None, rate=None, gdp=None):
    """Inflation-adjusted lo/hi per counted line, USD T and % of GDP."""
    gdp = gdp or d["basis"]["world_gdp_2026_usd_t"]
    rows = []
    for x in d["budget_lines"]:
        if "lo" in x:
            f = vintage_factor(d, x["vintage_usd"], mode, rate)
            rows.append((x["id"], x["name"], x["bee_layer"], x["counted"],
                         x["lo"] * f, x["hi"] * f,
                         100 * x["lo"] * f / gdp, 100 * x["hi"] * f / gdp))
    return rows


def layer_totals(d, mode=None, rate=None):
    r = compute(d, mode=mode, rate=rate)
    layers = {}
    for row in line_table(d, mode, rate):
        lid, _, layer, counted, lo, hi, _, _ = row
        if counted and lid in CORE:
            layers.setdefault(layer, [0.0, 0.0])
            layers[layer][0] += lo
            layers[layer][1] += hi
    layers["Resilience"] = [r["lo"]["reserve"], r["hi"]["reserve"]]
    layers["Governance"] = [r["lo"]["verification"], r["hi"]["verification"]]
    return layers


# ------------------------------------------------------------ water physics
def lift_kwh_per_m3(d, h):
    w = d["water_physics"]
    return w["rho_kg_per_m3"] * w["g_m_per_s2"] * h / 3.6e6


def equivalent_lift_m(d, kwh):
    w = d["water_physics"]
    return kwh * 3.6e6 / (w["rho_kg_per_m3"] * w["g_m_per_s2"])


# ------------------------------------------------------------ resonance contrast
def contrast_state(c_value, h_value, scale, k_min=None, k_max=None):
    """
    Resonance test for a decision (LICENSE.md Part C, PROPOSED).
    K = |C - H| / scale, where C is the computer-generated value and H the
    human-validated value for the same decision.
      K > k_max  -> 'violent'   (contrast beyond the band)
      K < k_min  -> 'captured'  (validation no longer independent)
      otherwise  -> 'resonant'
    The thresholds are OPEN for peer review. No default is supplied:
    calling without them raises, so no number can be invented silently.
    """
    if k_min is None or k_max is None:
        raise ValueError("k_min and k_max are OPEN; supply peer-reviewed thresholds")
    if not (0 <= k_min < k_max) or scale <= 0:
        raise ValueError("require 0 <= k_min < k_max and scale > 0")
    k = abs(c_value - h_value) / scale
    if k > k_max:
        return "violent", k
    if k < k_min:
        return "captured", k
    return "resonant", k


# ------------------------------------------------------------ printed figures
# Figures as printed in the whitepaper (default: CPI-table inflation, IMF 2026 GDP).
PUBLISHED = {
    "gross_lo_pct": 5.33, "gross_mid_pct": 7.92, "gross_hi_pct": 10.50,
    "net_lo_pct": 4.45, "net_mid_pct": 6.91, "net_hi_pct": 9.57,
    "gross_mid_usd_t": 9.78, "gross_lo_usd_t": 6.59, "gross_hi_usd_t": 12.98,
    "nominal_gross_mid_pct": 6.32, "rate_gross_mid_pct": 7.62,
    "subsidy_cover_mid": 0.27, "lift_equiv_m": 1321,
}

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))


def run_tests():
    d = load()
    r = compute(d)

    ok = True
    for x in d["budget_lines"]:
        if not x.get("source") or not x.get("dvc"):
            ok = False
        if "lo" in x and not (0 <= x["lo"] <= x["hi"]):
            ok = False
    check("T1  every budget line has source, DVC tag, ordered range", ok)

    pairs = [("gross_lo_pct", r["lo"]["gross_pct"]), ("gross_mid_pct", r["mid"]["gross_pct"]),
             ("gross_hi_pct", r["hi"]["gross_pct"]), ("net_lo_pct", r["lo"]["net_pct"]),
             ("net_mid_pct", r["mid"]["net_pct"]), ("net_hi_pct", r["hi"]["net_pct"]),
             ("gross_mid_usd_t", r["mid"]["gross"]), ("gross_lo_usd_t", r["lo"]["gross"]),
             ("gross_hi_usd_t", r["hi"]["gross"])]
    bad = [f"{k}: printed {PUBLISHED[k]} vs computed {v:.4f}"
           for k, v in pairs if abs(PUBLISHED[k] - v) > TOL + 1e-9]
    check("T2  printed headline figures reproduce from data", not bad, "; ".join(bad))

    gdp = d["basis"]["world_gdp_2026_usd_t"]
    check("T3  percent equals dollars over GDP",
          abs(r["mid"]["gross_pct"] - 100 * r["mid"]["gross"] / gdp) < 1e-9)

    l1a = line(d, "L1a")
    check("T4  food line subsumed (excluded; inside L1 agriculture band 0.315-0.420)",
          (not l1a["counted"]) and l1a["lo"] >= 0.295 and l1a["hi"] <= 0.420)

    check("T5  VEILED/OPEN lines carry null point value",
          all(v["point_value"] is None for v in d["veiled_lines"]))

    check("T6  reserve and verification tagged CONSTRUCTED",
          line(d, "L5")["dvc"] == "CONSTRUCTED" and line(d, "L6")["dvc"] == "CONSTRUCTED")

    r1, r2 = compute(d, y=1.0), compute(d, y=1.3)
    check("T7  net = gross at y=1; net falls as y rises; yield tagged CONJECTURE",
          abs(r1["mid"]["net"] - r1["mid"]["gross"]) < 1e-9
          and r2["mid"]["net"] < r["mid"]["net"] and d["yield"]["dvc"] == "CONJECTURE")

    f1 = [f for f in d["funding_sources"] if f["id"] == "F1"][0]
    f2 = [f for f in d["funding_sources"] if f["id"] == "F2"][0]
    cover = f1["value"] / r["mid"]["gross"]
    check("T8  subsidy coverage uses redirectable F1 only; IMF implicit excluded",
          f1["redirectable"] and not f2["redirectable"]
          and abs(cover - PUBLISHED["subsidy_cover_mid"]) < 0.01, f"coverage {cover:.3f}")

    lift100 = lift_kwh_per_m3(d, 100)
    equiv = equivalent_lift_m(d, d["water_physics"]["swro_kwh_per_m3"])
    check("T9  lifting 1 m3 by 100 m = 0.2725 kWh (ideal); 3.6 kWh = ~1321 m of lift",
          abs(lift100 - 0.2725) < 0.001 and abs(equiv - PUBLISHED["lift_equiv_m"]) < 1,
          f"lift100={lift100:.4f} kWh, equiv={equiv:.1f} m")

    w = d["water_physics"]
    check("T10 atmospheric harvest at least 6x desalination cost (cited band)",
          w["awh_cost_multiple_lo"] >= 6 and w["awh_cost_multiple_hi"] >= w["awh_cost_multiple_lo"])

    ralt = compute(d, gdp=d["basis"]["world_gdp_alt_usd_t"])
    check("T11 GDP vintage moves the midpoint by less than 0.25 points",
          abs(ralt["mid"]["gross_pct"] - r["mid"]["gross_pct"]) < 0.25,
          f"alt GDP midpoint {ralt['mid']['gross_pct']:.2f}%")

    rn = compute(d, mode="none")
    rr = compute(d, mode="rate")
    f_rate = vintage_factor(d, 2015, mode="rate")
    check("T12 inflation variable: none reproduces nominal; rate mode = (1+r)^(base-v)",
          abs(rn["mid"]["gross_pct"] - PUBLISHED["nominal_gross_mid_pct"]) < TOL + 1e-9
          and abs(rr["mid"]["gross_pct"] - PUBLISHED["rate_gross_mid_pct"]) < TOL + 1e-9
          and abs(f_rate - 1.033 ** 11) < 1e-12,
          f"nominal {rn['mid']['gross_pct']:.2f}%, rate {rr['mid']['gross_pct']:.2f}%")

    check("T13 inflation can only raise vintage amounts (factors >= 1)",
          all(v >= 1.0 for v in d["inflation"]["cpi_factor_to_base"].values()))

    raised = False
    try:
        contrast_state(1.0, 1.0, 1.0)
    except ValueError:
        raised = True
    s_v, _ = contrast_state(10.0, 5.0, 1.0, k_min=0.1, k_max=2.0)
    s_c, _ = contrast_state(5.0, 5.0, 1.0, k_min=0.1, k_max=2.0)
    s_r, _ = contrast_state(6.0, 5.0, 1.0, k_min=0.1, k_max=2.0)
    check("T14 resonance contrast: refuses missing thresholds; classifies violent/captured/resonant",
          raised and (s_v, s_c, s_r) == ("violent", "captured", "resonant"),
          "illustrative thresholds only; real values are OPEN")

    if os.path.exists(WP):
        with open(WP, encoding="utf-8") as f:
            text = f.read()
        need = ["## License", "## Credits", "## References", "## Open Items",
                "## Predictions", "Doctrine of Verifiable Claims", "VEILED",
                "Inflation — An Adjustable Variable", "CCAL v2.1", "CC BY 4.0"]
        missing = [s for s in need if s not in text]
        check("T15 whitepaper carries House Format sections", not missing,
              ("missing: " + ", ".join(missing)) if missing else "")
        found = set(re.findall(r"(\d+\.\d\d)(?:%|\u2013)", text))
        want = {f"{PUBLISHED[k]:.2f}" for k in
                ("gross_mid_pct", "net_mid_pct", "gross_lo_pct", "gross_hi_pct",
                 "nominal_gross_mid_pct")}
        check("T16 whitepaper states the computed headline figures", want <= found,
              (f"missing {sorted(want - found)}") if (want - found) else "")
    else:
        check("T15 whitepaper present", False, WP)

    if os.path.exists(LICENSE):
        with open(LICENSE, encoding="utf-8") as f:
            lic = f.read()
        need = ["Part A", "Part B", "Part C", "Attribution 4.0 International",
                "No downstream restrictions", "Three Governing Principles",
                "Don't hurt yourself.", "version-pinned", "PROPOSED", "evaporat"]
        missing = [s for s in need if s not in lic]
        check("T17 LICENSE.md: CC BY 4.0 + CCAL v2.1 separated, joined, evaporation PROPOSED",
              not missing, ("missing: " + ", ".join(missing)) if missing else "")
    else:
        check("T17 LICENSE.md present", False, LICENSE)

    return results


def print_compute(args):
    d = load()
    kw = {}
    if "--no-inflation" in args:
        kw["mode"] = "none"
    if "--rate" in args:
        kw["mode"] = "rate"
        kw["rate"] = float(args[args.index("--rate") + 1])
    if "--gdp" in args:
        kw["gdp"] = float(args[args.index("--gdp") + 1])
    if "--yield" in args:
        kw["y"] = float(args[args.index("--yield") + 1])
    r = compute(d, **kw)
    print(f"inflation mode: {kw.get('mode', d['inflation']['mode'])}"
          + (f" (rate {kw['rate']})" if "rate" in kw else ""))
    lt_kw = {k: kw[k] for k in ("mode", "rate", "gdp") if k in kw}
    for row in line_table(d, **lt_kw):
        lid, name, layer, counted, lo, hi, plo, phi = row
        flag = "" if counted else "  (excluded: subsumed)"
        print(f"  {lid:<4} {name[:46]:<46} {lo:6.3f}-{hi:6.3f}  {plo:5.2f}-{phi:5.2f}%{flag}")
    for b in ("lo", "mid", "hi"):
        x = r[b]
        print(f"{b:>4}: core {x['core']:.3f}  reserve {x['reserve']:.3f}  "
              f"verif {x['verification']:.3f}  gross {x['gross']:.3f} "
              f"({x['gross_pct']:.2f}%)  net {x['net']:.3f} ({x['net_pct']:.2f}%)")
    lt = layer_totals(d, kw.get("mode"), kw.get("rate"))
    for k, v in lt.items():
        print(f"  layer {k:<14} {v[0]:.3f} - {v[1]:.3f}")
    print(f"  subsidy cover (F1 / gross mid): {2.6 / r['mid']['gross']:.3f}")


if __name__ == "__main__":
    if "--compute" in sys.argv:
        print_compute(sys.argv)
        sys.exit(0)
    res = run_tests()
    fails = 0
    for name, ok, detail in res:
        print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
        fails += (not ok)
    print(f"\n{len(res) - fails} PASS / {fails} FAIL")
    sys.exit(1 if fails else 0)
