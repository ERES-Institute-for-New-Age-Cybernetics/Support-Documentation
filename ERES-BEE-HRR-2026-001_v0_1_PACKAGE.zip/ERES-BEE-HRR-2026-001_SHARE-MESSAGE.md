# Share Message — ERES-BEE-HRR-2026-001 v0.1

*Brief post for LinkedIn, ResearchGate or email. Replace the bracketed link once the Zenodo DOI is minted.*

---

**How much of world output does Earth need back to keep hosting us?**

New working paper: *The Host Reinvestment Rate (HRR).* Built from published global estimates for nature, climate, oceans and water, with double counting removed and inflation carried as an adjustable variable:

- **~7.9% of world GDP** gross (range 5.3–10.5%), about $9.8T a year
- Climate is ~69% of it, and the widest uncertainty
- Redirecting ~$2.6T in harmful subsidies covers about a quarter
- Water's true cost is mostly transport, and nature's own supply has no price at all

Every number reproduces from an open data file and testkit. Released for peer review: critiques of the climate line especially welcome.

📄 [ZENODO DOI — PENDING]

Joseph Allen Sprute · ERES Institute for New Age Cybernetics · CC BY 4.0 or CCAL v2.1

#Sustainability #NaturalCapital #ClimateFinance #WaterSecurity #ERES
