#!/usr/bin/env python3
"""Generate Figure 1 (SVG) for ERES-BEE-HRR-2026-001 from the data file via the testkit."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eres_hrr_testkit as tk  # noqa: E402

d = tk.load()
r = tk.compute(d)
gdp = d["basis"]["world_gdp_2026_usd_t"]
layers = tk.layer_totals(d)
order = ["Body", "Land / Region", "Planet (GAIA)", "Resilience", "Governance"]
desc = {
    "Body": "Water: access, infrastructure, irrigation",
    "Land / Region": "Nature, food-land transition, oceans",
    "Planet (GAIA)": "Climate stabilization and adaptation",
    "Resilience": "Reserve: return to base (10%)",
    "Governance": "Verification layer (1-3%)",
}
color = {
    "Body": "#2a7fb8", "Land / Region": "#3f9e5a", "Planet (GAIA)": "#c9792b",
    "Resilience": "#7b6fb0", "Governance": "#5f6b73",
}

W, H = 900, 560
left, top, barw_max = 300, 110, 520
scale = barw_max / 10.0  # px per USD trillion (axis to $10T)
row_h, gap = 40, 26

o = []
o.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
         'font-family="Helvetica, Arial, sans-serif" role="img" '
         'aria-label="Figure 1: Host Reinvestment Rate by BEE layer">')
o.append(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
o.append('<text x="30" y="38" font-size="20" font-weight="700" fill="#1d2329">'
         'Figure 1. Host Reinvestment Rate (HRR) by BEE layer</text>')
o.append(f'<text x="30" y="62" font-size="13" fill="#47525b">Gross HRR {r["mid"]["gross_pct"]:.2f}% of world GDP '
         f'(range {r["lo"]["gross_pct"]:.2f}-{r["hi"]["gross_pct"]:.2f}%), about ${r["mid"]["gross"]:.1f}T per year. '
         '2026 USD, CPI-adjusted; world GDP $123.6T.</text>')
o.append('<text x="30" y="80" font-size="12" fill="#6b757d">Bars: midpoint. Whiskers: low-high range. '
         'Source: ERES-BEE-HRR-2026-001_data.json via eres_hrr_testkit.py</text>')

# axis
ax_y = top + len(order) * (row_h + gap) - gap + 18
for t in range(0, 11, 2):
    x = left + t * scale
    o.append(f'<line x1="{x}" y1="{top - 8}" x2="{x}" y2="{ax_y}" stroke="#e3e7ea" stroke-width="1"/>')
    o.append(f'<text x="{x}" y="{ax_y + 16}" font-size="11" fill="#6b757d" text-anchor="middle">${t}T</text>')

for i, name in enumerate(order):
    lo, hi = layers[name]
    mid = (lo + hi) / 2
    y = top + i * (row_h + gap)
    o.append(f'<text x="{left - 14}" y="{y + 17}" font-size="14" font-weight="700" fill="#1d2329" '
             f'text-anchor="end">{name}</text>')
    o.append(f'<text x="{left - 14}" y="{y + 34}" font-size="11" fill="#6b757d" text-anchor="end">{desc[name]}</text>')
    o.append(f'<rect x="{left}" y="{y + 6}" width="{mid * scale:.1f}" height="{row_h - 12}" rx="3" fill="{color[name]}"/>')
    yc = y + row_h / 2
    o.append(f'<line x1="{left + lo * scale:.1f}" y1="{yc}" x2="{left + hi * scale:.1f}" y2="{yc}" '
             'stroke="#1d2329" stroke-width="1.5"/>')
    for xv in (lo, hi):
        o.append(f'<line x1="{left + xv * scale:.1f}" y1="{yc - 7}" x2="{left + xv * scale:.1f}" y2="{yc + 7}" '
                 'stroke="#1d2329" stroke-width="1.5"/>')
    lab_x = left + max(hi, mid) * scale + 10
    o.append(f'<text x="{lab_x:.1f}" y="{yc + 4}" font-size="12" fill="#1d2329">'
             f'{100 * lo / gdp:.2f}-{100 * hi / gdp:.2f}%</text>')

# subsidy strip
sy = ax_y + 44
cover = 2.6
o.append(f'<text x="30" y="{sy + 15}" font-size="13" font-weight="700" fill="#1d2329">Funding by redirection</text>')
o.append(f'<rect x="{left}" y="{sy}" width="{r["mid"]["gross"] * scale:.1f}" height="22" rx="3" fill="#e9edf0"/>')
o.append(f'<rect x="{left}" y="{sy}" width="{cover * scale:.1f}" height="22" rx="3" fill="#3f9e5a"/>')
o.append(f'<text x="{left + 8}" y="{sy + 15}" font-size="12" fill="#ffffff" font-weight="700">$2.6T</text>')
o.append(f'<text x="{left}" y="{sy + 40}" font-size="12" fill="#1d2329">'
         f'Redirecting ~$2.6T/yr of environmentally harmful subsidies funds ~{100 * cover / r["mid"]["gross"]:.0f}% '
         f'of the ${r["mid"]["gross"]:.1f}T gross midpoint.</text>')
o.append(f'<text x="30" y="{H - 18}" font-size="11" fill="#6b757d">Natural freshwater production '
         '(the water cycle) is real but unpriced (VEILED) and is not included. '
         'CC BY 4.0 or CCAL v2.1 - J. A. Sprute / ERES Institute.</text>')
o.append('</svg>')

path = os.path.join(HERE, "ERES-BEE-HRR-2026-001_Figure1.svg")
with open(path, "w", encoding="utf-8") as f:
    f.write("\n".join(o))
print("wrote", path)
