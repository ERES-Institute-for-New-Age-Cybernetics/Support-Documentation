# ERES-BEE-HRR-2026-001 — The Host Reinvestment Rate (HRR), v0.1

**How much of world output does Earth need reinvested each year to keep hosting humanity?**

Joseph Allen Sprute (ERES Maestro) · ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221
Status: v0.1 PROPOSED, pre-MIEVM, released for peer review · License: CC BY 4.0 **or** CCAL v2.1 (LICENSE.md)

## Result

| Measure | Value |
|---|---|
| Gross HRR, inflation-adjusted (default) | **7.92% of world GDP** (5.33–10.50%), ~$9.8T/yr |
| Gross HRR, nominal | 6.32% |
| Net HRR with verified yield (conditional) | 6.91% |
| Fundable by redirecting harmful subsidies | ~27% of gross |
| Natural freshwater production | VEILED (real, unpriced, not given a number) |

## Package contents

| File | Role |
|---|---|
| `ERES-BEE-HRR-2026-001_v0_1.md` | Whitepaper, master text |
| `ERES-BEE-HRR-2026-001_v0_1.pdf` | Whitepaper, rendered (13 pp.) |
| `ERES-BEE-HRR-2026-001_data.json` | All inputs, sources, DVC tags and the inflation variable |
| `eres_hrr_testkit.py` | Testkit and calculator; stdlib only; 17 tests |
| `ERES-BEE-HRR-2026-001_Figure1.svg` | Figure 1: HRR by BEE layer (generated from the data) |
| `LICENSE.md` | Part A CC BY 4.0 · Part B CCAL v2.1 · Part C how they work together |
| `CCAL_v2.1_LICENSE.md.pdf` | Reference copy of CCAL v2.1 as supplied by the author |
| `ERES-BEE-HRR-2026-001_SEO-META.md` | SEO title, abstract, keywords |
| `ERES-BEE-HRR-2026-001_SHARE-MESSAGE.md` | Brief share post |
| `.zenodo.json` | Zenodo deposit metadata |
| `CITATION.cff` | Citation metadata |
| `make_figure.py`, `build_pdf.py` | Rebuild the figure and PDF from source |
| `RUN.txt` | One-screen run instructions |
| `MANIFEST.json` | SHA-256 checksums for every file |

## Run

```bash
python3 eres_hrr_testkit.py            # 17 tests; exit 0 = PASS
python3 eres_hrr_testkit.py --compute  # print the full budget
```

## Adjust the inflation variable

Every source was priced in an older dollar year (2015–2021). Each amount is restated as A(2026) = A(v) × m(v).

```bash
python3 eres_hrr_testkit.py --compute                 # default: measured CPI ratios
python3 eres_hrr_testkit.py --compute --rate 0.033    # flat 3.3%/yr (US long-run average since 1913)
python3 eres_hrr_testkit.py --compute --rate 0.025    # any rate you choose
python3 eres_hrr_testkit.py --compute --no-inflation  # nominal
python3 eres_hrr_testkit.py --compute --gdp 126.3     # alternative world GDP (USD trillions)
python3 eres_hrr_testkit.py --compute --yield 1.10    # alternative verified-yield gain
```

To change the defaults permanently, edit `inflation` in the data file (`mode`, `cpi_factor_to_base`, `rate`). A reviewer may substitute the US GDP deflator or a construction-cost index there.

## Uploading to Zenodo

1. Upload the files individually or as the ZIP; `.zenodo.json` carries the metadata (title, creator with ORCID, keywords, version, dates).
2. **Resource type:** Publication → Working paper.
3. **License field:** CC BY 4.0. Zenodo records one license; the description and LICENSE.md state the dual license with CCAL v2.1.
4. **Related identifier:** "is supplement to" the ERES corpus, `10.5281/zenodo.21209870`.

**Recommended:** publish a new *version* of the ERES corpus record from the current library (https://eresinstitute.org/eresmaestro/download/), then change the related identifier to the corpus **concept DOI**, which always resolves to the latest version.

5. After the DOI is minted, insert it into the share message and `CITATION.cff`.

## Reading the evidence tags

Every claim is tagged under the ERES Doctrine of Verifiable Claims:

- **SOURCED:** published estimate.
- **DERIVED:** arithmetic or physics, checked by the testkit.
- **CONSTRUCTED:** declared policy parameter.
- **CONJECTURE:** testable hypothesis.
- **VEILED:** real but unpriced.
- **OPEN:** unresolved.

## Cite

Sprute, J. A. (2026). *The Host Reinvestment Rate (HRR): How Much of World Output Earth Needs Reinvested to Keep Humanity Hosted* (ERES-BEE-HRR-2026-001, v0.1). ERES Institute for New Age Cybernetics. Licensed under CC BY 4.0 or CCAL v2.1. ORCID 0000-0001-9946-3221. [DOI]
