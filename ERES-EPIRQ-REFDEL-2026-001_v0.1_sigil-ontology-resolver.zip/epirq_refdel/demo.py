"""Demo: resolve EPIR-Q addresses against the PlayNAC Semantic Ontology.

    python demo.py

Includes a TOY gloss backend to show where the canonical Semantic Spiral
cipher plugs in. The toy is not the Spiral — swap in
eres_semantic_spiral_cipher_v0-2.py's resolver for real glosses.
"""
from epirq_refdel import resolve, PlayNACSemanticOntology


def toy_spiral_gloss(word: str) -> str | None:
    """Stand-in for the canonical Spiral cipher backend."""
    seed = {
        "water": "sustenance referent; maps to RATE R1",
        "provision": "population-level provisioning act",
    }
    return seed.get(word.lower())


def main() -> None:
    onto = PlayNACSemanticOntology(gloss_backend=toy_spiral_gloss)

    # The @# pair the user named — both GROUNDED.
    print(resolve("@how #why", onto).summary())
    print()

    # With referents, glossed through the (toy) Spiral backend.
    print(resolve("@how:water #why:provision", onto).summary())
    print()

    # Full six-sigil address — four PROPOSED bindings get flagged.
    print(resolve("@how #why ^care *is %real (us:way)", onto).summary())
    print()

    # Binding table.
    print("ONTOLOGY BINDINGS")
    for role, slot in PlayNACSemanticOntology.bindings().items():
        tag = slot.grounding.upper()
        print(f"  {role:5} -> {slot.name:16} [{tag}] {slot.gloss}")


if __name__ == "__main__":
    main()
