"""ref-del — resolve an EPIR-Q sigil address against the PlayNAC ontology.

    resolve("@how:water #why:provision") ->
        Resolution with two ResolvedRefs, each carrying the ontology slot,
        pillar, grounding tier, and (if a referent + backend) a gloss.

The resolver is pure: parse -> bind each reference to its slot -> attach
optional gloss. It never fabricates a slot or a gloss; PROPOSED bindings are
labelled so downstream MIEVM ratification can see what still needs an author
decision.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import notation
from .notation import Reference
from .ontology import PlayNACSemanticOntology, Slot, Grounding


@dataclass(frozen=True)
class ResolvedRef:
    reference: Reference
    slot: Slot
    gloss: str | None

    def summary(self) -> str:
        r = self.reference
        tag = "" if self.slot.grounding == Grounding.GROUNDED else " [PROPOSED]"
        pillar = f" pillar={self.slot.pillar}" if self.slot.pillar else ""
        line = f"{r.render():<16} -> {self.slot.name}{tag}{pillar}"
        if r.referent:
            g = self.gloss if self.gloss else "(no gloss backend)"
            line += f"\n{'':18}referent {r.referent!r}: {g}"
        return line


@dataclass
class Resolution:
    address: str
    refs: list[ResolvedRef] = field(default_factory=list)

    @property
    def all_grounded(self) -> bool:
        return all(r.slot.grounding == Grounding.GROUNDED for r in self.refs)

    @property
    def proposed(self) -> list[ResolvedRef]:
        return [r for r in self.refs if r.slot.grounding != Grounding.GROUNDED]

    def summary(self) -> str:
        head = f"ref-del: {self.address!r}"
        body = "\n".join("  " + r.summary() for r in self.refs)
        note = ("" if self.all_grounded
                else f"\n  ({len(self.proposed)} proposed binding(s) "
                     f"pending MIEVM ratification)")
        return f"{head}\n{body}{note}"


def resolve(address: str,
            ontology: PlayNACSemanticOntology | None = None) -> Resolution:
    ontology = ontology or PlayNACSemanticOntology()
    out = Resolution(address)
    for ref in notation.parse(address):
        slot = ontology.slot_for(ref.role)
        gloss = ontology.gloss(ref.referent)
        out.refs.append(ResolvedRef(ref, slot, gloss))
    return out


# convenience alias matching the user's term
ref_del = resolve
