"""EPIR-Q ref-del — resolve EPIR-Q sigil notation against the PlayNAC
Semantic Ontology.

Instrument: ERES-EPIRQ-REFDEL-2026-001  v0.1  (sigil-ontology resolver)
"""
from .notation import Sigil, Reference, parse, NotationError, SIGIL_ROLE
from .ontology import PlayNACSemanticOntology, Slot, Grounding
from .resolver import resolve, ref_del, Resolution, ResolvedRef

__version__ = "0.1.0"
__instrument__ = "ERES-EPIRQ-REFDEL-2026-001"

__all__ = [
    "Sigil", "Reference", "parse", "NotationError", "SIGIL_ROLE",
    "PlayNACSemanticOntology", "Slot", "Grounding",
    "resolve", "ref_del", "Resolution", "ResolvedRef",
    "__version__", "__instrument__",
]
