"""EPIR-Q sigil notation — grammar and parser.

The EPIR-Q epistemic face (Zenodo Q&A engine) addresses meaning with six
sigils, each binding a token to an interrogative/ontic ROLE:

    @  how      #  why      ^  care      *  is      %  real
    (us:way)   the paren form — the situated "our-way" collective role

An address is a sequence of references. A reference is:

    SIGIL role                     e.g.  @how          #why
    SIGIL role : referent          e.g.  @how:water    #why:provision
    ( role : referent )            e.g.  (us:way)      (us:water)

`ref-del` (reference-resolve) consumes these and hands each to the ontology.
This module only PARSES; it asserts no ontology bindings itself.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class Sigil(Enum):
    HOW = "@"
    WHY = "#"
    CARE = "^"
    IS = "*"
    REAL = "%"
    US = "("   # paren form, closed by ")"


# canonical role token each sigil expects
SIGIL_ROLE = {
    Sigil.HOW: "how",
    Sigil.WHY: "why",
    Sigil.CARE: "care",
    Sigil.IS: "is",
    Sigil.REAL: "real",
    Sigil.US: "us",
}
ROLE_SIGIL = {v: k for k, v in SIGIL_ROLE.items()}


@dataclass(frozen=True)
class Reference:
    sigil: Sigil
    role: str
    referent: str | None = None  # optional target word/phrase

    def render(self) -> str:
        if self.sigil is Sigil.US:
            inner = f"{self.role}:{self.referent}" if self.referent else f"{self.role}:way"
            return f"({inner})"
        tail = f":{self.referent}" if self.referent else ""
        return f"{self.sigil.value}{self.role}{tail}"


# @how  #why  ^care  *is  %real   (with optional :referent)
_SIMPLE = re.compile(r"([@#^*%])([A-Za-z]+)(?::([^\s@#^*%()]+))?")
# (role:referent)  or  (role)
_PAREN = re.compile(r"\(([A-Za-z]+)(?::([^\s)]+))?\)")


class NotationError(ValueError):
    pass


def parse(address: str) -> list[Reference]:
    """Parse an EPIR-Q address string into ordered References.

    Left-to-right, greedy. Unknown sigils or role/sigil mismatches raise.
    """
    refs: list[Reference] = []
    i, n = 0, len(address)
    while i < n:
        ch = address[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "(":
            m = _PAREN.match(address, i)
            if not m:
                raise NotationError(f"bad paren form at {i}: {address[i:]!r}")
            role, referent = m.group(1), m.group(2)
            if role != "us":
                raise NotationError(f"paren form expects role 'us', got {role!r}")
            refs.append(Reference(Sigil.US, role, referent))
            i = m.end()
            continue
        m = _SIMPLE.match(address, i)
        if not m:
            raise NotationError(f"unrecognised token at {i}: {address[i:]!r}")
        sig = Sigil(m.group(1))
        role = m.group(2)
        expected = SIGIL_ROLE[sig]
        if role != expected:
            raise NotationError(
                f"sigil {sig.value} expects role {expected!r}, got {role!r}")
        refs.append(Reference(sig, role, m.group(3)))
        i = m.end()
    if not refs:
        raise NotationError("empty address")
    return refs
