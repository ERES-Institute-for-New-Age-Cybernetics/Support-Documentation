"""PlayNAC Semantic Ontology — the resolution target for EPIR-Q sigils.

Each EPIR-Q role resolves to an ONTOLOGY SLOT. Two grounding tiers:

  GROUNDED (from the corpus):
    #why  -> MyWay (Purpose)     PlayNAC right-side project column
    @how  -> HowWay (Method)     PlayNAC right-side project column

  PROPOSED (not fixed in the corpus — flagged, swappable):
    ^care -> BERA (ground-truth care/health signal)
    *is   -> FAVORS (biometric "is-ness" / witness of the present state)
    %real -> SOMT (append-only record of what actually happened)
    us    -> CBGMODD (the seven-seat collective "our-way")

Each slot also carries its EPIR-Q pillar (HELP / USE / Energy / Law) where the
corpus implies one; left None otherwise rather than invented.

A referent word (e.g. @how:water) can additionally be glossed through a
pluggable semantic backend — wire the canonical Semantic Spiral cipher here.
The default backend is None (returns no gloss) so nothing is fabricated.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from .notation import Reference, Sigil


class Grounding:
    GROUNDED = "grounded"
    PROPOSED = "proposed"


@dataclass(frozen=True)
class Slot:
    name: str            # ontology slot / PlayNAC construct
    gloss: str           # what the slot means in one line
    pillar: str | None   # EPIR-Q pillar HELP/USE/Energy/Law, or None
    grounding: str       # Grounding.GROUNDED | PROPOSED


# role -> Slot
_BINDINGS: dict[str, Slot] = {
    "why":  Slot("MyWay(Purpose)", "the purpose axis — why the act exists",
                 "Law", Grounding.GROUNDED),
    "how":  Slot("HowWay(Method)", "the method axis — how the act proceeds",
                 "USE", Grounding.GROUNDED),
    "care": Slot("BERA", "planet/ground-truth care signal (not vote-subject)",
                 "Energy", Grounding.PROPOSED),
    "is":   Slot("FAVORS", "biometric witness of present state (is-ness)",
                 "HELP", Grounding.PROPOSED),
    "real": Slot("SOMT", "append-only record of what actually happened",
                 None, Grounding.PROPOSED),
    "us":   Slot("CBGMODD", "seven-seat collective — the situated our-way",
                 None, Grounding.PROPOSED),
}

# Semantic gloss backend: word -> optional short definition string.
GlossBackend = Callable[[str], Optional[str]]


@dataclass
class PlayNACSemanticOntology:
    gloss_backend: GlossBackend | None = None

    def slot_for(self, role: str) -> Slot:
        if role not in _BINDINGS:
            raise KeyError(f"no ontology slot bound to role {role!r}")
        return _BINDINGS[role]

    def gloss(self, word: str | None) -> str | None:
        if not word or self.gloss_backend is None:
            return None
        return self.gloss_backend(word)

    @staticmethod
    def bindings() -> dict[str, Slot]:
        return dict(_BINDINGS)
