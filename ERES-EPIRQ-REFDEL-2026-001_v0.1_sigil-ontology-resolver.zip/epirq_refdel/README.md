# EPIR-Q ref-del — sigil → PlayNAC Semantic Ontology resolver

**Instrument:** ERES-EPIRQ-REFDEL-2026-001 · **v0.1** · role: sigil-ontology resolver

Resolves EPIR-Q's epistemic-face sigil notation against the PlayNAC Semantic
Ontology. `ref-del` = reference-resolve: an address of sigils comes in, each
reference comes out bound to its ontology slot, pillar, grounding tier, and
(optionally) a semantic gloss.

## Sigil grammar (`notation.py`)

```
@how    #why    ^care    *is    %real    (us:way)
```

Each sigil binds a fixed role; `@why` etc. is a parse error. A referent may be
attached: `@how:water`, `#why:provision`, `(us:water)`.

## Ontology bindings (`ontology.py`)

| sigil | role | slot | grounding |
|------|------|------|-----------|
| `#` | why | **MyWay (Purpose)** | grounded — PlayNAC project column |
| `@` | how | **HowWay (Method)** | grounded — PlayNAC project column |
| `^` | care | BERA | **proposed** |
| `*` | is | FAVORS | **proposed** |
| `%` | real | SOMT | **proposed** |
| `(…)` | us | CBGMODD | **proposed** |

The `@#` pair — the one you named — is the grounded anchor: it lands on
PlayNAC's own right-side Purpose/Method columns, so how/why addressing is a
direct read of the governance TABLE, not a new mapping. The other four are
labelled PROPOSED: they're the reasonable ERES constructs for care/is/real/us,
but the corpus doesn't fix them yet, so the resolver flags them as pending
MIEVM ratification rather than asserting them.

## Semantic gloss backend

A referent word can be glossed through a pluggable backend
(`gloss_backend`). Wire the **canonical Semantic Spiral cipher**
(`eres_semantic_spiral_cipher_v0-2.py`, already published to
Proof-of-Work_MD) here to resolve referents through the A–Z 4-level grid. The
default backend is `None` — no gloss is fabricated when none is available.

## Run

```bash
python demo.py          # six-sigil resolution + toy gloss backend
python -m pytest -q     # 11 tests
```

## Open forks (author decisions)

1. **The four PROPOSED bindings** — confirm or re-slot care/is/real/us. Swap
   `_BINDINGS` in `ontology.py`; nothing else changes.
2. **Gloss backend** — plug the real Spiral cipher for `:referent` resolution.
3. **Pillar coverage** — HELP/USE/Energy/Law are attached where the corpus
   implies one (`why→Law`, `how→USE`, `care→Energy`, `is→HELP`); `real` and
   `us` are left `None` rather than guessed.
