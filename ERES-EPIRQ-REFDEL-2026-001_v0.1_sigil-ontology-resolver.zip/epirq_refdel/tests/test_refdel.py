import pytest

from epirq_refdel import (
    resolve, parse, Sigil, NotationError, PlayNACSemanticOntology, Grounding,
)


# ---- notation ---------------------------------------------------------------
def test_parse_all_six():
    refs = parse("@how #why ^care *is %real (us:way)")
    assert [r.role for r in refs] == ["how", "why", "care", "is", "real", "us"]


def test_parse_referent():
    r = parse("@how:water")[0]
    assert r.sigil is Sigil.HOW and r.referent == "water"


def test_role_sigil_mismatch_raises():
    with pytest.raises(NotationError):
        parse("@why")            # @ must carry 'how'


def test_paren_requires_us():
    with pytest.raises(NotationError):
        parse("(how:x)")


def test_unknown_token_raises():
    with pytest.raises(NotationError):
        parse("!bad")


def test_render_roundtrip():
    for addr in ("@how", "#why:provision", "(us:way)", "(us:water)"):
        assert parse(addr)[0].render() == addr


# ---- resolution -------------------------------------------------------------
def test_how_why_grounded():
    res = resolve("@how #why")
    slots = {r.reference.role: r.slot for r in res.refs}
    assert slots["how"].name == "HowWay(Method)"
    assert slots["why"].name == "MyWay(Purpose)"
    assert res.all_grounded


def test_other_four_flagged_proposed():
    res = resolve("^care *is %real (us:way)")
    assert not res.all_grounded
    assert len(res.proposed) == 4


def test_gloss_backend_used():
    onto = PlayNACSemanticOntology(gloss_backend=lambda w: f"G:{w}")
    res = resolve("@how:water", onto)
    assert res.refs[0].gloss == "G:water"


def test_no_backend_no_gloss():
    res = resolve("@how:water")
    assert res.refs[0].gloss is None


def test_pillars_present_where_grounded():
    res = resolve("@how #why")
    pillars = {r.reference.role: r.slot.pillar for r in res.refs}
    assert pillars["how"] == "USE" and pillars["why"] == "Law"
