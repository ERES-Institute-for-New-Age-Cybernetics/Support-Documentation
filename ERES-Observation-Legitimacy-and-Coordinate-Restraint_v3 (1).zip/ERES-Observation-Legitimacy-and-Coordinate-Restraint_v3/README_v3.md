# ERES Observation Legitimacy & Coordinate Restraint — v3 Package

Two position papers and three executable test suites. The v3 pass responds to a
four-node MIEVM review (DeepSeek, ChatGPT, Qwen, Gemini) whose strongest
convergent finding was: unify the pair into one operational, graded test, and
carry reciprocity via a community-of-interest.

## Artifacts (4 = 2 papers x 2 formats)

- `observation_legitimacy_v3.md` / `.pdf` — Paper 1. Overhead observation earns
  legitimacy through reciprocity and restraint; adds the thin/thick reciprocity
  distinction, the Lop Nor counter-case, customary-law grounding, a tentative
  extrapolation to persistent sensing, and (v3) the BEST/SOUND/GOOD graded test.
- `coordinate_restraint_v3.md` / `.pdf` — Paper 2. The geographic coordinate as
  the unit of spatial restraint; defends the coordinate against rival units,
  argues (not asserts) the observation–property binding, promotes the
  jurisdiction objection to the center, demotes GSSG to a marked aside, and (v3)
  adds the graded restraint test and points to the combined test.

## Tests (3)

- `test_observation_legitimacy.py` — Test 1/3. Grades observation regimes
  BEST/SOUND/GOOD; confirms Open Skies reaches SOUND, NTM caps at GOOD (thin
  reciprocity), Lop Nor floor-fails (tolerated ≠ legitimated). 9/9, exit 0.
- `test_coordinate_restraint.py` — Test 2/3. Enforces the gauge design rules;
  confirms staticness (Separation Principle), non-transfer ("a hymn cannot move
  a decimal"), a measurable comfort-floor gap, and that spatial bounds cannot
  substitute for temporal/resolution/aggregation bounds. 10/10, exit 0.
- `test_combined_legitimacy.py` — Test 3/3. The unified ERES Observation
  Legitimacy Test. Folds reciprocity (Paper 1) and spatial restraint (Paper 2)
  into one graded evaluation across ten dimensions via min-composition (binding
  constraint). Community-of-interest carries reciprocity. HONEST MODE: an
  asymmetric regime with no accountability floor-fails even with perfect bounds;
  a community-of-interest with audit standing lifts it to GOOD (tolerated) but
  never to SOUND (asymmetry organized, not cured). 12/12, exit 0.

## Run

    python3 test_observation_legitimacy.py
    python3 test_coordinate_restraint.py
    python3 test_combined_legitimacy.py

All stdlib-only, deterministic, exit 0 on pass.

## What the tests do and do not claim

The suites test the internal grammar of the arguments — that the tiers
discriminate the cases the papers say they discriminate — not the truth of the
cited history (Paper 1) or the real-world performance of any material (Paper 2,
GSSG remains [CONJECTURE]). The combined test's honest-mode floor-fail on
asymmetry is deliberate: it encodes, rather than hides, the reciprocity gap both
papers leave open.
