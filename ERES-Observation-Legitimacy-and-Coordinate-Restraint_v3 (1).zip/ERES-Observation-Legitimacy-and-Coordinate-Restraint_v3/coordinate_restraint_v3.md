**The Coordinate as the Unit of Restraint**

*A latitude--longitude gauge for property management, and where its
claims stop*

Companion to "Overhead Observation and the Terms of Its Legitimacy" ·
ERES Institute

*Version 3 — BEST/SOUND/GOOD graded test added with executable companion suite; community-of-interest reciprocity unit (Version 2 revisions retained).*

**Précis.** The companion paper ended on an open assignment: work out
what "bounded" means for sensors the drafters of Open Skies never
imagined. This paper takes up the *boundedness* half of that assignment
only --- it does not claim to solve the reciprocity half. It proposes
the geographic coordinate as one candidate unit of restraint, defends
that choice against rival units rather than asserting it, and describes
a bounded instrument --- a coordinate-indexed thermal gauge --- that
operationalizes the unit for property management. It then argues, rather
than assumes, whether the same unit can carry observation rights, and
concludes that the binding is a defensible *policy choice* with a real
cost, not a derivation. The central practical objection --- that a
coordinate grid does not respect property or political boundaries --- is
treated as the main event, not a footnote. It is a proposal, not a
finding, and its speculative parts are tagged.

**1. From "bounded" to a boundary**

Restraint requires a unit. "Observation should be bounded" is an
aspiration until one can say bounded *to what*. The history in the
companion paper bounded observation by treaty geography --- national
territory, quota flights, filed flight plans. Those units were coarse
because the sensors were coarse: they observed force-scale objects
across whole countries. Contemporary sensing resolves to the parcel and
the individual, and a unit of restraint matched to that resolution has
to be correspondingly fine.

The proposal here is that the finest durable, non-arbitrary, universally
shared unit already exists: the geographic coordinate. Every point on
Earth has one latitude and one longitude. A coordinate cell is
objective, globally agreed, jurisdiction-neutral at the point of
reference, and --- critically --- it is the same unit whether one is
describing what may be *observed* at a location, what may be *built*
there, and what is *owed* in respect of it. This paper calls the
management of rights and obligations at that unit
**Longitude-and-Latitude Property Management (LLPM)**.

**2. Why the coordinate, and not some other unit**

The companion paper's reasoning about persistent sensing named three
candidate bounds: retention (time), aggregation, and resolution. The
coordinate is a fourth --- a *spatial* bound. Choosing among them is the
argument this section owes, because the coordinate's appeal is partly
aesthetic (it is clean, global, objective) and aesthetics are not
justification. Set honestly against the rivals, the coordinate has one
distinctive property and one distinctive weakness.

Bounding by **time** (data expires after N hours) constrains *how long*
observation persists but says nothing about *where* or *what*. Bounding
by **resolution** (no imagery finer than X) constrains *how closely* but
not duration or place. Bounding by **aggregation** (separately-innocuous
observations may not be combined) constrains *inference* but is
notoriously hard to administer, since no observer knows when a new datum
completes a revealing mosaic. Each of these is a real, useful bound, and
none is exclusive of the others.

The coordinate's distinctive property is that it is the only one of the
four that is *shared with the thing being governed*. Time, resolution,
and aggregation are properties of the *observation*; a coordinate is a
property of the *place*. Because property, habitability, jurisdiction,
and observation all already refer to locations, a coordinate is the one
unit at which a rule about seeing can be stated in the same terms as a
rule about owning or building. That is not a proof that observation
*should* be bounded spatially --- it is the reason the spatial bound is
uniquely *integrable* with the other things one already regulates at a
location. The honest claim is narrow: the coordinate is not the only
unit of restraint, and probably not sufficient alone, but it is the
natural unit at which spatial restraint composes with existing property
regimes. A mature regime would likely use it *alongside* temporal and
resolution bounds, not instead of them.

The coordinate's distinctive weakness is stated in §5 and not hidden: a
geodetic grid does not follow ownership or borders. That weakness is
serious enough that it, not the elegance, determines whether the
proposal is viable.

**3. The instrument: a coordinate-indexed gauge**

LLPM is operationalized by a specific, bounded instrument. Its design
constraints are deliberately narrow, because an instrument that claims
less is one that can be trusted more.

The gauge is a function ***G(φ, λ)*** over latitude φ and longitude λ.
Its purpose is to describe the *thermal / climatic normal* of a
coordinate --- the settled, precomputed environmental baseline of that
place --- as the reference field against which property decisions
(build, cost, comfort provision) are made. Three design rules govern it,
and each rule is a limit rather than a capability:

**\[DERIVED\] Separation Principle.** The gauge carries only static,
precomputed climate normals. It contains no live weather, no dynamics,
no real-time feed. Anything that moves --- today's temperature, an
anomaly, an event --- is explicitly excluded from G and handled, if at
all, in a separate monitoring layer. The gauge is a map of the settled
climate of a place, not a window onto its present state. This is what
keeps a property instrument from silently becoming a surveillance
instrument.

**\[DERIVED\] Boundary-only mapping.** Where the gauge connects to the
broader ERES stability model, only the outer boundaries of the field
carry meaning --- the limits beyond which a coordinate is too harsh to
inhabit without intervention. The interior detail is treated as
decorative, not load-bearing. The instrument commits only to where the
edges are, not to false precision in the middle.

**\[DERIVED\] Non-transfer.** The gauge has two registers --- a fixed
mathematical one (φ is latitude, λ is longitude, and these never move)
and an interpretive one used for exposition. A hard rule separates them:
interpretive or symbolic annotation can never alter a number the
instrument outputs. In the instrument's own test phrase, "a hymn cannot
move a decimal." The reproducible quantity is sealed off from the
language wrapped around it.

**4. What the gauge is for**

The investment target of the gauge is the **comfort-floor gap per
coordinate** --- the distance between the settled climate of a place and
the baseline of habitability a person there is owed. A coordinate whose
thermal normal sits far from that floor requires more to make it
livable; one near the floor requires less. LLPM uses the gauge to make
that gap explicit, per location, as the basis for how property is
developed and what its development owes. The gauge measures the gap; it
does not prescribe how to close it, and the means of closing it are
outside this paper's claims (see the aside below).

**5. Can the same unit carry observation rights?**

This is the paper's load-bearing move, and the first version of it
asserted what it should have argued. Stated baldly --- "the same cell
that defines what is owed to a place can define what may be seen of it"
--- it is a sleight of hand: measuring a coordinate's climate and
permitting a satellite to photograph it are different categories of act,
and a state might consent to the first while refusing the second. So the
binding must be earned, and it may not survive.

The argument for it is this. Restraint on observation requires a unit at
which the rule is written and enforced (§2). Property and habitability
rules are already written at the coordinate. Placing observation rules
at the same unit is therefore not a claim that geometry *generates* a
right to privacy --- it does not --- but a claim that *co-locating* the
observation rule with the existing property rule lets the two be
administered together, contested together, and traded together. The
coordinate does not create the entitlement; it provides the *registry*
at which an entitlement, established on other grounds, can be attached
to observation.

The argument *against* it is equally clear and the paper concedes it
rather than burying it: this is a **policy choice**, not a derivation.
Nothing in geometry compels a state that permits climate measurement at
a coordinate to permit military-grade imaging there. Whoever adopts
coordinate-bound observation rights is *choosing* to bind two different
intrusions to one unit for the administrative benefit of doing so, and
paying for that benefit with a loss of granularity --- the two rules
might warrant different treatment that a shared unit obscures. The
honest verdict: the coordinate is a defensible *registry* for
observation rights and a poor *source* of them. It answers "where is the
rule filed?" and leaves "what should the rule be?" to the law and
politics of the place. That is a smaller claim than the first version
made, and a truer one.

**ASIDE --- \[CONJECTURE\]** The gauge measures the comfort-floor gap;
it does not build anything. One ERES candidate for closing the gap is
**Green Solar-Sand Glass (GSSG)**, a sand-derived solar-active building
material. Its performance is unproven and outside this paper's claims;
it is named here only to indicate that the measured gap is meant to be
actionable, not to argue any specific material. The coordinate-unit
proposal stands or falls independently of GSSG, and readers evaluating
the restraint argument should set the material aside entirely.

**6. The central objection: coordinates do not respect boundaries**

One limit deserves promotion out of the list, because it is not a caveat
but the proposal's hardest test. A geodetic latitude/longitude grid is
indifferent to ownership and sovereignty. A single cell can cut through
one house, straddle two properties, or span an international river; grid
lines shift with the choice of datum. Using such a grid as the unit for
legal observation rights, taken naively, is impractical to the point of
absurdity --- it would attach one rule to fractions of several distinct
legal parcels at once.

The paper owes a response, not just an admission. The response is that
the coordinate functions as a *reference frame*, not as the parcel
itself. Cadastral systems already solve exactly this: they express
legally-bounded parcels *in* coordinates without pretending the grid
*is* the parcel. LLPM, to be viable, must do the same --- the coordinate
indexes a rule; the *extent* over which the rule applies is the
legally-defined parcel or jurisdiction at that coordinate, not a raw
grid cell. Under that reading the objection is answered but at a cost
the paper must own: the coordinate alone is *insufficient*; it requires
a cadastral / jurisdictional overlay to become operational. The clean
geometric unit of §1--§2 is a reference index, and the actual unit of
enforcement is the messy legal parcel it points to. That concession
narrows the proposal from "the coordinate is the unit of restraint" to
"the coordinate is the shared reference frame in which units of
restraint are expressed." That is weaker, and correct.

**7. What this paper does not claim**

Beyond the central objection above, the remaining limits, stated
plainly:

**\[LIMIT\] It is a proposal, not a validated system.** The gauge exists
as a specified instrument with a reproduction test, but its always-live
reproduction against real climate data is a pending,
environment-external step. Until that runs, the instrument is designed,
not demonstrated.

**\[LIMIT\] It answers only the boundedness half.** The companion
paper's open assignment had two halves --- reciprocity and boundedness.
This paper addresses boundedness (a unit of spatial restraint) and makes
no claim to solve reciprocity. Where one party can observe a coordinate
and the party at that coordinate cannot observe back, the coordinate
unit *organizes* the asymmetry --- it gives it a registry --- but does
not cure it. This is a real concession: an instrument that files the
asymmetry has not dissolved it, and the reciprocity half of the
assignment remains genuinely open.

**\[CONJECTURE\] The material means are unproven.** As flagged in the
aside, GSSG and any specific gap-closing technology are outside this
paper's claims and pending their own evidence.

**8. The restraint made testable**

As with the companion paper, this version renders its proposal as a
graded test rather than a binary one, so a proposed coordinate-restraint
deployment can be scored on the **BEST / SOUND / GOOD** scale.

**FLOOR-FAIL ---** a raw geodetic grid that never resolves to a legal
extent (the Section 6 absurdity). GOOD --- the coordinate resolves to a
parcel/jurisdiction via cadastral overlay and expresses a spatial bound;
the registry works, but spatially only. SOUND --- GOOD plus composition
with at least one non-spatial bound (retention, resolution, or
aggregation) drawn from the companion paper. BEST --- SOUND with all
three non-spatial bounds present and independently auditable.

The design rules are enforced as executable guards in a companion suite
(*test_coordinate_restraint.py*). It confirms the gauge is static (no
time dependence --- the Separation Principle), that the non-transfer
rule holds literally (one hundred symbolic annotations move zero
decimals --- "a hymn cannot move a decimal"), that the comfort-floor gap
is a measurable non-negative quantity, and --- critically --- that a
spatial bound alone can never substitute for the temporal, resolution,
and aggregation bounds: a spatial-only deployment is capped at GOOD no
matter how fine its coordinate resolution. The suite runs clean (10/10)
and exits zero.

Neither of these two tests, alone, evaluates a whole observation regime
--- each covers only its paper's half. A third, combined suite
(*test_combined_legitimacy.py*) folds reciprocity (companion paper) and
spatial restraint (this paper) into one graded evaluation across ten
dimensions, with the **community-of-interest** --- the parties who share
a stake in a coordinate --- carrying the reciprocity dimension. It
applies the same binding-constraint rule, and it preserves the honest
concession: a community-of-interest with audit standing lifts an
asymmetric regime off the floor to GOOD (the asymmetry is organized, and
can be contested) but not to SOUND (the asymmetry is not cured). Only
genuine thick reciprocity reaches SOUND. The combined suite runs clean
(12/12) and exits zero --- and one of its tests exists precisely to
confirm that a scenario with perfect bounds but no reciprocity still
fails.

**9. Conclusion**

The companion paper left a two-part assignment; this paper takes up one
part. For the boundedness of modern sensing it proposes the geographic
coordinate --- not as a unit that *generates* rights, which it cannot,
but as the shared reference frame in which spatial restraint can be
expressed and co-administered with the property and jurisdictional rules
that already live at a location. The instrument that operationalizes it,
the coordinate-indexed thermal gauge, is deliberately modest: static,
boundary-only, and sealed against its own rhetoric --- a hymn cannot
move its decimals.

The revisions in this version are concessions, and they leave a smaller
but sturdier claim. The coordinate is a registry for observation rights,
not their source. It requires a cadastral overlay to become operational,
so it is a reference frame rather than the unit of enforcement. It
answers the boundedness half of the assignment and explicitly not the
reciprocity half. And the material question --- how a measured gap is
actually closed --- is set aside as unproven. What survives all of that
is worth stating precisely because it survived it: a checkable unit and
a falsifiable instrument for expressing spatial restraint, offered as
one contribution to a problem the companion paper showed is still, in
its harder half, unsolved.

**Note on sources and status.** This is an ERES Institute position
paper. Unlike its companion --- which rests on the agreed external
historical record --- this paper describes ERES-internal instruments
(the G(φ,λ) Thermal Gauge, LLPM, and GSSG) and states their design and
limits. Claims are tagged in the ERES Doctrine-of-Verifiable-Claims
convention: \[DERIVED\] follows from the instrument's stated design;
\[CONJECTURE\] is asserted pending evidence; \[LIMIT\] marks what is out
of scope or unproven. The gauge instrument (ERES-VX-THERMAL-GAUGE / "The
Gauge Sings") carries a stdlib reproduction test suite; its live-data
reproduction is the principal pending gate. GSSG performance claims are
external to this paper. Nothing here overrides the property or privacy
law governing any actual coordinate.
