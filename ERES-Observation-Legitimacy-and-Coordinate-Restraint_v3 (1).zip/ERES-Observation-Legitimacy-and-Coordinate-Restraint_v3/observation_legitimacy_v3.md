**Overhead Observation and the Terms of Its Legitimacy**

*How reconnaissance from above became lawful --- not by rule, but by
reciprocity*

A position paper grounded in agreed historical precedent

*Version 3 — BEST/SOUND/GOOD graded test added with executable companion suite; community-of-interest reciprocity unit (Version 2 revisions retained).*

**Précis.** The right to observe another state from above was not
conferred by a court or discovered in a statute. It was constructed ---
deliberately, over decades --- out of a single bargain: observation is
tolerated when it is mutual, bounded, and stabilizing, and it is
contested when it is one-directional and unbounded. This paper traces
that bargain through five agreed historical episodes, from the first
orbital overflight to formal treaty regimes, and extracts the operative
principle that governed each. The principle is not "surveillance is
permitted." It is narrower and more useful: overhead observation earns
its legitimacy from reciprocity and restraint, and loses it in their
absence. The relevance to any actor now building persistent orbital
sensing is direct.

**1. The question, stated precisely**

A sensor in orbit can see what a sensor on the ground cannot, and it can
do so without the observed party's knowledge or consent. This capability
has existed for over sixty years. The question is not whether it is
technically possible --- that was settled in 1960 --- but on what terms
it is treated as legitimate rather than as an act of aggression. That
question has a clear historical answer, and the answer was worked out in
practice long before it was written into any instrument.

The method of this paper is deliberate. It relies on *agreed historical
episodes* rather than on contested case law or doctrinal argument. Each
episode below is a matter of record: the events occurred, the facts are
not in dispute, and the norm each established can be stated without
interpretation doing the heavy lifting. Where interpretation is
required, it is marked as such.

**2. Five episodes and the norm each set**

**2.1 The air/space divide --- an aircraft is war, a satellite is
tolerated**

The founding fact of overhead reconnaissance is a discontinuity. Flying
a military aircraft over another state's territory without permission
was, and remains, a violation of sovereign airspace --- an act of war.
Passing over the same territory in orbit was not treated the same way.
When Sputnik 1 crossed national borders from orbit in 1957, it
established a precedent for transit that aircraft never enjoyed.
Overflight by aircraft remained provocative; overflight from space
quietly became fact.

**The operative norm:** altitude changed the legal character of the
identical act. The same observation was aggression from an airplane and
tolerated from a satellite --- not because the observation differed, but
because the mode of transit did. Legitimacy attached to *how* the
observation was conducted, not to *what* it captured.

**2.2 Freedom of space --- a precedent engineered on purpose**

The tolerance of orbital overflight was not an accident of physics that
states stumbled into. It was manufactured. To secure the legal right to
orbit reconnaissance satellites over other countries without their
permission, the United States deliberately launched a scientific
satellite first --- even though military alternatives were ready sooner
--- timed to the International Geophysical Year and placed in an orbit
that would not cross the Soviet Union. The purpose was to set a
precedent that would later legitimize military reconnaissance from
orbit. It worked.

**The operative norm:** a legitimacy that does not yet exist can be
built by acting first in a form no one objects to, then extending the
tolerance to the contested use. Precedent is a constructed asset. This
is the single most important lesson in the history for anyone building a
new observational capability today: the norm governing your system is
not fixed --- it is set by the first uses, and it can be shaped.

**2.3 Corona --- capability in the open, without a governing rule**

By 1960, the Corona program was returning usable imagery of foreign
territory from orbit. The capability was operational and, over time,
undeniable. Yet no treaty authorized it and none prohibited it. It
occupied --- and satellite reconnaissance still largely occupies ---
what one scholar called a lawfully grey but tolerated zone: not
explicitly regulated, accepted by custom, permitted in practice because
no party with the power to object found it in their interest to do so.

**The operative norm:** a capability can be lawful-by-toleration long
before it is lawful-by-rule. Absence of prohibition is not the same as
authorization, but in the observational domain it has functioned as a
durable substitute --- sustained precisely because the observation
served mutual interests neither side wished to forgo.

**2.4 National Technical Means --- observation converted into a
protected right**

The decisive shift came when arms-control agreements stopped ignoring
satellite reconnaissance and began to depend on it. The strategic arms
treaties of the early 1970s introduced the term "national technical
means of verification" --- a diplomatic euphemism for reconnaissance
satellites. These treaties did two things at once: they granted an
affirmative right to observe the other party's territory by such means,
and they prohibited interference with that observation. Both sides
recognized that satellites could stabilize the relationship by making
each side's forces legible to the other, and so each agreed to be
watched in exchange for the right to watch.

**The operative norm:** observation becomes a *protected* right --- not
merely a tolerated practice --- at the moment it is made reciprocal and
tied to stability. The party that accepts being observed gains the
guaranteed right to observe, and interference with the other's
observation becomes itself a violation.

A distinction matters here, and the argument is stronger for drawing it.
Two different things travel under the word "reciprocity," and NTM rests
on the thinner of the two. **Thin reciprocity** is mutual observation
*capability* --- each side can watch the other. That is close to a fact
of physics once both have satellites; it costs no one a decision.
**Thick reciprocity** is mutual *accountability* --- each side shows the
other what it saw. NTM verification required only the thin version: the
United States had to be able to count Soviet missiles and refrain from
interfering with Soviet counting, but it never had to share the grain of
the photograph. It said, in effect, "we counted," not "here is what we
saw." Open Skies (§2.5) moved closer to the thick version by putting
escorts aboard and filing flight plans. The trajectory of the whole
history is from thin toward thick reciprocity, and the paper's later
claims about persistent sensing (§6) turn on which one a modern regime
supplies.

**2.5 Open Skies --- the purest form of conditional, reciprocal
observation**

The Treaty on Open Skies, proposed in concept as early as 1955 and
entered into force in 2002, is the clearest expression of the bargain.
It grants each party the right to conduct unarmed observation flights
over the entire territory of the others --- but under strict conditions.
Flights are allocated by national quota. They occur no sooner than
twenty-four hours after the observing state files a flight plan. They
are flown in agreed aircraft, with escorts of the observed state aboard.
Observation is a right; it is also a scheduled, bounded, escorted,
quota-limited right.

**The operative norm:** the mature form of legitimate observation is
neither prohibition nor free access. It is *conditional access* ---
permitted on defined triggers, bounded in time and scope, reciprocal by
construction, and transparent to the observed. This is the endpoint the
whole history moves toward.

**2.6 The counter-case --- Lop Nor, and observation without
reciprocity**

A clean trajectory invites a counter-example, and there is a sharp one
that the argument must face rather than omit. In the 1960s the United
States used Corona imagery to monitor China's nascent nuclear program at
Lop Nor. There was no arms-control treaty with China, no reciprocal
right for China to observe the United States, and no stabilizing bargain
of the kind that underwrote the U.S.--Soviet regimes. The purpose was
not mutual transparency but one-sided, pre-emptive monitoring of a
program the United States wished to constrain. And yet this observation
was broadly accepted internationally, including by the Soviet Union,
without any reciprocity being offered to the observed party.

This does not fit the neat line, and it should not be smoothed over. Two
honest readings are available, and the paper takes the second. The
first: legitimacy here came not from reciprocity but from the "freedom
of space" precedent already established (§2.2) --- once orbital
overflight was tolerated as such, a particular use of it inherited that
toleration regardless of reciprocity. The second, which is stronger: the
Lop Nor case shows that *toleration and legitimacy are not the same
thing*. The observation was tolerated --- no one had the means or the
will to stop it --- but it was never made *legitimate* in the
load-bearing sense of a right the observed party accepted and could
invoke. It sat in the grey zone (§2.3), not the protected zone (§2.4).
The counter-case therefore does not refute the principle; it sharpens
it. Reciprocity is what converts tolerated observation into *protected*
observation. Its absence at Lop Nor is exactly why that observation
conferred no right and set no accepted rule --- it was power exercised
in a permissive vacuum, which is a different thing from legitimacy.

**3. The principle the episodes share**

Read together, the five episodes describe a single trajectory. Overhead
observation began as a raw capability of ambiguous legality (air/space
divide, Corona), was made tolerable by engineered precedent (freedom of
space), and was ultimately made *legitimate* by binding it to two
conditions: reciprocity and restraint (NTM, Open Skies). At no point did
legitimacy flow from the observation being harmless --- reconnaissance
is intrusive by design. It flowed from the observation being *mutual*
and *bounded*.

**Stated as a principle:** overhead observation is stabilizing --- and
treated as legitimate --- to the exact degree that it is reciprocal,
bounded, and non-interfered-with. It is destabilizing --- and contested
--- to the degree that it is one-directional, unbounded, and secret. The
same sensor sits on both sides of that line. What determines which side
it falls on is not the hardware but the terms of its use.

This is the dual-use fact made concrete. A reconnaissance capability
protects when it verifies a mutual agreement and threatens when it
enables one-sided advantage. The historical record does not resolve that
duality by choosing a side; it resolves it by supplying *conditions*
under which the protective use is stable and the threatening use is
constrained. Reciprocity is the condition that does the most work: a
system everyone can point at everyone is stabilizing in a way that a
system only one party controls never is.

**4. What the record does not settle**

Intellectual honesty requires marking the limits of the argument. Three
of them matter.

**First, toleration is not codification --- but it is not nothing,
either.** Satellite reconnaissance remains, to a substantial degree,
legally grey rather than expressly authorized. The 1986 UN Principles on
Remote Sensing state that such sensing should respect the sovereignty of
states and that observed states should have access to the data --- but
these principles are non-binding, and in practice observing parties do
not share reconnaissance data with the observed. The custom is stable,
but it rests on interest as much as on enforceable law. This paper
should be candid about what it has and has not shown: it has traced
*political* legitimacy --- the practical acceptance of a practice by the
parties who could contest it --- not *legal* legitimacy in the formal
sense. The bridge between the two is the doctrine of customary
international law, under which consistent state practice combined with
*opinio juris* (a belief that the practice is legally required, not
merely convenient) can harden toleration into binding custom. Whether
satellite-reconnaissance toleration has crossed that threshold is a
genuine question in the international-law literature and is beyond this
paper's historical method. The paper claims the political pattern; it
flags the legal question as open rather than answering it.

**Second, the reciprocity bargain was built between peers.** The NTM and
Open Skies regimes worked because the parties had comparable
capabilities and comparable exposure --- each had something the other
wanted to watch, and each could watch back. The principle degrades where
the parties are radically asymmetric, where one can observe and the
other cannot. The historical solution assumes a rough balance that does
not always hold, and the paper does not claim it does.

**Third, persistence and resolution have changed since these norms
formed.** The regimes above governed periodic observation of
military-scale objects --- silos, aircraft, force build-ups. Continuous,
high-resolution observation of individuals and civil activity is a
different matter of degree that may amount to a difference in kind.
Whether the reciprocity-and-restraint principle scales to persistent,
fine-grained observation is an open question the record cannot answer,
because the record predates the capability.

**5. The principle made testable**

A principle that cannot be applied to a case is a slogan. This version
therefore renders the argument as a graded test, so that a given
observation regime can be scored rather than merely praised or
condemned. The test is not binary. It grades a regime on the **BEST /
SOUND / GOOD** scale, with a floor below GOOD for regimes that fail a
necessary condition outright.

The tiers correspond directly to the history above:

**GOOD --- tolerated.** Authority exists and observation is bounded, but
reciprocity is *thin* (mutual capability only). This is the NTM tier:
legitimate, but not fully protected.

**SOUND --- protected.** Reciprocity is *thick* (mutual accountability
--- the observed sees what is collected), bounds hold, and a remedy
exists for breach. This is the Open Skies tier, and the civilizational
operating target.

**BEST --- bounded optimum.** SOUND plus independent auditability and
interference protection. Not a maximum one sits at permanently, but the
asymptote the others are measured against.

**FLOOR-FAIL --- not on the ladder.** A regime lacking authority the
observed could invoke, or lacking a resolvable observed party, is power
in a permissive vacuum. This is where Lop Nor sits: tolerated, never
legitimated. The test must place it below GOOD, and it does.

The grading is composed by the *binding constraint* rule --- a regime is
only as legitimate as its weakest necessary condition (the minimum
across dimensions, in the ERES M×E+C=R form). This is deliberately the
honest rule: a regime with perfect bounds but thin reciprocity is capped
at GOOD, and one with no reciprocity at all fails outright, however
sophisticated its other properties. The test refuses to certify what the
argument has not established.

The scale is executable. A companion Python suite
(*test_observation_legitimacy.py*) encodes these tiers and their
discriminations as pass/fail structural checks --- confirming, among
other things, that Open Skies reaches SOUND, that NTM is capped at GOOD
by thin reciprocity, and that Lop Nor floor-fails below both. The suite
tests the *grammar* of the argument, not the truth of the history, which
is cited. It runs clean (9/9) and exits zero; a reader can reproduce it
or break it.

**6. Conclusion**

The history is unusually clear on one point and appropriately silent on
another. It is clear that overhead observation earned its legitimacy
through reciprocity and restraint, not through any claim that it was
benign --- and that the mature form of that legitimacy is conditional
access: bounded, triggered, reciprocal, transparent to the observed. It
is silent on how that principle applies to a generation of sensors that
can watch continuously and in detail, because that capability arrived
after the bargains were struck.

For anyone now building persistent observational capability, the record
offers a usable inheritance and an open assignment. The inheritance:
legitimacy is constructed, and it is constructed by binding capability
to reciprocal, bounded terms of use --- a lesson demonstrated five times
over, and confirmed in the negative by Lop Nor, where the absence of
reciprocity left observation tolerated but never legitimated.

The assignment is to work out what "reciprocal and bounded" means for
sensors the drafters of Open Skies never imagined. The record predates
the capability and cannot answer directly --- but the principle it
establishes does support a tentative extrapolation, offered here as a
first principle to be tested rather than a settled rule. If legitimacy
scales as the history suggests, then for persistent, fine-grained
sensing:

**Reciprocity** would have to move from thin to thick --- from mutual
capability to mutual accountability. Persistent observation is
legitimated not by both sides merely being *able* to watch continuously,
but by a mutual data-sharing or mutual-access framework: the observed
party sees what is collected about it, or the collection is logged in a
form both can audit. Thin reciprocity, adequate for counting missiles
once, is inadequate for watching everything always.

**Boundedness** would have to shift from spatial to temporal and
structural, because the spatial bound (national territory) no longer
constrains a sensor that resolves individuals. The candidate bounds are
limits on *retention* (how long observation may be kept), on
*aggregation* (whether separately-innocuous observations may be
combined), and on *resolution* (how finely a coordinate may be resolved)
--- possibly enforced by tamper-evident, on-orbit logging so that the
bound is auditable rather than merely promised.

These are proposals, not findings --- the history supports the *shape*
of the answer (thicker reciprocity, non-spatial bounds) without
dictating its content. The companion paper takes up one candidate for
the boundedness half; the reciprocity half remains genuinely open. That
is the actual work, and it is unfinished --- but it is no longer a
blank.

**Sources.** This paper is grounded in the documented historical record
of overhead reconnaissance: the Sputnik overflight precedent and the
engineered "freedom of space" launch policy (U.S. National
Reconnaissance Office historical materials; American Academy of Arts &
Sciences, Reconsidering the Rules for Space Security); the Corona
program and the "lawfully grey but tolerated" status of satellite
reconnaissance; the introduction of National Technical Means of
verification in the SALT/ABM treaties and the treaty prohibition on
interference with NTM; and the Treaty on Open Skies (U.S. Department of
State article-by-article analysis; Government of Canada treaty summary),
including its quota, flight-plan, and escort conditions. The non-binding
1986 UN Principles on Remote Sensing are noted as the limit of
codification. All factual claims above are drawn from these agreed
sources; interpretive statements are marked as "operative norm" or
"principle" and are the author's synthesis of the agreed facts.
