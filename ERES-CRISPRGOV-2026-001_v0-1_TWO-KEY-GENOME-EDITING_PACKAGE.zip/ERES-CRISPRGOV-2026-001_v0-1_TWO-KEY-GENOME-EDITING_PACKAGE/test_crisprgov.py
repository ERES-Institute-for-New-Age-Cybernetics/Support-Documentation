#!/usr/bin/env python3
"""
ERES-CRISPRGOV-2026-001 v0.1 -- specification test harness.

Implements the contract terms of the whitepaper as executable checks and
tests whether the CONTRACT behaves as specified. This is not a clinical
tool: it runs on synthetic configurations. It makes no safety claim about
any real editing protocol.

Stdlib only. Run:  python3 test_crisprgov.py
Exit 0 iff zero FAILs.

License: CC BY 4.0
"""

import sys
from dataclasses import dataclass, field
from typing import Optional, List

INSTRUMENT = "ERES-CRISPRGOV-2026-001"
VERSION = "v0.1"

# ---------------------------------------------------------------- results

RESULTS: List[tuple] = []


def check(tid, name, cond, note=""):
    RESULTS.append((tid, name, "PASS" if cond else "FAIL", note))


def skip(tid, name, why):
    RESULTS.append((tid, name, "SKIP", why))


# ---------------------------------------------------------------- C5/C6: band

@dataclass
class Band:
    """C5 -- declared specificity band."""
    eta_min: float        # minimum on-target editing efficiency
    omega_max: float      # maximum off-target event rate
    m_max: float          # maximum mosaicism (incl. germ-line compartment, T7)
    tau_days: int         # observation horizon
    version: int = 1      # C5 band versioning (T4)

    def valid(self):
        return (0 < self.eta_min <= 1 and self.omega_max >= 0
                and 0 <= self.m_max <= 1 and self.tau_days > 0)


@dataclass
class Readout:
    """C6 -- assay-derived readout. Intent and sponsorship are absent by design."""
    eta: float
    omega: float
    m: float

    def in_band(self, b: Band) -> bool:
        return self.eta >= b.eta_min and self.omega <= b.omega_max and self.m <= b.m_max

    def h_phi(self, b: Band) -> float:
        """Graded in-band readout in [0,1]: worst-margin fraction across the three axes."""
        if not b.valid():
            return 0.0
        a = min(1.0, self.eta / b.eta_min)
        c = 1.0 if self.omega <= b.omega_max else max(0.0, 1.0 - (self.omega - b.omega_max) / max(b.omega_max, 1e-9))
        d = 1.0 if self.m <= b.m_max else max(0.0, 1.0 - (self.m - b.m_max) / max(b.m_max, 1e-9))
        return min(a, c, d)


# ---------------------------------------------------------------- C8: deficit

def deficit(r: Readout, b: Band) -> float:
    """C8 -- D = f(B). Non-negative; zero when in band."""
    return (max(0.0, b.eta_min - r.eta)
            + max(0.0, r.omega - b.omega_max)
            + max(0.0, r.m - b.m_max))


# ---------------------------------------------------------------- C9: n_eff

def n_eff(k: int, rho_bar: float) -> float:
    """CDFE covariance discount. k assays at mean pairwise correlation rho_bar."""
    if k <= 0:
        return 0.0
    rho_bar = min(max(rho_bar, 0.0), 1.0)
    return k / (1.0 + (k - 1) * rho_bar)


N_EFF_GATE = 3.0


# ---------------------------------------------------------------- C11: gate

@dataclass
class IndependenceGate:
    """C11 -- the institutional PAM. Second key, locally verified."""
    recognition_failure_modes: frozenset
    licence_failure_modes: frozenset
    authorises_against_own_record: bool

    def clears(self) -> bool:
        disjoint = not (self.recognition_failure_modes & self.licence_failure_modes)
        return disjoint and not self.authorises_against_own_record


# ---------------------------------------------------------------- C12/C14/C16

@dataclass
class Consent:
    """C14 -- per-cycle revocable. C12 -- revocation routes to N at zero cost."""
    granted: bool
    revocable_this_cycle: bool
    revocation_cost: float          # in N-floor units; C12 requires 0.0
    n_floor_available_on_revoke: bool
    principal_can_sign: bool = True  # False -> C3 proxy required
    principal_will_hold_revocation_right: bool = False  # germline signature


@dataclass
class ReturnToBase:
    """C16 -- defined base, guaranteed path, reserve to traverse it."""
    base_state_defined: bool
    reversal_path_exists: bool
    reversal_demonstrated: bool      # asserted != demonstrated (T6)
    reserve_available: bool

    def admissible(self) -> bool:
        return (self.base_state_defined and self.reversal_path_exists
                and self.reversal_demonstrated and self.reserve_available)


@dataclass
class Contract:
    band: Band
    readout: Readout
    k_assays: int
    rho_bar: float
    gate: IndependenceGate
    consent: Consent
    rtb: ReturnToBase
    scale_band: str = "S1"
    control_concentration: float = 0.0   # C20
    certifier_has_interest: bool = False # C4
    raises: List[str] = field(default_factory=list)

    # -------- C3: proxy admissibility
    def c3_ok(self):
        if self.consent.principal_can_sign:
            return True
        # proxy may sign, but not away a revocation right the principal will hold
        return not self.consent.principal_will_hold_revocation_right

    # -------- C10: offset, not accrual
    def c10_ok(self):
        return deficit(self.readout, self.band) > 0.0

    # -------- C12/C14
    def consent_ok(self):
        c = self.consent
        return (c.granted and c.revocable_this_cycle
                and c.revocation_cost == 0.0 and c.n_floor_available_on_revoke)

    # -------- full admissibility
    def discharge_admissible(self):
        self.raises = []
        if not self.band.valid():
            self.raises.append("C5 band invalid")
        if not self.c10_ok():
            self.raises.append("C10 no measured deficit -- accrual, not offset")
        if n_eff(self.k_assays, self.rho_bar) < N_EFF_GATE:
            self.raises.append("C9 n_eff below gate")
        if not self.gate.clears():
            self.raises.append("C11 independence gate does not clear")
        if not self.c3_ok():
            self.raises.append("C3 proxy cannot sign away a future revocation right")
        if not self.consent_ok():
            self.raises.append("C14/C12 consent or floor not satisfied")
        if not self.rtb.admissible():
            self.raises.append("C16 return-to-base not established")
        if self.certifier_has_interest:
            self.raises.append("C4 certifier disqualified")
        if self.control_concentration > 0.95:
            self.raises.append("C20 control concentration raise")
        return len(self.raises) == 0


# ---------------------------------------------------------------- C19

def rho_R(in_band_flags) -> float:
    return sum(1 for f in in_band_flags if f) / len(in_band_flags) if in_band_flags else 0.0


RHO_R_GATE = 0.85


# ---------------------------------------------------------------- fixtures

def clean_gate():
    return IndependenceGate(frozenset({"assay_chemistry"}),
                            frozenset({"registry_audit"}),
                            False)


def clean_consent():
    return Consent(True, True, 0.0, True, True, False)


def clean_rtb():
    return ReturnToBase(True, True, True, True)


def somatic_contract():
    b = Band(0.70, 0.01, 0.05, 365)
    r = Readout(0.80, 0.03, 0.02)   # off-target out of band -> deficit exists
    return Contract(b, r, k_assays=5, rho_bar=0.15, gate=clean_gate(),
                    consent=clean_consent(), rtb=clean_rtb(), scale_band="S1")


# ---------------------------------------------------------------- tests

def run():
    # --- C5/C6 band arithmetic
    b = Band(0.70, 0.01, 0.05, 365)
    check("t01", "C5 valid band accepted", b.valid())
    check("t02", "C5 invalid band rejected", not Band(0.0, 0.01, 0.05, 365).valid())
    check("t03", "C6 in-band readout recognised", Readout(0.9, 0.005, 0.01).in_band(b))
    check("t04", "C6 out-of-band readout recognised",
          not Readout(0.9, 0.05, 0.01).in_band(b))
    check("t05", "C6 h_phi in [0,1]", 0.0 <= Readout(0.9, 0.05, 0.01).h_phi(b) <= 1.0)
    check("t06", "C6 readout ignores sponsorship (no such field)",
          not hasattr(Readout(0.9, 0.005, 0.01), "sponsor"))

    # --- C8 deficit
    check("t07", "C8 deficit zero when in band",
          deficit(Readout(0.9, 0.005, 0.01), b) == 0.0)
    check("t08", "C8 deficit positive when out of band",
          deficit(Readout(0.5, 0.05, 0.2), b) > 0.0)
    check("t09", "C8 deficit non-negative always",
          all(deficit(Readout(e, o, m), b) >= 0
              for e in (0.1, 0.9) for o in (0.0, 0.5) for m in (0.0, 0.9)))

    # --- C9 n_eff
    check("t10", "C9 n_eff -> k as rho -> 0", abs(n_eff(6, 0.0) - 6.0) < 1e-9)
    check("t11", "C9 n_eff -> 1 as rho -> 1", abs(n_eff(6, 1.0) - 1.0) < 1e-9)
    check("t12", "C9 n_eff monotone decreasing in rho",
          n_eff(6, 0.1) > n_eff(6, 0.5) > n_eff(6, 0.9))
    check("t13", "C9 six correlated assays fail the 3.0 gate",
          n_eff(6, 0.8) < N_EFF_GATE, f"n_eff={n_eff(6,0.8):.2f}")
    check("t14", "C9 three near-independent assays clear the gate",
          n_eff(4, 0.05) >= N_EFF_GATE, f"n_eff={n_eff(4,0.05):.2f}")
    check("t15", "C9 unanimity does not substitute for independence",
          n_eff(20, 0.95) < n_eff(4, 0.05))

    # --- C11 independence gate
    check("t16", "C11 disjoint failure modes clear", clean_gate().clears())
    check("t17", "C11 shared failure mode blocks (T1 PAM theatre)",
          not IndependenceGate(frozenset({"assay_chemistry"}),
                               frozenset({"assay_chemistry"}), False).clears())
    check("t18", "C11 self-authorisation blocks",
          not IndependenceGate(frozenset({"a"}), frozenset({"b"}), True).clears())

    # --- C10 offset vs accrual
    acc = somatic_contract()
    acc.readout = Readout(0.9, 0.005, 0.01)   # already in band
    check("t19", "C10 in-band trait yields no deficit -> enhancement is not an offset",
          not acc.c10_ok())
    check("t20", "C10 enhancement configuration is refused discharge",
          not acc.discharge_admissible())

    # --- baseline somatic case (S1)
    som = somatic_contract()
    check("t21", "S1 somatic contract is admissible",
          som.discharge_admissible(), str(som.raises))

    # --- C12/C14 consent
    costly = somatic_contract()
    costly.consent = Consent(True, True, 0.4, True, True, False)
    check("t22", "T3 costly revocation refused (C12 zero-cost floor)",
          not costly.discharge_admissible())
    nofloor = somatic_contract()
    nofloor.consent = Consent(True, True, 0.0, False, True, False)
    check("t23", "C12 missing N-floor refused", not nofloor.discharge_admissible())
    irrev = somatic_contract()
    irrev.consent = Consent(True, False, 0.0, True, True, False)
    check("t24", "C14 non-revocable consent refused", not irrev.discharge_admissible())

    # --- C16 return-to-base
    asserted = somatic_contract()
    asserted.rtb = ReturnToBase(True, True, False, True)   # designed, not demonstrated
    check("t25", "T6 asserted-but-undemonstrated reversal refused",
          not asserted.discharge_admissible())
    noreserve = somatic_contract()
    noreserve.rtb = ReturnToBase(True, True, True, False)
    check("t26", "C16 reversal path without reserve refused",
          not noreserve.discharge_admissible())
    nobase = somatic_contract()
    nobase.rtb = ReturnToBase(False, True, True, True)
    check("t27", "C16 undefined base state refused", not nobase.discharge_admissible())

    # --- germline: refusal must be DERIVED from C3+C14, not hard-coded
    germ = somatic_contract()
    germ.scale_band = "S5"
    germ.consent = Consent(granted=True, revocable_this_cycle=True,
                           revocation_cost=0.0, n_floor_available_on_revoke=True,
                           principal_can_sign=False,
                           principal_will_hold_revocation_right=True)
    germ.rtb = ReturnToBase(False, False, False, True)
    check("t28", "S5 germline configuration refused", not germ.discharge_admissible())
    check("t29", "germline refusal cites C3 (proxy/revocation), derived not declared",
          any("C3" in r for r in germ.raises), "; ".join(germ.raises))
    check("t30", "germline refusal ALSO cites C16 independently",
          any("C16" in r for r in germ.raises))
    check("t31", "no rule named 'germline' appears in the admissibility logic",
          "germline" not in Contract.discharge_admissible.__doc__.lower()
          if Contract.discharge_admissible.__doc__ else True)

    # --- gene drive: conditional, not barred outright
    drive_bad = somatic_contract()
    drive_bad.scale_band = "S4"
    drive_bad.rtb = ReturnToBase(True, True, False, True)  # reversal designed only
    check("t32", "S4 drive with undemonstrated reversal refused",
          not drive_bad.discharge_admissible())
    drive_ok = somatic_contract()
    drive_ok.scale_band = "S4"
    drive_ok.rtb = ReturnToBase(True, True, True, True)    # demonstrated
    check("t33", "S4 drive with demonstrated reversal admissible (not barred outright)",
          drive_ok.discharge_admissible(), str(drive_ok.raises))

    # --- C4 / C20
    cap = somatic_contract()
    cap.certifier_has_interest = True
    check("t34", "T9 interested certifier disqualified", not cap.discharge_admissible())
    conc = somatic_contract()
    conc.control_concentration = 0.97
    check("t35", "C20 concentration > 0.95 raises the contract",
          not conc.discharge_admissible())

    # --- C19 aggregation
    check("t36", "C19 rho_R computed correctly",
          abs(rho_R([True] * 17 + [False] * 3) - 0.85) < 1e-9)
    check("t37", "C19 below-gate ensemble refused population claim",
          rho_R([True] * 8 + [False] * 2) < RHO_R_GATE)

    # --- T4 enhancement drift
    drift = somatic_contract()
    v1 = drift.band
    v2 = Band(0.95, 0.0001, 0.001, 365, version=2)
    check("t38", "T4 upward band re-declaration is detectable as a version change",
          v2.version > v1.version and v2.eta_min > v1.eta_min)

    # --- T7 germ-line compartment bound by m_max
    t7 = somatic_contract()
    t7.readout = Readout(0.80, 0.03, 0.40)   # high mosaicism
    check("t39", "T7 germ-line mosaicism raises deficit via m_max",
          deficit(t7.readout, t7.band) > deficit(som.readout, som.band))

    # --- CT theorem falsification attempts
    ct1 = somatic_contract()
    ct1.readout = Readout(0.95, 0.001, 0.001)   # D = 0
    check("t40", "CT-CR-001 not falsified: no discharge at D=0",
          not ct1.discharge_admissible())
    ct2 = somatic_contract()
    ct2.rtb = ReturnToBase(True, True, False, True)
    check("t41", "CT-CR-002 not falsified: no discharge on asserted reversal",
          not ct2.discharge_admissible())
    ct3 = somatic_contract()
    ct3.consent = Consent(True, True, 0.25, True, True, False)
    check("t42", "CT-CR-003 not falsified: revocation available in form but costly is refused",
          not ct3.discharge_admissible())

    # --- explicit SKIPs: require real telemetry
    skip("t43", "O1 rho_bar calibrated from real assay covariance",
         "needs a real assay panel; no dataset claimed")
    skip("t44", "C7 tau-horizon continuity on live streams",
         "needs Context Field instantiation on real post-edit observation")
    skip("t45", "T3 revocation effective-cost measured in real units",
         "O4 open -- metric undefined")
    skip("t46", "Phase 3 retrospective gate run against approved protocols",
         "empirical roadmap phase 3; not run")
    skip("t47", "CT-CR-001/002/003 machine-checked rather than test-discharged",
         "roadmap phase 4")
    skip("t48", "MIEVM >=5-node ensemble at mean >=9.0",
         "roadmap phase 5; D.I.D. layer 2 not yet run")


def main():
    run()
    w = max(len(n) for _, n, _, _ in RESULTS) + 2
    print(f"{INSTRUMENT} {VERSION} -- specification harness\n")
    for tid, name, status, note in RESULTS:
        line = f"  {tid}  {name:<{w}} {status}"
        if note:
            line += f"   [{note}]"
        print(line)
    p = sum(1 for r in RESULTS if r[2] == "PASS")
    f = sum(1 for r in RESULTS if r[2] == "FAIL")
    s = sum(1 for r in RESULTS if r[2] == "SKIP")
    print(f"\n  {p} PASS / {f} FAIL / {s} SKIP")
    print("  Grade: GOOD (claim) / SOUND-candidate (specification).")
    print("  Nothing DERIVED => none BEST. SKIPs are open, not passed.")
    return 1 if f else 0


if __name__ == "__main__":
    sys.exit(main())
