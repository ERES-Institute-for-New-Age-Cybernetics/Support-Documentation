#!/usr/bin/env python3
"""Render the WP markdown to PDF via reportlab platypus."""
import re
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, HRFlowable, KeepTogether)

SRC = "ERES-CRISPRGOV-2026-001_v0.1_WP.md"
OUT = "ERES-CRISPRGOV-2026-001_v0.1_WP.pdf"

ss = getSampleStyleSheet()
INK = colors.HexColor("#1d2733")
MUTE = colors.HexColor("#5a6673")
RULE = colors.HexColor("#d8d2c6")

S = {
    "h1": ParagraphStyle("h1", parent=ss["Title"], fontName="Helvetica-Bold",
                         fontSize=17, leading=21, textColor=INK, spaceAfter=10),
    "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold",
                         fontSize=12.5, leading=15, textColor=INK,
                         spaceBefore=14, spaceAfter=6),
    "h3": ParagraphStyle("h3", parent=ss["Heading3"], fontName="Helvetica-Bold",
                         fontSize=10.8, leading=13, textColor=INK,
                         spaceBefore=10, spaceAfter=4),
    "p": ParagraphStyle("p", parent=ss["BodyText"], fontName="Helvetica",
                        fontSize=9.4, leading=13.2, textColor=INK,
                        alignment=TA_JUSTIFY, spaceAfter=6),
    "li": ParagraphStyle("li", parent=ss["BodyText"], fontName="Helvetica",
                         fontSize=9.4, leading=13.2, textColor=INK,
                         leftIndent=14, bulletIndent=4, spaceAfter=4),
    "meta": ParagraphStyle("meta", parent=ss["BodyText"], fontName="Helvetica",
                           fontSize=9, leading=12.6, textColor=MUTE, spaceAfter=2),
    "code": ParagraphStyle("code", parent=ss["BodyText"], fontName="Courier",
                           fontSize=9, leading=12, textColor=INK,
                           leftIndent=14, spaceBefore=4, spaceAfter=6),
    "cell": ParagraphStyle("cell", parent=ss["BodyText"], fontName="Helvetica",
                           fontSize=8.1, leading=10.2, textColor=INK),
    "cellh": ParagraphStyle("cellh", parent=ss["BodyText"], fontName="Helvetica-Bold",
                            fontSize=8.1, leading=10.2, textColor=colors.white),
    "note": ParagraphStyle("note", parent=ss["BodyText"], fontName="Helvetica-Oblique",
                           fontSize=8.4, leading=11.5, textColor=MUTE, spaceBefore=6),
}


def inline(t):
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"`([^`]+)`", r'<font face="Courier">\1</font>', t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<i>\1</i>", t)
    return t


def build():
    lines = open(SRC, encoding="utf-8").read().split("\n")
    story, i, n = [], 0, len(lines)
    while i < n:
        ln = lines[i]
        st = ln.strip()

        if not st:
            i += 1
            continue

        if st.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            for b in buf:
                story.append(Paragraph(inline(b).replace(" ", "&nbsp;"), S["code"]))
            continue

        if st == "---":
            story.append(Spacer(1, 4))
            story.append(HRFlowable(width="100%", thickness=0.8, color=RULE))
            story.append(Spacer(1, 4))
            i += 1
            continue

        if st.startswith("|"):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                r = lines[i].strip()
                if not re.match(r"^\|[\s:\-\|]+\|$", r):
                    rows.append([c.strip() for c in r.strip("|").split("|")])
                i += 1
            if rows:
                ncol = max(len(r) for r in rows)
                data = []
                for ri, r in enumerate(rows):
                    r = r + [""] * (ncol - len(r))
                    stl = S["cellh"] if ri == 0 else S["cell"]
                    data.append([Paragraph(inline(c), stl) for c in r])
                avail = 6.7 * inch
                t = Table(data, colWidths=[avail / ncol] * ncol, repeatRows=1)
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), INK),
                    ("GRID", (0, 0), (-1, -1), 0.4, RULE),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 3.5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1),
                     [colors.white, colors.HexColor("#f4f2ee")]),
                ]))
                story.append(Spacer(1, 4))
                story.append(t)
                story.append(Spacer(1, 8))
            continue

        if st.startswith("#"):
            lvl = len(st) - len(st.lstrip("#"))
            txt = inline(st.lstrip("# ").strip())
            story.append(Paragraph(txt, S["h1"] if lvl == 1 else S["h2"] if lvl == 2 else S["h3"]))
            i += 1
            continue

        if re.match(r"^[-*]\s+", st):
            story.append(Paragraph(inline(re.sub(r"^[-*]\s+", "", st)), S["li"], bulletText="\u2022"))
            i += 1
            continue

        if re.match(r"^\d+\.\s+", st):
            m = re.match(r"^(\d+)\.\s+(.*)$", st)
            story.append(Paragraph(inline(m.group(2)), S["li"], bulletText=m.group(1) + "."))
            i += 1
            continue

        if st.startswith("*") and st.endswith("*") and st.count("*") == 2:
            story.append(Paragraph(inline(st.strip("*")), S["note"]))
            i += 1
            continue

        if st.startswith("**") and ":**" in st and len(st) < 120:
            story.append(Paragraph(inline(st), S["meta"]))
            i += 1
            continue

        story.append(Paragraph(inline(st), S["p"]))
        i += 1

    def deco(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.4)
        canvas.setFillColor(MUTE)
        canvas.drawString(0.9 * inch, 0.55 * inch,
                          "ERES-CRISPRGOV-2026-001 v0.1  |  CC BY 4.0  |  "
                          "GOOD (claim) / SOUND-candidate (spec)")
        canvas.drawRightString(7.6 * inch, 0.55 * inch, "p. %d" % doc.page)
        canvas.setStrokeColor(RULE)
        canvas.line(0.9 * inch, 0.72 * inch, 7.6 * inch, 0.72 * inch)
        canvas.restoreState()

    doc = SimpleDocTemplate(OUT, pagesize=LETTER,
                            leftMargin=0.9 * inch, rightMargin=0.9 * inch,
                            topMargin=0.85 * inch, bottomMargin=0.95 * inch,
                            title="Two-Key Genome Editing: A Smart-Resonant Offset "
                                  "Contract for CRISPR Governance",
                            author="Joseph Allen Sprute (ERES Institute)",
                            subject="ERES-CRISPRGOV-2026-001 v0.1")
    doc.build(story, onFirstPage=deco, onLaterPages=deco)
    print("wrote", OUT)


if __name__ == "__main__":
    build()
