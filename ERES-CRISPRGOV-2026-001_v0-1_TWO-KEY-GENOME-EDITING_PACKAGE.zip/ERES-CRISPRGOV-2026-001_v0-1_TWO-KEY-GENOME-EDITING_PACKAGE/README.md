# ERES-CRISPRGOV-2026-001 — Package README

**Two-Key Genome Editing: A Smart-Resonant Offset Contract for CRISPR Governance**
Version v0.1 (Proposed) · 24 September 2026 · CC BY 4.0
ERES Institute for New Age Cybernetics · Bella Vista, Arkansas
Author: Joseph Allen Sprute · ORCID 0000-0001-9946-3221

---

## What this is

A governance instrument for deliberate genome editing, built on a primitive CRISPR itself demonstrates: **the PAM rule**. Cas9 will not cut on sequence match alone — a second, locally verifiable motif must be present. Match is necessary and insufficient.

This package lifts that rule from molecule to institution. An edit discharges only when a deficit is measured against a declared band, an independent second key clears, and a return-to-base path exists.

Two consequences follow without moral assertion:

- **Germline editing is refused** by C3 (a proxy may not sign away a revocation right the principal will later hold) *and independently* by C16 (no defined base state to return to). Two clauses, neither written for the case, both refuse it.
- **Gene drives are conditional, not barred** — admissible at S4 only where a reversal drive is *demonstrated in the field*, not designed, modelled, or named.

## Contents

| File | Role |
|---|---|
| `ERES-CRISPRGOV-2026-001_v0.1_WP.md` | Whitepaper, source of record |
| `ERES-CRISPRGOV-2026-001_v0.1_WP.pdf` | Whitepaper, 9pp, deposit/print form |
| `test_crisprgov.py` | Executable specification harness (stdlib only) |
| `ERES-CRISPRGOV-2026-001_v0.1_ARCHITECTURE.svg` | Two-key gate and discharge cycle |
| `META.txt` | SEO title, abstract, keywords, RG share message |
| `build_pdf.py` | MD → PDF renderer (reproduces the PDF from the MD) |
| `MANIFEST.txt` | File inventory with SHA-256 |
| `README.md` | This file |

## Running the harness

```
python3 test_crisprgov.py
```

Python 3.8+, no dependencies. Exit 0 iff zero FAILs.

**Current state: 42 PASS / 0 FAIL / 6 SKIP, exit 0.**

The 6 SKIPs are open, not passed. They require real telemetry: `ρ̄` calibration from a real assay panel, τ-horizon continuity on live post-edit streams, revocation effective-cost in real units, the Phase-3 retrospective gate run, machine-checked theorems, and a ≥5-node MIEVM round. Nothing is faked to reach a clean line.

The harness tests whether the **contract** behaves as specified. It is not a clinical tool and makes no safety claim about any real editing protocol.

## The one test worth reading first

```
t13  six correlated assays fail the 3.0 gate     PASS   [n_eff=1.20]
t14  three near-independent assays clear it      PASS   [n_eff=3.48]
```

`n_eff = k / (1 + (k−1)·ρ̄)`. Six off-target assays sharing a cell line, a guide-design algorithm family and a sequencing chemistry are, effectively, one assay run six times. Unanimity is not independence. The discount is declared from assay design **before** results, never fitted afterward to reach the gate.

## Also worth reading

```
t29  germline refusal cites C3, derived not declared
t30  germline refusal ALSO cites C16 independently
t31  no rule named 'germline' appears in the admissibility logic
```

The bar is emergent from the contract's own clauses. That is what distinguishes a constitution from a list of prohibitions.

## Grade and honest limits

- **Grade:** GOOD (claim) / SOUND-candidate (specification).
- **Ceiling:** nothing DERIVED ⇒ none BEST. No live telemetry; `ρ̄` uncalibrated; the three constitutional theorems are test-discharged, not machine-proved.
- **D.I.D. status:** author read = layer 1. Second-instrument validation not yet run. **This is not a completed MIEVM** and ships labelled as such.
- **The CRISPR↔ERES correspondence table in §2 is a design analogy, marked non-evidentiary.** No claim is made that ERES primitives derive from CRISPR biology.
- **Frame honesty:** the germline bar holds *under this contract*. A frame that denies future persons a revocation right reaches a different answer. ERES declares its frame in C14 and accepts the consequence.

## The honest experiment

Empirical roadmap Phase 3: run the C9 gate retrospectively against already-approved editing protocols and report how many clear `n_eff ≥ 3.0`.

If most clear it easily, the instrument adds ceremony. If most fail, either the gate is miscalibrated or current evidence standards are weaker than assumed. Either result is informative. Neither is assumed here.

## Open items

O1 `ρ̄` calibration · O2 band parameter authority · O3 certifier identity (`CA_n`) · O4 revocation effective-cost metric · O5 breach and arbitration · O6 reversal-demonstration standard · O7 mapping to existing regulatory regimes (ERES-RRH work).

Genuinely open. Not closed by naming.

## Related instruments

ERES-BIOTREATY-2026-001 (parent, clause architecture) · ERES-CDFE-2026-001 (`n_eff`) · ERES-RROI-2026-001 (A0 offset axiom) · ERES-ARH-2026-001 (Independence Gate) · ERES-RRH-2026-001 (regulatory hardening) · ERES-CPROV-2026-001 (provenance).

## License

Creative Commons Attribution 4.0 International (CC BY 4.0). Attribute: Joseph Allen Sprute, ERES Institute for New Age Cybernetics.
