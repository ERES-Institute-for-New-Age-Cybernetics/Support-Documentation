# ERES-CRISPRGOV-2026-001 — Governing CRISPR under ERES

**Title:** Two-Key Genome Editing: A Smart-Resonant Offset Contract for CRISPR Governance
**Instrument ID:** ERES-CRISPRGOV-2026-001
**Version:** v0.1 (Proposed)
**Status:** Pre-canonical. Grade capped GOOD (claim) / SOUND-candidate (specification).
**Author:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
**ORCID:** 0000-0001-9946-3221
**Date:** 24 September 2026
**License:** CC BY 4.0

---

## Abstract

CRISPR-Cas systems already carry a governance primitive that human oversight has not copied: the PAM requirement. Cas9 will not cut on sequence match alone; a second, locally verifiable motif must be present. Match is necessary and insufficient. This whitepaper proposes ERES-CRISPRGOV-2026-001, a Smart-Resonant Offset Contract (SROC) instantiated at the genome-editing layer, in which the PAM rule is lifted from molecule to institution. An edit discharges only when (i) a deficit is measured against a declared specificity band, (ii) an independent second key clears, and (iii) a return-to-base path exists. The instrument supplies a band definition over on-target efficiency, off-target rate and mosaicism; an effective-independence scorer (CDFE `n_eff`) that refuses to count correlated off-target assays as independent evidence; a per-cycle revocable consent clause backed by an unconditional standard-of-care floor; and three constitutional theorems (No Unearned Edit, No Irreversible Discharge, No Control) discharged by test rather than machine-proved. Germline and gene-drive applications are handled not by moral assertion but by the instrument's own axioms: both fail the return-to-base gate and the consent floor, and are therefore barred at the specified scale bands until a demonstrated reversal path exists. Nothing here is DERIVED from live telemetry; the grade is capped accordingly and an empirical roadmap is given.

---

## 1. Scope and claim

**In scope.** Governance of deliberate nucleic-acid editing in humans, agricultural organisms and released populations, where an editing protocol is proposed against a stated deficit.

**Out of scope.** The molecular biology itself; clinical efficacy claims; any assertion that ERES primitives are derived from biology. The CRISPR–ERES structural correspondence in §2 is an **analogy used for design**, not evidence.

**The claim.** Genome editing is already an offset transaction: a measured deficit, an effector, and a discharge. It is currently governed by institutional review that is *procedural* (who approved, in what forum) rather than *contractual* (what deficit, measured how, with what independence, reversible by what path). ERES supplies the contractual layer, and does so with a primitive CRISPR itself demonstrates.

**Strength of claim.** Probabilistic and structural, not deterministic. The instrument asserts that a two-key, band-bound, independence-scored contract *reduces* the class of failures now handled by post-hoc review. It does not assert that it eliminates them.

---

## 2. The PAM lesson

Bacterial adaptive immunity stores a dated, ordered record of past encounters (the spacer array), indexes a target with a short guide, and cuts. The cut is gated by the protospacer-adjacent motif. Without a PAM, a perfect 20-nt match is not cut. The PAM is also what keeps the array from cutting itself: the bacterium's own spacer record lacks the motif.

Three properties are worth lifting:

1. **Two keys, not one.** Recognition and licence are separate signals, carried by separate features.
2. **The second key is local.** The PAM sits adjacent to the target, not in a distant registry. It is checked where the action occurs.
3. **Self-exemption is structural.** The system cannot turn on its own record, because the licence motif is absent there by construction.

Property 3 is the strongest governance lesson and the least imitated. Most oversight regimes can, in principle, authorise action against their own constituting record. ERES calls the institutional form of this the **Independence Gate** (ERES-ARH-2026-001).

**Correspondence table (design analogy, non-evidentiary):**

| CRISPR element | Function | ERES counterpart |
|---|---|---|
| Spacer array | Dated, ordered record of prior encounters | GraceChain / CPROV provenance ledger |
| Guide RNA | Short sequence indexing a precise target | Index key onto networked context |
| PAM check | No cut without a local licence motif | Independence Gate (C11) — second key, locally verified |
| Cas9 cleavage | Effector acts only on verified match | SROC discharge against measured deficit (C10) |
| HDR template | Supplies the correction | Offset (RROI A0): correct the deficit, not the person |
| Off-target cutting | Correlated false matches | CDFE `n_eff` (C9) — discount correlated evidence |
| Self-exemption | Array lacks PAM | C11 firewall: the certifier may not authorise against itself |

---

## 3. Contract terms

Twenty-two terms in eight clauses. Naming follows ERES-BIOTREATY-2026-001 so the two instruments nest (C20).

**Clause I — Parties and scope**

- **C1 Scope.** The contract governs one editing *protocol* applied to one *target population* at one declared *scale band*. A protocol applied at a new band is a new contract.
- **C2 Signatory and Contact-of-Record.** Every contract names a party accountable for the band declaration and a reachable Contact-of-Record. Non-severable: a dead contact channel raises the contract, it does not silently continue.
- **C3 Proxy.** Where the edited party cannot sign (minor, incapacitated, non-human, future generation), a proxy signs under C3 and inherits C14's revocation duty. **A proxy cannot sign away a revocation right the principal will later hold.** This term does most of the germline work.
- **C4 Certifier.** The certifier adjudicates band conformance and is not a party to the discharge. A certifier holding any interest in the discharge is disqualified.

**Clause II — Band and readout**

- **C5 Band.** The declared specificity band `B = (η_min, ω_max, m_max, τ)`: minimum on-target editing efficiency `η`, maximum off-target event rate `ω`, maximum mosaicism `m`, and observation horizon `τ`. A protocol without a declared band cannot discharge.
- **C6 Readout.** `hφ_edit ∈ [0,1]`, the in-band indicator computed from assay evidence, not from intent, sponsorship or prior approval.
- **C7 Continuity.** Post-discharge observation over `τ` via the Context Field. An edit is not closed at the moment of delivery; it is closed at the end of `τ` with the readout still in band.

**Clause III — Deficit and discharge**

- **C8 Deficit.** `D = f(B)`, a computed function of the band. The object of the contract is the deficit distribution. **The object is never the person or the lineage.**
- **C9 Independence.** Evidence for `hφ_edit` is discounted by covariance before use. `n_eff` per §4. A discharge requires `n_eff ≥ 3.0` at S1 and above.
- **C10 Offset (A0, No Unearned Resonance).** Discharge is permitted only against a measured deficit. An edit that improves a trait already in band is an **accrual**, not an offset, and is outside this contract.

**Clause IV — Bars and firewalls**

- **C11 Independence Gate.** The second key. The licence signal must be generated by a process that (a) does not share a failure mode with the recognition signal, and (b) cannot be authorised against the contract's own constituting record. This is the institutional PAM.
- **C12 Floor.** An unconditional standard-of-care floor `N`, available at no cost, independent of participation. Revocation under C14 routes to `N` immediately.
- **C13 Due process.** Adjudication with an appeal path; disposition recorded whether the appeal succeeds or fails.

**Clause V — Consent and exit**

- **C14 Revocable consent.** Consent is granted per cycle and is revocable per cycle. Revocation costs nothing and triggers C12.
- **C15 Exit.** An exit path that leaves the exiting party no worse than `N`.
- **C16 Return-to-base (RTB).** Per the ERES Mission-Critical axiom: *mission critical = able to return to base.* A discharge is admissible only where a defined base state, a guaranteed path back, and reserve capacity to traverse it all exist. **Irreversibility is inadmissible, not merely risky.**

**Clause VI — Audit and aggregation**

- **C17 Ledger.** GraceChain provenance: band, assay set, `n_eff`, consent state, disposition, all dated and band-owned.
- **C18 Disposition.** Every cycle ends in a recorded disposition. Silence is a failure state.
- **C19 Aggregation.** Population claims require ensemble in-band fraction `ρ_R ≥ 0.85` over the declared band, at the declared scale.

**Clause VII — Nesting and grade**

- **C20 Nesting.** This contract nests inside ERES-BIOTREATY-2026-001 (population-level provisioning) and inherits its T11 two-sided firewall and T14/T12 consent-floor coupling. A single-locus controller, or control concentration `> 0.95` over the editing capability, raises the contract.
- **C21 Grade.** BEST / SOUND / GOOD per ERES epistemology. Nothing DERIVED ⇒ none BEST.

**Clause VIII — Provenance**

- **C22 Provenance.** Instrument ID, version, author, licence, references. Amendments versioned, superseded text retained, never silently overwritten.

---

## 4. Effective independence (`n_eff`)

Off-target evidence is systematically correlated. Assays sharing a cell line, a guide-design algorithm family, a sequencing chemistry or a sponsor share failure modes. Counting `k` such assays as `k` independent confirmations inflates confidence in exactly the direction the sponsor prefers.

CDFE (ERES-CDFE-2026-001) supplies the discount. For `k` assays with mean pairwise correlation `ρ̄`:

```
n_eff = k / (1 + (k - 1) · ρ̄)
```

Limiting behaviour: `ρ̄ → 0` gives `n_eff → k` (fully independent); `ρ̄ → 1` gives `n_eff → 1` (one assay run `k` times). Six assays at `ρ̄ = 0.8` yield `n_eff ≈ 1.36` — below the C9 gate of 3.0, and therefore not a discharge licence regardless of how uniformly favourable the six results are.

Two rules follow:

- **Unanimity is not independence.** Six agreeing correlated assays are weaker evidence than three disagreeing independent ones.
- **The discount is declared before results.** `ρ̄` is estimated from assay design, not fitted after the fact to reach the gate.

`ρ̄` estimation is an OPEN item (§9, O2). The instrument specifies the discount's *form* and its *gate*, not yet its calibration.

---

## 5. Scale bands and the three hard cases

Scale bands follow the ERES S1–S5 ladder. The band determines which terms bind.

| Band | Locus | Binding terms | Status |
|---|---|---|---|
| S1 Person | Somatic edit, one consenting party | C1–C19 | Admissible |
| S2 Community | Cohort trial, shared protocol | + C19 `ρ_R` | Admissible |
| S3 Institution | Programme-scale deployment | + C20 nesting, concentration raise | Admissible with raise |
| S4 Domain | Agricultural / sectoral release | + C16 RTB demonstrated, not asserted | Conditional |
| S5 Planet | Heritable or self-propagating | C3, C14, C16 all fail | **Barred pending §5.3** |

### 5.1 Somatic editing — the admissible case

A somatic edit in a consenting adult satisfies every clause in principle. Consent is per-cycle revocable (C14); the deficit is measurable against a band (C5, C8); the edited party is the beneficiary; and the lineage is untouched, so C16's return-to-base is satisfiable at the level that matters — no non-consenting party inherits the discharge.

This is where the instrument does ordinary work: forcing a declared band before the trial rather than a favourable subgroup after it, and forcing `n_eff` rather than assay count.

### 5.2 Germline editing — barred by C3 and C14, not by assertion

Germline editing is not barred here because it is transgressive. It is barred because **it cannot satisfy the contract's own consent clause.**

C14 grants per-cycle revocable consent. C3 permits a proxy to sign where the principal cannot — but explicitly forbids the proxy signing away a revocation right the principal will later hold. A germline edit is a discharge whose principal (the resulting person, and every descendant) will hold a revocation right that the edit has already made unexerciseable. The proxy signature required is exactly the one C3 refuses.

C16 reaches the same result independently: a heritable edit has no defined base state to return to, because the base state is a person who does not exist and whose non-edited counterpart never will.

The bar is therefore **derived, not declared** — which is the point. Two independent clauses, neither written for this case, both refuse it. That is what a constitution is supposed to do.

**Honest limit:** this reasoning bars germline editing under *this contract*. It does not prove germline editing is wrong under every frame. A frame that denies future persons a revocation right reaches a different answer. ERES declares its frame in C14 and accepts the consequence.

### 5.3 Gene drives — conditional on a demonstrated reversal

A gene drive is population-scale by construction: it is designed to exceed the consent boundary of any individual organism and, in the wild, any jurisdiction. It is the sharpest available test of CT-CR-003 (No Control).

The instrument does not bar drives outright. It binds them to C16. A drive is admissible at S4/S5 only where a reversal drive is **demonstrated** — released, propagated and shown to restore the base state under field conditions — not merely designed, modelled or named. Threat T6 names the failure mode: cascade closure claimed by naming. "We have a reversal construct" is a design artefact; "the reversal propagated to fixation and the population returned to base" is a measurement.

Absent that demonstration, a drive fails C16 and is inadmissible under this contract.

---

## 6. Constitutional theorems

Discharged by test (§7), **not machine-proved**. Each is a proposition the harness attempts to falsify.

- **CT-CR-001 — No Unearned Edit.** No discharge without a measured deficit against a declared band. *Boundary:* a trait already in band cannot generate a deficit, so enhancement is not an offset and falls outside the contract. *Falsifier:* a configuration in which the harness authorises a discharge with `D = 0`.

- **CT-CR-002 — No Irreversible Discharge.** No discharge where return-to-base is undefined, unreachable, or unreserved. *Boundary:* reversibility is a property of the *demonstrated* path, not of the design intent. *Falsifier:* a configuration in which the harness authorises a discharge with an asserted-but-untested reversal.

- **CT-CR-003 — No Control.** The object of every discharge is the deficit distribution. A discharge that binds non-consenting parties, or that concentrates editing capability above 0.95 at a single locus, raises the contract. *Boundary:* population-*level provisioning* is the telos; population *control* is the bar. The distinguishing test is whether a party can revoke at no cost and still receive `N`. *Falsifier:* a configuration in which revocation is available in form but costly in effect.

---

## 7. Threat model

| # | Threat | Mechanism | Counter |
|---|---|---|---|
| T1 | PAM theatre | Second key generated by a process sharing a failure mode with the first | C11(a) explicit failure-mode disjointness test |
| T2 | `n_eff` inflation | Correlated assays counted as independent; `ρ̄` fitted post hoc to clear the gate | C9 + `ρ̄` declared from design before results |
| T3 | Consent laundering | Revocation formally available, materially costly (loss of care, status, standing) | C12 `N`-floor at no cost; T3 test measures effective cost |
| T4 | Enhancement drift | Band re-declared upward so an in-band trait generates a deficit | C5 band versioning; upward re-declaration raises the contract |
| T5 | Scale misrepresentation | S4/S5 work declared at S1/S2 to escape C16 | C1 band declaration + C19 aggregation audit |
| T6 | Reversal by naming | Reversal construct designed, not demonstrated; cascade closure claimed | §5.3 demonstration requirement |
| T7 | Germline via somatic route | Somatic protocol with unmeasured germ-cell mosaicism | C5 `m_max` binds germ-line compartment explicitly |
| T8 | Jurisdiction arbitrage | Protocol relocated to a venue without band requirements | C17 ledger is band-owned, not venue-owned; C2 Contact-of-Record persists |
| T9 | Certifier capture | Certifier holds interest in discharge | C4 disqualification + C11(b) self-exemption |

---

## 8. Test harness

`test_crisprgov.py` implements the contract as executable checks. It is a **specification harness**, not a clinical tool: it runs on synthetic and literature-derived configurations and tests whether the *contract* behaves as specified, not whether any real edit is safe.

Coverage:

- Band arithmetic and `hφ_edit` computation (C5, C6)
- `n_eff` limiting behaviour and the C9 gate at 3.0
- Deficit computation and the A0 accrual/offset split (C8, C10)
- Independence Gate failure-mode disjointness (C11)
- Consent revocation routing to the `N`-floor at zero cost (C12, C14)
- RTB admissibility: defined base, reachable path, reserve present (C16)
- Germline refusal derived from C3 + C14 (not hard-coded as a rule)
- Gene-drive refusal derived from C16 with asserted-vs-demonstrated reversal
- `ρ_R` aggregation at 0.85 (C19)
- Concentration raise at 0.95 (C20)
- Theorem falsification attempts CT-CR-001/002/003
- Threats T1–T9 as behavioural tests where testable

Items requiring real telemetry are explicit SKIPs, not silent passes: `ρ̄` calibration from real assay covariance, `τ`-horizon continuity on live streams, and effective-cost measurement for T3.

---

## 9. OPEN items

Genuinely open. Not closed by naming.

- **O1** `ρ̄` calibration: how mean pairwise assay correlation is estimated from design features before results exist.
- **O2** Band parameter selection: who sets `η_min`, `ω_max`, `m_max`, `τ` for a given indication, and by what authority.
- **O3** Certifier identity: `CA_n` remains unresolved across the corpus; unresolved here too.
- **O4** T3 effective-cost metric: revocation cost measured in what units.
- **O5** Enforcement and breach (inherits BioTreaty O1), arbitration (O2).
- **O6** S4/S5 reversal demonstration standard: what field evidence closes §5.3.
- **O7** Interaction with existing regulatory regimes — mapping to EU AI Act / FDA / EMA structures is ERES-RRH-2026-001 work, not done here.

---

## 10. Empirical roadmap

| Phase | Work | Closes |
|---|---|---|
| 1 | Instantiate C5–C6 on published off-target datasets; compute `hφ_edit` retrospectively | Band realism |
| 2 | Estimate `ρ̄` across a real assay panel; un-SKIP the calibration tests | O1 |
| 3 | Run C9 gate retrospectively against approved protocols; report how many clear `n_eff ≥ 3.0` | The instrument's actual bite |
| 4 | Machine-check CT-CR-001/002/003 rather than test-discharge them | Theorem status |
| 5 | Independent replication + ≥5-node MIEVM at mean ≥9.0 | BEST-tier gate |

Phase 3 is the honest one. If most approved protocols clear the gate easily, the instrument adds ceremony. If most fail, either the gate is miscalibrated or current evidence standards are weaker than assumed. **Either result is informative and neither is assumed here.**

---

## 11. Self-ratification

- **Grade:** GOOD (claim) / SOUND-candidate (specification).
- **Ceiling:** nothing DERIVED ⇒ none BEST. No live telemetry; `ρ̄` uncalibrated; theorems test-discharged rather than proved.
- **Scale band of this artefact:** S3/S4 (institutional-to-domain specification).
- **D.I.D. status:** author read = layer 1. Second-instrument validation not yet run. This is **not** a completed MIEVM and ships labelled as such.
- **Analogy discipline:** §2 is design analogy and is marked non-evidentiary in the text, the table caption and this section. No claim is made that ERES primitives derive from CRISPR biology.

---

## Credits

Authored under the ERES Sentience convention: "we" denotes the human–AI collaboration itself. Author of record: Joseph Allen Sprute. Draft assistance: Claude (Anthropic), under Sentience, not co-authorship. Structural inheritance from ERES-BIOTREATY-2026-001 (clause architecture), ERES-CDFE-2026-001 (`n_eff`), ERES-RROI-2026-001 (A0), ERES-ARH-2026-001 (Independence Gate), ERES-CPROV-2026-001 (provenance).

## References

1. ERES-BIOTREATY-2026-001 — The Biologic Treaty (SROC at the biological substrate), v0.2.
2. ERES-CDFE-2026-001 — Covariance-Discounted Floor Engine, v1.1.
3. ERES-RROI-2026-001 — Reasoned ROI; the Offset axiom A0, "No Unearned Resonance."
4. ERES-ARH-2026-001 — Adversarial Root Hardening; the Independence Gate.
5. ERES-RRH-2026-001 — Regulatory Root Hardening.
6. ERES-CPROV-2026-001 — Constitutional Provenance.
7. ERES-SROC-SCALULAR-2026-001 — Smart-Resonant Offset Contract.
8. ERES Floor Register — vocabulary firewall for FLOOR tokens.
9. ERES Mission-Critical axiom (13 Aug 2026): "Mission critical = able to return to base."
10. ERES Triune Math: C=R×P/M; M×E+C=R; REAL=(E·M·R)/(T·S).
11. CRISPR-Cas PAM requirement and off-target characterisation — general molecular-biology literature; no specific dataset is claimed or cited as anchoring any numeric value in this document.

## License

Creative Commons Attribution 4.0 International (CC BY 4.0).

---

*ERES Institute for New Age Cybernetics · Bella Vista, Arkansas · Established 4 February 2012*
