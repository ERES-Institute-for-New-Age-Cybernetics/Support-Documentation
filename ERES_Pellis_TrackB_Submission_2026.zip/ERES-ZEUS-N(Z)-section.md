# Section 6 — N(Z): The Normality-Defect Index ("ZEUS")
*Status: HYPOTHESIZED Tierpresentation Layer*

## 6.1 Mathematical Poles
The leverage operator $J$ transitions between two foundational operator-theory poles:
1. **Normal Regime ($N = +1$):** $J$ is normal ($JJ^* = J^*J$). Eigenvectors remain strictly orthogonal and angle-invariant. The condition number is minimized: $\kappa(V) = 1$.
2. **Defective Limit ($N \rightarrow -1$):** $J$ hits the exceptional point. Eigenvalues coalesce (United Spectrum), eigenvectors collapse parallel, and the condition number diverges: $\kappa(V) \rightarrow \infty$.

## 6.2 Index Definition
Using the Henrici departure-from-normality $\Delta(J) = \sqrt{\|J\|\mathstrut_F^2 - \sum_i |\lambda_i|^2}$:
$$N(Z) := 1 - \frac{2\Delta(J)}{\Delta(J) + \|J\|\mathstrut_F} \in (-1, 1]$$

## 6.3 ZEUS Naming Convention
- **Z**ipper: Reflects eigenvector geometry (orthogonal/open at $+1$, parallel/zipped at $-1$).
- **E**nergy: Inherits $\mathrm{Re}(\lambda)$ decay parameters from the REAL mapping layer.
- **U**nited **S**pectrum: Highlights eigenvalue coalescence at the collapse threshold.