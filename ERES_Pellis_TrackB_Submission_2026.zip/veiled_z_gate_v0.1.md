# VEILED-Z Gate: Conditioned-Response Suspension (v0.1)
*Runtime Containment Framework*

## 1. Mathematical Trigger
Near a second-order exceptional point, the Petermann factor exhibits a known scaling divergence:
$$K \sim \epsilon^{-1/2}$$

This means that the exact zone where spectral tracking becomes most critical is also where individual eigenvalue readouts become most volatile and susceptible to noise amplification. We define the runtime trigger:
$$\mathrm{VEILED\text{-}Z}(t) := \mathrm{TRUE} \quad \text{when} \quad |z(t)| < Z_{\mathrm{threshold}}$$

## 2. Gate Logic & Circuit-Breaker Behavior
- **IF $\mathrm{VEILED\text{-}Z}(t) = \mathrm{TRUE}$:**
  - **SUSPEND** any automatic conditioned-response rules firing directly off $z(t)$.
  - **HOLD** execution open pending independent non-spectral confirmation, time-averaging smoothing, or explicit manual review.
  - **DEFAULT** to the "One-Good" baseline action (the option minimizing systemic harm under maximum uncertainty).
- **ELSE:**
  - Permit normal automated conditioned-response execution.

This operationalizes the Runtime Containment Requirement (RCR) via an explicit physical mechanism (EP-driven mode coupling).