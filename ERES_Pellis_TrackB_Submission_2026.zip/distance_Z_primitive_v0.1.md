# Distance Z — Testable Primitive (v0.1)
*ERES Institute*

## 1. Formal Definition
To remove any floating definitions, "Distance Z from BEST/SOUND/GOOD (BSG2)" is tied directly to the system stability functional:
$$z(t) := \alpha(t) = \sup_{\lambda \in \sigma(L(t))} \mathrm{Re}(\lambda)$$

- When $z(t) > 0$ and shrinks toward 0, the cybernetic system is actively losing distance from the structural collapse threshold.
- $z(t) = 0$ represents the critical manifold ($M_c$) itself.
- $z(t) \rightarrow 0^-$ represents past-threshold degradation.

## 2. The BSG2 Bridge Hypothesis ($H_Z$)
The BSG2 triple-criterion filter is an independent ERES governance construct. The relationship between architectural health and physical stability is formalized as an open, checkable bridge hypothesis:

$$H_Z: \text{BSG2 status transitions monotonically toward FAIL as } z(t) \rightarrow 0$$

This framing ensures that the equivalence remains a testable correspondence claim rather than an unearned assumption.