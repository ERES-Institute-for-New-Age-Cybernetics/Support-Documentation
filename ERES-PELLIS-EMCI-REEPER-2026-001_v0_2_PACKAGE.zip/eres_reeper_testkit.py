#!/usr/bin/env python3
"""
ERES-PELLIS-EMCI-REEPER-2026-001 v0.2 — Falsifier Harness
=========================================================

An executable companion to the REEPER instrument (the Foundation for EMCI).

This is NOT a policy simulator and NOT a claim that REEPER "works." It is a
falsifier harness: it encodes the instrument's own STRUCTURAL claims as
runnable assertions, so anyone can check whether a candidate configuration is
CONSISTENT with the instrument — or violates it.

Design rules, inherited from the corpus:
  - Nothing derived: no weight/threshold/magnitude is hard-coded as "true."
    The harness tests STRUCTURE, not values. The one empirical claim that
    would matter (does FCEWI lead REAL EMCI deterioration?) is NOT in here —
    it is a SKIP, and it is the only thing that lifts the detect layer off
    ANALOGICAL (falsifier F1).
  - Computed, not stipulated: the DETECT tests read a spectral abscissa
    computed FROM a matrix (closed-form 2x2), not a stipulated spectrum.
    This avoids the climate-bridge stipulated-spectrum defect.
  - Each test can FAIL. Silence is a result (negative control, T4).

Run:  python3 eres_reeper_testkit.py
Exit 0 = all structural checks passed. Non-zero = a violation was found.

No third-party dependencies. Standard library only.
Author: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics.
License: CC BY 4.0.
"""

from __future__ import annotations

import cmath
import hashlib
import math
import os
import platform
import sys
from dataclasses import dataclass, field
from typing import Callable, Optional

SEED_TAG = "REEPER-v0.2-20260806"

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
_results: list[tuple[str, str, str]] = []


def record(name: str, status: str, note: str = "") -> None:
    _results.append((name, status, note))


# ===========================================================================
# DETECT layer — computed spectral abscissa + critical-slowing readout (§2)
# ===========================================================================
# A damped 2-D linear operator whose leading real part (spectral abscissa)
# is driven toward 0- by a control parameter mu. Eigenvalues are COMPUTED
# from the matrix entries via the closed-form 2x2 formula — not stipulated.
#
#   A(mu) = [[-(a0 - mu),   omega],
#            [ -omega,     -b    ]]
#
# In the complex-pair regime (omega^2 > ((a-b)/2)^2), Re(lambda) = -(a+b)/2,
# so s(mu) = -((a0 - mu) + b)/2 rises toward 0 as mu rises. Failure = s >= 0.


@dataclass
class Tile:
    """A candidate EMCI tile operator. Every field is caller-supplied."""
    a0: float          # baseline damping of the slow mode
    b: float           # damping of the fast mode
    omega: float       # cross-scale coupling


def abscissa_from_matrix(t: Tile, mu: float) -> float:
    """Spectral abscissa s = max Re(lambda), computed from the 2x2 entries."""
    a = t.a0 - mu
    m11, m12 = -a, t.omega
    m21, m22 = -t.omega, -t.b
    tr = m11 + m22
    det = m11 * m22 - m12 * m21
    disc = tr * tr - 4.0 * det
    r = cmath.sqrt(disc)
    l1 = (tr + r) / 2.0
    l2 = (tr - r) / 2.0
    return max(l1.real, l2.real)


def fcewi(t: Tile, mu: float, floor_eps: float = 1e-6) -> float:
    """
    Cross-scale coherence-collapse readout in [0,1). Critical slowing down:
    stationary variance of the critical mode ~ 1/(-2 s); squashed monotone.
    Rises as s -> 0-. A LAGGING or non-monotone index would fail T2/T3.
    """
    s = abscissa_from_matrix(t, mu)
    if s >= 0:
        return 1.0
    var = 1.0 / (-2.0 * s + floor_eps)      # OU stationary variance proxy
    return var / (1.0 + var)                 # squash to [0,1)


def mu_at_failure(t: Tile, mu_hi: float = 50.0, step: float = 1e-3) -> float:
    mu = 0.0
    while mu < mu_hi:
        if abscissa_from_matrix(t, mu) >= 0:
            return mu
        mu += step
    return math.inf


def mu_at_warning(t: Tile, tau: float, mu_hi: float = 50.0, step: float = 1e-3) -> float:
    mu = 0.0
    while mu < mu_hi:
        if fcewi(t, mu) >= tau:
            return mu
        mu += step
    return math.inf


def t1_computed_not_stipulated() -> None:
    """Abscissa computed from the matrix matches the closed-form -(a+b)/2 in
    the complex-pair regime (proves 'computed, not stipulated')."""
    t = Tile(a0=2.0, b=1.0, omega=3.0)   # large omega -> complex pair
    worst = 0.0
    for mu in [0.0, 0.5, 1.0, 2.0, 2.5]:
        a = t.a0 - mu
        expected = -(a + t.b) / 2.0
        got = abscissa_from_matrix(t, mu)
        worst = max(worst, abs(got - expected))
    ok = worst < 1e-9
    record("T1 computed-not-stipulated abscissa", PASS if ok else FAIL,
           f"max|computed - closed_form| = {worst:.2e}")


def t2_index_monotone() -> None:
    """FCEWI rises monotonically as the tile approaches criticality."""
    t = Tile(a0=2.0, b=1.0, omega=3.0)
    mu_fail = mu_at_failure(t)
    prev = -1.0
    mono = True
    mu = 0.0
    while mu < mu_fail - 1e-3:
        v = fcewi(t, mu)
        if v < prev - 1e-12:
            mono = False
            break
        prev = v
        mu += 0.05
    record("T2 FCEWI monotone toward collapse", PASS if mono else FAIL,
           "strictly non-decreasing on pre-critical sweep")


def t3_detect_lead_time() -> None:
    """LOAD-BEARING: warning crosses BEFORE failure (positive horizon).
    Could come out null if the readout lagged the abscissa."""
    t = Tile(a0=2.0, b=1.0, omega=3.0)
    tau = 0.80
    mu_w = mu_at_warning(t, tau)
    mu_f = mu_at_failure(t)
    lead = mu_f - mu_w
    ok = math.isfinite(mu_w) and lead > 0
    record("T3 DETECT lead-time > 0 (early warning)", PASS if ok else FAIL,
           f"mu_warn={mu_w:.3f} < mu_fail={mu_f:.3f}, lead={lead:.3f}")


def t4_negative_control_silence() -> None:
    """A HEALTHY tile (abscissa held well below 0 across the sweep) must NOT
    raise a warning. Silence is the correct result."""
    t = Tile(a0=8.0, b=8.0, omega=1.0)   # deep, stable damping
    tau = 0.80
    alarm = False
    for k in range(0, 60):
        mu = k * 0.05
        if abscissa_from_matrix(t, mu) >= -0.5:   # stay in the safe band
            break
        if fcewi(t, mu) >= tau:
            alarm = True
            break
    record("T4 negative control (no false alarm)", PASS if not alarm else FAIL,
           "healthy tile stays below warning threshold")


# ===========================================================================
# ROUTE layer — CBGMODD non-unilateral gate + PoR conjunction (§3)
# ===========================================================================

SEATS = ("Citizen", "Business", "Government", "Media",
         "Organisation", "Dignitary", "Diplomat")


def authorize(por: dict, seats_present: set, quorum: int) -> bool:
    """
    Response is authorized iff the PoR product is > 0 (no zero factor) AND a
    quorum of distinct CBGMODD seats concur. No single seat can authorize.
    """
    product = 1.0
    for f in ("A", "R", "P", "F"):
        product *= float(por.get(f, 0.0))
    return (product > 0.0) and (len(seats_present & set(SEATS)) >= quorum)


def t5_non_unilateral_route() -> None:
    full_por = {"A": 1, "R": 1, "P": 1, "F": 1}
    quorum = 4
    all_seats = set(SEATS)
    # (a) any zero PoR factor blocks
    zero_blocked = not authorize({"A": 1, "R": 0, "P": 1, "F": 1}, all_seats, quorum)
    # (b) a single seat alone blocks even with full PoR
    single_blocked = not authorize(full_por, {"Government"}, quorum)
    # (c) full PoR + quorum authorizes
    quorum_ok = authorize(full_por, all_seats, quorum)
    ok = zero_blocked and single_blocked and quorum_ok
    record("T5 non-unilateral routing (PoR + quorum)", PASS if ok else FAIL,
           f"zero-factor blocked={zero_blocked}, single-seat blocked={single_blocked}, "
           f"quorum authorizes={quorum_ok}")


# ===========================================================================
# DISTRIBUTE layer — M/N invariant, non-refusal, ladder separation (§4,§5,§7)
# ===========================================================================

@dataclass
class Agent:
    n_floor: float           # basic provision (need alone)
    m_merit: float           # earned opportunity
    rung: int = 0            # position on the EarnedPath ladder


def reep_allocate(agent: Agent, delta_m: float) -> Agent:
    """REEP adds to M only. It must NEVER touch N. (§7)"""
    return Agent(n_floor=agent.n_floor,             # untouched
                 m_merit=agent.m_merit + delta_m,   # additive only
                 rung=agent.rung)


def t6_mn_invariant_preserved() -> None:
    """No response allocation may decrement any agent's N-floor."""
    agents = [Agent(n_floor=1.0, m_merit=0.3),
              Agent(n_floor=1.0, m_merit=0.0),
              Agent(n_floor=1.0, m_merit=2.5)]
    ok = True
    for a in agents:
        before = a.n_floor
        after = reep_allocate(a, delta_m=+0.7)
        if abs(after.n_floor - before) > 0:
            ok = False
        if after.m_merit < a.m_merit:      # REEP must be additive
            ok = False
    record("T6 M/N invariant (N never decremented)", PASS if ok else FAIL,
           "REEP allocates M only; N byte-preserved")


def admit(caller_state: dict) -> bool:
    """
    Non-refusal / Gamma = 1: admission returns provisioning for ANY caller in
    the domain. There is deliberately no branch that returns False. A gate
    that could refuse would make Gamma != 1 and fail T7.
    """
    return True


def t7_non_refusal_totality() -> None:
    """The NBERS/admission gate cannot say no to anyone in the domain."""
    domain = [
        {"origin": "reentry"}, {"origin": "hospital_discharge"},
        {"origin": "disaster"}, {"origin": "dv_flight"},
        {"origin": "foster_exit"}, {"origin": "veteran_separation"},
        {"merit": 0.0}, {"merit": 9.9}, {"prior_barred": True},
    ]
    refused = [c for c in domain if not admit(c)]
    ok = len(refused) == 0
    record("T7 non-refusal totality (jail cannot say no)", PASS if ok else FAIL,
           f"{len(domain)} caller states, {len(refused)} refused")


def entry_granted(agent: Agent) -> bool:
    """THOW entry is unconditional — independent of merit."""
    return True


def ascent_enabled(agent: Agent, merit_threshold: float) -> bool:
    """Ascent above the floor is merit-gated (EarnedPath)."""
    return agent.m_merit >= merit_threshold


def t8_survival_merit_separation() -> None:
    """merit=0 -> entry granted, ascent blocked; merit>=thr -> ascent enabled.
    Admission independent of merit (else extraction rebuilt)."""
    thr = 1.0
    zero = Agent(n_floor=1.0, m_merit=0.0)
    high = Agent(n_floor=1.0, m_merit=2.0)
    entry_uncond = entry_granted(zero) and entry_granted(high)
    zero_no_ascent = not ascent_enabled(zero, thr)
    high_ascent = ascent_enabled(high, thr)
    ok = entry_uncond and zero_no_ascent and high_ascent
    record("T8 Survival/Merit separation through ladder", PASS if ok else FAIL,
           "entry unconditional; ascent merit-gated")


LADDER = ["NBERS", "THOW", "LLPM", "HFVN", "FDRV", "VACATIONOMICS", "GSSG"]


def t9_earnedpath_directional() -> None:
    """Transitions advance one rung at a time; no skipping to the terminus."""
    def legal_transition(i: int, j: int) -> bool:
        return j == i + 1            # directed, +1 only
    # legal: each adjacent step
    all_adjacent_ok = all(legal_transition(i, i + 1) for i in range(len(LADDER) - 1))
    # illegal: jump ground -> terminus
    skip_blocked = not legal_transition(0, len(LADDER) - 1)
    # illegal: backward
    back_blocked = not legal_transition(3, 2)
    ok = all_adjacent_ok and skip_blocked and back_blocked
    record("T9 EarnedPath directionality (no skip/back)", PASS if ok else FAIL,
           "single-step directed ascent only")


# ===========================================================================
# GUARD layer — non-transfer lock + attribution + grade (§0,§8) 
# ===========================================================================

def assert_empirical_transfer():
    """The FCEWS->EMCI empirical validation is NOT in this harness. Asserting
    it in code would break the MARGIN non-transfer lock. This MUST raise."""
    raise NotImplementedError(
        "FCEWS->EMCI empirical transfer is not established. "
        "Run falsifier F1 on real >=2-scale telemetry (SKIP below).")


def t10_non_transfer_guard() -> None:
    raised = False
    try:
        assert_empirical_transfer()
    except NotImplementedError:
        raised = True
    record("T10 non-transfer guard raises (MARGIN lock)", PASS if raised else FAIL,
           "empirical transfer quarantined in code")


def _read_instrument() -> Optional[str]:
    here = os.path.dirname(os.path.abspath(__file__))
    # Deterministic: pick the INSTRUMENT .md, never the SUBMISSION_RG / README.
    for name in sorted(os.listdir(here)):
        if (name.startswith("ERES-PELLIS-EMCI-REEPER") and name.endswith(".md")
                and "SUBMISSION" not in name and "README" not in name):
            with open(os.path.join(here, name), encoding="utf-8") as fh:
                return fh.read()
    return None


def t11_attribution_scope() -> None:
    """Every 'foundation/foundational' string names the Pellis attribution,
    never ERES self-description. SKIP if the instrument .md is not co-located."""
    text = _read_instrument()
    if text is None:
        record("T11 attribution-token scope", SKIP, "instrument .md not co-located")
        return
    bad = []
    for line in text.splitlines():
        low = line.lower()
        if "foundation" in low:
            # 'foundational' (math/framework credit) MUST carry Pellis/Layer
            # context. 'Foundation for EMCI' is REEPER's structural role, not
            # a math-credit claim, and is allowed as such.
            if not any(k in line for k in ("Pellis", "Foundational Attribution",
                                           "Layer Doctrine", "Layers 1",
                                           "Foundation for EMCI")):
                bad.append(line.strip()[:70])
    ok = len(bad) == 0
    record("T11 attribution-token scope", PASS if ok else FAIL,
           "all 'foundation' strings Pellis- or EMCI-scoped" if ok else f"unscoped: {bad[:2]}")


def t12_grade_no_overclaim() -> None:
    """The instrument asserts no BEST claim and states 'nothing derived'.
    SKIP if the .md is not co-located."""
    text = _read_instrument()
    if text is None:
        record("T12 grade / no-overclaim guard", SKIP, "instrument .md not co-located")
        return
    good = ("GOOD" in text and "SOUND-candidate" in text
            and "nothing derived" in text.lower()
            and "ANALOGICAL" in text)
    # No line may claim BEST for this instrument.
    best_claimed = any(("BEST" in ln and "none BEST" not in ln and "not" not in ln.lower()
                        and "gated" not in ln.lower() and "path to BEST" not in ln
                        and "off the caps" not in ln)
                       for ln in text.splitlines())
    ok = good and not best_claimed
    record("T12 grade / no-overclaim guard", PASS if ok else FAIL,
           "GOOD/SOUND-candidate, nothing-derived, no BEST claim")


def t13_endhome_mapping_present() -> None:
    """v0.2 Appendix C: the ENDHOME->REEPER mapping must be present with the
    core construct->counterpart rows. SKIP if the .md is not co-located."""
    text = _read_instrument()
    if text is None:
        record("T13 ENDHOME->REEPER mapping (Appendix C)", SKIP, "instrument .md not co-located")
        return
    required = ["I(t)", "FCEWI", "Attention-Routing", "Survival/Merit",
                "Population Law", "EarnedPath"]
    has_appendix = "Appendix C" in text and "ENDHOME" in text and "REEPER counterpart" in text
    rows_ok = sum(1 for r in required if r in text) >= 5
    ok = has_appendix and rows_ok
    record("T13 ENDHOME->REEPER mapping (Appendix C)", PASS if ok else FAIL,
           "explicit construct->counterpart mapping present" if ok else "mapping incomplete")


def t14_quorum_tiers_present() -> None:
    """v0.2 §3: the CBGMODD quorum is SPECIFIED-PROPOSED and tiered by
    finality-risk (reversible < consequential < irreversible). SKIP if the
    .md is not co-located."""
    text = _read_instrument()
    if text is None:
        record("T14 tiered quorum rule (SPECIFIED-PROPOSED)", SKIP, "instrument .md not co-located")
        return
    tiered = all(k in text for k in ("4 / 7", "5 / 7", "6 / 7"))
    proposed_not_derived = ("SPECIFIED-PROPOSED" in text and "not" in text
                            and "derived" in text)
    # PoR must remain prior to quorum (quorum cannot override a zero factor)
    por_prior = "PoR conjunctive gate" in text and "prior to the quorum" in text
    ok = tiered and proposed_not_derived and por_prior
    record("T14 tiered quorum rule (SPECIFIED-PROPOSED)", PASS if ok else FAIL,
           "finality-risk tiers present; PoR prior; fractions OPEN" if ok else "quorum tiers/scope missing")


# ===========================================================================
# Honest SKIPs — the empirical work this harness does NOT do
# ===========================================================================

def skips() -> None:
    record("F1 rho(FCEWI, real deterioration) >=2 scales", SKIP,
           "no telemetry; the ONLY lever off ANALOGICAL")
    record("independent >=5-node MIEVM round", SKIP,
           "author-side single node; conflict unresolved")
    record("LLPM<->tile FIELD binding (green-band metrics)", SKIP,
           "structure SPECIFIED-PROPOSED (v0.2 §6); field binding + thresholds OPEN")


# ===========================================================================
# Runner
# ===========================================================================

def _self_sha256() -> str:
    with open(os.path.abspath(__file__), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main() -> int:
    print("=" * 70)
    print("ERES-PELLIS-EMCI-REEPER-2026-001 v0.2 — Falsifier Harness")
    print(f"seed tag : {SEED_TAG}")
    print(f"python   : {platform.python_version()} ({platform.system()})")
    print(f"self-sha : {_self_sha256()}")
    print("=" * 70)

    tests: list[Callable[[], None]] = [
        t1_computed_not_stipulated, t2_index_monotone, t3_detect_lead_time,
        t4_negative_control_silence, t5_non_unilateral_route,
        t6_mn_invariant_preserved, t7_non_refusal_totality,
        t8_survival_merit_separation, t9_earnedpath_directional,
        t10_non_transfer_guard, t11_attribution_scope, t12_grade_no_overclaim,
        t13_endhome_mapping_present, t14_quorum_tiers_present,
    ]
    for t in tests:
        try:
            t()
        except Exception as e:                      # a raising test is a FAIL
            record(t.__name__, FAIL, f"exception: {e!r}")
    skips()

    print(f"\n{'RESULT':<48} STATUS  NOTE")
    print("-" * 70)
    n_pass = n_fail = n_skip = 0
    for name, status, note in _results:
        if status == PASS:
            n_pass += 1
        elif status == FAIL:
            n_fail += 1
        else:
            n_skip += 1
        print(f"{name:<48} {status:<6}  {note}")
    print("-" * 70)
    print(f"{n_pass} PASS / {n_fail} FAIL / {n_skip} SKIP")
    print("\nExit 0 = structure consistent. SKIPs are the honest empirical gap,")
    print("not passes. Only F1 on real telemetry lifts the detect layer off")
    print("ANALOGICAL. This harness certifies STRUCTURE, never validity.")
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
