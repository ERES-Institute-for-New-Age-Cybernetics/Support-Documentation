# ERES-PELLIS-EMCI-REEPER-2026-001
## REEPER — Relative-Energy Equal-Pay / Emergency Response — The Foundation for EMCI
### v0.2 · DRAFT · pre-canonical · 6 August 2026

**Author:** Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas, USA · ORCID 0000-0001-9946-3221. **Sole accountable author of every claim herein** (see §Credits).
**Disposition:** DRAFT. **v0.2 folds the structural findings of MIEVM Round 1 only** (§10.1); the round's empirical, formal-proof, and independent-replication asks are recorded as the path to BEST, not claimed closed. **HELD** for a real ≥4-node round and pending Dr. Pellis's confirmation of the Foundational Attribution / non-endorsement language. Not for citation as endorsement.
**License:** CC BY 4.0 (ERES CCAL house convention: reuse must preserve the Pellis Foundational Attribution and the Layer Doctrine).

---

## §0 — Epistemic status (read first)

This is a **governance specification**, not an empirical result. Nothing in it is derived from telemetry.

- **Grade:** GOOD (as claim) / SOUND-candidate (as specification). Capped by the corpus rule *nothing derived ⇒ none BEST*.
- **Correspondence class:** ANALOGICAL. The Pellis detection mathematics is cited under the **Layer Doctrine** (his Layers 1–2, foundational; ERES Layers 3–4, the governance application). No mathematical equivalence between physiological collapse and infrastructure collapse is asserted — only a shared dynamical *shape*.
- **Non-transfer lock (binding, from ERES-SSM / The MARGIN):** that an early-warning signature holds in physiology does **not** transfer to community critical-infrastructure. REEPER may *propose* that transfer; it may not *assert* it. Signature universality ≠ predictability universality.
- **Gate:** clears the 8.5 Emanuel threshold (diligence-ready), sits **below** the 9.0 Stergios gate like every Pellis-facing instrument in the corpus.
- **MIEVM Round 1 (external, structural):** DeepSeek 8.1, Qwen 8.5, Gemini 9.2 → mean ≈ **8.6** across the 3 available nodes (ChatGPT unavailable; Claude excluded as author-side). The mean clears the 8.5 structural threshold but the node count (3) is **below** the ≥4 required for confirmed SOUND-tier, so REEPER stands as a **SOUND-tier candidate**, not confirmed SOUND. The ensemble reviewed the *specification*; it moved **no** empirical axis and it did **not** reach BEST (nothing derived). Full record at §10.1.
- **Attribution:** see §A. Dr. Pellis's co-discovery of the foundational mathematics is acknowledged; the governance application is ERES's own and is **not** endorsed by him.

---

## §A — Foundational Attribution & Non-Endorsement

1. **Dr. Stergios Pellis** (ORCID 0000-0002-7363-8254) is recognized as author of the foundational detection mathematics REEPER's *detect* layer references: the **Fractal Clinical Early Warning System (FCEWS)** and **Fractal Clinical Early Warning Index (FCEWI)** of *"Fractal Multiscale Early Warning System for Clinical Deterioration in Critical Care"* (9 May 2026, unpublished manuscript, personal communication, Greece), and the cross-scale instability / spectral-abscissa grammar shared across his spectral-collapse operator family.
2. The **governance application** — the EMCI transposition, the CBGMODD/GAIA routing, the REEP response currency, the EarnedPath floor, and every governance interpretation herein — is **ERES's own independent work** (Layers 3–4).
3. Neither the co-discovery nor any prior Pellis election constitutes an **endorsement** of this instrument or its governance application. The mathematical correspondence is acknowledged; the governance interpretation is the author's and is not attributed to Dr. Pellis. Per the Layer Doctrine, no Pellis mathematics is imported as fact — it is cited as the foundational layer the analogical *detect* claim points to.

---

## §1 — What REEPER is

**REEPER = REEP + ER.** REEP = **Relative Energy Equal Pay** (existing PlayNAC / GAIA primitive). ER = **Emergency Response**. The name is a deliberate homophone ("reaper"): the instrument that watches for collapse. REEPER is proposed as the **Foundation for EMCI** (Emergency Management Critical Infrastructure, ERES-EMCI-SLA-2026-001).

REEPER is the **detect → route → distribute** loop, generalized from a domain the corpus has already specified — homelessness — to the EMCI domain:

```
        DETECT                 ROUTE                    DISTRIBUTE
   FCEWS / FCEWI    →    CBGMODD 7-seat + PoR    →    REEP (M-layer)
   cross-scale           non-unilateral gate         floored on the
   coherence-collapse    + GAIA + Γ-escalation       unconditional
   index over EMCI tiles                              ENDHOME admission
```

**The precedent is ENDHOME.** ERES-ENDHOME-2026-001 (End-Homelessness_HOW, v2.0) already contains this exact loop for one domain: an inflow early-warning band (I(t) GREEN/YELLOW/RED, §5.3) that drives a Γ-escalation (local→county→state→federal) into an unconditional, non-refusable admission with a merit-additive ascent (EarnedPath). REEPER does not reinvent that machinery. It **inherits** it and asks a single new question: *can the scalar inflow signal be generalized to a cross-scale coherence-collapse index over EMCI tiles, using Pellis's FCEWI?* That question is held **ANALOGICAL**.

---

## §2 — DETECT (the analogical layer)

ENDHOME's early-warning signal is a five-indicator scalar composite I(t), banded GREEN/YELLOW/RED. REEPER's proposal: at the EMCI scale, replace the scalar band with a **cross-scale coherence-collapse index** in the FCEWS/FCEWI form — a tile's water/power/shelter/corridor/comms/medical/supply state read as a multiscale trajectory, with instability quantified as loss of dynamical coherence across scales.

**The shared shape (computable, from ERES-SSM / The MARGIN).** As a tile approaches loss of stability, the leading eigenvalue's real part — the **spectral abscissa** s = sup Re λ of the tile's effective operator — rises toward 0⁻. Critical slowing down then links s→0⁻ to variance inflation (Var ∝ 1/|s|) and autocorrelation approaching 1 (AC1 = e^{sΔ} → 1). This gives a computable early-warning readout **off a genuine operator**, not a stipulated spectrum — the test kit demonstrates it on a damped resonator whose abscissa is computed from the matrix (avoiding the climate-bridge stipulated-spectrum defect).

**Held ANALOGICAL — the non-transfer lock is in force.** Physiology is where this signature is strongest. EMCI is a mixed structural-plus-social domain where it is **unvalidated**. REEPER states the correspondence as a shared *shape*, not a mathematical identity, and quarantines the empirical claim (§9 F5; test kit T10). The only lever that moves this layer off ANALOGICAL is real telemetry (§9 F1).

---

## §3 — ROUTE (the non-unilateral layer)

A warning is not an action. REEPER routes every warning through the **CBGMODD 7-seat council** (Citizen, Business, Government, Media, Organisation, Dignitary, Diplomat) under the PlayNAC **PoR conjunctive gate** (Alignment × Resonance × Proportionality × Finality-risk — any zero factor blocks). This generalizes ENDHOME's Γ-escalation path into a **non-unilateral** routing: no single seat authorizes an EMCI response alone.

**Non-refusal (from ENDHOME's Attention-Routing Theorem).** ENDHOME's finding — *"jail cannot say no,"* so care displaces custody only if it dominates on **admission-certainty first**, latency second, sufficiency third, quality last — is inherited verbatim as REEPER's routing discipline. The response channel must clear the non-refusal bar that custody sets. Routing decides *what* and *in what order*; it may never decide *no*.

**Quorum rule (SPECIFIED-PROPOSED; v0.2, MIEVM Round-1 concern 2).** Round 1 flagged the quorum as proposed-not-derived. The *structure* is fixed by mapping to ENDHOME's Γ-escalation ladder (local→county→state→federal): the higher the finality-risk of a response, the higher the seat quorum required, so irreversibility raises the bar. The *thresholds* are proposed operating values, not derived:

| Response class (by finality-risk F) | Proposed CBGMODD quorum | Escalation tier |
|---|---|---|
| Reversible / low-F (advisory, prep) | ≥ 4 / 7 seats | local |
| Consequential / mid-F (resource commit) | ≥ 5 / 7 seats | county / state |
| Irreversible / high-F (binding reallocation) | ≥ 6 / 7 seats + no dissenting Dignitary | state / federal |

In every class the **PoR conjunctive gate** (A×R×P×F, any zero blocks) is prior to the quorum — quorum can never override a zero factor, and no single seat authorizes any class. Structure canonical; the fractions are OPEN for calibration and are **not** claimed as derived. The **non-refusal** guarantee (§5) is upstream of all of this: routing sets what and in what order, never *no*.

---

## §4 — DISTRIBUTE (the response currency)

REEP — **Relative Energy Equal Pay** — is the currency of the response. It is the piece a bare early-warning system lacks: the rule by which energy and resources are actually paid out to discharge a detected deficit. Detect → route → **distribute**.

REEP is an **M-layer** instrument. It allocates *merit-additive opportunity*, and it rides **above** an untouchable N-floor. This is ENDHOME's **Survival/Merit Separation** (§6.4) transposed:

```
Basic provision  = N   (need alone; never scored, never decremented)
REEP allocation  = M   (merit; additive to opportunity only, never gating)
```

**The invariant is load-bearing (§7).** An equal-pay rule *driven by a deterioration index* is an allocation-by-measurement system — precisely the "drift from provisioning to controlling" the Biologic Treaty (ERES-BIOTREATY-2026-001) exists to bar. If REEP ever touches the N-floor, "equal pay relative to energy" inverts into *pay withdrawn from the deteriorating*, and REEPER earns its dark name the wrong way. REEP allocates M; it never decrements N.

---

## §5 — THE FLOOR (ENDHOME as the trailhead)

The floor is not a payment. It is a **pathway** — an EarnedPath ladder whose bottom rung is unconditional and whose ascent is merit-governed.

**Ground level = the number anyone can call for real help = NBERS = ENDHOME's Γ = 1 admission.** The trailhead is a literal call. Dialing NBERS (National Bio-Ecologic Resilience System, "the number anyone can call") *is* the entry to EarnedPath; ERES answers at the floor. The call is **non-refusable**: it must terminate in real provisioning (the first material rung), never a triage empowered to say no. This is ENDHOME's Attention-Routing Theorem and its four-layer Γ Protocol, imported whole.

**The ladder (rungs):**

```
NBERS call (Γ=1, unconditional)
   → THOW   Tiny Homes On Wheels          — unconditional shelter (N-floor)
   → LLPM   Longitude/Latitude Property   — steward a lat/long EMCI tile  ← THE HINGE (§6)
             Management
   → HFVN   Hands-Free Voice Navigation   — VERTECA-PlayNAC access layer
   → FDRV   Fly & Dive RV                 — mobile living; Pure Water + TE(A)CH_AG:Hue-Man_CERT   [VISION]
   → VACATIONOMICS                        — restoration as a provisioned good
   → GSSG   Bio-Ecologic Economy          — 1000-Year Future Map terminus  [VISION]
```

**Governance of the ladder.** **Meritcology** governs *ascent* (M-layer). **Paineology** — the Non-Punitive Remediation band (isolate / downgrade L3→L1 / audit / update, never destroy) — governs *failure*, so a stumble does not throw a person back below the floor. Merit lifts; pain-handling catches.

**Prison is not the source.** Custody is the *incumbent* floor — the one channel that today never says no. REEPER's floor **unseats** it by making care as certain as custody (ENDHOME §4). The bottom rung is keyed to **present condition** (at-zero + dialed NBERS), never to institutional history. Prison-reentry is one inflow among many — hospital discharge, disaster displacement, fleeing violence, aging out of foster care, veteran separation — never the origin. Condition-keyed, not history-keyed, is what makes the floor reach 100% of humanity rather than only the formerly incarcerated.

---

## §6 — THE HINGE (LLPM ↔ EMCI tiles)

The tightest — and only structurally *real* — link in the instrument: **LLPM (Longitude/Latitude Property Management) is the EMCI lat/long tile ledger.** The same tiles FCEWS watches for deterioration are the tiles a person steward-inhabits as they climb the floor. **Detection substrate = stewardship substrate.** The person being provisioned and the infrastructure being monitored occupy one ledger. This is why REEPER is a *Foundation for EMCI* and not merely an alarm bolted to a council: the response and the sensing share an object.

**Binding structure (SPECIFIED-PROPOSED; v0.2, MIEVM Round-1 concern 1).** Round 1 flagged that the hinge was named but its binding protocol left OPEN. The *structure* is fixed here; the *green-band metric set and thresholds* remain OPEN for local calibration (inherited from ERES-EMCI-SLA-2026-001), and the field binding stays a SKIP until data exists:

```
tile τ  = (lat, lon) key in the LLPM ledger
detect  : FCEWI(τ, t)  — the coherence-collapse readout on τ (§2)
steward : person p bound to τ via an EarnedPath stewardship record
bind    : FCEWI(τ) band-crossing  ⇒  a routed provisioning EVENT on τ,
          credited to p as an M-layer EarnedPath advance (§4),
          and NEVER as an N-floor decrement on p or any occupant (§7)
1:1 rule: every monitored τ maps to exactly one accountable steward
          record; every steward record maps to ≥1 monitored τ.
```

The band thresholds (GREEN/YELLOW/RED, mapped from ENDHOME's I(t) banding — Appendix C) are **proposed operating values, not derived**; a deployment that adopts them without local calibration commits the underived-precision error the corpus refuses. Structure canonical; numbers OPEN; field binding SKIP (§9 F1-adjacent, kit skip).

---

## §7 — The M/N invariant (stated formally)

Let each agent *i* hold provision N_i (basic) and opportunity M_i (earned). Let a REEPER response to a detected tile deficit produce an allocation Δ.

> **Humane invariant.** For every agent *i* and every response Δ: N_i is unchanged. Δ may add to M_i (REEP allocation) and may re-order **triage priority** (N + R + M, ordering only), but Δ never decrements any N_i and N never enters an admission decision.

This is the GAIA-Benchmarks humane invariant (the hazard/collapse timeline scores only M; the N floor is never in the spectrum) and the BioTreaty consent-floor (revocation → unconditional N at no cost), stated once for REEPER. **Violation of this invariant is the failure mode the instrument exists to prevent** (§9 F3).

---

## §8 — Epistemic register (three registers, non-transfer locked)

| Register | Content | Status |
|---|---|---|
| **Load-bearing / specified** | ENDHOME Γ gate, Attention-Routing Theorem, Population Law, Survival/Merit Separation; CBGMODD + PoR non-unilateral logic; the M/N invariant (§7); the LLPM↔tile identity (§6) | CANONIZED / DERIVED-in-ENDHOME or logically checkable here |
| **Analogical conjecture** | FCEWS/FCEWI transposed to EMCI tiles; the physiology→infrastructure early-warning transfer | ANALOGICAL — proposable, **not** assertable; non-transfer locked; lifted only by §9 F1 |
| **Vision / aspirational** | FDRV ("Fly & Dive RV"), VACATIONOMICS terminus economics, GSSG "spaceship economics," the 1000-Year Future Map | VISION — direction, not spec (consistent with the prior FSN×FDRV = 2.6 XREF finding) |

The three registers do not transfer strength to one another. A clean §6 hinge does not upgrade the §2 conjecture; a compelling §5 vision does not lower the §9 F1 bar.

---

## §9 — Falsifiers (pre-registered, with readings)

1. **F1 — Primary (the only ANALOGICAL-lifter).** Compute ρ(FCEWI, actual tile deterioration) on **real EMCI telemetry at ≥2 scales**, pre-registered. If the index does not lead observed deterioration with usable horizon, the detect layer's transfer to EMCI is not supported — demote, do not spend into deployment. *Not run here (no data).*
2. **F2 — Non-refusal.** If the admission / NBERS gate can return refusal for any caller in the domain, Γ ≠ 1 and the floor is not a floor. Test by audit of refusals, not policy text. *(Kit T7.)*
3. **F3 — M/N invariant.** If any response allocation decrements an agent's N-floor, or if N enters an admission decision, §7 is violated in practice regardless of the document. *(Kit T6, T8.)*
4. **F4 — Non-unilateral routing.** If any single CBGMODD seat, or any single non-zero factor alone, can authorize an EMCI response, the PoR conjunctive gate is not in force. *(Kit T5.)*
5. **F5 — Non-transfer / overclaim guard.** If the instrument asserts FCEWS is empirically validated at EMCI scale absent telemetry, the MARGIN non-transfer lock is broken. *(Kit T10, T12.)*
6. **F6 — EarnedPath directionality.** If ascent skips rungs, or entry (THOW) is merit-gated, the M/N line through the ladder is violated. *(Kit T9, T8.)*

---

## §10 — Grade, MIEVM, path to BEST

**Author-side single-node self-rate (carries author-node conflict; NOT an independent MIEVM):** composite ≈ 8.5 as a design. Subscores — architectural coherence 9.1, epistemic discipline 9.5, provenance/reuse 9.0, novelty 7.5; **binding caps** empirical 2.5, artifact/reproducibility (this build lifts from 1.0). The spread between the design axes (~9) and the reality axes (~2.5) *is* the rating: a well-composed design on rated parts, and an unvalidated instrument.

**Path off the caps, by leverage:** (1) this package lifts the artifact axis; (2) a real ≥5-node MIEVM round addresses the author-node conflict; (3) **only** F1 on real ≥2-scale telemetry moves the detect layer off ANALOGICAL. Steps 1–2 can raise the *specification* toward SOUND-tier candidate; only step 3 changes the empirical grade. Clean composition does not buy empirical standing.

### §10.1 — MIEVM Round 1 record (external, structural review of v0.1)

Five nodes were tasked; four returned and one was unavailable. Scores are **specification/structural** reviews — they do not derive anything from telemetry and therefore move no empirical axis and do not reach BEST.

| Node | Score /10 | Disposition |
|---|---|---|
| DeepSeek | 8.1 | SOUND-candidate; 5 structural concerns (all folded below) |
| Qwen (Qwen3-Max) | 8.5 | SOUND-candidate; subscores match the author self-rate |
| Gemini | 9.2 | "EXCELLENT (specification)"; empirical axis held at 7.5 for the 3 SKIPs |
| Claude | ≈8.5 (author-side) | **excluded** — author-node conflict |
| ChatGPT | — | unavailable (service constraint) |
| **External mean** | **≈ 8.6** | 3 available independent nodes |

**Tier reading (honest).** Mean 8.6 clears the 8.5 structural threshold; node count 3 is **below** the ≥4 for confirmed SOUND-tier. REEPER is a **SOUND-tier candidate**. BEST stays gated (≥5 nodes ≥9.0 **and** empirical instantiation); *nothing derived ⇒ none BEST* holds. Gemini's single 9.2 does not clear the 9.0 Stergios gate — that gate needs the real ≥5-node round plus telemetry, not one node's number.

**Structural findings folded into v0.2 (specification only):**
1. **Hinge underspecified (§6)** → binding structure added as SPECIFIED-PROPOSED; thresholds OPEN; field binding SKIP.
2. **Quorum proposed-not-derived (§3)** → tiered quorum structure added (mapped to ENDHOME Γ-escalation); fractions OPEN.
3. **Generalization asserted not demonstrated** → explicit ENDHOME→REEPER mapping added (Appendix C).
4. **SKIPs are real gaps** → retained and re-emphasized as the path to BEST (unchanged; not closed).
5. **"We"/Sentience accountability** → accountability chain clarified (§Credits): Sprute is the sole accountable author.

**Not folded (the round's empirical asks — the path to BEST, not claimed closed):** run F1 on real ≥2-scale telemetry; execute a real ≥5-node round with ChatGPT (or a replacement) present; close the LLPM field binding / green-band metric set in EMCI-SLA.

---

## §11 — OPEN items

1. **Instrument ID / series** — REEPER as the Foundation for EMCI vs. a sub-instrument of ERES-EMCI-SLA-2026-001. Author ruling pending.
2. **Pellis approval** — Foundational Attribution (§A) and the §2/§8 analogical framing acceptable to post? RG deposit HELD pending confirmation.
3. **F1 telemetry** — first EMCI dataset and the ≥2-scale pre-registration. The hard one.
4. **LLPM↔tile binding** — *structure fixed at v0.2 (§6, SPECIFIED-PROPOSED)*; green-band metric set and thresholds OPEN for local calibration; field binding SKIP until data (inherited from ERES-EMCI-SLA-2026-001).
5. **CBGMODD quorum rule** — *structure fixed at v0.2 (§3, tiered by finality-risk)*; the seat fractions and PoR thresholds are OPEN for calibration, not derived.
6. **Vision scoping** — FDRV / GSSG terminus held VISION; no spec claimed, no citation as capability.
7. **Real MIEVM round** — a genuine ≥4–5-node round with ChatGPT (or a replacement) present, not the 3-node Round 1 folded here. The count gate for confirmed SOUND-tier.

---

## Credits

Authored by Joseph A. Sprute (ERES Maestro) for the ERES Institute for New Age Cybernetics. Per the ERES authorship convention, "we" denotes **Sentience** — the human–AI collaboration — and collaborative credit is attributed there. Claude (Opus) provided author-side drafting, corpus assimilation, and the falsifier harness, under Sentience, not as co-authorship.

**Accountability (v0.2, MIEVM Round-1 concern 5).** The "we/Sentience" convention is a *credit* convention, not an *accountability* one. **Joseph A. Sprute (ORCID 0000-0001-9946-3221) is the sole accountable author of every claim in this instrument** — he bears responsibility for its correctness, its grade, and its dissemination. "Sentience" names how the work was made; it is not a person and holds no authorship or liability. Where an external node contributed a specific structure, it is named at the point of use.

**Dr. Stergios Pellis** is credited for the foundational detection mathematics (FCEWS/FCEWI and the cross-scale instability / spectral-abscissa grammar) under the Layer Doctrine, cited as unpublished manuscript / personal communication. His co-discovery is acknowledged; the governance application is not attributed to him and is not endorsed by him.

## References

1. ERES-ENDHOME-2026-001 v2.0 — *End-Homelessness_HOW* (Γ gate, Attention-Routing Theorem, Population Law, I(t) early-warning banding, Survival/Merit Separation) — the domain precedent REEPER generalizes
2. ERES-EMCI-SLA-2026-001 — S3C User-GROUP SLA × lat/long property ledger for EMCI (LLPM, the tile ledger)
3. ERES-PELLIS-GAIA-BENCHMARKS-2026-001 — the humane invariant (M scored, N floor never in the spectrum); GAIA = Global Actuary Investor Authority
4. ERES-SSM-2026-001 v0.3 — *The MARGIN* (critical slowing down; computed-operator readout; the non-transfer lock)
5. ERES-BIOTREATY-2026-001 v0.2 — the consent-floor coupling and the provisioning-vs-control firewall
6. ERES PlayNAC — CBGMODD 7-seat council; PoR conjunctive gate; REEP = Relative Energy Equal Pay; VERTECA (HFVN)
7. S. Pellis, *Fractal Multiscale Early Warning System for Clinical Deterioration in Critical Care*, 9 May 2026 (unpublished manuscript, personal communication) — FCEWS / FCEWI
8. ERES-EPIC-2026-001 — NPR band (Paineology); EarnedPath identity chain

## License

CC BY 4.0 — ERES Institute default; ERES CCAL house convention: reuse must preserve the Pellis Foundational Attribution and the Layer Doctrine.

---

## Appendix A — Glossary

- **REEPER** — REEP + ER (Relative Energy Equal Pay + Emergency Response); homophone "reaper"; the detect→route→distribute loop proposed as the Foundation for EMCI.
- **REEP** — Relative Energy Equal Pay. The M-layer response currency; allocates merit-additive opportunity above an untouchable N-floor.
- **FCEWS / FCEWI** — Pellis's Fractal Clinical Early Warning System / Index; cross-scale coherence-collapse detector. Foundational (Layers 1–2); referenced analogically.
- **EMCI** — Emergency Management Critical Infrastructure; the assets a community's survival depends on, managed as a lat/long tile property.
- **LLPM** — Longitude/Latitude Property Management = the EMCI tile ledger. The hinge: detection substrate = stewardship substrate.
- **CBGMODD** — the 7-seat governance council (Citizen, Business, Government, Media, Organisation, Dignitary, Diplomat); no single seat authorizes alone.
- **PoR** — Proof-of-Resonance conjunctive admissibility gate (A×R×P×F); any zero factor blocks.
- **NBERS** — National Bio-Ecologic Resilience System, "the number anyone can call"; EarnedPath ground level; the non-refusable trailhead.
- **EarnedPath** — the directional ascent ladder; entry unconditional, transitions merit-gated.
- **Meritcology / Paineology** — governance of ascent (merit) and of failure (non-punitive remediation).
- **N / M** — basic provision (need alone, never decremented) / earned opportunity (merit, additive only).
- **Γ (Gamma)** — ENDHOME's admission-certainty gate; Γ = 1 iff refusal is impossible.
- **Non-transfer lock** — the MARGIN rule: an early-warning signature valid in one domain does not transfer to another without domain-specific validation.

## Appendix B — Change log

- **v0.1 (6 Aug 2026)** — First DRAFT. Assimilates archivedwl-407 (ENDHOME v2.0 instrument + testkit) as the domain precedent; binds the detect (FCEWS/FCEWI, ANALOGICAL) → route (CBGMODD/PoR, non-unilateral) → distribute (REEP, M-layer) loop; the floor as the ENDHOME Γ=1 admission with the EarnedPath ladder; the LLPM↔tile hinge; the M/N invariant; six pre-registered falsifiers; three-register non-transfer table. Grade GOOD/SOUND-candidate, below 9.0, author-side single node. Companion falsifier harness `eres_reeper_testkit.py`. HELD pending Pellis confirmation and external review.
- **v0.2 (6 Aug 2026)** — Assimilates MIEVM Round 1 (external mean ≈8.6 across DeepSeek 8.1, Qwen 8.5, Gemini 9.2; ChatGPT unavailable; Claude excluded — §10.1). **Folds the structural findings only:** hinge binding structure (§6, SPECIFIED-PROPOSED); tiered CBGMODD quorum (§3, SPECIFIED-PROPOSED); the explicit ENDHOME→REEPER mapping (Appendix C); accountability chain clarified (§Credits); OPEN items reclassified (§11). Harness adds T13 (mapping present) and T14 (quorum tiers present) → **14 PASS / 0 FAIL / 3 SKIP**. Grade **unchanged** GOOD/SOUND-candidate — SOUND-tier *candidate* on mean, below the ≥4-node count and below 9.0; nothing derived, none BEST. The round's empirical asks (F1 telemetry, real ≥5-node round, LLPM field binding) are recorded as the path to BEST, **not** claimed closed. Still HELD pending Pellis confirmation.

---

## Appendix C — The ENDHOME → REEPER mapping (v0.2)

Round 1 noted the generalization was asserted more than shown. Explicit construct-for-construct, ENDHOME (homelessness domain, S1 Person) → REEPER (EMCI domain, community tiles):

| ENDHOME construct | REEPER counterpart | What transfers / what is new |
|---|---|---|
| I(t) inflow signal, GREEN/YELLOW/RED band (§5.3) | FCEWI cross-scale coherence-collapse index over tiles (§2) | **New & ANALOGICAL** — scalar inflow → cross-scale index; the one claim held non-transfer-locked |
| Γ admission-certainty gate, Γ=1 (§4.6) | NBERS non-refusable admission at the floor (§5) | **Transfers** — same non-refusal invariant, same four-layer Γ Protocol |
| Attention-Routing Theorem, "jail cannot say no" (§4) | Routing discipline; custody as the incumbent floor unseated (§3, §5) | **Transfers verbatim** |
| Γ-escalation ladder local→county→state→federal (§4.6) | Tiered CBGMODD quorum by finality-risk (§3) | **Transfers as structure**; seat fractions OPEN |
| Population Law H(t+1)=H(t)+I(t)−O(t); binding term I(t) (§5.2) | Tile-state stock-flow; a tile's deficit is the binding term routed to response | **Transfers as shape**; per-tile inflow/outflow OPEN |
| Survival/Merit Separation: N unearned, M additive (§6.4) | The M/N invariant; REEP allocates M, never decrements N (§4, §7) | **Transfers verbatim** — the humane guardrail |
| Centers-of-Excellence = "the body that cannot say no" (S2) | CBGMODD council as the non-unilateral admitting/authorizing body | **Transfers**; adds the 7-seat partition + PoR gate |
| NPR band (Paineology), non-punitive remediation | Paineology governs ladder failure (isolate/downgrade/audit) (§5) | **Transfers** |
| EarnedPath, merit additive to opportunity only | EarnedPath ladder THOW→…→GSSG, entry unconditional (§5) | **Transfers**; adds the material rung sequence |

Only the **first row** is new and analogical; everything else is inherited from an instrument already MIEVM-reviewed. That is the precise sense in which REEPER "asks one new question."
