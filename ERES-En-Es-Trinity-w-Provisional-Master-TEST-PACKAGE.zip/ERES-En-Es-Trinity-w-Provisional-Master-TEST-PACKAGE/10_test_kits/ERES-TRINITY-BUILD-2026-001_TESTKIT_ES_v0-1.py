#!/usr/bin/env python3
"""
ERES-TRINITY-BUILD-2026-001 — Instrumento de Prueba  (v0.1)  [ES]
================================================================
Prueba de conformidad autocontenida para la cascada del Trinity Build:

    10 áreas (materia) x 6 dominios (ciclo de vida) -> 3 propietarios
    (BEST/SOUND/GOOD) -> 1 concentrador TRINITY

Codifica la estructura canónica del ERES NAC Dual-Axis y afirma las invariantes
en que se apoya el simulador RA/RV. Sin dependencias externas; ejecutar:

    python3 ERES-TRINITY-BUILD-2026-001_TESTKIT_ES_v0-1.py

Código de salida 0 = todo en verde.  Autor: Joseph A. Sprute (ERES Maestro).
Licencia: CCAL v2.1 / CC-BY 4.0.

Nota: los tokens canónicos (GOOD/SOUND/BEST, nombres de nodo y de dominio) y los
identificadores de código se conservan en su forma original; los mensajes de
prueba están en español.
"""

import sys

# --------------------------------------------------------------------------
# ESTRUCTURA CANÓNICA (según el ERES NAC Dual-Axis)
# --------------------------------------------------------------------------

# Capa A - las 10 áreas de materia (el anillo). Partición: un doc trata de un área.
AREAS = [
    "Orientation", "PlayNAC", "Livelihood", "Law", "Identity-Security",
    "Health-Body", "Environment-GAIA", "Data-Architecture",
    "Skills-EarnedPath", "Reference-Desk",
]

# Capa B - los 6 dominios, ordenados como el ascenso de valor Proof -> Market (Niveles 1-6).
DOMAINS = ["Proof", "Gate", "Wheel", "Light", "Harvest", "Market"]

NODE = {  # dominio -> (nivel, código de nodo)
    "Proof":   (1, "ERES"),
    "Gate":    (2, "VERTECA"),
    "Wheel":   (3, "SECUIR"),
    "Light":   (4, "CyberRAVE"),
    "Harvest": (5, "GunnySack"),
    "Market":  (6, "SaleBuilders"),
}

# Capa C - los 3 propietarios. Cada uno posee exactamente dos dominios (el apareamiento).
OWNER_OF = {
    "Proof": "GOOD", "Market": "GOOD",      # los extremos
    "Gate": "SOUND", "Wheel": "SOUND",      # el flujo
    "Light": "BEST", "Harvest": "BEST",     # la cima
}

OWNERS = {  # propietario -> (insignia, principio, tótem)
    "GOOD":  ("diamond", "M", "Pato"),
    "SOUND": ("star",    "R", "Águila"),
    "BEST":  ("hex",     "P", "Halcón"),
}

# Aritmética canónica de propietarios (Dual-Axis): GOOD x BEST = 72, 72 x 3 = 216 = SOUND
OWNER_PRODUCT_GOOD_BEST = 72
SOUND_VALUE = 216

# Capa D - el 1 concentrador.
HUB = "TRINITY"


# --------------------------------------------------------------------------
# LÓGICA DE REFERENCIA (lo que usará el ingest del simulador)
# --------------------------------------------------------------------------

def derive_owner(domain):
    """El propietario es derivable del dominio; el ingest lo usa para señalar discrepancias."""
    return OWNER_OF[domain]


def owner_pairs():
    """propietario -> los dos dominios que posee."""
    pairs = {o: [] for o in OWNERS}
    for d in DOMAINS:
        pairs[OWNER_OF[d]].append(d)
    return pairs


def trinity_complete(lit_cells):
    """
    lit_cells : iterable de (área, dominio) que contienen >=1 documento.
    Trinidad-completa si y solo si cada propietario tiene AMBOS dominios encendidos
    en >=1 área. (Criterio de cierre — estrictamente más débil que la cuadrícula completa.)
    """
    lit_domains = {d for (_a, d) in lit_cells}
    for owner, doms in owner_pairs().items():
        if not all(d in lit_domains for d in doms):
            return False
    return True


def validate_binding(area, domain, declared_owner):
    """Devuelve la lista de problemas de una vinculación de documento (vacía = OK)."""
    problems = []
    if area not in AREAS:
        problems.append(f"área desconocida '{area}'")
    if domain not in DOMAINS:
        problems.append(f"dominio desconocido '{domain}'")
    elif declared_owner != derive_owner(domain):
        problems.append(
            f"discrepancia de propietario: declarado '{declared_owner}', "
            f"el dominio '{domain}' deriva '{derive_owner(domain)}'"
        )
    return problems


# --------------------------------------------------------------------------
# ARNÉS DE PRUEBA
# --------------------------------------------------------------------------

_results = []

def check(name, cond):
    _results.append((name, bool(cond)))
    print(f"  [{'ÉXITO' if cond else 'FALLO'}] {name}")


def run():
    print("ERES-TRINITY-BUILD-2026-001 - prueba de conformidad de la cascada [ES]\n")

    # T1 - cardinalidad de la cascada 10 x 6 -> 3 -> 1
    check("T1  cardinalidad 10 áreas", len(AREAS) == 10)
    check("T1  cardinalidad 6 dominios", len(DOMAINS) == 6)
    check("T1  cardinalidad 3 propietarios", len(OWNERS) == 3)
    check("T1  cardinalidad 1 concentrador", HUB == "TRINITY")

    # T2 - el orden de dominios es el ascenso Proof->Market, niveles 1..6 contiguos
    levels = [NODE[d][0] for d in DOMAINS]
    check("T2  los niveles son 1..6 en orden", levels == [1, 2, 3, 4, 5, 6])
    check("T2  Proof es Nivel 1 (base del ascenso)", NODE["Proof"][0] == 1)
    check("T2  Market es Nivel 6 (ápice del ascenso)", NODE["Market"][0] == 6)

    # T3 - el apareamiento: cada dominio -> un propietario; cada propietario -> dos dominios
    pairs = owner_pairs()
    check("T3  cada dominio tiene propietario", all(d in OWNER_OF for d in DOMAINS))
    check("T3  cada propietario posee exactamente 2 dominios",
          all(len(v) == 2 for v in pairs.values()))
    check("T3  GOOD posee los extremos {Proof, Market}",
          set(pairs["GOOD"]) == {"Proof", "Market"})
    check("T3  SOUND posee el flujo {Gate, Wheel}",
          set(pairs["SOUND"]) == {"Gate", "Wheel"})
    check("T3  BEST posee la cima {Light, Harvest}",
          set(pairs["BEST"]) == {"Light", "Harvest"})

    # T4 - aritmética canónica: GOOD x BEST = 72, 72 x 3 = 216 = SOUND
    check("T4  producto GOODxBEST = 72", OWNER_PRODUCT_GOOD_BEST == 72)
    check("T4  72 x 3 = 216 = SOUND", OWNER_PRODUCT_GOOD_BEST * 3 == SOUND_VALUE)
    check("T4  216 = 6^3 (la red 6-6-6 cierra)", SOUND_VALUE == 6 ** 3)

    # T5 - el propietario es derivable del dominio (autorrelleno + guardián del ingest)
    check("T5  derive_owner coincide con la tabla para todos los dominios",
          all(derive_owner(d) == OWNER_OF[d] for d in DOMAINS))

    # T6 - cierre de la Trinidad con el conjunto mínimo de 6 documentos (uno por dominio)
    minimal = [("Livelihood", "Proof"), ("PlayNAC", "Gate"),
               ("Environment-GAIA", "Wheel"), ("Identity-Security", "Light"),
               ("Data-Architecture", "Harvest"), ("Law", "Market")]
    check("T6  el conjunto mínimo de 6 docs cierra la Trinidad", trinity_complete(minimal))
    check("T6  el conjunto mínimo es exactamente 6", len(minimal) == 6)

    # T7 - el cierre FALLA si falta cualquier dominio (guardián en ambas direcciones)
    missing_market = [c for c in minimal if c[1] != "Market"]
    check("T7  quitar 'Market' rompe el par GOOD -> no completa",
          not trinity_complete(missing_market))
    missing_wheel = [c for c in minimal if c[1] != "Wheel"]
    check("T7  quitar 'Wheel' rompe el par SOUND -> no completa",
          not trinity_complete(missing_wheel))

    # T8 - el piso de la cuadrícula es 60 celdas; el cierre es estrictamente más barato
    grid = [(a, d) for a in AREAS for d in DOMAINS]
    check("T8  cuadrícula completa = 60 celdas", len(grid) == 60)
    check("T8  el cierre es alcanzable por debajo de la cuadrícula (6 << 60)",
          trinity_complete(minimal) and len(minimal) < len(grid))

    # T9 - validador de vinculación: una limpia pasa, un propietario erróneo se señala
    check("T9  la vinculación limpia valida",
          validate_binding("Livelihood", "Proof", "GOOD") == [])
    check("T9  la vinculación con propietario erróneo se señala",
          validate_binding("Livelihood", "Proof", "BEST") != [])
    check("T9  el dominio desconocido se señala",
          validate_binding("Livelihood", "Nowhere", "GOOD") != [])

    # ------------------------------------------------------------------
    passed = sum(1 for _n, ok in _results if ok)
    total = len(_results)
    print(f"\n{passed}/{total} en verde")
    return passed == total


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
