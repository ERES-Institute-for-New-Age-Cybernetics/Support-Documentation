#!/usr/bin/env python3
"""
RUN_ALL — ERES Provision-Master + Trinity-Build dual (EN/ES) test kits.
Runs every kit in this folder tree and reports one aggregate verdict.
No dependencies:  python3 RUN_ALL.py   (exit 0 iff every kit is all-green)
"""
import subprocess, sys, pathlib

HERE = pathlib.Path(__file__).resolve().parent
KITS = sorted(p for p in HERE.rglob("*TESTKIT*_v0-1.py"))

print("=" * 70)
print("ERES DUAL TEST-KIT RUNNER  —  Provision Master + Trinity Build (EN/ES)")
print("=" * 70)

all_ok = True
for kit in KITS:
    r = subprocess.run([sys.executable, str(kit)], capture_output=True, text=True)
    tail = [ln for ln in r.stdout.strip().splitlines() if ln.strip()][-1:] or ["(no output)"]
    status = "GREEN" if r.returncode == 0 else "RED"
    all_ok &= (r.returncode == 0)
    print(f"[{status:5}] {kit.name:52} {tail[0].strip()}")

print("-" * 70)
print("AGGREGATE:", "ALL GREEN" if all_ok else "FAILURES PRESENT")
sys.exit(0 if all_ok else 1)
