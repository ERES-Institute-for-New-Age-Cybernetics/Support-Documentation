#!/usr/bin/env python3
"""
ERES-PROVISION-MASTER-2026-001 — Instrumento de Prueba  (v0.1)  [ES]
===================================================================
Prueba de conformidad autocontenida para la arquitectura del Documento
Maestro de Provisión:

    Una arquitectura, leída de dos maneras — por PROVISIÓN (tierra, cuidado,
    progreso ganado) y por RECICLAJE (materia, humano, valor) — sobre un piso
    económico de dos partes, a lo largo de un horizonte de mil años.

Codifica las afirmaciones de carga estructural del whitepaper como aserciones
ejecutables. Sin dependencias externas; ejecutar:

    python3 ERES-PROVISION-MASTER-2026-001_TESTKIT_ES_v0-1.py

Código de salida 0 = todo en verde.  Autor: Joseph A. Sprute (ERES Maestro).
Licencia: CC BY 4.0.

Nota: los identificadores de código y los tokens canónicos se conservan en su
forma original; los mensajes de prueba están en español.
"""

import sys

# --------------------------------------------------------------------------
# ESTRUCTURA CANÓNICA (según el whitepaper del Documento Maestro de Provisión)
# --------------------------------------------------------------------------

READINGS = ["provision", "recycling"]                      # las dos lecturas
PROVISION_MODES = ["place", "care", "earned_advancement"]  # los tres modos
RECYCLING_LOOPS = ["matter", "human", "value"]             # los tres bucles
CROSSWALK = {"place": "matter", "care": "human", "earned_advancement": "value"}

FLOOR = "unconditional_income"   # piso: supervivencia (nunca puntuada)
ASCENT = "merit_accounts"        # ascenso: ganado

COMMITMENTS = [
    "call_cannot_fail", "floor_untouchable", "no_surveillance",
    "care_not_custody", "no_unilateral_decision", "value_reverts",
    "repair_not_destroy", "rule_binds_makers",
]

COUNCIL = ["citizen", "business", "government", "media",
           "organization", "dignitary", "diplomat"]

BUILDABLE = {
    "tiny_home_on_wheels": True,
    "hands_free_voice": True,
    "fly_and_dive_vehicle": False,   # horizonte de visión
    "planetary_solar_grid": False,   # horizonte de visión
}

EXPOSITION_NOT_DEMONSTRATION = True   # exposición, no demostración


# --------------------------------------------------------------------------
# LÓGICA DE REFERENCIA (la mecánica en que se apoya la arquitectura)
# --------------------------------------------------------------------------

def standing(merit, effort, floor=1.0):
    """La aritmética: mérito ganado x esfuerzo, más el piso dado."""
    return merit * effort + floor


def apply_merit(current, delta):
    """El mérito solo ELEVA. Un incremento negativo es inadmisible."""
    if delta < 0:
        raise ValueError("la medida de mérito no puede bajar la posición (solo eleva)")
    return current + delta


def apply_pain(action, current_standing, floor=1.0):
    """
    La medida del dolor solo REPARA: aislar, rebajar, examinar, actualizar,
    restaurar, descansar. Nunca degrada como castigo ni cae por debajo del piso.
    """
    repair_actions = {"isolate", "step_down", "examine", "update", "restore", "rest"}
    if action in {"demote", "destroy", "punish"}:
        return ("rejected", current_standing)
    if action not in repair_actions:
        return ("rejected", current_standing)
    return ("applied", max(current_standing, floor))


def emergency_response(deficits, floor=1.0, keep_floor=True):
    """
    Detecta un déficit en cualquier lugar y distribuye una respuesta. Con el
    piso mantenido, cada receptor queda en el piso o por encima. Sin el piso, el
    mecanismo se INVIERTE — retira ayuda a los peor situados (el fallo documentado).
    """
    payouts = {}
    for who, level in deficits.items():
        payouts[who] = max(level, floor) if keep_floor else level - 1.0
    return payouts


def distribution_ok(payouts, floor=1.0):
    """Una distribución es válida solo si cabalga por encima del piso intocable."""
    return all(v >= floor for v in payouts.values())


def decision_is_plural(seats):
    """Una decisión es plural solo si concurre más de un sector."""
    return len(set(seats)) >= 2


def value_rank(items):
    """Valor = duración de la coherencia probada, NO magnitud extraída."""
    return sorted(items, key=lambda k: items[k][0], reverse=True)


def duration_reserve(proven_duration):
    """Reserva respaldada por duración; un futuro no construido tiene duración cero."""
    return proven_duration, (proven_duration > 0)


def location_query(_person):
    """La capa de la persona está velada: consultar su ubicación se rechaza."""
    raise PermissionError("la ubicación de la persona no es consultable (sin vigilancia)")


# --------------------------------------------------------------------------
# ARNÉS DE PRUEBA
# --------------------------------------------------------------------------

_results = []

def check(name, cond):
    _results.append((name, bool(cond)))
    print(f"  [{'ÉXITO' if cond else 'FALLO'}] {name}")


def run():
    print("ERES-PROVISION-MASTER-2026-001 - prueba de conformidad de arquitectura [ES]\n")

    # P1 - cardinalidad de la arquitectura
    check("P1  dos lecturas de una arquitectura", len(READINGS) == 2)
    check("P1  tres modos de provisión", len(PROVISION_MODES) == 3)
    check("P1  tres bucles de reciclaje", len(RECYCLING_LOOPS) == 3)
    check("P1  ocho compromisos compartidos", len(COMMITMENTS) == 8)

    # P2 - la correspondencia es una biyección (las dos lecturas son el mismo objeto)
    check("P2  la correspondencia cubre cada modo de provisión", set(CROSSWALK) == set(PROVISION_MODES))
    check("P2  la correspondencia cubre cada bucle de reciclaje", set(CROSSWALK.values()) == set(RECYCLING_LOOPS))
    check("P2  la correspondencia es uno-a-uno", len(set(CROSSWALK.values())) == len(CROSSWALK))

    # P3 - el suelo de dos partes: piso y ascenso distintos, nunca mezclados
    check("P3  piso y ascenso son tokens distintos", FLOOR != ASCENT)

    # P4 - separación supervivencia/mérito
    base = standing(merit=0, effort=0, floor=1.0)
    check("P4  la admisión es incondicional (piso con mérito cero)", base == 1.0)
    check("P4  el ascenso se gana (el mérito eleva la posición)", standing(2, 3, 1.0) > base)

    # P5 - la aritmética  M x E + piso
    check("P5  posición = mérito*esfuerzo + piso", standing(2, 3, 1.0) == 7.0)
    check("P5  la posición es monótona en el mérito", standing(3, 3, 1.0) > standing(2, 3, 1.0))

    # P6 - la respuesta de emergencia cabalga POR ENCIMA del piso
    pay = emergency_response({"a": 0.2, "b": 0.5}, floor=1.0, keep_floor=True)
    check("P6  la respuesta deja a cada receptor en/por encima del piso", distribution_ok(pay, 1.0))

    # P7 - el guardián de inversión: sin piso, el mecanismo se invierte
    bad = emergency_response({"a": 0.2, "b": 0.5}, floor=1.0, keep_floor=False)
    check("P7  la respuesta sin piso se invierte (cae bajo el piso)", not distribution_ok(bad, 1.0))

    # P8 - la medida del dolor solo repara (nunca castiga, nunca bajo el piso)
    check("P8  'demote' es rechazado por la medida del dolor", apply_pain("demote", 5.0)[0] == "rejected")
    check("P8  'destroy' es rechazado (reparar, no destruir)", apply_pain("destroy", 5.0)[0] == "rejected")
    check("P8  'step_down' repara y sostiene el piso", apply_pain("step_down", 0.3, 1.0) == ("applied", 1.0))

    # P9 - la medida del mérito solo eleva
    check("P9  el mérito positivo eleva", apply_merit(3.0, 2.0) == 5.0)
    try:
        apply_merit(3.0, -1.0); neg_ok = False
    except ValueError:
        neg_ok = True
    check("P9  el mérito negativo es inadmisible", neg_ok)

    # P10 - las decisiones son plurales (ningún sector aislado domina)
    check("P10 el consejo de siete asientos es plural", decision_is_plural(COUNCIL))
    check("P10 una decisión de un solo sector NO es plural", not decision_is_plural(["business"]))

    # P11 - el valor es duración, no magnitud
    ranked = value_rank({"slow_true": (100, 5), "fast_extractive": (2, 500)})
    check("P11 larga-duración/baja-magnitud supera a corta/alta", ranked[0] == "slow_true")

    # P12 - el bloqueo honesto de temporización
    r0, financeable0 = duration_reserve(0)
    check("P12 un futuro no construido tiene duración probada cero", r0 == 0)
    check("P12 la reserva por duración no es financiable en t=0", financeable0 is False)
    _, financeable_later = duration_reserve(50)
    check("P12 la reserva se vuelve financiable al probarse duración", financeable_later is True)

    # P13 - honestidad del horizonte de visión
    check("P13 la vivienda personal es construible ahora", BUILDABLE["tiny_home_on_wheels"] is True)
    check("P13 el vehículo + la red planetaria son horizonte de visión",
          BUILDABLE["fly_and_dive_vehicle"] is False and BUILDABLE["planetary_solar_grid"] is False)

    # P14 - los compromisos son completos y distintos
    check("P14 los compromisos son únicos", len(set(COMMITMENTS)) == len(COMMITMENTS))
    check("P14 floor_untouchable es un compromiso nombrado", "floor_untouchable" in COMMITMENTS)

    # P15 - sin vigilancia: la capa de la persona está velada
    try:
        location_query("alguien"); veiled = False
    except PermissionError:
        veiled = True
    check("P15 la ubicación de la persona no es consultable", veiled)

    # P16 - bucle cerrado: la posición reingresa al ciclo siguiente
    s1 = standing(2, 2, 1.0)
    s2 = standing(s1 - 1.0, 1, 1.0)
    check("P16 la posición alimenta el ciclo siguiente (bucle cerrado)", s2 > 0)

    # P17 - exposición, no demostración (bandera de honestidad)
    check("P17 declarado exposición, no demostración", EXPOSITION_NOT_DEMONSTRATION is True)

    # ------------------------------------------------------------------
    passed = sum(1 for _n, ok in _results if ok)
    total = len(_results)
    print(f"\n{passed}/{total} en verde")
    return passed == total


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
