#!/usr/bin/env python3
"""
ERES-PROVISION-MASTER-2026-001 — Test Instrument  (v0.1)  [EN]
=============================================================
Self-contained conformance test for the Provision Master architecture:

    One architecture, read two ways — by PROVISION (ground, care, earned
    advancement) and by RECYCLING (matter, human, value) — on a two-part
    economic floor, across a thousand-year horizon.

It encodes the load-bearing claims of the whitepaper as executable assertions.
No external dependencies; run:

    python3 ERES-PROVISION-MASTER-2026-001_TESTKIT_EN_v0-1.py

Exit code 0 = all green.  Author: Joseph A. Sprute (ERES Maestro).
License: CC BY 4.0.
"""

import sys

# --------------------------------------------------------------------------
# CANONICAL STRUCTURE (per the Provision Master whitepaper)
# --------------------------------------------------------------------------

# The two readings of the one architecture.
READINGS = ["provision", "recycling"]

# Reading one — the three provision modes (what a person is owed).
PROVISION_MODES = ["place", "care", "earned_advancement"]

# Reading two — the three recycling loops (how a planet affords it).
RECYCLING_LOOPS = ["matter", "human", "value"]

# The crosswalk: the two readings are the SAME object (a bijection).
CROSSWALK = {"place": "matter", "care": "human", "earned_advancement": "value"}

# The two-part economic ground. Floor = survival (never scored); Ascent = earned.
FLOOR = "unconditional_income"
ASCENT = "merit_accounts"

# The eight shared commitments that keep the architecture from inverting.
COMMITMENTS = [
    "call_cannot_fail", "floor_untouchable", "no_surveillance",
    "care_not_custody", "no_unilateral_decision", "value_reverts",
    "repair_not_destroy", "rule_binds_makers",
]

# The plural council (no single sector dominates).
COUNCIL = ["citizen", "business", "government", "media",
           "organization", "dignitary", "diplomat"]

# Honesty ledger: buildable now vs. vision-horizon (aspirational, not delivered).
BUILDABLE = {
    "tiny_home_on_wheels": True,
    "hands_free_voice": True,
    "fly_and_dive_vehicle": False,   # vision-horizon
    "planetary_solar_grid": False,   # vision-horizon
}

# This document is exposition, not demonstration.
EXPOSITION_NOT_DEMONSTRATION = True


# --------------------------------------------------------------------------
# REFERENCE LOGIC (the mechanics the architecture relies on)
# --------------------------------------------------------------------------

def standing(merit, effort, floor=1.0):
    """The rating arithmetic: earned merit x effort, plus the given floor."""
    return merit * effort + floor


def apply_merit(current, delta):
    """Merit only ever LIFTS. Negative deltas are inadmissible."""
    if delta < 0:
        raise ValueError("merit measure cannot lower standing (only lifts)")
    return current + delta


def apply_pain(action, current_standing, floor=1.0):
    """
    The pain measure only ever REPAIRS: isolate, step down, examine, update,
    restore, rest. It never demotes as punishment and never dips below floor.
    """
    repair_actions = {"isolate", "step_down", "examine", "update", "restore", "rest"}
    if action in {"demote", "destroy", "punish"}:
        return ("rejected", current_standing)
    if action not in repair_actions:
        return ("rejected", current_standing)
    return ("applied", max(current_standing, floor))


def emergency_response(deficits, floor=1.0, keep_floor=True):
    """
    Sense a deficit anywhere; distribute a response. When the floor is kept,
    every recipient lands at or above it. When the floor is removed, the
    mechanism INVERTS — it withdraws from the worst-off (the documented failure).
    """
    payouts = {}
    for who, level in deficits.items():
        payouts[who] = max(level, floor) if keep_floor else level - 1.0
    return payouts


def distribution_ok(payouts, floor=1.0):
    """A distribution is valid only if it rides above the untouchable floor."""
    return all(v >= floor for v in payouts.values())


def decision_is_plural(seats):
    """A decision is plural only if more than one sector concurs."""
    return len(set(seats)) >= 2


def value_rank(items):
    """Value = duration of proven coherence, NOT extracted magnitude."""
    return sorted(items, key=lambda k: items[k][0], reverse=True)


def duration_reserve(proven_duration):
    """A duration-backed reserve; an unbuilt future has zero proven duration."""
    return proven_duration, (proven_duration > 0)


def location_query(_person):
    """The person layer is veiled: querying a person's location is refused."""
    raise PermissionError("person location is not queryable (no surveillance)")


# --------------------------------------------------------------------------
# TEST HARNESS
# --------------------------------------------------------------------------

_results = []

def check(name, cond):
    _results.append((name, bool(cond)))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


def run():
    print("ERES-PROVISION-MASTER-2026-001 - architecture conformance test [EN]\n")

    # P1 - architecture cardinality
    check("P1  two readings of one architecture", len(READINGS) == 2)
    check("P1  three provision modes", len(PROVISION_MODES) == 3)
    check("P1  three recycling loops", len(RECYCLING_LOOPS) == 3)
    check("P1  eight shared commitments", len(COMMITMENTS) == 8)

    # P2 - the crosswalk is a bijection (the two readings are the same object)
    check("P2  crosswalk maps every provision mode", set(CROSSWALK) == set(PROVISION_MODES))
    check("P2  crosswalk covers every recycling loop", set(CROSSWALK.values()) == set(RECYCLING_LOOPS))
    check("P2  crosswalk is one-to-one", len(set(CROSSWALK.values())) == len(CROSSWALK))

    # P3 - the two-part ground: floor and ascent are distinct, never blended
    check("P3  floor and ascent are distinct tokens", FLOOR != ASCENT)

    # P4 - survival/merit separation
    base = standing(merit=0, effort=0, floor=1.0)
    check("P4  admission is unconditional (floor with zero merit)", base == 1.0)
    check("P4  ascent is earned (merit raises standing)", standing(2, 3, 1.0) > base)

    # P5 - the rating arithmetic  M x E + floor
    check("P5  standing = merit*effort + floor", standing(2, 3, 1.0) == 7.0)
    check("P5  standing is monotone in merit", standing(3, 3, 1.0) > standing(2, 3, 1.0))

    # P6 - emergency response rides ABOVE the floor
    pay = emergency_response({"a": 0.2, "b": 0.5}, floor=1.0, keep_floor=True)
    check("P6  response keeps every recipient at/above floor", distribution_ok(pay, 1.0))

    # P7 - the inversion guard: remove the floor and the mechanism inverts
    bad = emergency_response({"a": 0.2, "b": 0.5}, floor=1.0, keep_floor=False)
    check("P7  floorless response inverts (falls below floor)", not distribution_ok(bad, 1.0))

    # P8 - the pain measure only repairs (never punishes, never sub-floor)
    check("P8  'demote' is rejected by the pain measure", apply_pain("demote", 5.0)[0] == "rejected")
    check("P8  'destroy' is rejected (repair, not destroy)", apply_pain("destroy", 5.0)[0] == "rejected")
    check("P8  'step_down' repairs and holds the floor", apply_pain("step_down", 0.3, 1.0) == ("applied", 1.0))

    # P9 - the merit measure only lifts
    check("P9  positive merit lifts", apply_merit(3.0, 2.0) == 5.0)
    try:
        apply_merit(3.0, -1.0); neg_ok = False
    except ValueError:
        neg_ok = True
    check("P9  negative merit is inadmissible", neg_ok)

    # P10 - decisions are plural (no single sector dominates)
    check("P10 seven-seat council is plural", decision_is_plural(COUNCIL))
    check("P10 single-sector decision is NOT plural", not decision_is_plural(["business"]))

    # P11 - value is duration, not magnitude
    ranked = value_rank({"slow_true": (100, 5), "fast_extractive": (2, 500)})
    check("P11 long-duration/low-magnitude outranks short/high", ranked[0] == "slow_true")

    # P12 - the honest timing blocker
    r0, financeable0 = duration_reserve(0)
    check("P12 unbuilt future has zero proven duration", r0 == 0)
    check("P12 duration-reserve not financeable at t=0", financeable0 is False)
    _, financeable_later = duration_reserve(50)
    check("P12 reserve becomes financeable once duration is proven", financeable_later is True)

    # P13 - vision-horizon honesty
    check("P13 personal dwelling is buildable now", BUILDABLE["tiny_home_on_wheels"] is True)
    check("P13 vehicle + planetary grid are vision-horizon",
          BUILDABLE["fly_and_dive_vehicle"] is False and BUILDABLE["planetary_solar_grid"] is False)

    # P14 - commitments are complete and distinct
    check("P14 commitments are unique", len(set(COMMITMENTS)) == len(COMMITMENTS))
    check("P14 floor_untouchable is a named commitment", "floor_untouchable" in COMMITMENTS)

    # P15 - no surveillance: the person layer is veiled
    try:
        location_query("someone"); veiled = False
    except PermissionError:
        veiled = True
    check("P15 person location is not queryable", veiled)

    # P16 - closed loop: standing re-enters the next cycle rather than terminating
    s1 = standing(2, 2, 1.0)
    s2 = standing(s1 - 1.0, 1, 1.0)  # prior standing feeds the next cycle
    check("P16 standing feeds the next cycle (closed loop)", s2 > 0)

    # P17 - exposition, not demonstration (honesty flag)
    check("P17 declared exposition, not demonstration", EXPOSITION_NOT_DEMONSTRATION is True)

    # ------------------------------------------------------------------
    passed = sum(1 for _n, ok in _results if ok)
    total = len(_results)
    print(f"\n{passed}/{total} green")
    return passed == total


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
