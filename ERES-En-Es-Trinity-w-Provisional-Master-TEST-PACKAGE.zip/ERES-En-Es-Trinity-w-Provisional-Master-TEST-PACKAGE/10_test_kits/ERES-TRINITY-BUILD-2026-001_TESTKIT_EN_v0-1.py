#!/usr/bin/env python3
"""
ERES-TRINITY-BUILD-2026-001 — Test Instrument  (v0.1)
=====================================================
Self-contained conformance test for the Trinity Build cascade:

    10 areas (subject) x 6 domains (lifecycle) -> 3 owners (BEST/SOUND/GOOD) -> 1 TRINITY hub

It encodes the canonical structure from the ERES NAC Dual-Axis and asserts the
invariants the AR/VR simulator relies on. No external dependencies; run:

    python3 ERES-TRINITY-BUILD-2026-001_TEST_v0.1.py

Exit code 0 = all green.  Author: Joseph A. Sprute (ERES Maestro).
License: CCAL v2.1 / CC-BY 4.0.
"""

import sys

# --------------------------------------------------------------------------
# CANONICAL STRUCTURE (per ERES NAC Dual-Axis)
# --------------------------------------------------------------------------

# Layer A - the 10 subject areas (the ring). Partition: a doc is about one area.
AREAS = [
    "Orientation", "PlayNAC", "Livelihood", "Law", "Identity-Security",
    "Health-Body", "Environment-GAIA", "Data-Architecture",
    "Skills-EarnedPath", "Reference-Desk",
]

# Layer B - the 6 domains, ordered as the value ascent Proof -> Market (Levels 1-6).
DOMAINS = ["Proof", "Gate", "Wheel", "Light", "Harvest", "Market"]

NODE = {  # domain -> (level, node-code)
    "Proof":   (1, "ERES"),
    "Gate":    (2, "VERTECA"),
    "Wheel":   (3, "SECUIR"),
    "Light":   (4, "CyberRAVE"),
    "Harvest": (5, "GunnySack"),
    "Market":  (6, "SaleBuilders"),
}

# Layer C - the 3 owners. Each owns exactly two domains (the pairing).
OWNER_OF = {
    "Proof": "GOOD", "Market": "GOOD",      # bookends
    "Gate": "SOUND", "Wheel": "SOUND",      # throughput
    "Light": "BEST", "Harvest": "BEST",     # peak
}

OWNERS = {  # owner -> (badge, principle, totem)
    "GOOD":  ("diamond", "M", "Duck"),
    "SOUND": ("star",    "R", "Eagle"),
    "BEST":  ("hex",     "P", "Falcon"),
}

# Canonical owner math (Dual-Axis):  GOOD x BEST = 72 ,  72 x 3 = 216 = SOUND
OWNER_PRODUCT_GOOD_BEST = 72
SOUND_VALUE = 216

# Layer D - the 1 hub.
HUB = "TRINITY"


# --------------------------------------------------------------------------
# REFERENCE LOGIC (what the simulator ingest will use)
# --------------------------------------------------------------------------

def derive_owner(domain):
    """owner is derivable from domain; ingest uses this to flag mismatches."""
    return OWNER_OF[domain]


def owner_pairs():
    """owner -> the two domains it holds."""
    pairs = {o: [] for o in OWNERS}
    for d in DOMAINS:
        pairs[OWNER_OF[d]].append(d)
    return pairs


def trinity_complete(lit_cells):
    """
    lit_cells : iterable of (area, domain) that hold >=1 document.
    Trinity-complete iff each owner has BOTH its domains lit in >=1 area.
    (This is the closure criterion - strictly weaker than grid-completeness.)
    """
    lit_domains = {d for (_a, d) in lit_cells}
    for owner, doms in owner_pairs().items():
        if not all(d in lit_domains for d in doms):
            return False
    return True


def validate_binding(area, domain, declared_owner):
    """Return list of problems for a document binding (empty = OK)."""
    problems = []
    if area not in AREAS:
        problems.append(f"unknown area '{area}'")
    if domain not in DOMAINS:
        problems.append(f"unknown domain '{domain}'")
    elif declared_owner != derive_owner(domain):
        problems.append(
            f"owner mismatch: declared '{declared_owner}', "
            f"domain '{domain}' derives '{derive_owner(domain)}'"
        )
    return problems


# --------------------------------------------------------------------------
# TEST HARNESS
# --------------------------------------------------------------------------

_results = []

def check(name, cond):
    _results.append((name, bool(cond)))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


def run():
    print("ERES-TRINITY-BUILD-2026-001 - cascade conformance test\n")

    # T1 - cascade cardinality 10 x 6 -> 3 -> 1
    check("T1  cardinality 10 areas", len(AREAS) == 10)
    check("T1  cardinality 6 domains", len(DOMAINS) == 6)
    check("T1  cardinality 3 owners", len(OWNERS) == 3)
    check("T1  cardinality 1 hub", HUB == "TRINITY")

    # T2 - domain ordering is the Proof->Market ascent, levels 1..6 contiguous
    levels = [NODE[d][0] for d in DOMAINS]
    check("T2  levels are 1..6 in order", levels == [1, 2, 3, 4, 5, 6])
    check("T2  Proof is Level 1 (base ascent)", NODE["Proof"][0] == 1)
    check("T2  Market is Level 6 (apex ascent)", NODE["Market"][0] == 6)

    # T3 - the pairing: every domain -> exactly one owner; every owner -> exactly two domains
    pairs = owner_pairs()
    check("T3  every domain owned", all(d in OWNER_OF for d in DOMAINS))
    check("T3  each owner holds exactly 2 domains",
          all(len(v) == 2 for v in pairs.values()))
    check("T3  GOOD holds the bookends {Proof, Market}",
          set(pairs["GOOD"]) == {"Proof", "Market"})
    check("T3  SOUND holds the throughput {Gate, Wheel}",
          set(pairs["SOUND"]) == {"Gate", "Wheel"})
    check("T3  BEST holds the peak {Light, Harvest}",
          set(pairs["BEST"]) == {"Light", "Harvest"})

    # T4 - canonical owner math:  GOOD x BEST = 72 ,  72 x 3 = 216 = SOUND
    check("T4  GOODxBEST product = 72", OWNER_PRODUCT_GOOD_BEST == 72)
    check("T4  72 x 3 = 216 = SOUND", OWNER_PRODUCT_GOOD_BEST * 3 == SOUND_VALUE)
    check("T4  216 = 6^3 (the 6-6-6 lattice closes)", SOUND_VALUE == 6 ** 3)

    # T5 - owner is derivable from domain (ingest can auto-fill + guard)
    check("T5  derive_owner matches table for all domains",
          all(derive_owner(d) == OWNER_OF[d] for d in DOMAINS))

    # T6 - Trinity-closure with the minimal 6-document set (one per domain)
    minimal = [("Livelihood", "Proof"), ("PlayNAC", "Gate"),
               ("Environment-GAIA", "Wheel"), ("Identity-Security", "Light"),
               ("Data-Architecture", "Harvest"), ("Law", "Market")]
    check("T6  minimal 6-doc set closes the Trinity", trinity_complete(minimal))
    check("T6  minimal set is exactly 6", len(minimal) == 6)

    # T7 - closure FAILS when any one domain is missing (both directions of the guard)
    missing_market = [c for c in minimal if c[1] != "Market"]
    check("T7  dropping 'Market' breaks GOOD pair -> not complete",
          not trinity_complete(missing_market))
    missing_wheel = [c for c in minimal if c[1] != "Wheel"]
    check("T7  dropping 'Wheel' breaks SOUND pair -> not complete",
          not trinity_complete(missing_wheel))

    # T8 - grid floor is 60 cells; closure is strictly cheaper than grid-complete
    grid = [(a, d) for a in AREAS for d in DOMAINS]
    check("T8  full grid = 60 cells", len(grid) == 60)
    check("T8  closure reachable below grid-completeness (6 << 60)",
          trinity_complete(minimal) and len(minimal) < len(grid))

    # T9 - binding validator: clean binding passes, wrong owner is flagged
    check("T9  clean binding validates",
          validate_binding("Livelihood", "Proof", "GOOD") == [])
    check("T9  wrong-owner binding is flagged",
          validate_binding("Livelihood", "Proof", "BEST") != [])
    check("T9  unknown domain is flagged",
          validate_binding("Livelihood", "Nowhere", "GOOD") != [])

    # ------------------------------------------------------------------
    passed = sum(1 for _n, ok in _results if ok)
    total = len(_results)
    print(f"\n{passed}/{total} green")
    return passed == total


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
