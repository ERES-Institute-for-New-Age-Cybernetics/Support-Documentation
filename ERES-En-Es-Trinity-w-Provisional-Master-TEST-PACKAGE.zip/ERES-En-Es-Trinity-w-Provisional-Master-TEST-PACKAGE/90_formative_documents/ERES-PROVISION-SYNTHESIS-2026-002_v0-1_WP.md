# The People of a Planet, Recycled Rather Than Spent

### Global Human Resources on a Foundation of Water and Farming, Read Through the Thousand-Year Horizon — A Complete Plain-Language Synthesis

---

**Instrument identifier:** ERES-PROVISION-SYNTHESIS-2026-002 *(proposed; the author may rename)* — the second synthesis in this series (the author's "v2"), companion to ERES-PROVISION-SYNTHESIS-2026-001.
**Version / status:** v0.1 — Proposed, pre-canonical. A synthesis of instruments that already exist in the ERES corpus, read through an existing corpus lens; not itself put through the institute's ensemble review, and it introduces no data.
**Author of record:** Joseph Allen Sprute (ERES Maestro), sole accountable author. ORCID 0000-0001-9946-3221.
**Institution:** ERES Institute for New Age Cybernetics — Bella Vista, Arkansas — established 4 February 2012.
**Date:** 11 September 2026.
**License:** Creative Commons Attribution 4.0 International (CC BY 4.0).

---

## The lens: a thousand-year horizon

Everything below is viewed through one interpretive lens — the institute's thousand-year map of the future. That map changes what counts as sensible in four ways, and it is worth naming them before anything else, because each ordinary short-term instinct it overturns.

First, the horizon is a thousand years, not a quarter or an election cycle. On that horizon the relevant unit of value is not how much a thing is worth today but how long it can stay coherent — how many generations it can keep working without breaking. Duration, not magnitude, is the measure.

Second, the picture is a generation ship. Humanity is treated as a crew on a closed vessel that has to keep its air, water, and soil breathable and fertile the whole way, because there is nowhere to throw anything "away." On a ship, waste is just a resource in the wrong place, and everything is designed to loop back.

Third, the environment is the causal layer underneath the economy and the mind, not a topic beside them. Water, soil, and energy are not one sector among many; they are the floor that economics and psychology stand on. Get the floor wrong and no amount of financial or emotional cleverness will hold.

Fourth, the goal is a rising floor for everyone, not a defended ceiling for some. Success is measured by how high the worst-off are lifted over time, not by how high the best-off can be protected.

Read through this lens, the whole design has a single verb: **recycle**. Not waste, not spend, not extract — but circulate, restore, and re-tune. That verb runs through matter, through people, and through value alike, and the rest of this paper is that one verb, applied completely.

---

## The claim, written out in one sentence

The worldwide work of developing, matching, and caring for people — grounded on the real floor of water and farming, and carried by four technologies that are best understood as a recycling system rather than a set of gadgets — **is** the raising of what people can be and do: it becomes the same thing as human flourishing, folded into an economy run as a living ecology, answered by an equitable emergency response that never dips below the floor, held down by the honest accounting of pain and lifted by the honest accounting of merit, qualified by a fair lattice of access, and run entirely inside a continuous read of the system's health that serves each person by reason of their need while refusing to link that service to a tracked identity.

The rest of this paper is that one sentence, unpacked completely and read through the thousand-year lens.

---

## 1. Reading instruction

As in the companion paper, every load-bearing idea already lives in the corpus under a short name, and every short name has been removed here in favor of ordinary language. The short names survive only in the provenance table at the end, so the plain description can be traced back to its sources. If a sentence does not survive in plain words, it does not belong in the design. The organizing idea to hold onto throughout is recycling: matter recycled, people recycled — in the sense of restored and re-deployed, never discarded — and value recycled.

---

## 2. The floor: water and farming

People's work has to be anchored to something real, and in this design it is anchored to the two things a crew on a ship cannot live without: water and food. Water is the foundation; farming is what water makes possible; and farming, in turn, is the true center of the economy — the mainstay, the soft place to land, the source of the abundance floor. Money and markets sit above this floor and are meant to serve it, not to replace it.

This is why the worldwide management of people is grounded here rather than in finance. A person's worth and a person's work are measured against real quantities — clean water secured, food grown, dwellings kept warm and safe — not against abstract figures that can be inflated or hollowed out. Anchoring here also follows directly from the lens: since the environment is the causal layer beneath the economy, the human system has to be built on the environmental floor or it is built on nothing.

The single most important safeguard on this floor is that water can never be enclosed or privately captured. A floor that can be fenced off is not a floor. Everything else in the design fails at the bottom if water is allowed to become someone's private gate.

---

## 3. Global human resources as recycling, which is the same as human flourishing

The ordinary way of treating people economically is extractive: a person is hired, used, worn down, and let go — spent like fuel. The thousand-year lens forbids this the same way a generation ship forbids throwing anything overboard. People are not fuel to be burned; they are the crew, and the crew has to be kept whole for a thousand years.

So the worldwide work of developing and matching people is recast as a recycling discipline. A person who is exhausted is restored, not discarded. A person whose skills no longer fit is re-tuned and re-matched, not thrown away. A person shut out by circumstance is brought back into full participation. Rest and recovery are treated as a provisioned necessity rather than a reward, because a crew that is never restored will not last the voyage. This restoring-and-re-deploying of people, done continuously, simply *is* what it means to raise human performance: flourishing is not a separate goal bolted on afterward — it is what recycling the crew looks like when it is done well.

Two paired measures keep this honest, and they are deliberately asymmetric. One measure accounts for merit — what a person has genuinely earned above the floor — and it only ever lifts; it governs how someone rises and is never used to push anyone down. The other measure accounts for pain, stress, and cost — and it only ever repairs; it governs what happens when something fails, and it does so without punishment, by isolating the trouble, stepping it down to a safer state, examining it, and updating. Stress is rendered as a live color so strain is visible before it becomes damage. You cannot be demoted for suffering, and you cannot be promoted for merely enduring. Merit multiplies what rises; pain accounting holds and heals what falls.

Who may step onto the ladder of advancement, and how far, is settled by a fair lattice of access whose base is the natural signatures a person already carries in their own body, and whose entry is through several equal doorways rather than a single ranked gate — different ways in, not a hierarchy of worth. Admission to the floor is unconditional and never scored; ascent above it is earned. The line between the two never blurs.

---

## 4. The four technologies as one recycling system

The four technologies that carry the material side of this economy are not four products; through the lens they are one closed-loop recycling system spanning from the single person up to the whole planet.

At the smallest scale is the dwelling that closes its own loops — a tiny home on wheels, understood as a test model of a generation-ship cabin: a place designed to reclaim its own water, handle its own waste, and live within its own energy, so that a single household is already a small closed ecology rather than a straw drawing endlessly on the world outside.

Reaching upward from the person is access by voice, hands-free — an interface that recovers the full participation of anyone who cannot use hands, screens, or conventional controls. This is the recycling of human capability itself: it brings back into the crew the contribution of people that ordinary interfaces quietly discard.

Moving between the scales is a vehicle that can both fly and dive — mobility that lets people and materials circulate to where they are needed rather than pooling and stagnating in one place. Circulation is what keeps a loop a loop; without movement between scales, the system silos and the recycling stops.

At the largest scale is a planetary grid that turns sunlight into the continuous, shared power the loops require — a green solar substrate understood as the generation ship's power plant. Sunlight is the one input that arrives fresh every day and never has to be mined; building the planet's power around it is the ultimate recycling move, because it replaces a stock that runs down with a flow that renews.

Taken together these four span the whole vessel: the personal cabin at the bottom, the planetary power plant at the top, voice-access reaching up to include everyone, and mobility circulating between. Honesty requires marking the larger end of this span as horizon rather than delivered fact: the personal dwelling is buildable now, while the fly-and-dive vehicle and the planetary grid are vision-scale aims that the map points toward, not things in hand.

---

## 5. Three loops closing into one economy

The recycling verb closes three loops, and when all three close, they are the same economy seen from three sides.

The matter loop is the four technologies above: water, waste, energy, and materials circulated rather than consumed.

The human loop is the recycling of people described in section 3: the crew restored, re-tuned, and re-included rather than spent.

The value loop is the economic inversion the lens demands. Instead of measuring worth as extracted magnitude — how much was taken and sold — worth is measured as the duration of proven coherence: how long something has held together and kept working. This flips the basic economic verb from mining to tuning, from pushing costs onto others to offsetting and remediating them, from a one-time magnitude to a sustained duration. An economy that rewards how long you can keep a thing healthy, rather than how fast you can strip it, is an economy that recycles value instead of burning it.

Close all three and you have an economy run as a living ecology — one where nothing is extracted faster than it regenerates, and where the point of the whole machine is circulation, not throughput.

---

## 6. How the pieces are bound together, in words

The synthesis binds the raising of human performance to five things at once, and each binding can be said plainly.

It is **folded into** the ecological economy — human flourishing is not a byproduct of the economy but the same object as the economy when the economy is run as a living ecology.

It is **answered by** an equitable emergency response — a mechanism that senses a shortfall anywhere, decides what to do through a plural council so no single sector dominates, and distributes help on a fair, relative-to-real-contribution basis, always staying above the untouchable survival floor. Keeping that response above the floor is load-bearing: were it allowed to key payment to how badly someone is failing without the floor beneath, it would invert into withdrawing help from exactly the people who are failing. The floor is what keeps "respond to deficit" from becoming "abandon the deficient."

It is **held down by** the accounting of pain and **lifted by** the accounting of merit — the two asymmetric measures of section 3, one that only repairs and one that only raises.

It is **qualified by** the fair lattice of access — the several equal doorways and the bodily-signature base that decide who may climb and how high.

And it runs **entirely inside** a continuous read of the whole system's health — an always-on sense of whether the living system is well or drifting, more like a cardiogram than a camera — and that health-read operates on one non-negotiable privacy discipline: it reasons about what each person needs and serves them by reason of that need, while structurally refusing to associate the service, or the data behind it, to a tracked identity. Personal fit without personal exposure; the system knows you well enough to help and refuses to catalogue you. This is the same discipline that keeps the land layer described while the person layer stays veiled, here applied to the body and the record: help is linked to need, never to a name.

---

## 7. What the lens reveals that a short horizon hides

Viewed on a short horizon, each of these pieces looks like an expense — recycling costs more than dumping, restoring people costs more than replacing them, measuring duration is slower than booking magnitude. Viewed through the thousand-year, generation-ship lens, the sign flips: on a closed vessel with nowhere to dump and no replacement crew, recycling is not the expensive option, it is the only option that survives the voyage. What reads as cost on a quarterly view reads as the sole viable design on a thousand-year view. The lens is not decoration; it is what makes the whole synthesis rational rather than merely virtuous.

---

## 8. Status, scope, and honest limits

This is a plain-language synthesis, proposed and pre-canonical, not separately run through the institute's ensemble of independent evaluators, containing no fabricated figures or citations. The personal-scale technology is buildable; the vehicle and planetary-grid ends are stated as vision-horizon, not delivered.

The sharpest honest problem is a timing one, and the lens itself surfaces it. If value is to be measured as the duration of proven coherence, then a future that has not yet been built has, by definition, zero proven duration — so a reserve backed by duration cannot be funded at the very moment it is needed most, at the start. The thousand-year map is not financeable at time zero by its own rule, and no bootstrap for getting from a standing start to a duration-backed system has been settled here. Alongside it stand the same enforcement questions as ever: whether water is actually held as a commons, whether the planetary-scale authority is actually distributed rather than concentrated, whether the help-line actually delivers to every caller, and the exact thresholds inside each measure. None of these is closed here.

---

## Credits

Authorship follows the institute's convention, under which the collaborative "we" refers to the human–machine collaboration itself rather than a conventional team. Joseph Allen Sprute is the sole accountable author. Drafting assistance was provided by Claude (Anthropic) under that convention — assistance, not co-authorship, and carrying no share of accountability. The ERES Institute for New Age Cybernetics (Bella Vista, Arkansas) is the issuing body.

## References — source instruments and lens assimilated here

- The thousand-year lens, the generation-ship framing, and the value inversion from extracted magnitude to proven duration — *The Economic FLIP* and the 1000-Year Future Map (ERES-FLIP-2026-001), including its honest timing blocker (a not-yet-built future has zero proven duration).
- Water as foundation, farming as economic center of gravity, the four bio-ecologic technologies, and the extraction-to-tuning conversion — *Foundations of Sustainable Prosperity* (ERES-FOUNDATIONS-CODE-2026-001) and the associated framework material.
- The raising of human performance, stress rendered as live color, and provisioned rest as necessity — the Human-Performance frame, with its paired pain-accounting and merit-accounting.
- The equitable emergency response that senses, decides plurally, and distributes above the floor — the Emergency-Management Critical-Infrastructure instrument (ERES-EMCI-SLA-2026-001) and its response-currency mechanism, with the plural seven-seat council and non-punitive remediation of the resonance-governance engine (ERES-PlayNAC).
- The fair lattice of access and its bodily-signature base — the fair-access qualification lattice.
- The health-of-the-system signal — the resonance-architecture governance-health signal (rendered here by function; its expanded name appears in the corpus in more than one form).
- The privacy discipline of serving by reason of need without linking to identity — the reason-do-not-associate principle of the companion synthesis (ERES-PROVISION-SYNTHESIS-2026-001) and the veiled-person discipline of the Posterity Ledger (ERES-LLPM-2026-001, https://doi.org/10.13140/RG.2.2.18605.24802).
- The two-part economic ground of unconditional income plus merit accounts underlying both syntheses — the ERES Trilogy foundation.

## License

Released under the Creative Commons Attribution 4.0 International License (CC BY 4.0). You may share and adapt it, including commercially, with attribution to the author and the ERES Institute for New Age Cybernetics.

## Data-Integrity statement

No datasets, measurements, magnitudes, citations, or evaluation scores were invented for this document. Components that are aspirational rather than built are labeled as vision-horizon. The timing blocker and the enforcement questions are stated as open.
