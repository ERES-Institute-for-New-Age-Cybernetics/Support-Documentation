FORMATIVE DOCUMENTS — for researchers
=====================================
Every document used in forming this package, preserved verbatim as supplied:
- ERES-PROVISION-SYNTHESIS-2026-001 (provision reading) — md + pdf
- ERES-PROVISION-SYNTHESIS-2026-002 (recycling reading) — md + pdf
- ERES-PROVISION-MASTER-2026-001 EN/ES — md + pdf
- ERES-TRINITY-BUILD-2026-001 EN/ES — md + pdf
- prior sealed packages (nested .zip) and the Trinity cascade PNG
The English Markdown is the source of record; Spanish files are derived.
Nested .zip archives are kept intact as received.
