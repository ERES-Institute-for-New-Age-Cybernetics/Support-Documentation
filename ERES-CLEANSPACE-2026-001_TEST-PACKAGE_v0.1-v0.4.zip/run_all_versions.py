#!/usr/bin/env python3
"""
run_all_versions.py -- cross-version test runner for ERES-CLEANSPACE-2026-001 v0.1, v0.2, v0.3, v0.4

Unzips each version package into a temporary folder, verifies its SHA-256 manifest, runs its
own test suite (v0.2-v0.4; v0.1 is text-only), then runs lineage checks across versions.
Standard library only. Read-only: nothing outside a temp folder is written. Exit 0 = all pass.

License: CCAL v2.1 (DOI 10.5281/zenodo.23451312); CC-BY 4.0 compatible per CCAL s.12.
"""
import hashlib, importlib.util, json, os, re, subprocess, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
VERSIONS = ["0.1", "0.2", "0.3", "0.4"]
ZIP = "ERES-CLEANSPACE-2026-001_v{}_PACKAGE.zip"
results = []


def rec(tid, ok, msg, status=None):
    results.append((tid, status or ("PASS" if ok else "FAIL"), msg))


def unpack(tmp, v):
    d = os.path.join(tmp, "v" + v)
    with zipfile.ZipFile(os.path.join(HERE, ZIP.format(v))) as z:
        z.extractall(d)
    return d


def manifest_ok(d):
    m = json.load(open(os.path.join(d, "MANIFEST.json")))
    bad = [f["name"] for f in m["files"]
           if hashlib.sha256(open(os.path.join(d, f["name"]), "rb").read()).hexdigest() != f["sha256"]]
    return not bad, len(m["files"]), bad


def run_kit(d):
    p = subprocess.run([sys.executable, "-I", os.path.join(d, "eres_cleanspace_testkit.py")],
                       capture_output=True, text=True, cwd=d)
    rows = dict(re.findall(r"^(T\d\d|S\d)\s+(PASS|FAIL|SKIP)", p.stdout, re.M))
    return p.returncode, rows, p.stdout


def load_tool(d, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(d, "eres_cleanspace_manifest.py"))
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m          # dataclasses need the module registered
    spec.loader.exec_module(m)
    return m


def master_text(d, v):
    return open(os.path.join(d, f"ERES-CLEANSPACE-2026-001_v{v}.md"), encoding="utf-8").read()


def main():
    with tempfile.TemporaryDirectory() as tmp:
        dirs = {v: unpack(tmp, v) for v in VERSIONS}

        # V: per-version integrity and own suite
        for v in VERSIONS:
            ok, n, bad = manifest_ok(dirs[v])
            rec(f"V{v}-M", ok, f"v{v} manifest: {n} files, checksums {'match' if ok else 'MISMATCH ' + str(bad)}")
        kits = {}
        for v in ("0.2", "0.3", "0.4"):
            code, rows, _ = run_kit(dirs[v])
            kits[v] = rows
            n = {k: sum(1 for s in rows.values() if s == k) for k in ("PASS", "FAIL", "SKIP")}
            rec(f"V{v}-T", code == 0 and n["FAIL"] == 0,
                f"v{v} own suite: {n['PASS']} PASS / {n['FAIL']} FAIL / {n['SKIP']} SKIP, exit {code}")
        rec("V0.1-T", True, "v0.1 is text-only: no suite to run (testing begins at v0.2)", "N/A")

        # L1: no regression -- every passing test in each version still passes in the next
        for a, b in (("0.2", "0.3"), ("0.3", "0.4")):
            miss = [t for t, st in kits[a].items() if st == "PASS" and kits[b].get(t) != "PASS"]
            rec(f"L1-{b}", not miss, f"no regression v{a} -> v{b}: all "
                f"{sum(1 for st in kits[a].values() if st == 'PASS')} v{a} PASS tests still PASS"
                + (f"; missing/failing {miss}" if miss else ""))

        # L2: band constants unchanged between v0.2 and v0.3 tools
        t2, t3, t4 = (load_tool(dirs[v], "m" + v[-1]) for v in ("0.2", "0.3", "0.4"))
        same = all((t.BAND_LOW, t.BAND_HIGH) == (0.97, 0.98) for t in (t2, t3, t4))
        rec("L2", same, "band constants identical in v0.2, v0.3 and v0.4: (0.97, 0.98)")

        # L3: v0.2 and v0.3 inventory tools give identical results on the same synthetic corpus
        corp = os.path.join(tmp, "corpus")
        os.makedirs(os.path.join(corp, "mirror"))
        paths = []
        for i in range(70):
            p = os.path.join(corp, f"ERES-X{i:03d}-2026-001_v1.0.md")
            open(p, "w").write(str(i)); paths.append(p)
        open(os.path.join(corp, "mirror", "ERES-X000-2026-001_v1.0 copy.md"), "w").write("0")
        open(os.path.join(corp, "ERES-X001-2026-001_v0.9.md"), "w").write("old")
        open(os.path.join(corp, "notes.txt"), "w").write("unidentified")
        retire = {paths[2]: "V", paths[3]: "", paths[4]: "V"}
        r2 = t2.build([corp], retire=retire)[1]
        r3 = t3.build([corp], retire=retire)[1]
        r4 = t4.build([corp], retire=retire)[1]
        rec("L3", r2 == r3 == r4, f"v0.2, v0.3 and v0.4 tools agree on a 73-file corpus: ratio {r4['recovery_ratio']}, {r4['band']}")

        # L4: core invariants from v0.1 survive in every version's text
        inv = ["Recyclable", "Held", "Retired", "unilateral", "CONSTRUCTED", "F3", "Contact of Record",
               "offset", "return to base", "CCAL v2.1"]
        for v in VERSIONS:
            txt = master_text(dirs[v], v)
            missing = [w for w in inv if w.lower() not in txt.lower()]
            rec(f"L4-v{v}", not missing, f"v{v} carries all {len(inv)} v0.1 invariants" +
                (f"; missing {missing}" if missing else ""))

        # L5: the recycling band enters at v0.2 and persists; the general thesis enters at v0.3
        t1, t2x, t3x, t4x = (master_text(dirs[v], v) for v in VERSIONS)
        rec("L5", "97/3" not in t1 and all("97/3" in t for t in (t2x, t3x, t4x))
            and "Recycle Everything Made" in t3x and "Recycle Everything Made" not in t2x
            and "Where" in t4x.split("\n", 1)[0] and "Where" not in t3x.split("\n", 1)[0],
            "lineage: band added at v0.2 and kept; general thesis at v0.3; Where (LLPM) at v0.4")

        # L6: Appendix C math present only from v0.3, and every [T##] it cites exists in the v0.3 suite
        for v, txt in (("0.3", t3x), ("0.4", t4x)):
            cited = {"T" + c for c in set(re.findall(r"T(\d\d)", txt))}
            absent = sorted(c for c in cited if c not in kits[v])
            rec(f"L6-{v}", "Appendix C" in txt and not absent,
                f"v{v} text cites {len(cited)} tests, all present in the v{v} suite"
                + (f"; absent {absent}" if absent else ""))
        rec("L6-0.2", "Appendix C" not in t2x, "math appendix absent before v0.3, as recorded")

        # L7: the no-surveillance guard (LLPM I6) holds from v0.4 onward
        spec = importlib.util.spec_from_file_location("w4", os.path.join(dirs["0.4"], "eres_cleanspace_where.py"))
        w4 = importlib.util.module_from_spec(spec); sys.modules["w4"] = w4; spec.loader.exec_module(w4)
        led = w4.TileLedger()
        led.add(w4.Record(tile=(1, 1), asset_class=w4.THOW_SLOT, occupied=True, entitlement_ref="veiled:x"))
        refused = 0
        for name in ("locate_person", "person_at", "where_is"):
            try:
                getattr(led, name)("veiled:x")
            except w4.InvariantViolation:
                refused += 1
        clean = all(f not in r for r in led.query((1, 1)) for f in w4.PERSON_FIELDS)
        rec("L7", refused == 3 and clean, "v0.4 I6 guard: 3/3 person-location calls refused; public view carries no person field")

    print("ERES-CLEANSPACE-2026-001 cross-version test package (v0.1 to v0.4)")
    print("-" * 78)
    for tid, st, msg in results:
        print(f"{tid:7} {st:5} {msg}")
    fails = sum(1 for _, s, _ in results if s == "FAIL")
    print("-" * 78)
    print(f"{sum(1 for _, s, _ in results if s == 'PASS')} PASS / {fails} FAIL / "
          f"{sum(1 for _, s, _ in results if s == 'N/A')} N/A")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
