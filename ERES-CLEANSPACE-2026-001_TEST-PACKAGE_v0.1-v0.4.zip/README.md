# ERES-CLEANSPACE-2026-001 — Test Package, v0.1 to v0.4

All four versions of the instrument, each as its own sealed ZIP, plus one runner that tests them together.

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · 19 October 2026
License: CCAL v2.1 / CC-BY 4.0 (governing text DOI 10.5281/zenodo.23451312)

## Contents

| File | What it is |
| --- | --- |
| `ERES-CLEANSPACE-2026-001_v0.1_PACKAGE.zip` | v0.1 "Clean Space — ERES Global Consolidation Plan" + companion "The Clean Space Future Map". Text only (3 files) |
| `ERES-CLEANSPACE-2026-001_v0.2_PACKAGE.zip` | v0.2 "Clean Space: One Loop, Two Spaces, One Recycling Band" — adds the 97/3–98/2 band; 13-test suite (11 files) |
| `ERES-CLEANSPACE-2026-001_v0.3_PACKAGE.zip` | v0.3 "Recycle Everything Made: What, Why and How" — general thesis + Appendix C math; 18-test suite (11 files) |
| `ERES-CLEANSPACE-2026-001_v0.4_PACKAGE.zip` | v0.4 "Recycle Everything Made: What, Why, How and Where" — LLPM binding, REEPER gate, first real evidence; 24-test suite (13 files) |
| `run_all_versions.py` | Cross-version runner (standard library only) |
| `RUN_RECORD_ALL.txt` | Runner output for this sealed package: 20 PASS / 0 FAIL / 1 N/A, exit 0 |
| `MANIFEST.json` | SHA-256 of every file in this package |

## Run

```
python3 run_all_versions.py        # exit 0 = every check passes
```

The runner unzips each version into a temporary folder and never writes anywhere else.

## What it checks

| ID | Check |
| --- | --- |
| V-M | Each version's own SHA-256 manifest matches its files |
| V-T | v0.2, v0.3 and v0.4 each pass their own suite (v0.1 has none: N/A) |
| L1 | No regression: every test that passes in one version still passes in the next |
| L2 | The band constants (0.97, 0.98) are identical in v0.2, v0.3 and v0.4 |
| L3 | The v0.2, v0.3 and v0.4 inventory tools give identical results on the same 73-file corpus |
| L4 | Ten core invariants set in v0.1 (Recyclable/Held/Retired, no unilateral disposition, CONSTRUCTED tagging, F3, Contact of Record, offset, return to base, CCAL v2.1) survive in every version |
| L5 | Lineage: band at v0.2, general thesis at v0.3, Where (LLPM) at v0.4 |
| L6 | Every test cited in v0.3 and v0.4 exists in that version's suite |
| L7 | From v0.4: no person-location query exists and public views carry no person field (LLPM I6) |

## Version line

| Version | Title | Adds | Tests |
| --- | --- | --- | --- |
| v0.1 | Clean Space — ERES Global Consolidation Plan | One loop, two stages (corpus, orbit), F1–F3, offset ledger | none |
| v0.2 | Clean Space: One Loop, Two Spaces, One Recycling Band | 97/3–98/2 band, Sentry dovetail, MIEVM Round 1 folded, inventory tool | 13 PASS / 4 SKIP |
| v0.3 | Recycle Everything Made: What, Why and How | General thesis, Applications 1–2, F6, Appendix C math | 18 PASS / 4 SKIP |
| v0.4 | Recycle Everything Made: What, Why, How and Where | LLPM I1–I6 hard rules, REEPER gate, F7–F8, first real evidence | 24 PASS / 5 SKIP |

The SKIPs are the empirical work still owed: real catalogue data (F1), measured drift and latency (F2), a full-corpus inventory with validated retirements, MIEVM Round 2, and, from v0.4, person-layer VEIL cryptography.

For contributors, the companion ERES-CLEANSPACE-2026-001_DEV-STARTER-KIT_v0.4.zip packages the v0.4 core with CONTRIBUTING, an adapter template, first issues and CI.
