#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_flip_testkit.py  —  companion to ERES-FLIP-2026-001 v0.1 PROVISIONAL

FLIP-PREMISE (CPROV): the prose states the doctrine; this code makes its
load-bearing STRUCTURAL conditions runnable; the two track one version.
A green run is evidence of INTERNAL COHERENCE, not empirical or political
truth. Every empirical/political claim in the WP stays CONJECTURE by
construction and is out of scope here.

Standard library only. Expected: PASS on structural invariants, deliberate
SKIP on the two author-reserved definitions, exit 0.

    python3 eres_flip_testkit.py
"""

import sys

TESTS_SPEC_VERSION = (0, 1)
INSTRUMENT_ID = "ERES-FLIP-2026-001"

results = []  # (name, status, detail)   status in {PASS, FAIL, SKIP}


def check(name, ok, detail=""):
    results.append((name, "PASS" if ok else "FAIL", detail))


def skip(name, detail=""):
    results.append((name, "SKIP", detail))


# ----------------------------------------------------------------------
# Minimal structural model of the FLIP's load-bearing rules.
# ----------------------------------------------------------------------

class Reserve:
    """A reserve is denominated either in priced MAGNITUDE or in
    coherence-DURATION. The FLIP forbids the magnitude denomination and
    forbids converting qualified (VEILED) credits into magnitude (F3)."""
    def __init__(self, unit):
        assert unit in ("magnitude", "duration")
        self.unit = unit

    def convert_credits_to_magnitude(self):
        # F3: earned qualification never converts to priced magnitude.
        raise ValueError("F3 violation: credits qualify issuance, never convert")


def proven_duration_years(system):
    """A not-yet-built system has zero proven years (#U2)."""
    return system.get("proven_years", 0)


def reserve_satisfies(planned_years, system):
    """Duration-backed coverage requires proven >= planned."""
    return proven_duration_years(system) >= planned_years


def reuse_allowed(site):
    """Dignity rule: ordnance clearance AND human-remains recovery must
    both precede any material reuse. Precedence is absolute."""
    return bool(site.get("ordnance_cleared")) and bool(site.get("remains_recovered"))


REGION_ROLE = {
    "obligated": False,       # §6 / C10: never asserted
    "invitation": True,       # proposal only
    "portable": True,         # offered to any electing region
    "exclusive": False,       # not to the exclusion of any region
}


# ----------------------------------------------------------------------
# t1-t3  —  The economic inversion (§1), inherited F3 non-conversion
# ----------------------------------------------------------------------
r_mag = Reserve("magnitude")
r_dur = Reserve("duration")

check("t1_duration_unit_is_legal", r_dur.unit == "duration",
      "FLIP reserve denominated in coherence-duration")

try:
    r_dur.convert_credits_to_magnitude()
    check("t2_F3_blocks_conversion", False, "conversion should have raised")
except ValueError:
    check("t2_F3_blocks_conversion", True, "F3 non-conversion enforced")

check("t3_magnitude_and_duration_distinct", r_mag.unit != r_dur.unit,
      "magnitude and duration are not conflated")

# ----------------------------------------------------------------------
# t4-t6  —  The accrual gap #U2 (§7): unsatisfiable at t=0
# ----------------------------------------------------------------------
greenfield = {"proven_years": 0}
eres_now = {"proven_years": 14}

check("t4_greenfield_zero_proven", proven_duration_years(greenfield) == 0,
      "a not-yet-built future has zero proven duration")

check("t5_U2_unsatisfiable_at_inception",
      reserve_satisfies(1000, greenfield) is False,
      "1000 proven >= 1000 planned is FALSE at t=0 (#U2 load-bearing)")

check("t6_U2_not_falsely_closed_by_eres_age",
      reserve_satisfies(1000, eres_now) is False,
      "~14 proven years do not satisfy a 1000-year map either")

# ----------------------------------------------------------------------
# t7-t9  —  Dignity rule precedence (§0, §6): absolute
# ----------------------------------------------------------------------
raw_site = {"ordnance_cleared": False, "remains_recovered": False}
partial_site = {"ordnance_cleared": True, "remains_recovered": False}
cleared_site = {"ordnance_cleared": True, "remains_recovered": True}

check("t7_no_reuse_before_clearance", reuse_allowed(raw_site) is False,
      "reuse blocked until dignity gate passes")
check("t8_partial_clearance_still_blocks", reuse_allowed(partial_site) is False,
      "both ordnance AND remains recovery required; precedence absolute")
check("t9_reuse_only_after_full_dignity_gate", reuse_allowed(cleared_site) is True,
      "reuse permitted only after full dignity gate")

# ----------------------------------------------------------------------
# t10-t12  —  Proposal-not-obligation invariants (§6 / C10)
# ----------------------------------------------------------------------
check("t10_region_not_obligated", REGION_ROLE["obligated"] is False,
      "no region is claimed to be obligated")
check("t11_method_portable_nonexclusive",
      REGION_ROLE["portable"] and not REGION_ROLE["exclusive"],
      "method offered to any electing region, exclusive to none")
check("t12_role_is_invitation", REGION_ROLE["invitation"] is True,
      "the Arab-World role is an invitation, not an assignment")

# ----------------------------------------------------------------------
# t13-t14  —  Author-reserved definitions (§0): deliberate load-bearing SKIP
# Go green ONLY when JAS confirms the two flagged readings.
# ----------------------------------------------------------------------
RT_MEDIA_CONFIRMED = False   # RECORDED/REFLECTED/RECONCILE reading
FLIP_SENSE_CONFIRMED = False  # economic-inversion + FLIP-PREMISE reading

if RT_MEDIA_CONFIRMED:
    check("t13_rt_media_reading_confirmed", True)
else:
    skip("t13_rt_media_reading_confirmed",
         "RT-Media = RECORDED/REFLECTED/RECONCILE — awaiting author confirmation (§0)")

if FLIP_SENSE_CONFIRMED:
    check("t14_flip_sense_confirmed", True)
else:
    skip("t14_flip_sense_confirmed",
         "FLIP = economic inversion + CPROV FLIP-PREMISE — awaiting author confirmation (§0)")

# ----------------------------------------------------------------------
# Runner
# ----------------------------------------------------------------------
def main():
    n_pass = sum(1 for _, s, _ in results if s == "PASS")
    n_fail = sum(1 for _, s, _ in results if s == "FAIL")
    n_skip = sum(1 for _, s, _ in results if s == "SKIP")

    width = max(len(name) for name, _, _ in results)
    print(f"{INSTRUMENT_ID}  structural testkit  (spec {TESTS_SPEC_VERSION})")
    print("-" * (width + 22))
    for name, status, detail in results:
        line = f"{name.ljust(width)}  {status}"
        if detail:
            line += f"  · {detail}"
        print(line)
    print("-" * (width + 22))
    print(f"{n_pass} pass · {n_fail} fail · {n_skip} skip "
          f"(of {len(results)})")
    print("SKIPs are load-bearing: the two author-reserved readings (§0) "
          "and go green only on author confirmation.")
    print("Green == structural COHERENCE only; empirical/political claims "
          "remain CONJECTURE (out of scope).")
    # Coherence gate: no FAILs. Skips are expected and do not fail the run.
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
