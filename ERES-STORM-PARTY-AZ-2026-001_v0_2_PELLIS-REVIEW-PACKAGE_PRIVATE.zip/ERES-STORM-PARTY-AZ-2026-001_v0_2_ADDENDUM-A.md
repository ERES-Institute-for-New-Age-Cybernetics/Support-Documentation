# THE STORM PARTY — An A–Z HOW · Addendum A

## Reviewer response and executable layer

**Instrument:** ERES-STORM-PARTY-AZ-2026-001 · **Package version:** v0.2 = BOOK v0.1 (unchanged text) + this Addendum + engine, STATE, testkit, RUN record, MANIFEST
**Status:** DRAFT · single-node drafted · CANDIDATE / SOUND · conforms to the HOUSE format · no 10-10 verdict claimed · MIEVM not yet run
**Distribution:** PRIVATE REVIEW COPY. Not for public deposit. Release (Zenodo / ResearchGate / Substack) is held until all three of these are done: (1) the reviewer confirms the attribution wording below; (2) the author rules on clarification E1; (3) the author signs the H2C2H block. Checksums are then recomputed and the package is re-cut.
**From:** Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221
**Date:** 1 October 2026
**Responds to:** Dr. Stergios Pellis, letter of 30 September 2026 — technical review and domain-specific commentary, offered as expert consultation within a collaborative research dialogue. Dr. Pellis is not represented as endorsing this instrument. This attribution wording is pending his confirmation.
**Changelog:** v0.2. Adds the executable layer that the BOOK's §10 names. Also adds A1–A8 below, which take up the reviewer's structural suggestions. The BOOK's text, its PERT inputs and its estimates are unchanged.

---

## A0. What changed and what did not

- **Unchanged:** the INVARIANT, all O/M/P inputs, the Part VIII.1 table, the root estimate of 2116.2 ± 21.13 years, and the three gaps. Testkit T1–T2 recompute every row of the BOOK's table from the engine and check it against the BOOK's own text.
- **Added:** a deterministic engine that implements the BOOK's loop. The engine changes no number in the BOOK and adds no new claim. The rules it enforces are written in plain language (R1–R9) and tested (T1–T20).

## A1. Seven-layer separation

| # | Layer | Where it lives | Status |
|---|---|---|---|
| 1 | Formal definitions and internal mathematics | BOOK §1 Notation Lock; PERT TE = (O+4M+P)/6, σ = (P−O)/6, RSS combination | Defined. Arithmetic is reproduced by T1–T2. |
| 2 | Cybernetic architecture and control logic | BOOK §3.1–3.2; engine `F`, rules R1–R9 | A design principle (BOOK §12). It has executable form but no empirical standing. |
| 3 | Operational measurement definitions | The "Sensor" line of each RUNG; the A7 table below | **Weakest layer.** Milestone sensors are observable events. The harmony constructs have no operational protocol yet (A7). |
| 4 | Empirical hypotheses | A4: one registered H₀/H₁ pair per RUNG | Pre-registered; nothing has been tested. |
| 5 | Long-range temporal estimates | BOOK Part VIII.1 | Conditional estimates from author judgment, not calibrated (A6). |
| 6 | Normative or institutional design proposals | BOOK Parts I–VI (the HOW entries: UBIMIA, DOFA, JERC/NPR, CBGMODD) | Normative. These are objects for analysis and are not used as evidence. |
| 7 | Empirical validation | `STATE.json` evidence records | Empty. No RUNG has observed evidence. |

The rule that keeps layers apart: nothing in layers 5–6 can move layer 7. Only a signed, checkable record can move layer 7 (R1, R3).

## A2. The state-transition form

The engine implements the form Dr. Pellis proposed:

> **S_{t+1} = F(S_t, E_t, M, P)**

- **S_t** is the current state in `STATE.json`: RUNG statuses, evidence, gaps, the as-of year and the revision.
- **E_t** is one human-signed evidence record: a RUNG status change, a gap closure, or an advance of the as-of year.
- **M** is the method, rule set R1–R9. It is versioned with the DETAIL layer.
- **P** is the protected INVARIANT. Its SHA-256 is fixed in the engine, and an altered P makes the engine refuse to run (T3, exit 2).

F is pure (T5) and deterministic (T4). F only accepts or rejects a record; it never sets a status on its own initiative (H2C2H). When a pessimistic bound has passed, the report raises **REFUTATION DUE** for an Operator to act on (T15).

## A3. Three regimes

| Regime | Entry condition (computed by `regime()`) | Financing reading |
|---|---|---|
| INITIALIZATION | No RUNG VERIFIED | The floor cannot finance itself (G1). An external bridge must be named. |
| TRANSITION | At least one RUNG VERIFIED, and not (all six VERIFIED and G1–G3 CLOSED) | Mixed financing: bridge plus early GunnySack surplus. |
| STEADY_STATE | All six RUNGS VERIFIED and G1, G2, G3 CLOSED | The reserve has a proven duration, so the floor can finance itself. |

This makes explicit that the terminal architecture is not treated as its own initial condition (T17). Revision 0 is in INITIALIZATION.

## A4. Registered hypotheses, one pair per RUNG

All six pairs share the same structure:

- **H₁:** the milestone reaches PILOT by its pessimistic bound and VERIFIED on a checkable record.
- **H₀:** it does not.
- **𝒟:** dated, signed, independently checkable records.
- **𝒯:** the engine compares the as-of year with the bound.
- **ℱ:** Part VII rule 1, then rule 4.

| RUNG | Milestone (H₁) | Measurement ℳ (sensor) | Bound (rev. 0) |
|---|---|---|---|
| SALEBUILDERS | First certified community lab operating as a User-GROUP | Lab with published records | 2042 |
| GUNNYSACK | Certified bundle delivers floor goods/services to a COI or EMCI group | Delivery reconciled against need | 2055 |
| CYBERRAVE | Rating in ≥1 Key Domain, independently reproduced | Outside re-run gives the same result | 2082 |
| SECUIR | Energy-security + consent-directional identity in a live pilot | Independent security audit | 2125 |
| VERTECA | Live in ≥2 jurisdictions; credentials recognized externally | Public, reproducible dashboards | 2173 |
| ERES | Multi-jurisdiction network with floor provision | Jurisdictions adopting the charter | 2303 |

**Scope limit.** These hypotheses test whether the milestones happen and when. They do not test "harmony with Nature." The harmony hypothesis is a rising Resonance trend measured against a no-trend null. It is barred from the engine until G2 closes (R7, T13), because it has no measurement protocol yet (A7).

## A5. Failure taxonomy (adopted)

The engine uses ten failure classes, and a REFUTED record must name one (R6, T11):

definitional · measurement · identifiability · causal · implementation · governance · financing · continuity · adversarial capture · model misspecification.

| Class | Where it is already guarded |
|---|---|
| financing | G1 bridge (BOOK VIII.3) |
| measurement | G2; R7 Resonance gate |
| continuity | G3; R8 root gate. Continuity is now a state variable, as the reviewer suggested. |
| implementation | Part VII rule 1 (pessimistic bound) |
| governance | R1 human signature; JERC/NPR (Entry J) |
| adversarial capture | KERNEL threshold keys (Entry K); Xray scan (Entry X) |
| model misspecification | Rule 4 whole-book refutation; the §3.1 mapping is marked CANDIDATE |
| definitional, identifiability, causal | **No guard yet.** These are registered as OPEN exposure for v0.3. |

## A6. Reproducible propagation is not calibrated uncertainty

The engine's TE and σ propagate stated assumptions reproducibly, and every report says so. They become calibrated only when observed durations are compared with the registered intervals, for example by checking interval coverage across RUNGS and across later editions. Until that record exists, "2116.2 ± 21.13" is a conditional estimate, not a prediction.

## A7. Measurement-validity status of the BOOK's constructs

| Construct | Operational definition | Protocol | Uncertainty | Reliability | Validity | Null model |
|---|---|---|---|---|---|---|
| BERA (ARI, ERI, RHC, RCI) | Named only | — | — | — | — | — |
| Resonance = (ARI+ERI)/2 | Formula only | — | — | — | — | Proposed: no-trend |
| NBERS | Domains named | — | — | — | — | GDP as comparator |
| CyberRAVE rating | Method to be published with data | — | — | — | — | Required by RUNG sensor |

A dash means not yet done. A reproducible calculation establishes only that the calculation reproduces; it does not establish construct validity. None of these constructs is used as evidence until its row is complete.

## A8. Clarifications

- **E1. The pessimistic bound in Part VII rule 1.** The BOOK says "O + P years after the prior RUNG." The engine implements this wording literally. "After the prior RUNG" is read as after that RUNG's observed year if it is VERIFIED, and otherwise after its own bound, accumulated from 2026. The resulting bounds are SALEBUILDERS 2042, GUNNYSACK 2055, CYBERRAVE 2082, SECUIR 2125, VERTECA 2173 and ERES 2303. Two choices are reserved to the author: whether "O + P" was meant to read "P", which would be stricter (2041, 2053 and so on), and which anchor to use.
- **E2. The name.** "Party" is used in the canonical, non-electoral sense (ERES-TERMS-48: "No left, no right. Just prepared."). For readers outside the ERES corpus, the standard-language description is: *a long-horizon socio-ecological systems and cybernetic design framework.*
- **E3. Open questions for the reviewer:**
  1. Is A2's form, with P held fixed through a hash guard, an adequate representation of the invariant/update separation?
  2. Which of the three unguarded failure classes (definitional, identifiability, causal) should get the first formal test?

---

**Reproduce:** `python3 storm_party_engine.py report` · `python3 test_storm_party.py --verify-manifest` (expected: 21 PASS, exit 0)

**Record Integrity (H2C2H).** Drafting node: Claude (Anthropic), single node. Human review and signature: ______________________ (JAS), date ________.

**License.** CARE Commons Attribution License v2.1 (CCAL) / CC-BY 4.0.
