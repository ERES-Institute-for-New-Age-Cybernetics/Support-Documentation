#!/usr/bin/env python3
"""Testkit for ERES-STORM-PARTY-AZ-2026-001 package v0.2.
Standard library only, deterministic. Run:  python3 test_storm_party.py [--verify-manifest]
Every test works on an in-memory copy; STATE.json on disk is never written.
"""
import copy, glob, hashlib, json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import storm_party_engine as eng

S0 = json.load(open(os.path.join(HERE, "STATE.json"), encoding="utf-8"))
BOOK = open(glob.glob(os.path.join(HERE, "ERES-STORM-PARTY-AZ-2026-001_v0_1_BOOK.md"))[0],
            encoding="utf-8").read()
results = []
def test(name, cond):
    results.append((name, bool(cond)))

def ev(rung, status, year, **kw):
    e = {"type": "rung_status", "rung": rung, "status": status, "year": year,
         "record_ref": "doi:10.0000/example", "signed_by": "Operator"}
    e.update(kw); return e

def at(year, S=None):
    return eng.F(S or S0, {"type": "as_of", "year": year, "signed_by": "Operator"})

def rejects(S, E):
    try: eng.F(S, E); return False
    except eng.Rejected: return True

def climb(S, upto):  # PILOT then VERIFIED, one RUNG per year, through RUNG index `upto`
    for k, r in enumerate(S["rungs"][:upto + 1]):
        S = eng.F(S, ev(r["name"], "PILOT", 2027 + k))
        S = eng.F(S, ev(r["name"], "VERIFIED", 2027 + k))
    return S

# T1 revision-0 forecast reproduces the book's Part VIII.1 table, row by row
rows = eng.forecast(S0)
tbl = re.findall(r"^\| (\w+) \| (\d+) \| (\d+) \| (\d+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\w ]+?) \|$",
                 BOOK, re.M)
test("T1 engine == book table VIII.1 (O/M/P/TE/σ/year/phase)", len(tbl) == 6 and all(
    t[0] == r["rung"] and (int(t[1]), int(t[2]), int(t[3])) == (r["O"], r["M"], r["P"])
    and float(t[4]) == round(r["TE"], 2) and float(t[5]) == round(r["sigma"], 2)
    and float(t[6]) == round(r["expected"], 1) and t[7] == r["phase"] for t, r in zip(tbl, rows)))
# T2 root headline: 2116.2 ± 21.13, margin ≈ 909
test("T2 root 2116.2 ± 21.13, margin 909", round(rows[-1]["expected"], 1) == 2116.2
     and round(rows[-1]["cum_sigma"], 2) == 21.13 and round(3025 - rows[-1]["expected"]) == 909
     and "2116.2 ± 21.13" in BOOK)
# T3 INVARIANT tamper -> refuse (in-process and via CLI exit 2)
bad = copy.deepcopy(S0); bad["INVARIANT"]["principles"] = ["SELF", "OTHERS"]
try: eng.forecast(bad); t3 = False
except eng.InvariantViolation: t3 = True
with tempfile.TemporaryDirectory() as d:
    p = os.path.join(d, "S.json"); json.dump(bad, open(p, "w"))
    rc = subprocess.run([sys.executable, os.path.join(HERE, "storm_party_engine.py"), "report",
                         "--state", p], capture_output=True).returncode
test("T3 altered INVARIANT refused (exit 2)", t3 and rc == 2)
# T4 determinism
test("T4 report deterministic", eng.report(S0) == eng.report(copy.deepcopy(S0)))
# T5 F is pure: input state unchanged
snap = json.dumps(S0, sort_keys=True); eng.F(at(2030), ev("SALEBUILDERS", "PILOT", 2028))
test("T5 F does not mutate S_t", json.dumps(S0, sort_keys=True) == snap)
# T6 H2C2H: unsigned record rejected
test("T6 R1 unsigned rejected", rejects(at(2030), ev("SALEBUILDERS", "PILOT", 2028, signed_by="")))
# T7 transition order: NOT_STARTED -> VERIFIED rejected
test("T7 R2 skip PILOT rejected", rejects(at(2030), ev("SALEBUILDERS", "VERIFIED", 2029)))
# T8 VERIFIED needs record and year <= as-of
S = eng.F(at(2030), ev("SALEBUILDERS", "PILOT", 2028))
test("T8 R3 record + date required", rejects(S, ev("SALEBUILDERS", "VERIFIED", 2029, record_ref=""))
     and rejects(S, ev("SALEBUILDERS", "VERIFIED", 2031)))
# T9 VERIFIED collapses to observed year, σ resets, downstream shifts
S = eng.F(S, ev("SALEBUILDERS", "VERIFIED", 2029)); r = eng.forecast(S)
test("T9 VERIFIED collapse: σ→0, downstream −2.33 yr", r[0]["expected"] == 2029 and r[0]["cum_sigma"] == 0
     and abs(r[1]["expected"] - (2029 + 29 / 6)) < 1e-9 and abs(r[-1]["expected"] - (rows[-1]["expected"] - 7 / 3)) < 1e-9)
# T10 ladder rule: GUNNYSACK cannot be VERIFIED before SALEBUILDERS
S = eng.F(eng.F(at(2035), ev("GUNNYSACK", "PILOT", 2030)), ev("SALEBUILDERS", "PILOT", 2030))
test("T10 R5 ladder rule", rejects(S, ev("GUNNYSACK", "VERIFIED", 2031)))
# T11 REFUTED needs failure class; then halts everything above
S = at(2045)
nofc = rejects(S, ev("GUNNYSACK", "REFUTED", 2044))
S = eng.F(S, ev("GUNNYSACK", "REFUTED", 2044, failure_class="financing")); r = eng.forecast(S)
test("T11 R6 failure class + R4 halt above", nofc and all(x["phase"] == "HALTED" for x in r[1:])
     and r[0]["expected"] is not None and rejects(S, ev("CYBERRAVE", "PILOT", 2045))
     and "Ladder halted at GUNNYSACK" in eng.next_action(S))
# T12 failure taxonomy = Pellis's ten classes; every gap maps into it
test("T12 taxonomy 10 classes, gaps mapped", len(eng.FAILURE_CLASSES) == 10
     and all(g["failure_class"] in eng.FAILURE_CLASSES for g in S0["gaps"].values()))
# T13 measurement gate: Resonance evidence barred while G2 OPEN
S = at(2030)
g2 = eng.F(S, {"type": "gap_status", "gap": "G2", "status": "CLOSED", "year": 2030,
               "record_ref": "SIGFID-class report", "signed_by": "Operator"})
test("T13 R7 Resonance barred until G2 CLOSED",
     rejects(S, ev("SALEBUILDERS", "PILOT", 2028, kind="resonance"))
     and not rejects(g2, ev("SALEBUILDERS", "PILOT", 2028, kind="resonance")))
# T14 root claim needs continuity (G3) CLOSED
S = climb(at(2040), 4); S = eng.F(S, ev("ERES", "PILOT", 2035))
g3 = eng.F(S, {"type": "gap_status", "gap": "G3", "status": "CLOSED", "year": 2036,
               "record_ref": "ratified CAI", "signed_by": "Operator"})
test("T14 R8 root needs G3", rejects(S, ev("ERES", "VERIFIED", 2036))
     and not rejects(g3, ev("ERES", "VERIFIED", 2036)))
# T15 pessimistic bound -> REFUTATION DUE flag (never auto-applied); cumulative bounds
f42, f43 = eng.flags(at(2042)), eng.flags(at(2043))
test("T15 bound 2042 flags at 2043, status untouched; bounds cumulative",
     not f42 and any("SALEBUILDERS" in f for f in f43) and at(2043)["rungs"][0]["status"] == "NOT_STARTED"
     and [x["bound"] for x in rows] == [2042, 2055, 2082, 2125, 2173, 2303])
# T16 whole-book refutation (rule 4)
S = at(2049)
for n in ("SALEBUILDERS", "GUNNYSACK"):
    S = eng.F(S, ev(n, "REFUTED", 2048, failure_class="implementation"))
test("T16 rule 4 book refutation", any("BOOK REFUTED" in f for f in eng.flags(S)))
# T17 regimes: INITIALIZATION -> TRANSITION -> STEADY_STATE
S = climb(at(2040), 0); mid = eng.regime(S)
S = climb(at(2040), 4); S = eng.F(S, ev("ERES", "PILOT", 2035))
for g in ("G1", "G2", "G3"):
    S = eng.F(S, {"type": "gap_status", "gap": g, "status": "CLOSED", "year": 2036,
                  "record_ref": "record", "signed_by": "Operator"})
S = eng.F(S, ev("ERES", "VERIFIED", 2036))
test("T17 three regimes", eng.regime(S0) == "INITIALIZATION" and mid == "TRANSITION"
     and eng.regime(S) == "STEADY_STATE")
# T18 as-of monotone
test("T18 R9 as-of never backward", rejects(at(2030), {"type": "as_of", "year": 2029, "signed_by": "Op"}))
# T19 next action at revision 0 matches the book's PERCMARC (SALEBUILDERS lab + G1 bridge)
na = eng.next_action(S0)
test("T19 next action == PERCMARC VIII.4", na.startswith("SALEBUILDERS") and "bridge" in na and "(G1)" in na)
# T20 log + revision bump on every accepted record
S = at(2030)
test("T20 revision/log", S["state_revision"] == 1 and len(S["log"]) == 1 and S0["log"] == [])

if "--verify-manifest" in sys.argv:
    man = json.load(open(os.path.join(HERE, "MANIFEST.json"), encoding="utf-8"))
    ok = all(hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest() == h
             for f, h in man["files"].items())
    test("T21 MANIFEST checksums", ok and man["invariantsTouched"] == []
         and man["invariant_sha256"] == eng.INVARIANT_SHA256)

fails = 0
for n, ok in results:
    print(("PASS " if ok else "FAIL ") + n); fails += (not ok)
print("%d PASS / %d FAIL" % (len(results) - fails, fails))
sys.exit(1 if fails else 0)
