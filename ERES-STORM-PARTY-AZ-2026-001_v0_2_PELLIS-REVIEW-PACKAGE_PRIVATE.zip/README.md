# ERES-STORM-PARTY-AZ-2026-001 · v0.2 Review Package

THE STORM PARTY — An A–Z HOW, together with its executable layer (the Cybernetic_ARTIFACT).
DRAFT · CANDIDATE / SOUND · no 10-10 verdict claimed · CCAL v2.1 / CC-BY 4.0

**PRIVATE REVIEW COPY. Not for public deposit.** Release is held until the reviewer confirms the attribution wording, the author rules on E1 (Addendum A8), and the author signs the H2C2H block. Checksums are then recomputed and the package is re-cut.

| File | Role |
|---|---|
| `ERES-STORM-PARTY-AZ-2026-001_v0_1_BOOK.md` | The BOOK, unchanged from the edition already reviewed |
| `ERES-STORM-PARTY-AZ-2026-001_v0_2_ADDENDUM-A.md` | Reviewer response: seven-layer map, F(S,E,M,P), regimes, H₀/H₁ per RUNG, failure taxonomy, measurement-validity table, clarifications |
| `storm_party_engine.py` | Deterministic engine: S_{t+1} = F(S_t, E_t, M, P), PERT roll-up, rules R1–R9 |
| `STATE.json` | Revision 0: all RUNGS at NOT_STARTED, gaps G1–G3 OPEN, protected INVARIANT |
| `test_storm_party.py` | Testkit T1–T21 (T21 runs with `--verify-manifest`) |
| `RUN.txt` | Captured output of the two commands below |
| `MANIFEST.json` | SHA-256 checksums for every file, the REGISTRAR entry, and `invariantsTouched: []` |

**Run** (Python 3.8+, standard library only, no network, no randomness):

```
python3 storm_party_engine.py report
python3 test_storm_party.py --verify-manifest     # expect 21 PASS, exit 0
```

**Record evidence.** Every record needs a human signature. The engine does not set any status on its own:

```
python3 storm_party_engine.py asof 2028 --signed "JAS"
python3 storm_party_engine.py update SALEBUILDERS PILOT --year 2028 --record "<checkable ref>" --signed "JAS"
python3 storm_party_engine.py update GUNNYSACK REFUTED --year 2050 --record "<ref>" --failure-class financing --signed "JAS"
python3 storm_party_engine.py gap G1 CLOSED --year 2029 --record "<ref>" --signed "JAS"
```

Exit codes: 0 = accepted · 2 = INVARIANT altered (refused) · 3 = record rejected by a rule.

Run the update commands on a copy of `STATE.json` (pass `--state PATH`). Changing the shipped file breaks its MANIFEST checksum.
