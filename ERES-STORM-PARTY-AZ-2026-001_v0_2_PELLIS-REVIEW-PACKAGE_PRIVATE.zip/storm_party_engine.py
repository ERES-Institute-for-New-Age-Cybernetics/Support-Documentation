#!/usr/bin/env python3
"""
storm_party_engine.py — executable layer of ERES-STORM-PARTY-AZ-2026-001
("THE STORM PARTY — An A-Z HOW"), package v0.2.

Python 3.8+ standard library only. No network, no randomness: same STATE in,
same report out.

The engine is one state-transition function plus read-only views of the state:

    S_{t+1} = F(S_t, E_t, M, P)

    S_t  current state (STATE.json: RUNG statuses, evidence, gaps, as-of year)
    E_t  one signed evidence record (a RUNG status change, a gap closure,
         or an as-of-year advance)
    M    the method: the rule set below (RULES), versioned with DETAIL
    P    the protected INVARIANT. Its SHA-256 is fixed in this file. If STATE
         carries a different INVARIANT, the engine refuses to run (exit 2).

F proposes nothing and decides nothing on its own (H2C2H): it only accepts or
rejects a human-signed record. Status is never changed automatically; when a
pessimistic bound passes, the report flags REFUTATION DUE for an Operator.

Commands:
    report                       forecast table, regime, flags, next action
    next_action                  the single next operator action
    update RUNG STATUS --year Y --record REF --signed NAME
           [--failure-class C] [--kind K]
    gap GID STATUS --year Y --record REF --signed NAME
    asof YEAR --signed NAME
    verify                       check the INVARIANT only
Options: --state PATH (default STATE.json next to this file)

Epistemic status of the numbers: PERT O/M/P inputs are single-node author
judgments. TE and sigma are conditional estimates (reproducible propagation
of stated assumptions), NOT empirically calibrated predictive uncertainty.
"""
import copy
import hashlib
import json
import math
import os
import sys

ENGINE_VERSION = "0.2"

# SHA-256 of the canonical JSON of STATE["INVARIANT"] (sorted keys, no spaces).
INVARIANT_SHA256 = "f17b472e09ce45c1255e6a5fd561f494657278fcf0a54ea87f8089b46169a56c"

STATUSES = ("NOT_STARTED", "PILOT", "VERIFIED", "REFUTED")
ALLOWED = {  # pre-registered transitions (book §3.2, Part VII)
    "NOT_STARTED": {"PILOT", "REFUTED"},
    "PILOT": {"VERIFIED", "REFUTED"},
    "VERIFIED": {"REFUTED"},          # later contrary evidence may demote
    "REFUTED": set(),                 # terminal for this DETAIL version
}

# Failure taxonomy (adopted from Dr. Pellis's 30 Sep 2026 commentary).
FAILURE_CLASSES = (
    "definitional", "measurement", "identifiability", "causal",
    "implementation", "governance", "financing", "continuity",
    "adversarial_capture", "model_misspecification",
)

GAP_STATUSES = ("OPEN", "CLOSED")
FOUNDATION_END = 2050

RULES = {
    "R1": "Every evidence record carries a human signature (H2C2H).",
    "R2": "Status moves only NOT_STARTED->PILOT->VERIFIED, or to REFUTED.",
    "R3": "VERIFIED needs a dated, independently checkable record no later than as-of.",
    "R4": "No RUNG above a REFUTED RUNG may advance (ladder halt).",
    "R5": "VERIFIED at a RUNG needs the RUNG below it VERIFIED (ladder rule).",
    "R6": "REFUTED must name a failure class from the taxonomy.",
    "R7": "Resonance-kind evidence is rejected while G2 (measurement) is OPEN.",
    "R8": "The ERES root may not be VERIFIED while G3 (continuity) is OPEN.",
    "R9": "The as-of year never moves backward.",
}


class Rejected(Exception):
    """Evidence record refused by a rule in M."""


class InvariantViolation(Exception):
    """STATE carries an altered INVARIANT (P)."""


# ---------------------------------------------------------------- invariant
def invariant_digest(inv):
    blob = json.dumps(inv, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def check_invariant(state):
    if invariant_digest(state["INVARIANT"]) != INVARIANT_SHA256:
        raise InvariantViolation("INVARIANT altered; engine refuses to run.")
    return state["INVARIANT"]


# ---------------------------------------------------------------- PERT views
def pert(o, m, p):
    return (o + 4 * m + p) / 6.0, (p - o) / 6.0


def phase_of(year, inv):
    for name, start, end in inv["phases"]:
        if start <= year < end:
            return name
    return "Beyond horizon" if year >= inv["horizon_end_year"] else "Pre-Foundation"


def forecast(state):
    """Roll PERT up the RUNGS, ground to root.

    VERIFIED: collapses to its observed year; accumulated variance resets to 0.
    REFUTED: this RUNG and every RUNG above it are HALTED.
    Otherwise: expected = anchor + TE; variance accumulates (root-sum-of-squares).
    Pessimistic bound (Part VII rule 1, literal "O + P years after the prior
    RUNG"): anchor_P + O + P, where anchor_P is the observed year of the RUNG
    below if VERIFIED, else that RUNG's own bound (origin year for the ground).
    """
    inv = check_invariant(state)
    anchor, var = float(state["origin_year"]), 0.0
    anchor_p = float(state["origin_year"])
    halted, rows = False, []
    for r in state["rungs"]:
        o, m, p = r["pert"]["O"], r["pert"]["M"], r["pert"]["P"]
        te, sd = pert(o, m, p)
        row = {"rung": r["name"], "O": o, "M": m, "P": p, "TE": te, "sigma": sd,
               "status": r["status"]}
        if halted or r["status"] == "REFUTED":
            halted = True
            row.update(expected=None, cum_sigma=None, phase="HALTED", bound=None)
            rows.append(row)
            continue
        bound = anchor_p + o + p
        if r["status"] == "VERIFIED":
            anchor, var = float(r["evidence"]["year"]), 0.0
            anchor_p = anchor
        else:
            anchor, var = anchor + te, var + sd * sd
            anchor_p = bound
        row.update(expected=anchor, cum_sigma=math.sqrt(var),
                   phase=phase_of(anchor, inv), bound=bound)
        rows.append(row)
    return rows


def flags(state):
    out = []
    asof = state["as_of_year"]
    for row in forecast(state):
        if row["bound"] is not None and row["status"] == "NOT_STARTED" and asof > row["bound"]:
            out.append("REFUTATION DUE: %s has not reached PILOT by its pessimistic "
                       "bound %.1f (Part VII rule 1); Operator to record REFUTED."
                       % (row["rung"], row["bound"]))
    st = {r["name"]: r for r in state["rungs"]}
    ground = [st["SALEBUILDERS"], st["GUNNYSACK"]]
    if all(r["status"] == "REFUTED" and r["evidence"]["year"] < FOUNDATION_END for r in ground):
        out.append("BOOK REFUTED: SALEBUILDERS and GUNNYSACK both REFUTED within "
                   "Foundation (Part VII rule 4). Supersede this edition.")
    return out


def regime(state):
    """Initialization -> Transition -> Steady state (formal entry conditions).

    INITIALIZATION: no RUNG VERIFIED. The floor cannot finance itself (G1).
    TRANSITION:     at least one RUNG VERIFIED, but not all RUNGS VERIFIED
                    or not all gaps CLOSED.
    STEADY_STATE:   all six RUNGS VERIFIED and G1, G2, G3 all CLOSED.
    """
    v = [r["status"] == "VERIFIED" for r in state["rungs"]]
    if not any(v):
        return "INITIALIZATION"
    if all(v) and all(g["status"] == "CLOSED" for g in state["gaps"].values()):
        return "STEADY_STATE"
    return "TRANSITION"


def next_action(state):
    if any("BOOK REFUTED" in f for f in flags(state)):
        return "Supersede this edition; register a new DETAIL version before further claims."
    for r in state["rungs"]:
        if r["status"] == "REFUTED":
            return ("Ladder halted at %s (%s failure). Write a superseding DETAIL for it; "
                    "no claims above it until then."
                    % (r["name"], r["evidence"]["failure_class"]))
    for r in state["rungs"]:
        if r["status"] != "VERIFIED":
            act = {"NOT_STARTED": "start a PILOT", "PILOT": "obtain a dated, independently "
                   "checkable record to move it to VERIFIED"}[r["status"]]
            msg = "%s: %s. Milestone: %s. Sensor: %s." % (r["name"], act, r["milestone"], r["sensor"])
            if r["name"] in ("SALEBUILDERS", "GUNNYSACK") and state["gaps"]["G1"]["status"] == "OPEN":
                msg += " Name the bridge that finances the first GunnySack bundle (G1)."
            if r["name"] == "ERES" and state["gaps"]["G3"]["status"] == "OPEN":
                msg += " Ratify the Continuity & Abdication Instrument first (G3)."
            return msg
    open_g = [k for k, g in state["gaps"].items() if g["status"] == "OPEN"]
    if open_g:
        return "All RUNGS VERIFIED; close gaps %s to reach STEADY_STATE." % ", ".join(open_g)
    return "STEADY_STATE: hand the full VERIFIED record to MIEVM."


# ---------------------------------------------------------------- F
def F(S, E, M=RULES, P_digest=INVARIANT_SHA256):
    """S_{t+1} = F(S_t, E_t, M, P). Pure: S is never mutated.

    Raises InvariantViolation if P is altered, Rejected if E breaks a rule in M.
    """
    if invariant_digest(S["INVARIANT"]) != P_digest:
        raise InvariantViolation("INVARIANT altered; engine refuses to run.")
    if not str(E.get("signed_by", "")).strip():
        raise Rejected("R1: unsigned record")
    S1 = copy.deepcopy(S)
    t = E.get("type")

    if t == "as_of":
        y = int(E["year"])
        if y < S["as_of_year"]:
            raise Rejected("R9: as-of year may not move backward")
        S1["as_of_year"] = y

    elif t == "gap_status":
        g = E["gap"]
        if g not in S1["gaps"] or E["status"] not in GAP_STATUSES:
            raise Rejected("unknown gap or gap status")
        if E["status"] == "CLOSED" and not str(E.get("record_ref", "")).strip():
            raise Rejected("R3: closing a gap needs a checkable record")
        S1["gaps"][g]["status"] = E["status"]
        S1["gaps"][g]["evidence"] = {"year": int(E["year"]), "record_ref": E.get("record_ref"),
                                     "signed_by": E["signed_by"]}

    elif t == "rung_status":
        names = [r["name"] for r in S1["rungs"]]
        if E["rung"] not in names:
            raise Rejected("unknown RUNG")
        i = names.index(E["rung"])
        r, new = S1["rungs"][i], E["status"]
        if new not in STATUSES or new not in ALLOWED[r["status"]]:
            raise Rejected("R2: %s -> %s not allowed" % (r["status"], new))
        if any(x["status"] == "REFUTED" for x in S1["rungs"][:i]) and new != "REFUTED":
            raise Rejected("R4: a lower RUNG is REFUTED; ladder halted")
        year = int(E["year"])
        if year < S["origin_year"] or year > S["as_of_year"]:
            raise Rejected("R3: evidence year must lie between origin and as-of")
        if new == "VERIFIED":
            if not str(E.get("record_ref", "")).strip():
                raise Rejected("R3: VERIFIED needs an independently checkable record")
            if i > 0 and S1["rungs"][i - 1]["status"] != "VERIFIED":
                raise Rejected("R5: RUNG below is not VERIFIED")
            if r["name"] == "ERES" and S1["gaps"]["G3"]["status"] != "CLOSED":
                raise Rejected("R8: root claim needs G3 (continuity) CLOSED")
        if new == "REFUTED" and E.get("failure_class") not in FAILURE_CLASSES:
            raise Rejected("R6: REFUTED needs a failure class from the taxonomy")
        if E.get("kind") == "resonance" and S1["gaps"]["G2"]["status"] != "CLOSED":
            raise Rejected("R7: Resonance evidence barred while G2 (measurement) is OPEN")
        r["status"] = new
        r["evidence"] = {"year": year, "record_ref": E.get("record_ref"),
                         "signed_by": E["signed_by"], "kind": E.get("kind"),
                         "failure_class": E.get("failure_class")}
    else:
        raise Rejected("unknown evidence type")

    S1["state_revision"] = S["state_revision"] + 1
    S1["log"] = S["log"] + [dict(E, revision=S1["state_revision"])]
    return S1


# ---------------------------------------------------------------- report
def report(state):
    rows = forecast(state)
    L = ["ERES-STORM-PARTY-AZ-2026-001 · engine v%s · STATE revision %d · as-of %d"
         % (ENGINE_VERSION, state["state_revision"], state["as_of_year"]),
         "INVARIANT sha256 %s  OK" % INVARIANT_SHA256[:16],
         "",
         "%-13s %4s %4s %4s %7s %6s %-12s %9s %8s %-24s" % (
             "RUNG", "O", "M", "P", "TE", "sigma", "status", "expected", "P-bound", "phase")]
    for r in rows:
        exp = "%9.1f" % r["expected"] if r["expected"] is not None else "        -"
        bnd = "%8.1f" % r["bound"] if r["bound"] is not None else "       -"
        L.append("%-13s %4d %4d %4d %7.2f %6.2f %-12s %s %s %-24s" % (
            r["rung"], r["O"], r["M"], r["P"], r["TE"], r["sigma"], r["status"], exp, bnd, r["phase"]))
    root = rows[-1]
    L.append("")
    if root["expected"] is not None:
        L.append("Root RUNG expected: %.1f ± %.2f years (1σ); horizon margin to %d: %.0f years"
                 % (root["expected"], root["cum_sigma"], state["INVARIANT"]["horizon_end_year"],
                    state["INVARIANT"]["horizon_end_year"] - root["expected"]))
    else:
        L.append("Root RUNG: HALTED (a lower RUNG is REFUTED)")
    L.append("Register: conditional estimate — PERT inputs are author judgment, not calibrated.")
    L.append("Regime: %s" % regime(state))
    L.append("Gaps: " + ", ".join("%s %s (%s)" % (k, g["status"], g["failure_class"])
                                  for k, g in sorted(state["gaps"].items())))
    for f in flags(state):
        L.append("FLAG " + f)
    L.append("NEXT ACTION: " + next_action(state))
    return "\n".join(L)


# ---------------------------------------------------------------- CLI
def _load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _save(path, state):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(state, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def _opt(args, name, default=None):
    if name in args:
        i = args.index(name)
        return args[i + 1]
    return default


def main(argv):
    here = os.path.dirname(os.path.abspath(__file__))
    path = _opt(argv, "--state", os.path.join(here, "STATE.json"))
    cmd = argv[0] if argv else "report"
    try:
        S = _load(path)
        check_invariant(S)
        if cmd == "report":
            print(report(S))
        elif cmd == "next_action":
            print(next_action(S))
        elif cmd == "verify":
            print("INVARIANT OK")
        elif cmd in ("update", "gap", "asof"):
            if cmd == "update":
                E = {"type": "rung_status", "rung": argv[1], "status": argv[2],
                     "year": _opt(argv, "--year"), "record_ref": _opt(argv, "--record"),
                     "signed_by": _opt(argv, "--signed", ""),
                     "failure_class": _opt(argv, "--failure-class"), "kind": _opt(argv, "--kind")}
            elif cmd == "gap":
                E = {"type": "gap_status", "gap": argv[1], "status": argv[2],
                     "year": _opt(argv, "--year"), "record_ref": _opt(argv, "--record"),
                     "signed_by": _opt(argv, "--signed", "")}
            else:
                E = {"type": "as_of", "year": argv[1], "signed_by": _opt(argv, "--signed", "")}
            S1 = F(S, E)
            _save(path, S1)
            print("Accepted. STATE revision %d." % S1["state_revision"])
            print(report(S1))
        else:
            print(__doc__)
            return 64
    except InvariantViolation as e:
        print("REFUSED: %s" % e, file=sys.stderr)
        return 2
    except Rejected as e:
        print("REJECTED: %s" % e, file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
