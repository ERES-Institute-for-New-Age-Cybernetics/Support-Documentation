#!/usr/bin/env python3
"""
ERES-N2N-HHS-2026-001 v0.1 -- Nation-by-Nation Healthy-Happy-Safe TEST instrument
Companion testkit (zero-dependency, stdlib only).

Structure under test:
  CERTIFY  nation -> Healthy/Happy/Safe score (public data, min-rule)
  COUPLE   GAIA holds cross-nation coupling, n_eff, top-down bands
  TWIN     SOMT = SROC C2H2C Digital Twin for GAIA User-GROUPs (from H2C2H)
  TEST     twin-vs-measured gap (= ERES violence metric), pre-registered, no back-fitting

All data here is SYNTHETIC. Synthetic results cannot confirm or refute (Sec. 8).
DESIGN tests (T..) confirm + refuse; UNIT checks (U..) carry no design evidence.
Exit 0 = no FAIL.  License: CCAL v2.1 / CC-BY 4.0
"""
import hashlib, json, random, sys

SEED = 20261025
R = random.Random(SEED)
RESULTS = []
def rec(t, n, s, note=""): RESULTS.append((t, n, s, note))

# ---------- Sec. 3 certification ----------
# Goalposts (declared; life-expectancy pair follows UNDP HDI convention 20/85 years)
GOAL = {"healthy": (20.0, 85.0),        # life expectancy at birth, years
        "safe":    (0.0, 60.0),         # violent deaths per 100k (homicide + conflict); inverted
        "happy":   (0.0, 10.0)}         # Cantril ladder 0-10
def norm(term, x):
    lo, hi = GOAL[term]; v = (x - lo) / (hi - lo); v = min(1.0, max(0.0, v))
    return 1.0 - v if term == "safe" else v
def hhs(n):
    s = {k: norm(k, n[k]) for k in GOAL}
    return s, min(s.values())                     # min-rule: weakest term grades the nation
def tier(score):
    return "SOUND" if score >= 0.70 else "GOOD" if score >= 0.50 else "BELOW"

# ---------- Sec. 4 identifiability (reconstruction fibre) ----------
# Toy model. A design has FOUR knobs (health spend, social cohesion, policing, wealth) in [0,1]^4.
# The certification OBSERVES only the min-rule score (one number): the observation map discards information.
def terms(d):
    h, c, p, w = d
    return (0.5 * h + 0.2 * c + 0.3 * w,         # healthy
            0.2 * h + 0.6 * c + 0.2 * w,         # happy
            0.4 * c + 0.4 * p + 0.2 * w)         # safe
def observe(d):
    return round(min(terms(d)), 2)               # what nation-by-nation certification reports
def response(d, shock=1.0):
    """SOMT record after an intervention: all three terms, five periods. Designs differ in HOW they respond."""
    h, c, p, w = d
    gain = (0.8 * h - 0.2 * c, 0.5 * c, 0.6 * p - 0.1 * w)
    return tuple(round(terms(d)[k] + shock * gain[k] * (1 - 0.5 ** t), 3) for t in range(1, 6) for k in range(3))
GRID = [i / 5 for i in range(6)]
def fibres(obs):
    by = {}
    for h in GRID:
        for c in GRID:
            for p in GRID:
                for w in GRID:
                    d = (h, c, p, w); by.setdefault(obs(d), []).append(d)
    return by

# ---------- Sec. 5 GAIA coupling ----------
def neff(N, rho): return N / (1 + (N - 1) * rho)

# ---------- Sec. 6 SOMT twin ----------
def params_hash(p): return hashlib.sha256(json.dumps(p, sort_keys=True).encode()).hexdigest()
def twin_predict(p, d): return round(p["a"] * d[0] + p["b"] * d[1], 3)
def violence(computer, human, scale=1.0): return abs(computer - human) / scale
GAP_TRUST, GAP_FINDING = 0.05, 0.15     # pre-registered thresholds

PREREG = {"indicator": "twin-vs-measured gap per User-GROUP",
          "horizon": "5 periods after intervention",
          "failure": "gap > 0.15 on >= 1/3 of groups",
          "null": "twin no better than persistence (last value carried forward)",
          "metric": "mean absolute gap, normalized",
          "acceptance": "gap < 0.05 on >= 2/3 of groups AND beats null"}
PREREG_HASH = params_hash(PREREG)

# ================= DESIGN TESTS =================
def T01():
    a = {"healthy": 82, "safe": 1.0, "happy": 7.4}
    b = {"healthy": 82, "safe": 40.0, "happy": 7.4}
    sa, ga = hhs(a); sb, gb = hhs(b)
    ok = tier(ga) == "SOUND" and gb < 0.4 and gb == sb["safe"]
    rec("T01", "Min-rule: strong in two terms, weak in one -> graded at the weak term", "PASS" if ok else "FAIL",
        f"A={ga:.2f}, B={gb:.2f}")

def T02():
    by = fibres(observe)
    multi = sum(1 for v in by.values() if len(v) > 1)
    biggest = max(len(v) for v in by.values())
    ok = multi > 0 and biggest > 1
    rec("T02", "Reverse problem: the certified score alone does NOT identify the design (fibres > 1)",
        "PASS" if ok else "FAIL", f"{multi} score values shared by >1 design; largest fibre {biggest}")

def T03():
    by = fibres(observe)
    fibre = max(by.values(), key=len)
    sub = {}
    for d in fibre:
        sub.setdefault(response(d), []).append(d)
    after = max(len(v) for v in sub.values())
    ok = after < len(fibre)
    rec("T03", "SOMT time-series after intervention shrinks the fibre -> designs separate",
        "PASS" if ok else "FAIL", f"largest fibre {len(fibre)} -> {after} designs")

def T03b():
    # Negative control: if the observation already keeps all information (identity map), there is nothing to shrink.
    by = fibres(lambda d: d)
    ok = max(len(v) for v in by.values()) == 1
    rec("T03b", "Control: an information-preserving observation map has no fibres (identifiable)",
        "PASS" if ok else "FAIL")

def T04():
    # A buys Safe by exporting harm to B (displacement). Uncoupled ledger overcounts.
    gainA, harmB = 0.20, 0.15
    uncoupled = gainA
    coupled = gainA - harmB
    ok = coupled < uncoupled and abs(coupled - 0.05) < 1e-9
    rec("T04", "GAIA coupling: displaced harm is netted; nation-only ledger overcounts", "PASS" if ok else "FAIL",
        f"uncoupled +{uncoupled:.2f} vs coupled +{coupled:.2f}")

def T05():
    N = 190
    ok = neff(N, 0.0) == N and neff(N, 0.3) < 4 and neff(N, 1.0) == 1
    rec("T05", "n_eff: correlated nations count as far fewer independent cases", "PASS" if ok else "FAIL",
        f"N=190, rho=0.3 -> n_eff={neff(N, 0.3):.1f}")

def T06():
    p = {"a": 0.6, "b": 0.4}
    d = (0.8, 0.5, 0.5)
    comp = twin_predict(p, d)
    near, far = comp + 0.02, comp + 0.30
    ok = violence(comp, near) < GAP_TRUST and violence(comp, far) > GAP_FINDING
    rec("T06", "Twin-vs-measured gap: small -> twin trusted for group; large -> recorded as finding",
        "PASS" if ok else "FAIL")

def T07():
    frozen = {"a": 0.6, "b": 0.4}; h0 = params_hash(frozen)
    refit = dict(frozen, a=0.71)      # twin quietly corrected toward measured after the fact
    ok = params_hash(frozen) == h0 and params_hash(refit) != h0
    rec("T07", "No back-fitting: twin params hashed before outcomes; any post-hoc change detected",
        "PASS" if ok else "FAIL")

def T08():
    ok = len(PREREG) == 6 and params_hash(PREREG) == PREREG_HASH and \
         params_hash(dict(PREREG, acceptance="gap < 0.10")) != PREREG_HASH
    rec("T08", "Six-element pre-registration frozen; loosening acceptance after the fact detected",
        "PASS" if ok else "FAIL", PREREG_HASH[:12])

def T09():
    ledger = [("G1", "pass"), ("G2", "finding"), ("G3", "pass")]
    def honest(l): return any(r == "finding" for _, r in l) == any(r == "finding" for _, r in ledger)
    ok = honest(ledger) and not honest([x for x in ledger if x[1] != "finding"])
    rec("T09", "Negative findings kept at equal weight; dropping them is refused", "PASS" if ok else "FAIL")

def T10():
    band = (0.50, 1.00)
    def held(self_report, gaia_reading):
        return tier(min(self_report, gaia_reading)) if not (band[0] <= gaia_reading <= band[1]) else tier(self_report)
    ok = held(0.80, 0.80) == "SOUND" and held(0.80, 0.40) == "BELOW"
    rec("T10", "Bottom-up report vs top-down GAIA band: out-of-band reading overrides self-report",
        "PASS" if ok else "FAIL")

def T11():
    def admit(entry): return bool(entry.get("sroc_contract")) and bool(entry.get("contact_of_record"))
    ok = admit({"sroc_contract": "SROC-G1", "contact_of_record": "+1-xxx"}) and not admit({"sroc_contract": None})
    rec("T11", "SROC binding: twin entries without a contract and Contact of Record rejected", "PASS" if ok else "FAIL")

def T12():
    def admit(entry): return entry.get("level") == "user-group" and entry.get("n", 0) >= 50
    ok = admit({"level": "user-group", "n": 400}) and not admit({"level": "individual", "n": 1}) \
         and not admit({"level": "user-group", "n": 3})
    rec("T12", "Not surveillance: twin holds User-GROUP aggregates only (n >= 50); individual records refused",
        "PASS" if ok else "FAIL")

def T13():
    persistence = [0.60, 0.60, 0.60, 0.60]
    measured =    [0.60, 0.64, 0.68, 0.71]
    twin =        [0.60, 0.65, 0.67, 0.72]
    mae = lambda a, b: sum(abs(x - y) for x, y in zip(a, b)) / len(a)
    ok = mae(twin, measured) < mae(persistence, measured)
    rec("T13", "Null test: twin must beat persistence (carry-forward) or it adds nothing", "PASS" if ok else "FAIL",
        f"twin {mae(twin, measured):.3f} vs null {mae(persistence, measured):.3f}")

def T14():
    def grade(cert, derived, empirical): return "BEST" if (cert == "SOUND" and derived and empirical) else cert
    ok = grade("SOUND", False, True) == "SOUND" and grade("SOUND", True, True) == "BEST"
    rec("T14", "Nothing DERIVED => none BEST", "PASS" if ok else "FAIL")

# ================= UNIT CHECKS =================
def U1():
    ok = norm("healthy", 85) == 1.0 and norm("safe", 0.0) == 1.0 and norm("happy", 5.0) == 0.5
    rec("U1", "unit: goalpost normalization", "PASS" if ok else "FAIL")

def SKIPS():
    rec("S1", "Real nation data (life expectancy, violent deaths, Cantril ladder) for all nations", "SKIP", "needs data")
    rec("S2", "Real SOMT twin running on GAIA User-GROUPs", "SKIP", "not built")
    rec("S3", "Measured cross-nation coupling matrix (trade, migration, conflict)", "SKIP", "OPEN")
    rec("S4", "Independent >=5-node MIEVM round", "SKIP", "not run")
    rec("S5", "Dr. Pellis review of Sec. 4 identifiability framing", "SKIP", "HOLD")

if __name__ == "__main__":
    for f in (T01, T02, T03, T03b, T04, T05, T06, T07, T08, T09, T10, T11, T12, T13, T14, U1, SKIPS): f()
    print(f"ERES-N2N-HHS-2026-001 v0.1 testkit  seed={SEED}  python={sys.version.split()[0]}")
    print(f"pre-registration sha256 = {PREREG_HASH}")
    for t, n, s, note in RESULTS:
        print(f"[{s:4s}] {t:4s} {n}" + (f"  ({note})" if note else ""))
    T = [r for r in RESULTS if r[0].startswith("T")]; U = [r for r in RESULTS if r[0].startswith("U")]
    F = sum(r[2] == "FAIL" for r in RESULTS); S = sum(r[2] == "SKIP" for r in RESULTS)
    print(f"\nDESIGN {sum(r[2]=='PASS' for r in T)}/{len(T)} PASS · UNIT {sum(r[2]=='PASS' for r in U)}/{len(U)} PASS · {F} FAIL · {S} SKIP")
    sys.exit(1 if F else 0)
