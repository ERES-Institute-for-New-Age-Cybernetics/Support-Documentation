# License — ERES-JPN-FUSION-ADOPTION-2026-001 v0.2

Copyright © 2026 Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221).

1. **Text** (paper, Synopsis, README, Figure): CCAL v2.1 (CARE Commons Attribution License) and Creative Commons Attribution 4.0 International (CC BY 4.0) — https://creativecommons.org/licenses/by/4.0/legalcode . CCAL v2.1 adds no restriction beyond CC BY 4.0.
2. **Code** (`eres_jpn_fusion_testkit.py`): CC BY 4.0. A conventional software license may be requested from the author.
3. **Patents and trademarks are not licensed** (CC BY 4.0 §2(b)(2)). The author holds and files no patents on this content; it is openly published and may serve as prior art. No right is claimed in or granted to any third party's name or mark.
4. **Moral rights:** waived or not asserted only to the extent necessary and possible under applicable law. Where not waivable (e.g., author's personal rights under Japanese copyright law), the author's attribution and integrity rights are retained.
5. **Attribution form:** use the Suggested Citation in the paper (§12), with a link to the license and an indication of any changes.
6. **Governing text:** the official Creative Commons legal code governs the license. The English paper is the master and governs meaning over any translated edition.
7. **No warranty.** Not legal, investment or medical advice.
8. **Non-endorsement:** licensing this work implies no endorsement by any person or institution named or cited in it.
