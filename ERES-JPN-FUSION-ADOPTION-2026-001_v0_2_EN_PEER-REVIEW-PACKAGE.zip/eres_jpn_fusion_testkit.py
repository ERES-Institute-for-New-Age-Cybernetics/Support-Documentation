#!/usr/bin/env python3
"""
ERES-JPN-FUSION-ADOPTION-2026-001 v0.2 — Test Kit (English edition)
"Semiconduction to Fusion" — companion test suite.

Author : Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221
License: CC BY 4.0 (text and code). No patent or trademark rights licensed
         (CC BY 4.0 s.2(b)(2)). See paper s.10.
Python : 3.8+, standard library only. Deterministic. Exit code = verdict
         (0 = no FAIL, 1 = any FAIL).

Usage:   python3 eres_jpn_fusion_testkit.py [--dir PATH] [--withheld FILE] [--json]
         --dir       folder holding the paper + MANIFEST.json
                     (default: this file's folder). Paper REQUIRED for T9-T11.
         --withheld  author-held, out-of-band list of withheld names (one per
                     line). NOT shipped. Without it T9 reports SKIP.
         --json      also print a machine-readable result record

Scope of evidence: tests T1-T8 and T12 check ALGEBRA and BOOKKEEPING of the
model (structural). T9-T11 and T13 are document/package GUARDS. S1-S4 are
the EMPIRICAL predictions P1-P4 and report SKIP until real data are supplied.
A structural PASS is not empirical evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
import unicodedata
from typing import Dict, List, Optional, Sequence, Tuple

INSTRUMENT = "ERES-JPN-FUSION-ADOPTION-2026-001"
VERSION = "v0.2"
EN_FILE = INSTRUMENT + "_v0_2_EN.md"
TOL = 1e-9

# ---------------------------------------------------------------- core model
def hazard(p: float) -> float:
    """Proposition 1: p = exp(-H)  ->  H = -ln p   (p in (0,1])."""
    if not (0.0 < p <= 1.0):
        raise ValueError("probability must be in (0, 1]")
    return -math.log(p)


def survival(h: float) -> float:
    if h < 0:
        raise ValueError("hazard must be >= 0")
    return math.exp(-h)


def poisson_yield(area_cm2: float, d0_per_cm2: float) -> float:
    """S-model: Y = exp(-A * D0)."""
    return math.exp(-area_cm2 * d0_per_cm2)


# Reference phase-transition rates (BIO/Informa/QLS 2021, 2011-2020 aggregate).
PHARMA_REF = (0.520, 0.289, 0.578, 0.906)

# ---- Domain registry (s.4.7). The ERES 72-Industry taxonomy defines the menu;
# a domain may be FUSED only once a reference hazard is DECLARED for it.
# v0.2 declares the two exemplars; 70 remain undeclared (not fusable yet).
DOMAIN_COUNT = 72
REGISTRY: Dict[str, Dict[str, object]] = {
    "silicon": {"label": "semiconductor (exemplar)", "h_ref": hazard(0.80),
                "basis": "declared baseline: 80% die yield [CONSTRUCTED]"},
    "carbon": {"label": "pharmaceutical (exemplar)", "h_ref": sum(hazard(p) for p in PHARMA_REF),
               "basis": "industry LOA 2011-2020 [R6]"},
}

BANDS: Tuple[Tuple[str, float], ...] = (  # (grade, upper bound on h) CONSTRUCTED
    ("BEST", 0.50), ("SOUND", 0.80), ("GOOD", 1.00))
ORDER = {"BELOW": 0, "GOOD": 1, "SOUND": 2, "BEST": 3}
INV = {v: k for k, v in ORDER.items()}


def normalized(h_obs: float, h_ref: float) -> float:
    if h_ref <= 0:
        raise ValueError("reference hazard must be > 0")
    return h_obs / h_ref


def grade(h_norm: float, empirical: bool = False) -> str:
    """Grade band; epistemic cap: illustrative inputs can never reach BEST."""
    for g, ub in BANDS:
        if h_norm <= ub:
            if g == "BEST" and not empirical:
                return "SOUND"
            return g
    return "BELOW"


def fuse_min(*grades: str) -> str:
    """F2 Non-Collapse: fused grade = meet (minimum) over the declared scope."""
    if not grades:
        raise ValueError("empty scope")
    return INV[min(ORDER[g] for g in grades)]


def fuse_scope(grades: Dict[str, str], scope: Sequence[str]) -> str:
    """Scoped fusion (s.4.7): Phi_D = meet over a DECLARED decision scope D.
    Every domain in D must have a declared reference hazard."""
    if not scope:
        raise ValueError("scope must be declared and non-empty")
    undeclared = [d for d in scope if d not in REGISTRY]
    if undeclared:
        raise ValueError(f"undeclared reference hazard: {undeclared}")
    return fuse_min(*(grades[d] for d in scope))


def fuse_hier(clusters: Dict[str, Sequence[str]]) -> Dict[str, str]:
    """Hierarchical option: meet within each cluster, reported as a vector."""
    return {name: fuse_min(*gs) for name, gs in clusters.items()}


def fuse_mean_NULL(*grades: str) -> str:
    """Rejected null 1: average of ordinal grades (round half up)."""
    return INV[math.floor(sum(ORDER[g] for g in grades) / len(grades) + 0.5)]


def fuse_hazard_mean_NULL(*h_norms: float) -> str:
    """Rejected null 2 (credible): average the normalized hazards, then grade."""
    return grade(sum(h_norms) / len(h_norms), empirical=True)


def rate(cbgmodd: float, bera: float, favors: float) -> float:
    """F3: RATE = CBGMODD x BERA + FAVORS  (inputs in [0,1]; FAVORS host-declared)."""
    return cbgmodd * bera + favors


def rate_NULL(cbgmodd: float, bera: float, favors: float) -> float:
    """Rejected null: floor enters multiplicatively (can be zeroed)."""
    return cbgmodd * bera * favors


def apply_shock(merit: float, floor_n: float, h: float) -> Tuple[float, float]:
    """Humane invariant: hazard decrements merit M only, never floor N."""
    return merit * survival(h), floor_n


def p_all_clear(p_below: float, n: int) -> float:
    """Probability that n independent domains all clear the GOOD floor."""
    return (1.0 - p_below) ** n


LADDER = ("A0", "A1", "A2", "A3", "A4", "A5")


def ladder_valid(evidence: Dict[str, bool]) -> Tuple[bool, str]:
    """Highest claimable stage = longest evidenced prefix; gaps invalidate."""
    reached = "NONE"
    gap = False
    for st in LADDER:
        if evidence.get(st, False):
            if gap:
                return False, st
            reached = st
        else:
            gap = True
    return True, reached


CURRENT_EVIDENCE = {"A0": True}  # contact made; proposal transmitted

LOCKED_TERMS = ("GAIA", "RATE", "CBGMODD", "BERA", "FAVORS", "UBIMIA",
                "BEST", "SOUND", "GOOD", "BELOW", "F1", "F2", "F3",
                "A0", "A5", "CCAL v2.1", "CC BY 4.0", INSTRUMENT,
                "0000-0001-9946-3221", "72")

NON_ENDORSE = ("NON-ENDORSEMENT", "Nothing here is offered", "no endorsement")


# ---------------------------------------------------------------- harness
class Result:
    def __init__(self) -> None:
        self.rows: List[Tuple[str, str, str, str]] = []

    def add(self, tid: str, kind: str, status: str, note: str) -> None:
        self.rows.append((tid, kind, status, note))
        print(f"  [{status:4}] {tid:3} {kind:10} {note}")


def check(cond: bool) -> str:
    return "PASS" if cond else "FAIL"


def body(text: str) -> str:
    """Strip YAML frontmatter so guards check the body, not metadata (T10 fix)."""
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            return parts[2]
    return text


def norm(s: str) -> str:
    return unicodedata.normalize("NFKC", s).casefold()


def t1(r: Result) -> None:
    ps = [0.9, 0.5, 0.25]
    ok = abs(hazard(math.prod(ps)) - sum(hazard(p) for p in ps)) < TOL
    ok &= abs(survival(hazard(0.37)) - 0.37) < TOL
    try:
        hazard(0.0)
        ok = False
    except ValueError:
        pass
    r.add("T1", "structural", check(ok), "survival identity + additive composition (Prop.1); p=0 rejected")


def t2(r: Result) -> Dict[str, float]:
    y = poisson_yield(1.0, 0.10)
    h_s = hazard(y)
    ok = abs(h_s - 0.10) < TOL
    r.add("T2", "structural", check(ok), f"S-model Poisson yield Y={y:.4f} -> H_S={h_s:.4f} (=A*D0)")
    return {"H_S": h_s}


def t3(r: Result) -> Dict[str, float]:
    loa = math.prod(PHARMA_REF)
    h_p = sum(hazard(p) for p in PHARMA_REF)
    ok = abs(loa - 0.0787) < 0.001 and abs(h_p - hazard(loa)) < 1e-12
    r.add("T3", "structural", check(ok), f"P-model phase product LOA={loa:.4f} (~7.9%) -> H_P={h_p:.3f}")
    return {"H_P": h_p}


def t4(r: Result) -> None:
    grid = [i / 100 for i in range(0, 201)]
    gs = [ORDER[grade(h, empirical=True)] for h in grid]
    monotone = all(a >= b for a, b in zip(gs, gs[1:]))
    edges = (grade(0.5, True) == "BEST" and grade(0.8, True) == "SOUND"
             and grade(1.0, True) == "GOOD" and grade(1.0001, True) == "BELOW")
    r.add("T4", "structural", check(monotone and edges), "grade bands monotone; edges 0.5/0.8/1.0/1.0001 exact")


def t5(r: Result) -> None:
    h_s, h_p = 0.20, 1.60                       # strong silicon, failing carbon
    g_s, g_p = grade(h_s, True), grade(h_p, True)
    fused = fuse_min(g_s, g_p)
    null1 = fuse_mean_NULL(g_s, g_p)            # ordinal mean
    null2 = fuse_hazard_mean_NULL(h_s, h_p)     # hazard mean (credible null)
    ok = fused == "BELOW" and ORDER[null1] >= ORDER["GOOD"] and ORDER[null2] >= ORDER["GOOD"]
    ok &= fuse_mean_NULL("SOUND", "BEST") == "BEST"   # round-half-up fixed (v0.1 banker's bug)
    r.add("T5", "structural", check(ok),
          f"F2 non-collapse: min -> {fused}; ordinal-mean null -> {null1}, hazard-mean null -> {null2} (both mask; rejected)")


def t6(r: Result) -> None:
    ok = all(rate(c, b, f) >= f - TOL for c in (0.0, 0.3, 1.0) for b in (0.0, 0.5, 1.0) for f in (0.1, 0.4))
    greenwash_null = rate_NULL(1.0, 1.0, 0.0)   # perfect institution, zero floor
    ok &= greenwash_null == 0.0 and rate(1.0, 1.0, 0.0) == 1.0  # null lets floor vanish into product
    ok &= rate_NULL(0.0, 0.0, 0.2) == 0.0 and rate(0.0, 0.0, 0.2) == 0.2
    m, n = apply_shock(1.0, 1.0, 2.54)
    ok &= n == 1.0 and m < 1.0
    r.add("T6", "structural", check(ok),
          "F3 floor: RATE>=FAVORS by construction (definitional, not evidence); multiplicative null zeroes floor; N intact")


def t7(r: Result) -> None:
    ok = grade(0.2, empirical=False) != "BEST" and grade(0.2, empirical=True) == "BEST"
    r.add("T7", "structural", check(ok), "epistemic cap: illustrative inputs cannot reach BEST")


def t8(r: Result) -> None:
    v_cur, st = ladder_valid(CURRENT_EVIDENCE)
    v_skip, _ = ladder_valid({"A0": True, "A2": True})
    v_adopt, _ = ladder_valid({"A0": True, "A5": True})
    ok = v_cur and st == "A0" and not v_skip and not v_adopt
    r.add("T8", "structural", check(ok), f"adoption ladder: current={st}; skipping A1 / claiming A5 rejected")


def t12(r: Result) -> None:
    pc = p_all_clear(0.20, DOMAIN_COUNT)
    collapse = pc < 1e-6                                   # global min ~always BELOW
    grades = {"silicon": "SOUND", "carbon": "GOOD"}
    scoped = fuse_scope(grades, ["silicon", "carbon"]) == "GOOD"
    try:
        fuse_scope(grades, ["silicon", "agriculture"])     # undeclared reference hazard
        refuse = False
    except ValueError:
        refuse = True
    try:
        fuse_scope(grades, [])
        refuse = False
    except ValueError:
        pass
    hier = fuse_hier({"build": ["SOUND", "BEST"], "life": ["GOOD", "SOUND"]}) == {"build": "SOUND", "life": "GOOD"}
    ok = collapse and scoped and refuse and hier and len(REGISTRY) == 2
    r.add("T12", "structural", check(ok),
          f"72-domain scope: P(all 72 clear | p_below=0.2)={pc:.1e} -> global min collapses; "
          f"scoped Φ_D informative; undeclared/empty scope refused; {len(REGISTRY)}/{DOMAIN_COUNT} declared")


def _read(path: str) -> Optional[str]:
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return None


def t9(r: Result, en: Optional[str], withheld_path: Optional[str]) -> None:
    if not withheld_path:
        r.add("T9", "guard", "SKIP", "no-names guard is author-run with an out-of-band list (--withheld); none shipped")
        return
    if en is None:
        r.add("T9", "guard", "SKIP", "paper not found (use --dir)")
        return
    names = [norm(l.strip()) for l in open(withheld_path, encoding="utf-8") if l.strip()]
    text = norm(en)
    tokens = set(re.findall(r"\w+", text))
    hits = sum(1 for n in names if n in tokens or n in text)
    r.add("T9", "guard", check(hits == 0), f"no-names guard (Unicode, NFKC, out-of-band list of {len(names)}): {hits} hit(s)")


def t10(r: Result, en: Optional[str]) -> None:
    if en is None:
        r.add("T10", "guard", "SKIP", "paper not found (use --dir)")
        return
    missing = [t for t in LOCKED_TERMS if t not in body(en)]
    r.add("T10", "guard", check(not missing), f"term lock, body only ({len(LOCKED_TERMS)} terms); missing={missing}")


def t11(r: Result, en: Optional[str]) -> None:
    if en is None:
        r.add("T11", "guard", "SKIP", "paper not found (use --dir)")
        return
    ok = all(k in body(en) for k in NON_ENDORSE)
    r.add("T11", "guard", check(ok), "non-endorsement clause present in the paper body")


def t13(r: Result, d: str) -> None:
    mpath = os.path.join(d, "MANIFEST.json")
    if not os.path.exists(mpath):
        r.add("T13", "guard", "SKIP", "MANIFEST.json not found")
        return
    m = json.load(open(mpath, encoding="utf-8"))
    bad = []
    for f, h in m.get("files", {}).items():
        p = os.path.join(d, f)
        if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
            bad.append(f)
    r.add("T13", "guard", check(not bad), f"package integrity vs MANIFEST ({len(m.get('files', {}))} files); mismatches={bad}")


def skips(r: Result) -> None:
    r.add("S1", "empirical", "SKIP", "P1 min-fusion vs mean on real fab + pipeline outcomes")
    r.add("S2", "empirical", "SKIP", "P2 cross-domain comparability of h (needs a 3rd/4th declared domain)")
    r.add("S3", "empirical", "SKIP", "P3 floor supremacy vs retention on a real GAIA ledger")
    r.add("S4", "empirical", "SKIP", "P4 scoped-min vs global-min vs hierarchical-min on outcomes")


def self_hash() -> str:
    with open(os.path.abspath(__file__), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=INSTRUMENT + " test kit")
    ap.add_argument("--dir", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--withheld", default=None)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)

    print(f"{INSTRUMENT} {VERSION} — Test Kit (English edition)")
    print(f"self SHA-256: {self_hash()}")
    en = _read(os.path.join(a.dir, EN_FILE))
    r = Result()
    t1(r); s = t2(r); p = t3(r); t4(r); t5(r); t6(r); t7(r); t8(r); t12(r)
    t9(r, en, a.withheld); t10(r, en); t11(r, en); t13(r, a.dir); skips(r)

    h_s = normalized(s["H_S"], float(REGISTRY["silicon"]["h_ref"]))
    h_p = normalized(p["H_P"], float(REGISTRY["carbon"]["h_ref"]))
    g_s, g_p = grade(h_s), grade(h_p)
    print(f"\n  Worked example (scope D = {{silicon, carbon}}): h_S={h_s:.3f} -> {g_s}; "
          f"h_P={h_p:.3f} -> {g_p}; Φ_D = {fuse_scope({'silicon': g_s, 'carbon': g_p}, ['silicon', 'carbon'])} "
          f"(illustrative, capped below BEST)")

    def cnt(kind: str, st: str) -> int:
        return sum(1 for _, k, s_, _ in r.rows if (kind == "*" or k == kind) and s_ == st)

    n_fail = cnt("*", "FAIL")
    verdict = "PASS" if n_fail == 0 else "FAIL"
    print(f"\n  STRUCTURAL: {cnt('structural', 'PASS')} PASS / {cnt('structural', 'FAIL')} FAIL"
          f"   GUARDS: {cnt('guard', 'PASS')} PASS / {cnt('guard', 'FAIL')} FAIL / {cnt('guard', 'SKIP')} SKIP"
          f"   EMPIRICAL: 0 of {cnt('empirical', 'SKIP')} tested")
    print(f"  DOMAINS: {len(REGISTRY)} of {DOMAIN_COUNT} declared and exercised; 0 of {DOMAIN_COUNT} empirically calibrated")
    print(f"  VERDICT: {verdict} (structural + guards). A structural PASS is not empirical evidence.")
    if a.json:
        print(json.dumps({"instrument": INSTRUMENT, "version": VERSION, "verdict": verdict,
                          "domains_declared": len(REGISTRY), "domain_count": DOMAIN_COUNT,
                          "rows": [{"id": i, "kind": k, "status": st, "note": nt} for i, k, st, nt in r.rows]},
                         ensure_ascii=False, indent=2))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
