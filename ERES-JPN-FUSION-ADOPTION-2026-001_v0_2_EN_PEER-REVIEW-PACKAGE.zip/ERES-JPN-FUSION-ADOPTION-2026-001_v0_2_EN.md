---
instrument_id: ERES-JPN-FUSION-ADOPTION-2026-001
version: v0.2 (PEER-REVIEW DRAFT — pre-MIEVM, pre-ratification; supersedes v0.1)
date: 2026-10-30
author: Joseph Allen Sprute (ERES Maestro), Founder & Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas, USA
orcid: 0000-0001-9946-3221
language: English (master). English-only edition; a Japanese edition appears in the bilingual v0.2 package.
license: Text CCAL v2.1 (CARE Commons Attribution License) / CC BY 4.0 — see §10
---

# Semiconduction to Fusion

## A Nations-Role Adoption Proposal for Japan — Coupling the Semiconductor and Pharmaceutical Industry Models into a GAIA Fusion Model for Spaceship Economics

**Instrument ID:** ERES-JPN-FUSION-ADOPTION-2026-001 · **Version:** v0.2 Peer-Review Draft · **Date:** 30 October 2026
**Author:** Joseph Allen Sprute (ORCID 0000-0001-9946-3221), ERES Institute for New Age Cybernetics (non-profit, est. 4 Feb 2012), Bella Vista, Arkansas, USA

---

### STATUS AND NON-ENDORSEMENT (read first)

1. This is a **proposal for adoption**, not a record of adoption. Its current stage on the Adoption Ladder (§7) is **A0 — Introduction**.
2. No government, university, company, or person in Japan or elsewhere has reviewed, endorsed, or adopted this instrument. Nothing here is offered **on behalf of** Japan; it is offered **to** Japan-side reviewers, from a U.S. non-profit.
3. The Fellow named in the Dedication is acknowledged for publicly expressed ideas that informed this work. Naming confers no endorsement, affiliation, or role; any role is conditional on that person's written consent (Stage A1).
4. The pharmaceutical reference model in §3.2 was posed to ERES by a private fiduciary sponsor. The sponsor and any specific company are deliberately **not named**; the model is treated in industry-generic form only. The Test Kit verifies this (test T9).
5. **Evidence scope.** The Test Kit checks algebra, bookkeeping, and document integrity. **0 of 4 empirical predictions have been tested; 2 of 72 industry domains are declared and exercised; 0 of 72 are empirically calibrated.** A structural PASS is not empirical evidence.
6. Every claim carries a Doctrine-of-Verifiable-Claims tag: **[DERIVED]** (follows mathematically or from cited sources), **[CONSTRUCTED]** (a declared design choice or parameter), **[CONJECTURE]** (proposed, untested).

### REVISION NOTE — v0.2 (rectifications after independent review of v0.1)

| # | v0.1 finding | v0.2 rectification | § / test |
|---|---|---|---|
| 1 | "Shared spine" oversold an elementary identity | Prop. 1 restated as a commensurability device, not a discovery | §2 |
| 2 | Min over 72 domains collapses to worst-of-72 | **Scoped fusion** Φ_D over a declared decision scope; hierarchical option; vector reporting | §4.3, §4.7, T12 |
| 3 | Code exercised 2 domains while scope claimed 72 | Domain registry (2/72 declared), variadic fusion, undeclared domains refused | T12 |
| 4 | Averaging ordinal grades was a strawman null | Credible null added: averaging normalized hazards (also masks; rejected) | T5 |
| 5 | Banker's-rounding defect in the null model | Round-half-up | T5 |
| 6 | Dead code in floor test | Greenwash null now asserted | T6 |
| 7 | Published name-hashes were dictionary-attackable | Hashes removed; author-run guard with an out-of-band list; Unicode/NFKC matching | T9 |
| 8 | Term lock satisfiable by frontmatter | Guards read the body only | T10, T11 |
| 9 | No integrity chain | MANIFEST verified in-kit | T13 |
| 10 | FAVORS presented as fixed | Floor is host-declared; invariant stated | §4.3 F3 |
| 11 | GAIA could read as an authority over hosts | Host may substitute its own rating authority; GAIA as method | §5.1, §7 |
| 12 | Universality asserted, not tested | Tagged CONSTRUCTED; second, dissimilar instantiation specified | §7.2 |
| 13 | Dedication preceded consent | Dedication marked pending A1 consent; removable on request | Dedication |

---

### Abstract

Japan is rebuilding leading-edge semiconductor manufacturing through a public–private consortium model, while the global pharmaceutical industry runs on a phase-gated, attrition-priced development pipeline. ERES observes that the two industries—silicon and carbon—can be read on one common measure: the survival identity R = exp(−H), where H is cumulative hazard. The identity itself is elementary (any probability can be so written); its value here is commensurability, not discovery. Semiconductor yield and clinical-pipeline probability of success are two readouts on that measure, and are two exemplars of the 72 industry domains in the ERES taxonomy. This paper (i) states the correspondence formally, (ii) defines a **Fusion Model** that couples industry models without letting any one mask another (three conditions: common measure, non-collapse over a declared scope, floor supremacy), and shows why fusion must be scoped rather than taken over all 72 domains, (iii) places the Fusion Model inside ERES GAIA (Global Actuary Investor Authority) as the rating basis for long-horizon "Spaceship Economics," and (iv) proposes a consent-gated, six-stage **Nations-Role Adoption Ladder** through which a host nation—here, Japan—may review, reproduce, and, if warranted, adopt the instrument. A complete, deterministic, standard-library Python Test Kit accompanies the paper; it confirms or falsifies each structural rule and reports all four empirical predictions as SKIP until real data are supplied.

**Keywords:** Fusion Model; scoped fusion; 72-industry taxonomy; semiconductor yield; pharmaceutical pipeline attrition; survival analysis; cumulative hazard; GAIA; Spaceship Economics; Nations Role; adoption ladder; verifiable claims; Japan–United States collaboration; open licensing

---

### 1. Introduction — Why a Nations Role, why Japan, why now

**1.1 The Nations Role.** ERES instruments are written to scale "from any nation." A *Nations Role* is the template by which one nation's institutions may review and adopt an ERES instrument on their own terms, under their own law, without ceding authority to ERES. It is a door, not a treaty. [CONSTRUCTED]

**1.2 Why Japan.** Japan has re-entered leading-edge logic manufacturing through a government-backed consortium: the Rapidus pilot line at Chitose, Hokkaido has moved from construction to operation, with mass production of 2 nm-class logic targeted for 2027 and customer test chips planned for late 2026 [R3, R4]. This is the clearest live example of a nation treating semiconductor capability as shared, long-horizon infrastructure—the same posture ERES calls Spaceship Economics. [DERIVED from cited sources]

**1.3 Why a guide.** A Japan-side innovation leader recently retold a 14th-century parable from *Tsurezuregusa*: a disciplined monk, focused on his purpose, stopped at the shrine at the foot of the mountain and never reached the main shrine above; the lesson drawn was that research needs guides who can see the whole path to social implementation [D1]. ERES adopts that lesson as a design constraint: an adoption instrument must show the whole path (A0→A5), not only its first shrine.

**1.4 Contribution.** (a) A formal semiconductor ↔ pharmaceutical correspondence on the survival identity; (b) the Fusion Model and its three conditions; (c) its placement in GAIA; (d) the Adoption Ladder; (e) an Articulated Symbology; (f) a Test Kit; (g) a licensing and IP regime suited to a patent-literate host.

---

### 2. The shared spine: the survival identity

For any process exposed to failure over a span of exposure τ with hazard rate λ(τ) ≥ 0:

  H = ∫ λ(τ) dτ  (cumulative hazard)  R = exp(−H)  (survival / reliability / yield)

**Proposition 1 (Common Measure).** Any success probability p ∈ (0, 1] can be written p = exp(−H) with H = −ln p ≥ 0, and independent sequential stages compose additively in H: if p = ∏ pᵢ then H = Σ Hᵢ. [DERIVED — elementary; logarithm of a product]

**Remark (what Proposition 1 is and is not).** Proposition 1 is an elementary logarithmic identity, not a finding. Its use is to put unlike industries in one unit (nats of hazard) so that a stated baseline can be compared across them. All substantive content of this paper lies in the constructed rules of §4 (scope, minimum, floor, bands) and in the falsifiable predictions of §8. [DERIVED for the identity; CONSTRUCTED for its use]

This is the bridge. ERES's prior Track-B work recorded the reliability functional R = exp(−H) of semiconductor collapse analysis as term-for-term the actuarial survival identity [R1]; this paper extends the same identity to the pharmaceutical pipeline.

---

### 3. The two reference models

**3.1 Semiconductor model (S-model — silicon).** Under the Poisson defect model, die yield is Y = exp(−A·D₀), where A is die area and D₀ is defect density [R5]. So H_S = A·D₀. Node progression is gated: a process design kit (PDK) is released, test chips run, yield is ramped, and only then is volume production declared. In-field reliability obeys the same identity over operating time. [DERIVED]

**3.2 Pharmaceutical model (P-model — carbon).** A development program passes Phase I → Phase II → Phase III → regulatory filing → approval. Industry-wide reference transition rates for 2011–2020 were approximately 52.0%, 28.9%, 57.8%, and 90.6%, giving a likelihood of approval from Phase I of about 7.9% [R6]. By Proposition 1, H_P = Σ −ln pᵢ ≈ 2.54. The model was posed to ERES by a private fiduciary sponsor as the template for capital that funds long, uncertain, phase-gated work. [DERIVED for the arithmetic; reference rates as cited]

**3.3 Side by side.**

| | S-model (silicon) | P-model (carbon) |
|---|---|---|
| Unit at risk | die / wafer / device | candidate program |
| Gate structure | PDK → test chip → yield ramp → volume | Ph I → Ph II → Ph III → filing → approval |
| Hazard source | defects × area; wear-out | biological failure; safety; efficacy |
| Readout | yield Y, reliability R | likelihood of approval |
| Common form | Y = exp(−H_S) | LOA = exp(−H_P) |
| Capital posture | consortium, multi-year, national | portfolio, attrition-priced |

---

### 4. The Fusion Model

**4.1 Normalized hazard.** Each domain d declares a reference hazard H_ref,d (the industry baseline it must at least match). The normalized hazard is h_d = H_d / H_ref,d. h < 1 means better than baseline; h = 1 at baseline; h > 1 worse. [CONSTRUCTED — the baseline is a declared parameter]

**4.2 Grade bands** (CONSTRUCTED thresholds, tunable, published with every use):

| Band | Condition on h | Meaning |
|---|---|---|
| BEST-eligible | h ≤ 0.50 | well inside baseline (BEST also requires empirical derivation, §4.4) |
| SOUND | 0.50 < h ≤ 0.80 | operating target |
| GOOD | 0.80 < h ≤ 1.00 | admission floor — meets baseline |
| BELOW | h > 1.00 | fails the floor |

**4.3 Definition (Fusion).** A coupling of the S-model and P-model is a *Fusion* iff all three hold:

- **F1 Common Measure.** Both domains are read on H ≥ 0 with R = exp(−H). (Proposition 1.)
- **F2 Non-Collapse.** Over a **declared decision scope** D (the domains relevant to the decision at hand, each with a declared reference hazard), the fused grade is the **minimum** of the domain grades, Φ_D = ⊓_{d∈D} g_d, and every domain grade in D remains separately reported. No averaging—of grades or of hazards: a strong silicon readout may never mask a failing carbon readout, or the reverse. For the exemplar, D = {silicon, carbon} and Φ_D = min(g_S, g_P).
- **F3 Floor Supremacy.** The fused rating sits on an additive floor that no institutional score can remove: RATE = CBGMODD × BERA + FAVORS, so RATE ≥ FAVORS always; and the human floor N is never inside the hazard spectrum—only merit M is graded. **The floor is host-declared:** a universal basic income (the ERES UBIMIA conception) is one realization; a host may declare contributory insurance, means-tested transfer, a sovereign dividend, or another floor. Only the invariant is fixed: the floor enters additively, RATE ≥ FAVORS, and N is never decremented. (RATE ≥ FAVORS holds by construction; it is a design rule, not evidence.)

[CONSTRUCTED definition; F1 rests on DERIVED Proposition 1]

**4.4 Epistemic cap.** No fused readout may be graded BEST while any input remains illustrative rather than measured ("nothing derived ⇒ none BEST"). [CONSTRUCTED]

**4.5 The epiphyte principle.** The Fellow honored here wrote of epiphytic plants on ancient Yakusugi cedars—growth upon a host without taking its nutrients—and of the cedars in turn being sustained by rain, sun and soil [D1]. ERES reads this as the design rule of the Fusion: each industry model rests on the other's measure without extracting from it (F2), and both rest on a floor neither owns (F3). In ERES vocabulary this is "tune, not mine" and "no unearned resonance." [CONSTRUCTED — interpretive]

**4.7 Domain scope and the collapse problem.** Silicon and carbon are two exemplars of the **72 industry domains** of the ERES 72-Industry taxonomy [R7]. Taking the minimum over all 72 would be uninformative: if each domain independently had even a 20% chance of grading BELOW, the chance that all 72 clear the floor is 0.8⁷² ≈ 1.1 × 10⁻⁷, so a global Φ would read BELOW almost always. The Fusion Model therefore never fuses globally by default. Three admissible forms, in order of preference:

1. **Scoped fusion (default).** Φ_D over a declared scope D ⊆ 72—e.g., a fab decision scopes to silicon, materials, power, water; a therapeutic decision to carbon, regulatory, supply chain. The 72-domain registry is a menu, not a mandatory vector.
2. **Hierarchical fusion.** Minimum within declared clusters, reported as a vector of cluster grades.
3. **Vector reporting.** All in-scope grades reported, with Φ_D as one summary among them.

A domain may enter any scope only after its reference hazard is declared and published. In v0.2, **2 of 72** are declared (silicon, carbon); the remaining 70 are listed but not fusable. Where domains share systemic hazard, Proposition 1's independence assumption fails and joint modeling is required (§9). [CONSTRUCTED; collapse arithmetic DERIVED]

**4.6 Why "Semiconduction to Fusion."** A semiconductor conducts only inside a band; outside it, it either blocks or breaks down. The Fusion Model likewise holds value inside a band (SOUND) bounded by two failures: incoherence (hazard too high) and over-concentration (one domain masking the other). [CONJECTURE — analogy, maps-onto, not identity]

---

### 5. GAIA and Spaceship Economics

**5.1 GAIA** = Global Actuary Investor Authority: the ERES rating method that grades investor-worker standing on the survival identity. The Fusion Model supplies GAIA with a multi-domain basis—here exemplified by silicon (built capability) and carbon (living capability)—read on one measure. **A host may substitute its own rating authority** and use GAIA as method only; nothing in this instrument requires a host to recognize ERES as an authority. [CONSTRUCTED]

**5.2 Spaceship Economics** treats the Earth economy as a closed-loop vessel on a long voyage (the ERES 1000-Year Future Map): what matters is not peak output but sustained survival of the crew and the ship. The Fusion Model is its rating basis because both industries Japan cares about—chips and medicines—are exactly the capabilities a long voyage cannot lose. [CONSTRUCTED]

**5.3 Rating formula.** RATE = CBGMODD × BERA + FAVORS: CBGMODD (institutional conduct) multiplies BERA (the asset/ledger record) conjunctively; FAVORS (the biometric/human floor) adds unconditionally. Grade = min(epistemic axis, health axis). [CONSTRUCTED, per ERES corpus]

---

### 6. Articulated Symbology

| Symbol | Name | Role |
|---|---|---|
| Σᵢ | Silicon domain | S-model readouts |
| C | Carbon domain | P-model readouts |
| H | cumulative hazard | common measure (F1) |
| R = e^(−H) | survival identity | the shared spine |
| h | normalized hazard | H / H_ref |
| ⊓ | meet (minimum) | fusion operator (F2) |
| × | conjunctive | earned / institutional (CBGMODD × BERA) |
| + | additive | given / floor (+ FAVORS) (F3) |
| Φ_D | fusion grade over declared scope D | Φ_D = ⊓_{d∈D} g_d |
| D | decision scope | declared subset of the 72 domains |
| A0…A5 | adoption stages | §7 |

Reading rule: **× is earned, + is given, ⊓ is fair.** [CONSTRUCTED]

---

### 7. The Nations-Role Adoption Ladder

Modeled on both reference industries' gating (pipeline phases; node gates). No stage may be claimed without written evidence of every prior stage. (Test T8.)

| Stage | Name | Gate evidence required | Current |
|---|---|---|---|
| A0 | Introduction | contact made; proposal transmitted | ✔ reached |
| A1 | Consent | named Fellow consents in writing to name and role | — |
| A2 | Reproduction | independent run of the Test Kit reproduces the verdict | — |
| A3 | Peer review | disclosed external review, findings published | — |
| A4 | Institutional review | review by an authorized host-side body | — |
| A5 | Adoption | written adoption instrument from an authorized host party | — |

**Roles.** *Proposer:* ERES Institute (USA). *Host Nation reviewers:* Japan-side institutions, at their discretion. *Fiduciary Sponsor:* unnamed, posed the P-model. *Fellow / Guide:* consent-gated (A1). ERES claims no authority over any host body at any stage. [CONSTRUCTED]

**7.1 Host substitution.** At A4–A5 a host may (a) declare its own reference hazards, (b) re-tune the grade bands, provided monotonicity is preserved (T4), (c) declare its own floor (F3), and (d) substitute its own rating authority. Only F1–F3, the epistemic cap, and the ladder's prefix rule are invariant.

**7.2 Universality — claimed, then to be tested.** The Nations-Role template is designed for every nation; this instrument is its first instantiation, addressed to Japan. By this paper's own epistemic cap, "for every nation" is presently [CONSTRUCTED], supported by one instantiation. The test is a **second, deliberately dissimilar instantiation**: a different host and, more importantly, a different domain pair drawn from the 72, with real reference hazards. That experiment is P2 and P4 in §8. Success: bands re-tune without breaking monotonicity, the floor is re-declared without breaking RATE ≥ FAVORS, host substitution of authority works, and P1 replicates. Failure in any of these is informative and will be reported. Even a success yields n = 2: "tested, preliminary," not "derived." 

---

### 8. Test Kit and falsifiability

The accompanying `eres_jpn_fusion_testkit.py` (Python 3, standard library only, deterministic, exit code = verdict) runs:

| Test | Checks | Type |
|---|---|---|
| T1 | Survival identity and additive composition (Prop. 1) | confirm + falsify |
| T2 | S-model: Poisson yield ↔ hazard | confirm |
| T3 | P-model: phase product ↔ hazard (≈7.9% LOA) | confirm |
| T4 | Grade bands monotone and total | confirm + falsify |
| T5 | F2 Non-collapse: ordinal-mean and hazard-mean nulls both mask; min accepted | falsify nulls |
| T6 | F3 Floor rule (definitional): RATE ≥ FAVORS; multiplicative null zeroes the floor; N never decremented | confirm + falsify |
| T7 | Epistemic cap: illustrative inputs cannot reach BEST | falsify |
| T8 | Adoption Ladder: no stage skipping; current stage = A0 | confirm + falsify |
| T9 | No-names guard: author-run with an out-of-band list (none shipped); SKIP for reviewers | guard |
| T10 | Term lock in the paper body (frontmatter excluded) | guard |
| T11 | Non-endorsement clause present in the paper body | guard |
| T12 | 72-domain scope: global-min collapse shown; scoped fusion; undeclared domains refused | confirm + falsify |
| T13 | Package integrity against MANIFEST | guard |
| S1–S4 | Empirical predictions P1–P4 | SKIP until data |

**Expected reviewer result:** structural 9 PASS / 0 FAIL; guards 3 PASS / 1 SKIP (T9); empirical 0 of 4 tested. The papers and MANIFEST must sit in the same folder (`--dir`).

**Predictions** (falsifiable; [CONJECTURE]):
- **P1.** On paired real data (a fab line's yield history; a therapeutic area's pipeline history), the min-fusion grade Φ predicts long-horizon program survival better than the arithmetic mean of domain grades. *Reject if* Spearman ρ(Φ, outcome) ≤ ρ(mean, outcome) at p < 0.05.
- **P2.** Normalized hazard h is comparable across domains: programs at h ≈ 1 in either domain show similar baseline survival. *Reject if* survival at h ∈ [0.9, 1.1] differs between domains by > 0.15.
- **P3.** Floor supremacy improves workforce retention under shocks. *Reject if* retention under RATE does not exceed retention under CBGMODD × BERA alone.
- **P4.** Scoped fusion predicts decision outcomes better than global or hierarchical fusion. *Reject if* Spearman ρ(Φ_D, outcome) ≤ max(ρ(Φ_global), ρ(Φ_hier)) at p < 0.05 across ≥ 2 domain pairs.

---

### 9. Limitations

- Thresholds in §4.2 are declared policy, not derived. Reference hazards must be declared per use.
- Pharmaceutical reference rates are an aggregate across therapeutic areas; real use must stratify.
- The silicon–carbon "band" reading (§4.6) is analogy only.
- Independence of stages (Prop. 1) is an approximation; correlated stages require joint modeling.
- Only 2 of 72 domains have declared reference hazards; the taxonomy's selection criterion for 72 is itself [CONSTRUCTED] (see [R7]).
- The test of F2 against a hazard-mean null is structural (one constructed case); P1 is the empirical test.
- This is an author-side draft; no external reproduction yet (A2 not reached).

---

### 10. License, Intellectual Property and Attribution

**10.1 Text.** This paper is licensed under **CCAL v2.1 (CARE Commons Attribution License)** and **Creative Commons Attribution 4.0 International (CC BY 4.0)**. Reuse, translation, and adaptation are permitted with attribution (§12). Under the ERES CCAL/CC-BY compatibility instrument, CCAL v2.1 adds no restriction beyond CC BY 4.0.

**10.2 Test Kit code.** Licensed under CC BY 4.0 for corpus consistency. Adopters who require a conventional software license may request an additional grant from the author.

**10.3 Patents and trademarks — not licensed.** CC BY 4.0 expressly does **not** license patent or trademark rights (CC BY 4.0, §2(b)(2)). Accordingly: (a) ERES grants no patent license by this paper and holds no patents on its contents; (b) ERES files no patents on the Fusion Model and publishes it openly; such open publication may serve as prior art; (c) no right is claimed in, or granted to, any third party's name or mark (universities, companies, agencies mentioned in §1.2 or the references).

**10.4 Moral rights.** CC BY 4.0 waives or does not assert moral rights only to the extent necessary and possible under applicable law. Where moral rights cannot be waived (as under Japanese copyright law's author's personal rights), the author's integrity and attribution rights are retained and are honored by the attribution form in §12.

**10.5 Governing text.** For the license, the official Creative Commons legal code governs. This English edition is the master. Where a translated edition (including the Japanese edition in the bilingual package) differs, the English master governs for meaning.

**10.6 Third-party content.** Short paraphrases of public posts (D1) and cited facts (R3–R6) remain under their owners' rights and are used for commentary and citation only.

**10.7 No warranty.** Provided as-is, without warranty; not legal, investment, or medical advice.

---

### 11. Credits and References

**Credits.** All core concepts, instruments, and ERES vocabulary: Joseph Allen Sprute (ERES Maestro). The reliability ↔ survival correspondence: foundational co-discovery recognized with Dr. Stergios Pellis (attribution only; no endorsement of this application). Drafting and Test Kit implementation assisted by Claude (Anthropic), under the author's direction.

**References**
- [R1] Sprute, J.A. ERES-PELLIS-GAIA-BENCHMARKS-2026-001 v0.3 (2026). ERES Institute. CCAL v2.1 / CC BY 4.0.
- [R2] Sprute, J.A. Spaceship Economics: The Lineage, the Floor, and the Band (ERES Book Edition v2.0). Figshare (2026). doi:10.6084/m9.figshare.32975624
- [R3] TechSpot / Design & Reuse, "Japan's Rapidus ramps up 2nm chip plans" (9 Apr 2026).
- [R4] TrendForce, Rapidus 2 nm and 1.4 nm development update (30 Mar 2026), citing Nikkei XTech.
- [R5] Standard Poisson die-yield model, Y = exp(−A·D₀); see any semiconductor manufacturing text.
- [R6] BIO, Informa Pharma Intelligence, QLS. *Clinical Development Success Rates 2011–2020* (2021).
- [R7] CyberRAVE / J.A. Sprute. *ERES 72 Industry by CyberRAVE* — 72 single-token industry sectors, benchmarked against nine external classification systems (incl. Japan JIC, ISIC Rev.4, US SEC SIC). ERES internal taxonomy. [CONSTRUCTED]
- [D1] Public LinkedIn posts of the Fellow named below (5 Oct 2026; 23 Oct 2026), paraphrased.

---

### 12. Suggested Citation

Sprute, J.A. (2026). *Semiconduction to Fusion: A Nations-Role Adoption Proposal for Japan* (ERES-JPN-FUSION-ADOPTION-2026-001, v0.2 Peer-Review Draft). ERES Institute for New Age Cybernetics, Bella Vista, AR, USA. ORCID 0000-0001-9946-3221. CCAL v2.1 / CC BY 4.0.

---

### Dedication (pending the Fellow's consent — Stage A1)

Written in honor of **Yoichi Oshima** (Institute of Science Tokyo), whose path from DRAM design engineer to patent adjudicator to innovation leader joins the silicon world and the institutional world this paper seeks to fuse, and whose public reflections on the epiphyte and the guide shaped §1.3 and §4.5. This dedication implies no endorsement by him or his institution (see Status, item 3). It is offered subject to his consent and will be removed or amended at his request.
