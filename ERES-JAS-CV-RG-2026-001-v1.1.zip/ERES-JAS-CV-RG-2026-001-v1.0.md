# JOSEPH ALLEN SPRUTE

**Founder & Director, ERES Institute for New Age Cybernetics**
Independent Researcher — AI Governance · Verifiable-Claims Methodology · Cybernetic Systems Architecture

Bella Vista, Arkansas, USA · eresmaestro@gmail.com
ORCID: [0000-0001-9946-3221](https://orcid.org/0000-0001-9946-3221) · ResearchGate: Joseph-Sprute · GitHub: ERES-Institute-for-New-Age-Cybernetics
All output openly published (CC BY / CARE Commons Attribution License v2.1)

*Curriculum Vitae — as of August 2026*

---

## RESEARCH STATEMENT

AI governance has produced thousands of pages of principles and very few that can be tested. The core claims of the field — *fair*, *transparent*, *accountable* — are typically asserted rather than demonstrated, and usually cannot be re-derived or contested. My research develops the methods that close that gap: making governance assertions **falsifiable, re-derivable, and provenance-carrying**, so that a claim earns standing only when it can be checked and challenged.

Across fourteen continuous years (ERES Institute, founded 2012) this has produced an openly published, time-stamped corpus spanning verifiable-claims methodology, AI-governance validation, cryptographic attestation, biometric and resonance-measurement instruments, integrated economic frameworks, and long-horizon systems design. The corpus is the evidence for the method — DOI-deposited, ORCID-anchored, and mirrored as code and specifications on a public GitHub organization — not a product to be sold. I am now seeking to carry this work into practice at scale, within an established organization.

---

## DOMAINS OF CONTRIBUTION

- **AI Governance & Validation Methodology** — verifiable-claims doctrine, non-comparative adjudication for high-liability decisions, multi-model ensemble cross-validation, attribution protocols
- **Cryptographic Architecture & Attestation** — formal specification, hardware-rooted attestation, post-quantum migration architecture, resonance-keyed semantic-superposition primitives
- **Biometric & Resonance Instruments** — Bio-Electric Resonance Architecture (BERA) and its four-index measurement substrate (ARI · ERI · RHC · RCI); multi-modal authentication (FAVORS)
- **Enterprise & Governance Reference Architecture** — seven-stakeholder participant model (CBGMODD); multi-stakeholder councils; family-stewardship architecture (DOFA)
- **Integrated Economic Frameworks** — UBIMIA, Patriot Dividend, NBERS (national-accounts alternative), Meritcoin/Gracechain (Proof-of-Resonance)
- **Long-Horizon & Sustainability Systems** — SCALULAR lifelong-learning certification, ERES Equity Covenant, 1000-Year Future Map
- **Standards & Open Licensing** — CARE Commons Attribution License v2.1 (CCAL), ERES Attribution Protocol, Trust & Continuity License (TCL)
- **Symbolic & Semantic Substrate** — Talonics Symbol Matrix; resonance-keyed semantic-superposition primitives
- **Cybernetic Foundations** — Triune Math; the Three Governing Principles; ERES epistemology; constraint-based culling methodology

Working familiarity with the emerging governance-standards landscape, including **ISO/IEC 42001** (AI management systems), **42005** (AI impact assessment), and **38507** (governance implications of AI).

---

## METHODOLOGICAL CONTRIBUTIONS

**Doctrine of Verifiable Claims.** An admissibility test for governance assertions: a claim counts only if it is falsifiable, re-derivable, carries its provenance, is open to contest by those with standing, and is judged by a competent body. Formulated as a practical filter for separating demonstrable governance claims from asserted ones.

**Non-comparative adjudication pattern.** A design pattern for high-liability AI decisions (hiring, lending, benefits, access): measure each person against a fixed, published standard rather than ranking people against one another — removing the cross-person comparison where disparate-impact liability concentrates. Made concrete in the **EPIR-Q** worked adjudication engine.

**Multi-Instrument Ensemble Validation Method (MIEVM).** An original cross-validation methodology that stress-tests each instrument across several independent large-language-model platforms and records the disagreement, rather than accepting a single model's self-assessment. Designed to compensate for solo-researcher bandwidth with reproducible inter-platform agreement signal and to surface platform-specific reasoning artifacts.

**Constraint-based culling epistemology.** The methodological backbone shared by MIEVM and the earlier 72 Key Domains of CyberRAVE: treating resource and bandwidth constraints as a primary culling instrument that produces a defensible shortlist rather than as an obstacle to validation.

**ERES Triune Math.** Three canonical equations used as foundational scaffolding across the corpus: C = R × P / M (Cybernetics); M × E + C = R (Reason); REAL = (E · M · R) / (T · S).

**Three Governing Principles.** SELF · OTHERS · FUTURE — *don't hurt yourself; don't hurt others; build for generations to come* — the ethical spine locked across the ERES corpus.

---

## MAJOR FRAMEWORKS & CONSTRUCTS

**The ERES Trilogy.** Three-volume foundational corpus mapping to the BEST / SOUND / GOOD epistemological triad, and the engine of the PlayNAC Simulator (dictum: *PlayNAC ≡ (ERES Trilogy × ERES UBIMIA Monograph) + ERES Library*). Book 1 — One-Good (UBIMIA); Book 2 — Security-Clearance (IDIPITIS · NBERS · SCALULAR); Book 3 — Data-Integrity (FAVORS · CBGMODD · GAIA · SOMT · ESVRD).

**ERES Cryptographic Stack & Attestation.** Cryptographic Stack Primitive v1.3 — resonance-keyed semantic superposition built on three polysemantic primitives (GCF · EDF · USC); canonical interlock (CBGMODD × FAVORS) + BERA = RATE. ERES Attestation and Authorization Protocol (EAAP) v1.3 — attestation substrate with hardware-rooted BERA sensor attestation and a post-quantum migration timeline. Paired with the ERES Trust & Continuity License (TCL) v1.0.

**BERA — Bio-Electric Resonance Architecture.** A multi-index instrument substrate defined within ERES for authentication, longitudinal identity, and resonance measurement: ARI (Aura Resonance Index), ERI (Emission Resonance Index), RHC (Resonant Harmony Cycle), and RCI (Resonant Continuity Index, co-developed with Jimmy D. Butzbach).

**FAVORS — Multi-Modal Authentication.** Six-factor biometric composite: Fingerprint · Aura · Voice · Odor · Retina · Signature.

**CBGMODD — Seven-Stakeholder Reference Architecture.** Citizen · Business · Government · Mediator · Military · Dignitary · Diplomat — the canonical participant taxonomy across ERES governance and economic instruments.

**UBIMIA.** Integrated, biometrically-anchored economic framework; the UBIMIA Manual v1.1 (April 2026; 188 pages) is the operational reference.

**DOFA — Department of Family Amity.** Whitepaper series establishing a seven-seat CBGMODD Family Stewardship Council with a consumption-to-care flip as its central mechanism; priority date March 2026.

**SCALULAR.** Scalable Certification Architecture for Lifelong Universal Learning and Adaptive Resilience — four pillars: Health, Law, Protection, and Skills/Trade.

**Meritcoin & Gracechain.** Economic primitive on Proof-of-Resonance ("not mining — tuning"); Gracechain provides the ledger substrate.

**PlayNAC Simulator.** Governance simulation engine; KERNEL versioned through v7.x with VERTECA integration.

**ERES Equity Covenant.** A 1000-year governance instrument aligned with the 1000-Year Future Map and the Patriot Dividend program.

**Talonics Symbol Matrix.** A 452-element symbolic substrate organized in a 12-part / 18×7 grid.

---

## SELECTED PUBLICATIONS & WORKING PAPERS

Selected from a record of 500+ publications and working papers on ResearchGate (ORCID 0000-0001-9946-3221); the full record is available via the ORCID profile and the institute's GitHub and Zenodo deposits. Organized by domain.

**AI Governance & Methodology**
- ERES AI Governance Position Paper (v1–v3)
- Joseph-Sprute — AI Governance Positioning Brief (2026)
- ERES-MIEVM-PATCH-2026-001; ERES-MIEVM-TETRA-ASSESSMENT-2026-001
- Anthropic_ERES_PlayNAC_Comprehensive_Report; Anthropic_ERES_PlayNAC_Logical_Derivation
- ERES_Maestro_Epistemology

**Cryptographic Architecture & Attestation**
- ERES-CRYPTO-SPEC-2026-001 (v1.1–v1.3) — ERES Cryptographic Stack Primitive
- ERES-CRYPTO-STD-2026-001 — ERES Cryptographic Standard
- ERES-EAAP-STD-2026-001 (v1.2–v1.3, FINAL) — Attestation and Authorization Protocol
- ERES-WEB3-TCP-HTTPS-2026 — transport-layer integration brief

**Biometric & Resonance Instruments**
- BERA_Complete_Report; ERES_RG404_BERA_SENSOR
- ERES ARI Framework; ARI E-Manual v1/v2; ARI Application Framework; ARI Empirics
- Emission Resonance Index (ERI) Proposal; Resonant Harmony Cycle v3.0/v4.0
- ERES_RCI_Specification_v1.0 (with Jimmy D. Butzbach)
- ERES-BODY-SPEC-2026-001; ERES-BRAINS-SPEC-2026-001

**Enterprise & Governance Architecture**
- ERES-CBGMODD-Stateful-Taxonomy-White-Paper
- ERES-DOFA-WP-2026-001 (versions A–C); DOFA Proposal with Governance Architecture
- ERES-SCALULAR-ENGINE-2026; ERES-SCALULAR-PUBLIC-RECORD-2026-03-18

**Economic Frameworks**
- ERES-UBIMIA-MANUAL-2026-001-v1.1-FINAL (188 pp.); ERES-UBIMIA-PUB-2026-001-FULL
- ERES_PATRIOT_DIVIDEND_v4.0_WHITE_PAPER (and v2.0/v3.0)
- ERES-401K-Soft-Landing-v2; ERESMeritcoinGracechain
- ERES How & Why NBERS Replaces GDP

**Long-Horizon, Sustainability & Planetary Frameworks**
- ERES 1000-Year Future Map; ERES-COVENANT-2026-001 (Equity Covenant)
- ERES-VLSA-2026 — Very Long-horizon Sustainability Architecture
- A Preventive Framework for Planetary Collision Avoidance and Resonance Homeostasis
- ERES-GSSG-SH-WP-2026-001 — GSSG Self-Healing Structures

**Symbolic, Semantic & Foundational Cybernetics**
- ERES-Talonics-Symbol-Foundation-2026; ERES_Talonics_Glossary_2026 (v1/v2)
- ERES TERMS series (47 issues); ERES Triune Math (canonical equations)
- Concerning Cybernetics: Abstraction Expansion; Defining Cybernetics: Reflections

**International Co-Authorship & Multilingual Briefs**
- Drive Resonant Vacuum SYU ERES (ESVRD) — with Syu Jia Wun, Tatung University, Taiwan
- Skulski-Sprute ERES LLM; ERES Andrzej Skulski EAAP DETAIL
- ERES_Berggruen_2026 (English & Chinese variants)
- ERES Government Partnership Brief 2026 — English, Spanish, Chinese, Russian, Arabic, Japanese, Indonesian, German

---

## STANDARDS, LICENSING & FILINGS

- **CARE Commons Attribution License v2.1 (CCAL)** — open-licensing framework authored within ERES; the license under which institute outputs are published (CC BY–compatible)
- **ERES-ATTRIBUTION-PROTOCOL-2026-001** — formal attribution protocol for ERES-derived works
- **ERES-TCL-v1.0** — Trust & Continuity License
- **Hague Submission (March 2026)** — intellectual-priority filing for constitutional-governance proposals
- **Zenodo** — continuous DOI-deposited licensing record, 2012–present
- **ResearchGate / ORCID 0000-0001-9946-3221** — 500+ publications and working papers

---

## COLLABORATORS & CO-AUTHORS

- **Emanuel M. Alexiou** — Chief Social Engineer; co-architect of the JAS×EMA architecture; governance and linguistic-bridge design
- **Jimmy D. Butzbach** — co-developer, Resonant Continuity Index (RCI); Continuity Theory
- **Syu Jia Wun** (Tatung University, Taiwan) — cross-Pacific co-author; Drive Resonant Vacuum (ESVRD)
- **Andrzej Skulski** — international collaborator on EAAP detail and the Skulski-Sprute LLM-validated paper
- **Multi-LLM Ensemble (MIEVM nodes)** — independent large-language-model platforms used as parallel validation nodes

---

## POSITIONS HELD

**Founder & Director — ERES Institute for New Age Cybernetics** · Feb 2012 – present · Bella Vista, AR
Established the institute as an independent research vehicle; continuous solo direction of all research, specification, publication, and licensing; author of the CARE Commons Attribution License v2.1.

**Founder — SaleBuilders** · 2007 – 2012
Smart-city adaptive-living engineering vehicle; predecessor architecture to the ERES Institute.

**Lead Architect — CyberRAVE** · 1997 – 2007
Cybernetic Ratings Abolishing Veiled Exchanges; foundation phase of the ERES framework. Originated the 72 Key Domains via constraint-based culling under TLD/VPN domain-renewal constraints.

**Freelance ICT Consultant** · 2002 – present
Business-technology and enterprise-architecture consulting with an eco-centric, sustainability focus. Selected engagements: Department of Homeland Security (Critical Infrastructure Assurance Office, 2002); The Internet Society (TVPN / VPN-grid concepts); The Open Group (boundaryless information-flow architecture).

---

## MILITARY SERVICE

**U.S. Army Veteran** — Oregon Army National Guard, Infantry (11B), 1983–1989, Honorable Discharge.

---

## REPOSITORIES, DISTRIBUTION & LANGUAGES

- **ResearchGate** — ORCID 0000-0001-9946-3221 (500+ publications and working papers)
- **GitHub** — ERES Institute organization: code artifacts, README documents, protocol specifications
- **Zenodo** — continuous DOI-deposited licensing record, 2012–present
- **Public channels** — Substack, Bluesky, LinkedIn, X, Medium, Academia.edu
- **Languages** — English (native)

---

*All works listed, unless otherwise noted, are published under the CARE Commons Attribution License v2.1 (CCAL) / CC BY, authored within the ERES Institute and intended to remain durably citable, attributable, and re-usable across academic, governmental, and enterprise contexts.*
