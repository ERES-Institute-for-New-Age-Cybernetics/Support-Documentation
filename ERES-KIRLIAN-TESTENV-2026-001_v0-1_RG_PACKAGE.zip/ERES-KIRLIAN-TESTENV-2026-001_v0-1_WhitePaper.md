# ERES-KIRLIAN-TESTENV-2026-001 v0.1 — Kirlianography Carrier-Invariance Test Environment

**Technical White Paper** · 24 October 2026 · Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221)

**License: CCAL v2.1 / CC-BY 4.0** · Status: SPECIFIED, pre-ensemble (GOOD)

---

## Abstract

This paper specifies the rig that turns Kirlianography from an image technique into a testable instrument. One subject is observed through two physically independent carriers: Kirlian corona video (Light) and a contact-piezo array (Sound). Each carrier receives a stage verdict (Spectrum, Resonance, Harmony or Condensed) from identical code. The claim under test is carrier invariance: both carriers give the same verdict for a living subject, and a different verdict from an inanimate control. Two executable suites ship with the paper. Building the session harness surfaced two design requirements now written into the specification. First, the camera frame rate must be an integer divisor of the HV pulse rate, because a 1024 Hz pulse train filmed at 100 fps aliases to 24 Hz. Second, each carrier needs about 32 channels, because the 1% chance-coherence floor is 0.88 at 6 channels and 0.38 at 32.

## 1. Claim under test

One coupling, observed through two physically independent carriers, receives the same stage verdict. This is the Reverse X claim from ERES-TRIFURCATION-WP-2026-001 v1.3, applied to Kirlianography.

- **Light carrier:** Kirlian corona video of the subject's fingertip or palm, read as 32 corona sectors.
- **Sound carrier:** a contact-piezo array of 32 elements around the same plate.
- **Verdict:** Spectrum, Resonance, Harmony or Condensed, returned by `classify_traces()` in `eres_srh_carrier_invariance.py`.

**Falsifier.** For a living subject, the Light and Sound verdicts differ in any accepted session. A mismatch means the corona pattern belongs to the device (voltage, moisture, exposure), not to the subject.

**Second falsifier.** A living subject and an inanimate control at the same voltage receive the same verdict, which means the rig is reading itself.

The simulation already passes, but there both carriers derive from the same phases, so invariance is close to guaranteed. This rig exists to test the claim with two independent physical sensors.

## 2. Architecture

![Test environment](ERES-KIRLIAN-TESTENV-2026-001_v0-1_Test-Environment-Figure.svg)

The Light and Sound carriers see the same contact plate through different physics and feed the same classifier. The humidity reading checks that agreement is not explained by sweat, and the ELF reference serves only the separate Schumann arm.

## 3. Hardware specification

Requirements are stated by function, not by product. Values marked *approx.* are typical of published Kirlian/GDV practice and must be confirmed against the chosen device.

| Channel | Role | Requirement |
| --- | --- | --- |
| HV corona source | drives the discharge | pulsed high voltage, ~10 kV, pulse rate ~1 kHz (*approx.*); current-limited; logged per session |
| Light sensor | Light carrier | camera ≥ 100 fps, frame rate an integer divisor of the pulse rate (e.g. 128 fps at 1024 Hz); ≥ 32 corona sectors as channels; fixed exposure and gain |
| Sound sensor | Sound carrier | contact-piezo array, ≥ 32 elements around the plate; ≥ 1 kHz sampling, decimated to 100 Hz |
| Gas Vapor Detector (GVD) | covariate | relative humidity, temperature, skin-surface vapor/VOC; ≥ 1 Hz |
| ELF reference | Schumann reference | induction-coil magnetometer sited away from mains |
| Sync clock | alignment | one hardware timestamp source for every channel; drift < 1 ms per session |
| Shielding | Schumann arm only | magnetically shielded vs unshielded enclosure |
| Controls | rig self-test | inanimate object (metal coin, saline sponge) at identical settings |

**Design rules.**

1. **Lock the frame rate to the pulse rate.** A 1024 Hz pulse train filmed at 100 fps aliases to 24 Hz, inside the 0.5–45 Hz analysis band. At 128 fps the alias falls at DC.
2. **Use about 32 channels per carrier.** With N uncoupled channels, chance coherence exceeds √(ln 100 / N) only 1% of the time. That floor is 0.88 at 6 channels and 0.38 at 32. Six regions of interest cannot separate coupling from chance.
3. **Use magnetic shielding for the Schumann arm.** A Faraday cage blocks electric fields but barely attenuates ELF magnetic fields.

## 4. Signal chain and software

Every channel is resampled to 100 Hz on the shared clock, then classified with the same code. 100 Hz covers the 5th Schumann harmonic; the Nyquist floor for 33.8 Hz is 67.6 Hz.

1. **Light trace.** Per frame, mean corona intensity in each of 32 sectors → samples × channels.
2. **Sound trace.** Each piezo element band-passed 0.5–45 Hz and decimated to 100 Hz.
3. **Phase extraction.** Hilbert analytic phase per channel; 2 s trimmed from each edge.
4. **Session wall.** r_lo = max(0.30, √(ln 100 / N), 99th percentile of 200 channel-shift shuffles).
5. **Stage verdict.** Identical rules for both carriers:

| Stage | Rule |
| --- | --- |
| Spectrum | r < r_lo |
| Resonance | r_lo ≤ r < 0.95, not held |
| Harmony | r_lo ≤ r < 0.95 and windowed σ(r) ≤ 0.10 |
| Condensed | r ≥ 0.95 (over-lock; fails Harmony) |

6. **Temporal Schumann Coupling Coefficient (SCC).** Light-trace power in narrow bands at 7.83, 14.3, 20.8, 27.3 and 33.8 Hz, correlated against the simultaneous ELF reference.

**Units correction to Transmission #03, Step 2.** An FFT over one still image yields spatial frequencies (cycles per millimetre), not Hz. Temporal SCC requires the video time series. The spatial FFT can be kept as a separate image descriptor.

## 5. Run protocol

1. **Pre-register** thresholds, sectors, band edges and session count before any data is seen.
2. **Calibrate:** inanimate control for 60 s; record GVD and ELF.
3. **Acclimate:** subject rests 5 min; contact surface cleaned and dried to a logged GVD reading.
4. **Record subject:** 60 s at rest, all channels together.
5. **Record a coupling condition:** 60 s with a structured stimulus (metronome or music at a fixed tempo).
6. **Repeat control:** 60 s, to catch drift.
7. **Classify blind:** an analyst without the condition labels runs `evaluate_session()`.
8. **Log and seal:** raw traces, settings, GVD log, verdicts and code hash, checksummed.

The first 20 s of each 60 s recording is discarded as transient.

## 6. Controls, confounds and safety

| Confound | Effect | Control |
| --- | --- | --- |
| Skin moisture and sweat | changes discharge brightness and shape | GVD covariate; verdicts compared at matched humidity (C5) |
| Contact pressure | changes corona area | fixed-pressure finger guide; pressure logged |
| Voltage and exposure drift | device-made patterns | settings locked; control before and after (R1) |
| HV pulse aliasing | false peaks in band | frame rate locked to pulse rate (R2) |
| Mains hum (50/60 Hz) | false Schumann-band power | notch filters; ELF reference away from mains |
| Too few channels | chance coherence read as coupling | ≥ 32 channels; calibrated wall r_lo |
| Shared-cause coupling | both carriers driven by one artifact | inanimate control must differ from subject (C2) |
| Analyst expectation | biased labels | blind classification; pre-registration |
| Noise mistaken for coupling | false Resonance | shuffled null stays at Spectrum (C4) |

**Safety.** The HV source touches a person. The device must be current-limited and electrically isolated, with the IEC 60601-1 family as the reference. The protocol needs human-subjects review and written informed consent before the first session. No subject with an implanted electronic device takes part.

## 7. Acceptance criteria and falsifiers

| Check | Pass | Fail means |
| --- | --- | --- |
| R1 Rig self-test | control reads Spectrum on both carriers, before and after | rig makes its own coherence; session rejected |
| R2 Alias check | pulse-rate alias outside 0.5–45 Hz | aliasing; fix frame rate |
| C1 Carrier invariance | subject Light verdict = Sound verdict | **claim refuted** |
| C2 Living vs control | subject verdict ≠ control verdict | rig reads itself; claim refuted |
| C3 Over-lock exclusion | no Condensed segment labelled Harmony | classifier error |
| C4 Null | shuffled subject trace stays at Spectrum | false Resonance from noise |
| C5 Moisture match | subject and control humidity within 5% RH | verdict explained by sweat |
| S1 Schumann arm | SCC tracks live ELF and drops under magnetic shielding | no Schumann coupling at this sensitivity |

C1 and C2 decide the main claim. S1 is a separate, harder claim: the Schumann field is around a picotesla, so a C1 pass does not imply an S1 pass.

## 8. Executable suites and results

| Suite | What it shows | Result (seed 20261024; 10 consecutive seeds) |
| --- | --- | --- |
| `eres_srh_carrier_invariance.py` | stage geometry, carrier invariance on synthetic carriers, null, category rule | 6/6 PASS |
| `eres_kirlian_testenv.py` | session harness accepts genuine coupling and rejects each failure case | 4/4 scenarios as specified |

Harness scenarios (32 channels per carrier, calibrated wall 0.38):

| Scenario | Light | Sound | Session accepted | Claim supported | Rejected by |
| --- | --- | --- | --- | --- | --- |
| Genuine coupling | Harmony | Harmony | yes | yes | — |
| Device artifact (supply ripple on Light only) | Condensed | Spectrum | yes | no | C1 |
| Rig self-coherence (control coherent) | Harmony | Harmony | no | no | R1 |
| Aliased drive (1024 Hz at 100 fps) | Harmony | Harmony | no | no | R2 |

**Recorded findings.** Two calibration attempts were tested and rejected. A fixed 0.30 wall passed the inanimate control as coherent at 6 channels. A shuffle mean + 4σ wall exceeded 1.0, because each shuffle of a near-periodic signal yields one random constant. The chance-floor wall above replaced both.

## 9. Status (DVC) and open items

| Element | Status |
| --- | --- |
| Carrier-invariance classifier and session harness | CONSTRUCTED, executable; pass synthetic scenarios |
| Stage thresholds; calibrated wall rule | DECLARED policy, pre-registered per session |
| Hardware requirements | SPECIFIED; HV values *approx.* until a device is chosen |
| Light–Sound invariance on a living subject | CONJECTURE, untested |
| Schumann coupling via corona | CONJECTURE, untested; separate arm |

Open items:

- [ ] Choose the HV corona device; confirm pulse rate, voltage and current limit.
- [ ] Human-subjects review and consent form before any session.
- [ ] Session count for C1 (power analysis after a pilot).
- [ ] Reconcile the Schumann field magnitude: Transmission #03 states ~10⁻¹⁵ T; standard references give picotesla order.
- [ ] Decide whether the spatial-FFT descriptor stays in BESI scoring or moves to an image-only annex.
- [ ] Ensemble (MIEVM) review and author-hardware reproduction of both suites.

## 10. Credits, References, License

**Credits.** Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas (ORCID 0000-0001-9946-3221). Drafted with Claude (Anthropic) under the ERES Sentience convention; not co-authorship.

**References.**

1. Sprute, J.A. (2026). ERES-TRIFURCATION-WP-2026-001 v1.3, Spectrum · Resonance · Harmony with the Reverse X carrier layer.
2. Sprute, J.A. (2026). ERES-REVERSE-X-2026-001, The Reverse X (Sprute Protocol).
3. Sprute, J.A. (2026). ERES TRANSMISSION #03, Drive-Train Battery Logic & Kirlianography, Part II.
4. Sprute, J.A. & Claude (2026). ERES BESI Kirlianography v0.1, References & Citations.
5. Sprute, J.A., Sprute, J.R. (2023). ERES Bio-Electric Gas Detection Optics (BEGDO) "Startup", final draft 19 Feb 2023.
6. Sprute, J.A. (2026). ERES-PELLIS-SHB-001, Sound Holds the Band (Theorem 1, Corollary 1, Prediction 2).
7. IEC 60601-1, Medical electrical equipment — general requirements for basic safety and essential performance.

**License: CCAL v2.1 / CC-BY 4.0.** CCAL v2.1 (CARE Commons Attribution License) supplements CC-BY 4.0 — https://creativecommons.org/licenses/by/4.0/
