#!/usr/bin/env python3
"""
ERES-TRIFURCATION-WP-2026-001 v1.2 — Spectrum · Resonance · Harmony test kit
Carrier-Invariance Suite (Reverse X)

Makes the v1.2 figure executable. Each stage is a measurement:
  SPECTRUM  -> spectral entropy H_s of the observed field (breadth of potential)
  RESONANCE -> cross-oscillator coherence r inside the band  r_lo <= r < r_cond
  HARMONY   -> band HELD: in-band mean r AND low windowed variance, never condensed
               (full lock r >= r_cond = condensation = failed Harmony; SHB Corollary 1)

Central claim (the X): the stage verdict for one coupling is CARRIER-INVARIANT.
The same underlying dynamics observed through a LIGHT carrier and a SOUND carrier
must receive the same stage label (forward and reverse reads agree).
FALSIFIER: any regime whose label differs between carriers rejects the claim
that Resonance belongs to both carriers.

Also tested: category rule (third term must be a stage, never a carrier),
and a phase-shuffled null that must NOT reach Resonance.

Status tags (DVC): carrier models = CONSTRUCTED (synthetic transfer functions);
band thresholds = DECLARED policy; invariance result = evidence, not proof.
Real light/sound traces plug in via classify_traces().

Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics
        (ORCID 0000-0001-9946-3221). Drafted with Claude (Sentience convention).
License: CCAL v2.1 / CC-BY 4.0 — CCAL v2.1 supplements CC-BY 4.0.
Exit code 0 = all checks PASS. Standard library + numpy only.
"""
import sys
import numpy as np

SEED = 20261024
FS = 100.0          # samples per second
T_TOTAL = 60.0      # seconds simulated
T_DROP = 20.0       # transient discarded
N_OSC = 60
OMEGA0 = 2 * np.pi * 1.0   # 1 Hz mean natural frequency
SIGMA = 1.0                # spread of natural frequencies (rad/s)

# Declared band (policy): Gaussian sigma=1 gives analytic K_c = 2/(pi*g(0)) ~= 1.60
R_LO = 0.30        # lower wall: below = incoherence (Spectrum only)
R_COND = 0.95      # upper wall: at/above = condensation (over-lock)
R_WIN_STD = 0.10   # Harmony requires the band to be HELD (stable)

STAGES = {"Spectrum", "Resonance", "Harmony"}
CARRIERS = {"Light", "Sound"}
RETIRED_THIRD = {"Fractal": "disperses", "Light": "carrier", "Sound": "carrier"}


# ---------- dynamics ----------
def kuramoto(K, rng):
    """K is a constant, or a (start, end) tuple ramped linearly over the kept window."""
    n = int(T_TOTAL * FS)
    dt = 1.0 / FS
    w = OMEGA0 + SIGMA * rng.standard_normal(N_OSC)
    th = rng.uniform(0, 2 * np.pi, N_OSC)
    out = np.empty((n, N_OSC))
    drop = int(T_DROP * FS)
    for t in range(n):
        if isinstance(K, tuple):
            frac = max(0.0, (t - drop) / (n - drop))
            k = K[0] + (K[1] - K[0]) * frac
        else:
            k = K
        z = np.mean(np.exp(1j * th))
        th = th + dt * (w + k * np.abs(z) * np.sin(np.angle(z) - th))
        out[t] = th
    return out[int(T_DROP * FS):]


# ---------- carriers (CONSTRUCTED transfer functions) ----------
def light_carrier(theta, rng):
    """Intensity: non-negative, gain + shot-like noise."""
    return 0.8 * (1 + np.cos(theta)) / 2 + 0.05 * rng.standard_normal(theta.shape)


def sound_carrier(theta, rng):
    """Pressure: bipolar, soft-clipping nonlinearity + different noise floor."""
    return np.tanh(1.5 * np.cos(theta)) + 0.08 * rng.standard_normal(theta.shape)


# ---------- measurement ----------
def hilbert_phase(x):
    """Analytic-signal phase per column (numpy FFT Hilbert)."""
    x = x - x.mean(axis=0)
    n = x.shape[0]
    X = np.fft.fft(x, axis=0)
    h = np.zeros(n)
    h[0] = 1
    if n % 2 == 0:
        h[n // 2] = 1
        h[1:n // 2] = 2
    else:
        h[1:(n + 1) // 2] = 2
    return np.angle(np.fft.ifft(X * h[:, None], axis=0))


def spectral_entropy(field):
    s = field.mean(axis=1)
    s = s - s.mean()
    p = np.abs(np.fft.rfft(s)) ** 2
    p = p[1:] / p[1:].sum()
    return float(-(p * np.log(p + 1e-300)).sum() / np.log(len(p)))


def coherence_series(phase):
    return np.abs(np.mean(np.exp(1j * phase), axis=1))


def classify_traces(field, r_lo=None):
    """Stage verdict for an observed field (samples x channels). Plug real traces here.
    r_lo: lower wall; default R_LO (valid for many channels). With few channels pass a
    shuffle-null calibrated wall (see calibrate_r_lo) — chance coherence rises as 1/sqrt(channels)."""
    r_lo = R_LO if r_lo is None else r_lo
    phase = hilbert_phase(field)
    r = coherence_series(phase)
    edge = int(2 * FS)               # trim Hilbert edge effects
    r = r[edge:-edge]
    r_mean = float(r.mean())
    win = int(5 * FS)
    wins = [r[i:i + win].mean() for i in range(0, len(r) - win + 1, win)]
    r_std = float(np.std(wins))
    hs = spectral_entropy(field)
    if r_mean >= R_COND:
        stage = "Condensed"          # over-lock: fails Harmony, not a stage
    elif r_mean < r_lo:
        stage = "Spectrum"
    elif r_std <= R_WIN_STD:
        stage = "Harmony"
    else:
        stage = "Resonance"
    return {"stage": stage, "r_mean": r_mean, "r_win_std": r_std, "H_s": hs}


def chance_floor(n_channels, alpha=0.01):
    """Coherence that n_channels uncoupled phases exceed with probability alpha.
    For random unit phasors P(r > x) ~ exp(-N x^2)  ->  x = sqrt(ln(1/alpha) / N)."""
    return float(np.sqrt(np.log(1.0 / alpha) / n_channels))


def calibrate_r_lo(field, rng, n_shuffles=200, alpha=0.01):
    """Lower wall from the data: the larger of R_LO, the analytic chance floor, and the
    (1 - alpha) quantile of channel-shift shuffles of this field."""
    phase = hilbert_phase(field)
    edge = int(2 * FS)
    null = []
    for _ in range(n_shuffles):
        sh = np.stack([np.roll(phase[:, j], rng.integers(len(phase))) for j in range(phase.shape[1])], axis=1)
        null.append(coherence_series(sh)[edge:-edge].mean())
    return max(R_LO, chance_floor(field.shape[1], alpha), float(np.quantile(null, 1 - alpha)))


# ---------- checks ----------
def main():
    rng = np.random.default_rng(SEED)
    regimes = {"incoherent (K=0.3)": 0.3, "selecting (K 1.0->3.0)": (1.0, 3.0),
               "in-band (K=2.0)": 2.0, "over-coupled (K=40)": 40.0}
    expected = {"incoherent (K=0.3)": "Spectrum", "selecting (K 1.0->3.0)": "Resonance",
                "in-band (K=2.0)": "Harmony", "over-coupled (K=40)": "Condensed"}
    results, ok = {}, True

    print("ERES SRH Carrier-Invariance Suite — seed", SEED)
    print(f"band: r_lo={R_LO}  r_cond={R_COND}  held if window-std <= {R_WIN_STD}\n")
    for name, K in regimes.items():
        th = kuramoto(K, rng)
        L = classify_traces(light_carrier(th, rng))
        S = classify_traces(sound_carrier(th, rng))
        results[name] = (L, S)
        print(f"{name:24s} Light: {L['stage']:9s} r={L['r_mean']:.3f} Hs={L['H_s']:.3f} | "
              f"Sound: {S['stage']:9s} r={S['r_mean']:.3f} Hs={S['H_s']:.3f}")

    print()
    # C1 carrier invariance (the X)
    c1 = all(L["stage"] == S["stage"] for L, S in results.values())
    print(f"C1 carrier invariance (Light verdict == Sound verdict, all regimes): {'PASS' if c1 else 'FAIL'}")
    # C2 regimes land where Theorem-1 band geometry says
    c2 = all(results[n][0]["stage"] == expected[n] for n in regimes)
    print(f"C2 stage geometry (incoherent->Spectrum, selecting->Resonance, held->Harmony, over-lock->Condensed): {'PASS' if c2 else 'FAIL'}")
    # C3 condensation is never Harmony (SHB Corollary 1)
    c3 = all(r[0]["stage"] != "Harmony" for n, r in results.items() if "over" in n)
    print(f"C3 full lock is not Harmony (Corollary 1): {'PASS' if c3 else 'FAIL'}")
    # C4 Spectrum = the full range: the incoherent field has the broadest spectrum of all regimes.
    # NOTE (recorded finding): a stronger monotone ordering (incoherent > in-band > condensed) was
    # tested and REJECTED — the condensed field carries carrier harmonics and is not the spectral
    # minimum. Only the Spectrum-is-broadest claim is retained.
    hs = {n: results[n][0]["H_s"] for n in regimes}
    c4 = all(hs["incoherent (K=0.3)"] > v for n, v in hs.items() if n != "incoherent (K=0.3)")
    print(f"C4 Spectrum is the broadest field (max spectral entropy at incoherence): {'PASS' if c4 else 'FAIL'}")
    # C5 null: phase-shuffled surrogate of the in-band field must not reach Resonance
    th = kuramoto(2.0, rng)
    sh = th + rng.uniform(0, 2 * np.pi, th.shape[1])[None, :]
    sh = np.stack([np.roll(sh[:, j], rng.integers(len(sh))) for j in range(sh.shape[1])], axis=1)
    null = classify_traces(light_carrier(sh, rng))
    c5 = null["stage"] == "Spectrum"
    print(f"C5 shuffled null stays at Spectrum (r={null['r_mean']:.3f}): {'PASS' if c5 else 'FAIL'}")
    # C6 category rule: triad terms are stages, never carriers
    triad = ["Spectrum", "Resonance", "Harmony"]
    c6 = all(t in STAGES and t not in CARRIERS for t in triad) and \
        all(t not in STAGES for t in RETIRED_THIRD)
    print(f"C6 category rule (third term is a stage, never a carrier): {'PASS' if c6 else 'FAIL'}")

    ok = all([c1, c2, c3, c4, c5, c6])
    print(f"\nVERDICT: {'PASS — evidence, not proof (CONSTRUCTED carriers)' if ok else 'FAIL'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
