#!/usr/bin/env python3
"""
ERES-KIRLIAN-TESTENV-2026-001 v0.1 — Test-Environment Acceptance Harness

Session-level acceptance logic for the Kirlianography carrier-invariance rig.
Uses classify_traces() from eres_srh_carrier_invariance.py (same folder), so the
Light and Sound carriers are judged by identical code and identical thresholds.

Checks per session (see white paper section 7):
  R1  rig self-test   : inanimate control reads Spectrum on both carriers (pre and post)
  R2  alias check     : HV pulse rate does not alias into the 0.5-45 Hz analysis band
  C1  carrier invariance : subject Light verdict == subject Sound verdict
  C2  living vs control  : subject verdict != control verdict
  C4  null            : phase-shuffled subject Light trace stays at Spectrum
  C5  moisture match  : subject and control GVD humidity within tolerance

Lower wall: calibrated per session (kit.calibrate_r_lo) = the larger of 0.30, the
analytic chance floor sqrt(ln(1/alpha)/N) at alpha = 0.01, and the 99th percentile of
200 channel-shift shuffles.
Recorded findings: (1) with N uncoupled channels, chance coherence exceeds
sqrt(ln(100)/N) only 1% of the time: 0.88 at N = 6, 0.38 at N = 32. Six regions of
interest cannot separate coupling from chance; the rig needs ~32 channels per
carrier. (2) A first calibration (shuffle mean + 4 sd) gave walls above 1.0 and was
rejected: each shuffle of a near-periodic signal yields one random constant, so the
spread is the full chance distribution.

Real data: evaluate_session() takes arrays (samples x channels at 100 Hz) and a
GVD humidity value per segment. --demo runs four synthetic scenarios and checks
that the harness accepts the genuine case and REJECTS each failure case.
Exit code 0 = the harness behaved as specified in every scenario.

DVC status: synthetic scenarios = CONSTRUCTED; thresholds = DECLARED policy
(imported from the kit); harness logic = SPECIFIED. Evidence of harness
correctness only, not of the physical claim.

Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics
        (ORCID 0000-0001-9946-3221). Drafted with Claude (Sentience convention).
License: CCAL v2.1 / CC-BY 4.0 — CCAL v2.1 supplements CC-BY 4.0.
"""
import sys
import os
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eres_srh_carrier_invariance as kit  # noqa: E402

BAND = (0.5, 45.0)        # analysis band, Hz
RH_TOL = 5.0              # % relative humidity tolerance for C5
CH = 32                   # channels per carrier (corona sectors; piezo array elements)


# ---------- R2: aliasing of the HV pulse train into the frame clock ----------
def folded_alias(prf_hz, fps):
    """Frequency at which a pulse rate prf appears when sampled at fps."""
    f = prf_hz % fps
    return min(f, fps - f)


def alias_ok(prf_hz, fps):
    """True when the alias lands outside the analysis band (DC counts as outside)."""
    a = folded_alias(prf_hz, fps)
    return not (BAND[0] <= a <= BAND[1]), a


# ---------- session evaluation ----------
def shuffle_null(field, rng):
    """Independent circular shift per channel: keeps each spectrum, destroys cross-channel phase."""
    return np.stack([np.roll(field[:, j], rng.integers(len(field))) for j in range(field.shape[1])], axis=1)


def evaluate_session(s, rng):
    """s: dict with subj_light, subj_sound, ctrl_light, ctrl_sound, ctrl_light_post,
    ctrl_sound_post (arrays), rh_subj, rh_ctrl (floats), prf_hz, fps."""
    keys = ("subj_light", "subj_sound", "ctrl_light", "ctrl_sound", "ctrl_light_post", "ctrl_sound_post")
    # Lower wall calibrated per session from the subject's own shuffle null (few ROIs raise chance coherence).
    r_lo = max(kit.calibrate_r_lo(s["subj_light"], rng), kit.calibrate_r_lo(s["subj_sound"], rng))
    v = {k: kit.classify_traces(s[k], r_lo)["stage"] for k in keys}
    r1 = all(v[k] == "Spectrum" for k in ("ctrl_light", "ctrl_sound", "ctrl_light_post", "ctrl_sound_post"))
    r2, alias = alias_ok(s["prf_hz"], s["fps"])
    c1 = v["subj_light"] == v["subj_sound"]
    c2 = v["subj_light"] != v["ctrl_light"]
    c4 = kit.classify_traces(shuffle_null(s["subj_light"], rng), r_lo)["stage"] == "Spectrum"
    c5 = abs(s["rh_subj"] - s["rh_ctrl"]) <= RH_TOL
    rig_ok = r1 and r2
    claim = rig_ok and c1 and c2 and c4 and c5
    return {"r_lo": r_lo, "verdicts": v, "R1": r1, "R2": r2, "alias_hz": alias, "C1": c1, "C2": c2,
            "C4": c4, "C5": c5, "session_accepted": rig_ok, "claim_supported": claim}


# ---------- synthetic scenarios (CONSTRUCTED) ----------
def noise_field(rng, n, ch=CH, sd=0.1):
    return sd * rng.standard_normal((n, ch))


def ripple(n, hz, amp):
    t = np.arange(n) / kit.FS
    return amp * np.cos(2 * np.pi * hz * t)[:, None]


def scenario(name, rng):
    n = int((kit.T_TOTAL - kit.T_DROP) * kit.FS)
    base = dict(rh_subj=41.0, rh_ctrl=40.0, prf_hz=1024.0, fps=128.0)
    def free_phases():
        """Uncoupled oscillators: each channel runs at its own frequency (an inanimate plate has no coupling)."""
        w = kit.OMEGA0 + kit.SIGMA * rng.standard_normal(CH)
        t = np.arange(n)[:, None] / kit.FS
        return rng.uniform(0, 2 * np.pi, CH) + w * t + 0.05 * np.cumsum(rng.standard_normal((n, CH)), axis=0)
    ctrl = {"ctrl_light": lambda: kit.light_carrier(free_phases(), rng),
            "ctrl_sound": lambda: kit.sound_carrier(free_phases(), rng)}
    ctrl["ctrl_light_post"], ctrl["ctrl_sound_post"] = ctrl["ctrl_light"], ctrl["ctrl_sound"]
    if name == "genuine coupling":
        th = kit.kuramoto(2.0, rng)[:, :CH]
        s = dict(subj_light=kit.light_carrier(th, rng), subj_sound=kit.sound_carrier(th, rng))
    elif name == "device artifact":
        # Light sees a common supply ripple on every ROI; the subject is not coupled.
        th = kit.kuramoto(0.3, rng)[:, :CH]
        s = dict(subj_light=kit.light_carrier(th, rng) * 0.05 + ripple(n, 3.0, 1.0) + noise_field(rng, n),
                 subj_sound=kit.sound_carrier(th, rng))
    elif name == "rig self-coherence":
        th = kit.kuramoto(2.0, rng)[:, :CH]
        s = dict(subj_light=kit.light_carrier(th, rng), subj_sound=kit.sound_carrier(th, rng))
        base_ctrl = ripple(n, 3.0, 1.0) + noise_field(rng, n)
        s.update(ctrl_light=base_ctrl, ctrl_light_post=base_ctrl.copy())
    elif name == "aliased drive":
        th = kit.kuramoto(2.0, rng)[:, :CH]
        s = dict(subj_light=kit.light_carrier(th, rng), subj_sound=kit.sound_carrier(th, rng))
        base["fps"] = 100.0      # 1024 Hz pulses at 100 fps alias to 24 Hz
    else:
        raise ValueError(name)
    for k in ("ctrl_light", "ctrl_sound", "ctrl_light_post", "ctrl_sound_post"):
        s.setdefault(k, ctrl[k]())
    s.update(base)
    return s


EXPECT = {  # what a correctly built harness must conclude
    "genuine coupling": dict(session_accepted=True, claim_supported=True),
    "device artifact": dict(session_accepted=True, claim_supported=False, C1=False),
    "rig self-coherence": dict(session_accepted=False, R1=False),
    "aliased drive": dict(session_accepted=False, R2=False),
}


def demo():
    rng = np.random.default_rng(kit.SEED)
    print("ERES Kirlianography Test-Environment Harness — demo, seed", kit.SEED)
    print(f"chance floor (alpha=0.01): N=6 -> {kit.chance_floor(6):.2f}, N=32 -> {kit.chance_floor(32):.2f}; demo uses N={CH}")
    print(f"alias check: 1024 Hz @ 100 fps -> {folded_alias(1024, 100):.0f} Hz (in band); "
          f"1024 Hz @ 128 fps -> {folded_alias(1024, 128):.0f} Hz (DC, outside band)\n")
    ok_all = True
    for name, exp in EXPECT.items():
        res = evaluate_session(scenario(name, rng), rng)
        ok = all(res[k] == val for k, val in exp.items())
        ok_all &= ok
        v = res["verdicts"]
        print(f"{name:20s} wall={res['r_lo']:.2f} Light={v['subj_light']:9s} Sound={v['subj_sound']:9s} ctrl={v['ctrl_light']:9s} "
              f"R1={res['R1']!s:5s} R2={res['R2']!s:5s} C1={res['C1']!s:5s} C2={res['C2']!s:5s} "
              f"C4={res['C4']!s:5s} C5={res['C5']!s:5s} -> accepted={res['session_accepted']!s:5s} "
              f"supported={res['claim_supported']!s:5s} [{'as specified' if ok else 'WRONG'}]")
    print(f"\nVERDICT: {'PASS — harness accepts the genuine case and rejects each failure case' if ok_all else 'FAIL'}")
    print("Scope: harness correctness only (CONSTRUCTED scenarios); the physical claim needs real traces.")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(demo())
