# ERES-KIRLIAN-TESTENV-2026-001 v0.1 — Kirlianography Carrier-Invariance Test Environment

Test package: white paper, figures and two executable suites. The package specifies a rig in which one subject is read through two independent carriers, Kirlian corona video (Light) and a contact-piezo array (Sound). It checks whether both give the same stage verdict.

**Claim under test.** The Light verdict equals the Sound verdict for a living subject, and differs from an inanimate control.
**Falsifier.** Any accepted session where the two carriers disagree.

## Run

```
python3 eres_srh_carrier_invariance.py   # stage geometry + carrier invariance (6 checks)
python3 eres_kirlian_testenv.py          # session harness: accepts genuine, rejects each failure (4 scenarios)
```

Requires Python 3 and numpy. Exit code 0 means PASS. Both suites pass on seed 20261024 and on the 10 consecutive seeds after it.

## Design requirements found by the harness

1. **Frame rate locked to the pulse rate.** A 1024 Hz pulse train filmed at 100 fps aliases to 24 Hz, inside the analysis band; at 128 fps the alias falls at DC.
2. **About 32 channels per carrier.** The 1% chance-coherence floor √(ln 100 / N) is 0.88 at N = 6 and 0.38 at N = 32.

## Real data

`evaluate_session()` in `eres_kirlian_testenv.py` takes six arrays (samples × channels, 100 Hz):

- subject Light and subject Sound
- control Light and control Sound, before the subject
- control Light and control Sound, after the subject

It also takes the GVD humidity for subject and control, plus the pulse rate and frame rate. It returns R1, R2, C1, C2, C4 and C5, and whether the session is accepted and the claim supported.

## Files

| File | Role |
| --- | --- |
| `ERES-KIRLIAN-TESTENV-2026-001_v0-1_WhitePaper.md` | master text |
| `ERES-KIRLIAN-TESTENV-2026-001_v0-1_WhitePaper.pdf` | rendered white paper |
| `ERES-KIRLIAN-TESTENV-2026-001_v0-1_Test-Environment-Figure.svg` / `.png` | rig architecture |
| `ERES-TRIFURCATION-WP-2026-001_v1-3_Reverse-X-Figure.svg` / `.png` | Spectrum · Resonance · Harmony over the Kirlianography carriers |
| `eres_srh_carrier_invariance.py` | classifier + carrier-invariance suite |
| `eres_kirlian_testenv.py` | session acceptance harness |
| `META.txt` | ResearchGate title, abstract, keywords, share message |
| `CITATION.cff` | citation metadata |
| `manifest.json` | package metadata, test results, SHA-256 checksums |

## Status (DVC)

| Element | Status |
| --- | --- |
| Classifier and harness | CONSTRUCTED, executable |
| Thresholds | DECLARED policy |
| Physical claim | CONJECTURE, untested |
| Overall grade | GOOD, pending real traces, MIEVM review and author-hardware reproduction |

## Credits / License

Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221). Drafted with Claude under the Sentience convention.

**License: CCAL v2.1 / CC-BY 4.0.** CCAL v2.1 (CARE Commons Attribution License) supplements CC-BY 4.0.
