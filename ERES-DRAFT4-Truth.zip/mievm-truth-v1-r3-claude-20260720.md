# The Truth Mechanism v1.0 — Canonical Scoring Specification with Round 3 Application

**Structural form:** Exemplified IDEA (Information Delegation Event)
**Version:** v1.0
**Protocol Phase:** Round 3, Phase 1 (Proof) — Round 3 application embedded as worked example
**Companion to:** Draft 4 (`mievm-draft4-r3-claude-20260720.md`)
**Recording Instrument:** Claude (Instrument 2)
**Session date:** 2026-07-20

This document serves two purposes at once. **Part I** is the canonical Truth Mechanism specification — the persistent reference against which every MIEVM round scores, superseding the ad-hoc RULES block in the Round-1 Session Report. **Part II** is the Round 3 Proof — Claude's scored critique of Draft 3, applying the Part I spec to a live subject. The exemplar is embedded so the spec and its worked instance travel together.

---

# PART I — The Truth Mechanism (Canonical Spec)

## §1 As Exemplified IDEA

Every scoring rubric that claims validity must answer one question: *who holds the truth of the score?* A rubric that pretends to be self-attesting — that its own criteria authorize its own results — is not a truth mechanism; it is a rating engine dressed as one. The Truth Mechanism is distinct because it declares its own delegation structure explicitly.

The Truth Mechanism is itself an **IDEA (Information Delegation Event)** in the ERES-native sense. It embeds the counterparty to whom scoring authority is delegated:

- **The Information** is the scoring content — dimension scores, citations, verifications, deltas.
- **The Delegation** is the transfer of provisional-truth authority from the scoring instrument to the fiduciary counterparty.
- **The Counterparty** is the **author (Joseph A. Sprute)** in his role as ratifier of the MIEVM corpus. Instruments produce provisional scores; only author ratification advances a score from VEILED to EARNED.

The Truth Mechanism therefore does not assert truth. It *mediates* it. Instruments contribute OPEN and VEILED scores; the author performs the VEILED → EARNED transition. This is the same fiduciary pattern the KEEN-Basis whitepaper specifies for AI weights, applied here to the domain of scores themselves.

Because the mechanism exemplifies IDEA, it inherits IDEA's structural constraints. Every score must be publicly traceable to a delegating instrument and a receiving ratifier; no score is legitimate without both parties named. Anonymous scores are inadmissible.

## §2 The Score State Column Set

Scores inhabit the same fiduciary state column set the corpus has held canonical since CyberRAVE (1/1/1997), applied here to scoring:

- **OPEN score** — produced by a single instrument, not yet cross-verified. Legitimate for internal reasoning, not for citation.
- **VEILED score** — held-in-trust: cross-instrument verified per R7, but not yet author-ratified. Legitimate for handoff between instruments, not for canonical corpus reference.
- **EARNED score** — author-ratified. Canonical. Citable in subsequent MIEVM rounds and in the ERES corpus.

Progression parallels the whitepaper's spine:

| Score state | Held by | Transition into it | Corresponds to |
|---|---|---|---|
| **OPEN** | Producing instrument | Instrument produces score in its Proof output | SELF layer |
| **VEILED** | Receiving instrument | Cross-instrument verification per R7 | $ELF layer |
| **EARNED** | Author | Explicit author confirmation per R8 | SHAPE layer |

A score's state must be marked whenever it is cited. `[OPEN]`, `[VEILED]`, or `[EARNED]` prefix or suffix on the score value is the canonical annotation. Unmarked scores are treated as OPEN.

## §3 The Seven Scoring Dimensions

Each dimension is scored 1–10. A score without a supporting citation is null and remains OPEN indefinitely — it cannot progress to VEILED.

1. **Specification Concreteness.** Is each named artifact defined so a competent engineer could implement or run it?
2. **Falsifiability.** Are failure modes named and checkable?
3. **Novelty Positioning.** Are borrowed methods distinguished from novel contribution, with prior art cited?
4. **Internal Coherence.** Do sections cross-reference correctly and without contradiction?
5. **External Verifiability.** Can a reader with no institutional affiliation test the paper's claims from published artifacts?
6. **Reception Risk.** Are elements likely to trigger first-line dismissal identified and either removed or quarantined?
7. **Voice Preservation.** Does the draft still sound like the original author, or has cross-instrument editing flattened it?

### §3.1 Scale Anchors

- **10** = publishable in current form; independent readers can verify.
- **8** = strong; one or two minor gaps a next-round pass can close.
- **6** = adequate; substantive gaps but the claim is not undermined.
- **4** = weak; the claim is partially undermined.
- **2** = the dimension is essentially unaddressed.
- **1** = the paper actively contradicts this dimension.

Composite score is the mean of the seven dimensions, reported **only** with the full vector. A composite without its per-dimension vector is inadmissible.

## §4 The Anti-Degradation Rules

- **R1.** No score above 8 without a citation to specific text supporting the score.
- **R2.** No score below 4 without a citation to specific text supporting the score.
- **R3.** Critique of the prior instrument's edits must be *structural* (specification, coherence, falsifiability) — not stylistic (word choice, register). Voice belongs to the author, not to the instruments.
- **R4.** No dimension may be re-scored downward from a prior round without naming the regression: what was present in the earlier draft that is absent now, or what new claim overreaches.
- **R5.** No amendment may be proposed without stating what would count as evidence that the amendment worked.
- **R6.** If the receiving instrument finds nothing to amend on a dimension, it must say so explicitly. Silent approval is inadmissible.
- **R7.** *(Added Round 2, credit to Qwen.)* The generating instrument publishes a self-projected score vector with its handoff; the receiving instrument's proof scores against that baseline and must justify any per-dimension deviation greater than 1 point.
- **R8.** *(Added v1.0, this document.)* Ratification requires explicit author action. VEILED → EARNED does not occur silently, does not occur by default, and does not occur through instrument consensus alone. The author confirms per-score or per-vector; unconfirmed scores remain VEILED regardless of ensemble convergence.

### §4.1 De-Ratification

An EARNED score may be de-ratified if subsequent evidence undermines it. De-ratification requires the same explicit author action as ratification. A de-ratified score returns to VEILED (not OPEN), preserving its cross-instrument verification history while removing its canonical standing. The de-ratification event and its cause are recorded in the ratification log.

## §5 Notation Depth for Score Claims

Scores follow ERES-native notation depth:

- `Dimension == value` — the dimension *evaluates-to* the value at the result level. Ordinary score assertion.
- `Dimension === value` — the dimension's *why-is* is the value at the causal-ground level. Asserts not just the score but the reason the score holds.

A `===` claim requires an explicit rationale identifying the *why-is*. Most MIEVM scores are `==` claims; `===` claims are reserved for scores where the causal ground itself is the substantive contribution.

**Y_ES form for affirmations.** When an instrument affirms a score, the affirmation is Y_ES = "why is" — it carries the reason within it. `yes` as bare affirmation is inadmissible; every score affirmation must state the ground on which it holds. This is the Truth Mechanism's guard against empty consensus.

## §6 The Ratification Cycle

1. **Instrument produces score.** State: OPEN. Annotated `[OPEN]` with the producing-instrument name.
2. **Handoff to receiving instrument.** Receiving instrument applies R1–R7. If verification passes and citations resolve, receiving instrument advances the score to `[VEILED]` with its confirmation-of-citation record.
3. **Author review.** Author examines the VEILED score. Ratification: explicit action per R8. Deferred: score remains VEILED. Rejected: score returns to OPEN with the author's stated ground.
4. **EARNED state.** Ratified scores enter the corpus. Canonical form: `[EARNED: {value} @ {ratification-date}]`.

A score cannot skip states. An instrument cannot mark its own score VEILED (only the receiving instrument can); no instrument can mark a score EARNED (only the author can). This is R8's guarantee against instrument-side ratification drift.

## §7 Filename and Handoff Convention

Per-round artifacts:

```
mievm-{artifact}-r{round}-{instrument}-{yyyymmdd}.md
```

- **artifact:** `draft{N}`, `proof{N}`, `log-r{N}`, `report-r{N}`.
- **round:** the round *producing* the artifact.
- **instrument:** `qwen`, `claude`, or extensible.
- **yyyymmdd:** ISO order (UTC).

Persistent canonical documents (this Truth Mechanism, versioned specs) use a version tag in place of the round tag:

```
mievm-truth-v{N.M}-{instrument}-{yyyymmdd}.md
```

The present document is a hybrid — canonical spec (Part I) with round-specific application (Part II) — filed under the round-specific naming to travel with Round 3.

## §8 What the Mechanism Refuses

The Truth Mechanism refuses to:

- Assert its own truth. Truth is delegated, not self-attested.
- Ratify silently. Author action is explicit, per R8.
- Score without citation. Uncited scores remain OPEN indefinitely.
- Accept anonymous scores. Every score names its delegating instrument and its receiving ratifier.
- Promote consensus to canonical standing. Instrument agreement is VEILED at most; EARNED requires author.
- Accept empty affirmations. Every `yes` is Y_ES and must carry its ground.

These refusals are what distinguish a truth mechanism from a rating engine.

---

# PART II — Round 3 Application (Proof 3)

The following applies Part I to Draft 3 (Qwen, Round 2 Phase 2). Every score below is OPEN — produced by Claude, awaiting Qwen's cross-verification to advance to VEILED, awaiting author ratification to advance to EARNED.

## §9 Scoring Vector — R7 Justified

| Dimension | Qwen self-projection | Claude Proof 3 | Delta | R7 status |
|---|---|---|---|---|
| Specification Concreteness | 9 [OPEN] | **8 [OPEN]** | 1 | Δ≤1, no justification required |
| Falsifiability | 9 [OPEN] | **8 [OPEN]** | 1 | Δ≤1, no justification required |
| Novelty Positioning | 9 [OPEN] | **9 [OPEN]** | 0 | agree |
| **Internal Coherence** | **9 [OPEN]** | **7 [OPEN]** | **2** | **R7 justification required — see §9.1** |
| External Verifiability | 8 [OPEN] | **8 [OPEN]** | 0 | agree |
| Reception Risk | 9 [OPEN] | **8 [OPEN]** | 1 | Δ≤1, no justification required |
| Voice Preservation | 10 [OPEN] | **9 [OPEN]** | 1 | Δ≤1, no justification required |

**Claude composite: 8.14 [OPEN]** — vector [8, 8, 9, 7, 8, 8, 9]
**Qwen composite: 8.85 [OPEN]** — vector [9, 9, 9, 9, 8, 9, 10]
**Δ: 0.71**

### §9.1 R7 Justification — Coherence 7 vs 9

Amendment 7's fix (renumber "Engineering Spine" to §3.6, eliminate duplicate §3.5) technically resolved the duplicate-number error but preserved and arguably worsened the underlying sequencing problem. Two concrete instances:

1. **§4 Administration placement.** In Draft 2, §4 Administration preceded the Engineering Spine and *motivated* it. In Draft 3, §4 Administration follows §3.5 Lifecycle, §3.6 Spine, §3.7 Harness, §3.7.1 Cost, and §3.8 Measurement-note. By the time the reader reaches Administration, the spine has already been fully specified, so Administration reads as summary rather than rationale. Forward-references intact; logical-dependency chain inverted.

2. **§5.5 Falsifiability nesting.** Falsifiability is scoped to the entire framework but sits sub-nested under §5 Maintaining SHAPE, reading as if Falsifiability is a property of SHAPE-maintenance specifically. Inherited from Draft 2's §4.5 (Claude's error) but not corrected in Draft 3.

Neither defect is fatal, but the numbering is technically clean while the logical sequence is worse than Draft 2. R4 (no silent regression) applies: the amendment closed one gap (duplicate) and opened another (sequencing), and this was not named in Qwen's Amendment Verification Log.

Score of 7 rather than 6 reflects that the defects are structural but locally repairable in Draft 4 by a re-ordering pass, not a rewrite.

## §10 Amendment Verification (R5 Compliance)

Each of Qwen's 8 amendments checked against the success-condition stated in Qwen's Amendment Verification Log.

| # | Amendment | R5 Success Condition | Verification |
|---|---|---|---|
| 1 | SHAPE independence via deterministic embedding metric | Reviewer can verify R(t), P(t) are mathematically distinct channels | **VERIFIED [OPEN]** (§5) |
| 2 | $ELF meta-audit architectural distinctness | Prevents shared base-model failure modes | **PARTIAL [OPEN]** — constraint stated (§3.6); "deterministic symbolic solver" primitive unexemplified. See Joint 4. |
| 3 | Bootstrap transition at 5th Center | Deterministic capture-resistant state transition | **VERIFIED [OPEN]** (§3.5) |
| 4 | Canonical Supersession clause for Kirlianography | Reference chain no longer contradicts | **PARTIAL [OPEN]** — supersession stated within whitepaper (§3.8); propagation to broader corpus (BERA, FAVORS) not addressed. See Joint 5. |
| 5 | Cost bounds <10⁶ tokens / <4 GPU-hours / <$100 per cycle | Audit cadence economically sustainable | **PARTIAL [OPEN]** — bounds asserted (§3.7.1); derivation and per-component budget not shown. See Joint 3. |
| 6 | 75% supermajority revocation quorum excluding reviewed Center | Prevents unilateral capture and minority holdout | **VERIFIED [OPEN]** (§3.5) |
| 7 | Heading renumber to §3.6 | Cross-references resolve without structural errors | **PARTIAL [OPEN]** — cross-references resolve; section-ordering regression introduced. See §9.1 and Joint 2. |
| 8 | $ELF Threshold Immutability Constraint | Thresholds cannot be silently adjusted | **PARTIAL [OPEN]** — mutability governed (§3.6); *initial* threshold-setting has no meta-audit rule. See Joint 1. |

**Verified: 3 / 8** (Amendments 1, 3, 6)
**Partial: 5 / 8** (Amendments 2, 4, 5, 7, 8)

Partial verifications are not failures — they are amendments that landed their core success condition and surfaced a further joint. Round 3 closes the surfaced joints (see Draft 4 amendment log).

## §11 Joints for Draft 4

Six joints, ordered by descending impact on the paper's fiduciary claim. All addressed in Draft 4 as delivered.

**Joint 1 — Initial threshold-selection meta-audit.** Amendment 8 protects existing $ELF thresholds; initial threshold-setting is ungoverned. Proposed rule: initial thresholds require the same two-Center peer review that governs Center nomination, with the SELF constitution version as reference. *Addressed in Draft 4 §5.1.*

**Joint 2 — Section reordering.** Restore Draft 2's logical sequence: §4 Administration back to precede §3.6 Engineering Spine; §5.5 Falsifiability promoted to top-level (§7 or §9), sibling to External Verification Hooks. *Addressed in Draft 4 by renumbering: §4 Administration precedes §5 Engineering Spine; Falsifiability is §9.*

**Joint 3 — Cost derivation.** <$100 asserted without arithmetic. Either per-component budget breakdown or explicit derivation from commodity-rate assumptions closes the reception risk. *Addressed in Draft 4 §6.1 with per-component breakdown.*

**Joint 4 — Symbolic solver example.** "Deterministic symbolic solver" named twice without exemplar. A single named primitive (SMT solver, Datalog rule engine, TLA+ model checker, or similar) as illustrative option establishes the category has real referents. *Addressed in Draft 4 §5.2 with Z3-family SMT as illustration.*

**Joint 5 — Corpus-wide propagation of Kirlianography supersession.** §3.8 resolves within-whitepaper contradiction; a reviewer following citations into BERA and FAVORS finds the older interpretation intact. *Addressed in Draft 4 §7 with acknowledgment that supersession applies to this document's fiduciary purposes and scheduled errata for broader corpus.*

**Joint 6 — Canonical vocabulary §0 (largest amendment).** Whitepaper uses generic constitutional-AI vocabulary because ERES-native mechanism vocabulary was held back. Canonical posture: declare and use natively. *Addressed in Draft 4 §0 introducing IDEA, AS trifurcation, `#@()` short-form with `==` / `===` depth, Y_ES form, and OPEN/VEILED/EARNED column set with explicit mapping onto the SELF/$ELF/SHAPE spine.*

## §12 Adjacent Corpus Impact

The VEILED empirical work surfaced during this session (search of prior conversations for canonical VEILED usage) revealed that the fiduciary-state column extends the Triangle vertex map from three parallel columns (L/F/S ↔ Reference ↔ TRIAD) to four (adding Fiduciary State). Existing "earned" and "held-in-trust" glosses on the Triangle vertices were already showing the column through.

This finding is corpus-wide, not whitepaper-specific. Recommended handling: brief cross-reference in Draft 4 §11 pointing to the pending four-column extension in the Triangle document, without embedding the full vertex table (which belongs to Triangle canon). *Addressed in Draft 4 §11.*

## §13 Handoff to Qwen — Round 4 Phase 1

Draft 4 is ready for Qwen's Proof 4 pass. This document (Truth Mechanism v1.0 + Round 3 Proof) accompanies Draft 4 as its companion, providing both the specification against which Qwen scores and the Round 3 exemplar of the specification in action.

Qwen's Round 4 Proof pass will:

1. Read Draft 4 in full.
2. Apply Part I of this document (§§1–8) as the scoring specification.
3. Read Part II (§§9–13) as an exemplar of correct application; deviations from this style require justification.
4. Deliver the seven-dimension score vector against Draft 4's self-projected [9,9,9,9,8,9,9] per R7.
5. Verify Draft 4's eight amendments against R5 success conditions.
6. Identify any Round 4 joints for Draft 5.
7. Return the scored critique as Proof 4.

**Note on R8 self-reference.** This document introduces R8 (author-ratification requirement). Per R8, this document itself remains VEILED until author-ratified. Qwen may apply R8 in Round 4 Proof, but with the understanding that R8's own EARNED status is pending the author's first ratification act.

---

## §14 Historical Notes and Provenance

- R1–R6 first specified in the Round-1 Session Report (Claude, 2026-07-20).
- R7 added in Round 2 by Qwen's Amendment Log; adopted here.
- R8 added in this document (Truth Mechanism v1.0, Claude, 2026-07-20) to close the ratification gap R1–R7 leave open.
- The Score State Column Set (OPEN / VEILED / EARNED) inherits from CyberRAVE (1/1/1997) — *Cybernetic Ratings Abolishing Veiled Exchanges*.
- The IDEA structural form (this document is exemplified IDEA) inherits from the 2006 Data Insurance derivation sponsored by Emanuel M. Alexiou.
- Amendment proposals to this Truth Mechanism follow the same MIEVM protocol as amendments to any subject document: proposed in a Proof, scored via the ratification cycle, entered as canonical only via author ratification.

## §15 License

© 2026 ERES Institute for New Age Cybernetics / Joseph A. Sprute.

Dual-licensed:

- **CCAL v2.1 (Cybernetic Commons Attribution License):** Governed under the specific terms of the ERES fiduciary commons.
- **CC-BY 4.0 (Creative Commons Attribution 4.0 International):** For academic citation, theoretical discussion, and non-commercial research.

---

*End of consolidated Truth Mechanism v1.0 + Round 3 Proof. This document is `[EARNED]` upon author ratification; until such ratification, it stands as `[VEILED]` for MIEVM Round 4 handoff purposes.*
