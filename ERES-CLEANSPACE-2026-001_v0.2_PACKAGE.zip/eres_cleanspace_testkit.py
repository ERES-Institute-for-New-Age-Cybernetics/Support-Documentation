#!/usr/bin/env python3
"""
eres_cleanspace_testkit.py  --  companion test suite for ERES-CLEANSPACE-2026-001 v0.2
"Clean Space: One Loop, Two Spaces, One Recycling Band (97/3-98/2)"

Standard library only. Deterministic (seed 20261019). Exit code = verdict:
0 = no FAIL (SKIPs allowed), 1 = at least one FAIL.

What this suite tests: the STRUCTURAL rules of the instrument (band edges, disposition
rules, no-unilateral-retirement, dependency guard, margin-law validity, stage gates,
offset-ledger asymmetry, three-principle gate, single decision rule across domains).
What it does NOT test: any real orbital outcome. T08 runs a synthetic toy population;
it shows the prioritization rule is coherent, not that it works in orbit. Load-bearing
SKIPs name the empirical work still owed.

License: CCAL v2.1 (DOI 10.5281/zenodo.23451312); CC-BY 4.0 compatible per CCAL s.12.
"""
from __future__ import annotations

import os
import random
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eres_cleanspace_manifest as M  # noqa: E402

SEED = 20261019
TESTS_SPEC_VERSION = (0, 2)
RESULTS = []

TRACEABILITY = {
    "T01": "Sec 3.1 Recycling band edges 97/3-98/2",
    "T02": "Sec 4.2 Exact copies collapse; not a retirement",
    "T03": "Sec 3.1 Held (VEILED) excluded from the ratio",
    "T04": "Sec 2.3 DOI'd versions never retired",
    "T05": "Sec 2.3 No unilateral disposition (author + validator)",
    "T06": "Sec 6 F3 dependency guard",
    "T07": "Sec 3.2 Margin law m* = v*tau sets which band edge holds",
    "T08": "Sec 6 F1 targeted vs random removal (toy population)",
    "T09": "Sec 6 F5 band verdict end-to-end on synthetic corpus",
    "T10": "Sec 5.4 Offset ledger: recycling earns credit, deorbit only clears",
    "T11": "Sec 2.4 Three governing principles = conjunctive gate",
    "T12": "Sec 4.4 Stage 1 exit gate = Stage 2 entry gate",
    "T13": "Sec 6 F4 one decision rule across both domains",
    "S1": "F1 on real catalogue data (ESA/USSPACECOM) -- OPEN",
    "S2": "F2 measured drift v and latency tau per orbital shell -- OPEN",
    "S3": "Stage 1 live inventory of the author's corpus -- OPEN",
    "S4": "MIEVM round 2: >=4 nodes, mean >=8.5 -- OPEN",
}


def record(tid, status, msg):
    RESULTS.append((tid, status, msg))


def check(tid, cond, msg):
    record(tid, "PASS" if cond else "FAIL", msg)


# ---------------------------------------------------------------------------
# helpers shared by both domains (F4: one rule, two adapters)
# ---------------------------------------------------------------------------
def dispose(item):
    """The single disposition rule. item: dict with keys
    in_service_value(bool), identified(bool), immutable(bool), retire_request(bool), validated(bool)."""
    if not item["identified"]:
        return M.HELD
    if item["immutable"]:
        return M.RECYCLABLE
    if item["retire_request"]:
        return M.RETIRED if item["validated"] else M.HELD
    return M.RECYCLABLE if item["in_service_value"] else M.HELD


def corpus_adapter(f):
    return {"in_service_value": f["latest"], "identified": f["id"] is not None,
            "immutable": f["doi"], "retire_request": f["retire"], "validated": f["validator"] is not None}


def orbit_adapter(o):
    return {"in_service_value": o["serviceable"], "identified": o["catalogued"],
            "immutable": False, "retire_request": o["deorbit_request"],
            "validated": o["registry_consent"]}


def margin_valid(v, tau, dK, reserve_share):
    """Margin law (GAIA grid App. B): a reserve share m holds iff v*tau <= m*dK."""
    return v * tau <= reserve_share * dK


def ledger(disposition, mass_t, deficit_t):
    """Offset ledger: returns (deficit_after, credit). Deorbit clears, recycling clears and earns."""
    if disposition == "deorbit":
        return max(0.0, deficit_t - mass_t), 0.0
    if disposition == "recycle":
        return max(0.0, deficit_t - mass_t), mass_t
    return deficit_t, 0.0


def three_principles(no_self_harm, no_other_harm, no_future_harm):
    return all((no_self_harm, no_other_harm, no_future_harm))


def stage2_entry(report, license_mismatches, f3_triggered):
    return (report["orphans_no_id"] == 0 and license_mismatches == 0 and not f3_triggered
            and report["band"].startswith("IN-BAND"))


def mkfile(d, name, content):
    p = os.path.join(d, name)
    with open(p, "wb") as f:
        f.write(content)
    return p


# ---------------------------------------------------------------------------
def t01():
    ok = (M.band_verdict(0.97).startswith("IN-BAND") and M.band_verdict(0.98).startswith("IN-BAND")
          and M.band_verdict(0.9699).startswith("LOWER") and M.band_verdict(0.9801).startswith("UPPER"))
    check("T01", ok, "band edges: 0.97 and 0.98 in; 0.9699 lower wall; 0.9801 upper wall")


def t02():
    with tempfile.TemporaryDirectory() as d:
        mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"A")
        os.mkdir(os.path.join(d, "mirror"))
        mkfile(os.path.join(d, "mirror"), "ERES-TEST-2026-001_v1.0 (copy).md", b"A")
        entries, rep = M.build([d])
    check("T02", rep["unique_items"] == 1 and rep["exact_copies_collapsed"] == 1
          and rep["dispositions"][M.RETIRED] == 0,
          "two identical files -> 1 unique item, 1 copy collapsed, 0 retirements")


def t03():
    with tempfile.TemporaryDirectory() as d:
        mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"old")
        mkfile(d, "ERES-TEST-2026-001_v2.0.md", b"new")
        mkfile(d, "notes.txt", b"unidentified")
        entries, rep = M.build([d])
    check("T03", rep["dispositions"][M.HELD] == 2 and rep["recovery_ratio"] == 1.0,
          "old draft + unidentified file Held; ratio counts resolved items only (1/1)")


def t04():
    with tempfile.TemporaryDirectory() as d:
        p = mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"deposited")
        mkfile(d, "ERES-TEST-2026-001_v2.0.md", b"newer")
        entries, _ = M.build([d], doi_ids=frozenset({"ERES-TEST-2026-001@1.0"}), retire={p: "Validator"})
    e = [x for x in entries if x.path == p][0]
    check("T04", e.disposition == M.RECYCLABLE, "DOI'd v1.0 listed for retirement stays Recyclable")


def t05():
    with tempfile.TemporaryDirectory() as d:
        a = mkfile(d, "ERES-AAA-2026-001_v1.0.md", b"a")
        b = mkfile(d, "ERES-BBB-2026-001_v1.0.md", b"b")
        entries, _ = M.build([d], retire={a: "", b: "Second Signer"})
    disp = {x.path: x.disposition for x in entries}
    check("T05", disp[a] == M.HELD and disp[b] == M.RETIRED,
          "retirement without validator -> Held; with validator -> Retired")


def t06():
    with tempfile.TemporaryDirectory() as d:
        old = mkfile(d, "ERES-ROOT-2026-001_v1.0.md", b"1")
        new = mkfile(d, "ERES-ROOT-2026-001_v2.0.md", b"2")
        deps = {"ERES-CHILD-2026-001": ["ERES-ROOT-2026-001"]}
        e1, _ = M.build([d], deps=deps, retire={old: "V"})
        e2, _ = M.build([d], deps=deps, retire={old: "V", new: "V"})
    d1 = {x.path: x.disposition for x in e1}
    d2 = {x.path: x.disposition for x in e2}
    check("T06", d1[old] == M.RETIRED and d1[new] == M.RECYCLABLE and d2[old] == M.HELD and d2[new] == M.HELD,
          "older copy of a needed root may retire; retiring its last live copy is blocked (Held)")


def t07():
    dK, tau = 1.0, 1.0
    a = margin_valid(0.02, tau, dK, 0.02) and not margin_valid(0.021, tau, dK, 0.02)
    b = margin_valid(0.03, tau, dK, 0.03) and not margin_valid(0.031, tau, dK, 0.03)
    c = margin_valid(0.025, tau, dK, 0.03) and not margin_valid(0.025, tau, dK, 0.02)
    check("T07", a and b and c,
          "98/2 holds iff v*tau <= 0.02*dK; 97/3 iff <= 0.03*dK; 0.025 needs the 97/3 edge; >0.03 fails both (F2)")


def t08():
    rng = random.Random(SEED)
    pop = []
    for _ in range(2000):
        mass = rng.lognormvariate(0, 1.2)
        density = rng.choice([0.2, 0.5, 1.0, 3.0])   # shell congestion factor
        pop.append((mass, mass * density))           # (mass, cascade-load proxy)
    total_load = sum(l for _, l in pop)
    budget = 0.05 * sum(m for m, _ in pop)

    def remove(order):
        spent = removed = 0.0
        for m, l in order:
            if spent + m > budget:
                continue
            spent += m
            removed += l
        return removed / total_load

    targeted = remove(sorted(pop, key=lambda x: -x[1] / x[0]))
    rand_runs = []
    for k in range(30):
        r = random.Random(SEED + k)
        o = pop[:]
        r.shuffle(o)
        rand_runs.append(remove(o))
    rmean = sum(rand_runs) / len(rand_runs)
    check("T08", targeted > max(rand_runs),
          f"toy: equal 5% mass budget removes {targeted:.1%} of load targeted vs {rmean:.1%} random "
          f"(max of 30 random runs {max(rand_runs):.1%}) -- synthetic only")


def t09():
    def corpus(n_retired):
        with tempfile.TemporaryDirectory() as d:
            paths = [mkfile(d, f"ERES-X{i:03d}-2026-001_v1.0.md", str(i).encode()) for i in range(100)]
            _, rep = M.build([d], retire={p: "V" for p in paths[:n_retired]})
        return rep
    r2, r4, r0 = corpus(2), corpus(4), corpus(0)
    check("T09", r2["band"].startswith("IN-BAND") and r4["band"].startswith("LOWER")
          and r0["band"].startswith("UPPER"),
          f"100 unique items: 2 retired -> {r2['recovery_ratio']} in-band; 4 -> {r4['recovery_ratio']} lower wall; "
          f"0 -> {r0['recovery_ratio']} upper wall")


def t10():
    d_after, c = ledger("deorbit", 3.0, 5.0)
    r_after, rc = ledger("recycle", 3.0, 5.0)
    check("T10", d_after == r_after == 2.0 and c == 0.0 and rc == 3.0,
          "same 3 t against a 5 t deficit: both clear to 2 t; only recycling earns 3 t credit")


def t11():
    ok = three_principles(True, True, True) and not three_principles(True, False, True) \
        and not three_principles(True, True, False)
    check("T11", ok, "an intervention that improves a metric but harms others or the future fails the gate")


def t12():
    good = {"orphans_no_id": 0, "band": "IN-BAND (97/3-98/2)"}
    ok = stage2_entry(good, 0, False) and not stage2_entry(good, 1, False) \
        and not stage2_entry(good, 0, True) \
        and not stage2_entry({"orphans_no_id": 0, "band": "UPPER-WALL"}, 0, False) \
        and not stage2_entry({"orphans_no_id": 3, "band": "IN-BAND"}, 0, False)
    check("T12", ok, "Stage 2 opens only on zero orphans, zero license mismatches, F3 clear, band in-band")


def t13():
    f = {"latest": True, "id": "ERES-A-2026-001", "doi": False, "retire": False, "validator": None}
    o = {"serviceable": True, "catalogued": True, "deorbit_request": False, "registry_consent": False}
    cases = [
        (dict(f), dict(o)),
        (dict(f, retire=True), dict(o, deorbit_request=True)),
        (dict(f, retire=True, validator="V"), dict(o, deorbit_request=True, registry_consent=True)),
        (dict(f, id=None), dict(o, catalogued=False)),
    ]
    same = all(dispose(corpus_adapter(a)) == dispose(orbit_adapter(b)) for a, b in cases)
    check("T13", same, "four paired cases give identical dispositions under one rule; only adapters differ")


def skips():
    for s in ("S1", "S2", "S3", "S4"):
        record(s, "SKIP", TRACEABILITY[s])


def main():
    for t in (t01, t02, t03, t04, t05, t06, t07, t08, t09, t10, t11, t12, t13):
        try:
            t()
        except Exception as ex:  # a crash is a FAIL, never a silent pass
            record(t.__name__.upper(), "FAIL", f"exception: {ex!r}")
    skips()
    print("ERES-CLEANSPACE-2026-001 v0.2 testkit  (spec %d.%d, seed %d)" % (*TESTS_SPEC_VERSION, SEED))
    print("-" * 78)
    for tid, st, msg in RESULTS:
        print(f"{tid:4} {st:5} {msg}")
    n = {k: sum(1 for _, s, _ in RESULTS if s == k) for k in ("PASS", "FAIL", "SKIP")}
    print("-" * 78)
    print(f"{n['PASS']} PASS / {n['FAIL']} FAIL / {n['SKIP']} SKIP  (SKIPs are load-bearing: empirical work owed)")
    print("Traceability:")
    for k, v in TRACEABILITY.items():
        print(f"  {k}: {v}")
    return 1 if n["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(main())
