# ERES-CLEANSPACE-2026-001 v0.2 — Package

**Clean Space: One Loop, Two Spaces, One Recycling Band**
Consolidating the ERES Corpus as Proof and Earth Orbit as Application, held to the ERES Recycling band 97/3–98/2.

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · 19 October 2026
Status: PROPOSED · MIEVM Round 1 folded (4 nodes, mean 7.39; SOUND not yet met) · License: CCAL v2.1 / CC-BY 4.0

## Contents

| File | What it is |
| --- | --- |
| `ERES-CLEANSPACE-2026-001_v0.2.md` | Master text (house WP format) |
| `ERES-CLEANSPACE-2026-001_v0.2.pdf` | Typeset companion with both figures |
| `ERES-CLEANSPACE-2026-001_v0.2_Fig1_Loop-and-Band.svg` | Figure 1: the loop and the 97/3–98/2 band |
| `ERES-CLEANSPACE-2026-001_v0.2_Fig2_One-Light-Two-Spaces.svg` | Figure 2: story image layout, "One Light, Two Spaces" |
| `eres_cleanspace_manifest.py` | Stage 1 inventory tool (read-only; hashes, dispositions, band verdict) |
| `eres_cleanspace_testkit.py` | Test suite: 13 PASS / 0 FAIL / 4 SKIP, exit 0 |
| `RUN_RECORD.txt` | Test output from the sealed package copy |
| `META_TEXT.md` | Deposit title, abstract, keywords, share messages |
| `CITATION.cff` | Citation metadata |
| `MANIFEST.json` | SHA-256 of every file in this package |

## Run

Python 3.9+, standard library only.

```
python3 eres_cleanspace_testkit.py                 # exit 0 = no FAIL
python3 eres_cleanspace_manifest.py PATH_TO_CORPUS --out my_manifest
python3 eres_cleanspace_manifest.py PATH --out m --doi doi_list.txt --deps deps.json --retire retire.txt
```

- `doi_list.txt`: one `INSTRUMENT-ID@version` per line that carries a DOI (never retired).
- `deps.json`: `{"ITEM": ["INSTRUMENT-ID", ...]}` registry dependencies (F3 guard).
- `retire.txt`: `path,validator` per line. A line with no validator stays Held.

The manifest tool never moves, renames or deletes files. It writes `<out>.json` and `<out>.csv`.

## The band in one line

Recovery ratio = Recyclable ÷ (Recyclable + Retired), Held excluded. In band: 0.97–0.98. Below 0.97 retires too much; above 0.98 retires too little. The same 2–3% is the Sentry return-to-base reserve; the margin law m* = v·τ decides which edge a domain can use.

## What the tests do and do not show

They check the instrument's structural rules. T08 runs a synthetic toy population and shows only that the removal-priority rule is coherent. The four SKIPs are the empirical work still owed: F1 on real catalogue data, F2 with measured v and τ, a live Stage 1 inventory, and MIEVM Round 2.

## Changes from v0.1

See Appendix B of the master text.
