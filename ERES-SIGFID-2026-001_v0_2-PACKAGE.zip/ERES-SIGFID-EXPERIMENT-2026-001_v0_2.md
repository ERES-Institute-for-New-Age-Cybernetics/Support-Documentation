# The Signature-Fidelity Experiment
### Testing the natural-measurement root of ERES certification — pre-registration protocol

**ID:** ERES-SIGFID-EXPERIMENT-2026-001 · **Version:** v0.2 PROPOSED (pre-canonical, not MIEVM-rated)
**Author:** Joseph A. Sprute, ERES Institute for New Age Cybernetics · **Date:** 6 Aug 2026
**License:** CCAL v2.1 / CC BY 4.0 · **Companion WP:** ERES-SIGFID-WP-2026-001 v0.2

---

## 0. What this tests — and what it does not

ERES certification terminates in the claim that the certifying authority is **"parallel in
Nature"**: a self carries a stable natural signature (bio-electric / resonant), legitimacy is
**found** not conferred, and recognition is **convergence** — independent measurers agreeing,
as with a physical constant. Everything above this rung (EarnedPath, GAIA benchmarks, UBIMIA
standing, HPE) inherits its legitimacy from it. The root reduces to one question:

> Does the signature reading track a **real, self-distinctive natural fact** that **survives
> confound control** and on which **independent instruments converge** — or is it a
> physiological/environmental **confound** or a per-instrument **projection**?

**In scope:** whether such a signal exists. **Out of scope:** what it *means* (merit, HPE,
values) — a separate construct-validity experiment, only after this one passes.

## 1. Hypotheses

- **H1:** after confound control, readings are reliable within a self, discriminate selves
  above a permutation null, and converge across two blind independent instruments.
- **H0:** apparent structure is fully explained by measured confounds, or is instrument-private.

## 2. Four nested gates (pre-registered thresholds — frozen before collection)

| Gate | Statistic | Pass rule |
|---|---|---|
| G1 reliability | mean per-dimension ICC(1,1) | ≥ 0.60 |
| G2 discriminability | LOSO nearest-centroid balanced accuracy, **train-fold z-standardized** | > permutation-97.5% and ≥ 0.15 |
| G3 confound-independence | G2 on **multivariate** confound-residualized features | > permutation-97.5% and ≥ 0.15 |
| G4 convergence | cross-operator Pearson r of per-self residual means | > shuffle-97.5% and ≥ 0.35 |

Report **bootstrap CI95** for G2 and G4. **G3 is the confound falsifier; G4 the projection
falsifier.**

## 3. Design

- **Subjects:** ≥ 24, pre-enrolled, no self-selection. Confirm power first (§8).
- **Sessions:** ≥ 6 per subject across ≥ 3 days; randomized order each session.
- **Operators/instruments:** ≥ 2, **hardware-independent** — different device unit, ideally
  different manufacturer or **modality**; isolated hardware chains; separate locations; blind
  to each other and to subject identity; **no cross-calibration**. (Shared device artifact can
  otherwise pass G4 falsely.)
- **Analyst blinding:** scripted, pre-registered analysis; labels revealed only after the gate
  vector is computed.

## 4. Confounds — measured every reading (multivariate G3 uses all of them)

Log per reading with instruments **independent of the signature device**: skin hydration/
conductance, contact pressure, contact area, skin temperature, ambient temp + humidity, supply
voltage/self-calibration, time-of-day, hours since caffeine/food/exercise, hours slept. CSV
columns `c1..cp`; the harness residualizes each feature on all of them jointly. Unmeasured
confounds cannot be partialled — enumerate and measure first.

## 5. Measurement standardization

Fixed finger/hand, cleaned contact, fixed acclimatization + capture duration, fixed posture,
identical settings across operators; deviations logged as covariates. Feature definition
`f1..fN` frozen before collection. Features are z-standardized inside the analysis using
**training-fold statistics only**.

## 6. Pre-registration, analysis, stopping

1. Freeze feature defn, thresholds, N, sessions, confound list, this document.
2. **Phase-0 public pre-registration:** deposit protocol + code + SHA-256 manifest to a
   public, timestamped registry (OSF / Zenodo / signed release) *before* collection, so
   thresholds cannot shift post-hoc.
3. Collect to CSV: `operator,sid,session,c1..cp,f1..fN`.
4. Run `signature_fidelity_harness.py --data readings.csv` → gate vector + CIs + verdict.
5. **Stopping rule:** no peeking at the gate vector mid-collection; analyze once at target N;
   report the full vector whatever it shows — a first-gate FAIL is a publishable result.

## 7. Falsifiers

- **F1 (G1):** ICC < 0.60 → not repeatable.
- **F2 (G2):** identification not above permutation null → no distinctive signal.
- **F3 (G3):** discriminability vanishes after **multivariate** confound partialling → the
  "signature" was the confound(s).
- **F4 (G4):** operators don't converge → instrument-private projection, not a natural fact.

## 8. Power (before enrolling)

Use the harness synthetic mode at your instrument's realistic effect size and noise (heavier
than the demo NOISE=0.6), sweeping subjects/sessions, until G2/G3 clear the permutation band at
your planned N. If they don't, the study is underpowered — do not collect.

## 9. Interpretation

| Vector | Reading |
|---|---|
| (T,T,T,T) | real, confound-independent, convergent natural fact — root earned; proceed to construct validity |
| (T,T,F,·) | stable confound (e.g. hydration) — fix instrument or claim |
| (T,T,T,F) | reliable & confound-clean per device but not shared — instrument-private projection |
| (F,·,·,·) | not repeatable — stop |

## 10. Ethics & honesty

Informed consent, IRB/ethics review, subject codes not names, data minimization. Passing
establishes **fidelity, not meaning**. A clean **fail** is as informative as a pass — it names
the exact rung the certification chain cannot yet stand on.

---

### Companion artifacts
`signature_fidelity_harness.py` (analysis + power + self-validation), `eres_sigfid_testkit.py`
(claim verification, 16 PASS / 0 FAIL / 4 SKIP), `run_report.py` (math driver), MANIFEST.json
(SHA-256). *ERES Institute for New Age Cybernetics · CCAL v2.1 / CC BY 4.0 · pre-canonical.*
