# ResearchGate Submission Block — ERES-SIGFID-2026-001 (Package v0.2)

## SEO Title
Signature Fidelity: A Falsifiable Four-Gate Protocol and Self-Validating Harness for Testing Bio-Electric Identity Signatures (ERES-SIGFID v0.2)

## Short Title
Signature Fidelity — Four-Gate Falsifiable Test (ERES-SIGFID v0.2)

## Abstract
Claims that a person carries a stable, distinctive bio-electric or resonant "signature" are
easy to assert and hard to test, because reliable-looking readings are routinely produced by
physiological and environmental confounds (skin hydration, contact pressure, temperature,
humidity) or by device-specific artifact. This package reduces the claim to a pre-registered,
falsifiable protocol with four nested gates — reliability (intraclass correlation),
discriminability (leave-one-session-out identification against a permutation null),
confound-independence (multivariate residualization of every feature on all measured
confounds), and inter-operator convergence (agreement between two blind, hardware-independent
instruments) — where the two ways the claim can be false are caught by two distinct gates. A
stdlib-only, deterministic analysis harness computes the gates with bootstrap confidence
intervals and, critically, **self-validates** on three synthetic worlds: it passes only if it
detects a true signature, fails a pure-confound world at the confound gate, and fails a
per-instrument-projection world at the convergence gate. A companion test instrument confirms
and falsifies each structural claim (16 pass / 0 fail / 4 skip). Results reported here are on
simulation: the package validates the **instrument of inference**, not any biological signal —
it converts an unfalsifiable assertion into a measurement ready to be falsified by independent
measurers. Included: protocol, whitepaper, harness, test instrument, math-report driver,
mapped simulation datasets, and a SHA-256 manifest.

## Keywords
bioelectric signature; biometric fidelity; identity verification; intraclass correlation;
permutation test; multivariate confound control; residualization; inter-rater convergence;
reproducible research; pre-registration; falsifiability; electrophotonic imaging; GDV;
measurement validity; New Age Cybernetics; ERES Institute; open science

## Disclosure
Pre-canonical (v0.2). MIEVM Round-1 (AI-reviewer panel: DeepSeek, ChatGPT, Qwen) folded —
reviewers, not endorsers. Empirical grounding is zero by design: no human subjects measured.
No third parties cited, implied, or associated. License CCAL v2.1 / CC BY 4.0.

## Suggested Citation
Sprute, J. A. (2026). *Signature Fidelity as the Natural-Measurement Root of ERES
Certification* (ERES-SIGFID-2026-001, Package v0.2). ERES Institute for New Age Cybernetics.
