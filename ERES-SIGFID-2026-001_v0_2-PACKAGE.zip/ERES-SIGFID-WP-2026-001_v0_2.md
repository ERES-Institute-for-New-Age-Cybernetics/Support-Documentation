# Signature Fidelity as the Natural-Measurement Root of ERES Certification

**ID:** ERES-SIGFID-WP-2026-001 · **Version:** v0.2 DRAFT (MIEVM Round-1 folded; structural only)
**Author:** Joseph A. Sprute, ERES Institute for New Age Cybernetics
**Companions:** ERES-SIGFID-EXPERIMENT-2026-001 v0.2 (protocol) · `signature_fidelity_harness.py` · `eres_sigfid_testkit.py` · `run_report.py`
**License:** CCAL v2.1 / CC BY 4.0 · **Date:** 6 Aug 2026

---

## Abstract

ERES certification grounds a self's standing in a **natural signature** (bio-electric /
resonant) rather than a conferred social status. This paper isolates the one empirical
claim that grounding rests on — *signature fidelity* — and reduces it to a falsifiable,
pre-registered test with four nested gates: reliability, discriminability,
confound-independence, and inter-operator convergence. On mapped simulation data the test
**discriminates**, returning distinct verdicts for a true signature (T,T,T,T), a stable
confound (T,T,F,F), and an instrument-private projection (T,T,T,F), with the two failure
modes caught at different gates. A companion test instrument confirms and falsifies every
structural claim (16 PASS / 0 FAIL / 4 SKIP). We state plainly what this does and does not
establish: it validates the **instrument of inference**, not the signature — no real
bio-measurement is claimed. The contribution is to convert an unfalsifiable root into one
ready to be falsified by measurers who share none of ERES's priors.

## 0. Version note — MIEVM Round-1 folded (structural only)

v0.2 incorporates the external review (§9): **multivariate** confound residualization (G3
now regresses each feature on *all* measured confounds jointly), **train-fold-only feature
standardization** in the identification step (no test leakage), and **bootstrap confidence
intervals** on the G2 accuracy and G4 convergence estimates. These are analysis-hardening
changes; **no empirical claim is added** and the grade is unchanged.

## 1. Motivation — where the argument terminates

A separate dialectic (KEEN-Basis, 6 Aug 2026) walked the ERES stack down through
propagation → instantiation → certification → legitimacy. Legitimacy is where a self-founded
authority meets the wall of adoption: you cannot self-certify your way to being others' root
of trust. The resolution moved the root from a **founded social authority** (needs adoption)
to one **"parallel in Nature"** (needs only measurement): a natural fact does not precede its
readers in time and is not conferred by assent — it is *found*, and recognition of it is
**convergence**, the way independent laboratories converge on a physical constant. That move
is sound as argument but hands the whole remaining weight to one thing: whether the instrument
**faithfully reads the natural fact**. This paper tests that.

## 2. Claim and hypotheses

- **H1 (fidelity):** After confound control, signature readings are reliable within a self,
  discriminate selves above a permutation null, and converge across two independent
  instruments blind to each other.
- **H0 (null):** Apparent structure is fully explained by measured confounds (hydration,
  contact pressure, temperature, humidity, placement) **or** is instrument-private
  (per-device reliable but non-convergent).

H0 is the historically dominant outcome for electrophotonic/bioelectric measurement.

### 2.1 Assumptions (made explicit, per review)

(a) The candidate natural fact, if it exists, is **stable** over the study window (days, not
minutes). (b) Confounds are **measurable** with instruments independent of the signature
device; unmeasured confounds cannot be partialled. (c) The signature→feature map is
approximately **stationary** across sessions. (d) Confound contamination is approximately
**linear/additive** in the measured confounds at first order (the multivariate residualizer's
model); strong non-linear confounding is a known residual risk, flagged in §6. (e) Operators
in G4 are **hardware-independent** (see §3).

## 3. Four nested gates

| Gate | Claim | Statistic | Pass rule |
|---|---|---|---|
| G1 | reliability | mean per-dimension ICC(1,1) | ≥ 0.60 |
| G2 | discriminability | leave-one-session-out nearest-centroid balanced accuracy (train-fold z-standardized) | > permutation-97.5% and ≥ 0.15 floor |
| G3 | confound-independence | G2 re-run on **multivariate** confound-residualized features | > permutation-97.5% and ≥ 0.15 |
| G4 | inter-operator convergence | cross-operator Pearson r of per-self residual means | > shuffle-97.5% and ≥ 0.35 |

The decisive property: **the two ways the claim can be false are caught by two different
gates.** A stable confound survives G1–G2 (reliable, discriminating) and dies at **G3** once
partialled; an instrument-private projection survives G1–G3 (reliable, discriminating,
confound-clean per device) and dies at **G4** when two blind instruments fail to converge.
Convergence is only *demonstrated* by operators that **could have diverged**, so instrument
independence and blinding are the test, not procedure.

### 3.1 Threshold justification (per review)

Significance is fixed by a label-permutation null (2.5% tail); the accuracy floor (0.15 ≈ 3×
chance at 24 subjects) and the convergence floor (r ≥ 0.35) are **effect-size guards** so
that a statistically-significant-but-trivial effect does not pass. G1 ICC ≥ 0.60 is the
conventional "good reliability" line. All thresholds are pre-registered and frozen before
collection; the protocol forbids post-hoc adjustment.

### 3.2 G4 independence (strengthened, per review)

Two operators using the same device model, firmware, electrode type, and calibration can pass
G4 on **shared systematic artifact**. A credible G4 therefore requires different device units,
ideally different manufacturer or **modality**, isolated hardware chains, separate locations,
and no cross-calibration.

## 4. Methods

The harness (`signature_fidelity_harness.py`, stdlib-only, deterministic) computes the gates
and includes a **design self-validation**: three synthetic worlds, passing only if it clears
the true-signature world, fails the confound world at G3, and fails the projection world at
G4 (verified across seeds). Mapped simulation: 24 subjects × 6 sessions × 2 operators × 8
features × 2 measured confounds; chance identification 0.0417.

## 5. Results (executed, v0.2)

| World | G1 ICC | G2 acc [CI95] | G3(MV) resid-acc [CI95] | G4 r [CI95] | Vector |
|---|---|---|---|---|---|
| Natural | 0.940 | 1.000 [1.00, 1.00] | 0.965 [0.92, 1.00] | 0.967 [0.95, 0.98] | (T,T,T,T) |
| Confound | 0.895 | 0.632 | **0.014** | −0.025 | (T,T,**F**,F) |
| Idiosyncratic | 0.940 | 1.000 | 0.965 | **0.060** | (T,T,T,**F**) |

**Worked math (natural, operator A).**
- **G1** f1: MS_between 20.492, MS_within 0.459, k 6, n 24 → ICC = (20.492 − 0.459)/(20.492 +
  5·0.459) = 0.879; mean over 8 dims = 0.940.
- **G2** balanced acc 1.000, CI95 [1.00, 1.00]; permutation null-hi 0.076.
- **G3 (multivariate)** f1 fit on both confounds: f1 ≈ 0.612 + 1.511·c1 + 0.519·c2;
  residualᵢ = f1ᵢ − fitted; acc on residuals 0.965, CI95 [0.92, 1.00].
- **G4** mean cross-operator r 0.967, CI95 [0.95, 0.98] vs shuffle null-hi 0.144.

The confound world reproduces the classic trap — raw discriminability 0.632 (well above the
null) *looks* like a signature — and only the **multivariate** residualization exposes it,
now collapsing to 0.014 as both confounds are removed. The idiosyncratic world is reliable and
confound-clean per operator (0.965) yet does not converge (r 0.060 < 0.159), separating
*shared reality* from *private reliability*.

## 6. Significance, evidence ladder, and failure modes

The finding is **structural, not substantive**: an apparatus now exists that returns a clean,
pre-registered verdict on real signature data and fails loudly in exactly the two ways the
natural-root claim can be false. Its honest limit is central: **simulation validates the
instrument of inference, not the signature.** No fingertip has been measured.

**Evidence ladder** (each rung strictly stronger): (0) argument that the root should be natural
→ (1) *this package*: a falsifiable design that self-validates on synthetic ground truth →
(2) single-instrument real pilot passing G1–G3 → (3) two-instrument real study passing G4 →
(4) multi-cohort replication → (5) construct validity (does the signal *mean* anything).
v0.2 sits at rung 1.

**Failure modes that real data will probe:** non-linear or unmeasured confounding (G3 model is
first-order); shared device artifact inflating G4 (§3.2); state confounds (caffeine, sleep,
time-of-day) if unlogged; feature drift across sessions; and small-N instability (mitigated by
the pre-registered power step).

## 7. Scope firewall — fidelity is not meaning

Passing all four gates shows a stable, self-distinctive, confound-independent, convergent
signal **exists**. It does **not** show what it *means* — that it tracks merit, HPE, character,
or value. Construct validity is a separate experiment, licensed only **after** G4 clears. The
inference code contains no meaning-claim vocabulary; the test instrument enforces this (T12).

## 8. Verification

`eres_sigfid_testkit.py` confirms and falsifies each structural claim, including v0.2's
multivariate residualization (T14), standardization scale-invariance (T15), and CI bracketing
(T16). Result: **16 PASS / 0 FAIL / 4 SKIP** (exit 0). The four SKIPs are the empirical claims
(E1 real test-retest, E2 real confound-partial, E3 real two-instrument convergence, E4
construct validity) — held as SKIP, never quietly passed.

## 9. MIEVM Round-1 and self-rating

**External Round-1 (v0.1 package):** DeepSeek 8.3; ChatGPT 9.5; Qwen "DILIGENCE-READY"
(epistemic 9.5 / design 9.0 / code 8.5, empirical 0.0 by design). External design mean ≈ 8.9
across 3 nodes; Claude 8.4 excluded author-side. 3 nodes < 4 ⇒ **SOUND-CANDIDATE** (not
canonized); clears the 8.5 diligence line, below the 9.0 canon gate; nothing empirically
derived ⇒ **not BEST**. Consensus finding folded into v0.2: multivariate G3, standardization,
CIs.

**Self-rate (author-side, single node — conflict noted).** As a design: composite ≈ 8.4 —
architectural coherence 9.0, epistemic discipline 9.4, provenance/reuse 8.8, novelty 6.5.
Binding caps: empirical 1.0 (all synthetic), artifact/reproducibility 9.2 (built, deterministic,
self-validates, testkit 16/0/4, review folds integrated). The spread — design ~8.4, reality
~1.0 — *is* the rating. Grade **GOOD / SOUND-candidate**. **Movers:** (1) real data on one
instrument — the only lever off the empirical floor; (2) a 4th–5th external node for SOUND
canonization; (3) a genuinely second instrument *modality* for a non-simulated G4.

## 10. Reproduction

```
python3 signature_fidelity_harness.py            # design self-validation (3 worlds)
python3 signature_fidelity_harness.py --ci       # with bootstrap CIs
python3 run_report.py                            # maps sim data, shows the math
python3 signature_fidelity_harness.py --data readings_natural.csv   # real-data mode
python3 eres_sigfid_testkit.py                   # 16 PASS / 0 FAIL / 4 SKIP
```

---

### Credits / References / License
ERES Institute for New Age Cybernetics. Derived from the 6 Aug 2026 KEEN-Basis dialectic.
Methods are standard and independently validated (intraclass correlation; leave-one-out
identification; permutation inference; multivariate confound residualization; inter-rater
convergence; bootstrap CIs). MIEVM Round-1 nodes are AI systems used as reviewers, not
endorsers. No third parties are cited, implied, or associated. Standing read; pre-canonical.
CCAL v2.1 / CC BY 4.0.
