#!/usr/bin/env python3
"""
ERES SIGNATURE-FIDELITY EXPERIMENT — analysis & power harness  (v0.2)
====================================================================

Tests the terminal claim of the parallel-in-Nature dialectic: that the
bio-electric / resonant signature is a stable, self-distinctive NATURAL fact
that independent measurers CONVERGE on after confound control (legitimacy by
convergence, not fiat).

Four NESTED gates (a higher gate counts only if all lower gates pass):
  G1 RELIABILITY        same self reads the same        (mean per-dim ICC)
  G2 DISCRIMINABILITY   readings identify the self       (LOSO nearest-centroid)
  G3 CONFOUND-INDEP.    survives MULTIVARIATE confound partialling
  G4 CONVERGENCE        two blind instruments agree      (cross-operator r)

v0.2 CHANGES (MIEVM Round-1, structural only — no real-data claims added):
  * G3 residualization is now MULTIVARIATE (regress features on ALL measured
    confound columns jointly), per DeepSeek/ChatGPT/Qwen. Univariate helper
    retained for the testkit.
  * LOSO identification z-scores features using TRAIN-fold statistics only
    (no test-fold leakage), per Qwen 1.2.
  * Bootstrap (subject-resampled) confidence intervals on G2 accuracy and G4 r,
    per Qwen 1.3 / ChatGPT.
Design self-validation across three synthetic worlds is unchanged in spirit and
still the gate of record. Pure stdlib, deterministic under --seed.
"""

import argparse, csv, math, random, statistics as st
from collections import defaultdict

# --------------------------------------------------------------------------
def mean(xs): return sum(xs) / len(xs)

def pearson(xs, ys):
    n = len(xs)
    if n < 2: return 0.0
    mx, my = mean(xs), mean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    return num / (dx * dy) if dx > 0 and dy > 0 else 0.0

def icc_one_way(by_subject):
    groups = [v for v in by_subject.values() if len(v) >= 2]
    if len(groups) < 2: return 0.0
    all_vals = [x for g in groups for x in g]
    grand = mean(all_vals)
    k = mean([len(g) for g in groups]); n = len(groups)
    ss_between = sum(len(g) * (mean(g) - grand) ** 2 for g in groups)
    ss_within = sum(sum((x - mean(g)) ** 2 for x in g) for g in groups)
    ms_b = ss_between / (n - 1)
    ms_w = ss_within / (len(all_vals) - n) if len(all_vals) > n else 1e-9
    denom = ms_b + (k - 1) * ms_w
    return (ms_b - ms_w) / denom if denom > 0 else 0.0

def mean_dimension_icc(readings):
    ncols = len(readings[0]["feat"]); iccs = []
    for j in range(ncols):
        by = defaultdict(list)
        for r in readings: by[r["sid"]].append(r["feat"][j])
        iccs.append(icc_one_way(by))
    return mean(iccs)

# ---- confound residualization --------------------------------------------
def ols_residualize(feature_vals, confound_vals):
    """UNIVARIATE regression (retained for testkit / single-confound CSVs)."""
    b = pearson(feature_vals, confound_vals)
    sd_f = st.pstdev(feature_vals) or 1e-9
    sd_c = st.pstdev(confound_vals) or 1e-9
    slope = b * sd_f / sd_c
    inter = mean(feature_vals) - slope * mean(confound_vals)
    return [f - (inter + slope * c) for f, c in zip(feature_vals, confound_vals)]

def _solve(A, b):
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(M[r][col]))
        if abs(M[piv][col]) < 1e-12: continue
        M[col], M[piv] = M[piv], M[col]
        pv = M[col][col]; M[col] = [v / pv for v in M[col]]
        for r in range(n):
            if r != col and M[r][col]:
                f = M[r][col]; M[r] = [a - f * bb for a, bb in zip(M[r], M[col])]
    return [M[i][n] for i in range(n)]

def multivariate_residualize(feature_vals, confound_matrix):
    """Regress one feature on ALL confound columns jointly (intercept + ridge nudge)."""
    p = len(confound_matrix[0]) if confound_matrix else 0
    if p == 0: return feature_vals[:]
    X = [[1.0] + list(row) for row in confound_matrix]
    dim = p + 1
    XtX = [[sum(X[r][i] * X[r][j] for r in range(len(X))) for j in range(dim)]
           for i in range(dim)]
    Xty = [sum(X[r][i] * feature_vals[r] for r in range(len(X))) for i in range(dim)]
    for i in range(dim): XtX[i][i] += 1e-6
    beta = _solve(XtX, Xty)
    fitted = [sum(beta[i] * X[r][i] for i in range(dim)) for r in range(len(X))]
    return [feature_vals[r] - fitted[r] for r in range(len(X))]

# ---- identification with train-fold-only standardization -----------------
def dist(a, b): return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

def _standardize(train, test):
    ncols = len(train[0]["feat"])
    mu = [mean([r["feat"][j] for r in train]) for j in range(ncols)]
    sd = [st.pstdev([r["feat"][j] for r in train]) or 1e-9 for j in range(ncols)]
    def z(r): return {**r, "feat": [(r["feat"][j] - mu[j]) / sd[j] for j in range(ncols)]}
    return [z(r) for r in train], [z(r) for r in test]

def loso_per_subject(readings):
    """Return {sid: accuracy} from leave-one-session-out nearest-centroid,
    with train-fold-only z-standardization."""
    sids = sorted({r["sid"] for r in readings})
    sessions = sorted({r["session"] for r in readings})
    per_subject = defaultdict(lambda: [0, 0])
    for held in sessions:
        train = [r for r in readings if r["session"] != held]
        test = [r for r in readings if r["session"] == held]
        if not train or not test: continue
        train, test = _standardize(train, test)
        centroids = {}
        for sid in sids:
            fs = [r["feat"] for r in train if r["sid"] == sid]
            if fs: centroids[sid] = [mean(col) for col in zip(*fs)]
        for r in test:
            if not centroids: continue
            pred = min(centroids, key=lambda s: dist(r["feat"], centroids[s]))
            c = per_subject[r["sid"]]; c[1] += 1
            if pred == r["sid"]: c[0] += 1
    return {s: c[0] / c[1] for s, c in per_subject.items() if c[1] > 0}

def loso_identification(readings):
    accs = list(loso_per_subject(readings).values())
    return mean(accs) if accs else 0.0

def permutation_chance(readings, n_perm=120, seed=0):
    rng = random.Random(seed)
    sids = [r["sid"] for r in readings]; accs = []
    for _ in range(n_perm):
        shuf = sids[:]; rng.shuffle(shuf)
        accs.append(loso_identification([{**r, "sid": s} for r, s in zip(readings, shuf)]))
    accs.sort()
    return mean(accs), accs[int(0.025 * len(accs))], accs[int(0.975 * len(accs))]

def bootstrap_ci_acc(readings, n_boot=2000, seed=0):
    """CI on balanced accuracy by resampling the per-subject accuracy vector.
    (Resampling subjects' *readings* would duplicate identities and bias an
    identification task downward — so we bootstrap the accuracy estimates.)"""
    per = list(loso_per_subject(readings).values())
    if not per: return (0.0, 0.0)
    rng = random.Random(seed); means = []
    for _ in range(n_boot):
        means.append(mean([rng.choice(per) for _ in per]))
    means.sort()
    return means[int(0.025 * len(means))], means[int(0.975 * len(means))]

# ---- gate evaluation ------------------------------------------------------
def _confounds(r): return r.get("confounds", [r.get("confound", 0.0)])

def evaluate_operator(readings, thresholds, seed=0, label="", ci=False):
    g1_icc = mean_dimension_icc(readings)
    acc = loso_identification(readings)
    _, _, chance_hi = permutation_chance(readings, seed=seed)
    g2_pass = acc > chance_hi and acc >= thresholds["ident_acc"]

    ncols = len(readings[0]["feat"])
    conf_mat = [_confounds(r) for r in readings]
    resid_cols = [multivariate_residualize([r["feat"][j] for r in readings], conf_mat)
                  for j in range(ncols)]
    resid_readings = [
        {"sid": r["sid"], "session": r["session"],
         "feat": [resid_cols[j][i] for j in range(ncols)], "confounds": conf_mat[i]}
        for i, r in enumerate(readings)]
    acc_resid = loso_identification(resid_readings)
    _, _, chance_hi_r = permutation_chance(resid_readings, seed=seed + 1)
    g3_pass = acc_resid > chance_hi_r and acc_resid >= thresholds["ident_acc_resid"]

    out = {"label": label,
           "g1_icc": g1_icc, "g1_pass": g1_icc >= thresholds["icc"],
           "g2_acc": acc, "g2_chance_hi": chance_hi, "g2_pass": g2_pass,
           "g3_acc_resid": acc_resid, "g3_chance_hi": chance_hi_r, "g3_pass": g3_pass,
           "resid_readings": resid_readings}
    if ci:
        out["g2_ci"] = bootstrap_ci_acc(readings, seed=seed + 2)
        out["g3_ci"] = bootstrap_ci_acc(resid_readings, seed=seed + 3)
    return out

def inter_operator_convergence(op1, op2, thresholds, seed=0, ci=False):
    sids = sorted({r["sid"] for r in op1["resid_readings"]})
    def subj_means(readings):
        m = {}
        for sid in sids:
            fs = [r["feat"] for r in readings if r["sid"] == sid]
            if fs: m[sid] = [mean(col) for col in zip(*fs)]
        return m
    m1, m2 = subj_means(op1["resid_readings"]), subj_means(op2["resid_readings"])
    common = [s for s in sids if s in m1 and s in m2]
    ncols = len(m1[common[0]])
    def conv_of(idx):
        rs = []
        for j in range(ncols):
            xs = [m1[common[i]][j] for i in idx]; ys = [m2[common[i]][j] for i in idx]
            rs.append(pearson(xs, ys))
        return mean(rs)
    conv = conv_of(range(len(common)))
    rng = random.Random(seed); null = []
    for _ in range(200):
        perm = common[:]; rng.shuffle(perm)
        m2p = {s: m2[p] for s, p in zip(common, perm)}
        null.append(mean([pearson([m1[s][j] for s in common], [m2p[s][j] for s in common])
                          for j in range(ncols)]))
    null.sort(); base_hi = null[int(0.975 * len(null))]
    res = {"convergence": conv, "baseline_hi": base_hi,
           "g4_pass": conv > base_hi and conv >= thresholds["convergence"]}
    if ci:
        boot = []
        for _ in range(200):
            idx = [rng.randrange(len(common)) for _ in common]; boot.append(conv_of(idx))
        boot.sort(); res["g4_ci"] = (boot[int(0.025 * len(boot))], boot[int(0.975 * len(boot))])
    return res

# ---- synthetic worlds (design self-validation) : TWO measured confounds ---
def make_world(kind, n_subjects=24, n_sessions=6, dim=8, seed=1):
    rng = random.Random(seed)
    latent = {s: [rng.gauss(0, 1) for _ in range(dim)] for s in range(n_subjects)}
    latent2 = {s: [rng.gauss(0, 1) for _ in range(dim)] for s in range(n_subjects)}
    hydration = {s: rng.gauss(0, 1) for s in range(n_subjects)}
    temp = {s: rng.gauss(0, 1) for s in range(n_subjects)}
    load_h = [abs(rng.gauss(0, 1)) + 0.5 for _ in range(dim)]
    load_t = [abs(rng.gauss(0, 1)) + 0.3 for _ in range(dim)]
    NOISE = 0.6
    def gen(operator):
        rows = []
        for s in range(n_subjects):
            for sess in range(n_sessions):
                c1 = hydration[s] + rng.gauss(0, 0.12)
                c2 = temp[s] + rng.gauss(0, 0.12)
                feat = []
                for j in range(dim):
                    v = NOISE * rng.gauss(0, 1)
                    v += 1.2 * c1 * load_h[j] + 1.0 * c2 * load_t[j]
                    if kind == "natural": v += 1.4 * latent[s][j]
                    elif kind == "confound": pass
                    elif kind == "idiosyncratic":
                        src = latent if operator == 1 else latent2
                        v += 1.4 * src[s][j]
                    feat.append(v)
                rows.append({"sid": s, "session": sess, "feat": feat,
                             "confounds": [c1, c2], "confound": c1})
        return rows
    return gen(1), gen(2)

TH = {"icc": 0.60, "ident_acc": 0.15, "ident_acc_resid": 0.15, "convergence": 0.35}
def yn(b): return "PASS" if b else "FAIL"

def run_world(kind, seed=1, verbose=True, ci=False):
    op1_raw, op2_raw = make_world(kind, seed=seed)
    chance = 1.0 / len({r["sid"] for r in op1_raw})
    o1 = evaluate_operator(op1_raw, TH, seed=seed, label="op1", ci=ci)
    o2 = evaluate_operator(op2_raw, TH, seed=seed + 7, label="op2")
    g4 = inter_operator_convergence(o1, o2, TH, seed=seed, ci=ci)
    if verbose:
        print(f"\n=== WORLD_{kind.upper()} (chance ident acc = {chance:.3f}) ===")
        c2 = f"  CI95[{o1['g2_ci'][0]:.3f},{o1['g2_ci'][1]:.3f}]" if ci else ""
        c4 = f"  CI95[{g4['g4_ci'][0]:.3f},{g4['g4_ci'][1]:.3f}]" if ci else ""
        print(f"  G1 reliability   ICC={o1['g1_icc']:.3f}                 [{yn(o1['g1_pass'])}]")
        print(f"  G2 discriminab.  acc={o1['g2_acc']:.3f}  chance_hi={o1['g2_chance_hi']:.3f}{c2} [{yn(o1['g2_pass'])}]")
        print(f"  G3 confound-indep(MV) acc={o1['g3_acc_resid']:.3f} chance_hi={o1['g3_chance_hi']:.3f} [{yn(o1['g3_pass'])}]")
        print(f"  G4 convergence   r={g4['convergence']:.3f}  base_hi={g4['baseline_hi']:.3f}{c4}  [{yn(g4['g4_pass'])}]")
    return (o1["g1_pass"], o1["g2_pass"], o1["g3_pass"], g4["g4_pass"])

EXPECTED = {"natural": (True, True, True, True),
            "confound": (True, True, False, False),
            "idiosyncratic": (True, True, True, False)}

def self_validate(seed=1, ci=False):
    print("SIGNATURE-FIDELITY DESIGN SELF-VALIDATION (v0.2: multivariate G3, standardized LOSO)")
    print("Thresholds:", TH)
    ok = True
    for kind, exp in EXPECTED.items():
        got = run_world(kind, seed=seed, ci=ci)
        m = (got == exp)
        print(f"  -> pattern {got}  expected {exp}  [{'OK' if m else 'MISMATCH'}]")
        ok = ok and m
    print("\nRESULT:", "PASS — design detects a real signature AND both fake modes"
          if ok else "FAIL — design does not discriminate; do NOT collect data yet")
    return ok

def load_csv(path):
    ops = defaultdict(list)
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            feat = [float(v) for k, v in row.items() if k.startswith("f") and k[1:].isdigit()]
            confs = [float(v) for k, v in row.items() if k.startswith("c") and k[1:].isdigit()]
            if not confs and "confound" in row: confs = [float(row["confound"])]
            ops[row["operator"]].append({"sid": row["sid"], "session": row["session"],
                                         "feat": feat, "confounds": confs,
                                         "confound": confs[0] if confs else 0.0})
    return ops

def run_real(path):
    ops = load_csv(path); keys = sorted(ops)
    print(f"Loaded operators: {keys}")
    evals = {k: evaluate_operator(ops[k], TH, label=k, ci=True) for k in keys}
    for k in keys:
        e = evals[k]
        print(f"\n[{k}] G1 ICC={e['g1_icc']:.3f}[{yn(e['g1_pass'])}] "
              f"G2 acc={e['g2_acc']:.3f} CI{e['g2_ci']} [{yn(e['g2_pass'])}] "
              f"G3(MV) resid={e['g3_acc_resid']:.3f}[{yn(e['g3_pass'])}]")
    if len(keys) >= 2:
        g4 = inter_operator_convergence(evals[keys[0]], evals[keys[1]], TH, ci=True)
        print(f"\nG4 convergence r={g4['convergence']:.3f} CI{g4['g4_ci']} "
              f"base_hi={g4['baseline_hi']:.3f} [{yn(g4['g4_pass'])}]")
        gates = (evals[keys[0]]["g1_pass"], evals[keys[0]]["g2_pass"],
                 evals[keys[0]]["g3_pass"], g4["g4_pass"])
        print("\nGATE VECTOR (G1,G2,G3,G4):", gates)
        print("VERDICT:", "SIGNATURE SUPPORTED — natural fact, convergent, confound-independent"
              if all(gates) else "SIGNATURE NOT SUPPORTED at this gate — see first FAIL above")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--ci", action="store_true")
    ap.add_argument("--data", type=str, default=None)
    a = ap.parse_args()
    if a.data: run_real(a.data)
    else: raise SystemExit(0 if self_validate(seed=a.seed, ci=a.ci) else 1)
