#!/usr/bin/env python3
"""Executes the v0.2 signature-fidelity core on mapped simulation data; shows the math."""
import csv, importlib.util, statistics as st
spec = importlib.util.spec_from_file_location("h", "signature_fidelity_harness.py")
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
N_SUBJ, N_SESS, DIM, SEED = 24, 6, 8, 1

def write_csv(kind, path):
    op1, op2 = h.make_world(kind, n_subjects=N_SUBJ, n_sessions=N_SESS, dim=DIM, seed=SEED)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["operator","sid","session","c1","c2"] + [f"f{i+1}" for i in range(DIM)])
        for opn, rows in [("A", op1), ("B", op2)]:
            for r in rows:
                w.writerow([opn, r["sid"], r["session"], f"{r['confounds'][0]:.5f}",
                            f"{r['confounds'][1]:.5f}"] + [f"{x:.5f}" for x in r["feat"]])
    return op1, op2

print("="*72)
print("MAPPED SIM DATA — %d subj x %d sess x 2 op x %d feat, 2 confounds (c1,c2); chance=%.4f"
      % (N_SUBJ, N_SESS, DIM, 1/N_SUBJ))
print("="*72)
W = {}
for kind in ("natural","confound","idiosyncratic"):
    W[kind] = write_csv(kind, f"readings_{kind}.csv")
    print(f"  wrote readings_{kind}.csv")

opA = W["natural"][0]
o1 = h.evaluate_operator(opA, h.TH, seed=1, ci=True)
o2 = h.evaluate_operator(W["natural"][1], h.TH, seed=8)
g4 = h.inter_operator_convergence(o1, o2, h.TH, seed=1, ci=True)
print("\nMATH — WORLD_NATURAL, operator A (v0.2: multivariate G3, standardized LOSO, bootstrap CI)")
# ICC dim f1
from collections import defaultdict
by = defaultdict(list)
for r in opA: by[r["sid"]].append(r["feat"][0])
g = list(by.values()); allv=[x for gg in g for x in gg]; grand=sum(allv)/len(allv)
k=sum(len(x) for x in g)/len(g); n=len(g)
ssb=sum(len(x)*(sum(x)/len(x)-grand)**2 for x in g); ssw=sum(sum((v-sum(x)/len(x))**2 for v in x) for x in g)
msb=ssb/(n-1); msw=ssw/(len(allv)-n); icc=(msb-msw)/(msb+(k-1)*msw)
print(f"  G1  ICC f1 = (MSb-MSw)/(MSb+(k-1)MSw) = ({msb:.3f}-{msw:.3f})/({msb:.3f}+{k-1:.0f}*{msw:.3f}) = {icc:.3f}")
print(f"      mean per-dim ICC = {o1['g1_icc']:.3f}")
print(f"  G2  balanced acc = {o1['g2_acc']:.3f}  CI95={o1['g2_ci']}  perm-null-hi={o1['g2_chance_hi']:.3f}")
# multivariate residual: show beta on f1 vs [c1,c2]
conf=[r["confounds"] for r in opA]; f1=[r["feat"][0] for r in opA]
X=[[1.0]+c for c in conf]; dim=3
XtX=[[sum(X[r][i]*X[r][j] for r in range(len(X))) for j in range(dim)] for i in range(dim)]
Xty=[sum(X[r][i]*f1[r] for r in range(len(X))) for i in range(dim)]
for i in range(dim): XtX[i][i]+=1e-6
beta=h._solve(XtX,Xty)
print(f"  G3  multivariate fit f1 ~ 1 + c1 + c2 : beta = [{beta[0]:.3f}, {beta[1]:.3f}, {beta[2]:.3f}]")
print(f"      resid_i = f1_i - (b0 + b1*c1_i + b2*c2_i);  acc on residuals = {o1['g3_acc_resid']:.3f}  CI95={o1['g3_ci']}")
print(f"  G4  mean cross-op r = {g4['convergence']:.3f}  CI95={g4['g4_ci']}  shuffle-null-hi={g4['baseline_hi']:.3f}")

print("\nFALSIFIERS (multivariate G3 now removes BOTH confounds):")
oC=h.evaluate_operator(W["confound"][0], h.TH, seed=1)
print(f"  CONFOUND world:      G2 acc {oC['g2_acc']:.3f} -> G3(MV) resid {oC['g3_acc_resid']:.3f} (null-hi {oC['g3_chance_hi']:.3f})  => G3 FAIL")
oI1=h.evaluate_operator(W["idiosyncratic"][0], h.TH, seed=1); oI2=h.evaluate_operator(W["idiosyncratic"][1], h.TH, seed=8)
g4i=h.inter_operator_convergence(oI1,oI2,h.TH,seed=1)
print(f"  IDIOSYNCRATIC world: G3(MV) resid {oI1['g3_acc_resid']:.3f} clean -> G4 r {g4i['convergence']:.3f} (null-hi {g4i['baseline_hi']:.3f})  => G4 FAIL")
