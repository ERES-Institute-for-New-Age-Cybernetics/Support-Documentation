# RT / Social Share Message — ERES-SIGFID Package v0.2

**Post (long):**
ERES-SIGFID v0.2 — the natural-measurement root, made falsifiable.

If a "self-signature" is real, it must (1) repeat, (2) tell selves apart, (3) survive
confound control, and (4) make two blind instruments agree. Four gates. Two of them exist
only to KILL the claim if it's fake — a confound dies at gate 3, a device artifact dies at
gate 4.

The harness self-validates: it passes a real signal, fails a pure-confound world, fails a
private-projection world. Testkit: 16 PASS / 0 FAIL / 4 SKIP. The 4 SKIPs are the real
fingertips — not yet measured. This proves the TEST, not the signature.

Legitimacy that is *found*, not *conferred* = convergence you can run. Package: protocol +
WP + harness + test instrument + data + SHA-256.
[RG link]  #ERES #PlayNAC #OpenScience #NewAgeCybernetics

**Post (short / index-key):**
ERES-SIGFID v0.2: four gates, two are falsifiers. Confound dies at G3, artifact dies at G4.
Harness self-validates; testkit 16/0/4. Validates the test, not the signature — real
fingertips still un-run. Found, not conferred. [RG link] #ERES #OpenScience
