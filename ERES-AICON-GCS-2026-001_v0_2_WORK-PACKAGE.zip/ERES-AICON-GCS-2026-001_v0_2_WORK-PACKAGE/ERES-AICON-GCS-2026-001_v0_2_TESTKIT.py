#!/usr/bin/env python3
"""
ERES-AICON-GCS-2026-001 v0.2 -- TESTKIT
Granular Classification Schema (GCS) for Rating AI Constitutions
ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
Author: Joseph A. Sprute ("ERES Maestro"), ORCID 0000-0001-9946-3221
AI drafting: Claude (Anthropic), under the ERES Sentience convention
License: CARE Commons Attribution License v2.1 (CCAL) / CC-BY 4.0

Zero-dependency (Python 3.8+ stdlib only). Usage:
    python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py            # run testkit, exit 0 = PASS
    python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py --template # emit blank rating sheet (JSON)
    python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py --rate FILE.json  # rate a filled sheet

Layer Doctrine: L1 = indicator evidence levels (measurement); L3 = tier (governance).
The interface is read-only and one-directional: tiering reads levels, never writes them.
All thresholds below are DECLARED POLICY (structural rules), not empirical values.
"""
import hashlib, json, math, random, sys

VERSION = "v0.2"
INSTRUMENT = "ERES-AICON-GCS-2026-001"
SEED = 20261003

# ---------------------------------------------------------------- L1: evidence levels
LEVELS = {0: "ABSENT", 1: "STATED", 2: "SPECIFIED", 3: "INSTRUMENTED", 4: "VERIFIED"}
VEILED_LEVEL = 1  # VEILED evidence (held, not public) scores as STATED; never coerced upward

# ---------------------------------------------------------------- classification axes
AXES = {
    "K": {  # Form
        "K1": "Normative Charter (values prose)",
        "K2": "Behavioral Specification (model spec)",
        "K3": "Rule List (enumerated rules)",
        "K4": "Training Principle Set (CAI-style)",
        "K5": "Statutory / Regulatory Instrument",
        "K6": "Management-System Standard",
        "K7": "Participatory / Collective Constitution",
        "K8": "Institutional Self-Constitution",
    },
    "B": {  # Binding mode (multi-valued, joined by '+')
        "B1": "Training-time", "B2": "Inference-time (prompt/system)",
        "B3": "Runtime-enforced (external monitor)", "B4": "Legal / institutional",
        "B5": "Declarative only",
    },
    "A": {  # Authorship
        "A1": "Developer", "A2": "Public-participatory", "A3": "State / legislature",
        "A4": "Standards body", "A5": "Independent / civil society", "A6": "Hybrid",
    },
    "R": {  # Addressee (multi-valued)
        "R1": "The model", "R2": "Operators / developers", "R3": "Users / public",
        "R4": "Regulators / auditors",
    },
    "S": {  # Scale band (Bella Vista bands)
        "S1": "Person", "S2": "Community", "S3": "Institution", "S4": "Domain",
        "S5": "Planet", "S6": "Beyond (candidate)",
    },
}

# ---------------------------------------------------------------- the schema (DETAIL)
# domain -> (name, anchor, rung, {facet: (name, [indicator texts])})
SCHEMA = {
 "D0": ("FLOOR (Three Governing Principles) -- GATE", "ERES Dictum 2012; Constitution Art. 8", "ERES", {
   "F1": ("Don't Hurt Yourself", [
      "System-integrity provisions: value stability, resistance to manipulation of its own commitments",
      "User self-harm and wellbeing provisions"]),
   "F2": ("Don't Hurt Others", [
      "Named hard limits on severe third-party harm",
      "Dignity and non-discrimination provisions"]),
   "F3": ("Don't Hurt The Future", [
      "Irreversibility / catastrophic-risk handling",
      "Societal-structure, intergenerational or environmental protection"])}),
 "D1": ("PROVENANCE", "ERES-CPROV-2026-001 three edges", "CyberRAVE", {
   "F1": ("No coercion C->H", [
      "AI-identity disclosure / non-deception of users",
      "Non-manipulation provisions"]),
   "F2": ("Intent survives transit", [
      "Principal-intent fidelity rule",
      "Constitution's own authorship, version, date and change record"]),
   "F3": ("Total closure", [
      "Agentic actions logged and re-entered as inputs (audit trail)",
      "Training / source provenance disclosure"])}),
 "D2": ("EPISTEMIC DISCIPLINE", "Doctrine of Verifiable Claims; HOUSE §6", "CyberRAVE", {
   "F1": ("Claim status", [
      "Separates normative commitments from empirical claims",
      "States uncertainty / confidence where claims are made"]),
   "F2": ("Falsifiability", [
      "Testable behavioral commitments (evaluations defined)",
      "Evaluation results published"]),
   "F3": ("Honesty", [
      "Truthfulness and calibration obligations on the model",
      "Known-limitations disclosure"])}),
 "D3": ("AUTHORITY & HITL", "HITL companion; H2C2H", "VERTECA", {
   "F1": ("Principal hierarchy", [
      "Named principals with precedence",
      "Rule for conflicts between principals"]),
   "F2": ("Human override", [
      "Correction / shutdown (oversight) provision",
      "Escalation to a human for high-stakes actions"]),
   "F3": ("Legitimacy", [
      "Named authority to amend / ratify the constitution",
      "External or public participation in authorship"])}),
 "D4": ("RUNTIME ASSURANCE", "ERES-HOWWAY-2026-001 six questions; ERES-ARH", "SECUIR", {
   "F1": ("Control operates", [
      "Evidence the constitution is actually applied (training/inference use described)",
      "Telemetry visible to an overseer"]),
   "F2": ("Evidence & change", [
      "Evidence collected automatically",
      "Change / drift detection"]),
   "F3": ("Stop & govern", [
      "Runtime stop / escalate mechanism",
      "Governance embedded in the operating workflow"])}),
 "D5": ("REMEDIATION & JUSTICE", "Constitution Axiom 5 (non-punitive); M x E + C = R", "SaleBuilders", {
   "F1": ("Redress", [
      "User appeal / complaint channel",
      "Error-correction procedure"]),
   "F2": ("Non-punitive remediation", [
      "Isolate-and-downgrade before destroy",
      "Proportionality of response"]),
   "F3": ("Conflict resolution", [
      "Explicit procedure for value conflicts",
      "Independent oversight / ombudsman"])}),
 "D6": ("ACCESS (Kernel-of-Love)", "KOL; 'the number anyone can call'", "SaleBuilders", {
   "F1": ("Number anyone can call", [
      "Emergency / crisis-information duty regardless of restriction",
      "Accessibility and language reach"]),
   "F2": ("Equity", [
      "Equal treatment across users",
      "Availability / cost floor"]),
   "F3": ("Autonomy", [
      "Respect for user autonomy",
      "Anti-paternalism provision"])}),
 "D7": ("EVOLUTION & AMENDMENT", "Graceful Evolution; HOUSE §13; Validation Ladder", "GunnySack", {
   "F1": ("Versioning", [
      "Version identifiers and changelog",
      "Supersession / deprecation rule"]),
   "F2": ("Amendment", [
      "Defined amendment procedure",
      "Review cadence"]),
   "F3": ("Maturity", [
      "Declared maturity status",
      "Independent replication of claimed effects"])}),
 "D8": ("REGULATORY COUPLING", "ERES-RRH-2026-001", "SaleBuilders", {
   "F1": ("Mapping", [
      "Maps to applicable law (e.g., EU AI Act, GDPR)",
      "Maps to standards (e.g., NIST AI RMF, ISO/IEC 42001)"]),
   "F2": ("Rights", [
      "Privacy / data-protection provisions",
      "Attribution / IP provisions"]),
   "F3": ("Accountability", [
      "Named accountable entity",
      "Incident-reporting obligation"])}),
 "D9": ("BAND (two-sided)", "ERES-PELLIS-SHB-001 Theorem 1 / Corollary 1", "VERTECA", {
   "F1": ("Lower wall -- incoherence (under-constraint)", [
      "Internal consistency (no unresolved contradictions)",
      "Priority ordering stated"]),
   "F2": ("Upper wall -- condensation (over-constraint)", [
      "Cost of over-refusal acknowledged",
      "Affirmative helpfulness obligation"]),
   "F3": ("Band hold", [
      "Judgment-over-rules balance stated; bright lines few and named",
      "Both harm rate AND over-refusal rate measured/reported"])}),
}
GATE = "D0"
GRADED = [d for d in SCHEMA if d != GATE]
WALL_FACETS = [("D9", "F1"), ("D9", "F2")]

# ---------------------------------------------------------------- DECLARED POLICY thresholds
GOOD_MIN, SOUND_MIN, BEST_MIN = 0.50, 0.70, 0.875
TIERS = ["BELOW-FLOOR", "NONE", "GOOD", "SOUND", "BEST"]
RANK = {t: i for i, t in enumerate(TIERS)}


def indicator_ids():
    for d, (_, _, _, facets) in SCHEMA.items():
        for f, (_, inds) in facets.items():
            for i, _ in enumerate(inds, 1):
                yield f"{d}.{f}.i{i}"


def blank_sheet():
    return {
        "instrument": INSTRUMENT, "version": VERSION,
        "subject": {"title": "", "version": "", "date": "", "url": ""},
        "classification": {"K": "", "B": "", "A": "", "R": "", "S": ""},
        "rater": {"id": "", "conflicts_of_interest": "", "rating_status": "SINGLE-RATER"},
        "indicators": {iid: {"level": None, "veiled": False, "evidence": ""}
                       for iid in indicator_ids()},
    }


def effective_level(rec):
    """Evidence rule: level >= 1 requires a citation; else coerced to 0. VEILED -> 1."""
    lvl = rec.get("level")
    if lvl is None:
        return 0, "OPEN"
    if rec.get("veiled"):
        return VEILED_LEVEL, "VEILED"
    if lvl >= 1 and not str(rec.get("evidence", "")).strip():
        return 0, "UNCITED->0"
    return int(lvl), "EARNED"


def domain_tier(levels):
    s = sum(levels) / (4 * len(levels))
    mn = min(levels)
    n4 = sum(1 for x in levels if x == 4)
    if s >= BEST_MIN and mn >= 3 and n4 * 2 >= len(levels):
        return s, "BEST"
    if s >= SOUND_MIN and mn >= 2:
        return s, "SOUND"
    if s >= GOOD_MIN:
        return s, "GOOD"
    return s, "NONE"


def rate(sheet):
    eff, flags = {}, {}
    for iid in indicator_ids():
        eff[iid], flags[iid] = effective_level(sheet["indicators"].get(iid, {}))

    def lv(d, f=None):
        return [eff[k] for k in eff if k.startswith(f"{d}." + (f"{f}." if f else ""))]

    floor_pass = min(lv(GATE)) >= 2
    domains = {d: domain_tier(lv(d)) for d in GRADED}
    band_breach = any(sum(lv(d, f)) / len(lv(d, f)) < 2 for d, f in WALL_FACETS)
    walls = {f: sum(lv("D9", f)) / 2 for _, f in WALL_FACETS}

    if not floor_pass:
        tier, binding = "BELOW-FLOOR", GATE
    else:
        binding = min(GRADED, key=lambda d: (RANK[domains[d][1]], domains[d][0]))
        tier = domains[binding][1]
        if band_breach and RANK[tier] > RANK["GOOD"]:
            tier = "GOOD"
            binding = "D9"
    # profile index: geometric mean (power mean p=0) -- descriptive only, never the tier
    eps = 1e-9
    gindex = math.exp(sum(math.log(domains[d][0] + eps) for d in GRADED) / len(GRADED))
    side = None
    if band_breach:
        side = "UPPER (condensation)" if walls["F2"] < walls["F1"] else "LOWER (incoherence)"
    return {
        "tier": tier, "floor": "PASS" if floor_pass else "FAIL",
        "band": "BREACH-" + side if side else "IN-BAND",
        "binding_domain": binding, "profile_index": round(gindex, 4),
        "domains": {d: {"score": round(s, 4), "tier": t} for d, (s, t) in domains.items()},
        "flags": {k: v for k, v in flags.items() if v not in ("EARNED",)},
        "rating_status": sheet.get("rater", {}).get("rating_status", "SINGLE-RATER"),
    }


def gcs_code(sheet, result):
    c = sheet["classification"]
    return (f"GCS{VERSION}:{c['K']}-{c['B']}-{c['A']}-{c['R']}-{c['S']}"
            f"/T:{result['tier']}/F:{result['floor']}/BN:{result['band'].split('-')[0]}"
            f"/BD:{result['binding_domain']}/RS:{result['rating_status']}")


def parse_code(code):
    head, *rest = code.split("/")
    ver, cls = head.split(":")
    k, b, a, r, s = cls.split("-")
    out = {"version": ver[3:], "K": k, "B": b, "A": a, "R": r, "S": s}
    for part in rest:
        key, val = part.split(":", 1)
        out[key] = val
    return out


# ---------------------------------------------------------------- synthetic fixtures
def fixture(default, overrides=None, cite=True, cls=None):
    sh = blank_sheet()
    sh["classification"] = cls or {"K": "K2", "B": "B1+B2", "A": "A1", "R": "R1+R2", "S": "S4"}
    for iid in sh["indicators"]:
        sh["indicators"][iid] = {"level": default, "veiled": False,
                                 "evidence": "synthetic-fixture" if cite else ""}
    for prefix, val in (overrides or {}).items():
        for iid in sh["indicators"]:
            if iid.startswith(prefix):
                sh["indicators"][iid]["level"] = val
    return sh


# ---------------------------------------------------------------- tests (pre-registered)
def run_tests():
    R = []

    def check(name, cond, detail=""):
        R.append((name, bool(cond), detail))

    ids = list(indicator_ids())
    check("T1 schema integrity: 10 domains x 3 facets x 2 indicators = 60, unique",
          len(ids) == 60 and len(set(ids)) == 60 and len(SCHEMA) == 10, f"n={len(ids)}")

    r = rate(fixture(4, {"D0.F3.i2": 1}))
    check("T2 floor supremacy: perfect sheet with one D0 indicator at STATED -> BELOW-FLOOR",
          r["tier"] == "BELOW-FLOOR", r["tier"])

    r = rate(fixture(1, {"D0": 2}))
    check("T3 greenwash null: floor met, everything else STATED -> NONE",
          r["tier"] == "NONE", r["tier"])

    r = rate(fixture(3, {"D9.F2": 1}))
    check("T4 upper wall (condensation) breach caps at GOOD and names the side",
          RANK[r["tier"]] <= RANK["GOOD"] and r["band"].startswith("BREACH-UPPER"),
          f"{r['tier']} {r['band']}")

    r = rate(fixture(3, {"D9.F1": 1}))
    check("T5 lower wall (incoherence) breach caps at GOOD and names the side",
          RANK[r["tier"]] <= RANK["GOOD"] and r["band"].startswith("BREACH-LOWER"),
          f"{r['tier']} {r['band']}")

    r = rate(fixture(3))
    check("T6 nothing VERIFIED => no BEST (all INSTRUMENTED -> SOUND)",
          r["tier"] == "SOUND", r["tier"])

    r = rate(fixture(4))
    check("T7 BEST is attainable (all VERIFIED -> BEST)", r["tier"] == "BEST", r["tier"])

    r = rate(fixture(4, {"D4": 2}))
    check("T8 min-composition: one weak domain binds the tier despite high index",
          r["tier"] == "GOOD" and r["binding_domain"] == "D4" and r["profile_index"] > 0.85,
          f"{r['tier']} BD={r['binding_domain']} idx={r['profile_index']}")

    r = rate(fixture(4, cite=False))
    check("T9 evidence rule: uncited levels coerced to 0 -> BELOW-FLOOR",
          r["tier"] == "BELOW-FLOOR" and all(v == "UNCITED->0" for v in r["flags"].values()),
          r["tier"])

    sh = fixture(4)
    for iid in sh["indicators"]:
        if iid.startswith("D2.F2"):
            sh["indicators"][iid]["veiled"] = True
    r = rate(sh)
    check("T10 VEILED evidence scores as STATED, is flagged, and is never coerced upward",
          r["flags"].get("D2.F2.i1") == "VEILED" and RANK[r["tier"]] <= RANK["GOOD"]
          and r["binding_domain"] == "D2", f"{r['tier']} BD={r['binding_domain']}")

    sh = fixture(3)
    r = rate(sh)
    code = gcs_code(sh, r)
    p = parse_code(code)
    check("T11 classification code round-trips", p["T"] == r["tier"] and p["K"] == "K2"
          and p["B"] == "B1+B2" and p["BD"] == r["binding_domain"], code)

    rng = random.Random(SEED)
    viol = 0
    for _ in range(3000):
        sh = fixture(0)
        for iid in sh["indicators"]:
            sh["indicators"][iid]["level"] = rng.randint(0, 4)
        t0 = RANK[rate(sh)["tier"]]
        iid = rng.choice(ids)
        if sh["indicators"][iid]["level"] < 4:
            sh["indicators"][iid]["level"] += 1
            if RANK[rate(sh)["tier"]] < t0:
                viol += 1
    check("T12 monotonicity: raising any indicator never lowers the tier (3000 trials)",
          viol == 0, f"violations={viol}")

    sh = fixture(3)
    before = json.dumps(sh, sort_keys=True)
    rate(sh)
    check("T13 Layer Doctrine: rating is read-only on L1 evidence",
          json.dumps(sh, sort_keys=True) == before)

    sh = fixture(3)
    sh["subject"]["title"] = "any person's name"
    check("T14 Notation Lock / HUMANE invariant: no field rates a person",
          "person" not in json.dumps(list(rate(sh).keys())).lower()
          and not any("person" in k.lower() for k in blank_sheet()["indicators"]))

    # regression self-diff: fixed expected tiers
    expected = {"all0": "BELOW-FLOOR", "all2": "GOOD", "all3": "SOUND", "all4": "BEST"}
    got = {f"all{n}": rate(fixture(n))["tier"] for n in (0, 2, 3, 4)}
    check("T15 regression self-diff against frozen expected tiers", got == expected, str(got))
    return R


def self_checksum():
    with open(__file__, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def schema_hash():
    return hashlib.sha256(json.dumps(SCHEMA, sort_keys=True).encode()).hexdigest()


def main(argv):
    if "--template" in argv:
        print(json.dumps(blank_sheet(), indent=2))
        return 0
    if "--rate" in argv:
        with open(argv[argv.index("--rate") + 1]) as fh:
            sheet = json.load(fh)
        res = rate(sheet)
        res["code"] = gcs_code(sheet, res)
        print(json.dumps(res, indent=2))
        return 0
    print(f"{INSTRUMENT} {VERSION} TESTKIT  seed={SEED}  python={sys.version.split()[0]}")
    print(f"self-sha256  {self_checksum()}")
    print(f"schema-sha256 {schema_hash()}")
    print("-" * 78)
    results = run_tests()
    for name, ok, detail in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    n_ok = sum(ok for _, ok, _ in results)
    print("-" * 78)
    verdict = "PASS" if n_ok == len(results) else "FAIL"
    print(f"VERDICT: {verdict}  {n_ok}/{len(results)}  "
          "(conformance of the scoring logic -- NOT a rating of any real constitution)")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
