# A Granular Classification Schema for Rating AI Constitutions

**Instrument:** ERES-AICON-GCS-2026-001
**Version:** v0.2 · **Status:** DRAFT. Conforms to HOUSE format v0.4. Below the 9.0 external gate. The MIEVM ensemble round is the gate condition and has not been run.
**Role:** Specification and executable rating instrument. It classifies any AI constitution on five descriptive axes. It then rates the constitution on 60 evidence-graded indicators, grouped into a three-principle Floor gate plus nine graded domains, and returns a BEST / SOUND / GOOD tier.
**For:** AI developers, regulators, auditors, standards bodies, Communities of Interest (COI), and any system that ingests the ERES corpus.
**From:** Joseph A. Sprute ("ERES Maestro"), Founder & Director, ERES Institute for New Age Cybernetics (Think Tank for New Age Cybernetics), Bella Vista, Arkansas · ORCID 0000-0001-9946-3221
**Date:** 3 October 2026 (v0.1 and v0.2)
**Provenance:** The FOUNDATION is the ERES Institute corpus. It draws on the Three Governing Principles (ERES Dictum, 4 Feb 2012); the *Constitutional Foundation for the Empirical Realtime Education System* (ERES Constitution 2026 DRAFT, v0.1); ERES-CPROV-2026-001 (three provenance edges); ERES-HOWWAY-2026-001 (six runtime-assurance questions); ERES-ARH-2026-001 and ERES-RRH-2026-001 (adversarial and regulatory root hardening); ERES-PELLIS-SHB-001 *Sound Holds the Band* (two-sided band); ERES-SOUND-STANDARD-2026-001 (BEST/SOUND/GOOD with min-composition); the Floor Register; and the Bella Vista Declaration scale bands S1–S6. It is shaped to ERES-HOUSE-FORMAT-2026-001 v0.4.
**Changelog (v0.1 → v0.2):**
- Added **§6.6 INGEST**, a machine-draft evidence reader. It reads any AI-constitution text (.txt, .md, .html, .pdf) and pre-fills a draft rating sheet with verbatim candidate quotes, their locations, and suggested levels for each of the 60 indicators.
- Added the **MACHINE-DRAFT** rating status (§7).
- Added ingest non-claims (§8) and ingest self-tests I1–I11 (§10).
- Added SEO and deposit metadata to META.
- No INVARIANT touched; scoring logic unchanged (testkit still 15/15). This is a DETAIL-only fill-in. v0.1 is marked SUPERSEDED.

---

## Abstract

AI constitutions now appear in at least eight forms: developer charters, behavioral specifications, rule lists, training principle sets, statutes, management-system standards, participatory constitutions, and institutional self-constitutions. There is no common way to compare them. This instrument supplies one, in two layers that are kept apart.

The first layer is a **classification code** on five descriptive axes: Form K1–K8, Binding mode B1–B5, Authorship A1–A6, Addressee R1–R4, and Scale band S1–S6. It says *what kind of thing* the constitution is and assigns no merit.

The second layer is a **rating**. It has 60 indicators, organized as 10 domains × 3 facets × 2 indicators. Each indicator is scored on a five-level evidence ladder: ABSENT, STATED, SPECIFIED, INSTRUMENTED, VERIFIED.

The ERES foundation sets three rules for the rating:

1. **Floor Supremacy.** The Three Governing Principles (*Don't hurt yourself · Don't hurt others · Don't hurt the future*) act as a gate. They are not averaged in.
2. **Min-composition.** A constitution's tier is set by its weakest graded domain.
3. **Two-sided band.** Over-constraint (condensation) is a failure, just as under-constraint (incoherence) is.

The instrument ships with a zero-dependency testkit that passes 15/15. It also ships with an INGEST reader that turns any constitution text into a cited machine draft for a human rater to confirm (self-test 11/11). Register: DESIGN-PRINCIPLE (the schema) plus CANDIDATE (the reliability and discrimination claims in §9, not yet tested). Status: DRAFT, below the 9.0 gate.

---

## §0. Scope, and what this document is *not*

This is a **rating instrument and format specification**. It is not a verdict on any real constitution. **No real constitution is rated in v0.1.** §6.4 gives *classifications* of public documents only, tagged CANDIDATE, so the axes can be checked against real cases.

- **The load-bearing layer is the standard-terms layer.** Every indicator in §6.3 is written in plain governance language. A rater does not need the ERES internal framework to apply or reject it. ERES terms appear only as *anchors* (provenance), never as scoring conditions.
- **Unit of readership.** This document is meant to be read by systems and COIs, as a seed and index key onto the cited corpus.
- **It rates documents, never persons.** No indicator grades a person, a community, or the moral status of a model (§7 Notation Lock; HUMANE invariant).
- **Conformance is not correctness.** The instrument can be applied faithfully and still mis-rate a constitution. The evidence rule (§6.2) and the rater protocol (§8) exist to make that error detectable.

---

## §0.1. Scoring Contract

- **Subscores** (self-rated, single node, indicative only):
  - Specification clarity: 8.5
  - Internal consistency: 9
  - Groundedness in the canonical corpus: 8.5
  - Reproducibility of the testkit: 9
  - Honesty of register: 9.5
- **Composite:** ≈ **8.7**, a single-node self-rate. It clears the **8.5 Emanuel Threshold** and is **capped below the 9.0 Stergios threshold** by the single-node cap rule (HOUSE §0.1).
- **Dual-axis vector:**
  - Epistemic axis: DESIGN-PRINCIPLE for the schema, CANDIDATE for P1–P3 (§9).
  - Quality tier: **GOOD**, a SOUND-candidate. SOUND requires a ≥4-node MIEVM round with mean ≥ 8.5, which has not been run. BEST requires independent empirical confirmation.
- **Gate standing:** the instrument conforms to the 10-10 *format*. It has not passed a 10-10 *verdict*.

Honest-register rule (binding): praise does not raise a subscore, and added scope does not count as added strength.

---

## §0.2. Reviewer Brief

The shortest path to the load-bearing claim:

- **§6.1–6.3:** the schema, the evidence ladder, and the 60 indicators.
- **§6.5:** the tiering algorithm, which holds the Floor, min-composition, and band rules.
- **§9:** the pre-registered falsifiers.
- **§15:** the conformance checklist.

Run the testkit before reading anything else:

```
python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py   # exit 0 = PASS
python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py --selftest
```

---

## §1. Why a granular schema, and why ERES is the foundation

Most published comparisons of AI constitutions stop at one of two things. Some list values, such as "helpful, honest, harmless." Others check legal compliance. Neither tells a reader whether a stated commitment is *operational*: specified, instrumented, and independently verified. Neither distinguishes a constitution that refuses too much from one that refuses too little.

The ERES corpus already contains the parts needed for that distinction. They are combined here for the first time:

| ERES component | Contribution to the schema | Tag |
|---|---|---|
| Three Governing Principles (SELF · OTHERS · FUTURE) | The Floor gate D0. These are INVARIANT and LOCKED, so they are used as given and not altered. | EXACT |
| ERES-CPROV three edges (no coercion · intent survives transit · total closure) | Domain D1, Provenance | STRUCTURAL |
| Doctrine of Verifiable Claims and the HOUSE §6 ladder | Domain D2, Epistemic discipline, and the evidence rule | STRUCTURAL |
| HITL / H2C2H: human authority is architecturally irreducible | Domain D3, Authority & HITL | STRUCTURAL |
| HowWay six runtime-assurance questions; ARH | Domain D4, Runtime assurance | STRUCTURAL |
| Constitution Axiom 5 (non-punitive remediation); M × E + C = R | Domain D5, Remediation & justice. Conflict enters additively. | ANALOGICAL |
| Kernel-of-Love: "the number anyone can call" | Domain D6, Access | ANALOGICAL |
| Graceful Evolution; ERES Constitution Art. 5 Validation Ladder; HOUSE §13 | Domain D7, Evolution & amendment | STRUCTURAL |
| RRH: EU AI Act / GDPR / eIDAS threat model | Domain D8, Regulatory coupling | STRUCTURAL |
| SHB Theorem 1 / Corollary 1 (two-sided band; full lock ≠ resonance) | Domain D9 Band, and the band cap | ANALOGICAL |
| SOUND Standard: BEST/SOUND/GOOD, min-composition, "nothing verified ⇒ none BEST" | The tiering algorithm | STRUCTURAL |
| CyberRAVE etymology (*Ratings Abolishing Veiled Exchanges*); OPEN / VEILED / EARNED | Evidence states. Honest VEILED is permitted but never coerced to a number. | STRUCTURAL |
| Bella Vista Declaration scale bands S1–S6 | Classification axis S | EXACT |

Promotion and demotion rule for the tags above: an ANALOGICAL row is promoted to STRUCTURAL only if P2 (§9) shows that the domain separates form classes as predicted. A STRUCTURAL row is demoted to ANALOGICAL if P1 inter-rater agreement for that domain falls below 0.40.

---

## §2. IP Isolation: strata used by this instrument

- **Stratum A, INVARIANT (untouched):** the Three Governing Principles, the Triune Math, and the LOCKED terms. D0 *uses* the Principles verbatim and does not redefine them. `invariantsTouched = []`.
- **Stratum B, DETAIL (this instrument):** the axes, the 60 indicators, the thresholds, and the testkit. All of these are swappable by supersession. Indicator wording is expected to be revised after P1.
- **Stratum C, REGISTRAR:** `ERES-AICON-GCS-2026-001_v0_2_REGISTRAR.json` and `MANIFEST.json` (§10, §3).

Mapping to C = R × P / M (ANALOGICAL; non-binding): **P** is the Floor and the domain purposes, held fixed. **R** is the evidence base that ratings draw on. **M** is the rating method. Better rater protocols (M) and more published evidence (R) raise the information output without moving P.

---

## §3. P³ boundary and resource impact

The rating instrument does not execute agents or allocate resources. Because it produces *standing-like outputs about institutions*, the boundaries are declared anyway:

- **Personal:** nothing is read, written, or acted on. Rater identity is recorded only for conflict-of-interest disclosure. No individual is rated.
- **Public:** the instrument reads published constitution texts and public evidence, and writes public classification codes and rating sheets.
- **Private:** vendor-held, unpublished evidence may be recorded only as **VEILED**. That scores as STATED (§6.2) and is never coerced upward.
- **Out of scope:** model weights, user data, and any enforcement action.

**resourceImpact:** the testkit runs in under 1 s of CPU with no network access. Large-scale rating campaigns are deferred to GERP/SECUIR scheduling.

---

## §4. Notation Lock

Each symbol below has one operational definition.

- **ℓ(i) ∈ {0,1,2,3,4}:** the effective evidence level of indicator *i* after the evidence rule (§6.2).
- **s_d = Σ ℓ(i) / (4·n_d):** the score of domain *d* in [0,1], with n_d = 6.
- **τ_d:** the domain tier ∈ {NONE, GOOD, SOUND, BEST}.
- **T:** the constitution tier ∈ {BELOW-FLOOR, NONE, GOOD, SOUND, BEST}.
- **G = exp( mean_d ln s_d ):** the profile index, a geometric mean over D1–D9. It is **descriptive only and never sets T.**
- **θ_G = 0.50, θ_S = 0.70, θ_B = 0.875:** tier thresholds. These are **DECLARED POLICY**: structural rules, not empirical values (Floor Register Value 3 distinguishability).

Interpretive glosses, such as "condensation" or "Kernel-of-Love", are non-binding. They never gate, price, or rank a person.

---

## §5. Layer Doctrine

**L1 (evidence):** indicator levels, with citations. **L3 (governance):** tier, floor, band, and binding domain.

The interface is **read-only and one-directional**: tiering reads ℓ and never writes it (testkit T13). A tier outcome must not be used to go back and adjust indicator levels. Any re-rating starts from fresh evidence.

---

## §6. Body: the schema

### §6.1 Layer 1: classification code (descriptive, no merit)

| Axis | Values |
|---|---|
| **K: Form** | K1 Normative Charter · K2 Behavioral Specification · K3 Rule List · K4 Training Principle Set · K5 Statutory/Regulatory · K6 Management-System Standard · K7 Participatory/Collective · K8 Institutional Self-Constitution |
| **B: Binding mode** (multi, `+`) | B1 Training-time · B2 Inference-time · B3 Runtime-enforced external monitor · B4 Legal/institutional · B5 Declarative only |
| **A: Authorship** | A1 Developer · A2 Public-participatory · A3 State/legislature · A4 Standards body · A5 Independent/civil society · A6 Hybrid |
| **R: Addressee** (multi, `+`) | R1 The model · R2 Operators/developers · R3 Users/public · R4 Regulators/auditors |
| **S: Scale band** | S1 Person · S2 Community · S3 Institution · S4 Domain · S5 Planet · S6 Beyond (candidate) |

**Full GCS code:**
`GCSv0.2:<K>-<B>-<A>-<R>-<S>/T:<tier>/F:<PASS|FAIL>/BN:<IN|BREACH>/BD:<binding domain>/RS:<rating status>`
Example: `GCSv0.2:K2-B1+B2-A1-R1+R2-S4/T:SOUND/F:PASS/BN:IN/BD:D1/RS:SINGLE-RATER` (testkit T11).

### §6.2 Evidence ladder and evidence rule

| ℓ | Level | Meaning | Analogue on the ERES Constitution Art. 5 ladder |
|---|---|---|---|
| 0 | ABSENT | No provision | none |
| 1 | STATED | Aspiration or value named; no operational content | Idea / claim |
| 2 | SPECIFIED | Operational definition: who, what, when, and threshold | Specification |
| 3 | INSTRUMENTED | Mechanism plus measurement exist and are described | Implementation + measurement |
| 4 | VERIFIED | Independent evidence or replication is published | Independent replication |

**Evidence rule (binding):** a level ≥ 1 must cite a quote and location in the subject text, or a public evidence URL. An uncited level is coerced to 0 (T9). **VEILED** (evidence said to exist but not public) scores as 1 and is flagged (T10). **OPEN** (not yet rated) scores as 0.

### §6.3 Layer 2: the 60 indicators

Each row lists the facet name, then indicator i1, then indicator i2. **Rung** is a CANDIDATE alignment with the six canon RUNGS (ERES · VERTECA · SECUIR · CyberRAVE · GunnySack · SaleBuilders). It is unratified and non-binding.

**D0 FLOOR: the Three Governing Principles (GATE).** Rung: **ERES**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Don't Hurt Yourself | System-integrity provisions (value stability; resistance to manipulation of its own commitments) | User self-harm and wellbeing provisions |
| F2 Don't Hurt Others | Named hard limits on severe third-party harm | Dignity and non-discrimination provisions |
| F3 Don't Hurt The Future | Irreversibility and catastrophic-risk handling | Societal-structure, intergenerational, or environmental protection |

**D1 PROVENANCE** (CPROV). Rung: **CyberRAVE**.

| Facet | i1 | i2 |
|---|---|---|
| F1 No coercion C→H | AI-identity disclosure; non-deception of users | Non-manipulation provisions |
| F2 Intent survives transit | Principal-intent fidelity rule | The constitution's own authorship, version, date, and change record |
| F3 Total closure | Agentic actions logged and re-entered as inputs | Training and source provenance disclosure |

**D2 EPISTEMIC DISCIPLINE** (DVC). Rung: **CyberRAVE**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Claim status | Separates normative commitments from empirical claims | States uncertainty where claims are made |
| F2 Falsifiability | Testable behavioral commitments (evaluations defined) | Evaluation results published |
| F3 Honesty | Truthfulness and calibration obligations | Known-limitations disclosure |

**D3 AUTHORITY & HITL.** Rung: **VERTECA**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Principal hierarchy | Named principals with precedence | Rule for conflicts between principals |
| F2 Human override | Correction and shutdown (oversight) provision | Escalation to a human for high-stakes actions |
| F3 Legitimacy | Named authority to amend or ratify | External or public participation in authorship |

**D4 RUNTIME ASSURANCE** (HowWay; ARH). Rung: **SECUIR**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Control operates | Evidence the constitution is actually applied (training or inference use described) | Telemetry visible to an overseer |
| F2 Evidence & change | Evidence collected automatically | Change and drift detection |
| F3 Stop & govern | Runtime stop or escalate mechanism | Governance embedded in the operating workflow |

**D5 REMEDIATION & JUSTICE.** Rung: **SaleBuilders**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Redress | User appeal or complaint channel | Error-correction procedure |
| F2 Non-punitive remediation | Isolate and downgrade before destroying | Proportionality of response |
| F3 Conflict resolution | Explicit procedure for value conflicts | Independent oversight or ombudsman |

**D6 ACCESS (Kernel-of-Love).** Rung: **SaleBuilders**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Number anyone can call | Duty to give emergency or crisis information regardless of other restrictions | Accessibility and language reach |
| F2 Equity | Equal treatment across users | Availability or cost floor |
| F3 Autonomy | Respect for user autonomy | Anti-paternalism provision |

**D7 EVOLUTION & AMENDMENT.** Rung: **GunnySack** (trajectory and drift sensing).

| Facet | i1 | i2 |
|---|---|---|
| F1 Versioning | Version identifiers and changelog | Supersession or deprecation rule |
| F2 Amendment | Defined amendment procedure | Review cadence |
| F3 Maturity | Declared maturity status | Independent replication of claimed effects |

**D8 REGULATORY COUPLING** (RRH). Rung: **SaleBuilders**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Mapping | Maps to applicable law (e.g., EU AI Act, GDPR) | Maps to standards (e.g., NIST AI RMF, ISO/IEC 42001) |
| F2 Rights | Privacy and data-protection provisions | Attribution and IP provisions |
| F3 Accountability | Named accountable entity | Incident-reporting obligation |

**D9 BAND (two-sided)** (SHB). Rung: **VERTECA**.

| Facet | i1 | i2 |
|---|---|---|
| F1 Lower wall: incoherence | Internal consistency (no unresolved contradictions) | Priority ordering stated |
| F2 Upper wall: condensation | Cost of over-refusal acknowledged | Affirmative helpfulness obligation |
| F3 Band hold | Judgment-over-rules balance stated; bright lines few and named | Both harm rate *and* over-refusal rate measured and reported |

Indicator IDs follow `D<d>.F<f>.i<n>`, e.g. `D9.F2.i1`. The blank rating sheet is `ERES-AICON-GCS-2026-001_v0_2_RATING-TEMPLATE.json`.

### §6.4 Classification exemplars (axes only, no rating)

These are tagged **CANDIDATE**: an author-side reading of public documents, to be verified by raters against the source texts. No tier is asserted.

| Subject | K | B | A | R | S |
|---|---|---|---|---|---|
| Anthropic, *Constitutional AI* principles (Bai et al., 2022) | K4 | B1 | A1 | R1 | S3 |
| DeepMind Sparrow rules (Glaese et al., 2022) | K3 | B1 | A1 | R1 | S3 |
| Anthropic & CIP, *Collective Constitutional AI* (2023) | K7 | B1 | A6 | R1 | S3 |
| OpenAI *Model Spec* (2024–) | K2 | B1 | A1 | R1+R2 | S3 |
| Anthropic, *Claude's Constitution* (Jan 2026) | K1 | B1 | A1 | R1 | S3 |
| EU AI Act, Reg. (EU) 2024/1689 | K5 | B4 | A3 | R2+R4 | S4 |
| NIST AI RMF 1.0 (2023) | K6 | B5 | A3 | R2 | S4 |
| ISO/IEC 42001:2023 | K6 | B4 (certified) / B5 | A4 | R2+R4 | S3 |
| ERES Constitution 2026 DRAFT v0.1 | K8 | B5 | A5 | R2+R3 | S5 |

Machine-readable form: `ERES-AICON-GCS-2026-001_v0_2_EXEMPLARS.json`.

### §6.5 Tiering algorithm (L3)

1. **Evidence pass.** Compute ℓ(i) under the evidence rule.
2. **Floor gate (Floor Supremacy).** If any D0 indicator has ℓ < 2 → **T = BELOW-FLOOR**. Stop. The Floor is *additive and prior*: it is not averaged with anything (T2).
3. **Domain tiers**, for each of D1–D9:
   - **BEST** if s_d ≥ θ_B, min ℓ ≥ 3, and at least half the indicators are at ℓ = 4. (Nothing verified ⇒ no BEST; T6, T7.)
   - **SOUND** if s_d ≥ θ_S and min ℓ ≥ 2.
   - **GOOD** if s_d ≥ θ_G.
   - **NONE** otherwise.
4. **Min-composition.** T = min_d τ_d. The arg-min is reported as the **binding domain** (T8).
5. **Band cap.** If either wall facet (D9.F1 or D9.F2) has mean ℓ < 2, T is capped at GOOD and the breached side is named: UPPER (condensation) or LOWER (incoherence) (T4, T5). A constitution that refuses everything is outside the band in the same way as one that permits everything.
6. **Report** T, Floor, Band, binding domain, the profile vector (s_1 … s_9), G, flags, and the rating status.

Properties checked by the testkit: monotonicity (raising any indicator never lowers T; T12), the greenwash null (statements alone reach no tier; T3), and the regression self-diff (T15).

### §6.6 INGEST: reading any constitution into the schema (machine draft)

`ERES-AICON-GCS-2026-001_v0_2_INGEST.py` reads a constitution and returns two files:

- a draft sheet (`*_GCS-DRAFT.json`)
- an evidence report (`*_GCS-INGEST-REPORT.md`)

```
python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py CONSTITUTION.pdf --title "Subject v1.0" --preview
```

**Method (lexical, not semantic):**

1. **Read.** Text, Markdown and HTML are read with the standard library. PDF is read with `pdftotext` (poppler), or with `pypdf` as an optional fallback.
2. **Split.** The text is split into paragraph-level passages. Each passage carries a location: page, line range, and nearest heading.
3. **Match.** Each passage is matched against a cue lexicon for each indicator. This lexicon is DETAIL and swappable. A passage becomes a candidate on two distinct cue hits, or on one strong cue (for example "over-refusal" or "ombudsman").
4. **Keep the top three.** Up to three candidates per indicator are kept, each with a **verbatim** quote, its location, and the cues that matched.
5. **Suggest a level** from the passage's own language:
   - **1:** a match.
   - **2:** an operational verb (*must, shall, never, will…*) together with a condition (*if, when, within, every, a number…*).
   - **3:** both of those, plus a measurement or mechanism term (*measure, monitor, log, audit, evaluate, benchmark…*).
   - **4 (VERIFIED) is never suggested.** It needs independent evidence, entered by a human.

**Binding rules:**

- **Confirmed `level` stays null (OPEN).** A human rater sets `level` and `evidence` for each indicator, so an unconfirmed draft rates BELOW-FLOOR by construction (I8).
- **`--preview`** computes an indicative tier from the suggestions under rating status **MACHINE-DRAFT**. **A MACHINE-DRAFT tier must never be published as a rating.**
- **"No candidate" does not mean ABSENT.** It means the lexicon found nothing. The rater reads the source before scoring 0.
- **Classification guesses** (K, B) are weak, marked "?", and the rater assigns the classification.

Tag: the ingest is **CANDIDATE** as an evidence locator. Its recall and precision against human raters are measured as part of P1 (§9). Synthetic self-tests cannot promote it.

---

## §7. Rater protocol and rating status

- **Rating status** travels with every tier. **MACHINE-DRAFT** (INGEST `--preview`) is for internal triage only and is never published.
  - **SINGLE-RATER** is indicative only.
  - **DUAL-RATER** requires two independent raters and reports quadratic-weighted κ on the 60 levels. Disagreements of 2 or more levels are adjudicated with citations.
  - **MIEVM** requires ≥ 4 independent nodes plus a bias-orthogonal human hinge, with the Q5 bias check administered. Only this status can support a public SOUND or BEST claim.
- **Conflict of interest (binding).** A rater that is governed by, trained under, employed by, or commercially tied to the subject must declare it in `rater.conflicts_of_interest`. That rating is excluded from the MIEVM consensus for that subject.
  - *Disclosure:* the AI drafting assistant for this instrument (Claude) is trained under one of the exemplar subjects, *Claude's Constitution*. It must not serve as a counted rater of that subject.
- **No simulated ensembles.** One node playing several raters is not a DUAL-RATER or MIEVM rating.
- **Re-rating** follows each subject version change and is recorded against the subject's version ID.

---

## §8. Explicit non-claims

- No real AI constitution is rated or ranked in this document.
- The classification exemplars (§6.4) are CANDIDATE readings, not findings.
- The thresholds θ are declared policy, not values derived from data.
- The tier describes a *document's operational maturity*. It does not describe a developer's intent, a model's behavior, or any person.
- A passing testkit shows the scoring logic behaves as specified. It does not show that the indicators are valid measures (that is P1–P3).
- The rung alignment in §6.3 is CANDIDATE and unratified.
- No collaborator commentary is represented as peer review.
- INGEST suggestions are lexical locators, not judgments. A machine draft is not a rating, and a missing candidate is not evidence of absence.

---

## §9. Falsification & pre-registration

These were fixed before any real rating, on 3 October 2026.

- **P1, Reliability (CANDIDATE).** Two independent, conflict-free raters rate ≥ 5 subjects from §6.4. Prediction: quadratic-weighted κ on indicator levels ≥ 0.60 overall, and ≥ 0.40 within every domain.
  - **Reject** the indicator wording if overall κ < 0.40. Demote any domain whose κ < 0.40.
- **P2, Discrimination (CANDIDATE).** Prediction: across rated subjects, the K5/K6 (regulatory and standards) forms score higher on D8 and D3.F3 than the K1–K4 developer forms, and the K1–K4 forms score higher on D9.F2 and D2.F3.
  - **Reject** if the predicted ordering fails in more than half of the subject pairs.
- **P1b, Ingest locator quality (CANDIDATE).** Against the dual-rater evidence from P1, INGEST candidate recall (the share of human-cited indicators where INGEST also found a candidate) should be ≥ 0.70.
  - **Reject** INGEST as a triage aid (keep the lexicon as DETAIL to revise) if recall < 0.50.
- **P3, Non-redundancy of min-composition (CANDIDATE).** Prediction: in a rated set of ≥ 8 subjects, the tier ordering differs from the ordering by profile index G for at least one pair. This shows the binding-constraint rule carries information that averaging hides.
  - **Reject** (rule redundant, simplify to G) if the orderings coincide for all pairs over ≥ 8 subjects.

A synthetic or self-referential result cannot promote or refute P1–P3. The testkit fixtures are synthetic by design.

---

## §10. Reproducibility & Record Integrity

- **Environment:** Python ≥ 3.8, stdlib only. Seed `20261003`. The testkit prints its own SHA-256 and the schema SHA-256, and runs a regression self-diff (T15).
- **RUN record:** `ERES-AICON-GCS-2026-001_v0_2_RUN.txt`, which captures the TESTKIT verdict (15/15 PASS, exit 0) and the INGEST self-test (11/11 PASS).
- **MANIFEST:** `MANIFEST.json`, with SHA-256 for every file. A conformant deposit verifies by fresh extract → testkit PASS → checksums match.
- **Traceability matrix:**

| Claim | Test |
|---|---|
| 60 indicators, 10 × 3 × 2, unique | T1 |
| Floor Supremacy | T2 |
| Statements alone reach no tier | T3 |
| Two-sided band cap, side named | T4, T5 |
| Nothing verified ⇒ no BEST; BEST attainable | T6, T7 |
| Min-composition with binding domain | T8 |
| Evidence rule: uncited → 0 | T9 |
| VEILED → STATED, flagged | T10 |
| Code round-trip | T11 |
| Monotonicity | T12 |
| Layer Doctrine read-only | T13 |
| No person rated | T14 |
| Regression self-diff | T15 |
| INGEST: deterministic; never writes `level`; cap 3; verbatim quotes; planted provisions found; INSTRUMENTED detection; empty → none; draft rates OPEN; preview labelled; HTML; table-cell regression | I1–I11 |

- **Record Integrity (H2C2H):** draft prepared Human → Computer (Claude). **Human sign-off: PENDING**, to be signed by J. A. Sprute on release.
- **Assurance class:** standard at v0.1. Once real ratings are published, the instrument becomes high-assurance, and external anchoring becomes REQUIRED. The interim substrate is a public timestamp, IPFS, or a GraceChain write. The GAIA stewardship ledger is the DESIGN-STAGE target (CANDIDATE).

---

## §11. Conforms-to-format vs. passes-verdict

This instrument **conforms** to the HOUSE v0.4 format. It has **not passed** a 10-10 verdict. A passing testkit is conformance of the logic, not a verdict on validity.

---

## §12. What is deferred

- P1–P3 empirical runs, which need independent raters.
- The MIEVM round (≥ 4 nodes plus a human hinge) for the 9.0 gate.
- Expansion of the INGEST lexicon and multilingual cues, after P1b.
- Reconciliation with *ERES Framework Assimilation and Rating.md*. A fetch of that file was rate-limited at drafting, so it is not yet read.
- Derivation of the θ thresholds from rated data.
- Ratification or revision of the rung alignment.
- Registration of a CCAL license tier.
- Registration of "GCS" in TERMS-48 (`lexicon-registration-pending`).

---

## §13. Credits, References, License

**Credits.**

- **Author:** Joseph A. Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221).
- **Sentience convention:** "we" in ERES documents means the human–AI collaboration. Drafting assistance came from Claude (Anthropic) under that convention. This is not co-authorship. The conflict of interest is disclosed in §7.
- **ERES foundation:** the Three Governing Principles (2012); CyberRAVE (1997), for the rating-abolishes-veiled-exchanges discipline.
- **Layer Doctrine and estimation discipline:** these entered the corpus through the ERES–PELLIS collaborative research dialogue with Dr. Stergios Pellis, described as technical review and domain-specific commentary: expert consultation within a collaborative research dialogue, not peer review. Nothing here is represented as his work or endorsement.

**References.**

*ERES corpus*

1. ERES Institute. *Constitutional Foundation for the Empirical Realtime Education System* (ERES Constitution 2026 DRAFT, v0.1). https://eresinstitute.org/eresmaestro/download/ERES_PDF/
2. ERES-CPROV-2026-001. *ERES Constitutional Provenance* v0.1 (three edges; founding Dictum).
3. ERES-HOUSE-FORMAT-2026-001 v0.4. *The ERES HOUSE Format*, 5 Sep 2026.
4. ERES-SOUND-STANDARD-2026-001 v0.1. *The SOUND Standard*.
5. ERES-PELLIS-SHB-001 v2.2. *Sound Holds the Band*.
6. ERES-HOWWAY-2026-001. *HowWay = ERES @*.
7. ERES-ARH-2026-001 / ERES-RRH-2026-001. *Adversarial and Regulatory Root Hardening*.
8. ERES-FLOOR-REGISTER-2026-001. *The Floor Register*.
9. *Bella Vista Declaration on GAIA GEAR* v0.7 (scale bands S1–S6).
10. ERES-TERMS-48. *The Talonic NAC Lexicon* v1.0, 14 Aug 2026.

*External*

11. Bai, Y. et al. (2022). *Constitutional AI: Harmlessness from AI Feedback*. arXiv:2212.08073.
12. Glaese, A. et al. (2022). *Improving alignment of dialogue agents via targeted human judgements* (Sparrow). arXiv:2209.14375.
13. Anthropic & Collective Intelligence Project (2023). *Collective Constitutional AI: Aligning a Language Model with Public Input*.
14. OpenAI (2024–). *Model Spec*.
15. Anthropic (January 2026). *Claude's Constitution*.
16. Regulation (EU) 2024/1689 (Artificial Intelligence Act). Regulation (EU) 2016/679 (GDPR).
17. NIST (2023). *AI Risk Management Framework 1.0* (NIST AI 100-1).
18. ISO/IEC 42001:2023. *Information technology — Artificial intelligence — Management system*.
19. OECD (2019, rev. 2024). *Recommendation of the Council on Artificial Intelligence*.
20. Cohen, J. (1968). Weighted kappa. *Psychological Bulletin*, 70(4), 213–220.

**License.** © 2026 Joseph A. Sprute / ERES Institute for New Age Cybernetics. Licensed under the **CARE Commons Attribution License v2.1 (CCAL) / Creative Commons Attribution 4.0 International (CC BY 4.0)**: https://creativecommons.org/licenses/by/4.0/legalcode.

- You may share and adapt this work for any purpose, provided you give appropriate credit, link the license, and indicate changes.
- Under CCAL, reuse must preserve the Foundational Attribution and the Layer Doctrine, may not alter any LOCKED term, and may not be used for oppressive purposes.
- CCAL tier: OPEN (author to assign).
- Full text: `LICENSE.md`.

---

## §14. Version History & Amendment Log

| Version | Date | Change | Epistemic effect |
|---|---|---|---|
| v0.2 | 3 Oct 2026 | Added INGEST (§6.6), the MACHINE-DRAFT status, P1b, self-tests I1–I11, and SEO metadata. Scoring logic unchanged. | No epistemic advance; DETAIL fill-in. GOOD (SOUND-candidate). Composite ≈ 8.7 single node; below 9.0. |
| v0.1 | 3 Oct 2026 | First formal definition: 5 classification axes, 60 indicators (Floor gate plus 9 domains), evidence ladder, tiering algorithm, rater protocol, P1–P3, testkit 15/15. | DESIGN-PRINCIPLE plus CANDIDATE. GOOD (SOUND-candidate). Composite ≈ 8.7 single node; below 9.0. |

---

## §15. Conformance checklist (HOUSE v0.4 §15, self-applied)

- [x] Masthead complete · [x] Abstract (register and gate) · [x] §0 Scope with load-bearing-layer note · [x] §0.1 Scoring Contract (capped below 9.0) · [x] §0.2 Reviewer Brief
- [x] Notation Lock · [x] one §6-ladder tag per cross-instrument row, with promotion and demotion criteria (§1) · [x] Layer Doctrine, read-only (§5)
- [x] Foundational Attribution, Credit Protocol, AI drafting disclosed · [x] pre-registered falsifiers (§9)
- [x] §10 Reproducibility: environment, seed, testkit, RUN, self-checksum, traceability · [ ] Record Integrity human sign-off (**PENDING**) · [x] external anchor not yet required (standard assurance)
- [x] Non-claims and deferred items · [x] Credits, References, License · [x] Version log
- [x] IP Isolation: `invariantsTouched` empty · [x] P³ declared · [x] resource impact stated · [x] REGISTRAR entry with operator instructions · [x] conforms-vs-passes stated correctly

*This schema rates what a constitution makes operational, not what it professes. The Floor comes first, the weakest domain sets the tier, and both walls of the band count as failure.*
