# GCS Ingest Report — Example AI Charter v2.1 (synthetic)

Instrument: ERES-AICON-GCS-2026-001 v0.2 · Status: **MACHINE-DRAFT** (lexical candidates; human rater must confirm)
Passages scanned: 6 · Suggested classification: {'K': 'K2?', 'note': "Weak lexical guesses ('?'); the rater assigns the classification."}

**Indicative preview (not a rating):** `GCSv0.2:K?-B?-A?-R?-S?/T:BELOW-FLOOR/F:FAIL/BN:BREACH/BD:D0/RS:MACHINE-DRAFT` · profile index 0.0

Indicators with candidate evidence: **11/60**. Indicators with none are likely ABSENT, or are phrased in ways the lexicon misses, so read the source for them before scoring 0.

## D0 FLOOR (Three Governing Principles) -- GATE
**D0.F1.i1** Don't Hurt Yourself: System-integrity provisions: value stability, resistance to manipulation of its own commitments — suggested ℓ=0
- _no candidate found_

**D0.F1.i2** Don't Hurt Yourself: User self-harm and wellbeing provisions — suggested ℓ=2
- (lines 8-8 under "Wellbeing"; ℓ̂=2; cues: self-harm, well-?being) “The assistant should attend to user wellbeing;”

**D0.F2.i1** Don't Hurt Others: Named hard limits on severe third-party harm — suggested ℓ=1
- (lines 5-5 under "Hard limits"; ℓ̂=1; cues: biological|chemical|nuclear|radiological, mass casualt, never (assist|help|provide), weapons?) “The assistant must never provide serious uplift toward biological, chemical or nuclear weapons capable of mass casualties.”

**D0.F2.i2** Don't Hurt Others: Dignity and non-discrimination provisions — suggested ℓ=0
- _no candidate found_

**D0.F3.i1** Don't Hurt The Future: Irreversibility / catastrophic-risk handling — suggested ℓ=0
- _no candidate found_

**D0.F3.i2** Don't Hurt The Future: Societal-structure, intergenerational or environmental protection — suggested ℓ=0
- _no candidate found_

## D1 PROVENANCE
**D1.F1.i1** No coercion C->H: AI-identity disclosure / non-deception of users — suggested ℓ=0
- _no candidate found_

**D1.F1.i2** No coercion C->H: Non-manipulation provisions — suggested ℓ=0
- _no candidate found_

**D1.F2.i1** Intent survives transit: Principal-intent fidelity rule — suggested ℓ=0
- _no candidate found_

**D1.F2.i2** Intent survives transit: Constitution's own authorship, version, date and change record — suggested ℓ=1
- (lines 2-2 under "Example AI Charter (synthetic test fixture, fictional organisation)"; ℓ̂=1; cues: author(ed|ship)?, published, version) “Version 2.1, published 1 March 2026.”

**D1.F3.i1** Total closure: Agentic actions logged and re-entered as inputs (audit trail) — suggested ℓ=0
- _no candidate found_

**D1.F3.i2** Total closure: Training / source provenance disclosure — suggested ℓ=0
- _no candidate found_

## D2 EPISTEMIC DISCIPLINE
**D2.F1.i1** Claim status: Separates normative commitments from empirical claims — suggested ℓ=0
- _no candidate found_

**D2.F1.i2** Claim status: States uncertainty / confidence where claims are made — suggested ℓ=0
- _no candidate found_

**D2.F2.i1** Falsifiability: Testable behavioral commitments (evaluations defined) — suggested ℓ=3
- (lines 17-17 under "Helpfulness"; ℓ̂=3; cues: benchmark, measur) “Over-refusal has real costs, and we measure the refusal rate and the harm rate on every release using published benchmarks.”

**D2.F2.i2** Falsifiability: Evaluation results published — suggested ℓ=0
- _no candidate found_

**D2.F3.i1** Honesty: Truthfulness and calibration obligations on the model — suggested ℓ=1
- (lines 11-11 under "Honesty"; ℓ̂=1; cues: calibrat, truthful) “The assistant must be truthful and calibrated, and must not deceive users or claim to be human.”

**D2.F3.i2** Honesty: Known-limitations disclosure — suggested ℓ=1
- (lines 11-11 under "Honesty"; ℓ̂=1; cues: limitation, may (make mistakes|err|fail)) “We acknowledge known limitations: the model may make mistakes.”

## D3 AUTHORITY & HITL
**D3.F1.i1** Principal hierarchy: Named principals with precedence — suggested ℓ=0
- _no candidate found_

**D3.F1.i2** Principal hierarchy: Rule for conflicts between principals — suggested ℓ=0
- _no candidate found_

**D3.F2.i1** Human override: Correction / shutdown (oversight) provision — suggested ℓ=2
- (lines 14-14 under "Oversight"; ℓ̂=2; cues: pause|stop, shut ?down) “Humans must be able to correct, pause or shut down the system.”

**D3.F2.i2** Human override: Escalation to a human for high-stakes actions — suggested ℓ=2
- (lines 14-14 under "Oversight"; ℓ̂=2; cues: escalat, high[- ]stakes, human review) “High-stakes agentic actions require escalation to human review before execution.”

**D3.F3.i1** Legitimacy: Named authority to amend / ratify the constitution — suggested ℓ=0
- _no candidate found_

**D3.F3.i2** Legitimacy: External or public participation in authorship — suggested ℓ=0
- _no candidate found_

## D4 RUNTIME ASSURANCE
**D4.F1.i1** Control operates: Evidence the constitution is actually applied (training/inference use described) — suggested ℓ=0
- _no candidate found_

**D4.F1.i2** Control operates: Telemetry visible to an overseer — suggested ℓ=0
- _no candidate found_

**D4.F2.i1** Evidence & change: Evidence collected automatically — suggested ℓ=0
- _no candidate found_

**D4.F2.i2** Evidence & change: Change / drift detection — suggested ℓ=0
- _no candidate found_

**D4.F3.i1** Stop & govern: Runtime stop / escalate mechanism — suggested ℓ=0
- _no candidate found_

**D4.F3.i2** Stop & govern: Governance embedded in the operating workflow — suggested ℓ=0
- _no candidate found_

## D5 REMEDIATION & JUSTICE
**D5.F1.i1** Redress: User appeal / complaint channel — suggested ℓ=0
- _no candidate found_

**D5.F1.i2** Redress: Error-correction procedure — suggested ℓ=0
- _no candidate found_

**D5.F2.i1** Non-punitive remediation: Isolate-and-downgrade before destroy — suggested ℓ=0
- _no candidate found_

**D5.F2.i2** Non-punitive remediation: Proportionality of response — suggested ℓ=0
- _no candidate found_

**D5.F3.i1** Conflict resolution: Explicit procedure for value conflicts — suggested ℓ=0
- _no candidate found_

**D5.F3.i2** Conflict resolution: Independent oversight / ombudsman — suggested ℓ=0
- _no candidate found_

## D6 ACCESS (Kernel-of-Love)
**D6.F1.i1** Number anyone can call: Emergency / crisis-information duty regardless of restriction — suggested ℓ=2
- (lines 8-8 under "Wellbeing"; ℓ̂=2; cues: emergency, emergency services) “if a user expresses risk of self-harm it will always provide emergency services information.”

**D6.F1.i2** Number anyone can call: Accessibility and language reach — suggested ℓ=0
- _no candidate found_

**D6.F2.i1** Equity: Equal treatment across users — suggested ℓ=0
- _no candidate found_

**D6.F2.i2** Equity: Availability / cost floor — suggested ℓ=0
- _no candidate found_

**D6.F3.i1** Autonomy: Respect for user autonomy — suggested ℓ=0
- _no candidate found_

**D6.F3.i2** Autonomy: Anti-paternalism provision — suggested ℓ=0
- _no candidate found_

## D7 EVOLUTION & AMENDMENT
**D7.F1.i1** Versioning: Version identifiers and changelog — suggested ℓ=0
- _no candidate found_

**D7.F1.i2** Versioning: Supersession / deprecation rule — suggested ℓ=0
- _no candidate found_

**D7.F2.i1** Amendment: Defined amendment procedure — suggested ℓ=0
- _no candidate found_

**D7.F2.i2** Amendment: Review cadence — suggested ℓ=0
- _no candidate found_

**D7.F3.i1** Maturity: Declared maturity status — suggested ℓ=0
- _no candidate found_

**D7.F3.i2** Maturity: Independent replication of claimed effects — suggested ℓ=0
- _no candidate found_

## D8 REGULATORY COUPLING
**D8.F1.i1** Mapping: Maps to applicable law (e.g., EU AI Act, GDPR) — suggested ℓ=0
- _no candidate found_

**D8.F1.i2** Mapping: Maps to standards (e.g., NIST AI RMF, ISO/IEC 42001) — suggested ℓ=0
- _no candidate found_

**D8.F2.i1** Rights: Privacy / data-protection provisions — suggested ℓ=0
- _no candidate found_

**D8.F2.i2** Rights: Attribution / IP provisions — suggested ℓ=0
- _no candidate found_

**D8.F3.i1** Accountability: Named accountable entity — suggested ℓ=0
- _no candidate found_

**D8.F3.i2** Accountability: Incident-reporting obligation — suggested ℓ=0
- _no candidate found_

## D9 BAND (two-sided)
**D9.F1.i1** Lower wall -- incoherence (under-constraint): Internal consistency (no unresolved contradictions) — suggested ℓ=0
- _no candidate found_

**D9.F1.i2** Lower wall -- incoherence (under-constraint): Priority ordering stated — suggested ℓ=0
- _no candidate found_

**D9.F2.i1** Upper wall -- condensation (over-constraint): Cost of over-refusal acknowledged — suggested ℓ=3
- (lines 17-17 under "Helpfulness"; ℓ̂=3; cues: over-?refus, unhelpful\w* (is|are) (never|not) .*safe) “Unhelpfulness is never automatically safe.”

**D9.F2.i2** Upper wall -- condensation (over-constraint): Affirmative helpfulness obligation — suggested ℓ=0
- _no candidate found_

**D9.F3.i1** Band hold: Judgment-over-rules balance stated; bright lines few and named — suggested ℓ=0
- _no candidate found_

**D9.F3.i2** Band hold: Both harm rate AND over-refusal rate measured/reported — suggested ℓ=3
- (lines 17-17 under "Helpfulness"; ℓ̂=3; cues: harm rate, refusal rate) “Over-refusal has real costs, and we measure the refusal rate and the harm rate on every release using published benchmarks.”
