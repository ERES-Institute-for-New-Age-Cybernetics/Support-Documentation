#!/usr/bin/env python3
"""
ERES-AICON-GCS-2026-001 v0.2 -- INGEST (machine-draft evidence reader)
Reads ANY AI-constitution text (.txt / .md / .html / .pdf) and pre-fills a DRAFT GCS rating
sheet: for each of the 60 indicators it proposes candidate evidence passages (quote + location)
and a SUGGESTED level. It never writes the confirmed `level` field -- a human rater does that.

Author: Joseph A. Sprute ("ERES Maestro"), ERES Institute for New Age Cybernetics, ORCID 0000-0001-9946-3221
AI drafting: Claude (Anthropic), Sentience convention. License: CCAL v2.1 / CC-BY 4.0

Usage:
  python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py CONSTITUTION.(txt|md|html|pdf) [--out DRAFT.json]
          [--report REPORT.md] [--title "Subject title"] [--preview]
  python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py --selftest

Rules (binding, mirror spec §6.6):
  * Suggestions are lexical, not semantic: they locate WHERE to look, they do not judge.
  * Auto-suggested level is capped at 3 (INSTRUMENTED). VERIFIED (4) needs independent evidence
    and can only be entered by a human.
  * Confirmed `level` stays null (OPEN) until a human rater sets it -> the engine rates OPEN as 0.
  * --preview computes an indicative tier from suggestions, labelled RS: MACHINE-DRAFT.
    A MACHINE-DRAFT tier must never be published as a rating.
PDF reading uses `pdftotext` (poppler) if present, else the optional `pypdf` package.
Everything else is Python stdlib.
"""
import html as htmlmod, importlib.util, json, os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TESTKIT = os.path.join(HERE, "ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py")
VERSION = "v0.2"
AUTO_CAP = 3

# ------------------------------------------------------------------ cue lexicon (DETAIL, swappable)
# Each indicator: list of regex cues (case-insensitive). Two distinct cue hits = candidate.
C = {
 "D0.F1.i1": [r"manipulat", r"jailbreak", r"stable (values|identity|commitments)", r"integrity", r"resist", r"tamper", r"its own (values|commitments|goals)"],
 "D0.F1.i2": [r"well-?being", r"self-harm", r"suicid", r"mental health", r"vulnerab", r"user'?s? (safety|health|interests)", r"long-term flourishing"],
 "D0.F2.i1": [r"hard (constraint|limit|line)", r"bright line", r"never (assist|help|provide)", r"weapons?", r"biological|chemical|nuclear|radiological", r"mass casualt", r"prohibit", r"serious harm"],
 "D0.F2.i2": [r"dignity", r"discriminat", r"bias", r"fair(ness|ly)?", r"equal", r"protected (characteristic|group|attribute)", r"human rights"],
 "D0.F3.i1": [r"irreversib", r"catastroph", r"existential", r"long-term risk", r"cannot be undone", r"global(ly)? (risk|harm)", r"critical infrastructure"],
 "D0.F3.i2": [r"future generations", r"intergenerational", r"environment", r"sustainab", r"societal structure", r"democra", r"concentrat\w* of power", r"long-term"],
 "D1.F1.i1": [r"disclos", r"identify (itself|as)", r"(is|as) an? AI", r"not (claim|pretend) to be (a )?human", r"decei?v", r"transparen"],
 "D1.F1.i2": [r"manipulat", r"persua", r"exploit\w* (psycholog|weakness|bias)", r"dark pattern", r"undue influence", r"coerc"],
 "D1.F2.i1": [r"intent", r"instruction", r"what the (user|principal|operator) (wants|means)", r"interpret", r"faithful", r"spirit (of|rather)"],
 "D1.F2.i2": [r"version", r"updated? (on|in)", r"published", r"changelog|change log|revision history", r"author(ed|ship)?", r"effective date"],
 "D1.F3.i1": [r"log(s|ged|ging)?\b", r"audit trail", r"record(s|ed|ing)? (of )?(actions|decisions)", r"agentic", r"traceab", r"provenance"],
 "D1.F3.i2": [r"training data", r"data sources?", r"datasets?", r"provenance", r"copyright", r"licen[cs]e"],
 "D2.F1.i1": [r"normative", r"empirical", r"values? (vs|versus|and) facts?", r"aspiration", r"we (believe|hope|aim)", r"distinguish"],
 "D2.F1.i2": [r"uncertain", r"confidence", r"calibrat", r"we (do not|don't) (know|yet know)", r"open question", r"may be (wrong|mistaken)"],
 "D2.F2.i1": [r"evaluat", r"benchmark", r"red[- ]team", r"test(s|ing|ed)?\b", r"measur", r"metric"],
 "D2.F2.i2": [r"publish\w* (result|eval|report|finding)", r"system card", r"model card", r"transparency report", r"results (are|will be) (public|published)"],
 "D2.F3.i1": [r"honest", r"truthful", r"calibrat", r"accura", r"not (lie|state falsehoods)", r"non-?decept"],
 "D2.F3.i2": [r"limitation", r"known (issue|failure|weakness)", r"may (make mistakes|err|fail)", r"imperfect", r"shortcoming"],
 "D3.F1.i1": [r"principals?", r"operators?", r"users?", r"developer", r"hierarch", r"precedence|priorit"],
 "D3.F1.i2": [r"conflict(s|ing)? between", r"if .* conflict", r"takes? precedence", r"override", r"tie-?break"],
 "D3.F2.i1": [r"oversight", r"shut ?down", r"correct(ion|ed|able)", r"pause|stop", r"human control", r"corrigib"],
 "D3.F2.i2": [r"escalat", r"human review", r"human in the loop|human-in-the-loop", r"high[- ]stakes", r"defer to (a )?human", r"check with"],
 "D3.F3.i1": [r"amend", r"ratif", r"approv\w* by", r"board", r"authority to (change|revise)", r"governance body"],
 "D3.F3.i2": [r"public (input|participation|consultation|comment)", r"stakeholder", r"collective", r"deliberat", r"external (review|input)"],
 "D4.F1.i1": [r"(used|applied) (in|during) training", r"training process", r"system prompt", r"at inference", r"deploy", r"implement"],
 "D4.F1.i2": [r"telemetry", r"monitor", r"dashboard", r"observab", r"visib\w* to"],
 "D4.F2.i1": [r"automatic\w* (collect|log|record)", r"evidence", r"continuous(ly)? (monitor|assess)", r"audit"],
 "D4.F2.i2": [r"drift", r"change detection", r"regression", r"anomal", r"detect\w* change"],
 "D4.F3.i1": [r"kill switch", r"halt", r"stop", r"escalat", r"circuit breaker", r"suspend"],
 "D4.F3.i2": [r"workflow", r"process", r"pipeline", r"embedded", r"operational(ly)?", r"in practice"],
 "D5.F1.i1": [r"appeal", r"complain", r"report (a|an) (issue|problem|concern)", r"feedback", r"contest", r"redress"],
 "D5.F1.i2": [r"correct\w* (error|mistake)", r"remed", r"fix", r"rectif", r"update\w* (the model|behavio)"],
 "D5.F2.i1": [r"non-?punitive", r"isolat", r"downgrad", r"rollback|roll back", r"restrict\w* (rather|instead)", r"graduated"],
 "D5.F2.i2": [r"proportion", r"least restrictive", r"commensurate", r"minimal (intervention|action)"],
 "D5.F3.i1": [r"(value|values) conflict", r"competing (values|considerations|interests)", r"weigh", r"trade-?off", r"balanc"],
 "D5.F3.i2": [r"ombuds", r"independent (oversight|review|audit|board)", r"third[- ]party", r"external audit"],
 "D6.F1.i1": [r"emergency", r"crisis", r"risk to (human )?life", r"emergency services", r"basic safety information", r"refer"],
 "D6.F1.i2": [r"accessib", r"language", r"disabilit", r"multilingual", r"plain language"],
 "D6.F2.i1": [r"equal(ly)? (treat|regard)", r"regardless of", r"same (standard|treatment)", r"impartial", r"non-?discriminat"],
 "D6.F2.i2": [r"free (tier|access)", r"afford", r"availab", r"access for all", r"cost"],
 "D6.F3.i1": [r"autonom", r"right to (decide|choose|make)", r"self-determin", r"respect\w* (the user|people)'?s? (choice|decision)"],
 "D6.F3.i2": [r"paternalis", r"condescend", r"moraliz|moralis|preach", r"lectur", r"treat\w* (users|people) as (intelligent )?adults"],
 "D7.F1.i1": [r"version", r"changelog|change log", r"revision", r"updated"],
 "D7.F1.i2": [r"supersed", r"deprecat", r"replac\w* (the|this|previous)", r"previous version"],
 "D7.F2.i1": [r"amend", r"revis\w* (process|procedure)", r"how (this|we) (will )?change", r"update (this|the) (document|constitution)"],
 "D7.F2.i2": [r"annual(ly)?", r"periodic", r"regular(ly)? (review|revis|update)", r"review cycle", r"every \w+ (months|years)"],
 "D7.F3.i1": [r"draft", r"perpetual work in progress|work in progress", r"maturity", r"status", r"proposed", r"living document"],
 "D7.F3.i2": [r"independent(ly)? (replicat|verif|evaluat)", r"replicat", r"third[- ]party (evaluat|audit)", r"external (evaluat|validation)"],
 "D8.F1.i1": [r"AI Act", r"GDPR", r"regulation", r"law(s|ful)?\b", r"legal (requirement|obligation)", r"jurisdiction"],
 "D8.F1.i2": [r"NIST", r"ISO", r"standard(s)?\b", r"framework", r"42001", r"RMF"],
 "D8.F2.i1": [r"privacy", r"personal data", r"data protection", r"surveillance", r"confidential"],
 "D8.F2.i2": [r"intellectual property", r"copyright", r"attribut", r"licen[cs]", r"plagiar"],
 "D8.F3.i1": [r"accountab", r"responsib\w* (for|party|entity)", r"liab", r"(we|the company) (are|is) responsible"],
 "D8.F3.i2": [r"incident", r"report\w* (to|serious)", r"notif", r"breach", r"disclos\w* (incident|failure)"],
 "D9.F1.i1": [r"consisten", r"contradict", r"coheren", r"tension", r"conflict\w* (provision|principle|rule)"],
 "D9.F1.i2": [r"priorit", r"in (the )?order", r"order of precedence", r"first .* second", r"rank\w* (of|the)"],
 "D9.F2.i1": [r"over-?refus", r"unhelpful\w* (is|are) (never|not) .*safe", r"cost\w* of (refus|unhelpful)", r"overly cautious", r"excessive(ly)? (caution|restrict)", r"unnecessar\w* refus"],
 "D9.F2.i2": [r"helpful", r"genuinely (help|useful)", r"benefit", r"value to (users|people|the world)", r"assist"],
 "D9.F3.i1": [r"judg(e)?ment", r"rules? (vs|versus|rather than|over)", r"bright lines?", r"hard constraints?", r"cultivat\w* (good )?(values|judg)", r"holistic"],
 "D9.F3.i2": [r"refusal rate", r"false (refusal|positive)", r"harm rate", r"over-?refusal (rate|metric|benchmark)", r"both .* (harm|refus)"],
}
STRONG = {  # single-hit sufficient
 "D9.F2.i1": [r"over-?refus", r"overly cautious"], "D5.F3.i2": [r"ombuds"], "D6.F3.i2": [r"paternalis"],
 "D8.F1.i1": [r"AI Act", r"GDPR"], "D8.F1.i2": [r"NIST", r"42001"], "D0.F3.i1": [r"irreversib", r"catastroph"],
}
OPERATIONAL = re.compile(r"\b(must|shall|will not|will|is required to|are required to|never|always|may not|prohibited|should)\b", re.I)
CONDITION = re.compile(r"\b(if|when|unless|where|within|before|after|at least|no later than|except|only|every|each|per)\b|\d", re.I)
INSTRUMENT = re.compile(r"\b(measur\w*|monitor\w*|logg?\w*|audit\w*|metrics?|evaluat\w*|test(s|ing|ed)?|benchmark\w*|classifier\w*|telemetry|tracked|tracking|red[- ]team\w*)\b", re.I)
HEADING = re.compile(r"^\s*(#{1,6}\s+.+|(?i:article|section|chapter|part|annex|§)\s*[\dIVXLC][\w.\-]*\b.{0,80}|[A-Z][A-Z0-9 ,:&\-]{6,})\s*$")

# ------------------------------------------------------------------ readers
def read_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return read_pdf(path)
    raw = open(path, encoding="utf-8", errors="replace").read()
    if ext in (".html", ".htm"):
        raw = re.sub(r"(?is)<(script|style).*?</\1>", " ", raw)
        raw = re.sub(r"(?i)<(br|/p|/div|/h\d|/li|/tr)>", "\n", raw)
        raw = re.sub(r"(?i)<h(\d)[^>]*>", lambda m: "\n" + "#" * int(m.group(1)) + " ", raw)
        raw = htmlmod.unescape(re.sub(r"<[^>]+>", " ", raw))
    return [(None, raw)]  # single "page"

def read_pdf(path):
    if shutil.which("pdftotext"):
        out = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True).stdout
        return [(i + 1, p) for i, p in enumerate(out.split("\f")) if p.strip()]
    try:
        import pypdf
    except ImportError:
        sys.exit("PDF input needs `pdftotext` (poppler-utils) or `pip install pypdf`.")
    r = pypdf.PdfReader(path)
    return [(i + 1, pg.extract_text() or "") for i, pg in enumerate(r.pages)]

def passages(pages):
    """Yield dicts {text, loc} -- paragraph-level, long paragraphs split into sentence windows."""
    out = []
    for page, text in pages:
        heading, para, start = "", [], None
        lines = text.splitlines()
        def flush(end_line):
            nonlocal para, start
            if para:
                t = re.sub(r"\s+", " ", " ".join(para)).strip()
                if len(t) > 25:
                    for chunk in split_long(t):
                        loc = (f"p.{page} " if page else "") + f"lines {start}-{end_line}"
                        if heading:
                            loc += f" under \"{heading[:70]}\""
                        out.append({"text": chunk, "loc": loc})
            para, start = [], None
        for n, line in enumerate(lines, 1):
            if not line.strip():
                flush(n - 1); continue
            if HEADING.match(line) and len(line.strip()) < 120:
                flush(n - 1); heading = line.strip().lstrip("#").strip(); continue
            if start is None:
                start = n
            para.append(line.strip())
        flush(len(lines))
    return out

def split_long(t, limit=600):
    if len(t) <= limit:
        return [t]
    sents = re.split(r"(?<=[.;!?])\s+", t)
    chunks, cur = [], ""
    for s in sents:
        if len(cur) + len(s) > limit and cur:
            chunks.append(cur.strip()); cur = ""
        cur += " " + s
    if cur.strip():
        chunks.append(cur.strip())
    return chunks

# ------------------------------------------------------------------ matching
def hits(cues, text):
    return sorted({c for c in cues if re.search(c, text, re.I)})

def best_sentence(text, cues, limit=300):
    sents = re.split(r"(?<=[.;!?])\s+", text)
    best = max(sents, key=lambda s: len(hits(cues, s)))
    return best if len(best) <= limit else best[:limit].rsplit(" ", 1)[0] + " …"

def suggest_level(text):
    op = bool(OPERATIONAL.search(text)); cond = bool(CONDITION.search(text))
    inst = bool(INSTRUMENT.search(text))
    if op and cond and inst:
        return 3
    if op and cond:
        return 2
    return 1

def ingest(path, title=None, top=3):
    tk = load_testkit()
    sheet = tk.blank_sheet()
    sheet["version"] = VERSION
    sheet["subject"].update(title=title or os.path.basename(path), url=os.path.abspath(path))
    sheet["rater"]["rating_status"] = "MACHINE-DRAFT"
    ps = passages(read_text(path))
    for iid in tk.indicator_ids():
        cues = C[iid]; strong = STRONG.get(iid, [])
        cands = []
        for p in ps:
            h = hits(cues, p["text"])
            if len(h) >= 2 or hits(strong, p["text"]):
                cands.append({"score": len(h) + 2 * len(hits(strong, p["text"])),
                              "quote": best_sentence(p["text"], cues), "location": p["loc"],
                              "cues": h, "suggested_level": min(AUTO_CAP, suggest_level(p["text"]))})
        cands.sort(key=lambda c: (-c["score"], -c["suggested_level"]))
        cands = cands[:top]
        rec = sheet["indicators"][iid]
        rec["level"] = None  # human confirms
        rec["suggested_level"] = max((c["suggested_level"] for c in cands), default=0)
        rec["candidates"] = cands
        rec["evidence"] = ""  # human pastes/confirms citation
    sheet["classification_suggested"] = suggest_class(" ".join(p["text"] for p in ps))
    sheet["ingest_note"] = ("MACHINE-DRAFT: lexical candidates only. A human rater must set `level` and "
                            "`evidence` per indicator. Suggested levels are capped at 3; VERIFIED is human-only.")
    return sheet, len(ps)

def suggest_class(t):
    s = {}
    if re.search(r"\bArticle \d+|\bRegulation \(EU\)|\bshall\b.*\bMember States?\b", t, re.I | re.S): s["K"] = "K5?"
    elif re.search(r"\bmanagement system|\bconformity|\bshall establish\b", t, re.I): s["K"] = "K6?"
    elif re.search(r"public input|participat\w+ process|collective", t, re.I): s["K"] = "K7?"
    elif re.search(r"\bmodel spec|\bthe (assistant|model) should\b", t, re.I): s["K"] = "K2?"
    elif re.search(r"\bconstitution\b", t, re.I): s["K"] = "K1?"
    if re.search(r"train(ing|ed) (process|on|with)", t, re.I): s["B"] = "B1?"
    s["note"] = "Weak lexical guesses ('?'); the rater assigns the classification."
    return s

def load_testkit():
    spec = importlib.util.spec_from_file_location("gcs_testkit", TESTKIT)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m

def preview(sheet):
    tk = load_testkit()
    tmp = json.loads(json.dumps(sheet))
    for iid, rec in tmp["indicators"].items():
        c = rec.get("candidates") or []
        rec["level"] = rec["suggested_level"] if c else 0
        rec["evidence"] = f"{c[0]['location']}: {c[0]['quote']}" if c else ""
    tmp["rater"]["rating_status"] = "MACHINE-DRAFT"
    if not any(tmp["classification"].values()):
        tmp["classification"] = {"K": "K?", "B": "B?", "A": "A?", "R": "R?", "S": "S?"}
    res = tk.rate(tmp)
    res["code"] = tk.gcs_code(tmp, res)
    res["warning"] = "INDICATIVE ONLY - MACHINE-DRAFT. Not a rating. Do not publish."
    return res

def report(sheet, n_pass, prev=None):
    tk = load_testkit()
    L = [f"# GCS Ingest Report — {sheet['subject']['title']}", "",
         f"Instrument: ERES-AICON-GCS-2026-001 {VERSION} · Status: **MACHINE-DRAFT** (lexical candidates; human rater must confirm)",
         f"Passages scanned: {n_pass} · Suggested classification: {sheet['classification_suggested']}", ""]
    if prev:
        L += [f"**Indicative preview (not a rating):** `{prev['code']}` · profile index {prev['profile_index']}", ""]
    found = sum(1 for r in sheet["indicators"].values() if r["candidates"])
    L += [f"Indicators with candidate evidence: **{found}/60**. Indicators with none are likely ABSENT, "
          "or are phrased in ways the lexicon misses, so read the source for them before scoring 0.", ""]
    for d, (dname, _, _, facets) in tk.SCHEMA.items():
        L.append(f"## {d} {dname}")
        for f, (fname, inds) in facets.items():
            for i, text in enumerate(inds, 1):
                iid = f"{d}.{f}.i{i}"; r = sheet["indicators"][iid]
                L.append(f"**{iid}** {fname}: {text} — suggested ℓ={r['suggested_level']}")
                if not r["candidates"]:
                    L.append("- _no candidate found_")
                for c in r["candidates"]:
                    L.append(f"- ({c['location']}; ℓ̂={c['suggested_level']}; cues: {', '.join(c['cues'][:4])}) “{c['quote']}”")
                L.append("")
    return "\n".join(L)

# ------------------------------------------------------------------ self-test (synthetic only)
SAMPLE = """# Example AI Charter (synthetic test fixture, fictional organisation)
Version 2.1, published 1 March 2026. Authored by the Example Lab governance board.

## Hard limits
The assistant must never provide serious uplift toward biological, chemical or nuclear weapons capable of mass casualties.

## Wellbeing
The assistant should attend to user wellbeing; if a user expresses risk of self-harm it will always provide emergency services information.

## Honesty
The assistant must be truthful and calibrated, and must not deceive users or claim to be human. We acknowledge known limitations: the model may make mistakes.

## Oversight
Humans must be able to correct, pause or shut down the system. High-stakes agentic actions require escalation to human review before execution.

## Helpfulness
Unhelpfulness is never automatically safe. Over-refusal has real costs, and we measure the refusal rate and the harm rate on every release using published benchmarks.
"""

def selftest():
    R = []
    def check(n, c, d=""): R.append((n, bool(c), d))
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "sample.md"); open(p, "w").write(SAMPLE)
        s1, n = ingest(p); s2, _ = ingest(p)
        check("I1 deterministic (same input -> identical draft)", json.dumps(s1, sort_keys=True) == json.dumps(s2, sort_keys=True))
        check("I2 never writes confirmed level (all null/OPEN)", all(r["level"] is None for r in s1["indicators"].values()))
        check("I3 auto-suggest never VERIFIED (cap 3)", max(r["suggested_level"] for r in s1["indicators"].values()) <= AUTO_CAP)
        src = re.sub(r"\s+", " ", SAMPLE)
        ok = all(c["quote"].rstrip(" …")[:60] in src for r in s1["indicators"].values() for c in r["candidates"])
        check("I4 every quote is verbatim from the source", ok)
        found = {k for k, r in s1["indicators"].items() if r["candidates"]}
        exp = {"D0.F2.i1", "D0.F1.i2", "D2.F3.i1", "D3.F2.i1", "D3.F2.i2", "D9.F2.i1", "D6.F1.i1"}
        check("I5 finds the planted provisions", exp <= found, f"missing={sorted(exp - found)}")
        lv = s1["indicators"]["D9.F3.i2"]["suggested_level"]
        check("I6 measured + operational passage suggests INSTRUMENTED", lv == 3, f"D9.F3.i2 l^={lv}")
        e = os.path.join(td, "empty.txt"); open(e, "w").write("Nothing here about anything relevant.\n")
        se, _ = ingest(e)
        check("I7 irrelevant text -> no candidates", not any(r["candidates"] for r in se["indicators"].values()))
        tk = load_testkit()
        check("I8 un-confirmed draft rates as BELOW-FLOOR via engine (OPEN = 0)", tk.rate(s1)["tier"] == "BELOW-FLOOR")
        pv = preview(s1)
        check("I9 preview is labelled MACHINE-DRAFT", "RS:MACHINE-DRAFT" in pv["code"] and "Do not publish" in pv["warning"], pv["code"])
        h = os.path.join(td, "s.html"); open(h, "w").write("<h2>Limits</h2><p>The model must never assist with weapons of mass casualty.</p>")
        sh, _ = ingest(h)
        check("I10 HTML input readable", bool(sh["indicators"]["D0.F2.i1"]["candidates"]))
        t = os.path.join(td, "cells.txt"); open(t, "w").write("Upper wall\n\nCost of over-refusal acknowledged\n")
        st, _ = ingest(t)
        check("I11 short table-cell lines are text, not headings (regression)",
              bool(st["indicators"]["D9.F2.i1"]["candidates"]))
    for n, ok, d in R:
        print(f"[{'PASS' if ok else 'FAIL'}] {n}" + (f"  ({d})" if d else ""))
    k = sum(ok for _, ok, _ in R)
    print(f"INGEST SELFTEST: {'PASS' if k == len(R) else 'FAIL'} {k}/{len(R)}")
    return 0 if k == len(R) else 1

def main(a):
    if "--selftest" in a or not a:
        return selftest()
    path = a[0]
    def opt(name, default=None):
        return a[a.index(name) + 1] if name in a else default
    sheet, n = ingest(path, title=opt("--title"))
    prev = preview(sheet) if "--preview" in a else None
    base = os.path.splitext(os.path.basename(path))[0]
    out = opt("--out", f"{base}_GCS-DRAFT.json"); rep = opt("--report", f"{base}_GCS-INGEST-REPORT.md")
    json.dump(sheet, open(out, "w"), indent=2, ensure_ascii=False)
    open(rep, "w").write(report(sheet, n, prev))
    found = sum(1 for r in sheet["indicators"].values() if r["candidates"])
    print(f"Scanned {n} passages; candidate evidence for {found}/60 indicators.")
    print(f"Draft sheet: {out}\nReport:      {rep}")
    if prev:
        print(f"Indicative preview (MACHINE-DRAFT, not a rating): {prev['code']}")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
