# ERES-AICON-GCS-2026-001 v0.2 — Work Package

**A Granular Classification Schema for Rating AI Constitutions**
J. A. Sprute · ERES Institute for New Age Cybernetics · Bella Vista, AR · ORCID 0000-0001-9946-3221 · 3 Oct 2026
Status: DRAFT · HOUSE-format v0.4 conformant · below the 9.0 gate (MIEVM not yet run) · CCAL v2.1 / CC BY 4.0 · supersedes v0.1

**New in v0.2: INGEST.** It reads any AI constitution (.txt, .md, .html or .pdf) into the schema and produces a cited machine draft for a human rater to confirm.

## Contents
| File | Role |
|---|---|
| `…_SPECIFICATION.md` / `.pdf` | DETAIL: the full white paper (INGEST is §6.6) |
| `…_FIGURE-1.svg` | Schema figure |
| `…_TESTKIT.py` | Rating engine and testkit (stdlib only), 15/15 |
| `…_INGEST.py` | Constitution reader that writes a machine draft and an evidence report; self-test 11/11 |
| `…_RUN.txt` | Captured runs of both programs |
| `…_RATING-TEMPLATE.json` | Blank 60-indicator rating sheet |
| `…_EXEMPLARS.json` | CANDIDATE classifications of 9 public instruments (axes only) |
| `…_EXAMPLE-SUBJECT.md` | Synthetic, fictional constitution used for the demo |
| `…_EXAMPLE-DRAFT.json` / `…_EXAMPLE-INGEST-REPORT.md` | INGEST output for the example |
| `…_REGISTRAR.json` | REGISTRAR entry |
| `…_META.txt` | SEO title, abstract, keywords and deposit metadata |
| `MANIFEST.json`, `LICENSE.md`, `CITATION.cff` | Checksums, license, citation |

## Verify
```
python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py          # VERDICT: PASS 15/15
python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py --selftest  # INGEST SELFTEST: PASS 11/11
```
For PDF input, install `pdftotext` (poppler-utils) or run `pip install pypdf`. Everything else uses only the Python standard library.

## Rate any constitution in three steps
```
# 1. Machine draft: candidate quotes and locations for all 60 indicators
python3 ERES-AICON-GCS-2026-001_v0_2_INGEST.py constitution.pdf --title "Subject v1.0" --preview
#    -> constitution_GCS-DRAFT.json  +  constitution_GCS-INGEST-REPORT.md

# 2. Human rater: open the DRAFT.json and, for each indicator, set "level" (0-4) and "evidence"
#    (confirm or correct the candidate quote and location). Also fill in the classification
#    K/B/A/R/S and the rater block, and declare any conflicts of interest.

# 3. Rate
python3 ERES-AICON-GCS-2026-001_v0_2_TESTKIT.py --rate constitution_GCS-DRAFT.json
```

**Rules:**

- INGEST never sets the confirmed level, and never suggests 4 (VERIFIED).
- An unconfirmed draft rates BELOW-FLOOR by design.
- A `--preview` tier is labelled **MACHINE-DRAFT** and must never be published.
- "No candidate" means the lexicon found nothing. It does not mean the provision is absent. Read the source before scoring 0.

## What the PASS means
The PASS means the scoring logic and the reader behave as specified. It is not a rating of any real constitution, and it does not show that the indicators are valid measures. That depends on the pre-registered P1, P1b, P2 and P3, which need independent raters.

## Open
- Human sign-off (H2C2H)
- MIEVM round
- P1–P3 and P1b runs
- CCAL tier
- TERMS-48 registration of "GCS"
- Multilingual cue lexicon
- Reconciliation with *ERES Framework Assimilation and Rating.md*
