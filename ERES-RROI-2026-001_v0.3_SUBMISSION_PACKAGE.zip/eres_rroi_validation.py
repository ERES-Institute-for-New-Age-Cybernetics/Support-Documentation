#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_rroi_validation.py  —  ERES-RROI-2026-001 v0.3  structural validation suite

Tests STRUCTURAL RULES ONLY. Claims nothing measured. Defines no SROC §7 term,
modifies no SROC spec, closes no S5. Each test both CONFIRMS a well-formed case
and FALSIFIES its violation. The 2 remaining SKIPs are load-bearing and map to
the whitepaper's remaining open items (§8.4-r audit mechanism, §8.5-r QA metric),
both deferred to named upstream corpus — deliberately NOT fabricated here.

stdlib only. Safely importable (harness guarded). Exit 0 iff no FAIL.
"""

from dataclasses import dataclass

# open-item identifiers (machine-cross-referenceable with the whitepaper §8)
OPEN_AUDIT_MECHANISM = "§8.4-r"
OPEN_QA_METRIC = "§8.5-r"

# ----------------------------------------------------------------------
# Model:  an Exchange fills an SROC-slot as (WHAT ⊗ HOW) ⊕ WHY  [raw potential]
#         its MEASURED value is P^3 = Π(WHAT, HOW, WHY)          [RATABLE semantic]
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class Exchange:
    what: float        # WHAT  — resonant-energy content            (>=0)
    how: float         # HOW   — real-time diagnostic magnitude     (>=0; 0 = no rater)
    offset: float      # WHY   — cognitive price vs a shared deficit(>=0; 0 = free/un-offset)
    accrual: str       # where the return lands: "band" | "holder"
    audit_owner: str   # who owns the trail:      "band" | "holder" | "none"

    def __post_init__(self):
        for name, v in (("what", self.what), ("how", self.how), ("offset", self.offset)):
            if not isinstance(v, (int, float)) or v < 0:
                raise ValueError(f"{name} must be a number >= 0")
        if self.accrual not in ("band", "holder"):
            raise ValueError("accrual must be 'band' or 'holder'")
        if self.audit_owner not in ("band", "holder", "none"):
            raise ValueError("audit_owner must be 'band', 'holder' or 'none'")


# ---- primitives ------------------------------------------------------

def product_term(x: Exchange) -> float:
    """WHAT ⊗ HOW — product, not sum. Either factor at 0 collapses it."""
    return x.what * x.how

def slot_value(x: Exchange) -> float:
    """(WHAT ⊗ HOW) ⊕ WHY — raw-potential layer."""
    return product_term(x) + x.offset

def has_diagnostic(x: Exchange) -> bool:
    return x.how > 0

def is_offset(x: Exchange) -> bool:
    """A shared price was paid ⇒ a deficit exists to reason against."""
    return x.offset > 0

def p3_defined(x: Exchange) -> bool:
    """P^3 = Π(WHAT, HOW, WHY): WHY is an INTERIOR factor. All three must be
    present, or the measured semantic is zero (v0.3: RATABLE == p3_defined)."""
    return x.what > 0 and x.how > 0 and x.offset > 0

def p3_product(x: Exchange) -> float:
    """The measured magnitude (informational; ratability keys off p3_defined
    to avoid float under/overflow deciding measured-status)."""
    return x.what * x.how * x.offset

def is_ratable(x: Exchange) -> bool:
    """RATABLE iff the P^3 semantic is defined — a verified offset over real
    content (measured, not asserted). Tightened in v0.3 to require WHAT too."""
    return p3_defined(x)

def has_audit_record(x: Exchange) -> bool:
    """A verified P^3 leaves a re-checkable ledger entry (same predicate as
    is_ratable — the WP claims RATABLE and auditable are one property)."""
    return p3_defined(x)

def audit_valid(x: Exchange) -> bool:
    """Band-ownership guardrail: a trail that accrues to a holder is surveillance."""
    return has_audit_record(x) and x.audit_owner == "band"

def is_reasoned_roi(x: Exchange) -> bool:
    """Full gate: rateable + return lands on the band (non-accrual) + audit band-owned."""
    return is_ratable(x) and x.accrual == "band" and audit_valid(x)

def a0_conditions(x: Exchange) -> bool:
    """A0: measured value = discharge against a shared deficit, non-accrual,
    band-owned trail. Dual of Reasoned ROI (tested for coincidence in t12)."""
    return (is_offset(x) and has_diagnostic(x) and x.what > 0
            and x.accrual == "band" and audit_valid(x))

def classify(x: Exchange) -> str:
    return "earned" if is_offset(x) else "free"


# ---- Enable–Solidify–Contain (CONSTRUCT; 1:1 = structural law as of v0.3) ----

CANONICAL_ESC = {"WHAT": "Enable", "HOW": "Solidify", "WHY": "Contain"}
ESC_ORDER = ["Enable", "Solidify", "Contain"]   # open -> hold -> bound

def esc_valid(mapping: dict) -> bool:
    """1:1 role→verb binding: exactly the three roles onto the three verbs, canonically."""
    if set(mapping.keys()) != {"WHAT", "HOW", "WHY"}:
        return False
    if set(mapping.values()) != {"Enable", "Solidify", "Contain"}:
        return False
    return mapping == CANONICAL_ESC

def esc_lifecycle_valid(seq) -> bool:
    """A valid lifecycle is an ordered prefix of open->hold->bound. Rejects
    skipped stages, reordering, and joint (unordered) application. A set/other
    unordered container models simultaneous 'joint' action and has no lifecycle
    order, so it is rejected by type."""
    if not isinstance(seq, (list, tuple)):
        return False
    seq = list(seq)
    return len(seq) >= 1 and seq == ESC_ORDER[:len(seq)]


# ----------------------------------------------------------------------
# Reference exchanges
# ----------------------------------------------------------------------

WELL_FORMED      = Exchange(1.0, 1.0, 1.0, "band",   "band")
FROZEN_EXTRACTOR = Exchange(1.0, 1.0, 0.0, "holder", "holder")  # no offset, pooled, no audit
CLAIMED_ONLY     = Exchange(1.0, 0.0, 1.0, "band",   "band")    # price asserted, no rater
HOARDED_MASTERY  = Exchange(1.0, 1.0, 1.0, "holder", "band")    # skilled but pooled
SURVEILLANCE     = Exchange(1.0, 1.0, 1.0, "band",   "holder")  # trail held over people
_MATRIX = [WELL_FORMED, FROZEN_EXTRACTOR, CLAIMED_ONLY, HOARDED_MASTERY, SURVEILLANCE]


# ----------------------------------------------------------------------
# Harness
# ----------------------------------------------------------------------

def _raises(fn) -> bool:
    try:
        fn()
        return False
    except Exception:
        return True


def run():
    p = f = s = 0

    def check(tid, desc, cond):
        nonlocal p, f
        ok = bool(cond)
        print(f"[{'PASS' if ok else 'FAIL'}] {tid}: {desc}")
        if ok: p += 1
        else:  f += 1

    def skip(tid, desc, ref):
        nonlocal s
        s += 1
        print(f"[SKIP] {tid}: {desc}  (OPEN {ref})")

    # t01 product form: either factor at 0 collapses the product term
    check("t01", "WHAT⊗HOW is a product; either factor→0 collapses it, both nonzero survives",
          product_term(Exchange(0.0, 1.0, 1.0, "band", "band")) == 0.0
          and product_term(Exchange(1.0, 0.0, 1.0, "band", "band")) == 0.0
          and product_term(WELL_FORMED) > 0.0)

    # t02 RATABLE requires a nonzero offset (free ⇒ un-RATABLE)
    check("t02", "nonzero offset ⇒ RATABLE; zero offset (free) ⇒ un-RATABLE",
          is_ratable(WELL_FORMED) and not is_ratable(FROZEN_EXTRACTOR))

    # t03 measured, not asserted: a claimed price with no rater does not rate
    check("t03", "offset asserted but no diagnostic ⇒ NOT verified-RATABLE; diagnostic present ⇒ rates",
          (not is_ratable(CLAIMED_ONLY)) and is_ratable(WELL_FORMED))

    # t04 free / earned classification tracks offset magnitude
    check("t04", "classify: offset==0 → 'free', offset>0 → 'earned'",
          classify(FROZEN_EXTRACTOR) == "free" and classify(WELL_FORMED) == "earned")

    # t05 non-accrual guardrail: return must land on the band
    check("t05", "Reasoned ROI valid iff return accrues to band; accrual to holder rejected",
          is_reasoned_roi(WELL_FORMED) and not is_reasoned_roi(HOARDED_MASTERY))

    # t06 currency-not-mastery: skill is fine; UN-DISCHARGED (pooled) holding is not
    check("t06", "skilled+discharged-to-band accepted; same skill pooled to holder rejected",
          is_reasoned_roi(WELL_FORMED)
          and not is_reasoned_roi(HOARDED_MASTERY)
          and product_term(HOARDED_MASTERY) > 0)

    # t07 RATABLE ⟺ auditable (one property, two sides) across the case matrix
    check("t07", "RATABLE and has-audit-record coincide for every case",
          all(is_ratable(x) == has_audit_record(x) for x in _MATRIX))

    # t08 band-ownership of the audit trail (audit-as-accrual = surveillance)
    check("t08", "audit band-owned ⇒ valid; audit held by a holder ⇒ rejected as surveillance",
          audit_valid(WELL_FORMED) and not audit_valid(SURVEILLANCE))

    # t09 ESC is a canonical 1:1 binding (reject swap, doubled, and unknown verb)
    check("t09", "canonical ESC bijection accepted; swapped/doubled/unknown-verb rejected",
          esc_valid(CANONICAL_ESC)
          and not esc_valid({"WHAT": "Enable", "HOW": "Solidify", "WHY": "Enable"})   # doubled
          and not esc_valid({"WHAT": "Solidify", "HOW": "Enable", "WHY": "Contain"})  # swapped
          and not esc_valid({"WHAT": "Enable", "HOW": "Solidify", "WHY": "Destroy"})) # unknown verb

    # t10 end-to-end: well-formed passes every gate; frozen-extractor fails every gate
    check("t10", "well-formed exchange passes all gates; frozen-extractor fails all",
          all([is_offset(WELL_FORMED), is_ratable(WELL_FORMED),
               audit_valid(WELL_FORMED), is_reasoned_roi(WELL_FORMED)])
          and not any([is_offset(FROZEN_EXTRACTOR), is_ratable(FROZEN_EXTRACTOR),
                       audit_valid(FROZEN_EXTRACTOR), is_reasoned_roi(FROZEN_EXTRACTOR)]))

    # t11 P^3 semantic: WHY is an interior necessary factor (any zeroed factor ⇒ undefined)
    check("t11", "P^3=Π(WHAT,HOW,WHY) defined iff all three present; any factor→0 ⇒ undefined",
          p3_defined(WELL_FORMED) and p3_product(WELL_FORMED) > 0
          and not p3_defined(Exchange(0.0, 1.0, 1.0, "band", "band"))
          and not p3_defined(Exchange(1.0, 0.0, 1.0, "band", "band"))
          and not p3_defined(Exchange(1.0, 1.0, 0.0, "band", "band")))

    # t12 duality A0 ⇔ Reasoned ROI (closed §8.2): the two coincide on every case
    check("t12", "A0 conditions and Reasoned ROI coincide for every case (duality)",
          all(is_reasoned_roi(x) == a0_conditions(x) for x in _MATRIX))

    # t13 ESC lifecycle (closed §8.3): open→hold→bound ordered; joint/skip/reorder rejected
    check("t13", "lifecycle prefix-ordered; skipped/reordered/joint action rejected",
          esc_lifecycle_valid(["Enable"])
          and esc_lifecycle_valid(["Enable", "Solidify"])
          and esc_lifecycle_valid(["Enable", "Solidify", "Contain"])
          and not esc_lifecycle_valid(["Enable", "Contain"])          # skipped Solidify
          and not esc_lifecycle_valid(["Solidify", "Enable"])         # reordered
          and not esc_lifecycle_valid(["Contain"])                    # bound before open
          and not esc_lifecycle_valid(set(ESC_ORDER)))                # joint (unordered)

    # t14 input validation: model rejects malformed exchanges
    check("t14", "Exchange rejects negative magnitude and invalid enum; accepts well-formed",
          _raises(lambda: Exchange(-1.0, 1.0, 1.0, "band", "band"))
          and _raises(lambda: Exchange(1.0, 1.0, 1.0, "nope", "band"))
          and _raises(lambda: Exchange(1.0, 1.0, 1.0, "band", "nope"))
          and not _raises(lambda: Exchange(1.0, 1.0, 1.0, "band", "band")))

    # t15 fuzz extremes: ratability stays field-based and well-defined (no overflow decides it)
    _big = Exchange(1e308, 1e308, 1.0, "band", "band")   # product_term → inf
    _tiny = Exchange(1e-300, 1e-300, 1.0, "band", "band")  # product_term underflows → 0.0
    check("t15", "extreme magnitudes: ratability well-defined regardless of over/underflow",
          is_ratable(_big) and is_ratable(_tiny)
          and product_term(_tiny) == 0.0 and is_ratable(_tiny))  # underflow ≠ un-ratable

    # ---- load-bearing SKIPs → remaining open items ----
    skip("s01", "audit-layer ENFORCEMENT mechanism — property tested (t08); mechanism is GraceChain-internal",
         OPEN_AUDIT_MECHANISM)
    skip("s02", "QuestionAnswer diagnostic METRIC — interface tested (t03); the threshold's measure is deferred",
         OPEN_QA_METRIC)

    print("-" * 62)
    print(f"{p} PASS / {f} FAIL / {s} SKIP")
    return f


if __name__ == "__main__":
    raise SystemExit(1 if run() else 0)
