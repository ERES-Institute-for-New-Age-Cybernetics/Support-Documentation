"""End-to-end demo: run three proposals through the KERNEL and inspect the
resulting SOMT log, BERA health, and an RHC drift-correction.

    python demo.py
"""
from playnac_kernel import (
    Kernel, Proposal, Tier, AuthToken, Seat, PoRFactors, principles,
)
from playnac_kernel.principles import Principle
from playnac_kernel import homeostasis, execution


def seats(v):
    """Uniform council score helper."""
    return {s: v for s in Seat}


def main() -> None:
    k = Kernel()

    # ---- Proposal A: clean pass -------------------------------------------
    a = Proposal(
        action_id="A-provision-water",
        description="Fund a community water line",
        principles=principles.evaluate(True, True, True),
        por_factors=PoRFactors(0.9, 0.8, 0.85, 0.95),
        council_scores=seats(9.0),
        tier=Tier.ACT_CONFIRM,
        token=AuthToken(tier=Tier.ACT_CONFIRM, live=True),
    )

    # ---- Proposal B: blocked by principle #2 (harms others) ---------------
    b = Proposal(
        action_id="B-divert-supply",
        description="Divert supply from a neighbouring group",
        principles=principles.evaluate(
            True, False, True,
            notes={Principle.NO_OTHER_HARM: "downstream group loses access"},
        ),
        por_factors=PoRFactors(0.9, 0.7, 0.6, 0.8),  # good scores, still fails
        council_scores=seats(9.5),                   # even a happy council
        tier=Tier.ACT,
        token=AuthToken(tier=Tier.ACT, live=True),
    )

    # ---- Proposal C: admissible but council divergent (no convergence) ----
    c_scores = {
        Seat.CITIZEN: 10, Seat.BUSINESS: 10, Seat.GOVERNMENT: 9,
        Seat.MEDIA: 2, Seat.ORGANISATION: 3, Seat.DIGNITARY: 10,
        Seat.DIPLOMAT: 9,
    }
    c = Proposal(
        action_id="C-fast-track",
        description="Fast-track a contested rule",
        principles=principles.evaluate(True, True, True),
        por_factors=PoRFactors(0.8, 0.7, 0.7, 0.9),
        council_scores=c_scores,
        tier=Tier.ACT_CONFIRM,
        token=AuthToken(tier=Tier.ACT_CONFIRM, live=True),
    )

    for p in (a, b, c):
        print(k.decide(p).summary())
        print()

    print(k.bera.read().summary())
    print()

    # ---- SOMT integrity ---------------------------------------------------
    ok, broken = k.log.verify()
    print(f"SOMT entries={len(k.log)} intact={ok} broken_at={broken}")

    # ---- RHC drift correction --------------------------------------------
    corr = homeostasis.correct("agent-7", baseline=5.0, sigma=1.0, observed=8.2)
    print(corr.summary())

    # ---- Paineology on a breach ------------------------------------------
    out = execution.remediate("agent-7", execution.Tier.ACT, "acted out of band")
    print(out.summary())


if __name__ == "__main__":
    main()
