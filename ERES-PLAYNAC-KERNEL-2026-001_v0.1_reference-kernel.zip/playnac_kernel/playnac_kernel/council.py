"""CBGMODD council + MIEVM convergent-mean ratification.

CBGMODD = seven sectoral seats, so no single sector dominates the signal:
    Citizen, Business, Government, Media, Organisation, Dignitary, Diplomat.

MIEVM ratification requires BOTH:
    * mean score >= threshold (default 8.5 / 10), and
    * convergence: spread across seats within a dispersion cap.

The dispersion test is what makes it "convergent mean" rather than just a
mean: a high average produced by a split council (some 10s, some 2s) is not a
consensus and is not ratified. This blocks unilateral or coalition capture —
seven happy seats and no outliers, or it does not pass.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from enum import Enum


class Seat(Enum):
    CITIZEN = "Citizen"
    BUSINESS = "Business"
    GOVERNMENT = "Government"
    MEDIA = "Media"
    ORGANISATION = "Organisation"
    DIGNITARY = "Dignitary"
    DIPLOMAT = "Diplomat"


ALL_SEATS = tuple(Seat)

DEFAULT_MIEVM_THRESHOLD = 8.5     # out of 10
DEFAULT_MAX_STDEV = 1.5           # convergence cap on inter-seat spread


@dataclass
class MIEVMResult:
    scores: dict[Seat, float]
    mean: float
    stdev: float
    threshold: float
    max_stdev: float
    ratified: bool
    reasons: list[str] = field(default_factory=list)

    def summary(self) -> str:
        verdict = "RATIFIED" if self.ratified else "NOT RATIFIED"
        s = f"MIEVM: mean={self.mean:.2f} (>= {self.threshold}) " \
            f"stdev={self.stdev:.2f} (<= {self.max_stdev}) [{verdict}]"
        if self.reasons:
            s += " — " + "; ".join(self.reasons)
        return s


def ratify(scores: dict[Seat, float],
           threshold: float = DEFAULT_MIEVM_THRESHOLD,
           max_stdev: float = DEFAULT_MAX_STDEV) -> MIEVMResult:
    missing = [s.value for s in ALL_SEATS if s not in scores]
    if missing:
        raise ValueError(f"missing council seats: {missing}")
    for seat, v in scores.items():
        if not 0.0 <= v <= 10.0:
            raise ValueError(f"seat {seat.value} score {v} out of [0,10]")

    values = [scores[s] for s in ALL_SEATS]
    mean = statistics.fmean(values)
    stdev = statistics.pstdev(values)
    reasons: list[str] = []
    if mean < threshold:
        reasons.append(f"mean below {threshold}")
    if stdev > max_stdev:
        reasons.append(f"council divergent (stdev {stdev:.2f} > {max_stdev})")
    ratified = not reasons
    return MIEVMResult(dict(scores), mean, stdev, threshold, max_stdev,
                       ratified, reasons)
