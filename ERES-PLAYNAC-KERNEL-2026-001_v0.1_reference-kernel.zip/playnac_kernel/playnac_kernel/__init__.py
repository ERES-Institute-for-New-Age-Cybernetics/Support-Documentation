"""PlayNAC KERNEL — reference implementation of the ERES resonance-governance
core. See kernel.Kernel for the decision pipeline.

Instrument: ERES-PLAYNAC-KERNEL-2026-001  v0.1  (reference kernel)
"""
from .kernel import Kernel, Proposal, Decision
from . import principles, por, council, homeostasis, execution, somt, table
from .execution import Tier, AuthToken
from .council import Seat
from .por import PoRFactors
from .somt import SOMTLog
from .homeostasis import BERA

__version__ = "0.1.0"
__instrument__ = "ERES-PLAYNAC-KERNEL-2026-001"

__all__ = [
    "Kernel", "Proposal", "Decision",
    "principles", "por", "council", "homeostasis", "execution",
    "somt", "table",
    "Tier", "AuthToken", "Seat", "PoRFactors", "SOMTLog", "BERA",
    "__version__", "__instrument__",
]
