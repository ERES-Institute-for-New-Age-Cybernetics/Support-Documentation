"""PlayNAC KERNEL — the governance orchestrator.

Decision pipeline for any proposed action, in order (fail-closed at each gate):

    1. PRINCIPLES  — three governing principles (conjunctive hard floor)
    2. PoR         — A x R x P x F admissibility gate
    3. MIEVM       — CBGMODD council convergent-mean ratification (>= 8.5)
    4. RCR         — runtime containment: live authorisation for the tier
    5. EXECUTE     — at the requested RAEC tier
    -  SOMT        — every stage outcome is appended to the provenance log
    -  BERA        — running health signal updated from the outcome

"Admissibility before Consistency": principles and PoR run BEFORE the council
ever scores merits. Humans remain the final constitutional layer — the kernel
can refuse, but a permit from the kernel is a licence to act, not a command;
enactment of T0/T1 tiers is still a human hand.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import por, council, execution, principles as principles_mod
from .homeostasis import BERA
from .somt import SOMTLog
from .execution import Tier, AuthToken


@dataclass
class Proposal:
    action_id: str
    description: str
    principles: principles_mod.PrinciplesReport
    por_factors: por.PoRFactors
    council_scores: dict[council.Seat, float]
    tier: Tier
    token: AuthToken | None = None


@dataclass
class Decision:
    action_id: str
    permitted: bool
    stage_failed: str | None
    trace: list[str] = field(default_factory=list)

    def summary(self) -> str:
        head = f"[{self.action_id}] {'PERMIT' if self.permitted else 'REFUSE'}"
        if self.stage_failed:
            head += f" @ {self.stage_failed}"
        return head + "\n  " + "\n  ".join(self.trace)


class Kernel:
    def __init__(self, log: SOMTLog | None = None, bera: BERA | None = None):
        self.log = log or SOMTLog()
        self.bera = bera or BERA()

    def decide(self, p: Proposal) -> Decision:
        trace: list[str] = []
        admissible = False
        ratified = False

        def fail(stage: str) -> Decision:
            self.log.append("decision", {"action": p.action_id,
                                         "permitted": False, "stage": stage})
            self.bera.record(admissible, ratified)
            return Decision(p.action_id, False, stage, trace)

        # 1. PRINCIPLES ------------------------------------------------------
        trace.append(p.principles.summary())
        self.log.append("principles", {"action": p.action_id,
                                        "passed": p.principles.passed})
        if not p.principles.passed:
            return fail("PRINCIPLES")

        # 2. PoR -------------------------------------------------------------
        por_res = por.evaluate(p.por_factors)
        trace.append(por_res.summary())
        admissible = por_res.admissible
        self.log.append("por", {"action": p.action_id,
                                "product": por_res.product,
                                "admissible": por_res.admissible})
        if not por_res.admissible:
            return fail("PoR")

        # 3. MIEVM (council) -------------------------------------------------
        miev = council.ratify(p.council_scores)
        trace.append(miev.summary())
        ratified = miev.ratified
        self.log.append("mievm", {"action": p.action_id,
                                  "mean": miev.mean, "stdev": miev.stdev,
                                  "ratified": miev.ratified})
        if not miev.ratified:
            return fail("MIEVM")

        # 4. RCR (containment) ----------------------------------------------
        rcr = execution.rcr_check(p.tier, p.token)
        trace.append(rcr.summary())
        self.log.append("rcr", {"action": p.action_id, "tier": p.tier.name,
                                "permitted": rcr.permitted})
        if not rcr.permitted:
            return fail("RCR")

        # 5. EXECUTE ---------------------------------------------------------
        trace.append(f"EXECUTE: tier={p.tier.name} authorised")
        self.log.append("decision", {"action": p.action_id,
                                     "permitted": True, "tier": p.tier.name})
        self.bera.record(admissible, ratified)
        return Decision(p.action_id, True, None, trace)
