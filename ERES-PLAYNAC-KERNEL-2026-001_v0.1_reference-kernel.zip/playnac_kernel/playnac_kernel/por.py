"""PoR — Proof-of-Resonance admissibility gate.

    PoR = A x R x P x F   (conjunctive)

        A = Alignment          (with declared baseline purpose)
        R = Resonance          (fit with the governance signal / community)
        P = Proportionality    (means scaled to stakes)
        F = Finality-Risk      (1 - risk of irreversible harm)

Each factor is a [0, 1] score. The gate MULTIPLIES them, so any single zero
factor blocks the action outright. This encodes the spec's rule
"Admissibility before Consistency": a proposal is not weighed on its merits
until it is first admissible. A high average cannot rescue a zeroed factor —
that is the whole point of a conjunctive gate versus a weighted sum.
"""
from __future__ import annotations

from dataclasses import dataclass

# Below this product, an action is inadmissible even with no hard zero.
DEFAULT_ADMISSIBILITY_FLOOR = 0.30


@dataclass(frozen=True)
class PoRFactors:
    alignment: float
    resonance: float
    proportionality: float
    finality_risk: float  # already expressed as (1 - risk), higher = safer

    def _validate(self) -> None:
        for name, v in self.as_dict().items():
            if not 0.0 <= v <= 1.0:
                raise ValueError(f"PoR factor {name}={v} out of [0,1]")

    def as_dict(self) -> dict[str, float]:
        return {
            "A": self.alignment,
            "R": self.resonance,
            "P": self.proportionality,
            "F": self.finality_risk,
        }


@dataclass
class PoRResult:
    factors: PoRFactors
    product: float
    admissible: bool
    zeroed: list[str]
    floor: float

    def summary(self) -> str:
        f = " x ".join(f"{k}={v:.2f}" for k, v in self.factors.as_dict().items())
        verdict = "ADMISSIBLE" if self.admissible else "INADMISSIBLE"
        if self.zeroed:
            verdict += f" (hard-zero: {', '.join(self.zeroed)})"
        return f"PoR: {f} => {self.product:.3f} [{verdict}] floor={self.floor:.2f}"


def evaluate(factors: PoRFactors,
             floor: float = DEFAULT_ADMISSIBILITY_FLOOR) -> PoRResult:
    factors._validate()
    d = factors.as_dict()
    zeroed = [k for k, v in d.items() if v == 0.0]
    product = 1.0
    for v in d.values():
        product *= v
    admissible = (not zeroed) and product >= floor
    return PoRResult(factors, product, admissible, zeroed, floor)
