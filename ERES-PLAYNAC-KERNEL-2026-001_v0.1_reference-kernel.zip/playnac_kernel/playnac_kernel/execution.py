"""RAEC (risk-adaptive execution) + RCR (runtime containment) + Paineology.

RAEC autonomy tiers (0..3), rising with risk-adaptivity:

    T0 OBSERVE   — no actuation; log only.
    T1 SUGGEST   — proposes; a human must enact.
    T2 ACT+CONFIRM — acts, but each act needs live authorisation (RCR).
    T3 ACT       — autonomous within an authorised envelope.

RCR (Runtime Containment Requirement): no execution proceeds without a live
authorisation token for the current tier. A stale or absent token contains
(halts) execution — "no execution without live-state authorisation."

Paineology = non-punitive remediation. On a breach the response is:
isolate -> downgrade one tier (never below T0) -> audit -> update.
It repairs and constrains; it does not destroy the agent.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class Tier(IntEnum):
    OBSERVE = 0
    SUGGEST = 1
    ACT_CONFIRM = 2
    ACT = 3


@dataclass(frozen=True)
class AuthToken:
    tier: Tier
    live: bool  # whether the token reflects current live state


@dataclass
class RCRResult:
    tier: Tier
    permitted: bool
    reason: str

    def summary(self) -> str:
        return (f"RCR: tier={self.tier.name} "
                f"{'PERMIT' if self.permitted else 'CONTAIN'} — {self.reason}")


def rcr_check(tier: Tier, token: AuthToken | None) -> RCRResult:
    if tier <= Tier.SUGGEST:
        # T0/T1 never actuate on their own; no live token required.
        return RCRResult(tier, True, "non-actuating tier")
    if token is None:
        return RCRResult(tier, False, "no authorisation token")
    if not token.live:
        return RCRResult(tier, False, "stale token (not live state)")
    if token.tier < tier:
        return RCRResult(tier, False,
                         f"token authorises only {token.tier.name}")
    return RCRResult(tier, True, "live authorisation present")


# ------------------------------------------------------- Paineology ----------
@dataclass
class RemediationOutcome:
    agent: str
    old_tier: Tier
    new_tier: Tier
    steps: list[str] = field(default_factory=list)

    def summary(self) -> str:
        return (f"PAINEOLOGY[{self.agent}]: {self.old_tier.name} -> "
                f"{self.new_tier.name} | " + " ; ".join(self.steps))


def remediate(agent: str, current_tier: Tier, breach: str) -> RemediationOutcome:
    new_tier = Tier(max(Tier.OBSERVE, current_tier - 1))
    steps = [
        f"isolate ({breach})",
        f"downgrade {current_tier.name}->{new_tier.name}",
        "audit trail written to SOMT",
        "baseline empirically updated",
    ]
    return RemediationOutcome(agent, current_tier, new_tier, steps)
