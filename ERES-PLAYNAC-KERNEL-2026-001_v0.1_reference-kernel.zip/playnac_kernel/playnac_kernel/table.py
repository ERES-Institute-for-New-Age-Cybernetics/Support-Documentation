"""PlayNAC TABLE — 17 existence-keyword rows x 7 subject-columns, +Row 18.

The TABLE is the linguistic substrate: user-groups assign core-linguistic
profiles across 17 rows (existence-keyword categories) and 7 subject columns.
Each cell can hold a Level 1/2/3 input = Question / Answer / Dictum.

Row 18 (MUSIC) is the measurement extension that *reads* the 17 rows — it is
not a content row but the layer that scores/measures them (see TALONICS
Row-18 RAW measurement layer in the wider corpus).

This module is intentionally a data structure only. The KERNEL's governance
logic never depends on specific row/column *labels* — those are configuration.
The defaults below are placeholders so the structure runs; swap in the
canonical keyword set from the corpus when wiring to real content.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum

N_ROWS = 17           # existence-keyword categories
N_COLS = 7            # subject columns
MUSIC_ROW = 18        # measurement extension (reads the 17)


class Level(IntEnum):
    QUESTION = 1
    ANSWER = 2
    DICTUM = 3


# Header frame: contestability is built into the columns (challenge/response).
COLUMN_HEADERS = (
    "User/GROUP SEARCH",
    "Question SCORE",
    "Answer RATING",
    "User/GROUP CHALLENGE",
    "User/GROUP RESPONSE",
    "Project (CPM/WBS/PERT)",
    "Purpose/Method (MyWay/HowWay)",
)


@dataclass
class Cell:
    row: int
    col: int
    level: Level | None = None
    content: str = ""

    def set(self, level: Level, content: str) -> "Cell":
        self.level = level
        self.content = content
        return self


class Table:
    def __init__(self, n_rows: int = N_ROWS, n_cols: int = N_COLS):
        if n_cols != len(COLUMN_HEADERS):
            # allow custom widths but keep headers aligned for the default
            pass
        self.n_rows = n_rows
        self.n_cols = n_cols
        self._cells: dict[tuple[int, int], Cell] = {
            (r, c): Cell(r, c)
            for r in range(1, n_rows + 1)
            for c in range(1, n_cols + 1)
        }
        # Row 18 measurement cells (one per column).
        self._music: dict[int, Cell] = {
            c: Cell(MUSIC_ROW, c) for c in range(1, n_cols + 1)
        }

    def cell(self, row: int, col: int) -> Cell:
        if row == MUSIC_ROW:
            return self._music[col]
        return self._cells[(row, col)]

    def filled(self) -> int:
        return sum(1 for c in self._cells.values() if c.level is not None)

    def completeness(self) -> float:
        total = self.n_rows * self.n_cols
        return self.filled() / total if total else 0.0
