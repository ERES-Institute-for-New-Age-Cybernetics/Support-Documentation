"""RHC (Resonant Harmony Cycle) + BERA (governance health signal).

BERA is the "organisational ECG": a health reading over recent governance
acts, NOT surveillance of agents. Here it summarises the running admissibility
/ ratification rate and flags when the system itself is drifting.

RHC is the self-correcting loop: given an agent whose behaviour has drifted
from its baseline purpose, it computes a correction that pulls the agent back
toward within 1 standard deviation of baseline. It corrects; it does not
punish (see paineology.py for the breach path).
"""
from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------- BERA --------
@dataclass
class BERAReading:
    n: int
    admissible_rate: float
    ratified_rate: float
    healthy: bool
    note: str = ""

    def summary(self) -> str:
        tag = "healthy" if self.healthy else "ATTENTION"
        return (f"BERA[{tag}]: n={self.n} "
                f"admissible={self.admissible_rate:.0%} "
                f"ratified={self.ratified_rate:.0%} {self.note}").strip()


class BERA:
    def __init__(self, healthy_floor: float = 0.5, window: int = 50):
        self._admissible: list[bool] = []
        self._ratified: list[bool] = []
        self.healthy_floor = healthy_floor
        self.window = window

    def record(self, admissible: bool, ratified: bool) -> None:
        self._admissible.append(admissible)
        self._ratified.append(ratified)
        self._admissible = self._admissible[-self.window:]
        self._ratified = self._ratified[-self.window:]

    def read(self) -> BERAReading:
        n = len(self._admissible)
        if n == 0:
            return BERAReading(0, 0.0, 0.0, True, "no acts yet")
        adm = sum(self._admissible) / n
        rat = sum(self._ratified) / n
        healthy = adm >= self.healthy_floor
        note = "" if healthy else "admissibility collapsing — inspect inputs"
        return BERAReading(n, adm, rat, healthy, note)


# ---------------------------------------------------------------- RHC ---------
@dataclass
class RHCCorrection:
    agent: str
    baseline: float
    sigma: float
    observed: float
    within_1sigma: bool
    corrected_target: float
    step: float
    notes: list[str] = field(default_factory=list)

    def summary(self) -> str:
        state = "in-band" if self.within_1sigma else "DRIFTED"
        return (f"RHC[{self.agent}]: observed={self.observed:.2f} "
                f"baseline={self.baseline:.2f}+/-{self.sigma:.2f} [{state}] "
                f"-> target={self.corrected_target:.2f} (step {self.step:+.2f})")


def correct(agent: str, baseline: float, sigma: float, observed: float,
            gain: float = 0.5) -> RHCCorrection:
    """Pull `observed` back toward the [baseline +/- sigma] band.

    If already within 1 sigma, no correction. Otherwise move toward the nearer
    band edge by `gain` fraction of the excess (a damped step, not a snap).
    """
    if sigma < 0:
        raise ValueError("sigma must be >= 0")
    lo, hi = baseline - sigma, baseline + sigma
    if lo <= observed <= hi:
        return RHCCorrection(agent, baseline, sigma, observed, True,
                             observed, 0.0, ["within 1 sigma; no action"])
    edge = hi if observed > hi else lo
    step = (edge - observed) * gain
    target = observed + step
    return RHCCorrection(agent, baseline, sigma, observed, False,
                         target, step, [f"drift {observed - edge:+.2f} beyond band"])
