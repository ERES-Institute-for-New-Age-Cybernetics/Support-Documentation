"""SOMT — append-only, hash-chained provenance log.

The "living memory of every governance act." Each entry carries the hash of
the previous entry, so any retroactive edit breaks the chain from that point
forward and is detectable by verify(). This is a tamper-evidence structure,
not an encryption or access-control one: it proves the record has not been
rewritten, nothing more.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field, asdict

GENESIS_PREV = "0" * 64


def _hash(prev: str, seq: int, ts: float, kind: str, payload: dict) -> str:
    blob = json.dumps(
        {"prev": prev, "seq": seq, "ts": ts, "kind": kind, "payload": payload},
        sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


@dataclass(frozen=True)
class SOMTEntry:
    seq: int
    ts: float
    kind: str
    payload: dict
    prev_hash: str
    entry_hash: str

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class SOMTLog:
    entries: list[SOMTEntry] = field(default_factory=list)
    _clock: object = time.time  # injectable for deterministic tests

    def append(self, kind: str, payload: dict) -> SOMTEntry:
        prev = self.entries[-1].entry_hash if self.entries else GENESIS_PREV
        seq = len(self.entries)
        ts = float(self._clock())
        h = _hash(prev, seq, ts, kind, payload)
        entry = SOMTEntry(seq, ts, kind, payload, prev, h)
        self.entries.append(entry)
        return entry

    def verify(self) -> tuple[bool, int | None]:
        """Return (ok, first_broken_seq). first_broken_seq is None if intact."""
        prev = GENESIS_PREV
        for e in self.entries:
            recomputed = _hash(prev, e.seq, e.ts, e.kind, e.payload)
            if recomputed != e.entry_hash or e.prev_hash != prev:
                return False, e.seq
            prev = e.entry_hash
        return True, None

    def __len__(self) -> int:
        return len(self.entries)
