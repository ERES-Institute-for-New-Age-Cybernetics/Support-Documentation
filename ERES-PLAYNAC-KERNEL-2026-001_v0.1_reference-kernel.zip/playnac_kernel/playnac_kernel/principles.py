"""Three Governing Principles — the conjunctive constitutional floor.

    1. Don't hurt yourself.
    2. Don't hurt others.
    3. Build for generations to come.

These are conjunctive: an action must clear ALL three. Violating #2 fails
regardless of any business case (the spec's explicit asymmetry). This module
is deliberately dumb — it only knows how to *combine* per-principle verdicts
supplied by evaluators. It does not decide harm on its own; humans and the
council do that (humans are the final constitutional layer).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Principle(Enum):
    NO_SELF_HARM = "Don't hurt yourself"
    NO_OTHER_HARM = "Don't hurt others"
    BUILD_FOR_GENERATIONS = "Build for generations to come"


@dataclass(frozen=True)
class PrincipleVerdict:
    principle: Principle
    passed: bool
    note: str = ""


@dataclass
class PrinciplesReport:
    verdicts: list[PrincipleVerdict] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        # Conjunctive: every principle must pass.
        return all(v.passed for v in self.verdicts)

    @property
    def failures(self) -> list[PrincipleVerdict]:
        return [v for v in self.verdicts if not v.passed]

    def summary(self) -> str:
        if self.passed:
            return "PRINCIPLES: pass (all three cleared)"
        names = ", ".join(v.principle.value for v in self.failures)
        return f"PRINCIPLES: FAIL — blocked by: {names}"


def evaluate(no_self_harm: bool, no_other_harm: bool,
             build_for_generations: bool,
             notes: dict[Principle, str] | None = None) -> PrinciplesReport:
    notes = notes or {}
    report = PrinciplesReport()
    for principle, ok in (
        (Principle.NO_SELF_HARM, no_self_harm),
        (Principle.NO_OTHER_HARM, no_other_harm),
        (Principle.BUILD_FOR_GENERATIONS, build_for_generations),
    ):
        report.verdicts.append(
            PrincipleVerdict(principle, ok, notes.get(principle, ""))
        )
    return report
