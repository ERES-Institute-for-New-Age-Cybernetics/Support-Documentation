# PlayNAC KERNEL — reference implementation

**Instrument:** ERES-PLAYNAC-KERNEL-2026-001 · **v0.1** · role: reference kernel

A runnable, dependency-free (stdlib-only) core of the ERES resonance-governance
stack. This is the **KERNEL** — the decision core — not the full PlayNAC app.
It implements the governance loop faithfully enough to test the stack's
behaviour; the TABLE labels and content keywords are left as configuration.

## Decision pipeline (`kernel.Kernel.decide`)

Fail-closed, in order:

1. **PRINCIPLES** — three governing principles, conjunctive hard floor
   (`principles.py`). Hurting others fails regardless of any other score.
2. **PoR** — `A × R × P × F` admissibility gate (`por.py`). Conjunctive:
   any zero factor blocks. *Admissibility before Consistency.*
3. **MIEVM** — CBGMODD 7-seat council convergent-mean ratification
   (`council.py`). Needs mean ≥ 8.5 **and** low inter-seat spread — a high
   average from a split council is not consensus.
4. **RCR** — runtime containment (`execution.py`). No actuation without a
   live authorisation token for the requested RAEC tier.
5. **EXECUTE** — at the requested RAEC tier (T0 OBSERVE … T3 ACT).

Every stage writes to **SOMT** (`somt.py`), an append-only hash-chained log
with tamper detection. **BERA** (`homeostasis.py`) tracks running health.

## Homeostasis & remediation

- **RHC** (`homeostasis.correct`) — damped drift-correction pulling an agent
  back toward within 1σ of baseline purpose.
- **Paineology** (`execution.remediate`) — non-punitive breach response:
  isolate → downgrade one tier (never below T0) → audit → update. Repairs and
  constrains; does not destroy.

## Constitutional note

Humans are the final constitutional layer. A kernel *permit* is a licence to
act, not a command; T0/T1 tiers still require a human hand to enact.

## Run

```bash
python demo.py          # end-to-end: 3 proposals + SOMT + BERA + RHC
python -m pytest -q     # 15 tests
```

## Layout

```
playnac_kernel/
  principles.py   three governing principles (conjunctive floor)
  por.py          A×R×P×F admissibility gate
  council.py      CBGMODD seats + MIEVM ratification
  homeostasis.py  BERA health signal + RHC drift correction
  execution.py    RAEC tiers + RCR containment + Paineology
  somt.py         append-only hash-chained provenance log
  table.py        17×7 (+Row-18 MUSIC) TABLE data model
  kernel.py       orchestrator
demo.py · tests/test_kernel.py
```

## Scope / honesty

This is a structural reference: it makes the governance *shape* executable and
testable. It does not ship the canonical 17-keyword row set, the GAIA/COI
resolution layer, or the TALONICS Row-18 measurement math — those plug into
`table.py` and the council/score inputs. Factor scores (PoR, council) are
inputs the kernel *combines*; it does not compute them from raw content.
