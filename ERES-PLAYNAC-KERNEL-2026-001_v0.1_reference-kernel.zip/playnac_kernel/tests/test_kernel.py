import pytest

from playnac_kernel import (
    Kernel, Proposal, Tier, AuthToken, Seat, PoRFactors, principles, SOMTLog,
)
from playnac_kernel import por, council, execution, homeostasis
from playnac_kernel.principles import Principle


def _seats(v):
    return {s: v for s in Seat}


def _clean_proposal(**over):
    base = dict(
        action_id="T",
        description="",
        principles=principles.evaluate(True, True, True),
        por_factors=PoRFactors(0.9, 0.8, 0.85, 0.95),
        council_scores=_seats(9.0),
        tier=Tier.ACT_CONFIRM,
        token=AuthToken(tier=Tier.ACT_CONFIRM, live=True),
    )
    base.update(over)
    return Proposal(**base)


# ---- principles -------------------------------------------------------------
def test_principles_conjunctive():
    assert principles.evaluate(True, True, True).passed
    assert not principles.evaluate(True, False, True).passed


def test_other_harm_blocks_regardless():
    k = Kernel()
    d = k.decide(_clean_proposal(
        principles=principles.evaluate(True, False, True),
        por_factors=PoRFactors(1.0, 1.0, 1.0, 1.0),
        council_scores=_seats(10.0),
    ))
    assert not d.permitted
    assert d.stage_failed == "PRINCIPLES"


# ---- PoR --------------------------------------------------------------------
def test_por_hard_zero_blocks():
    r = por.evaluate(PoRFactors(0.0, 1.0, 1.0, 1.0))
    assert not r.admissible
    assert "A" in r.zeroed


def test_por_floor():
    r = por.evaluate(PoRFactors(0.4, 0.4, 0.4, 0.4))  # product 0.0256
    assert not r.admissible
    r2 = por.evaluate(PoRFactors(0.8, 0.8, 0.8, 0.8))  # product 0.4096
    assert r2.admissible


def test_por_out_of_range():
    with pytest.raises(ValueError):
        por.evaluate(PoRFactors(1.2, 0.5, 0.5, 0.5))


# ---- MIEVM / council --------------------------------------------------------
def test_mievm_needs_mean_and_convergence():
    assert council.ratify(_seats(9.0)).ratified
    assert not council.ratify(_seats(8.0)).ratified  # below 8.5
    divergent = {s: 9.0 for s in Seat}
    divergent[Seat.MEDIA] = 2.0
    assert not council.ratify(divergent).ratified     # high spread


def test_mievm_missing_seat():
    scores = _seats(9.0)
    del scores[Seat.DIPLOMAT]
    with pytest.raises(ValueError):
        council.ratify(scores)


# ---- RCR / execution --------------------------------------------------------
def test_rcr_contains_stale_token():
    r = execution.rcr_check(Tier.ACT, AuthToken(Tier.ACT, live=False))
    assert not r.permitted


def test_rcr_contains_insufficient_tier():
    r = execution.rcr_check(Tier.ACT, AuthToken(Tier.ACT_CONFIRM, live=True))
    assert not r.permitted


def test_rcr_allows_nonactuating():
    assert execution.rcr_check(Tier.SUGGEST, None).permitted


def test_paineology_downgrades_not_destroys():
    out = execution.remediate("a", Tier.ACT, "breach")
    assert out.new_tier == Tier.ACT_CONFIRM
    floor = execution.remediate("a", Tier.OBSERVE, "breach")
    assert floor.new_tier == Tier.OBSERVE  # never below floor


# ---- RHC --------------------------------------------------------------------
def test_rhc_no_action_in_band():
    c = homeostasis.correct("a", 5.0, 1.0, 5.5)
    assert c.within_1sigma and c.step == 0.0


def test_rhc_corrects_toward_band():
    c = homeostasis.correct("a", 5.0, 1.0, 8.0, gain=0.5)
    assert not c.within_1sigma
    assert c.corrected_target < 8.0  # moved back toward the band


# ---- SOMT -------------------------------------------------------------------
def test_somt_chain_intact_and_tamper_detected():
    log = SOMTLog()
    log.append("x", {"v": 1})
    log.append("y", {"v": 2})
    ok, broken = log.verify()
    assert ok and broken is None
    # Tamper with a past entry's payload.
    object.__setattr__(log.entries[0], "payload", {"v": 999})
    ok2, broken2 = log.verify()
    assert not ok2 and broken2 == 0


# ---- full pipeline ----------------------------------------------------------
def test_clean_proposal_permits():
    k = Kernel()
    d = k.decide(_clean_proposal())
    assert d.permitted and d.stage_failed is None
    ok, _ = k.log.verify()
    assert ok
