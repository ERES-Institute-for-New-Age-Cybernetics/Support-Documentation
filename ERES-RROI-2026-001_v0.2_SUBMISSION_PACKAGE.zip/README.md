# ERES-RROI-2026-001 — Reasoned ROI (v0.2 Submission Package)

**Deposit title:** Reasoned ROI: The Offset Axiom and its PlayNAC Landing
**Instrument ID:** ERES-RROI-2026-001 (working ID — author-ratifiable)
**Version:** v0.2 DRAFT
**Date:** 2026-07-28
**Author:** Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221 — ERES Institute for New Age Cybernetics
**Status:** Author-side, pre-MIEVM. DVC-tagged.

## Abstract

Formalizes one axiom and its consequences for how an ERES PlayNAC user-group holds a computer, exchanges thought, and produces rateable output. The axiom generalizes the SROC "Offset" (§2) from contract-value to cognition-value: measured value exists only as discharge against a shared deficit. The distilled slot form (WHAT ⊗ HOW) ⊕ WHY, the Enable–Solidify–Contain lifecycle, Reasoned ROI (free = un-offset / earned = nonzero-offset), tool-as-currency-not-mastery, and thought-auditability are all derived from that single posit and marked as construct vs corpus.

## Keywords

Reasoned ROI, Offset axiom, No Unearned Resonance, SROC, ERES, PlayNAC, auditability, non-accrual, band-ownership, QuestionAnswer, RATABLE, New Age Cybernetics

## Contents (flat, 3 files)

- `ERES-RROI-2026-001_v0.2_Reasoned-ROI.md` — whitepaper MD master (Credits, References, License affixed)
- `eres_rroi_validation.py` — stdlib-only structural validation suite
- `README.md` — this file

## Running the validation suite

```
python3 eres_rroi_validation.py
```

Expected: `10 PASS / 0 FAIL / 4 SKIP`, exit code 0. No third-party dependencies. Tests structural rules only — each rule is both confirmed on a well-formed case and falsified on a violation (frozen-extractor, claimed-only, hoarded-mastery, surveillance). The 4 SKIPs are load-bearing and map to the whitepaper's §8 open items (P^3 gloss, primitive-choice, QuestionAnswer instrument, audit mechanism).

## Scope firewall

Defines no SROC §7 author-term. Modifies no SROC spec. Closes no S5. Claims nothing measured.

## Disposition

Pre-MIEVM. Not yet D.I.D.-cleared. This package is prepared for the author's MIEVM ensemble run.

## License

CC BY 4.0 (consistent with prior ERES Zenodo deposits); CC BY-SA 4.0 available on author ratification. See the whitepaper License section.

## Credits

Author-originated (J. A. Sprute). Structural formalization and validation prepared in author-directed dialogue with an AI assistant (Claude, Anthropic), which originated no axiom or token.
