#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_rroi_validation.py  —  ERES-RROI-2026-001 v0.2  structural validation suite

Tests STRUCTURAL RULES ONLY. Claims nothing measured. Defines no SROC §7 term,
modifies no SROC spec, closes no S5. Each test both CONFIRMS a well-formed case
and FALSIFIES its violation (a frozen-extractor / un-offset / accrual-to-holder
case must be rejected). SKIPs are load-bearing and map to the §8 OPEN items.

stdlib only. Exit 0 iff no FAIL.
"""

from dataclasses import dataclass

# ----------------------------------------------------------------------
# Model:  an Exchange fills an SROC-slot as  (WHAT ⊗ HOW) ⊕ WHY
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class Exchange:
    what: float        # WHAT  — resonant-energy content            (>=0)
    how: float         # HOW   — real-time diagnostic magnitude     (>=0; 0 = no rater)
    offset: float      # WHY   — cognitive price vs a shared deficit(>=0; 0 = free/un-offset)
    accrual: str       # where the return lands: "band" | "holder"
    audit_owner: str   # who owns the trail:      "band" | "holder" | "none"


# ---- primitives ------------------------------------------------------

def product_term(x: Exchange) -> float:
    """WHAT ⊗ HOW — product, not sum. Either factor at 0 collapses it."""
    return x.what * x.how

def slot_value(x: Exchange) -> float:
    """(WHAT ⊗ HOW) ⊕ WHY."""
    return product_term(x) + x.offset

def has_diagnostic(x: Exchange) -> bool:
    return x.how > 0

def is_offset(x: Exchange) -> bool:
    """A shared price was paid ⇒ a deficit exists to reason against."""
    return x.offset > 0

# RATABLE and AUDITABLE are computed independently from the same inputs;
# the WP claims they are one property seen from two sides — t07 tests coincidence.

def is_ratable(x: Exchange) -> bool:
    """An offset can be scored against it — but only if a rater verified it
    (measured, not asserted): a claimed price with no diagnostic does not rate."""
    return is_offset(x) and has_diagnostic(x)

def has_audit_record(x: Exchange) -> bool:
    """A verified offset leaves a re-checkable ledger entry."""
    return is_offset(x) and has_diagnostic(x)

def audit_valid(x: Exchange) -> bool:
    """Band-ownership guardrail: a trail that accrues to a holder is surveillance."""
    return has_audit_record(x) and x.audit_owner == "band"

def is_reasoned_roi(x: Exchange) -> bool:
    """Full gate: rateable + return lands on the band (non-accrual) + audit band-owned."""
    return is_ratable(x) and x.accrual == "band" and audit_valid(x)

def classify(x: Exchange) -> str:
    return "earned" if is_offset(x) else "free"


# ---- Enable–Solidify–Contain (CONSTRUCT — not SROC corpus) -----------

CANONICAL_ESC = {"WHAT": "Enable", "HOW": "Solidify", "WHY": "Contain"}

def esc_valid(mapping: dict) -> bool:
    """1:1 lifecycle binding: exactly the three roles onto the three verbs, canonically."""
    roles = {"WHAT", "HOW", "WHY"}
    verbs = {"Enable", "Solidify", "Contain"}
    if set(mapping.keys()) != roles:
        return False
    if set(mapping.values()) != verbs:        # bijection — no verb dropped or doubled
        return False
    return mapping == CANONICAL_ESC


# ----------------------------------------------------------------------
# Reference exchanges
# ----------------------------------------------------------------------

WELL_FORMED = Exchange(what=1.0, how=1.0, offset=1.0, accrual="band",   audit_owner="band")
FROZEN_EXTRACTOR = Exchange(what=1.0, how=1.0, offset=0.0, accrual="holder", audit_owner="holder")
CLAIMED_ONLY = Exchange(what=1.0, how=0.0, offset=1.0, accrual="band",   audit_owner="band")   # price asserted, no rater
HOARDED_MASTERY = Exchange(what=1.0, how=1.0, offset=1.0, accrual="holder", audit_owner="band") # skilled but pooled
SURVEILLANCE = Exchange(what=1.0, how=1.0, offset=1.0, accrual="band",   audit_owner="holder")  # trail held over people


# ----------------------------------------------------------------------
# Harness
# ----------------------------------------------------------------------

_pass = _fail = _skip = 0

def check(tid, desc, cond):
    global _pass, _fail
    tag = "PASS" if cond else "FAIL"
    if cond: _pass += 1
    else:    _fail += 1
    print(f"[{tag}] {tid}: {desc}")

def skip(tid, desc, open_ref):
    global _skip
    _skip += 1
    print(f"[SKIP] {tid}: {desc}  (OPEN {open_ref})")


# ---- t01  product form: either factor at 0 collapses the product term
check("t01", "WHAT⊗HOW is a product; either factor→0 collapses it, both nonzero survives",
      product_term(Exchange(0.0, 1.0, 1.0, "band", "band")) == 0.0
      and product_term(Exchange(1.0, 0.0, 1.0, "band", "band")) == 0.0
      and product_term(WELL_FORMED) > 0.0)

# ---- t02  RATABLE requires a nonzero offset (free ⇒ un-RATABLE)
check("t02", "nonzero offset ⇒ RATABLE; zero offset (free) ⇒ un-RATABLE",
      is_ratable(WELL_FORMED) and not is_ratable(FROZEN_EXTRACTOR))

# ---- t03  measured, not asserted: a claimed price with no rater does not rate
check("t03", "offset asserted but no diagnostic ⇒ NOT verified-RATABLE; diagnostic present ⇒ rates",
      (not is_ratable(CLAIMED_ONLY)) and is_ratable(WELL_FORMED))

# ---- t04  free / earned classification tracks offset magnitude
check("t04", "classify: offset==0 → 'free', offset>0 → 'earned'",
      classify(FROZEN_EXTRACTOR) == "free" and classify(WELL_FORMED) == "earned")

# ---- t05  non-accrual guardrail: return must land on the band
check("t05", "Reasoned ROI valid iff return accrues to band; accrual to holder rejected",
      is_reasoned_roi(WELL_FORMED) and not is_reasoned_roi(HOARDED_MASTERY))

# ---- t06  currency-not-mastery: skill is fine; UN-DISCHARGED (pooled) holding is not
check("t06", "skilled+discharged-to-band accepted; same skill pooled to holder rejected",
      is_reasoned_roi(WELL_FORMED)                      # skilled (what,how>0) + discharged
      and not is_reasoned_roi(HOARDED_MASTERY)          # identical skill, pooled ⇒ rejected
      and product_term(HOARDED_MASTERY) > 0)            # rejection is about pooling, not competence

# ---- t07  RATABLE ⟺ auditable (one property, two sides) across a case matrix
_matrix = [WELL_FORMED, FROZEN_EXTRACTOR, CLAIMED_ONLY, HOARDED_MASTERY, SURVEILLANCE]
check("t07", "RATABLE and has-audit-record coincide for every case",
      all(is_ratable(x) == has_audit_record(x) for x in _matrix))

# ---- t08  band-ownership of the audit trail (audit-as-accrual = surveillance)
check("t08", "audit band-owned ⇒ valid; audit held by a holder ⇒ rejected as surveillance",
      audit_valid(WELL_FORMED) and not audit_valid(SURVEILLANCE))

# ---- t09  Enable–Solidify–Contain is a canonical 1:1 binding
check("t09", "canonical ESC bijection accepted; dropped/doubled verb rejected",
      esc_valid(CANONICAL_ESC)
      and not esc_valid({"WHAT": "Enable", "HOW": "Solidify", "WHY": "Enable"})   # verb doubled
      and not esc_valid({"WHAT": "Solidify", "HOW": "Enable", "WHY": "Contain"})) # non-canonical

# ---- t10  end-to-end: well-formed passes every gate; frozen-extractor fails every gate
check("t10", "well-formed exchange passes all gates; frozen-extractor fails all",
      all([is_offset(WELL_FORMED), is_ratable(WELL_FORMED),
           audit_valid(WELL_FORMED), is_reasoned_roi(WELL_FORMED)])
      and not any([is_offset(FROZEN_EXTRACTOR), is_ratable(FROZEN_EXTRACTOR),
                   audit_valid(FROZEN_EXTRACTOR), is_reasoned_roi(FROZEN_EXTRACTOR)]))


# ---- load-bearing SKIPs → §8 OPEN items ------------------------------
skip("s01", "P^3 Semantic gloss — cannot test an ungloss token", "§8.1")
skip("s02", "primitive-choice A0 vs Reasoned ROI — a design posit, not a structural rule", "§8.2")
skip("s03", "QuestionAnswer measurement instrument — named, not specified; only its presence-flag is tested", "§8.5")
skip("s04", "audit-layer band-ownership MECHANISM — rule tested (t08), enforcement mechanism deferred upstream", "§8.4")


# ----------------------------------------------------------------------
print("-" * 60)
print(f"{_pass} PASS / {_fail} FAIL / {_skip} SKIP")
raise SystemExit(1 if _fail else 0)
