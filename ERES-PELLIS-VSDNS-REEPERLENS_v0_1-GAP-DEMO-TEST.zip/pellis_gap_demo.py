#!/usr/bin/env python3
"""
DETECT-shape demo for the REEPER-lens encapsulation of Pellis Spectral Thermodynamics
into ERES VOICE-SOUND-DNS. Computes the Pellis spectral GAP Delta = lambda0 - lambda1 off
a GENUINE 2x2 operator approaching an exceptional point (eigenvalue coalescence) — NOT a
stipulated spectrum (REEPER's anti-'stipulated-spectrum' discipline). As delta->0 the gap
closes, the collapse indicator K = 1/(Delta+eps) diverges, and the state leaves the
Universal Spectral Stability Region R = {Delta > Delta_min}. Pure stdlib.

Mapping (ANALOGICAL, non-transfer locked): the SAME computed gap serves two VOICE-SOUND-DNS
readouts — FIDELITY (Step 1: genuine voice-signature = open gap; spoof/degraded = closing gap)
and RESONANCE (Step 5: HELD = open gap inside R; TUNING = gap falling; collapse = gap->0).
"""
import cmath, math

def operator(gamma, delta):
    # genuine non-Hermitian 2x2: modes coalesce (exceptional point) as delta->0
    #   M = [[-gamma, 1], [-delta^2, -gamma]]   ->  eigenvalues -gamma +/- i*delta
    return [[-gamma, 1.0], [-(delta*delta), -gamma]]

def eig2(M):
    a, b = M[0]; c, d = M[1]
    tr = a + d; det = a*d - b*c
    disc = cmath.sqrt(tr*tr - 4*det)
    return (tr + disc)/2, (tr - disc)/2

def gap(M):
    l0, l1 = eig2(M)
    return abs(l0 - l1), l0, l1

GAMMA = 0.5
DELTA_MIN = 0.15          # minimum spectral protection gap (R boundary)
EPS = 1e-6

print(f"Pellis spectral GAP off a genuine operator  (gamma={GAMMA}, Delta_min={DELTA_MIN})")
print(f"{'delta':>7} {'gap Delta':>11} {'Re lambda':>10} {'K=1/(D+eps)':>13}  state")
print("-"*60)
for delta in [0.80, 0.50, 0.30, 0.20, 0.15, 0.08, 0.03, 0.005, 0.0]:
    M = operator(GAMMA, delta)
    D, l0, l1 = gap(M)
    K = 1.0/(D + EPS)
    inR = D > DELTA_MIN
    state = "R: HELD (stable)" if inR else ("boundary" if abs(D-DELTA_MIN)<1e-9 else "COLLAPSE (Delta->0)")
    print(f"{delta:>7.3f} {D:>11.4f} {l0.real:>10.3f} {K:>13.1f}  {state}")

print("\nFIDELITY  read: genuine signature -> gap open (HELD); spoof/degraded -> gap closes (COLLAPSE) -> reject")
print("RESONANCE read: HELD = Delta>Delta_min ; TUNING = Delta falling toward Delta_min ; collapse = Delta->0")
print("M/N INVARIANT: K may re-order which dashboards/depths open (M, triage) — it NEVER gates the N-floor (HFVN-3).")
