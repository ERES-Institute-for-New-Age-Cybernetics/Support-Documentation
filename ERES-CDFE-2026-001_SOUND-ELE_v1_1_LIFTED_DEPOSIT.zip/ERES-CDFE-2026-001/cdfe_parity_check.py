#!/usr/bin/env python3
"""
cdfe_parity_check.py -- faithful-port proof for ERES-CDFE-2026-001 "SOUND-ELE" v1.0.

Runs the v0.2 numpy engine (favors_cov.FavorsCov) and the v1.0 stdlib engine
(cdfe_engine.FavorsCov) on IDENTICAL verdict histories; asserts n_eff agrees to
< 1e-9 and every band matches. This shows v1.0 removed numpy, not behaviour.

The v0.2 engine + numpy are DEV-TIME dependencies only. If either is absent this
script prints an explanation and exits 0 (the shipped v1.0 engine is stdlib-only).
To reproduce: place favors_cov.py (v0.2) on the path, `pip install numpy`, and set
CDFE_V02_DIR to the v0.2 folder if it is not a sibling.
"""
import os, sys, random

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
for cand in (os.environ.get("CDFE_V02_DIR"),
             os.path.join(os.path.dirname(os.path.abspath(__file__)), "v02"),
             "/home/claude/cdfe/v02/ERES-CDFE-2026-001"):
    if cand and os.path.isdir(cand):
        sys.path.insert(0, cand)

import cdfe_engine as v10
try:
    import numpy  # noqa: F401
    import favors_cov as v02
except Exception as e:
    print(f"[parity] v0.2 engine or numpy unavailable ({e.__class__.__name__}). "
          f"Shipped v1.0 engine is stdlib-only; parity is a dev-time check. Skipping.")
    sys.exit(0)


def build(cls, seed, k, n_items, r, theta=2.5, tau=8.0):
    rng = random.Random(seed)
    eng = cls(theta=theta, tau=tau)
    names = [f"c{j}" for j in range(k)]
    pf = (1.0 + r) / 2.0
    for i in range(n_items):
        latent = rng.choice([-1, 1])
        for nm in names:
            v = latent if rng.random() < pf else rng.choice([-1, 1])
            eng.record(f"i{i:04d}", nm, v)
    for nm in names:
        eng.record("PROBE", nm, +1)
    return eng, "PROBE"


worst = 0.0
cases = [(s, k, n, r) for s in (1, 2, 3) for k in (2, 3, 4)
         for n in (12, 150) for r in (0.0, 0.6, 0.9)]
for (s, k, n, r) in cases:
    e0, p0 = build(v02.FavorsCov, s, k, n, r)
    e1, p1 = build(v10.FavorsCov, s, k, n, r)
    worst = max(worst, abs(float(e0.n_eff(p0)) - e1.n_eff(p1)))
    assert e0.band(p0) == e1.band(p1), f"band mismatch at {(s,k,n,r)}"

print(f"[parity] {len(cases)} cases  worst |n_eff_v0.2 - n_eff_v1.0| = {worst:.2e}  bands: all match")
print("[parity] PASS" if worst < 1e-9 else "[parity] FAIL")
sys.exit(0 if worst < 1e-9 else 1)
