#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cdfe_upi_test.py -- ERES-CDFE-TEST-2026-001 . CDFE-UPI TEST harness
Release: "SOUND-ELE" v1.0   .   zero-dependency stdlib   .   deterministic

Instrument under test : ERES-CDFE-2026-001 (cdfe_engine.py :: FavorsCov)
Primitive under test   : COVARIANCE as the equilibrium operator of the rating stack.

[A] Seven falsifiable tests on the real engine (each could fail):
    T1 DAMPING       co-moving channels do NOT double-count (r=1 -> n_eff -> 1)
    T2 INDEPENDENCE  decorrelated channels ARE credited (r~0, deep -> n_eff -> 2)
    T3 CONSERVATIVE  thin history yields LOWER n_eff than deep (prior pull)
    T4 REVERSIBILITY discovered common mode DEMOTES a FLOOR item
    T5 AURA OFF-AXIS salience never enters n_eff; band invariant to aura
    T6 UPI/G         co-moving UPI/G validation is <1.5 effective tests, not 2
    T7 UPPER BOUND   n_eff bounded by count and monotone in correlation

[B] Worked application -- Dr. Pellis's reported UPI-vs-G correlations
    (closed-form, deterministic). Every value is an EFFECTIVE-INDEPENDENCE
    ESTIMATE UNDER THE CDFE's ASSUMPTIONS -- NOT a statement about the UPI's
    evidentiary strength. Dr. Pellis characterised the correlations as
    "substantially" accurate (corr > 0.87) and has REQUESTED, not yet performed,
    a math/statistics audit of this engine. He endorses the citation only.

[C] Empirical claims -- SKIPPED, not silently passed. They go green only on
    real held-out data through a >=5-node MIEVM.

Run: python3 cdfe_upi_test.py   (exit 0 = all falsifiable checks pass)
Requires cdfe_engine.py on the path. Standard library only. No numpy.
"""

from __future__ import annotations
import math
import random
import sys

import cdfe_engine as cdfe

SEED = 20260823  # date-anchored, recorded for provenance
_p, _f, _s = [], [], []


def check(tid, claim, ok, readout=""):
    (_p if ok else _f).append(tid)
    print(f"  [{'PASS' if ok else 'FAIL'}] {tid}  {claim}")
    if readout:
        print(f"         {readout}")


def skip(tid, reason):
    _s.append(tid)
    print(f"  [SKIP] {tid}  {reason}")


# --------------------------------------------------------------------------- #
# Verdict-history synthesis (stdlib RNG)
# --------------------------------------------------------------------------- #
def correlated_pair(n_items, r, seed):
    rng = random.Random(seed)
    p_agree = (1.0 + r) / 2.0
    a = [rng.choice([-1, 1]) for _ in range(n_items)]
    b = [a[i] if rng.random() < p_agree else -a[i] for i in range(n_items)]
    return a, b


def correlated_batch(n_items, r, seed, k):
    rng = random.Random(seed)
    p_follow = (1.0 + r) / 2.0
    latent = [rng.choice([-1, 1]) for _ in range(n_items)]
    out = []
    for i in range(n_items):
        row = []
        for _ in range(k):
            row.append(latent[i] if rng.random() < p_follow else rng.choice([-1, 1]))
        out.append(row)
    return out


def two_channel_engine(n_items, r, seed, theta=2.5, tau=8.0,
                       names=("proc_A", "proc_B")):
    eng = cdfe.FavorsCov(theta=theta, tau=tau)
    a, b = correlated_pair(n_items, r, seed)
    for i in range(n_items):
        eng.record(f"item_{i:04d}", names[0], a[i])
        eng.record(f"item_{i:04d}", names[1], b[i])
    eng.record("PROBE", names[0], +1)
    eng.record("PROBE", names[1], +1)
    return eng, "PROBE"


def observed_corr(eng, p, q):
    M, P = eng._verdict_matrix()
    ia, ib = P.index(p), P.index(q)
    va = [row[ia] for row in M if row[ia] is not None and row[ib] is not None]
    vb = [row[ib] for row in M if row[ia] is not None and row[ib] is not None]
    return cdfe._pearson(va, vb)


# --------------------------------------------------------------------------- #
print("=" * 78)
print("CDFE-UPI TEST -- ERES-CDFE-TEST-2026-001 'SOUND-ELE' v1.0")
print(f"engine: cdfe_engine.FavorsCov   seed(provenance): {SEED}   stdlib-only")
print("=" * 78)

print("\n[A] Falsifiable tests on the real engine")

# T1 damping
eng, pr = two_channel_engine(400, 0.999, seed=1)
n = eng.n_eff(pr)
check("T1", "co-moving channels do not double-count", n < 1.15,
      f"r_obs={observed_corr(eng,'proc_A','proc_B'):.3f}  n_eff={n:.3f}  (expect ->1)")

# T2 independence
eng, pr = two_channel_engine(1200, 0.0, seed=2)
n = eng.n_eff(pr)
check("T2", "decorrelated channels are credited", n > 1.7,
      f"r_obs={observed_corr(eng,'proc_A','proc_B'):.3f}  n_eff={n:.3f}  (expect ->2)")

# T3 conservative prior
thin, pt = two_channel_engine(3, 0.0, seed=3)
deep, pd = two_channel_engine(1200, 0.0, seed=3)
nt, nd = thin.n_eff(pt), deep.n_eff(pd)
check("T3", "thin history is pulled toward correlated (slow Floor)", nt < nd,
      f"n_eff(thin N=3)={nt:.3f}  <  n_eff(deep N=1200)={nd:.3f}")

# T4 reversibility
eng = cdfe.FavorsCov(theta=2.5, tau=1.0)
names = ("c1", "c2", "c3")
for i, row in enumerate(correlated_batch(60, 0.0, seed=4, k=3)):
    for nm, v in zip(names, row):
        eng.record(f"e_{i:03d}", nm, v)
for nm in names:
    eng.record("PROBE", nm, +1)
band_before, neff_before = eng.band("PROBE"), eng.n_eff("PROBE")
for i, row in enumerate(correlated_batch(300, 0.985, seed=5, k=3)):
    for nm, v in zip(names, row):
        eng.record(f"c_{i:03d}", nm, v)
band_after, neff_after = eng.band("PROBE"), eng.n_eff("PROBE")
check("T4", "discovered common mode demotes a FLOOR item",
      band_before == "FLOOR" and band_after != "FLOOR" and neff_after < neff_before,
      f"{band_before}(n_eff={neff_before:.3f}) -> {band_after}(n_eff={neff_after:.3f})")

# T5 aura off-axis
eng = cdfe.FavorsCov()
eng.add_procedure("some_proc")
eng.set_salience("GHOST", 9.9)
n0, band = eng.n_eff("GHOST"), eng.band("GHOST")
eng.set_salience("GHOST", 0.0)
n1 = eng.n_eff("GHOST")
check("T5", "aura is pointer-only, never enters n_eff",
      n0 == 0.0 and band == "RESONANCE/OFF-AXIS" and n0 == n1,
      f"band={band}  n_eff(aura=9.9)={n0:.3f}  n_eff(aura=0)={n1:.3f}")

# T6 UPI/G adjudication
eng, pr = two_channel_engine(800, 0.90, seed=6, names=("UPI", "G_golden_fractal"))
r_obs = observed_corr(eng, "UPI", "G_golden_fractal")
n = eng.n_eff(pr)
check("T6", "co-moving UPI/G gives effective independent COUNT < 1.5 (not 'tests')",
      r_obs > 0.87 and n < 1.5,
      f"r_obs={r_obs:.3f} (>0.87)  n_eff^(V)={n:.3f}  (effective statistical dimensionality < 1.5)")

# T7 upper bound + monotone
seq = []
for r in (0.0, 0.3, 0.6, 0.9, 0.999):
    e, p = two_channel_engine(1000, r, seed=7)
    seq.append(e.n_eff(p))
bounded = all(x <= 2.0 + 1e-9 for x in seq)
monotone = all(seq[i] >= seq[i + 1] - 0.03 for i in range(len(seq) - 1))
check("T7", "n_eff bounded by count and monotone in correlation", bounded and monotone,
      "n_eff by r[0,.3,.6,.9,.999] = " + ", ".join(f"{x:.2f}" for x in seq))

# --------------------------------------------------------------------------- #
print("\n[B] Worked application -- Dr. Pellis's reported UPI-vs-G correlations")
print("    (effective statistical independence COUNT under CDFE assumptions; NOT an")
print("     evidentiary-strength statement, and NOT '1.43 independent tests')")
print(f"    {'channel pair':<32}{'reported r':>11}{'n_eff (CDFE)':>15}")
for label, rr in [
    ("Japan", 0.93), ("Indonesia", 0.95), ("California", 0.76),
    ("Mediterranean", 0.71), ("Headline corr>0.87 (floor)", 0.87),
    ("Aggregate r~=0.90", 0.90),
]:
    print(f"    {label:<32}{rr:>11.2f}{cdfe.n_eff_two_channel(rr):>15.4f}")
print("    r_reported > 0.87 is the value to PRESERVE from the manuscript;")
print("    r = 0.90 is ILLUSTRATIVE only (Pellis 21 Aug 2026, sec. 1).")
print("    Pellis-approved reading: this is an effective statistical INDEPENDENCE")
print("    COUNT / effective dimensionality of the validation information under the")
print("    assumed correlation model -- NOT a literal count of independent tests.")
print("    Strong INTERNAL consistency of two constructs of one program; weaker")
print("    EXTERNAL corroboration. n_eff here is n_eff^(V) (verdict covariance),")
print("    a proxy for error covariance (Assumption A1) -- n_eff^(E) is stronger.")

# --------------------------------------------------------------------------- #
print("\n[B2] Error-covariance path -- n_eff^(E) (the SOUND-tier quantity, Pellis sec.5-6)")
print("     Structural demo on a SYNTHETIC error series: separates common physical")
print("     signal from common prediction error. On REAL y_true this is E1 (SKIP).")
_er = random.Random(SEED)
y_true = [_er.gauss(0, 1) for _ in range(500)]
# two predictors with partially shared error (shared component weight w)
w = 0.5
shared = [_er.gauss(0, 1) for _ in range(500)]
e_a = [w * shared[i] + (1 - w) * _er.gauss(0, 1) for i in range(500)]
e_b = [w * shared[i] + (1 - w) * _er.gauss(0, 1) for i in range(500)]
neff_E = cdfe.n_eff_from_error_series(e_a, e_b)
r_e = cdfe._pearson(e_a, e_b)
# closed-form check: n_eff^(E) must equal the two-channel identity at r_e
check("T8", "n_eff^(E) from error series matches the closed form (computed, not stipulated)",
      abs(neff_E - cdfe.n_eff_two_channel(max(-1.0, min(1.0, r_e)))) < 1e-9,
      f"r_e={r_e:.3f}  n_eff^(E)={neff_E:.3f}  (structure only -- synthetic errors cannot corroborate)")

# --------------------------------------------------------------------------- #
print("\n[C] Empirical claims -- SKIPPED (go green only on real data via MIEVM)")
skip("E1", "SOUND: n_eff^(E) on REAL error series (UPI vs one INDEPENDENT precursor "
     "operator -- ETAS/b-value/RTL/AMR -- held-out events, frozen params, explicit null, "
     "with an UNCERTAINTY INTERVAL on n_eff, not a point estimate)")
skip("E2", "CDFE math/statistics audit (derivation, implementation, assumptions, "
     "verdict-covariance vs error-covariance behaviour) -- requested by Dr. Pellis, not yet done")
skip("E3", "BEST: prospective pre-registered future events + n_eff->2 at power "
     "+ >=5-node MIEVM >= 9.0")

# --------------------------------------------------------------------------- #
print("\n" + "=" * 78)
print(f"RESULT: {len(_p)} PASS . {len(_f)} FAIL . {len(_s)} SKIP")
print("Honest scope: verdict-cov proxies error-cov; every n_eff is an UPPER BOUND")
print("on true independence. Mechanism demonstrated, no claim certified.")
print("=" * 78)
if _f:
    print("FAILED:", ", ".join(_f))
    sys.exit(1)
sys.exit(0)
