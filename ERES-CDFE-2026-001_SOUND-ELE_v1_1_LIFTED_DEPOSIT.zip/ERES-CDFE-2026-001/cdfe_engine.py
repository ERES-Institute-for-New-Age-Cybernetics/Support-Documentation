#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cdfe_engine.py -- ERES-CDFE-2026-001 . Covariance-Discounted Floor Engine
Release: "SOUND-ELE" v1.0

Zero-dependency stdlib port of the v0.2 engine (favors_cov.py :: FavorsCov).
Behaviour is preserved term-for-term; numpy is replaced by an in-file Jacobi
eigensolver and Pearson routine. Parity against the v0.2 numpy engine is proven
by cdfe_parity_check.py (n_eff agrees to < 1e-9 on identical verdict histories).

PRIMITIVE
    Covariance is the equilibrium operator of the ERES rating stack. It converts
    a count of confirmations into a count of INDEPENDENT confirmations and
    refuses credit for the difference. The disequilibrium every verification
    system fails into is counting an echo as a chorus; covariance prices the
    echo at zero.

CORE QUANTITY
    n_eff = ( sum sqrt(lambda_i) )^2 / sum(lambda_i)  -- Galwey (2009) effective
    number over the correlation eigenspectrum of the procedures that PASSED an
    item. n_eff = 1 when all passing procedures perfectly co-move; it rises
    toward the raw count only as they decorrelate.

TWO EFFECTIVE COUNTS (per Dr. Pellis, 21 Aug 2026, sec. 9)
    n_eff^(V) -- computed from VERDICT covariance (FavorsCov.n_eff). What the
                 running engine reports from a pass/fail history.
    n_eff^(E) -- computed from PREDICTION-ERROR covariance against ground truth
                 (n_eff_from_error_series). Methodologically STRONGER; this is
                 the SOUND-tier quantity. Requires y_true, so it cannot be run
                 on a verdict history alone.
    Assumption A1 (formal, not an identity): Cov(V_i,V_j) ~= Cov(E_i,E_j). Its
    validity depends on how verdicts are generated from continuous errors. The
    engine reports n_eff^(V); n_eff^(E) is preferred wherever y_true exists.

HONEST SCOPE (in code, not just the paper)
    Verdict covariance is a PROXY for error covariance. Every n_eff is an
    UPPER BOUND on true effective independence, tightening as history lengthens.
    A running engine demonstrates the MECHANISM; it certifies no claim true.
    "No common mode found yet" is never "none exists."

License: CCAL v2.1 / CC-BY 4.0. Foundational-math attribution per README.
"""

from __future__ import annotations
import math
from typing import Dict, List, Sequence, Tuple

__all__ = [
    "FavorsCov",
    "jacobi_eig", "jacobi_eigenvalues",
    "n_eff_from_corr", "n_eff_two_channel",
    "n_eff_from_error_series",
]


def jacobi_eig(mat, max_sweeps=100, tol=1e-14):
    """Eigenvalues and eigenvectors of a real symmetric matrix (cyclic Jacobi).
    Returns (eigvals, eigvecs) with eigvecs[k] the k-th eigenvector (column)."""
    n = len(mat)
    a = [[float(mat[i][j]) for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            if abs(a[i][j] - a[j][i]) > 1e-9:
                raise ValueError("jacobi_eig: matrix must be symmetric")
    v = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    if n == 1:
        return [a[0][0]], [[1.0]]
    for _ in range(max_sweeps):
        off = math.sqrt(sum(a[i][j] ** 2 for i in range(n) for j in range(n) if i != j))
        if off < tol:
            break
        for p in range(n - 1):
            for q in range(p + 1, n):
                if abs(a[p][q]) < 1e-300:
                    continue
                theta = (a[q][q] - a[p][p]) / (2.0 * a[p][q])
                t = math.copysign(1.0, theta) / (abs(theta) + math.sqrt(theta * theta + 1.0))
                c = 1.0 / math.sqrt(t * t + 1.0)
                s = t * c
                for k in range(n):
                    akp, akq = a[k][p], a[k][q]
                    a[k][p] = c * akp - s * akq
                    a[k][q] = s * akp + c * akq
                for k in range(n):
                    apk, aqk = a[p][k], a[q][k]
                    a[p][k] = c * apk - s * aqk
                    a[q][k] = s * apk + c * aqk
                for k in range(n):
                    vkp, vkq = v[k][p], v[k][q]
                    v[k][p] = c * vkp - s * vkq
                    v[k][q] = s * vkp + c * vkq
    eigvals = [a[i][i] for i in range(n)]
    # v[i][k] is component i of eigenvector k (column k). Return v as-is so that
    # A[i][j] = sum_k v[i][k] * eigvals[k] * v[j][k].
    return eigvals, v


def jacobi_eigenvalues(mat):
    return sorted(jacobi_eig(mat)[0], reverse=True)


def _nearest_psd(A):
    """Project a symmetric matrix to the nearest PSD correlation-ish matrix.
    stdlib equivalent of the v0.2 numpy _nearest_psd."""
    n = len(A)
    B = [[(A[i][j] + A[j][i]) / 2.0 for j in range(n)] for i in range(n)]
    w, V = jacobi_eig(B)
    w = [x if x > 0.0 else 0.0 for x in w]
    B2 = [[sum(V[i][k] * w[k] * V[j][k] for k in range(n)) for j in range(n)]
          for i in range(n)]
    d = [math.sqrt(B2[i][i]) if B2[i][i] > 1e-12 else math.sqrt(1e-12) for i in range(n)]
    for i in range(n):
        for j in range(n):
            B2[i][j] = B2[i][j] / (d[i] * d[j])
    for i in range(n):
        B2[i][i] = 1.0
    return B2


def _pearson(va, vb):
    m = len(va)
    ma = sum(va) / m
    mb = sum(vb) / m
    da = [x - ma for x in va]
    db = [x - mb for x in vb]
    sa = math.sqrt(sum(x * x for x in da))
    sb = math.sqrt(sum(x * x for x in db))
    if sa == 0.0 or sb == 0.0:
        return 0.0
    return sum(da[i] * db[i] for i in range(m)) / (sa * sb)


def n_eff_two_channel(r):
    """Two channels at correlation r: eigenvalues (1+r),(1-r) ->
    n_eff = (sqrt(1+r)+sqrt(1-r))^2 / 2.  r=0 -> 2 ; |r|->1 -> 1."""
    if not -1.0 <= r <= 1.0:
        raise ValueError("n_eff_two_channel: r must lie in [-1, 1]")
    return (math.sqrt(1.0 + r) + math.sqrt(1.0 - r)) ** 2 / 2.0


def n_eff_from_corr(corr):
    """Galwey effective number over a correlation matrix."""
    if len(corr) == 0:
        return 0.0
    eig = jacobi_eig(corr)[0]
    denom = sum(eig)
    if denom <= 0:
        return 0.0
    numer = sum(math.sqrt(x) for x in eig if x > 0.0) ** 2
    return numer / denom


def n_eff_from_error_series(errors_a, errors_b):
    """n_eff^(E): the SOUND-tier effective count, computed from PREDICTION-ERROR
    covariance against ground truth (Pellis 21 Aug 2026, sec. 5-6).

        e_i(t) = yhat_i(t) - y_true(t)  for i in {a, b}
        r_e    = corr(e_a, e_b)
        n_eff  = ( sqrt(1+r_e) + sqrt(1-r_e) )^2 / 2

    This separates a common PHYSICAL signal from common prediction ERROR, which
    raw verdict correlation cannot. It is methodologically stronger than the
    verdict-based n_eff^(V) and is the quantity the SOUND experiment reports.
    Two error series of equal length are required (both aligned to y_true)."""
    if len(errors_a) != len(errors_b):
        raise ValueError("n_eff_from_error_series: error series must be equal length")
    if len(errors_a) < 2:
        raise ValueError("n_eff_from_error_series: need >= 2 aligned errors")
    r_e = _pearson(list(errors_a), list(errors_b))
    return n_eff_two_channel(max(-1.0, min(1.0, r_e)))


class FavorsCov:
    def __init__(self, theta=2.5, tau=8.0, rho_conservative=0.95):
        # theta: EarnedPath promotion threshold on n_eff (into the 1% Floor)
        # tau:   history-depth shrinkage constant; young history (N << tau) is
        #        pulled toward the conservative near-fully-correlated prior, so
        #        the Floor grows SLOWEST when the covariance record is thinnest.
        # rho_conservative: "assume correlated until proven independent" prior.
        self.theta = theta
        self.tau = tau
        self.rho_conservative = rho_conservative
        self.procedures = []            # ordered channel names
        self.items = {}                 # item -> {proc: +1/-1}
        self.salience = {}              # item -> aura pointer (NON-WARRANT)

    def add_procedure(self, name):
        if name not in self.procedures:
            self.procedures.append(name)

    def record(self, item, proc, verdict):
        """verdict: +1 procedure passed the item, -1 it failed it."""
        self.add_procedure(proc)
        self.items.setdefault(item, {})[proc] = int(verdict)

    def set_salience(self, item, value):
        """Aura = pointer only. Flags where to look. Never enters n_eff."""
        self.salience[item] = float(value)

    def _verdict_matrix(self):
        """items x procedures matrix; None where a procedure was not applied."""
        P = self.procedures
        rows = []
        for _, verds in sorted(self.items.items()):
            rows.append([float(verds[p]) if p in verds else None for p in P])
        return rows, P

    def _correlation(self):
        """Pairwise verdict correlation among procedures over co-applied items,
        projected to nearest PSD. No shared history -> conservative prior."""
        M, P = self._verdict_matrix()
        k = len(P)
        R = [[1.0 if i == j else 0.0 for j in range(k)] for i in range(k)]
        for a in range(k):
            for b in range(a + 1, k):
                va, vb = [], []
                for row in M:
                    if row[a] is not None and row[b] is not None:
                        va.append(row[a]); vb.append(row[b])
                if len(va) >= 2:
                    va_std = _pearson(va, va)  # 1.0 unless constant -> 0.0
                    vb_std = _pearson(vb, vb)
                    if va_std == 0.0 or vb_std == 0.0:
                        r = 0.0
                    else:
                        r = _pearson(va, vb)
                else:
                    r = self.rho_conservative     # unknown -> assume correlated
                R[a][b] = R[b][a] = r
        return _nearest_psd(R), P

    def _shrunk_correlation(self):
        """Blend observed R toward the conservative all-correlated prior J,
        weight alpha = tau/(tau+N) decaying as history deepens."""
        R, P = self._correlation()
        N = len(self.items)
        alpha = self.tau / (self.tau + N)          # ->1 young, ->0 mature
        k = len(P)
        Rs = [[0.0] * k for _ in range(k)]
        for i in range(k):
            for j in range(k):
                prior = 1.0 if i == j else self.rho_conservative
                Rs[i][j] = (1 - alpha) * R[i][j] + alpha * prior
        return _nearest_psd(Rs), P, alpha

    def n_eff(self, item):
        """Effective-independent count of the procedures that PASSED this item."""
        Rs, P, _ = self._shrunk_correlation()
        passing = [p for p, v in self.items.get(item, {}).items() if v == +1]
        if not passing:
            return 0.0
        idx = [P.index(p) for p in passing]
        sub = [[Rs[i][j] for j in idx] for i in idx]
        lam = [x if x > 0.0 else 0.0 for x in jacobi_eig(sub)[0]]
        s = sum(lam)
        if s <= 0:
            return 0.0
        return (sum(math.sqrt(x) for x in lam) ** 2) / s

    def band(self, item):
        x = self.n_eff(item)
        if x >= self.theta:
            return "FLOOR"                # promoted (the 1%)
        if x > 0:
            return "ASPIRATION"          # rising middle band (the 2%)
        return "RESONANCE/OFF-AXIS"      # x=0: pointer-only, no earned verification

    def recompute(self):
        """Re-derive every reading from current history. Promotion AND demotion
        both fall out -- reversibility is not a special case."""
        _, _, alpha = self._shrunk_correlation()
        return {
            "shrink_alpha": round(alpha, 3),
            "n_items": len(self.items),
            "items": {
                it: {"n_eff": round(self.n_eff(it), 3),
                     "band": self.band(it),
                     "aura": self.salience.get(it, 0.0)}
                for it in sorted(self.items)
            },
        }


if __name__ == "__main__":
    for r in (0.0, 0.5, 0.87, 0.90, 0.93, 0.95, 0.999):
        print("r=%6s  n_eff_2ch=%.4f" % (r, n_eff_two_channel(r)))
