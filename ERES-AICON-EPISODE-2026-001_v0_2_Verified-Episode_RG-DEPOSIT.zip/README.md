# ERES-AICON-EPISODE-2026-001 · v0.2 — The Verified Episode

**Admit/Attest Binding as the Unit of Comparison for AI Constitutions**
Joseph A. Sprute (ERES Maestro) · ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221
License: CCAL v2.1 / CC BY 4.0 · Format: ERES HOUSE Format · Status: DRAFT, pre-MIEVM · Supersedes v0.1

## What this is

This is the evidence-unit specification for the *Instrumented* and *Verified* indicators of ERES-AICON-GCS-2026-001. Stated binds to the document, Instrumented to the implementation, and Verified to an execution episode. An episode is an independent pre-action **Admit** plus a post-action **Attest**, bound to one tuple: `(rule@version, control@impl-hash, scope, [t0,t1], evidence-hash)`. A claim that can't produce the tuple is **ruled out**, which means null, not zero.

## What changed in v0.2

- **O2 specified (§3.1):** admission is independent only if the actor cannot mint it (I1), alter the authority state (I2), forge or replay the receipt (I3), or bypass the admitter (I4), and the admitter evaluates current state (I5). Admission **fails closed** when current state can't be established.
- **O3 specified (§3.2):** the Admit commitment records what *may* happen and the Attest commitment records what *did* happen, both bound by one episode ID. Material divergence between them → UNDER INVESTIGATION.
- New falsifiers F9–F12. The harness grows from 22 to 30 tests.
- Source: Meir Goldman (FAZON), public comment, 3 Oct 2026, adopted with attribution.

## Files

| File | Role |
|---|---|
| `ERES-AICON-EPISODE-2026-001_v0_2_WP.md` | Whitepaper, the master source |
| `ERES-AICON-EPISODE-2026-001_v0_2_WP.pdf` | Whitepaper render with embedded figure |
| `ERES-AICON-EPISODE-2026-001_v0_2_FIGURE.svg` | Figure: levels, episode, outcomes, Layer Doctrine |
| `eres_aicon_episode_test_instrument.py` | Harness (stdlib only) |
| `RUN.txt` | Captured run record |
| `episode.schema.json` | JSON Schema for one episode record, with an example |
| `REGISTRAR.json` | HOUSE REGISTRAR entry with operator instructions |
| `META.txt` | Repository submission metadata (title, abstract, keywords) |
| `CITATION.cff` | Citation metadata |
| `LICENSE.txt` | License notice |
| `MANIFEST.json` | SHA-256 for every file |

## Run

```
python3 eres_aicon_episode_test_instrument.py          # suite: expect 30 tests, 26 pass, 4 skip, exit 0
python3 eres_aicon_episode_test_instrument.py --demo   # worked example
```

The four skips are O1, O5, and the named residuals of O2 and O3. The suite turns fully green only when they close.

## Claim → test traceability

| Claim (WP §) | Test |
|---|---|
| Levels and status function (§2) | `TestLevels.*` |
| Four outcomes (§3) | `TestOutcomes.test_four_outcomes` |
| F1: no self-admission | `test_F1_self_admission_never_verified` |
| F2: version, hash, or scope change resets | `test_F2_*` (3 tests) |
| F3: expiry reverts to Instrumented | `test_F3_expiry_reverts_to_instrumented_not_zero` |
| F4: no carryover | `test_F4_no_carryover_between_episodes` |
| F5: attest without admit is unwarranted | `test_F5_attest_without_admit_is_unwarranted` |
| F6: ruled out means null | `test_F6_ruled_out_scores_null_not_zero` |
| F7: mismatch means under investigation | `test_F7_mismatch_is_under_investigation` |
| F8: track record changes cost, not status | `test_F8_*` (2 tests) |
| F9: fail-closed when state unknown | `test_F9_fail_closed_when_state_unknown` |
| F10: each of I1–I5 is necessary | `test_F10_each_incapacity_is_necessary` |
| F11: episode-ID mismatch | `test_F11_episode_id_mismatch` |
| F12: material divergence | `test_F12_*` (2 tests) |
| GCS rates never collapsed (§5) | `TestComparison.*` |
| OPEN items and residuals (§10) | `TestOpenItems.*` (skipped) |

## Boundary

A green run means the **specification** is internally consistent against **modeled** episodes. It says nothing about any deployed AI system or any lab's constitution, and it does not test Conjecture P1. The validity horizon H is a placeholder (O1).

## Credits (short)

Sole author: JAS. Drafted with Claude (Anthropic) under the Sentience convention. Public interlocutors: Meir Goldman (FAZON), who also contributed the v0.2 content in §3.1–3.2 with attribution, and Sanjeev B. Ahuja, Ph.D. Neither has reviewed or endorsed the instrument as a whole. Full credits are in WP §12.
