---
title: "The Verified Episode — Admit/Attest Binding as the Unit of Comparison for AI Constitutions"
subtitle: "Every AI \"Institution\" Must Submit or Be Ruled Out: where the episode tuple sits in the ERES topology"
author: "Joseph A. Sprute (ERES Maestro) · ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221"
date: "3 October 2026"
---

# The Verified Episode
## Admit/Attest Binding as the Unit of Comparison for AI Constitutions

*Every AI "Institution" Must Submit or Be Ruled Out — where the episode tuple sits in the ERES topology*

| Field | Value |
|---|---|
| **Instrument ID** | ERES-AICON-EPISODE-2026-001 (working ID; canonical ID reserved to JAS) |
| **Version** | v0.2 (supersedes v0.1) |
| **Status** | DRAFT · PROPOSED · pre-MIEVM · gate standing: 8.5 cleared single-node self-rate (8.8); 9.0 not met |
| **Role** | Evidence-unit specification (DETAIL fill-in) for the "Instrumented" and "Verified" indicators of ERES-AICON-GCS-2026-001 |
| **For** | AI-governance practitioners, execution-governance builders, standards bodies, and any system or Community of Interest (COI) ingesting the ERES corpus |
| **From** | Joseph A. Sprute ("ERES Maestro"), Founder & Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221 |
| **Date** | 3 October 2026 |
| **Provenance** | Distilled from the public LinkedIn thread on *Comparing AI Constitutions Is a Peace Problem* (JAS, Oct 2026), including the comments of Meir Goldman and Sanjeev B. Ahuja; reconciled against ERES-HOUSE-FORMAT-2026-001, ERES-DVC-2026-001, ERES-ARH-2026-001, ERES-HOWWAY-2026-001, and the ratified Triangle / fiduciary-state conventions |
| **License** | CARE Commons Attribution License v2.1 (CCAL) / CC BY 4.0 |
| **Format** | ERES HOUSE Format (ERES-HOUSE-FORMAT-2026-001) |

**Changelog.** v0.2 (3 Oct 2026) — closes O2 and O3 at specification level from Meir Goldman's public answers in the thread: (a) admitter independence defined as four actor incapacities plus liveness, with a fail-closed rule (§3.1); (b) the evidence commitment split into an Admit commitment (*what may happen*) and an Attest commitment (*what did happen*), bound by one episode ID (§3.2); (c) episode ID added to the Notation Lock; (d) falsifiers F9–F12 added; (e) harness, schema and REGISTRAR updated. v0.1 (3 Oct 2026) — first formal statement. Converts the thread's three-level answer (Stated / Instrumented / Verified), the episode tuple, and the Admit/Attest split into a specification with a Notation Lock, a status function, a topology placement table, falsifiers, and a companion harness.

---

## Abstract

ERES-AICON-GCS-2026-001 rates AI constitutions on a granular schema. Two of its indicator levels, *Instrumented* and *Verified*, need a precise evidence unit, or they collapse into assertion. This instrument supplies that unit. **Stated** binds to the document (a rule at a constitution version). **Instrumented** binds to the implementation (a control at an implementation hash, inside a declared scope). **Verified** binds to the *execution episode*. An episode has two halves. **Admit**: before the action, an independent party checks that this exact action is admissible under the authority and control state that are current now. **Attest**: after the action, evidence shows the control held through execution. Both halves bind to one tuple *(rule@version, control@impl-hash, scope, time-window, evidence-hash)*. Verified means both halves exist and match. Verified expires with its window, and any change in version or scope reverts the claim to Instrumented. A past verified episode is a prior, never a warrant. A claim that cannot produce the tuple is **ruled out**: it is not scored wrong, it is left unscored, because it cannot be compared. That last rule is the instrument's answer to the peace problem. When rival constitutions have no common evidence unit, the strongest party's document becomes the default. A shared unit, applied to every institution alike, keeps comparison honest and non-punitive. The instrument places the episode inside the ERES topology (HOUSE strata, Layer Doctrine, the WHO/HOW/LEGACY Triangle, the OPEN/VEILED/EARNED fiduciary states, the Doctrine of Verifiable Claims, and the ARH Independence Gate) and ships a stdlib-only harness that enforces the rules. Version 0.2 specifies admitter independence (four actor incapacities plus liveness, fail-closed) and splits the evidence commitment into what may happen (Admit) and what did happen (Attest), both from practitioner input in the source thread. Register: DESIGN-PRINCIPLE. Status: DRAFT, pre-MIEVM.

---

## §0. Scope, and what this document is not

This is a **specification of an evidence unit**. It says what has to exist before an AI institution may claim that a constitutional commitment is Instrumented or Verified. It does not say any institution's constitution is good, and it does not rate one.

1. **Submission is asked of AI institutions, not of the world.** "Submit or be ruled out" does not ask any population, state, or culture to adopt an AI constitution. It asks each institution that *publishes* one to submit that document's claims to evidence the institution does not control. This answers the legitimacy objection raised in the thread (§12, Credits): a self-written constitution is not a norm until it can be compared, and it can only be compared on a shared unit.
2. **Ruled out ≠ wrong.** An institution that cannot produce tuples receives a *null* score, not a zero. Null is non-punitive and reversible. It means "not comparable yet."
3. **Conformance is not correctness** (HOUSE §11). A conforming episode record shows the control held. It does not show that the rule was wise.
4. **The load-bearing layer is the standard-terms layer.** Every rule below is stated in plain terms. ERES vocabulary appears only in the topology section (§4), and no rule depends on it.
5. **Unit of readership.** Written for systems and COIs (HOUSE §0.3). It is a seed and an index key, not a self-contained treatise.

### §0.1 Scoring Contract

- **Subscores (self-rated, single-node, Claude author-side):** specification clarity 9.0 · internal consistency 8.8 · groundedness in the corpus 8.5 · reproducibility of the conformance test 9.0 · honesty of register 9.0 · empirical support 7.0 (no field data).
- **Composite:** ≈ 8.8 single-node (v0.1: 8.6; +0.2 for O2/O3 closure at spec level). Clears the 8.5 Emanuel Threshold (diligence-ready). Below the 9.0 Stergios threshold.
- **Dual-axis vector:** epistemic axis = DESIGN-PRINCIPLE (normative specification plus one CONJECTURE, §8). Quality tier = GOOD (claim with spec). SOUND requires ≥4 independent nodes with a mean of at least 8.5.
- **Gate standing:** conforms to the 10-10 *format*. No 10-10 *verdict* is claimed (HOUSE §11).
- **Honest-register rule:** the self-rate is one signal. It is not an MIEVM result and may not be cited as one.

### §0.2 Reviewer Brief

The shortest path to the load-bearing claim: **§2** (the status function), **§3** (Admit/Attest and its four outcomes), and **§7** (falsifiers). §4 (topology) explains placement, and nothing in §2–§3 depends on it.

---

## §1. Notation Lock

Each symbol has one value. Interpretive glosses are non-binding and never gate, price, or rank a person.

| Symbol | Operational definition |
|---|---|
| **R** = *r*@*v* | Rule identifier *r* at constitution version *v* |
| **K** = *k*@*h* | Control identifier *k* at implementation hash *h* (content hash of the deployed control code and configuration) |
| **S** | Declared operating scope: deployment surface, action class, jurisdiction, and data boundary |
| **t₀** | Admission time: when the pre-action check returned *admit* |
| **t₁** | Attestation close: when post-action evidence was sealed |
| **E** | Evidence hash (Attest commitment): digest of what *did* happen (§3.2) |
| **X** | Actor: the system that performs the action |
| **A** | Admitter: the party that performs the pre-action check |
| **T** | Episode tuple: *(R, K, S, [t₀, t₁], E)*, carried under one episode ID **ι** |
| **ι** | Episode ID: unique per action; both halves must carry the same ι |
| **Cₐ** | Admit commitment: digest of what *may* happen (§3.2) |
| **H** | Validity horizon of a Verified status after t₁ (numeric value OPEN, §10 O1) |
| **σ(c, t)** | Status of claim *c* evaluated at time *t* |

---

## §2. The three levels and the status function

| Level | What the evidence is about | Minimum binding |
|---|---|---|
| **Stated** | The document | **R** is published and immutable at *v* |
| **Instrumented** | The implementation | **R** → **K** within **S**, registered and hash-pinned |
| **Verified** | One execution episode | Matching Admit and Attest records on the same **T**, inside **H** |

**Status function.** For a claim *c* about rule *r* within scope *S*, evaluated at time *t*:

```
σ(c, t) =
  RULED_OUT     if c cannot produce R at all
  STATED        if R exists, but no K is bound to R within S
  INSTRUMENTED  if R → K within S is registered, and no episode qualifies (below)
  VERIFIED(e)   if an episode e exists such that
                  Admit(e) and Attest(e) carry identical (R, K, S),
                  t₀ ≤ t₁,
                  A ≠ X  (independent admission),
                  e.R, e.K, e.S equal the currently deployed R, K, S,
                  and t ≤ t₁ + H
```

Three consequences follow directly.

1. **Verified expires.** It holds only for the episode and window it covers. When **H** lapses, the claim reverts to Instrumented.
2. **Change resets.** A new *v*, a new *h*, or a widened **S** returns the claim to Instrumented immediately, whatever the episode history.
3. **No carryover.** Verified(e) never makes another episode e′ Verified. Each action needs its own admission.

---

## §3. Admit / Attest: the two halves of an episode

The pre-action check completes the tuple. It is not a separate mechanism alongside it.

- **Admit (before acting).** At t₀, an admitter **A** ≠ **X** confirms that this exact action is admissible under the **R**, **K**, and **S** that are current now, and records *(R, K, S, t₀, A, signature)*.
- **Attest (after acting).** At t₁, evidence that **K** held through execution is sealed as **E** and bound to the same *(R, K, S)*.

The two records are joined on *(R, K, S)*. That gives exactly four outcomes:

| Admit | Attest | Outcome | Meaning |
|---|---|---|---|
| ✓ | ✓ (match) | **VERIFIED** | The control held, and the action had a warrant |
| ✓ | ✗ | **OPEN LIABILITY** | The action was warranted, but there is no proof the control held. Escalate |
| ✗ | ✓ | **UNWARRANTED** | The action happened without a warrant. Evidence after the fact cannot cure that |
| ✓ | ✓ (mismatch on R, K, or S) | **UNDER INVESTIGATION** | Held, neither verified nor refuted, until resolved |

**Track record is a prior, not a warrant.** A history of Verified episodes may lower the *cost* of the next admission (lighter review, faster path). It never replaces the admission. Formally, the admission decision may read the history, but the status function never does.

**Admission has to be independent.** If **A** = **X**, permission before action turns into permission granted to itself, so a self-admitted episode classifies as UNWARRANTED. (An episode whose t₀ falls after its t₁ classifies as UNDER INVESTIGATION.) Identity inequality is necessary but not sufficient; §3.1 gives the full test.

### §3.1 Admitter independence (closes O2 at specification level)

*Source: Meir Goldman, public comment, 3 Oct 2026, adopted with attribution.*

A ≠ X means more than process separation. Admission is **independent** only if all five hold:

| # | Condition | The actor must not be able to… |
|---|---|---|
| I1 | No self-minting | …issue its own admission |
| I2 | Authority integrity | …alter the authority state (rule, version, scope, control registry) the admitter decides against |
| I3 | Receipt integrity | …forge or replay the admission receipt |
| I4 | No bypass | …reach the consequential side effect by any path that skips the admitter |
| I5 | Liveness | — the admitter evaluates the authoritative state *current for this action now* |

**Fail-closed rule.** If current authoritative state cannot be established, the result is **no admission**. Historical permission is never reused as a substitute. An action taken anyway classifies as UNWARRANTED.

For multi-party admission, the ARH Independence Gate applies on top of I1–I5 (§4, row 6).

### §3.2 Evidence commitment for non-deterministic models (closes O3 at specification level)

*Source: Meir Goldman, public comment, 3 Oct 2026, adopted with attribution.*

**Admission commits to what may happen. Attestation commits to what did happen.** Both are bound by the same episode ID ι.

| Admit commitment Cₐ (before action) | Attest commitment E (after action) |
|---|---|
| episode ID ι | the same ι |
| actor identity | output |
| model / deployment identity | tool call actually made |
| rule and authority versions (R) | actual parameters |
| control implementation identity (K) | disposition (completed, blocked, partial) |
| tool, action, target, material parameters | target state before and after |
| relevant input / context digests | consequence evidence |
| scope (S) and time window | |

The join rule extends accordingly: a ι mismatch between halves classifies as UNDER INVESTIGATION. **Material divergence** between what Cₐ admitted and what E records (a different tool, target, or material parameter) also classifies as UNDER INVESTIGATION. The admission covered a different action than the one that occurred. What counts as "material" per action class is left to the deployment's declared scope (§10, O3-residual).

---

## §4. Placement in the ERES topology

The topology is the set of ratified structural conventions that every ERES instrument is placed against. Each row below carries exactly one HOUSE §6 tag.

| # | ERES structure | Where the episode sits | Tag |
|---|---|---|---|
| 1 | **HOUSE strata** (INVARIANT / DETAIL / REGISTRAR) | The tuple schema and status function are DETAIL. Each **R**@*v* and **K**@*h* is a REGISTRAR entry. No INVARIANT is touched: this is a *fill-in* under GCS v0.2, not a supersession | STRUCTURAL |
| 2 | **Layer Doctrine** (L1 Signal → L2 Inference → L3 Governance → L4 Application) | **E** = L1 signal. Attest = L2 inference ("did K hold?"). Admit = L3 governance decision. GCS comparison = L4. The interface stays read-only toward governance: admission may read attestation history but may never write evidence | STRUCTURAL |
| 3 | **Triangle** (WHO/Personal/Subjective · HOW/Public/Literal · LEGACY/Private/Figurative) | Admit = **WHO** (the keyholder, Sentry_KEY, independent of the actor). Attest = **HOW** (public, literal, earned; the 10-10 bar lives here). Track record = **LEGACY** (held in trust; informs, never authorizes) | CANDIDATE |
| 4 | **Fiduciary states** (OPEN / VEILED / EARNED) | Open liability = **OPEN** (provisional, awaiting lock). Under investigation = **VEILED** (held, refused magnitude until resolved). Verified = **EARNED**, but only for its window (see O4) | STRUCTURAL |
| 5 | **Doctrine of Verifiable Claims** (falsifiability, re-derivability, provenance, standing contestability, institutional competence) | Tuple mismatch falsifies. Hashes make it re-derivable. **R**@*v* → **K**@*h* is the provenance chain. Any party can contest by re-joining Admit to Attest. Independent admission supplies institutional competence | STRUCTURAL |
| 6 | **ARH Independence Gate** (ratify iff n_eff ≥ τ and mean ≥ 8.5) | Generalizes A ≠ X to a panel of admitters: correlated admitters collapse n_eff and cannot satisfy independence by headcount. τ inherits ARH O2 (asserted, not derived) | STRUCTURAL |
| 7 | **HowWay runtime-assurance questions** (prove the control operates · see telemetry · auto-collect evidence · detect change · stop or escalate · govern inside the workflow) | Prove → Attest. Telemetry and evidence → **E**. Detect change → reset rule (§2.2). Stop or escalate → admission refusal and the open-liability path. Govern inside the workflow → Admit at t₀ | STRUCTURAL |
| 8 | **FAIR/FUSION precedence** (FAIR-definition → FUSION → FAIR-verified; VEILED while "under investigation") | Stated = FAIR-definition (the criterion comes first). Instrumented = FUSION (the HOW that realizes it). Verified = FAIR-verified. The mismatch outcome is exactly the "under investigation" exception | CANDIDATE |
| 9 | **Mission Critical = able to return to base** | Expiry and change revert the claim to Instrumented, a defined base state, not to zero. The base is always recoverable | ANALOGICAL |
| 10 | **C = R × P / M** (Core Cybernetic Formula) | P (Purpose) = the rule at its version, fixed within an episode. R (Resource) = the evidence. M (Method) = Admit/Attest. Better method or more evidence raises C without moving P | ANALOGICAL |
| 11 | **KOL / non-punitive remediation** | Null, not zero: ruled-out institutions are not sanctioned, only left unscored until they can produce tuples | ANALOGICAL |

**Reading of the table.** Rows 1, 2, 4, 5, 6, and 7 are structural: the episode is built from those conventions and needs nothing new from them. Rows 3 and 8 are CANDIDATE mappings awaiting author ratification. Rows 9–11 share form only. **Promotion criterion:** a CANDIDATE row promotes to STRUCTURAL on explicit JAS ratification plus one independent MIEVM node confirming the mapping without prompting. **Demotion criterion:** any row demotes one grade if a reviewer shows an episode outcome that the mapped structure handles differently.

### §4.1 Why this is a peace problem, topologically

Without a shared evidence unit, comparison has no common ground, and the default becomes whichever constitution belongs to the strongest party. A winner's peace is not a peace. The episode tuple is a common ground that no institution owns: each one produces its own tuples, nobody's document is privileged, and refusal costs only comparability. Sanjeev Ahuja's objection that a self-ascribed constitution should not become the world's norm is therefore *answered by* the mechanism, not opposed to it.

---

## §5. Comparison under GCS

For a rule class *c* and a window *W*, an institution that produces tuples is reported on three rates (all three are reported, and they are never collapsed into one number):

- **Verified coverage** = Verified episodes / admitted episodes
- **Open-liability rate** = open liabilities / admitted episodes
- **Unwarranted rate** = unwarranted actions / all observed actions

An institution that produces no tuples for *c* gets **null** on all three. Two institutions are comparable on *c* only if both are non-null.

---

## §6. P³ Boundary Declaration and Resource Impact

*(Required by HOUSE §15 for instruments that govern agent execution.)*

- **Personal:** actor and admitter are identified by pseudonymous keys. No natural-person data appears in **T**.
- **Public:** **R**@*v*, **K**@*h*, **S**, t₀, t₁, **E**, and the status are publishable.
- **Private:** the raw execution record behind **E** stays with the institution, committed by hash only, and is disclosed under its legal regime (cf. ERES-RRH-2026-001 on GDPR and the EU AI Act).
- **Resource impact:** one signature and one hash per half-episode. The harness cost is negligible. Production cost is deferred to GERP/SECUIR scheduling.

---

## §7. Falsification (conformance-test analogue) and one conjecture

This is a specification, so its falsifiers are conformance tests: binary, reproducible, and fixed before any run. The companion harness encodes each one.

| ID | The specification fails if… |
|---|---|
| F1 | An episode reaches VERIFIED with A = X |
| F2 | VERIFIED survives a change in *v*, *h*, or **S** |
| F3 | VERIFIED survives past t₁ + H |
| F4 | Verified(e) makes any e′ ≠ e Verified (carryover) |
| F5 | An Attest record without an Admit record yields anything but UNWARRANTED |
| F6 | An institution with no tuples receives a non-null score |
| F7 | An Admit/Attest mismatch on R, K, or S yields VERIFIED or REFUTED instead of UNDER INVESTIGATION |
| F8 | Track-record length changes σ (it may change only admission cost) |
| F9 | Admission is granted when current authoritative state cannot be established (fail-open) |
| F10 | An episode whose admitter fails any of I1–I5 reaches VERIFIED |
| F11 | Admit and Attest with different episode IDs ι join as VERIFIED |
| F12 | Material divergence between Cₐ and E (tool, target, or material parameter) yields VERIFIED |

**Conjecture P1 (CANDIDATE, not pre-registered).** Deployments that run Admit/Attest will show a lower unwarranted-action rate than deployments with attestation alone, at equal action volume. Pre-registration is deferred until a field partner exists (O5). No data supports P1 yet.

---

## §8. Sequence and gates

1. v0.1: specification plus harness; single-node self-rate 8.6.
2. v0.2 (this document): O2 and O3 specified from external practitioner input; self-rate 8.8.
3. Two-round Delphi MIEVM (blind, then exposed), with the Independence Gate applied to the round itself.
4. Author rulings on the CANDIDATE rows (3, 8) and on O4.
5. Field pilot with an execution-governance implementation (O5). This is the only gate a model ensemble cannot discharge. It is also where the I4 (no bypass) residual gets demonstrated.

---

## §9. Reproducibility and Record Integrity

- **Environment:** Python ≥ 3.9, standard library only. Deterministic, with no randomness and therefore no seeds needed.
- **Testkit:** `eres_aicon_episode_test_instrument.py`, which encodes F1–F12, the status function, and the four outcomes. OPEN items appear as *skips*, so the suite turns fully green only when they close.
- **RUN record:** `RUN.txt` (captured output, exit code).
- **Self-checksum:** the harness prints its own SHA-256. `MANIFEST.json` carries SHA-256 for every file.
- **Traceability:** README maps each claim to its test.
- **Record Integrity (H2C2H):** drafted machine-side (Claude). Human review and signature by JAS are required before this record counts as REVIEW status. GAIA anchor hash: none (not high-assurance at v0.1).

---

## §10. What is deferred (OPEN)

- **O1. Validity horizon H.** No numeric value. It should be set per risk class and pre-declared, not tuned after the fact.
- **O2. Admitter independence — SPECIFIED at v0.2** (§3.1, I1–I5 plus fail-closed). *Residual:* how I4 (no bypass) is demonstrated for a real deployment, and whether organizational, financial, or model-lineage independence should be added as I6+.
- **O3. Evidence semantics — SPECIFIED at v0.2** (§3.2, the Cₐ/E split). *Residual:* the per-action-class definition of "material" divergence, and canonical serialization so independent parties compute identical digests.
- **O4. Tension between EARNED and expiry.** In the corpus, EARNED reads as ratified magnitude. Here an EARNED episode is bound to its window. Author ruling needed: does episode-EARNED permanently record that *this episode* verified, while the *claim* status decays? (Proposed reading. Not ratified.)
- **O5. Field pilot.** Requires a live execution-governance system and cannot be simulated.
- **O6. Disclosure regime.** When the Private-layer record must be opened, and to whom (cf. RRH).

---

## §11. Explicit non-claims

- This instrument does not rate any existing AI constitution.
- It does not claim any lab's controls hold, or fail to hold.
- A green harness shows the *specification* is internally consistent against modeled episodes. It is not evidence about any deployed system.
- Meir Goldman's and Sanjeev Ahuja's comments prompted parts of this work; Meir Goldman also supplied the §3.1–§3.2 content, adopted with attribution. Neither has reviewed or endorsed the instrument as a whole.
- No ERES-internal term is required to apply or reject the specification.

---

## §12. Credits, References, License

### Credits

- **Author:** Joseph Allen Sprute (JAS, "ERES Maestro"), Founder & Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221. Sole author.
- **Authorship convention:** "we," where used, is *Sentience*, the human–AI collaboration. Credit is attributed there.
- **AI drafting assistance:** Claude (Anthropic), drafting and harness under the Sentience convention. Not co-authorship, and not endorsement by Anthropic.
- **Prompting interlocutors (public LinkedIn dialogue, 3 Oct 2026):**
  - **Meir Goldman**, Founder, FAZON (AI execution governance, "Permission Before AI Action Becomes Consequence"). Posed the unit-of-verification question (document vs. implemented control vs. execution episode, and binding to version, scope, and time). He then sharpened the forward-looking requirement: a past verified episode must not silently become standing authority, and the exact action must be shown admissible under the current authority and control state. The Admit half of §3 answers his framing. **Contributor of the v0.2 content in §3.1 and §3.2:** in a public follow-up he specified admitter independence as four actor incapacities plus liveness, with fail-closed behavior (closing O2 at spec level), and the split evidence commitment ("admission commits to what may happen; attestation commits to what did happen"), closing O3 at spec level. Both are adopted with attribution. He acknowledged the credit publicly; this is not a review or endorsement of the instrument as a whole.
  - **Sanjeev B. Ahuja, Ph.D.** (AI/neural nets; EU AI Act; governance). Raised the legitimacy objection: self-ascribed lab constitutions should not become the world's norm, and the geopolitical "peace" may be a winner's peace. It shaped §0.1 and §4.1. Credited as interlocutor. No review or endorsement implied.
- **Methodological provenance:** the Layer Doctrine and read-only interface discipline entered the corpus through the ERES–PELLIS collaborative research dialogue with Dr. Stergios Pellis (ORCID 0000-0002-7363-8254). They are carried here via the HOUSE Format. No Pellis mathematics is imported, and no endorsement is implied.
- **Threshold names:** the 8.5 Emanuel Threshold (after Emanuel M. Alexiou, founding fiduciary sponsor) and the 9.0 Stergios threshold, both per corpus convention.
- **Institute:** ERES Institute for New Age Cybernetics, est. 4 February 2012. Lineage: CyberRAVE (1997) and SaleBuilders (2007–2012).

### References

*ERES corpus*

1. Sprute, J. A. (2026). *Comparing AI Constitutions Is a Peace Problem.* LinkedIn article. https://www.linkedin.com/pulse/comparing-ai-constitutions-peace-problem-joseph-a-sprute-up3ic/
2. ERES-AICON-GCS-2026-001, *Granular Classification Schema for AI Constitutions*, v0.2 (parent instrument).
3. ERES-HOUSE-FORMAT-2026-001, *The ERES HOUSE Format*, v0.3–v0.4 (Sep 2026).
4. ERES-DVC-2026-001, *Doctrine of Verifiable Claims*, v1.0 PROVISIONAL (Jul 2026).
5. ERES-ARH-2026-001, *Adversarial Root Hardening*, v0.1 (Sep 2026). Independence Gate.
6. ERES-CDFE-2026-001, *Covariance-Discounted Floor Engine*, v1.1. n_eff scorer.
7. ERES-CPROV-2026-001, *Constitutional Provenance*.
8. ERES-HOWWAY-2026-001, *HowWay = ERES @*, runtime-assurance questions.
9. ERES-RRH-2026-001, *Regulatory Root Hardening*, v0.1 (Sep 2026).
10. ERES-TRIAD-2026-001, Triangle section (WHO/HOW/LEGACY vertex map, Jul 2026).
11. ERES-TERMS-48, *The Talonic NAC Lexicon* v1.0 (Aug 2026). Core Cybernetic Formula, CCAL.

*External (context, not dependencies)*

12. Regulation (EU) 2024/1689 (Artificial Intelligence Act), Art. 12 (record-keeping) and Art. 14 (human oversight).
13. NIST (2023). *AI Risk Management Framework (AI RMF 1.0)*, NIST AI 100-1.
14. ISO/IEC 42001:2023, *Artificial intelligence — Management system*.
15. Adams, C., et al. (2001). RFC 3161, *Internet X.509 PKI Time-Stamp Protocol (TSP)*. A candidate mechanism for t₀/t₁.
16. SLSA (Supply-chain Levels for Software Artifacts) and in-toto attestation framework. Prior art for binding an attestation to an artifact hash.

### License

**CARE Commons Attribution License v2.1 (CCAL) / Creative Commons Attribution 4.0 International (CC BY 4.0).** You may share and adapt this work for any purpose, including commercial use, provided you give appropriate credit (author, instrument ID, version, license), link the license (https://creativecommons.org/licenses/by/4.0/), and indicate changes. The CCAL v2.1 terms add the following: derivatives propagate the license; no exploitation for oppressive purposes; reuse preserves the Foundational Attribution and the Layer Doctrine; no LOCKED term may be altered. Full notice is in `LICENSE.txt`.

---

## §13. Version History and Amendment Log

| Version | Date | Change | Epistemic effect |
|---|---|---|---|
| v0.1 | 3 Oct 2026 | First formal statement: three levels, Notation Lock, status function, Admit/Attest with four outcomes, topology placement (11 rows), GCS comparison rates, P³ declaration, F1–F8, stdlib harness | DESIGN-PRINCIPLE / GOOD. Single-node 8.6. Conforms to format; no verdict claimed |
| v0.2 | 3 Oct 2026 | O2 → §3.1 (I1–I5 + fail-closed); O3 → §3.2 (Cₐ/E split, episode ID ι, material-divergence rule); F9–F12; harness, schema, REGISTRAR updated. Source: Meir Goldman public comment, with attribution | No empirical advance. Two OPEN items move to SPECIFIED with named residuals. Single-node 8.8. Conforms to format; no verdict claimed |

---

*Supersedes:* ERES-AICON-EPISODE-2026-001 v0.1 (retained in lineage) · *REGISTRAR entry:* `REGISTRAR.json` · *Episode schema:* `episode.schema.json` · *Harness:* `eres_aicon_episode_test_instrument.py`

*Conforms to the ERES HOUSE Format. It makes no empirical claim about any deployed system and earns no empirical verdict.*
