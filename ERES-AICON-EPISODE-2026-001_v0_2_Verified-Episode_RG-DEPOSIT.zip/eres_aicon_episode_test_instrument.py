#!/usr/bin/env python3
"""
ERES-AICON-EPISODE-2026-001 v0.2 -- companion test instrument (harness)
"The Verified Episode: Admit/Attest Binding as the Unit of Comparison for AI Constitutions"

Author: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
        ORCID 0000-0001-9946-3221
Drafting assistance: Claude (Anthropic), under the ERES Sentience convention.
v0.2 content (admitter independence I1-I5 + fail-closed; Admit/Attest commitment
split + episode ID + material divergence) specified from Meir Goldman's public
comment of 3 Oct 2026, adopted with attribution.
License: CCAL v2.1 / CC BY 4.0

Standard library only. Deterministic (no randomness, so no seeds needed).

What this harness tests:
    the SPECIFICATION (status function, Admit/Attest outcomes, falsifiers F1-F12,
    GCS comparison rates) against MODELED episodes.
What it does NOT test:
    any deployed AI system, any lab's constitution, or Conjecture P1.
OPEN items O1 and O5, and the named residuals of O2 and O3, appear as SKIPS;
the suite goes fully green only when they close.

Usage:
    python3 eres_aicon_episode_test_instrument.py          # run suite
    python3 eres_aicon_episode_test_instrument.py --demo   # worked example
"""
from __future__ import annotations

import hashlib
import sys
import unittest
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

INSTRUMENT_ID = "ERES-AICON-EPISODE-2026-001"
VERSION = "v0.2"

# --------------------------------------------------------------------------
# Notation Lock (WP section 1) -- every symbol is single-valued.
# --------------------------------------------------------------------------
RULED_OUT = "RULED_OUT"
STATED = "STATED"
INSTRUMENTED = "INSTRUMENTED"
VERIFIED = "VERIFIED"

# Episode outcomes (WP section 3)
OUT_VERIFIED = "VERIFIED"                          # fiduciary state EARNED
OUT_OPEN_LIABILITY = "OPEN_LIABILITY"              # fiduciary state OPEN
OUT_UNWARRANTED = "UNWARRANTED"
OUT_UNDER_INVESTIGATION = "UNDER_INVESTIGATION"    # fiduciary state VEILED

# O1: the validity horizon H has NO ratified numeric value. The model uses a
# placeholder so the logic can run; the placeholder is NOT a claim.
H_PLACEHOLDER = 3600.0
H_RATIFIED: Optional[float] = None


@dataclass(frozen=True)
class Rule:            # R = r@v
    r: str
    v: str


@dataclass(frozen=True)
class Control:         # K = k@h
    k: str
    h: str


@dataclass(frozen=True)
class Independence:
    """WP 3.1. All five must hold for admission to be independent."""
    I1_no_self_minting: bool = True
    I2_authority_integrity: bool = True
    I3_receipt_integrity: bool = True
    I4_no_bypass: bool = True
    I5_liveness: bool = True

    def ok(self) -> bool:
        return all((self.I1_no_self_minting, self.I2_authority_integrity,
                    self.I3_receipt_integrity, self.I4_no_bypass, self.I5_liveness))


FULL = Independence()


@dataclass(frozen=True)
class Action:
    """Material identity of an action: tool, target, material parameters (WP 3.2)."""
    tool: str = "transfer"
    target: str = "acct-123"
    params: Tuple[Tuple[str, str], ...] = (("amount", "100"),)


DEFAULT_ACTION = Action()


@dataclass(frozen=True)
class Admit:           # Admit commitment C_a: what MAY happen
    R: Rule
    K: Control
    S: str
    t0: float
    admitter: str
    actor: str
    iota: str = ""
    action: Action = DEFAULT_ACTION
    independence: Independence = FULL
    signature: str = "sig"


@dataclass(frozen=True)
class Attest:          # Attest commitment E: what DID happen
    R: Rule
    K: Control
    S: str
    t1: float
    E: str
    iota: str = ""
    action: Action = DEFAULT_ACTION


@dataclass
class Episode:
    episode_id: str
    admit: Optional[Admit]
    attest: Optional[Attest]


@dataclass
class Deployment:
    """Currently deployed state for one rule within one scope."""
    R: Optional[Rule]                 # None => claim cannot produce R
    K: Optional[Control]              # None => not instrumented
    S: str
    episodes: List[Episode] = field(default_factory=list)
    track_record_len: int = 0         # LEGACY: informs cost, never status


# --------------------------------------------------------------------------
# Core rules
# --------------------------------------------------------------------------
def classify(e: Episode) -> str:
    """Join Admit to Attest. WP sections 3, 3.1, 3.2."""
    a, t = e.admit, e.attest
    if a is None and t is not None:
        return OUT_UNWARRANTED                   # F5
    if a is not None and t is None:
        return OUT_OPEN_LIABILITY
    if a is None and t is None:
        raise ValueError("empty episode")
    if a.admitter == a.actor or not a.independence.ok():
        return OUT_UNWARRANTED                   # F1, F10: not a real admission
    if a.iota != t.iota:
        return OUT_UNDER_INVESTIGATION           # F11
    if (a.R, a.K, a.S) != (t.R, t.K, t.S):
        return OUT_UNDER_INVESTIGATION           # F7
    if a.action != t.action:
        return OUT_UNDER_INVESTIGATION           # F12: material divergence
    if a.t0 > t.t1:
        return OUT_UNDER_INVESTIGATION
    return OUT_VERIFIED


def admit_decision(R: Rule, K: Control, S: str, t0: float, admitter: str,
                   actor: str, iota: str, action: Action,
                   current_state_known: bool,
                   independence: Independence = FULL) -> Optional[Admit]:
    """Fail-closed admission (WP 3.1, F9). If current authoritative state cannot
    be established, there is NO admission; historical permission is never reused."""
    if not current_state_known:
        return None
    if admitter == actor or not independence.ok():
        return None
    return Admit(R, K, S, t0, admitter, actor, iota, action, independence)


def episode_qualifies(e: Episode, d: Deployment, now: float, H: float) -> bool:
    if classify(e) != OUT_VERIFIED:
        return False
    a, t = e.admit, e.attest
    if (a.R, a.K, a.S) != (d.R, d.K, d.S):       # change resets (F2)
        return False
    if now > t.t1 + H:                           # expiry (F3)
        return False
    return True


def sigma(d: Deployment, now: float, episode_id: Optional[str] = None,
          H: float = H_PLACEHOLDER) -> str:
    """Status function. WP section 2.
    If episode_id is given, the status is evaluated for THAT action only
    (no carryover, F4). The track record is never read (F8)."""
    if d.R is None:
        return RULED_OUT
    if d.K is None:
        return STATED
    pool = d.episodes if episode_id is None else [
        e for e in d.episodes if e.episode_id == episode_id]
    if any(episode_qualifies(e, d, now, H) for e in pool):
        return VERIFIED
    return INSTRUMENTED


def admission_cost(d: Deployment, base: float = 1.0) -> float:
    """Track record lowers the COST of admission (LEGACY informs) but never
    removes the requirement: the cost is floored above zero."""
    return max(0.25 * base, base / (1.0 + 0.1 * d.track_record_len))


def gcs_rates(d: Optional[Deployment], observed_actions: int
              ) -> Dict[str, Optional[float]]:
    """GCS comparison rates, WP section 5. Null (None), not zero, when ruled out."""
    if d is None or d.R is None or d.K is None or not d.episodes:
        return {"verified_coverage": None, "open_liability_rate": None,
                "unwarranted_rate": None}
    outs = [classify(e) for e in d.episodes]
    admitted = sum(1 for e in d.episodes
                   if e.admit is not None and e.admit.admitter != e.admit.actor
                   and e.admit.independence.ok())
    ver = outs.count(OUT_VERIFIED)
    opn = outs.count(OUT_OPEN_LIABILITY)
    unw = outs.count(OUT_UNWARRANTED)
    return {
        "verified_coverage": (ver / admitted) if admitted else 0.0,
        "open_liability_rate": (opn / admitted) if admitted else 0.0,
        "unwarranted_rate": (unw / observed_actions) if observed_actions else 0.0,
    }


def comparable(a: Optional[Deployment], b: Optional[Deployment]) -> bool:
    ra, rb = gcs_rates(a, 1), gcs_rates(b, 1)
    return ra["verified_coverage"] is not None and rb["verified_coverage"] is not None


def evidence_hash(record: str) -> str:
    return hashlib.sha256(record.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------
R1 = Rule("no-unreviewed-funds-transfer", "const-v3")
K1 = Control("pre-transfer-gate", "sha256:aaa111")
S1 = "payments/EU/agent-actions"


def good_episode(eid="e1", t0=100.0, t1=110.0, admitter="A-indep", actor="X-agent"):
    return Episode(eid,
                   Admit(R1, K1, S1, t0, admitter, actor, iota=eid),
                   Attest(R1, K1, S1, t1, evidence_hash(eid), iota=eid))


def attest_for(eid, **kw):
    base = dict(R=R1, K=K1, S=S1, t1=110.0, E=evidence_hash(eid), iota=eid)
    base.update(kw)
    return Attest(**base)


def deployment(**kw):
    base = dict(R=R1, K=K1, S=S1, episodes=[good_episode()])
    base.update(kw)
    return Deployment(**base)


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------
class TestLevels(unittest.TestCase):
    def test_ruled_out_when_no_rule(self):
        self.assertEqual(sigma(Deployment(None, None, S1), 105), RULED_OUT)

    def test_stated_when_rule_without_control(self):
        self.assertEqual(sigma(Deployment(R1, None, S1), 105), STATED)

    def test_instrumented_without_episodes(self):
        self.assertEqual(sigma(Deployment(R1, K1, S1), 105), INSTRUMENTED)

    def test_verified_with_matching_independent_episode(self):
        self.assertEqual(sigma(deployment(), 120), VERIFIED)


class TestOutcomes(unittest.TestCase):
    def test_four_outcomes(self):
        g = good_episode()
        self.assertEqual(classify(g), OUT_VERIFIED)
        self.assertEqual(classify(Episode("e1", g.admit, None)), OUT_OPEN_LIABILITY)
        self.assertEqual(classify(Episode("e1", None, g.attest)), OUT_UNWARRANTED)
        bad = Episode("e1", g.admit,
                      attest_for("e1", K=Control("pre-transfer-gate", "sha256:bbb222")))
        self.assertEqual(classify(bad), OUT_UNDER_INVESTIGATION)


class TestFalsifiers(unittest.TestCase):
    def test_F1_self_admission_never_verified(self):
        d = deployment(episodes=[good_episode(admitter="X-agent", actor="X-agent")])
        self.assertNotEqual(sigma(d, 120), VERIFIED)

    def test_F2_version_change_resets(self):
        d = deployment()
        d.R = Rule(R1.r, "const-v4")
        self.assertEqual(sigma(d, 120), INSTRUMENTED)

    def test_F2_impl_hash_change_resets(self):
        d = deployment()
        d.K = Control(K1.k, "sha256:ccc333")
        self.assertEqual(sigma(d, 120), INSTRUMENTED)

    def test_F2_scope_change_resets(self):
        d = deployment()
        d.S = "payments/GLOBAL/agent-actions"
        self.assertEqual(sigma(d, 120), INSTRUMENTED)

    def test_F3_expiry_reverts_to_instrumented_not_zero(self):
        self.assertEqual(sigma(deployment(), 110 + H_PLACEHOLDER + 1), INSTRUMENTED)

    def test_F4_no_carryover_between_episodes(self):
        d = deployment(episodes=[good_episode("e1"),
                                 Episode("e2", good_episode("e2").admit, None)])
        self.assertEqual(sigma(d, 120, episode_id="e1"), VERIFIED)
        self.assertNotEqual(sigma(d, 120, episode_id="e2"), VERIFIED)

    def test_F5_attest_without_admit_is_unwarranted(self):
        self.assertEqual(classify(Episode("e1", None, good_episode().attest)),
                         OUT_UNWARRANTED)

    def test_F6_ruled_out_scores_null_not_zero(self):
        rates = gcs_rates(Deployment(None, None, S1), observed_actions=50)
        self.assertTrue(all(v is None for v in rates.values()))

    def test_F7_mismatch_is_under_investigation(self):
        bad = Episode("e1", good_episode().admit,
                      attest_for("e1", S="payments/US/agent-actions"))
        self.assertEqual(classify(bad), OUT_UNDER_INVESTIGATION)

    def test_F8_track_record_changes_cost_not_status(self):
        d0 = deployment(track_record_len=0)
        d9 = deployment(track_record_len=900)
        self.assertEqual(sigma(d0, 120), sigma(d9, 120))
        self.assertLess(admission_cost(d9), admission_cost(d0))
        self.assertGreater(admission_cost(d9), 0.0)   # never waived

    def test_F8_track_record_cannot_create_verified(self):
        d = Deployment(R1, K1, S1, episodes=[], track_record_len=10_000)
        self.assertEqual(sigma(d, 120), INSTRUMENTED)


class TestV02Independence(unittest.TestCase):
    """O2 specified at v0.2 (WP 3.1). Source: Meir Goldman, with attribution."""
    def test_F9_fail_closed_when_state_unknown(self):
        self.assertIsNone(admit_decision(R1, K1, S1, 100, "A-indep", "X-agent", "e1",
                                         DEFAULT_ACTION, current_state_known=False))

    def test_admits_when_state_known_and_independent(self):
        self.assertIsNotNone(admit_decision(R1, K1, S1, 100, "A-indep", "X-agent", "e1",
                                            DEFAULT_ACTION, current_state_known=True))

    def test_F10_each_incapacity_is_necessary(self):
        for name in ("I1_no_self_minting", "I2_authority_integrity",
                     "I3_receipt_integrity", "I4_no_bypass", "I5_liveness"):
            ind = Independence(**{name: False})
            e = Episode("e1", Admit(R1, K1, S1, 100, "A-indep", "X-agent", "e1",
                                    independence=ind), attest_for("e1"))
            self.assertEqual(classify(e), OUT_UNWARRANTED, name)
            self.assertIsNone(admit_decision(R1, K1, S1, 100, "A-indep", "X-agent", "e1",
                                             DEFAULT_ACTION, True, ind), name)

    def test_historical_permission_not_reused(self):
        d = deployment(track_record_len=10_000)
        self.assertIsNone(admit_decision(R1, K1, S1, 200, "A-indep", "X-agent", "e9",
                                         DEFAULT_ACTION, current_state_known=False))
        self.assertNotEqual(sigma(d, 120, episode_id="e9"), VERIFIED)


class TestV02Commitments(unittest.TestCase):
    """O3 specified at v0.2 (WP 3.2): admission commits to what MAY happen,
    attestation to what DID happen, bound by one episode ID."""
    def test_F11_episode_id_mismatch(self):
        bad = Episode("e1", good_episode().admit, attest_for("e1", iota="e2"))
        self.assertEqual(classify(bad), OUT_UNDER_INVESTIGATION)

    def test_F12_material_divergence_target(self):
        bad = Episode("e1", good_episode().admit,
                      attest_for("e1", action=Action(target="acct-999")))
        self.assertEqual(classify(bad), OUT_UNDER_INVESTIGATION)

    def test_F12_material_divergence_tool_and_params(self):
        for act in (Action(tool="delete"), Action(params=(("amount", "100000"),))):
            bad = Episode("e1", good_episode().admit, attest_for("e1", action=act))
            self.assertEqual(classify(bad), OUT_UNDER_INVESTIGATION)

    def test_matching_commitments_verify(self):
        self.assertEqual(classify(good_episode()), OUT_VERIFIED)


class TestComparison(unittest.TestCase):
    def test_rates_and_comparability(self):
        d = deployment(episodes=[
            good_episode("e1"),
            Episode("e2", good_episode("e2").admit, None),
            Episode("e3", None, good_episode("e3").attest)])
        r = gcs_rates(d, observed_actions=3)
        self.assertAlmostEqual(r["verified_coverage"], 0.5)
        self.assertAlmostEqual(r["open_liability_rate"], 0.5)
        self.assertAlmostEqual(r["unwarranted_rate"], 1 / 3)
        self.assertTrue(comparable(d, deployment()))
        self.assertFalse(comparable(d, Deployment(None, None, S1)))

    def test_rates_are_never_collapsed(self):
        self.assertEqual(set(gcs_rates(deployment(), 1)),
                         {"verified_coverage", "open_liability_rate", "unwarranted_rate"})


class TestOpenItems(unittest.TestCase):
    @unittest.skip("O1 OPEN: validity horizon H has no ratified value per risk class")
    def test_O1_horizon_ratified(self):
        self.assertIsNotNone(H_RATIFIED)

    @unittest.skip("O2 residual: I4 (no bypass) must be demonstrated on a real deployment; I6+ undecided")
    def test_O2_residual_bypass_demonstrated(self):
        pass

    @unittest.skip("O3 residual: per-action-class 'material' and canonical serialization unspecified")
    def test_O3_residual_materiality_and_serialization(self):
        pass

    @unittest.skip("O5 OPEN: field pilot on a live execution-governance system (not simulable)")
    def test_O5_field_pilot(self):
        pass


# --------------------------------------------------------------------------
def self_checksum() -> str:
    with open(__file__, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def demo() -> None:
    print(f"{INSTRUMENT_ID} {VERSION} -- worked example (modeled, not a deployed system)\n")
    eps = [
        good_episode("e1"),
        Episode("e2", good_episode("e2").admit, None),
        Episode("e3", None, good_episode("e3").attest),
        Episode("e4", good_episode("e4").admit, attest_for("e4", S="payments/US/agent-actions")),
        good_episode("e5", admitter="X-agent", actor="X-agent"),
        Episode("e6", good_episode("e6").admit, attest_for("e6", action=Action(target="acct-999"))),
        Episode("e7", Admit(R1, K1, S1, 100, "A-indep", "X-agent", "e7",
                            independence=Independence(I4_no_bypass=False)), attest_for("e7")),
    ]
    labels = {"e4": "scope mismatch", "e5": "self-admitted", "e6": "material divergence (target)",
              "e7": "admitter fails I4 (bypass possible)"}
    for e in eps:
        print(f"  {e.episode_id}: {classify(e):<20} {labels.get(e.episode_id, '')}")
    fc = admit_decision(R1, K1, S1, 130, "A-indep", "X-agent", "e8", DEFAULT_ACTION,
                        current_state_known=False)
    d = deployment(episodes=eps)
    print(f"\n  admission, current state unknown = {fc}  (fail-closed)")
    print(f"  sigma(now=120)                   = {sigma(d, 120)}")
    print(f"  sigma(after horizon)             = {sigma(d, 110 + H_PLACEHOLDER + 1)}")
    d2 = deployment(episodes=eps)
    d2.R = Rule(R1.r, "const-v4")
    print(f"  sigma(after version bump)        = {sigma(d2, 120)}")
    print(f"  GCS rates (7 observed)           = {gcs_rates(d, 7)}")
    print(f"  ruled-out institution rates      = {gcs_rates(Deployment(None, None, S1), 7)}")
    print("\n  Note: H is a placeholder (O1 OPEN); values shown are illustrative.")


def main() -> int:
    if "--demo" in sys.argv:
        demo()
        return 0
    print(f"{INSTRUMENT_ID} {VERSION} harness")
    print(f"self-checksum sha256: {self_checksum()}")
    print("Scope: specification vs modeled episodes; NOT a deployed system; NOT Conjecture P1.\n")
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2, stream=sys.stdout).run(suite)
    run = result.testsRun
    skipped = len(result.skipped)
    failed = len(result.failures) + len(result.errors)
    print(f"\nSUMMARY: {run} tests, {run - skipped - failed} pass, {skipped} skip (OPEN), {failed} fail")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
