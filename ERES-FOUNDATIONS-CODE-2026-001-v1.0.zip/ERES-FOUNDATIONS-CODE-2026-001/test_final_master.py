"""
test_final_master.py

Test suite for the ERES whitepaper
"Foundations of Sustainable Prosperity: A Global Perspective" (FINAL-MASTER).

Verifies canonical structure, required sections, ERES token coverage, and key
doctrinal phrases per ERES Institute house style. Also includes an operational
primitive — the FRAME absorption-ratio gate from Section 3 / Section 7 — with
its own tests.

Usage
-----
    python test_final_master.py
    python test_final_master.py path/to/FINAL-MASTER.md

Exits 0 if all tests pass, non-zero on failure.
"""

from __future__ import annotations

import re
import sys
import unittest
from pathlib import Path


DEFAULT_PATH = "Foundations_of_Sustainable_Prosperity_FINAL-MASTER.md"


# ---------------------------------------------------------------------------
# Operational primitive derived from the whitepaper
# ---------------------------------------------------------------------------


def absorption_ratio_pass(
    friction_in: float, friction_out_to_human_layer: float
) -> bool:
    """FRAME empirical gate (Sections 3 and 7).

    A FRAME passes only if the friction it takes in exceeds the friction it
    passes out to the human layer, measured over a stress event. Absorbing
    equal-to or more-than incoming friction to human layer is a failure.
    """
    if friction_in < 0 or friction_out_to_human_layer < 0:
        raise ValueError("Friction values must be non-negative.")
    return friction_in > friction_out_to_human_layer


# ---------------------------------------------------------------------------
# Document tests
# ---------------------------------------------------------------------------


class FinalMasterTests(unittest.TestCase):
    """Structural and content checks against the FINAL-MASTER markdown."""

    doc_path: str = DEFAULT_PATH

    @classmethod
    def setUpClass(cls) -> None:
        path = Path(cls.doc_path)
        if not path.exists():
            raise FileNotFoundError(
                f"FINAL-MASTER not found at {path.resolve()}. "
                f"Pass a path as the first CLI argument."
            )
        cls.text = path.read_text(encoding="utf-8")
        cls.lower = cls.text.lower()

    # -- Header / identity ---------------------------------------------------

    def test_title(self) -> None:
        self.assertIn("Foundations of Sustainable Prosperity", self.text)

    def test_subtitle(self) -> None:
        self.assertIn("A Global Perspective", self.text)

    def test_final_master_designation(self) -> None:
        self.assertIn("FINAL-MASTER", self.text)

    def test_institute_attribution(self) -> None:
        self.assertIn("ERES Institute", self.text)

    def test_bella_vista_location(self) -> None:
        self.assertIn("Bella Vista", self.text)

    # -- Required top-level sections ----------------------------------------

    def test_abstract_present(self) -> None:
        self.assertRegex(self.text, r"(?m)^## Abstract\b")

    def test_credits_present(self) -> None:
        self.assertRegex(self.text, r"(?m)^## Credits\b")

    def test_references_present(self) -> None:
        self.assertRegex(self.text, r"(?m)^## References\b")

    def test_license_present(self) -> None:
        self.assertRegex(self.text, r"(?m)^## License\b")

    def test_cc_by_license(self) -> None:
        self.assertIn("CC BY 4.0", self.text)

    # -- Body sections 1..11 -------------------------------------------------

    EXPECTED_SECTIONS = [
        (1, "The Working Ground"),
        (2, "Four Capacities"),
        (3, "Absorbing Friction"),
        (4, "From Extraction to Tuning"),
        (5, "The Bio-Ecologic Foundation"),
        (6, "Closed-Loop Design and the Number Anyone Can Call"),
        (7, "The Postulate"),
        (8, "Certifying the Outcome"),
        (9, "The Method"),
        (10, "Scale"),
        (11, "What Wins Hearts and Minds"),
    ]

    def test_all_numbered_sections(self) -> None:
        for num, title in self.EXPECTED_SECTIONS:
            with self.subTest(section=num):
                pattern = rf"(?m)^## {num}\.\s+.*{re.escape(title)}"
                self.assertRegex(
                    self.text, pattern, f"Section {num} ({title}) missing"
                )

    # -- Canonical ERES tokens ----------------------------------------------

    CANONICAL_TOKENS = [
        "BEE",
        "THOW",
        "HFVN",
        "FDRV",
        "GSSG",
        "AI.RE",
        "Bio-Ecologic Economy",
        "Bio-Ecologic Foundation",
        "Tiny House on Wheels",
        "Hands-Free Voice Navigation",
        "Full Drive Resonance Vehicle",
        "Green Solar Substrate Grid",
    ]

    def test_canonical_tokens(self) -> None:
        for token in self.CANONICAL_TOKENS:
            with self.subTest(token=token):
                self.assertIn(token, self.text, f"Canonical token missing: {token}")

    # -- Postulate (Section 7) ----------------------------------------------

    def test_postulate_notation(self) -> None:
        self.assertIn("AI.RE ≡ IT's / S / $ IN THE AI.RE", self.text)

    def test_postulate_three_forms(self) -> None:
        for form in ("IT's", "Sentry", "$ELF"):
            with self.subTest(form=form):
                self.assertIn(form, self.text)

    def test_air_wordplay(self) -> None:
        self.assertIn("it's in the AIR", self.text)

    def test_atmospheric_continuity(self) -> None:
        self.assertIn("atmospheric continuity", self.text)

    # -- Key doctrinal phrases ----------------------------------------------

    def test_number_anyone_can_call(self) -> None:
        self.assertIn("number anyone can call", self.lower)

    def test_willingness_clause(self) -> None:
        self.assertIn(
            "if you are willing, this system is willing", self.lower
        )

    def test_agriculture_is_the_anchor(self) -> None:
        self.assertIn("agriculture is the anchor", self.lower)

    def test_center_of_gravity(self) -> None:
        self.assertIn("center of gravity", self.lower)

    def test_extraction_and_tuning_both_present(self) -> None:
        self.assertIn("extraction", self.lower)
        self.assertIn("tuning", self.lower)

    def test_indio_real_estate(self) -> None:
        self.assertIn("Indio Real Estate", self.text)

    def test_r_ea_l_hyphenation(self) -> None:
        self.assertIn("R_EA-L", self.text)

    def test_healthy_happy_safe_triad(self) -> None:
        for term in ("Healthy", "Happy", "Safe"):
            with self.subTest(outcome=term):
                self.assertRegex(self.text, rf"\*\*{term}\*\*")

    # -- Scale bands (Section 10) -------------------------------------------

    SCALE_BANDS = ["Person", "Community", "Institution", "Domain", "Nation", "Planet"]

    def test_scale_bands(self) -> None:
        for band in self.SCALE_BANDS:
            with self.subTest(band=band):
                self.assertRegex(self.text, rf"\*\*{band}\.\*\*")

    # -- Method actions (Section 9): six-plus-one --------------------------

    SIX_ACTIONS = ["Publish", "Sponsor", "Pledge", "Protect", "Provide", "Advocate"]

    def test_six_actions(self) -> None:
        for action in self.SIX_ACTIONS:
            with self.subTest(action=action):
                # Each appears in a bold list item like "**Publish the standard.**"
                self.assertRegex(self.text, rf"\*\*{action}[^*]*\*\*")

    def test_seventh_relate_action(self) -> None:
        self.assertIn("relate to others", self.lower)

    # -- Four capacities (Section 2) ----------------------------------------

    FOUR_CAPACITIES = ["Health", "Law", "Protection", "Skills and Trades"]

    def test_four_capacities(self) -> None:
        for cap in self.FOUR_CAPACITIES:
            with self.subTest(capacity=cap):
                self.assertRegex(self.text, rf"\*\*{cap}\.\*\*")


# ---------------------------------------------------------------------------
# Primitive tests
# ---------------------------------------------------------------------------


class AbsorptionRatioTests(unittest.TestCase):
    """Tests for the FRAME absorption-ratio operational primitive."""

    def test_absorbing_frame_passes(self) -> None:
        # System absorbs most of a large incoming shock
        self.assertTrue(absorption_ratio_pass(10.0, 2.0))

    def test_pass_through_frame_fails(self) -> None:
        # System transmits more friction than it took in
        self.assertFalse(absorption_ratio_pass(5.0, 8.0))

    def test_equal_is_failure(self) -> None:
        # Strict inequality required — no absorption is failure
        self.assertFalse(absorption_ratio_pass(3.0, 3.0))

    def test_zero_in_zero_out_fails(self) -> None:
        # Vacuous case: nothing came in, nothing went out
        self.assertFalse(absorption_ratio_pass(0.0, 0.0))

    def test_negative_input_rejected(self) -> None:
        with self.assertRaises(ValueError):
            absorption_ratio_pass(-1.0, 0.5)

    def test_negative_output_rejected(self) -> None:
        with self.assertRaises(ValueError):
            absorption_ratio_pass(1.0, -0.5)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def main() -> None:
    # If the first CLI arg is a path, adopt it and remove it from argv so that
    # unittest doesn't try to interpret it.
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        FinalMasterTests.doc_path = sys.argv.pop(1)
    unittest.main(verbosity=2)


if __name__ == "__main__":
    main()
