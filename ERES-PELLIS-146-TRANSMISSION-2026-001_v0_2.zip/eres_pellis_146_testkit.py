#!/usr/bin/env python3
"""
ERES-PELLIS-146-TESTKIT-2026-001  v0.1 DRAFT
Test instrument for ERES-PELLIS-146-BRT-MAP-2026-001 v0.1.1 DRAFT

PURPOSE
-------
Make the mapping instrument's open items executable rather than rhetorical.

Two jobs:
  (1) Declare, as code, the BRT-side interface the mapping assumes.
      The BRTLike protocol below IS the Author-Verification register
      (AV-1..AV-5) written as an interface. Confirming or correcting it
      is a reading task, not a writing task.
  (2) Demonstrate, on synthetic data with a KNOWN transition, that the
      row-7 and row-12 tests are well-formed independently of BRT.

LAYER DOCTRINE POSITION
-----------------------
Layer 1 (Math Foundation) objects implemented here are Pellis (2026a),
Universal Spectral Calculus, sec. 14.6, eqs. (4838)-(4855), and Pellis
(2026b), Spectral Operator Theory for Predictive Stability, Failure
Prevention, and Autonomous Recovery in Critical Cyber-Physical
Infrastructure, 22 July 2026 -- specifically the spectral abscissa and
critical-boundary definitions, eqs. (391)-(399). The test
harness, thresholds, and grading vocabulary are ERES (Layers 3-4).
This kit derives no new mathematics and claims none.

WHAT THIS KIT CANNOT DO
-----------------------
Passing every test here does NOT move any mapping row to EXACT, and does
NOT close the 9.0 assertion gate. Synthetic data proves the tests are
well-formed; only real BRT data can grade the correspondence. Rows 8 and
12 remain CANDIDATE until run against the bridge simulation.

CHANGE LOG
----------
v0.1  Initial kit. 4/6 pass. T4 (row-12 early warning) failed at 0.00 detection.
v0.2  T4 failure diagnosed as TWO errors in this kit, not an ambiguity in the
      source:
        (a) criterion mis-operationalized as min_i |Re mu_i| across the whole
            spectrum. Corrected to the SPECTRAL ABSCISSA
            s(A) = sup{Re(lambda) : lambda in sigma(A)}, per Pellis (2026b),
            eq. (391), with the precursor being s(A) -> 0^- and failure at
            s(A) -> 0^+ (eq. 396-398). Dominance is by MAXIMUM REAL PART.
        (b) synthetic harness sign error: the stress profile drove the abscissa
            AWAY from zero rather than toward it. Baseline is now strictly
            stable and stress drives s(A) upward toward the critical boundary.
      With both corrected: T4 passes at 1.00 detection, 0.00 false alarm.
      No question to the author arises from T4. The kit was wrong.

v0.3  Rigor gap closed: pellis_operator, pellis_commutator and
      trace_invariant were implemented but exercised by NO test -- three
      Layer 1 constructions shipped unverified inside a verification
      instrument. Added T7 (Layer 1 algebraic smoke test) and T8 (classical
      containment limit: as a_n phi^-n -> b_n, P_phi(L) must reduce to the
      ordinary functional calculus sum b_n L^n, which is the source's own
      containment claim and was previously untested anywhere). Runner now
      writes a dated, reproducible run record.

Dependencies: numpy only.  Run: python3 eres_pellis_146_testkit.py
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Protocol, Sequence

import numpy as np

VERSION = "v0.3 DRAFT"
INSTRUMENT = "ERES-PELLIS-146-TESTKIT-2026-001"
MAPS_TO = "ERES-PELLIS-146-BRT-MAP-2026-001 v0.1.1 DRAFT"

RNG_SEED = 3690  # fixed for reproducibility


# ---------------------------------------------------------------------------
# SECTION 1 -- PRE-REGISTERED THRESHOLDS
# Fixed before any test was run. Changing a value here is a protocol
# amendment and must be logged in the mapping instrument's change log.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Thresholds:
    # Row 7: spectral gap must be computable and finite at every step
    gap_finite_fraction: float = 1.0

    # Row 7: two independent computations of lambda must agree to this tol
    cross_computation_tol: float = 1e-8

    # Row 12: warning window (steps before a transition) in which the
    # criterion max_i |Re mu_i| -> 0 must show approach
    warning_window: int = 12

    # Row 12: fraction of true transitions the criterion must anticipate
    detection_rate_min: float = 0.80

    # Row 12: false-positive ceiling (alarms in quiet regions / total steps)
    false_alarm_max: float = 0.15

    # Row 9: isospectral trace invariant conservation tolerance (relative)
    trace_drift_tol: float = 1e-6

    # Row 8: minimum |Spearman rho| for D_phi vs stability margin to count
    # as a positive finding. A null result is reported at equal weight.
    d_phi_corr_min: float = 0.50


TH = Thresholds()


# ---------------------------------------------------------------------------
# SECTION 2 -- THE DECLARED BRT INTERFACE  (== the AV register, as code)
#
# AV-1: coupling(t) -> square real/complex matrix. The operator-valued
#       representation of the sim state. If BRT has no such matrix, say so;
#       mapping rows 1-2 stay ANALOGICAL and rows 6-12 become unreachable.
# AV-2: driver(t)   -> matrix of the same shape (Schumann-band forcing).
#       Return zeros if forcing is not represented as an additive operator.
# AV-3: is_mute(t)  -> bool. TRUE iff step t is in the small-perturbation
#       regime. Row 5 hinges on whether "mute" means small-amplitude.
# AV-4: invariant(t)-> float or None. Whatever Phi10-10 CONSERVES. Return
#       None if Phi10-10 is a threshold/rule-gate rather than a conserved
#       quantity; row 9 then downgrades to ANALOGICAL. This is a real and
#       acceptable answer.
# AV-5: margin(t)   -> float. M_BRT(t). Row 10 asks whether this is a
#       distance from a reference configuration (metric) or a count/state.
# ---------------------------------------------------------------------------

class BRTLike(Protocol):
    """Interface the mapping assumes of the BRT bridge simulation."""

    n_steps: int

    def coupling(self, t: int) -> np.ndarray: ...      # AV-1
    def driver(self, t: int) -> np.ndarray: ...        # AV-2
    def is_mute(self, t: int) -> bool: ...             # AV-3
    def invariant(self, t: int) -> float | None: ...   # AV-4
    def margin(self, t: int) -> float: ...             # AV-5
    def transitions(self) -> Sequence[int]: ...        # active->yield step indices


# ---------------------------------------------------------------------------
# SECTION 3 -- LAYER 1 OBJECTS  (Pellis 2026, sec. 14.6)
# Implemented exactly as defined in the source. No ERES modification.
# ---------------------------------------------------------------------------

PHI = (1.0 + np.sqrt(5.0)) / 2.0  # golden scaling constant, phi^2 = phi + 1


def pellis_operator(L: np.ndarray, coeffs: Sequence[float]) -> np.ndarray:
    """P_phi(L) = sum_n a_n phi^-n L^n   (Pellis 2026, eq. 4949)."""
    out = np.zeros_like(L, dtype=complex)
    term = np.eye(L.shape[0], dtype=complex)
    for n, a_n in enumerate(coeffs):
        out += a_n * (PHI ** -n) * term
        term = term @ L
    return out


def pellis_commutator(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """[A,B]_phi = A*B - B*A   (eq. 4840, star-composition at leading order)."""
    return A @ B - B @ A


def spectrum(M: np.ndarray) -> np.ndarray:
    """Instantaneous eigenvalues (eq. 4846)."""
    return np.linalg.eigvals(M)


def spectral_gap(M: np.ndarray) -> float:
    """Delta-lambda(t): gap between the two leading eigenvalues by real part.

    This is the first argument of Pellis's joint functional
    F(Delta-lambda, M_BRT, E, C) -- mapping row 7.
    """
    ev = spectrum(M)
    re = np.sort(np.real(ev))[::-1]
    return float(re[0] - re[1]) if re.size >= 2 else float("nan")


def spectral_abscissa(M: np.ndarray) -> float:
    """s(A) = sup{Re(lambda) : lambda in sigma(A)}   (Pellis 2026b, eq. 391).

    Dominance is by MAXIMUM REAL PART -- not modulus, not distance to the
    axis. The precursor of failure is s(A) -> 0^- (eq. 396); the critical
    boundary Gamma_c is Re(lambda) = 0 (eq. 397); crossing is s(A) -> 0^+
    (eq. 398). This is the operational form of the sec. 14.6 criterion
    max_i |Re mu_i| -> 0 (eq. 4854).
    """
    return float(np.max(np.real(spectrum(M))))


# retained alias: the mapping instrument refers to this by its row-12 name
transition_criterion = spectral_abscissa


def d_phi(gaps: np.ndarray, dt: float = 1.0) -> np.ndarray:
    """D_phi(t) = sum_i |d P_phi(lambda_i)/dt|^2 (eq. 4849), computed here on
    the leading-gap trajectory as a scalar proxy. Proxy status is a
    limitation of this kit, not of the source definition."""
    d = np.gradient(gaps, dt)
    return d ** 2


def trace_invariant(M: np.ndarray, m: int = 2) -> float:
    """Tr(P_phi^m); conserved under invariant flows (eq. 4851)."""
    return float(np.real(np.trace(np.linalg.matrix_power(M, m))))


# ---------------------------------------------------------------------------
# SECTION 4 -- SYNTHETIC HARNESS
# A system with a KNOWN, planted transition. Ground truth is available, so
# the tests can be validated before any real data is involved.
# ---------------------------------------------------------------------------

@dataclass
class SyntheticBRT:
    """Reference implementation of BRTLike with planted transitions.

    Construction: a symmetric coupling matrix whose leading eigenvalue is
    driven toward the imaginary axis at planted transition times, mimicking
    the eq.-4854 signature. Mute steps are low-amplitude; the margin is a
    true distance from a reference configuration.
    """
    n: int = 8
    n_steps: int = 238           # matches the bridge sim step count
    planted: tuple = (60, 118, 176, 214)
    seed: int = RNG_SEED
    _cache: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        rng = np.random.default_rng(self.seed)
        self._base = rng.normal(size=(self.n, self.n)) * 0.15
        self._base = (self._base + self._base.T) / 2
        self._base -= np.eye(self.n) * 0.9   # baseline strictly stable: s(A) < 0
        self._ref = self._base.copy()
        self._rng = rng

    def _stress(self, t: int) -> float:
        """Approach-to-criticality profile: rises before each planted event."""
        s = 0.0
        for p in self.planted:
            d = p - t
            if 0 <= d <= 25:
                s = max(s, 1.0 - d / 25.0)
        return s

    def coupling(self, t: int) -> np.ndarray:            # AV-1
        if t in self._cache:
            return self._cache[t]
        stress = self._stress(t)
        drift = np.eye(self.n) * (0.95 * stress)   # drives s(A) -> 0^- (eq. 396)
        noise = self._rng.normal(size=(self.n, self.n)) * 0.01
        noise = (noise + noise.T) / 2
        M = self._base + drift + noise
        self._cache[t] = M
        return M

    def driver(self, t: int) -> np.ndarray:              # AV-2
        w = 2 * np.pi * 7.83 / 100.0                     # Schumann-band analogue
        return np.eye(self.n) * 0.02 * np.sin(w * t)

    def is_mute(self, t: int) -> bool:                   # AV-3
        return self._stress(t) < 0.05

    def invariant(self, t: int) -> float | None:         # AV-4
        return None  # synthetic system declares Phi10-10 unmodelled

    def margin(self, t: int) -> float:                   # AV-5
        return float(np.linalg.norm(self.coupling(t) - self._ref))

    def transitions(self) -> Sequence[int]:
        return self.planted


# ---------------------------------------------------------------------------
# SECTION 5 -- THE SIX TESTS
# Each returns (name, passed, detail). Negative results are reported at
# equal weight to positive ones -- a failure here is a finding, not a defect.
# ---------------------------------------------------------------------------

def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    denom = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / denom) if denom else 0.0


def test_1_interface(sim: BRTLike):
    """T1 -- AV register: does the object satisfy the declared interface?"""
    missing = []
    for meth in ("coupling", "driver", "is_mute", "invariant", "margin", "transitions"):
        if not hasattr(sim, meth):
            missing.append(meth)
    if missing:
        return ("T1 interface (AV-1..AV-5)", False, f"missing: {', '.join(missing)}")
    M = sim.coupling(0)
    ok = M.ndim == 2 and M.shape[0] == M.shape[1]
    return ("T1 interface (AV-1..AV-5)", ok,
            f"coupling shape {M.shape}; invariant declared: "
            f"{'yes' if sim.invariant(0) is not None else 'NO -> row 9 downgrades'}")


def test_2_row7_gap_computable(sim: BRTLike):
    """T2 -- Row 7: Delta-lambda(t) computable and finite at every step."""
    gaps = np.array([spectral_gap(sim.coupling(t)) for t in range(sim.n_steps)])
    frac = float(np.isfinite(gaps).mean())
    return ("T2 row-7 gap computable", frac >= TH.gap_finite_fraction,
            f"finite fraction {frac:.3f} (threshold {TH.gap_finite_fraction})")


def test_3_row7_cross_computation(sim: BRTLike):
    """T3 -- Row 7: two independent routes to the spectrum must agree.

    This is the test that matters for the JOINT computation: it shows the
    observable is route-independent, so Pellis computing from his side and
    ERES computing from the sim should agree up to numerics.
    """
    worst = 0.0
    for t in range(0, sim.n_steps, 17):
        M = sim.coupling(t)
        via_eig = np.sort(np.real(spectrum(M)))[::-1]
        via_char = np.sort(np.real(np.linalg.eigvals(M.T)))[::-1]  # transpose route
        worst = max(worst, float(np.max(np.abs(via_eig - via_char))))
    return ("T3 row-7 route independence", worst <= TH.cross_computation_tol,
            f"max disagreement {worst:.2e} (tol {TH.cross_computation_tol:.0e})")


def test_4_row12_early_warning(sim: BRTLike):
    """T4 -- Row 12: does the spectral abscissa approach 0 before transitions?

    Pre-registered: detection >= 80% of planted events within a 12-step
    window; false alarms <= 15% of quiet steps.
    """
    crit = np.array([spectral_abscissa(sim.coupling(t)) for t in range(sim.n_steps)])
    # alarm when the abscissa rises toward the critical boundary Re = 0
    alarm = crit > np.quantile(crit, 0.80)

    events = list(sim.transitions())
    detected = 0
    for p in events:
        lo = max(0, p - TH.warning_window)
        if alarm[lo:p + 1].any():
            detected += 1
    rate = detected / len(events) if events else 0.0

    quiet = np.ones(sim.n_steps, dtype=bool)
    for p in events:
        quiet[max(0, p - TH.warning_window):min(sim.n_steps, p + 3)] = False
    fa = float(alarm[quiet].mean()) if quiet.any() else 1.0

    ok = rate >= TH.detection_rate_min and fa <= TH.false_alarm_max
    return ("T4 row-12 early warning", ok,
            f"detection {rate:.2f} (min {TH.detection_rate_min}), "
            f"false-alarm {fa:.3f} (max {TH.false_alarm_max})")


def test_5_row8_d_phi_margin(sim: BRTLike):
    """T5 -- Row 8: correlation of D_phi(t) with the stability margin.

    Hypothesis H1 was pre-registered as: margin degrades as D_phi rises.
    A null result here is a legitimate reportable finding.
    """
    gaps = np.array([spectral_gap(sim.coupling(t)) for t in range(sim.n_steps)])
    dphi = d_phi(gaps)
    marg = np.array([sim.margin(t) for t in range(sim.n_steps)])
    rho = _spearman(dphi, marg)
    ok = abs(rho) >= TH.d_phi_corr_min
    verdict = "H1 supported" if ok else "NULL -- reported at equal weight"
    return ("T5 row-8 D_phi vs margin", ok, f"spearman {rho:+.3f} -> {verdict}")


def test_6_row9_invariant(sim: BRTLike):
    """T6 -- Row 9: is a trace invariant conserved under commutator flow?

    Conditional test: if AV-4 returns None (Phi10-10 not a conserved
    quantity), the test correctly reports NOT APPLICABLE rather than failing.
    """
    if sim.invariant(0) is None:
        return ("T6 row-9 invariant", True,
                "N/A -- AV-4 declares no conserved quantity; row 9 -> ANALOGICAL")
    vals = np.array([sim.invariant(t) for t in range(sim.n_steps)], dtype=float)
    drift = float(np.max(np.abs(vals - vals[0])) / (abs(vals[0]) + 1e-12))
    return ("T6 row-9 invariant", drift <= TH.trace_drift_tol,
            f"relative drift {drift:.2e} (tol {TH.trace_drift_tol:.0e})")


def test_7_layer1_algebra(sim: BRTLike):
    """T7 -- Layer 1 smoke test: golden identity and commutator antisymmetry.

    Exercises PHI, pellis_operator, pellis_commutator, trace_invariant.
    These are Pellis (2026a) constructions; this test verifies THIS KIT'S
    implementation of them, not the source mathematics.
    """
    checks = []
    checks.append(("phi^2 = phi + 1", abs(PHI ** 2 - (PHI + 1)) < 1e-12))

    rng = np.random.default_rng(RNG_SEED)
    A = rng.normal(size=(5, 5)); B = rng.normal(size=(5, 5))
    anti = float(np.max(np.abs(pellis_commutator(A, B) + pellis_commutator(B, A))))
    checks.append(("[A,B] = -[B,A]", anti < 1e-10))

    P = pellis_operator(A, [1.0, 0.5, 0.25])
    checks.append(("P_phi(L) finite", bool(np.all(np.isfinite(P)))))
    checks.append(("Tr(P^m) finite", np.isfinite(trace_invariant(np.real(P), 2))))

    failed = [n for n, ok in checks if not ok]
    return ("T7 layer-1 algebra", not failed,
            f"{len(checks) - len(failed)}/{len(checks)} checks"
            + (f"; failed: {', '.join(failed)}" if failed else ""))


def test_8_classical_limit(sim: BRTLike):
    """T8 -- Containment: P_phi must reduce to classical functional calculus.

    Pellis (2026a) states the calculus contains the linear theory as its
    limit: when a_n phi^-n -> b_n, P_phi(L) -> sum_n b_n L^n. Choosing
    a_n = b_n * phi^n makes the substitution exact, so the two computations
    must agree to numerical precision. Failure would indicate this kit
    mis-implements eq. (4949), not that the source claim is wrong.
    """
    rng = np.random.default_rng(RNG_SEED + 1)
    L = rng.normal(size=(6, 6)) * 0.3
    b = [1.0, -0.4, 0.2, 0.05]

    a = [b_n * (PHI ** n) for n, b_n in enumerate(b)]
    via_pellis = pellis_operator(L, a)

    classical = np.zeros_like(L, dtype=complex)
    term = np.eye(L.shape[0], dtype=complex)
    for b_n in b:
        classical += b_n * term
        term = term @ L

    err = float(np.max(np.abs(via_pellis - classical)))
    return ("T8 classical containment", err <= 1e-10,
            f"max deviation {err:.2e} (tol 1e-10)")


TESTS = (test_1_interface, test_2_row7_gap_computable, test_3_row7_cross_computation,
         test_4_row12_early_warning, test_5_row8_d_phi_margin, test_6_row9_invariant,
         test_7_layer1_algebra, test_8_classical_limit)


# ---------------------------------------------------------------------------
# SECTION 6 -- RUNNER
# ---------------------------------------------------------------------------

def run(sim: BRTLike | None = None) -> int:
    sim = sim if sim is not None else SyntheticBRT()
    print("=" * 74)
    print(f"{INSTRUMENT}  {VERSION}")
    print(f"tests the mapping: {MAPS_TO}")
    print(f"Layer 1 objects: Pellis (2026), sec. 14.6, eqs. 4838-4855")
    print(f"harness: {type(sim).__name__}  steps={sim.n_steps}  phi={PHI:.6f}")
    print("=" * 74)

    passed = 0
    record = []
    for fn in TESTS:
        name, ok, detail = fn(sim)
        line = f"[{'PASS' if ok else 'FAIL'}] {name:<32} {detail}"
        print(line)
        record.append(line)
        passed += int(ok)

    print("-" * 74)
    print(f"{passed}/{len(TESTS)} pass")
    print()
    print("SCOPE NOTE: synthetic harness only. These results establish that the")
    print("row-7 and row-12 tests are WELL-FORMED. They do not grade the BRT")
    print("correspondence and do not move any mapping row to EXACT. Rows 8 and 12")
    print("remain CANDIDATE until run against the bridge simulation.")
    print("=" * 74)

    # reproducible run record -- results ship with the kit, not asserted
    try:
        from datetime import datetime, timezone
        stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with open("eres_pellis_146_testkit_RUN.txt", "w") as fh:
            fh.write(f"{INSTRUMENT} {VERSION}\nrun (UTC): {stamp}\n")
            fh.write(f"harness: {type(sim).__name__}  steps={sim.n_steps}  "
                     f"seed={RNG_SEED}  numpy={np.__version__}\n")
            fh.write(f"result: {passed}/{len(TESTS)} pass\n\n")
            fh.write("\n".join(record) + "\n")
        print("run record written: eres_pellis_146_testkit_RUN.txt")
    except OSError as exc:
        print(f"(run record not written: {exc})")

    return 0 if passed == len(TESTS) else 1


if __name__ == "__main__":
    sys.exit(run())
