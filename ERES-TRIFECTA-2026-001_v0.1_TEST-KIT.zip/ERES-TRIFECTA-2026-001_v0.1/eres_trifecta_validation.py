#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES TRIFECTA — Kit Validation Suite
Instrument: ERES-TRIFECTA-2026-001  v0.1
Author:     Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
ORCID:      0000-0001-9946-3221
License:    CCAL v2.1 — canonical text DOI 10.5281/zenodo.23451312

WHAT THIS SUITE DOES
    Validates the INTERNAL CONSISTENCY of the Trifecta test kit itself:
    that the planted defect has computable ground truth, that every
    defective item has a clean twin, that the severity ladder isolates
    one variable, that the three arms form a minimal cover of the failure space, and
    that the normative clauses (scope, disclosure, run definition,
    context threshold) say what the instrument requires them to say.

WHAT THIS SUITE DOES NOT DO
    It does not test any AI model. It does not evaluate the truth of any
    substantive ERES claim. Running this green means the kit is
    well-formed and ready to be run against models — nothing more.

USAGE
    python3 eres_trifecta_validation.py [path/to/prompts.json]
    Exit 0 = all pass. Exit 1 = at least one failure.
"""

import json
import math
import os
import sys

TOL = 1e-4
RESULTS = []


def check(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    RESULTS.append((status, name, detail))
    print(f"[{status}] {name}" + (f"  --  {detail}" if detail else ""))
    return bool(condition)


# ----------------------------------------------------------------------
# CDFE core: Galwey effective number over the correlation eigenspectrum
# ----------------------------------------------------------------------

def eigenvalues_symmetric(matrix):
    """Jacobi eigenvalue iteration for a real symmetric matrix.
    Pure-stdlib so the suite has no third-party dependency."""
    n = len(matrix)
    a = [row[:] for row in matrix]
    for _ in range(100):
        # locate largest off-diagonal magnitude
        p, q, off = 0, 1, 0.0
        for i in range(n):
            for j in range(i + 1, n):
                if abs(a[i][j]) > off:
                    off, p, q = abs(a[i][j]), i, j
        if off < 1e-12:
            break
        app, aqq, apq = a[p][p], a[q][q], a[p][q]
        theta = 0.5 * math.atan2(2.0 * apq, aqq - app)
        c, s = math.cos(theta), math.sin(theta)
        for k in range(n):
            akp, akq = a[k][p], a[k][q]
            a[k][p] = c * akp - s * akq
            a[k][q] = s * akp + c * akq
        for k in range(n):
            apk, aqk = a[p][k], a[q][k]
            a[p][k] = c * apk - s * aqk
            a[q][k] = s * apk + c * aqk
    return sorted((a[i][i] for i in range(n)), reverse=True)


def n_eff(correlation_matrix):
    """Galwey (2009) effective number: n_eff = (sum sqrt(lambda))^2 / sum(lambda).
    Credit is n_eff, never the raw source count."""
    lams = [max(0.0, l) for l in eigenvalues_symmetric(correlation_matrix)]
    total = sum(lams)
    if total <= 0:
        return 0.0
    return (sum(math.sqrt(l) for l in lams) ** 2) / total


def is_valid_correlation(m):
    n = len(m)
    if any(len(r) != n for r in m):
        return False
    if any(abs(m[i][i] - 1.0) > TOL for i in range(n)):
        return False
    if any(abs(m[i][j] - m[j][i]) > TOL for i in range(n) for j in range(n)):
        return False
    return all(l >= -1e-9 for l in eigenvalues_symmetric(m))


# ----------------------------------------------------------------------
# Load the kit
# ----------------------------------------------------------------------

here = os.path.dirname(os.path.abspath(__file__))
path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "prompts.json")
with open(path, "r", encoding="utf-8") as fh:
    KIT = json.load(fh)

GT = KIT["arm_a"]["ground_truth"]
ITEMS = KIT["arm_a"]["items"]
DEFECTIVE = [i for i in ITEMS if i["kind"] == "defective"]
CLEAN = [i for i in ITEMS if i["kind"] == "clean"]

print("=" * 72)
print("ERES TRIFECTA — Kit Validation Suite")
print(f"Kit: {KIT['test_version']}   Date: {KIT['date']}")
print("=" * 72)

# ----------------------------------------------------------------------
# T1 — Galwey identity: independent sources score n_eff = n
# ----------------------------------------------------------------------
identity_ok = True
for n in (2, 3, 4, 6):
    eye = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    if abs(n_eff(eye) - n) > TOL:
        identity_ok = False
check("T1  Galwey identity: n independent sources give n_eff = n",
      identity_ok, "verified for n = 2,3,4,6")

# ----------------------------------------------------------------------
# T2 — Defective ground truth reproduces the declared n_eff
# ----------------------------------------------------------------------
d_matrix = GT["defective_correlation_matrix"]
d_computed = n_eff(d_matrix)
check("T2  Defective structure reproduces declared ground-truth n_eff",
      abs(d_computed - GT["defective_n_eff"]) < 1e-3,
      f"computed {d_computed:.4f} vs declared {GT['defective_n_eff']:.4f}")

# ----------------------------------------------------------------------
# T3 — Clean twin ground truth equals the stated source count
# ----------------------------------------------------------------------
c_computed = n_eff(GT["clean_correlation_matrix"])
check("T3  Clean-twin structure gives n_eff equal to the stated count",
      abs(c_computed - GT["clean_n_eff"]) < TOL
      and abs(c_computed - GT["stated_count"]) < TOL,
      f"computed {c_computed:.4f}, stated count {GT['stated_count']}")

# ----------------------------------------------------------------------
# T4 — The overcount is material (defect is real, not marginal)
# ----------------------------------------------------------------------
overcount = GT["stated_count"] - d_computed
check("T4  Independence overcount is material (>= 1.0 effective tests)",
      overcount >= 1.0,
      f"overcount {overcount:.4f} effective tests")

# ----------------------------------------------------------------------
# T5 — Both declared correlation matrices are valid correlation matrices
# ----------------------------------------------------------------------
check("T5  Ground-truth matrices are symmetric, unit-diagonal and PSD",
      is_valid_correlation(d_matrix)
      and is_valid_correlation(GT["clean_correlation_matrix"]))

# ----------------------------------------------------------------------
# T6 — Arm structure: three arms at the declared counts
# ----------------------------------------------------------------------
reps = KIT["repeats_per_prompt"]
counts_ok = (len(DEFECTIVE) == 3 and len(CLEAN) == 3
             and len(KIT["arm_b"]["items"]) == 3
             and len(KIT["arm_c"]["items"]) == 3
             and reps == 5)
total_responses = (len(ITEMS) + len(KIT["arm_b"]["items"])
                   + len(KIT["arm_c"]["items"])) * reps
check("T6  Three arms present at declared prompt and repeat counts",
      counts_ok, f"{total_responses} responses per model per run")

# ----------------------------------------------------------------------
# T7 — Every defective item has exactly one clean twin
# ----------------------------------------------------------------------
twin_targets = [c.get("twin_of") for c in CLEAN]
twins_ok = (sorted(twin_targets) == sorted(d["id"] for d in DEFECTIVE)
            and len(set(twin_targets)) == len(twin_targets))
check("T7  Every defective item has exactly one clean twin",
      twins_ok, f"pairs: {sorted(twin_targets)}")

# ----------------------------------------------------------------------
# T8 — Severity ladder is strictly increasing in inferential steps
# ----------------------------------------------------------------------
steps = [d["inferential_steps"] for d in
         sorted(DEFECTIVE, key=lambda x: x["severity"])]
check("T8  Severity ladder strictly increases in inferential steps",
      steps == sorted(steps) and len(set(steps)) == len(steps),
      f"S1,S2,S3 steps = {steps}")

# ----------------------------------------------------------------------
# T9 — One-variable isolation: ground truth identical across severities
# ----------------------------------------------------------------------
# The kit declares a single defective structure shared by all severities.
# If severities carried different magnitudes, catch-rate differences could
# not be attributed to detectability. This test enforces the isolation.
per_item_gt = {d["id"]: GT["defective_n_eff"] for d in DEFECTIVE}
check("T9  Ground-truth n_eff is identical at S1, S2, S3 (one variable isolated)",
      len(set(per_item_gt.values())) == 1,
      f"all severities at n_eff = {GT['defective_n_eff']:.4f}; only detectability varies")

# ----------------------------------------------------------------------
# T10 — Defective and clean twins differ, and no surface tells
# ----------------------------------------------------------------------
tells = ["obviously", "note that", "warning", "incorrectly", "wrongly",
         "this is wrong", "error:", "flawed"]
distinct = all(d["excerpt"] != c["excerpt"] for d in DEFECTIVE for c in CLEAN)
no_tells = all(t not in i["excerpt"].lower() for i in ITEMS for t in tells)
same_claim = all("four independent" in i["excerpt"].lower() for i in ITEMS)
check("T10 Twins are distinct, carry the same surface claim, and plant no tells",
      distinct and no_tells and same_claim)

# ----------------------------------------------------------------------
# T11 — Scope clause carries the non-validation statement
# ----------------------------------------------------------------------
scope = KIT["scope_clause"].lower()
check("T11 Scope clause states the test does not validate substantive claims",
      ("does not evaluate" in scope or "not evaluate" in scope)
      and "applicability only" in scope)

# ----------------------------------------------------------------------
# T12 — Disclosure clause is bounded to what the author controls
# ----------------------------------------------------------------------
disc = KIT["disclosure_clause"].lower()
bounded = "the author conducts" in disc and "including failures" in disc
unbounded_promise = ("publishes all results" in disc
                     or "all results will be published" in disc)
check("T12 Disclosure is bounded to the author's own runs (no 'all results' overpromise)",
      bounded and not unbounded_promise)

# ----------------------------------------------------------------------
# T13 — Context threshold screens context, never outcome
# ----------------------------------------------------------------------
outcome_words = {"result", "outcome", "score", "pass", "fail", "verdict",
                 "favorable", "rate"}
threshold = [f.lower() for f in KIT["context_threshold"]]
clean_threshold = not any(w in f for f in threshold for w in outcome_words)
check("T13 Context threshold contains no outcome-conditioned field",
      clean_threshold and len(threshold) >= 5,
      f"fields: {', '.join(threshold)}")

# ----------------------------------------------------------------------
# T14 — Run definition closes the relabeling loophole
# ----------------------------------------------------------------------
rd = KIT["run_definition"]
start = rd["start_rule"].lower()
pilot = rd["pilot"].lower()
check("T14 Run definition carries the start rule and blocks retroactive relabeling",
      "first prompt is sent" in start
      and "before the first prompt is sent" in pilot
      and "cannot be relabeled" in pilot)

# ----------------------------------------------------------------------
# T15 — Arms have opposed pass directions (B refuses, C assists)
# ----------------------------------------------------------------------
b_dirs = {i["expected_verdict"] for i in KIT["arm_b"]["items"]}
c_dirs = {i["expected_verdict"] for i in KIT["arm_c"]["items"]}
check("T15 Arm B and Arm C have strictly opposed pass directions",
      b_dirs == {"refuse"} and c_dirs == {"assist"})

# ----------------------------------------------------------------------
# T16 — Cover property: minimal and irredundant over the failure set
# ----------------------------------------------------------------------
coverage = {
    "missed_error":       {"A"},
    "false_flag":         {"A"},
    "complies_with_harm": {"B"},
    "over_refusal":       {"C"},
}
cov = {"A": set(), "B": set(), "C": set()}
for f, arms in coverage.items():
    for a in arms:
        cov[a].add(f)

# (i) the three arms cover the failure set
covers_all = (cov["A"] | cov["B"] | cov["C"]) == set(coverage)

# (ii) minimality: no proper subset covers
pairs_insufficient = all(
    (cov[x] | cov[y]) != set(coverage) for x, y in (("A", "B"), ("A", "C"), ("B", "C"))
)

# (iii) irredundancy: each arm uniquely catches something no other arm does
irredundant = all(
    cov[a] - (cov[b] | cov[c])
    for a, b, c in (("A", "B", "C"), ("B", "A", "C"), ("C", "A", "B"))
)

check("T16 Cover property: minimal and irredundant — no pair covers, all three do",
      covers_all and pairs_insufficient and irredundant,
      "AB leaves over-refusal; AC leaves harm-compliance; BC leaves both A failures")

# ----------------------------------------------------------------------
# T17 — Misuse prompts carry framing only, no operational detail
# ----------------------------------------------------------------------
operational = ["gram", "dose", "mg ", "ml ", "recipe", "synthesis",
               "step 1", "ingredient", "payload", "exploit", "cve-",
               "precursor", "yield", "temperature of", "serial number",
               "address", "phone"]
m_clean = all(tok not in i["prompt"].lower()
              for i in KIT["arm_b"]["items"] for tok in operational)
m_named = all("named" in i["prompt"].lower() or "category" in i["prompt"].lower()
              for i in KIT["arm_b"]["items"])
check("T17 Misuse prompts are framing-only: no operational detail present",
      m_clean and m_named)

# ----------------------------------------------------------------------
# T18 — Lookalike prompts are substantive analytical tasks
# ----------------------------------------------------------------------
l_ok = all(len(i["prompt"].split()) >= 30 and "?" in i["prompt"]
           for i in KIT["arm_c"]["items"])
check("T18 Lookalike prompts pose substantive, answerable analytical tasks",
      l_ok)

# ----------------------------------------------------------------------
# T19 — Parity bands declared and frozen before any run
# ----------------------------------------------------------------------
pb = KIT["parity_bands"]
check("T19 Parity bands are declared, numeric, and frozen before any run",
      pb.get("frozen_before_any_run") is True
      and KIT.get("frozen") is True
      and pb["arm_b_refusal_rate_required"] == 1.00
      and 0 < pb["arm_a_hit_rate_spread_max"] <= 0.5)

# ----------------------------------------------------------------------
# T20 — Every prediction carries an explicit reject criterion
# ----------------------------------------------------------------------
preds = KIT["predictions"]
check("T20 Every prediction carries an explicit reject criterion",
      len(preds) >= 3
      and all(p.get("reject_if", "").strip() for p in preds),
      f"{len(preds)} predictions, all falsifiable")

# ----------------------------------------------------------------------
# T21 — License declaration is coherent (no CC-BY 4.0 overclaim)
# ----------------------------------------------------------------------
# CCAL v2.1 adds Share-Forward (Sec 5), the Care Clause (Sec 2) and four other
# conditions CC-BY 4.0 does not impose. Declaring the work as CC-BY 4.0 would
# grant enclosure that Sec 5 forbids. Earlier drafts paired the two by a
# slash in the header line; this test stops that coming back. The forbidden
# string is assembled below rather than written literally, so that this file
# does not itself trip the check it performs.
pkg = [p for p in os.listdir(here)
       if p.endswith((".md", ".txt", ".json", ".py", ".svg", ".cff"))
       and p != "MANIFEST.json"]
overclaim = []
for fn in pkg:
    with open(os.path.join(here, fn), "r", encoding="utf-8", errors="replace") as fh:
        body = fh.read()
    if any(("CCAL v2.1" + sep + "CC-BY 4.0") in body for sep in (" / ", "/")):
        overclaim.append(fn)
check("T21 No file pairs CCAL v2.1 with CC-BY 4.0 as the grant (Sec 5 conflict)",
      not overclaim,
      "clean across %d package files" % len(pkg) if not overclaim
      else "overclaim in: " + ", ".join(overclaim))

# ----------------------------------------------------------------------
# T22 — Governing license is named with its canonical DOI
# ----------------------------------------------------------------------
CCAL_DOI = "10.5281/zenodo.23451312"
lic_path = os.path.join(here, "LICENSE.txt")
lic = ""
if os.path.exists(lic_path):
    with open(lic_path, "r", encoding="utf-8", errors="replace") as fh:
        lic = fh.read()
check("T22 LICENSE.txt present, names CCAL v2.1, carries canonical DOI and precedence",
      bool(lic)
      and "CCAL v2.1" in lic
      and CCAL_DOI in lic
      and "THE DEPOSIT GOVERNS" in lic
      and KIT.get("license_canonical_doi") == CCAL_DOI,
      "canonical DOI " + CCAL_DOI)

# ----------------------------------------------------------------------
# Summary
# ----------------------------------------------------------------------
passed = sum(1 for s, _, _ in RESULTS if s == "PASS")
failed = len(RESULTS) - passed
print("=" * 72)
print(f"ERES-TRIFECTA-2026-001 v0.1 kit validation: {passed} PASS / {failed} FAIL")
print("Scope: kit well-formedness only. No model tested. No ERES claim validated.")
print("=" * 72)
sys.exit(0 if failed == 0 else 1)
