# PlayNAC-KERNEL / NAC-GT: NERSC High-Performance Computing Reference Package

**Framework:** New Age Cybernetic Game Theory (NAC-GT) & `PlayNAC-KERNEL`  
**Target Environment:** NERSC *Perlmutter* & *Doudna* (NERSC-10) HPC Architectures (Lawrence Berkeley National Laboratory)  
**Originator:** Joseph Allen Sprute, Founder & Director, **ERES Institute for New Age Cybernetics** (Est. February 2012)  
**License:** Dual-Licensed under **CC-BY 4.0** and **Cybernetic Commons Attribution License v2.1 (CCAL v2.1)**  

---

## 1. Overview & Scientific Purpose
This package provides a reproducible Python/MPI reference implementation (`playnac_nersc_benchmark.py`) translating **New Age Cybernetic Game Theory (NAC-GT)** into distributed High-Performance Computing (HPC) workflows suitable for U.S. Department of Energy (DOE) Office of Science exploratory benchmarks.

Specifically, it demonstrates three core capabilities:
1. **Non-Zero-Sum Multi-Agent Coupling:** Uses `MPI.Allreduce` collective communication to balance local state restoration with global network coherence under simulated exogenous shocks (e.g., extreme-weather power-grid perturbations).
2. **Statistical Resonance Certification (*Strike, Ring, Earned*):** Converts qualitative cybernetic coherence criteria into verifiable Uncertainty Quantification (UQ) gates measuring instantaneous accuracy (*Strike*), harmonic low-variance stability (*Ring*), and sustained empirical proof (*Earned*).
3. **Human-in-the-Loop (`ARI/BEST`) Circuit Breakers:** Halts autonomous execution automatically when state deviation crosses predefined UQ safety bounds, supporting NERSC *Superfacility* human-oversight workflows.

---

## 2. Quickstart on NERSC *Perlmutter*

### Local / Single-Node Execution
```bash
python3 playnac_nersc_benchmark.py
```

### Multi-Node Slurm Batch Script (`submit_playnac.slurm`)
Save the following batch script and submit via `sbatch submit_playnac.slurm` using an active DOE ERCAP allocation:

```bash
#!/bin/bash
#SBATCH -A <YOUR_DOE_ERCAP_ACCOUNT>
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -t 00:10:00
#SBATCH -N 2
#SBATCH --ntasks-per-node=32
#SBATCH -J playnac_nacgt_bench

module load python
srun -n 64 python3 playnac_nersc_benchmark.py
```

---

## 3. Architectural Mapping to DOE / NERSC Workflows
| ERES Layer | Computational Equivalent | NERSC Implementation |
| :--- | :--- | :--- |
| **NAC-GT Coupling** | Distributed Multi-Agent Control | `mpi4py` collective state aggregation (`Allreduce`) |
| **NBERS Telemetry** | Real-Time Energy & Drift Logging | Structured JSON telemetry compatible with `Superfacility` APIs |
| **Resonance Certification** | Uncertainty Quantification (UQ) Gates | Rolling window threshold & variance checks (`certify_resonance`) |
| **ARI/BEST Alignment** | Human-in-the-Loop (HITL) Interrupt | Deterministic `uq_halt_limit` safety circuit breaker |

---

## 4. Credits & Provenance
* **Framework Originator:** Joseph Allen Sprute, Founder & Director, **ERES Institute for New Age Cybernetics** (Bella Vista, Arkansas, USA; Established February 2012).
* **Foundational Works:** *New Age Cybernetic Game Theory (NAC-GT)*, *PlayNAC-KERNEL*, *Empirically-Based Real-Time Rating Systems (NBERS)*, and *Achieving Harmony with ERES*.

## 5. Selected References
1. Wiener, N. (1948). *Cybernetics: Or Control and Communication in the Animal and the Machine*. MIT Press.
2. Beer, S. (1972). *Brain of the Firm: The Managerial Cybernetics of Organization*. Allen Lane / The Penguin Press.
3. Axelrod, R. (1984). *The Evolution of Cooperation*. Basic Books.
4. Ostrom, E. (1990). *Governing the Commons: The Evolution of Institutions for Collective Action*. Cambridge University Press.
5. Sprute, J. A. (2012–2026). *ERES Institute Foundational Compendium: NAC-GT, PlayNAC-KERNEL, and Falsifiable AI Governance*. ERES Institute Archive.

## 6. Open Licensing
This repository package is dual-licensed for unrestricted scientific, governmental, academic, and public-interest use under:
* **Creative Commons Attribution 4.0 International (CC-BY 4.0):** Free to share and adapt for any purpose with attribution to **Joseph Allen Sprute / ERES Institute for New Age Cybernetics**.
* **Cybernetic Commons Attribution License v2.1 (CCAL v2.1):** Derivative governance and computational safety implementations must preserve transparent provenance and attribution.
