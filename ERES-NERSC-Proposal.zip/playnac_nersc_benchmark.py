"""
playnac_nersc_benchmark.py
Reference MPI/Python Architecture for Benchmarking NAC-GT & PlayNAC-KERNEL on NERSC Perlmutter.

Credits & Provenance:
  Originator: Joseph Allen Sprute, Founder & Director, ERES Institute for New Age Cybernetics (Est. Feb 2012)
  Architecture: Empirically-Based Real-Time Rating Systems (NBERS), NAC-GT, PlayNAC-KERNEL, Resonance Certification

License:
  Dual-Licensed under Creative Commons Attribution 4.0 International (CC-BY 4.0)
  and Cybernetic Commons Attribution License v2.1 (CCAL v2.1).
"""

import time
import json
import numpy as np

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK = COMM.Get_rank()
    SIZE = COMM.Get_size()
except ImportError:
    COMM = None
    RANK = 0
    SIZE = 1


class NACGTAgent:
    """
    Represents a distributed cybernetic node (e.g., microgrid controller or AI sub-model)
    operating under New Age Cybernetic Game Theory (NAC-GT) non-zero-sum feedback rules.
    """

    def __init__(self, agent_id: int, state_dim: int = 16, learning_rate: float = 0.05):
        self.agent_id = agent_id
        self.rng = np.random.default_rng(seed=42 + agent_id)
        self.state = self.rng.normal(loc=1.0, scale=0.1, size=state_dim)
        self.target_equilibrium = np.ones(state_dim)
        self.lr = learning_rate

    def step(self, global_mean_state: np.ndarray, shock_vector: np.ndarray) -> dict:
        """
        Executes one cybernetic feedback step balancing local restoration with
        systemic multi-agent coherence.
        """
        local_error = self.target_equilibrium - self.state
        coherence_coupling = global_mean_state - self.state

        # NAC-GT update rule: local restoration + systemic coupling - exogenous shock
        delta = self.lr * (0.6 * local_error + 0.4 * coherence_coupling) - shock_vector
        self.state += delta

        # Empirical telemetry metrics (NBERS layer)
        deviation = float(np.linalg.norm(self.state - self.target_equilibrium))
        coherence_score = float(np.exp(-deviation))
        return {
            "agent_id": self.agent_id,
            "deviation": deviation,
            "coherence_score": coherence_score,
        }


def certify_resonance(coherence_history: list, threshold: float = 0.85) -> dict:
    """
    Translates ERES Resonance Certification ('Strike, Ring, Earned') into
    verifiable Uncertainty Quantification (UQ) & harmonic stability gates.
    """
    if len(coherence_history) < 5:
        return {"certified": False, "status": "INSUFFICIENT_TELEMETRY"}

    recent = np.array(coherence_history[-5:])
    strike = bool(recent[-1] >= threshold)
    ring = bool(np.std(recent) < 0.03)
    earned = bool(np.mean(recent) >= threshold and strike and ring)

    return {
        "strike": strike,
        "ring": ring,
        "earned": earned,
        "mean_coherence": round(float(np.mean(recent)), 5),
        "variance": round(float(np.var(recent)), 6),
    }


def run_benchmark(num_steps: int = 50, state_dim: int = 16, uq_halt_limit: float = 3.5):
    """
    Runs a distributed NAC-GT stability benchmark across MPI ranks and logs
    NERSC Superfacility-compatible JSON telemetry.
    """
    agent = NACGTAgent(agent_id=RANK, state_dim=state_dim)
    coherence_history = []
    telemetry_log = []
    start_time = time.perf_counter()

    for step_idx in range(num_steps):
        if COMM is not None:
            global_sum = np.zeros_like(agent.state)
            COMM.Allreduce(agent.state, global_sum, op=MPI.SUM)
            global_mean = global_sum / SIZE
        else:
            global_mean = agent.state.copy()

        # Inject simulated extreme grid/systemic shock at step 20
        shock = np.zeros(state_dim)
        if step_idx == 20:
            shock = agent.rng.normal(loc=0.0, scale=0.35, size=state_dim)

        metrics = agent.step(global_mean_state=global_mean, shock_vector=shock)
        coherence_history.append(metrics["coherence_score"])

        # Human-in-the-Loop (HITL) / ARI-BEST Circuit Breaker Check
        if metrics["deviation"] > uq_halt_limit:
            if RANK == 0:
                print(f"[CIRCUIT BREAKER] Step {step_idx}: UQ bound exceeded. Halting for HITL review.")
            break

        if RANK == 0:
            cert = certify_resonance(coherence_history)
            telemetry_log.append({
                "step": step_idx,
                "mpi_ranks": SIZE,
                "rank0_coherence": round(metrics["coherence_score"], 5),
                "resonance_certification": cert,
            })

    elapsed = time.perf_counter() - start_time

    if RANK == 0:
        summary = {
            "framework": "PlayNAC-KERNEL / NAC-GT NERSC Benchmark",
            "mpi_world_size": SIZE,
            "steps_completed": len(telemetry_log),
            "wall_time_sec": round(elapsed, 4),
            "final_certification": telemetry_log[-1]["resonance_certification"] if telemetry_log else {},
            "credits": "Joseph Allen Sprute / ERES Institute for New Age Cybernetics",
            "license": "CC-BY 4.0 / CCAL v2.1",
        }
        print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    run_benchmark(num_steps=50, state_dim=16)
