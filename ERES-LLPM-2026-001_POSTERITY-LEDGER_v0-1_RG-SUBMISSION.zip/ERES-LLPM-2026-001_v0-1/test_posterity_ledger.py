#!/usr/bin/env python3
"""
ERES-LLPM-2026-001 - POSTERITY Ledger
Reference implementation + invariant test suite (v0.1 Proposed).

Self-contained. Standard library only. Run:

    python3 test_posterity_ledger.py -v

This file makes the instrument's six invariants (I1-I6) executable and
FALSIFIABLE. It is a specification check, not a deployed system: it holds
NO real coordinates, holders, or magnitudes (Data-Integrity value 3). The
sample entries below are structural placeholders, not records of any place
or person.

License: CC BY 4.0    Authorship: Sentience convention (author JAS)
"""

from __future__ import annotations

import sys
import unittest
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


# --------------------------------------------------------------------------
# Domain types
# --------------------------------------------------------------------------

class AssetClass(Enum):
    WATER = "WATER"
    AG = "AG"
    THOW_SLOT = "THOW-slot"
    GSSG_NODE = "GSSG-node"
    COI_TERRITORY = "CoI-territory"


class TrustState(Enum):
    OPEN = "OPEN"        # provisional, awaiting lock authority
    VEILED = "VEILED"    # held-in-trust; magnitude/holder not publicly exposed
    EARNED = "EARNED"    # publicly verified, signed, ratified


class FloorStatus(Enum):
    ATTESTED = "Healthy-Happy-SAFE attested"
    FLAGGED = "attestation missing -> care-response"   # never grounds for removal


# --------------------------------------------------------------------------
# Errors that encode the invariants
# --------------------------------------------------------------------------

class InvariantViolation(Exception):
    pass

class WaterCommonsError(InvariantViolation):   # I1
    pass

class KeyBindingError(InvariantViolation):     # I3
    pass

class ReversionError(InvariantViolation):      # I5
    pass

class SurveillanceError(InvariantViolation):   # I6
    pass


# --------------------------------------------------------------------------
# Person layer (VEILED) - I4 / I6
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class VeiledEntitlement:
    """
    Person layer. An OPAQUE, non-reversible reference to the entitlement
    holder - never an identity and never a location. `ref` is a token
    (e.g. an Aura-Signature hash) that this ledger cannot resolve to a person.
    """
    ref: str
    proxy_held: bool = False     # held in proxy by an App-Parent (98/2)
    future_claim: bool = False   # not-yet-born holder (I5)


# --------------------------------------------------------------------------
# Entry
# --------------------------------------------------------------------------

@dataclass
class Entry:
    latitude: float
    longitude: float
    asset_class: AssetClass
    trust_state: TrustState
    coi: str
    fiduciary: str                        # the Center-of-Excellence holding it
    floor: Optional[FloorStatus] = None   # meaningful only for occupiable dwellings
    bee_link: Optional[str] = None        # true-cost accounting reference
    entitlement: Optional[VeiledEntitlement] = None
    sroc_ref: Optional[str] = None        # escrow / reversion contract reference

    def __post_init__(self):
        # I1 - Water-commons: WATER coordinates can never be EARNED (private).
        if self.asset_class is AssetClass.WATER and self.trust_state is TrustState.EARNED:
            raise WaterCommonsError(
                "I1: WATER-class coordinate cannot hold an EARNED (private) trust state"
            )


# --------------------------------------------------------------------------
# Invariant operations
# --------------------------------------------------------------------------

def public_view(entry: Entry) -> dict:
    """I4 - resource layer is public; person layer is NEVER exposed."""
    return {
        "latitude": entry.latitude,
        "longitude": entry.longitude,
        "asset_class": entry.asset_class.value,
        "trust_state": entry.trust_state.value,
        "coi": entry.coi,
        "fiduciary": entry.fiduciary,
        "floor": entry.floor.value if entry.floor else None,
        "bee_link": entry.bee_link,
        # entitlement (person layer) intentionally omitted
    }


def evaluate_floor(entry: Entry) -> FloorStatus:
    """
    I2 - Floor-universal. An occupied dwelling must carry a current
    Healthy-Happy-SAFE attestation. A missing attestation returns a
    care-response FLAG. There is deliberately no eviction path anywhere
    in this module (see TestI2.test_no_eviction_capability_exists).
    """
    occupied = entry.asset_class is AssetClass.THOW_SLOT and entry.entitlement is not None
    if occupied and entry.floor is not FloorStatus.ATTESTED:
        return FloorStatus.FLAGGED
    return FloorStatus.ATTESTED


def allocate(actor: str, entry: Entry, role_swap_passed: bool) -> Entry:
    """
    I3 - KEY-binding. Any GERP allocation or CoE definition touching a
    coordinate must pass the role-swap (planned as-if-recipient). No exemption.
    """
    if not role_swap_passed:
        raise KeyBindingError(
            f"I3: {actor} allocation refused - role-swap (design-as-if-recipient) not passed"
        )
    return entry


def revert(entry: Entry, capacity_regained: bool) -> Entry:
    """
    I5 - Reversion. Proxy-held entitlements are escrowed (SROC) and revert to
    the holder on regained capacity. Default-to-revert: ambiguity returns
    authority to the recipient, never retains it.
    """
    ent = entry.entitlement
    if ent is None:
        raise ReversionError("I5: no entitlement to revert")
    if ent.proxy_held and capacity_regained:
        entry.entitlement = VeiledEntitlement(
            ref=ent.ref, proxy_held=False, future_claim=ent.future_claim
        )
    return entry


def transfer_claim(entry: Entry, new_ref: str) -> Entry:
    """I5 - a not-yet-born future-claim can never be sold or transferred."""
    ent = entry.entitlement
    if ent is not None and ent.future_claim:
        raise ReversionError(
            "I5: a not-yet-born future-claim cannot be sold or transferred"
        )
    entry.entitlement = VeiledEntitlement(ref=new_ref)
    return entry


def query_by_coordinate(ledger: List[Entry], lat: float, lon: float) -> List[dict]:
    """I6 - permitted query: what resource/obligation exists at a coordinate."""
    return [public_view(e) for e in ledger
            if e.latitude == lat and e.longitude == lon]


def locate_person(*_args, **_kwargs):
    """
    I6 - No-surveillance. The ledger may NOT be queried to locate a person.
    This function exists only to refuse that query explicitly and loudly.
    """
    raise SurveillanceError(
        "I6: the POSTERITY ledger cannot be queried to locate a person"
    )


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------

_MODULE = sys.modules[__name__]


class TestI1WaterCommons(unittest.TestCase):
    def test_water_cannot_be_earned_private(self):
        with self.assertRaises(WaterCommonsError):
            Entry(0.0, 0.0, AssetClass.WATER, TrustState.EARNED, "CoI-A", "CoE-1")

    def test_water_may_be_open_or_veiled(self):
        for st in (TrustState.OPEN, TrustState.VEILED):
            e = Entry(0.0, 0.0, AssetClass.WATER, st, "CoI-A", "CoE-1")
            self.assertEqual(e.asset_class, AssetClass.WATER)

    def test_non_water_may_be_earned(self):
        e = Entry(0.0, 0.0, AssetClass.AG, TrustState.EARNED, "CoI-A", "CoE-1")
        self.assertEqual(e.trust_state, TrustState.EARNED)


class TestI2FloorUniversal(unittest.TestCase):
    def test_missing_attestation_yields_care_response(self):
        e = Entry(1.0, 2.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  floor=None, entitlement=VeiledEntitlement("tok"))
        self.assertEqual(evaluate_floor(e), FloorStatus.FLAGGED)

    def test_attested_dwelling_passes(self):
        e = Entry(1.0, 2.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  floor=FloorStatus.ATTESTED, entitlement=VeiledEntitlement("tok"))
        self.assertEqual(evaluate_floor(e), FloorStatus.ATTESTED)

    def test_no_eviction_capability_exists(self):
        # The floor is enforced by care-response, never removal. Assert the
        # module exposes no eviction-like operation at all.
        banned = ("evict", "remove", "expel", "displace", "eject", "clear")
        names = [n.lower() for n in dir(_MODULE) if callable(getattr(_MODULE, n))]
        for b in banned:
            self.assertFalse(
                any(b in n for n in names),
                f"I2 violation: an eviction-like callable containing '{b}' exists",
            )


class TestI3KeyBinding(unittest.TestCase):
    def setUp(self):
        self.e = Entry(3.0, 4.0, AssetClass.AG, TrustState.OPEN, "CoI-A", "CoE-1")

    def test_allocation_without_role_swap_refused(self):
        with self.assertRaises(KeyBindingError):
            allocate("GERP", self.e, role_swap_passed=False)

    def test_allocation_with_role_swap_allowed(self):
        self.assertIs(allocate("GERP", self.e, role_swap_passed=True), self.e)


class TestI4Describable(unittest.TestCase):
    def test_public_view_omits_person_layer(self):
        e = Entry(5.0, 6.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  entitlement=VeiledEntitlement("secret-token"))
        view = public_view(e)
        self.assertNotIn("entitlement", view)
        self.assertNotIn("secret-token", repr(view))

    def test_resource_layer_is_present(self):
        e = Entry(5.0, 6.0, AssetClass.GSSG_NODE, TrustState.EARNED, "CoI-A", "CoE-1",
                  bee_link="bee://ref")
        view = public_view(e)
        self.assertEqual(view["asset_class"], "GSSG-node")
        self.assertEqual(view["bee_link"], "bee://ref")


class TestI5Reversion(unittest.TestCase):
    def test_proxy_reverts_on_capacity(self):
        e = Entry(7.0, 8.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  entitlement=VeiledEntitlement("tok", proxy_held=True),
                  sroc_ref="sroc://x")
        revert(e, capacity_regained=True)
        self.assertFalse(e.entitlement.proxy_held)

    def test_proxy_retained_while_incapacitated(self):
        e = Entry(7.0, 8.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  entitlement=VeiledEntitlement("tok", proxy_held=True))
        revert(e, capacity_regained=False)
        self.assertTrue(e.entitlement.proxy_held)

    def test_future_claim_cannot_be_transferred(self):
        e = Entry(7.0, 8.0, AssetClass.THOW_SLOT, TrustState.VEILED, "CoI-A", "CoE-1",
                  entitlement=VeiledEntitlement("tok", future_claim=True))
        with self.assertRaises(ReversionError):
            transfer_claim(e, "buyer-token")


class TestI6NoSurveillance(unittest.TestCase):
    def test_coordinate_query_allowed(self):
        ledger = [
            Entry(9.0, 10.0, AssetClass.WATER, TrustState.OPEN, "CoI-A", "CoE-1"),
            Entry(9.0, 10.0, AssetClass.AG, TrustState.EARNED, "CoI-A", "CoE-1"),
            Entry(1.0, 1.0, AssetClass.GSSG_NODE, TrustState.EARNED, "CoI-B", "CoE-2"),
        ]
        hits = query_by_coordinate(ledger, 9.0, 10.0)
        self.assertEqual(len(hits), 2)
        for h in hits:
            self.assertNotIn("entitlement", h)

    def test_person_location_query_refused(self):
        with self.assertRaises(SurveillanceError):
            locate_person("any-token")


if __name__ == "__main__":
    unittest.main(verbosity=2)
