# ERES-LLPM-2026-001 — POSTERITY Ledger (v0.1 Proposed)

A specification-and-test package for the **Longitude–Latitude Property-Management Instrument**, the geospatial anchor that fixes the ERES SUCCESS / KEY architecture to physical coordinates so its floor is verifiable on the ground and inheritable across generations.

Prepared for external review.

## Contents

| File | What it is |
|---|---|
| `ERES-LLPM-2026-001_POSTERITY-LEDGER_v0-1.md` | The instrument: purpose, scope rule, record schema, six invariants, open items. |
| `test_posterity_ledger.py` | Self-contained reference implementation **plus** a test suite that makes the six invariants executable and falsifiable. |
| `README.md` | This file. |
| `METADATA.txt` | Deposit metadata: title, abstract, keywords, license, DOI slot. |

## Run it

No dependencies. Standard library only.

```bash
python3 test_posterity_ledger.py -v
```

Expected: `Ran 15 tests ... OK`.

## What the tests actually check

Each invariant in the instrument is turned into a pass/fail test, so the design claims are checkable rather than merely asserted:

- **I1 — Water-commons.** A `WATER` coordinate cannot be assigned an `EARNED` (private) trust state; construction raises.
- **I2 — Floor-universal.** An occupied dwelling missing its Healthy-Happy-SAFE attestation returns a **care-response flag**, and the module is asserted to expose **no eviction-like operation at all**. The floor is held by care, never by removal.
- **I3 — KEY-binding.** An allocation that has not passed the role-swap (design-as-if-recipient) is refused, at any scale — including the planetary planner (GERP).
- **I4 — Describable / VEILED.** The public view exposes the resource layer and never the person layer; the entitlement holder is an opaque, non-reversible token.
- **I5 — Reversion.** Proxy-held entitlements revert to the recipient on regained capacity (default-to-revert); a not-yet-born future-claim cannot be sold or transferred.
- **I6 — No-surveillance.** Queries by coordinate are permitted (what resource exists here); queries to locate a person are refused loudly.

## Design spine

The instrument anchors **resources and trust-obligations** to coordinates — water sources, agricultural plots, dwelling-slots, energy-grid nodes, community territories. It is defined **against** tracking people. A recipient's location is the most-protected datum in the system: veiled, non-queryable, recorded only as an entitlement-claim ("a dwelling is held for you"), never as whereabouts. A property ledger that logs where people are is a surveillance-and-eviction tool; this one refuses that from its first line, and the test suite enforces the refusal.

## Status and integrity

- **v0.1 Proposed**, pre-canonical. Not yet run through the multi-instrument ensemble review; do not read it as ratified.
- Contains **no real coordinates, holders, or magnitudes**. The sample entries in the test file are structural placeholders, not records of any place or person.
- The genuinely open problems are enforcement, not vocabulary — chiefly the **person-layer veil cryptography** (proving an entitlement without revealing who or where the holder is), which is unsolved and load-bearing.

## License & authorship

License: **CC BY 4.0**.
Authorship: *Sentience* convention (author J. A. Sprute, ERES Institute for New Age Cybernetics; AI draft assistance under Sentience, not co-authorship).
