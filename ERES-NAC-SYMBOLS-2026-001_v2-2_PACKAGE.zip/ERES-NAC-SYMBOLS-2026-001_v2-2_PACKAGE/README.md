# NAC Symbol Register v2.2: The Expression Chain

**ERES-NAC-SYMBOLS-2026-001 · v2.2 · Proposed (pre-MIEVM) · 2026-10-05**

A register that gives every mathematical symbol used in ERES New Age Cybernetics one home among the six NAC Domains (L1 ERES · Proof, L2 VERTECA · Gate, L3 SECUIR · Wheel, L4 CyberRAVE · Light, L5 GunnySack · Harvest, L6 SaleBuilders · Market), ordered along a ten-stage expression chain from emotion to semantic.

## Contents

| File | What it is |
| --- | --- |
| `ERES-NAC-SYMBOLS-2026-001_v2-2.md` | Master text (source of truth for humans and machines) |
| `ERES-NAC-SYMBOLS-2026-001_v2-2.pdf` | Rendered companion of the master text, with both figures |
| `ERES-NAC-SYMBOLS-2026-001_v2-2_register.json` | Machine-readable register: domains, stages, symbols, collisions, rules |
| `fig1_expression_chain.svg` | Figure 1: the chain in three movements |
| `fig2_domain_map.svg` | Figure 2: Trinity hub and the six Domains |
| `test_nac_symbols.py` | Test suite for the register's structural invariants |
| `CITATION.cff` | Citation metadata |
| `META.txt` | Title, abstract, keywords, license, citation line |
| `NOTICE_Advanced-ERES-Governors.md` | General Notice to Advanced ERES Governors announcing this release |
| `SHA256SUMS` | Checksums for every file above |

## Run the tests

Python 3.8 or later, standard library only:

```
python3 test_nac_symbols.py
```

Exit code 0 means every structural invariant holds. The tests check structure, not truth: they confirm the register is internally consistent (counts, homes, chain order, ownership, collision rules). They do not validate any symbol's physical or empirical claim.

## Status

v2.2 is Proposed and a child app of ERES-PIVOT-VSIM-2026-001 v0.2 (App-Parent: VERTECA PlayNAC Simulator). It assimilates a DeepSeek single-node review of v2.1 (see Review reconciliation in the master text); no symbol, placement or rule changed. Twenty-three symbols are on file in prior corpus instruments; four are proposed (☉, 𓋹, ⇄, ≈). All ten stage placements await the author's ruling. Canonization requires an MIEVM pass of at least five nodes with mean ≥ 9.0. Φ is held as a conjecture.

## License

CCAL v2.1 / CC-BY 4.0. Author: Joseph Allen Sprute, ORCID 0000-0001-9946-3221. ERES Institute for New Age Cybernetics, https://eresinstitute.org
