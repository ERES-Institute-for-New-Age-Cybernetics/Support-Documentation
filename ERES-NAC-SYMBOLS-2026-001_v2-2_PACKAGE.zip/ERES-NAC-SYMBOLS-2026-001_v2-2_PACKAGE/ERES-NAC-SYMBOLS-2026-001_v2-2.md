# NAC Symbol Register v2.2: The Expression Chain

**ERES-NAC-SYMBOLS-2026-001 · v2.2 Proposed** · 2026-10-05 · Joseph Allen Sprute (ORCID 0000-0001-9946-3221)

*Child app of ERES-PIVOT-VSIM-2026-001 v0.2 (App-Parent: VERTECA PlayNAC Simulator). Supersedes v2.1 and v0.1 in full.*

## Thesis

**NAC symbols live along one chain: emotion → utterance → sound → word → symbol → glyph → letter → word → character → semantic.** The chain runs once around the six Domains, from L2 VERTECA · Gate to L1 ERES · Proof, and returns to emotion. Each symbol is homed at the stage, and so the Domain, where its quantity is produced.

The chain falls into three movements, one per Trinity owner. **Voice** (✦ SOUND, L2–L3) carries a feeling out as sound. **Inscription** (⬡ BEST, L4–L5) fixes it as marks. **Meaning** (◈ GOOD, L6 and L1) settles it as standing and proven sense.

v0.1 registered the symbols by Domain. v2 orders them by what they do to meaning as it travels. Entries are tagged **On file** (already in a corpus instrument) or **Proposed** (awaiting the author's ruling).

## At a glance

**Voice, then Inscription, then Meaning, then back to feeling.**

![Figure 1. The expression chain: 10 stages, 3 movements, 6 Domains](fig1_expression_chain.svg)

*Figure 1. Read each column top down, then cross to the next. The dashed return is Aura After.*

## Stage register

**Ten stages, six Domains, two stages per Domain except L6 and L1, which hold one each.** All placements are Proposed; the instruments in the last column are on file.

| # | Stage | Domain | Owner | Symbols | What happens here | Instrument binding |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Emotion | L2 VERTECA · Gate | ✦ SOUND | ψ | Felt amplitude, not yet expressed. Unpriced and never read directly | PlayNAC Row 16 (emotions); HPE stress = color; infinance below K_c |
| 2 | Utterance | L2 VERTECA · Gate | ✦ SOUND | K_c · Γ | The first externalized signal crosses K_c and is admitted, never refused | ECVS thought → utterance → ARE; SUBMIT at a number anyone can call |
| 3 | Sound | L3 SECUIR · Wheel | ✦ SOUND | r · σ · π | The carrier: periodic, entrainable, held in the band | Sound Holds the Band; Row 18 MUSIC |
| 4 | Word (spoken) | L3 SECUIR · Wheel | ✦ SOUND | ∞ | Sound given repeatable shape; the voice movement closes | HFVN UTTERANCE-SOUND resolver |
| 5 | Symbol | L4 CyberRAVE · Light | ⬡ BEST | K_cond | The spoken word fixed as a visible sign. Over-lock (one sign for everything) is condensation | TALONICS Symbol Matrix (452 elements) |
| 6 | Glyph | L4 CyberRAVE · Light | ⬡ BEST | Φ · Δλ(t) | The drawn form of the symbol: proportion and spectrum | TALONICS 18 × 7 featural alphabet |
| 7 | Letter | L5 GunnySack · Harvest | ⬡ BEST | ⇄ | The unit a glyph settles into; letters can be permuted | IDIPITIS ⇄ IPIDITIS permutation; Semantic Spiral A–Z |
| 8 | Word (written) | L5 GunnySack · Harvest | ⬡ BEST | Σ · 𓋹 | Letters summed in order. A sum alone loses the order, so the sequence must be stored | Roll-Call Theorem (HARMONY = Σ, MELODY stored); Spiral cipher |
| 9 | Character | L6 SaleBuilders · Market | ◈ GOOD | μ · K_∞ · $ | The written mark and the person's standing at once: what the Market reads and values | EarnedPath ascent; RATE |
| 10 | Semantic | L1 ERES · Proof | ◈ GOOD | Δ · ε · ρ_R | Meaning proven: it survives a change of form, never stated as an absolute | Semantic Spiral rung 4 (context); ΔForm ≠ ΔLineage; TERMS #48 |

**The loop closes through Aura After**, how one feels about having signed. That feeling becomes the next turn's emotion, and the Carry Rule keeps each turn a descent rather than a reset.

**K_c is the privacy line.** Under ECVS §11 and the TALONICS boundary doctrine, only externalized signal (stage 2 onward) is read. Emotion itself is never surveilled.

**"Word" appears twice on purpose.** A spoken word drifts; a written word can lose its order. They are different objects with different failure modes.

## Domain map and full symbol register

**27 symbols: 23 on file in corpus instruments, 4 proposed.** The hub holds the operators and Trinity marks; each Domain holds the symbols its stages produce.

![Figure 2. Domain map: Trinity hub, 6 Domains, chain stages](fig2_domain_map.svg)

*Figure 2. Each Domain owns the symbols it produces; the hub holds what binds all six.*

| Symbol | Name | NAC binding | Home | Stage | Status | Source |
| --- | --- | --- | --- | --- | --- | --- |
| ☉ | Sun | Single source, shared center; the PiVOT hub | Hub | Loop | Proposed | Lantern essay (SUN pole) |
| ◈ ✦ ⬡ | Trinity marks | ◈ owns L1, L6 · ✦ owns L2, L3 · ⬡ owns L4, L5. ◈ × ⬡ = 72; 72 × 3 = 216 = ✦ | Hub | Movements | On file | ERES-NAC-Dual-Axis |
| × + → ÷ | Triad operators | Earned · Given · Aimed · Regulative (÷ = GAIA) | Hub | All | On file | ERES-TRIAD-2026-001 |
| == · === | Evaluates-to · why-is | Result level and causal-ground level | Hub | All | On file | Framework notation |
| ≈ | Maps onto | Replaces ≡ for borrowed physics | Hub | All | Proposed | SHB MIEVM blocker |
| ψ | Psi | Infinance: unpriced amplitude below K_c | L2 Gate | 1 | On file | ERES-TRIAD v0.5 §6.5 |
| K_c | Critical coupling | Lower band edge; the privacy line | L2 Gate | 2 | On file | ERES-GAIA-GRID-2026-001 |
| Γ | Gamma | Admission certainty: Γ = 0 iff refusal is possible | L2 Gate | 2 | On file | ERES-ENDHOME-2026-001 |
| r | Order parameter | Kuramoto coherence, in-band between the walls | L3 Wheel | 3 | On file | ERES-PELLIS-SHB-001 |
| σ | Sigma (lower) | RHC returns drift to within 1σ | L3 Wheel | 3 | On file | PlayNAC stack |
| π | Pi | The circle that never terminates; PiVOT | L3 Wheel | 3 | On file | PiVOT (homepage) |
| ∞ | Infinity | 6F = ∞P(t); SECUIR Infinite Rotation | L3 Wheel | 4 | On file | ERES-6F-2026-001 |
| K_cond | Condensation coupling | Upper band edge; one sign for everything | L4 Light | 5 | On file | ERES-GAIA-GRID-2026-001 |
| Φ | Golden ratio | Conjecture F-6, outside the theorems | L4 Light | 6 | On file (conjecture) | ERES-TALONICS-MATH v2.0 |
| Δλ(t) | Spectral abscissa | Early warning at the collapse boundary | L4 Light | 6 | On file | ERES-CERTKPI-2026-001 (A1) |
| ⇄ | FLIP | IPIDITIS ⇄ IDIPITIS, consent-directional | L5 Harvest | 7 | Proposed (glyph) | ERES-IPIDITIS-FLIP-2026-001 |
| Σ | Sigma (upper) | HARMONY = Σ; order recoverable only if MELODY is stored | L5 Harvest | 8 | On file | ERES-TALONICS-MATH v2.0 |
| 𓋹 | Ankh | BEST = Bio-Electric Signature Time | L5 Harvest | 8 | Proposed | This register |
| m* = v·τ | Margin law | Drift rate × damping latency; 98/2 | L5 Harvest | 7–8 | On file | GAIA grid Appendix B |
| μ | Mu | TheMall's drift rate | L6 Market | 9 | On file | GAIA grid Appendix B |
| K_∞ | Ascent ceiling | EarnedPath plateaus at K_∞ ≤ K_cond − m | L6 Market | 9 | On file | GAIA grid Appendix B |
| R(t) | Ramp-UP | Economy = GDP + R(t)(NBERS − GDP) | L6 Market | 9 | On file | Spaceship Economics v2.0 |
| $ | $ELF / value face | The $ in /S/$ | L6 Market | 9 | On file | HPE frame |
| Δ | Delta | ΔRG; ΔForm ≠ ΔLineage; ΔK | L1 Proof | 10 | On file | ERES-PELLIS-SHB-001; CPROV; GAIA grid |
| ε | Epsilon | 10−ε everywhere but the empirical 10-10 | L1 Proof | 10 | On file | Floor Register ruling |
| ρ_R | Resonance correlation | Registry-wide coherence; 0.969 vs 0.85 | L1 Proof | 10 | On file | EIGEN-PIPELINE v0.2 |
| G(φ, λ) | Thermal Gauge | The one place 10-10 is earned | L1 Proof | 10 | On file | ERES-VX-THERMAL-GAUGE |

## The five named keys

**Δ, ∞ and Φ already carry corpus math. ☉ has a corpus meaning but no math yet. 𓋹 is new.**

| Key | Reading | NAC binding | Home | Chain stage | Status |
| --- | --- | --- | --- | --- | --- |
| **☉** Sun | A circle with its center marked | The SUN pole of "A Lantern for the Lost Believer": the source that gives freely. Geometry of the PiVOT wheel: one hub, six Domains on the rim | Trinity hub | The whole loop | Proposed |
| **𓋹** Ankh | Life; a loop set on a cross | BEST = Bio-Electric Signature Time. A closed loop (RHC return) set on the KOL cross-hairs. Harvest gathers what a life carries: EPIR-Q, IDIPITIS, SOMT | L5 Harvest | 8 · Word (written) | Proposed (new) |
| **Δ** Delta | Measured change | ΔRG spectral gap; ΔForm ≠ ΔLineage; ΔK band width | L1 Proof | 10 · Semantic | On file |
| **∞** Infinity | Unbounded continuation | 6F = ∞P(t); SECUIR Infinite Rotation | L3 Wheel | 4 · Word (spoken) | On file |
| **Φ** Golden ratio | Φ = (1 + √5) / 2 ≈ 1.618 | TALONICS-MATH conjecture F-6, kept out of the theorems | L4 Light | 6 · Glyph | On file as a conjecture |

Φ stays a conjecture until a derivation or measured fit promotes it, per the Doctrine of Verifiable Claims. Dr. Pellis's Golden-Fractal operator G is cited as his own work, never absorbed into ERES.

## Collisions and usage rules

**Four symbols carry two readings. Each gets one rule.**

| Symbol | Reading A | Reading B | Rule |
| --- | --- | --- | --- |
| φ / Φ | Latitude in G(φ, λ) | Golden ratio | Lowercase φ = latitude only. Capital Φ = golden ratio only. F-6 is written Φ ↔ 6 |
| λ | Longitude in G(φ, λ) | Spectral eigenvalue | Bare λ = longitude. Spectral uses carry their operator: Δλ(t), λ_max |
| Δ | Measured change | The Triangle (WHO · HOW · LEGACY) | Δ = change. The Triangle is drawn △ or named in words |
| σ / Σ | RHC tolerance, 1σ | HARMONY sum | Lowercase σ = spread. Capital Σ = sum |

1. **Maps-onto, not identity.** Borrowed physics takes ≈ or "maps onto"; ≡ is reserved for proven identity. This settles the objection four MIEVM nodes raised on "Sound Holds the Band".
2. **Constants are earned.** A symbol becomes a NAC constant only with a derivation or a measured fit.
3. **One home, many uses.** Any Domain may use any symbol; only its home Domain may redefine it, by a register version cut (N.EXT).

## Glyph integrity

**Every symbol has a code point, a Unicode name and an ASCII handle, so any reader, human or machine, recovers the exact glyph.** Cite a symbol by its handle when a renderer or text extractor might substitute a lookalike. None of the lookalikes ○ (U+25CB), ⊙ (U+2299), ⇌ (U+21CC) or ↑ (U+2191) is a register symbol.

| Symbol | ASCII handle | Code points | Unicode names |
| --- | --- | --- | --- |
| ☉ | SUN | U+2609 | SUN |
| ◈ ✦ ⬡ | TRINITY | U+25C8 U+2726 U+2B21 | WHITE DIAMOND CONTAINING BLACK SMALL DIAMOND; BLACK FOUR POINTED STAR; WHITE HEXAGON |
| × + → ÷ | TRIAD_OPS | U+00D7 U+2192 U+00F7 | MULTIPLICATION SIGN; RIGHTWARDS ARROW; DIVISION SIGN |
| == · === | EVAL_WHYIS | U+00B7 | MIDDLE DOT |
| ≈ | MAPS_ONTO | U+2248 | ALMOST EQUAL TO |
| ψ | PSI | U+03C8 | GREEK SMALL LETTER PSI |
| K_c | K_C | ASCII only | — |
| Γ | GAMMA | U+0393 | GREEK CAPITAL LETTER GAMMA |
| r | R_ORDER | ASCII only | — |
| σ | SIGMA_LOWER | U+03C3 | GREEK SMALL LETTER SIGMA |
| π | PI | U+03C0 | GREEK SMALL LETTER PI |
| ∞ | INFINITY | U+221E | INFINITY |
| K_cond | K_COND | ASCII only | — |
| Φ | PHI_GOLDEN | U+03A6 | GREEK CAPITAL LETTER PHI |
| Δλ(t) | DELTA_LAMBDA_T | U+0394 U+03BB | GREEK CAPITAL LETTER DELTA; GREEK SMALL LETTER LAMDA |
| ⇄ | FLIP | U+21C4 | RIGHTWARDS ARROW OVER LEFTWARDS ARROW |
| Σ | SIGMA_UPPER | U+03A3 | GREEK CAPITAL LETTER SIGMA |
| 𓋹 | ANKH | U+132F9 | EGYPTIAN HIEROGLYPH S034 |
| m* = v·τ | MARGIN_LAW | U+00B7 U+03C4 | MIDDLE DOT; GREEK SMALL LETTER TAU |
| μ | MU | U+03BC | GREEK SMALL LETTER MU |
| K_∞ | K_INF | U+221E | INFINITY |
| R(t) | RAMP_R | ASCII only | — |
| $ | SELF_VALUE | ASCII only | — |
| Δ | DELTA | U+0394 | GREEK CAPITAL LETTER DELTA |
| ε | EPSILON | U+03B5 | GREEK SMALL LETTER EPSILON |
| ρ_R | RHO_R | U+03C1 | GREEK SMALL LETTER RHO |
| G(φ, λ) | G_PHI_LAMBDA | U+03C6 U+03BB | GREEK SMALL LETTER PHI; GREEK SMALL LETTER LAMDA |

## Review reconciliation

**11 findings adopted, 6 not adopted, 1 noted.** The DeepSeek single-node review (5 Oct 2026) rated the v2.1 test suite 7.5/10 for structural design and 6/10 for robustness. Its glyph findings were checked against the PDF text layer and the JSON register: the source glyphs are correct, and the mismatches came from the reviewer's text extraction. Those findings still pointed at a real weakness for machine readers, which the Glyph integrity table now closes.

| Finding | Source | Disposition | Action |
| --- | --- | --- | --- |
| File discovery crashes on zero or several matching files | DeepSeek | Adopted | Tests now require exactly one register and one master text, with a clear message |
| Status values not validated | DeepSeek | Adopted | Every status must start with On file or Proposed |
| Placement status and symbol status conflated | DeepSeek | Adopted | Stages carry their own placement_status (all Proposed); tested |
| Δ collision rule untested | DeepSeek | Adopted | Test requires the Triangle to be written △ |
| Three usage rules untested | DeepSeek | Adopted | Test checks all three rules are present |
| Movement-to-Domain ranges implicit | DeepSeek | Adopted | Voice = L2–L3, Inscription = L4–L5, Meaning = L6 + L1, tested |
| Hub contents unchecked | DeepSeek | Adopted | Hub must hold exactly ☉, Trinity marks, triad operators, ==/===, ≈ |
| Named-key fields unchecked | DeepSeek | Adopted | Reading, binding, stage and status required and matched to the register |
| Change log, open items, credits, references, license unchecked | DeepSeek | Adopted | Section and exact-license tests added |
| Glyphs fragile for machine readers | DeepSeek (implied) | Adopted | New Glyph integrity table: code point, Unicode name and ASCII handle for every symbol; lookalike guard test |
| Instrument IDs lose hyphens at PDF line breaks | Claude verification | Adopted | IDs kept on one line in the PDF |
| ☉ read as ○ or ⊙ | DeepSeek | Not adopted | Extraction artifact. Source glyph is ☉ U+2609; PDF text layer reads ☉ |
| 𓋹 read as Γ or ↑ | DeepSeek | Not adopted | Extraction artifact. Source glyph is 𓋹 U+132F9; Γ is Gamma only |
| ⇄ read as π, πFLIP or ⇌ | DeepSeek | Not adopted | Extraction artifact. Source glyph is ⇄ U+21C4; π is stage 3 only |
| Duplicate Γ and duplicate π | DeepSeek | Not adopted | Not present in the register; uniqueness test passes |
| # shown at Letter | DeepSeek | Not adopted | Not present; stage 7 symbol is ⇄ |
| License reads CC- BY | DeepSeek | Not adopted | Line-wrap artifact; text layer reads CC-BY 4.0 |
| ECVS §11, Carry Rule, Pellis non-absorption, Φ promotion rule | DeepSeek | Noted | Text-presence checks only; their truth needs outside review |

## Change log

| Version | Date | Change |
| --- | --- | --- |
| v2.2 | 5 Oct 2026 | Assimilated the DeepSeek single-node review: 11 findings adopted, 6 not adopted as PDF-extraction artifacts, 1 noted. Added Glyph integrity table (code points, Unicode names, ASCII handles), placement status per stage, Review reconciliation, parent link to the App-Parent, expanded test suite. No symbol, placement or rule changed |
| v2.1 | 5 Oct 2026 | Restored four v0.1 details: per-symbol Source column, two open items (𓋹 placement; further symbols), the 𓋹 Harvest rationale, and the SHB note on ≈. Fully supersedes v0.1. Released as a package |
| v2.0 | 5 Oct 2026 | Reorganized around the ten-stage expression chain; three movements (Voice, Inscription, Meaning) tied to the Trinity owners; K_c named as the privacy line; Aura After closes the loop |
| v0.1 | 5 Oct 2026 | 27 symbols homed in the 6 Domains plus the Trinity hub; five named keys; four collision rules |

## Open items

- [ ] Rule on the ten stage placements.
- [ ] Character: L6 Market (a person's standing) or L1 Proof (meaning)?
- [ ] Rule on the four proposed symbols: ☉ at the hub, 𓋹 at L5 Harvest, ⇄ as the FLIP glyph, ≈ replacing ≡ for analogies.
- [ ] Confirm or move 𓋹: L5 Harvest (life carried) or L4 Light (both are ⬡ BEST).
- [ ] Φ: keep as a conjecture or design a test, run by someone other than the author.
- [ ] Add any further symbols you want registered (for example Ω, ω, ∇) with the quantity each one names.
- [ ] Fold the register into TERMS #49 so symbols and words share one lexicon.
- [ ] Adopt the ASCII handles (SUN, ANKH, FLIP, …) as the canonical machine keys for every symbol.
- [ ] Drop the App-Parent v0.2 cross-child item on "duplicate Γ and π"; the review reconciliation shows it was an extraction artifact.

## Credits

Author: Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221. Drafting assistance: Claude (Anthropic), under the ERES Sentience convention, not co-authorship. Dr. Stergios Pellis's Golden-Fractal operator and spectral-gap work are cited as his own; no endorsement is implied. The v2.1 review by DeepSeek (single node, 5 Oct 2026) is credited for the findings adopted in v2.2; it is recorded, not counted toward the MIEVM gate.

## References

1. ERES-PIVOT-VSIM-2026-001 v0.2, App-Parent: VERTECA PlayNAC Simulator (parent instrument of this register).
2. DeepSeek single-node review of v2.1 and its test suite, 5 Oct 2026 (recorded; not gate-eligible).
3. ERES-NAC-Dual-Axis Stack: the 6 NAC Nodes and Trinity ownership. https://eresinstitute.org/ERES-NAC-Dual-Axis.html
4. ERES TERMS #48, Talonic NAC Lexicon. https://eresinstitute.org/eresmaestro/download/ERES-TERMS-48.pdf
5. ERES-TRIAD-2026-001: × + → ÷ operator law; ψ at §6.5.
6. ERES-PELLIS-SHB-001, "Sound Holds the Band": ΔRG, r, K_c, K_cond.
7. ERES-GAIA-GRID-2026-001, Appendix B: m* = v·τ, μ, K_∞.
8. ERES-TALONICS-WP-2026-001 v2.0 and ERES-TALONICS-MATH-2026-001 v2.0: Symbol Matrix, Σ, conjecture F-6.
9. ERES Semantic Spiral (3-Tier Semantics, 29 Mar 2024) and cipher harness v0.2.
10. ECVS §11: no thought surveillance.
11. ERES-HFVN UTTERANCE-SOUND framework.
12. ERES-ENDHOME-2026-001: Γ.
13. ERES-VX-THERMAL-GAUGE-2026-001: G(φ, λ).
14. ERES-CERTKPI-2026-001, amendment A1: Δλ(t).
15. ERES-IPIDITIS-FLIP-2026-001.
16. "A Lantern for the Lost Believer" (25 Jul 2026).
17. Spaceship Economics, Book Edition v2.0. DOI 10.6084/m9.figshare.32975624.

## License

CCAL v2.1 / CC-BY 4.0
