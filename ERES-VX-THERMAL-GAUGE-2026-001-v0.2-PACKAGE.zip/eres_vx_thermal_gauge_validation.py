#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_vx_thermal_gauge_validation.py
===================================
Validation & Principle Suite for:
  "The Shape of the Well" — ERES-VX-THERMAL-GAUGE-2026-001 v0.2
  (V(x) as Band-Holding Potential; Latitude–Longitude Thermal Gauge
   for Property-MANAGEMENT)

Author-directed, drafted H2C2H with Claude (Anthropic).
License: CC-BY 4.0 — Joseph A. Sprute, ERES Institute for New Age Cybernetics.

Design contract (corpus standard, per eres_transmission_validation.py):
  * Confirm/falsify separation: every principle is tested from BOTH sides —
    the in-spec construction must PASS its check, and a null/wall construction
    must FAIL it. A suite that cannot fail proves nothing.
  * Synthetic data only. No network, no real-property data. The real-data
    run (NOAA/NREL x benchmark energy) is the v1.0 gate, not this file's job.
  * Exit code = verdict (0 = all tests pass; 1 = any failure), for MIEVM/CI.
  * DVC discipline: tests T1a/T1b machine-check DERIVED math; the rest
    exercise CONSTRUCTED definitions. PASS = evidence, not proof.

Tests
  T1  Homotopy Reduction (instrument §3.1/§3.3)
      a) Poschl-Teller spectrum: numerical diagonalization matches the
         analytic E_n. [DERIVED check]
      b) Reduction invariance: varying (V0, a) changes the internal level
         count but never the reduced object (two walls + non-empty
         interior). Falsify branch: a mapping keyed to level count breaks
         under parameter change; the reduced mapping cannot.
  T2  Thermal Gauge & Separation Principle (instrument §5.2/§5.2.1)
      a) G is computable from climate normals alone; fixed global
         (F_min, F_max) makes G cross-portfolio comparable.
      b) Weight-ratio law w_C/w_H = c_C/c_H: with the ratio enforced, the
         G-ordering matches the cost ordering; with the ratio broken
         (falsify branch), rank agreement degrades.
      c) Calibration protocol: fit weights on reference "cities," freeze,
         verify out-of-sample Spearman rank stability.
  T3  Comfort Loss asymmetry (instrument §5.3)
      Asymmetric L(T) (k_c > k_h, L_cool > L_heat) yields higher annual
      loss for the hot-wall trace than the mirror-image cold-wall trace;
      the symmetric null must show no such gap (falsify branch).
  T4  Separation dynamics: Sentry margin law + GERP replanning
      (instrument §5.2/§5.4)
      delta(t) drift with margin law m* = v*tau: alarm fires before breach
      iff margin >= v*tau (both branches checked); a regime shift defeats
      a stale plan but not a replanning loop.
  T5  Prediction-2 machinery: latitude-only null model (instrument §6)
      In a world where the longitude correction field C(phi,lambda)
      carries real signal, G beats the latitude-only null; in a control
      world where C is pure noise, the test must correctly report NO
      marginal value (falsify branch).

Usage:  python3 eres_vx_thermal_gauge_validation.py
"""

import sys
import numpy as np
from scipy.stats import spearmanr

SEED = 20260711
rng = np.random.default_rng(SEED)

RESULTS = []

def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    return bool(ok)


# ----------------------------------------------------------------------
# T1 — Homotopy Reduction: Poschl-Teller spectrum and boundary invariance
# ----------------------------------------------------------------------
def pt_analytic_levels(V0, a, hbar=1.0, m=1.0):
    """Bound-state energies of V(x) = -V0 sech^2(x/a). [DERIVED]"""
    lam = 0.5 * (-1.0 + np.sqrt(1.0 + 8.0 * m * V0 * a**2 / hbar**2))
    n_max = int(np.floor(lam))
    if lam == n_max and n_max > 0:      # edge: E_n = 0 is not bound
        n_max -= 1
    ns = np.arange(0, n_max + 1)
    return -(hbar**2 / (2 * m * a**2)) * (lam - ns) ** 2

def pt_numeric_levels(V0, a, L=30.0, N=4000, hbar=1.0, m=1.0):
    """Finite-difference diagonalization of H = -h^2/2m d2/dx2 + V(x)."""
    x = np.linspace(-L, L, N)
    dx = x[1] - x[0]
    V = -V0 / np.cosh(x / a) ** 2
    main = hbar**2 / (m * dx**2) + V
    off = -hbar**2 / (2 * m * dx**2) * np.ones(N - 1)
    from scipy.linalg import eigh_tridiagonal
    w = eigh_tridiagonal(main, off, select='v', select_range=(-V0, -1e-9))[0]
    return w

def reduced_object(levels, V0):
    """The ERES-reduced well: (lower wall, upper failure mode, interior?)."""
    return {
        "lower_wall_exists": True,               # continuum threshold E = 0
        "upper_failure_exists": True,            # well floor at -V0
        "interior_nonempty": levels.size >= 1,   # >= 1 bound state
    }

def test_T1():
    print("T1  Homotopy Reduction — spectrum check and boundary invariance")
    ok = True

    # (a) DERIVED check: analytic vs numerical spectrum
    V0, a = 8.0, 1.0
    Ea = pt_analytic_levels(V0, a)
    En = pt_numeric_levels(V0, a)
    n = min(len(Ea), len(En))
    err = np.max(np.abs(np.sort(Ea)[:n] - np.sort(En)[:n]))
    ok &= check("T1a analytic == numerical Poschl-Teller spectrum",
                len(Ea) == len(En) and err < 1e-3,
                f"{len(Ea)} bound states, max |dE| = {err:.2e}")

    # (b) reduction invariance under parameter change
    params = [(8.0, 1.0), (30.0, 1.0), (8.0, 2.5), (2.0, 0.8)]
    counts, reduced = [], []
    for (v, aa) in params:
        lv = pt_analytic_levels(v, aa)
        counts.append(len(lv))
        reduced.append(reduced_object(lv, v))
    count_varies = len(set(counts)) > 1
    reduced_invariant = all(r == reduced[0] for r in reduced)
    ok &= check("T1b internal level count varies with (V0, a)",
                count_varies, f"counts = {counts}")
    ok &= check("T1b reduced object invariant across (V0, a)",
                reduced_invariant, "two walls + non-empty interior in all cases")
    # falsify branch: a level-count-keyed mapping is NOT invariant
    ok &= check("T1b falsify: level-count-keyed mapping breaks (as it must)",
                not (len(set(counts)) == 1),
                "decorative data is provably non-load-bearing")
    return ok


# ----------------------------------------------------------------------
# Synthetic climate-normals world (shared by T2/T5)
# ----------------------------------------------------------------------
def synth_world(n_sites=200, lon_signal=True):
    """Sites with latitude phi, longitude lambda, 30-yr normals, and a
    'true' annual band-holding cost. Longitude acts only through a STATIC
    correction field C(phi,lambda) (continentality-like), per §5.1."""
    phi = rng.uniform(-60, 65, n_sites)                    # inhabited band
    lam = rng.uniform(-180, 180, n_sites)
    base = np.abs(phi) / 65.0                              # latitude driver
    C = 0.25 * np.sin(np.radians(lam) * 2.0) * (0.4 + 0.6 * base)
    noise = 1.0
    if not lon_signal:                                     # control world:
        C = np.zeros(n_sites)                              #  no lambda signal,
        noise = 0.0                                        #  normals purely
    hdd = np.clip(3000 * (base + C) + noise * rng.normal(0, 60, n_sites), 0, None)
    cdd = np.clip(1800 * (1 - base - C) + noise * rng.normal(0, 60, n_sites), 0, None)
    sol = np.clip(2000 * (1 - 0.7 * base) + noise * rng.normal(0, 40, n_sites), 100, None)
    return phi, lam, hdd, cdd, sol, C

def gauge(hdd, cdd, sol, wH, wC, wS, Fmin, Fmax):
    F = wH * hdd + wC * cdd - wS * sol
    return (F - Fmin) / (Fmax - Fmin)

def test_T2():
    print("T2  Thermal Gauge — Separation Principle, weight law, calibration")
    ok = True
    phi, lam, hdd, cdd, sol, _ = synth_world()

    # 'true' band-holding cost with asymmetric wall costs (c_C > c_H)
    cH, cC, cS = 1.0, 1.6, 0.3
    true_cost = cH * hdd + cC * cdd - cS * sol

    # fixed GLOBAL normalization constants (terrestrial-extremes stand-ins)
    Fmin, Fmax = -3000.0, 9000.0

    # (a) computable from normals alone (no building inputs anywhere above)
    G_ok = gauge(hdd, cdd, sol, cH, cC, cS, Fmin, Fmax)
    ok &= check("T2a Gauge computes from climate normals only",
                np.all(np.isfinite(G_ok)), f"{len(G_ok)} sites")

    # (b) weight-ratio law: enforced ratio -> rank agreement with cost
    rho_law, _ = spearmanr(G_ok, true_cost)
    G_broken = gauge(hdd, cdd, sol, cH, 0.4 * cH, cS, Fmin, Fmax)  # w_C/w_H << c_C/c_H
    rho_broken, _ = spearmanr(G_broken, true_cost)
    ok &= check("T2b w_C/w_H = c_C/c_H  -> G ranks by cost",
                rho_law > 0.999, f"rho = {rho_law:.4f}")
    ok &= check("T2b falsify: broken ratio degrades rank agreement",
                rho_broken < rho_law - 0.01,
                f"rho_broken = {rho_broken:.4f} < rho_law = {rho_law:.4f}")

    # (c) calibration protocol: fit on reference cities, freeze, test OOS
    idx = rng.permutation(len(phi))
    train, test = idx[:12], idx[12:]           # 12 "reference cities"
    A = np.stack([hdd[train], cdd[train], -sol[train]], axis=1)
    w_fit, *_ = np.linalg.lstsq(A, true_cost[train], rcond=None)
    G_frozen = gauge(hdd, cdd, sol, *w_fit, Fmin, Fmax)
    rho_oos, p_oos = spearmanr(G_frozen[test], true_cost[test])
    ok &= check("T2c frozen fitted weights hold out-of-sample",
                rho_oos > 0.95 and p_oos < 0.05,
                f"rho_oos = {rho_oos:.4f}, ratio w_C/w_H = {w_fit[1]/w_fit[0]:.3f} "
                f"(target {cC/cH:.3f})")
    return ok


# ----------------------------------------------------------------------
# T3 — Comfort Loss asymmetry
# ----------------------------------------------------------------------
def comfort_loss(T, Tlow=18.0, Thigh=26.0, kh=0.8, kc=1.4,
                 Lheat=1.0, Lcool=1.8):
    return (Lheat / (1 + np.exp(kh * (T - Tlow))) +
            Lcool / (1 + np.exp(-kc * (T - Thigh))))

def test_T3():
    print("T3  Comfort Loss — asymmetric walls vs symmetric null")
    ok = True
    t = np.linspace(0, 1, 8760)
    mid = 22.0
    hot = mid + 8 * np.sin(2 * np.pi * t) + 4      # hot-wall-riding trace
    cold = 2 * mid - hot                           # exact mirror image

    loss_hot = comfort_loss(hot).sum()
    loss_cold = comfort_loss(cold).sum()
    ok &= check("T3 asymmetric L(T): hot wall costs more than mirrored cold",
                loss_hot > 1.15 * loss_cold,
                f"hot/cold = {loss_hot/loss_cold:.3f}")

    # falsify branch: symmetric null (k_h=k_c, L_heat=L_cool) must show ~no gap
    sym = dict(kh=1.0, kc=1.0, Lheat=1.0, Lcool=1.0)
    lh = comfort_loss(hot, **sym).sum()
    lc = comfort_loss(cold, **sym).sum()
    ok &= check("T3 falsify: symmetric null shows no wall asymmetry",
                abs(lh / lc - 1.0) < 1e-6, f"hot/cold(sym) = {lh/lc:.6f}")
    return ok


# ----------------------------------------------------------------------
# T4 — Sentry margin law and GERP replanning under regime shift
# ----------------------------------------------------------------------
def sentry_breaches(v, tau, margin, horizon=200.0, dt=0.1):
    """delta(t) = v*t. Alarm at delta >= threshold - margin; remedy lands
    tau later. Breach iff delta(t_alarm + tau) > threshold."""
    threshold = 10.0
    t_alarm = (threshold - margin) / v
    if t_alarm > horizon:
        return False
    return v * (t_alarm + tau) > threshold + 1e-12

def test_T4():
    print("T4  Sentry margin law m* = v*tau; GERP replanning vs stale plan")
    ok = True
    v, tau = 0.05, 40.0
    m_star = v * tau
    ok &= check("T4 margin >= v*tau  -> no breach",
                not sentry_breaches(v, tau, m_star * 1.01),
                f"m = 1.01*m* = {m_star*1.01:.3f}")
    ok &= check("T4 falsify: margin < v*tau -> breach (as it must)",
                sentry_breaches(v, tau, m_star * 0.80),
                f"m = 0.80*m* = {m_star*0.80:.3f}")

    # regime shift: drift doubles mid-horizon. Stale plan keeps margin sized
    # for old v; replanning loop re-sizes margin to new v*tau.
    def run(replan):
        vv, margin = v, m_star * 1.05
        t, delta, threshold = 0.0, 0.0, 10.0
        alarmed, alarm_t = False, None
        while t < 400.0:
            if t >= 100.0:
                vv = 2 * v
                if replan:
                    margin = (2 * v) * tau * 1.05
            if not alarmed and delta >= threshold - margin:
                alarmed, alarm_t = True, t
            if alarmed and t >= alarm_t + tau:
                return False                     # remedy landed in time
            delta += vv * 0.1
            if delta > threshold:
                return True                      # breach
            t += 0.1
        return False
    ok &= check("T4 regime shift + stale plan -> breach", run(replan=False))
    ok &= check("T4 regime shift + GERP replanning -> held", not run(replan=True))
    return ok


# ----------------------------------------------------------------------
# T5 — Prediction 2 machinery: latitude-only null model
# ----------------------------------------------------------------------
def marginal_value_of_lambda(lon_signal):
    phi, lam, hdd, cdd, sol, _ = synth_world(n_sites=300, lon_signal=lon_signal)
    cH, cC, cS = 1.0, 1.6, 0.3
    energy = (cH * hdd + cC * cdd - cS * sol) + rng.normal(0, 80, len(phi))
    Fmin, Fmax = -3000.0, 9000.0
    G = gauge(hdd, cdd, sol, cH, cC, cS, Fmin, Fmax)

    rho_G, p_G = spearmanr(G, energy)
    rho_lat, _ = spearmanr(np.abs(phi), energy)
    # fraction of G-explained (rank) variance already explained by latitude
    frac = (rho_lat ** 2) / (rho_G ** 2)
    return rho_G, p_G, frac

def test_T5():
    print("T5  Prediction-2 machinery — latitude-only null model")
    ok = True
    rho_G, p_G, frac = marginal_value_of_lambda(lon_signal=True)
    ok &= check("T5 signal world: G significant and lambda adds value",
                (p_G < 0.05) and (frac < 0.90),
                f"rho_G = {rho_G:.3f}, latitude-only fraction = {frac:.2f}")
    rho_G0, p_G0, frac0 = marginal_value_of_lambda(lon_signal=False)
    ok &= check("T5 falsify: control world correctly reports NO marginal value",
                frac0 >= 0.90,
                f"latitude-only fraction = {frac0:.2f} (>= 0.90 -> reject lambda)")
    return ok


# ----------------------------------------------------------------------
def main():
    print("=" * 72)
    print("ERES-VX-THERMAL-GAUGE-2026-001 v0.2 — Validation & Principle Suite")
    print(f"seed = {SEED}   (confirm/falsify separated; exit code = verdict)")
    print("=" * 72)
    all_ok = True
    for t in (test_T1, test_T2, test_T3, test_T4, test_T5):
        all_ok &= t()
        print("-" * 72)
    n_pass = sum(1 for _, okk, _ in RESULTS if okk)
    print(f"VERDICT: {n_pass}/{len(RESULTS)} checks passed -> "
          f"{'PASS (evidence, not proof; CONSTRUCTED tags stand until real-data run)' if all_ok else 'FAIL'}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
