# The Shape of the Well
## V(x) as Band-Holding Potential — from the Schrödinger Equation to a Latitude–Longitude Thermal Gauge for Property-MANAGEMENT

**Instrument ID:** ERES-VX-THERMAL-GAUGE-2026-001 · **Version 0.2** (post-MIEVM revision — N.EXT of v0.1) · **Date:** 11 July 2026
**Author:** Joseph A. Sprute ("ERES Maestro"), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas, USA · ORCID 0000-0001-9946-3221
**Drafted H2C2H with Claude (Anthropic) under author direction** · **License:** CC-BY 4.0
**Companion artifacts:** `eres_vx_thermal_gauge_validation.py` (this package) · ERES-PELLIS-SHB-001 v2.2 *Sound Holds the Band* · ERES-GAIA-GRID-2026-001 v0.4

---

## Revision Log (v0.1 → v0.2)

Four-node MIEVM pass on v0.1: Claude 8.6 (drafting node — author-side, discounted), DeepSeek 6.5, ChatGPT 9.4, Qwen 9.0. Independent-node composite **8.3/10**. Convergent blockers, all addressed in this revision:

1. **Correspondence asserted, not derived** (DeepSeek, ChatGPT) → closed by §3.1 **Homotopy Reduction Lemma**: the mapping is formally topological (boundaries only); internal eigenvalues declared decorative. Adopted from DeepSeek's self-retracted-then-corrected remedy sequence.
2. **Weights underived** (all four nodes) → closed by §5.2.1: constraint formula **derived**, numbers remain declared policy, calibration protocol specified (98/2 pattern: the formula is DERIVED, the number is policy).
3. **Predictions under-specified** (Claude, DeepSeek) → §6 rewritten with matching protocols, null models, and reject thresholds.
4. **GAIA-column opacity / not self-contained** (DeepSeek) → Appendix A Minimal GAIA Lexicon added. (DeepSeek's reading of the v0.1 column contained extraction artifacts — "Wigall," "water keeper" — which do not appear in v0.1; the lexicon nonetheless resolves the underlying self-containment complaint.)
5. **ASHRAE stated loosely** (Claude, DeepSeek) → §5.3 rewritten against ASHRAE-55 operative-temperature/PMV conditions; band endpoints made declared parameters.
6. **No validation suite** (Claude, ChatGPT, Qwen) → `eres_vx_thermal_gauge_validation.py` ships in this package; confirm/falsify separated; exit code = verdict.
7. **Transmission table row over-tagged** (Claude self-deduction) → recalibrated CONSTRUCTED → CONJECTURE with linearity-gap footnote (§3, Table 1 note).
8. **"Page 5 corruption"** (DeepSeek) → not reproducible in the v0.1 source PDF; attributed to reviewer-side text extraction. Document rebuilt from a Markdown master (this file) regardless, so the failure mode is retired.
9. **Pellis citation hardening** (author directive, verified by web lookup 11 July 2026) → References updated: the Pellis manuscript is cited as **unpublished** (no public locator); identity anchors verified against his own public title pages; the Ioannina prohibition confirmed correct.

Qwen's **"10-10 DETAIL" standard** is adopted as the v1.0 exit condition (§9).

**Suite self-catch log (corpus tradition, per eres_transmission_validation.py):** the validation suite caught TWO of its own construction errors on first execution before external review — (1) T4's regime-shift scenario had a timing race in which the replanning branch's remedy landed exactly at the breach boundary (fixed by moving the shift so the remedy lands strictly in-band); (2) T5's control world retained site-level climate noise, which legitimately carries non-latitude information, so the "no marginal λ-value" null was falsely rejectable — the control world must be purely latitude-determined for the null test to mean what it claims (fixed; the correction sharpens Prediction 2's real-data protocol: the latitude-only null must be compared against *normals-beyond-latitude*, of which the λ-correction field is one component). Final run: 16/16 PASS, exit 0.

---

## Abstract

This instrument does two things. First, it fixes the correspondence between the potential-energy function V(x) of the time-independent Schrödinger equation and the two-sided resonance band of *Sound Holds the Band* (SHB) at the only level the "maps onto, never ≡" rule permits: the **topological** level. Both are confinement architectures with a lower wall (escape/incoherence), an upper failure mode (over-binding/condensation), and a non-empty habitable interior; nothing finer than the boundaries and the interior's existence is claimed to transfer (§3.1, Homotopy Reduction Lemma). Second, it instantiates the reduced landscape geophysically: latitude and longitude (φ, λ) coordinate a **Thermal Gauge** G(φ, λ) — a static, climate-normals-only potential field over the Earth's surface — and the human thermal-comfort band is read as a measured two-sided band for Property-MANAGEMENT. The Gauge is a provisioning input to GERP; all building-specific and time-dependent detail is exiled to the Sentry anomaly layer by the Separation Principle (§5.2). Weight ratios are constrained by a derived cost-asymmetry formula while the numbers remain declared policy. Three falsifiable Predictions carry explicit reject criteria and a shipping validation suite. All claims carry inline Doctrine-of-Verifiable-Claims tags.

---

## 1. Purpose and Scope

SHB (ERES-PELLIS-SHB-001) established that resonance is a bounded regime: a band between a lower critical coupling K_c (incoherence below) and an upper condensation threshold K_condensation (lock-in above), with Theorem 1 (two-sided synchronization band) and Corollary 1 (full synchronization is not resonance-preserving — the formal tune-not-mine). What SHB did not supply is the *landscape* object: a formal structure that **holds** the band the way a governor shapes a substrate. Quantum mechanics has owned that object for a century — the potential V(x). This instrument imports it at exactly the resolution the import can survive, and then puts the imported structure to work on real climate data.

**Scope discipline.** Claims are tiered: **[DERIVED]** — standard quantum mechanics, standard geophysics, and formulas proved within the operator model; **[CONSTRUCTED]** — the correspondence, the Gauge definition, and the integrations; **[CONJECTURE]** — explicitly quarantined items. No claim of quantum effects in buildings, economies, or property markets is made anywhere in this document (Appendix B makes the prohibitions exhaustive). The Schrödinger equation supplies *structure* (a bounded-spectrum classifier), never *mechanism*.

---

## 2. V(x) in the Schrödinger Equation **[DERIVED]**

The time-independent Schrödinger equation is the eigenvalue problem

$$\hat{H}\psi = E\psi, \qquad \hat{H} = -\frac{\hbar^2}{2m}\nabla^2 + V(x).$$

The kinetic term is universal; V(x) is the problem-defining input. Its shape determines whether states are bound or free, the discrete levels of bound states, where probability density concentrates, and the spectral gaps between levels. Any finite well yields three regimes on the energy axis:

- **E > 0 (unbound continuum):** delocalized scattering states — nothing is held.
- **Bound band (−V₀ < E < 0):** discrete, stable, distinct states coexisting in one confinement structure.
- **Well floor (deep-binding limit):** as binding deepens, excited structure is squeezed out; in the many-body limit, macroscopic ground-state occupation is literal condensation (Bose–Einstein).

The ERES readings of these regimes (incoherence / resonance / collapse) are the CONSTRUCTED overlay of §3, applied **after** the reduction of §3.1.

---

## 3. Correspondence: V(x) ↔ the SHB Band **[CONSTRUCTED — topological, "maps onto," never ≡]**

### 3.1 Homotopy Reduction Lemma **[CONSTRUCTED]**

Let W be any potential well holding a finite, non-zero number of bound states. Define the **ERES-reduced well** W_ERES as the quotient that identifies all internal bound eigenstates:

$$W_{\mathrm{ERES}} \equiv W/\!\sim, \qquad E_i \sim E_j \;\; \forall\, i,j \in \{0,\dots,N\}.$$

The only surviving structural data are:

1. the **lower wall** (escape to continuum) ⟷ K_c (SHB lower wall);
2. the **upper failure mode** (floor / deep-binding condensation) ⟷ K_condensation (SHB upper wall);
3. the **non-empty interior** (∃ at least one bound state) ⟷ the resonance band itself.

**Consequence.** Only the boundaries and the interior's existence map. The internal level count, level spacings, reflectionless properties, and soliton connections of any particular well are formally **decorative** for ERES purposes. This immunizes the instrument against the discrete-vs-continuous category error identified (and first committed, then self-retracted) in the DeepSeek MIEVM node: quantum wells hold countable bound states; the SHB band is a continuous coupling interval; only a topological correspondence survives that mismatch. It also dissolves ChatGPT's uniqueness demand ("prove Pöschl–Teller is the right potential"): after reduction, **every** admissible finite well maps to the same reduced object, so the choice of well is a visualization decision, not a load-bearing one.

### 3.2 The correspondence grid

| Schrödinger landscape (reduced) | SHB / Kuramoto band | GAIA Grid reading (Appendix A) |
|---|---|---|
| V(x): landscape input | Coupling architecture (SHB Fig. 1) | What GAIA-as-governor imposes on the substrate |
| Lower wall (escape) | K_c | Avatar (lower keeper) |
| Upper failure mode (floor) | K_condensation | Sentry (upper keeper) |
| Non-empty interior | Resonance band (Theorem 1, regime b) | TheWall — the structure holding the band |
| E > 0 continuum | Incoherence (r → 0) | TheALL — unpriced potential; infinance |
| Deep-binding condensation | Condensation (r → 1) | TheMall's ungoverned limit |
| "Gap to the walls stays open" | Spectral-gap language (ΔRG, Pellis dialogue) | Smoothing-is-winning |

**Table 1.** All rows CONSTRUCTED. *Recalibration note:* the v0.1 row "distinct eigenstates ↔ ERES Transmission" is removed from the grid and re-tagged **[CONJECTURE]**: eigenstates of a linear operator do not couple, so "synchronized difference" was carried entirely by the analogy — and after §3.1 the internal spectrum is decorative anyway. Transmission remains defined solely in SHB terms.

### 3.3 The candidate well, retained as verification anchor **[DERIVED math; CONSTRUCTED role]**

The Pöschl–Teller well is kept because it is exactly solvable, which makes the *reduction itself* checkable by machine:

$$V(x) = -V_0\,\mathrm{sech}^2(x/a), \qquad E_n = -\frac{\hbar^2}{2ma^2}\,(\lambda_{\mathrm{PT}} - n)^2, \quad n = 0,1,\dots,\lfloor \lambda_{\mathrm{PT}} \rfloor,$$

$$\lambda_{\mathrm{PT}}(\lambda_{\mathrm{PT}}+1) = \frac{2mV_0 a^2}{\hbar^2}.$$

(λ_PT is the standard well parameter; it is typographically distinguished from longitude λ throughout — Vocabulary Firewall applies.) The validation suite (Test T1) diagonalizes the discretized Hamiltonian, confirms the analytic spectrum, then varies (V₀, a) to show the internal level count changes while the reduced object — two walls, non-empty interior — is invariant. That is the machine-checkable content of §3.1: **a mapping that depended on internal levels would break under parameter change; the reduced mapping cannot.** Corollary 1 of SHB, in landscape language, survives reduction untouched: driving V₀ → ∞ is not resonance-preserving. *Manage the well depth; never maximize it.*

---

## 4. Figure 1

*(figure1.png in this package — panel A: the Pöschl–Teller well with its three regimes and bound band; panel B: the Thermal Gauge over latitude with the comfort band as a two-sided resonance band. Schematic; not fitted to data.)*

---

## 5. The Thermal Gauge: (φ, λ) as Coordinates of a Static Potential Field

### 5.1 Physical basis **[DERIVED]**, and the roles of φ and λ **[CONSTRUCTED]**

Mean annual insolation is, to first order, a function of latitude: it scales with the cosine of the solar zenith angle, falling from equator to poles. Latitude φ is a genuine **thermal driver**. Longitude λ has no intrinsic thermal law; it is formally defined here as the **static interpolation coordinate** over a precomputed correction field C(φ, λ), built once from 30-year climate normals and encoding continentality, elevation lapse, and time-averaged ocean-current anomalies. **Explicit prohibition:** no time-dependent oscillatory modes (ENSO, NAO, PDO) are embedded in λ or in C; the Gauge is a frozen landscape. Temporal dynamics belong exclusively to the Sentry layer (§5.4).

### 5.2 Definition and the Separation Principle **[CONSTRUCTED]**

$$G(\varphi,\lambda) \;=\; \frac{F(\varphi,\lambda) - F_{\min}}{F_{\max} - F_{\min}}, \qquad F(\varphi,\lambda) \;=\; w_H\,\mathrm{HDD}(\varphi,\lambda) + w_C\,\mathrm{CDD}(\varphi,\lambda) - w_S\,\mathrm{SOL}(\varphi,\lambda),$$

with HDD/CDD in degree-days against a declared base temperature T_base, SOL in kWh·m⁻²·yr⁻¹ converted by a declared factor into degree-day-equivalent units, and (F_min, F_max) **fixed global constants** taken from terrestrial climate extremes — never per-portfolio bounds — so G is comparable across portfolios (DeepSeek blocker resolved).

**Separation Principle (non-negotiable).** G is a function of 30-year climate normals **only**. It takes no building-specific inputs — no air-change rates, no HVAC efficiencies, no envelope values. A siting field must be evaluable *prior to acquisition*; a G requiring an energy audit would be a post-hoc accounting metric, not a planning landscape. All building physics lives in the per-property Sentry anomaly:

$$\delta(t) \;=\; \mathrm{Load}_{\mathrm{actual}}(t) \;-\; \mathrm{Baseline}\big(G(\varphi,\lambda)\big),$$

and the derived margin law m\* = v·τ (drift rate × damping latency; inherited DERIVED from ERES-GAIA-GRID Appendix B) applies to δ(t), never to G.

### 5.2.1 Weight constraint: derived formula, declared numbers **[DERIVED formula; policy numbers]**

Let c_H and c_C be the portfolio-declared marginal costs (monetary or BERA-denominated) of holding the band per unit degree-day excursion at the lower and upper walls respectively. If G is to rank locations by band-holding cost — its defining job — the weights cannot be free:

$$\boxed{\;\frac{w_C}{w_H} \;=\; \frac{c_C}{c_H}\;}$$

and since cooling works against a Carnot-limited COP while heating can approach or exceed unit delivered-energy ratios, c_C ≥ c_H in nearly all inhabited climates, giving the **default inequality** w_C/w_H ≥ 1. The formula is DERIVED (it is the condition under which G's ordering matches cost ordering under the linear model); the specific values of c_C, c_H, w_S, and T_base remain **declared policy**, per the 98/2 precedent — the validity formula is derived, the number is policy. **Calibration protocol:** weights are fit once, globally, against a declared reference-city training set using 30-year normals, then frozen for the life of the portfolio. Validation Test T2 executes this protocol on synthetic normals and verifies out-of-sample rank stability.

### 5.3 The comfort band, stated precisely **[CONSTRUCTED on DERIVED physiology]**

ANSI/ASHRAE Standard 55 defines thermal comfort zones over **operative temperature** conditioned on humidity, air speed, clothing (clo), and metabolic rate (met) — typically via the PMV/PPD method (|PMV| ≤ 0.5) or the graphic comfort-zone method. There is no unconditional "18–26 °C" in the standard; this instrument therefore declares its band endpoints as **parameters** [T_low, T_high] with defaults (18 °C, 26 °C) understood as an operative-temperature approximation at ~0.5–1.0 clo, ~1.0–1.3 met, moderate humidity — and requires any deploying portfolio to re-declare them per ASHRAE-55 conditions for its stock.

The band is two-sided and **asymmetric**. Define the Comfort Loss Function over operative temperature T:

$$L(T) \;=\; \frac{L_{\mathrm{heat}}}{1 + e^{\,k_h\,(T - T_{\mathrm{low}})}} \;+\; \frac{L_{\mathrm{cool}}}{1 + e^{\,-k_c\,(T - T_{\mathrm{high}})}},$$

with steepness (k_h, k_c) and wall costs (L_heat, L_cool) declared per deployment; epidemiological temperature–mortality curves motivate k_c > k_h and L_cool > L_heat in humid-heat climates. HDD counts lower-wall excursions, CDD counts upper-wall excursions, and COMFORT_LIVES (the Sanctuary Floor standard) names band occupancy. The annual integral ∫ L(T(t)) dt is the v1.0 upgrade path for F(φ, λ), replacing the linear degree-day sum. Validation Test T3 exercises L(T) and rejects the symmetric null.

### 5.4 Property-MANAGEMENT integration **[CONSTRUCTED]**

- **GERP (provisioning).** Per the discrimination chain (GERP provisions → SECUIR realizes → TheWall is the invariant), G is a GERP-side input: a slow, shared-budget planning field for HVAC capacity, retrofit priority, energy budgeting, and acquisition/disposition. A climate-driven regime shift is exactly the stale-plan scenario in which GERP replanning is jointly necessary; Test T4 simulates it.
- **Sentry (margin).** Each property carries a Sentry on δ(t) with m\* = v·τ; the 98/2 default applies per instance, validity-gated by v ≤ 0.02·ΔK/τ.
- **GSSG (siting).** The −w_S·SOL term makes G the siting logic for Green Solar-Sand Glass: a **wall-softening intervention** that lowers G locally — reshaping the well rather than pushing the occupants. Governor behavior by construction.
- **ARE register.** Vocabulary Firewall: this instrument writes to ARE = About Real Estate. The enforcement-conditional identity (ARE == OUR only under full 1000-Year Future Map enforcement) is noted, not advanced.
- **TheWall vs TheMall assignment — open, with a recorded lean.** Qwen's node argues G is TheWall-side (invariant habitability floor) with TheMall ascent economics operating *on top of* it; the author's earlier note flags acquisition logic as EarnedPath-scented. A GERP/SECUIR-style discrimination suite is the clean resolver; until it runs, the assignment stays **open** (§9).
- **UBIMIA/Meritcoin hook [CONJECTURE].** Band-occupancy performance (COMFORT_LIVES at minimum G-expenditure) as a BERA-indexed merit signal — quarantined pending RHC/BERA linkage specification.

---

## 6. Predictions (falsifiable; reject criteria; instrumented in the validation suite)

**Prediction 1 (Gauge validity).** Across ≥ 30 metered properties, G from public climate normals predicts annual HVAC energy intensity (kWh·m⁻²·yr⁻¹) with Spearman ρ ≥ 0.7. **Reject if ρ < 0.5 or p > 0.05** (Mann-Kendall trend caveat: portfolio-composition drift must be controlled by evaluating within vintage strata).

**Prediction 2 (λ adds marginal value — null model test).** The rank correlation between G-decile and 5-year mean HVAC energy intensity is significant at p < 0.05 **against a latitude-only null model**. **Reject if the latitude-only model explains ≥ 90% of the G-explained variance** — i.e., if the C(φ, λ) correction field adds no marginal siting information. Matching protocol for any paired comparison: same climate zone, envelope vintage within ±10 years, floor area within ±25%.

**Prediction 3 (proactive yield).** For upper-decile-G properties, GERP-triggered proactive intervention (executed when Sentry's control limit — derived from the portfolio's own 10-year volatility — is crossed) reduces the coefficient of variation of annual operating cost versus matched-pair controls that defer to equipment failure. **Reject if the proactive group shows higher CoV or negative NPV over a 7-year horizon.**

All three are classical, data-available tests. None requires — or licenses — any quantum claim. The shipping suite instruments their statistical machinery on synthetic data with confirm/falsify separation; the real-data run is the v1.0 gate.

---

## 7. DVC Tag Summary

**DERIVED:** §2 entirely; the Pöschl–Teller spectrum (§3.3); §5.1 latitude–insolation physics; the weight-ratio condition w_C/w_H = c_C/c_H as a formula (§5.2.1); m\* = v·τ (inherited).
**CONSTRUCTED:** §3.1 Homotopy Reduction Lemma; Table 1; the Gauge definition, Separation Principle, and calibration protocol; §5.3 band parameterization and L(T); §5.4 integrations except as noted.
**CONJECTURE:** eigenstate↔Transmission reading (recalibrated out of Table 1); the BERA/Meritcoin hook; extension of the Gauge to non-thermal landscapes.

---

## 8. Ensemble Record (MIEVM pass on v0.1)

| Node | Score | Headline |
|---|---|---|
| Claude (drafting node — author-side) | 8.6 | HOLD for weight derivation + validation suite |
| DeepSeek | 6.5 | "Promising but problematic"; correspondence asserted; supplied then self-retracted metric-precision packages; remedy = architectural subtraction |
| ChatGPT | 9.4 | "Top three of recent series"; derive gauge from optimization; add numerical validation |
| Qwen | 9.0 | "Excellent draft"; defined the 10-10 DETAIL standard; leans TheWall-side |

Independent-node composite (DeepSeek, ChatGPT, Qwen): **8.3/10**. Provenance caveats: Claude is the drafting node (self-rating, discounted); score scales are not calibrated across nodes; the DeepSeek node's remedy sequence — proposing detail, catching its own category error, retracting to the topological reduction — is itself the strongest single review artifact of the pass and is adopted as §3.1.

---

## 9. The 10-10 DETAIL Standard and the v1.0 Gate

Adopted from the Qwen node as the exit condition for v1.0 (FINAL): **(1)** zero unresolved ontological discriminations — requires the TheWall/TheMall discrimination suite for G (open); **(2)** all policy parameters derived or strictly bounded — §5.2.1 closes the ratio, leaving (w_S, T_base, band endpoints) as bounded declarations; **(3)** fully instrumented, executable falsifiability — the shipping suite closes the synthetic layer; the **real-data run** (NOAA/NREL normals × benchmark energy data) remains open; **(4)** completed MIEVM re-pass on v0.2 with zero DVC tag violations and author-hardware reproduction reports (open).

---

## Appendix A — Minimal GAIA Lexicon (for self-containment)

- **TheWall:** the structural invariant — what must hold (here: the habitability band). GERP provisions into it; SECUIR realizes it.
- **TheMall:** the governed upward-ascent economy of holdings; its ungoverned limit is condensation; its protocol is EarnedPath.
- **TheALL:** the undifferentiated substrate below K_c; its unpriced potential is **infinance**; its protocol is the Context Field.
- **Avatar:** lower-wall keeper (K_c); PlayNAC is its coupling protocol.
- **Sentry:** upper-wall keeper and per-subsystem margin enforcer; alarms per m\* = v·τ (98/2 default policy).
- **GAIA:** the enclosing governor — damping across all regimes; shapes the well rather than pushing the oscillators.
- Semantics fixed by ERES-GAIA-GRID-2026-001 v0.4: **Role = invariant; Protocol = realization (many-to-one); Substrate = provisioning state.**

## Appendix B — Prohibited Inferences (Epistemological Floor)

1. No quantum-mechanical effects (tunneling, superposition, entanglement) are asserted in buildings, markets, or human comfort.
2. No equality is claimed between any potential-well spectrum and any property-market observable; after §3.1, internal spectra are decorative by construction.
3. Longitude does not drive climate; it indexes static, pre-averaged corrections. No ENSO/NAO/PDO content is embedded in the Gauge.
4. The Gauge does not predict individual building performance; it supplies the statistical prior for portfolio-level provisioning. Building physics lives in Sentry's δ(t).
5. "Potential" in this document means *landscape of required band-holding work*, not a thermodynamic potential.
6. Pellis Track-B contributions are technical review and domain-specific commentary within a collaborative research dialogue — **not peer review, and not independent institutional validation**.

## License

Creative Commons Attribution 4.0 International (CC-BY 4.0). Attribution: Joseph A. Sprute, ERES Institute for New Age Cybernetics.

## Credits

Author and director: Joseph A. Sprute (ERES Maestro). Drafting, mathematics, figure, and validation suite: Claude (Anthropic), H2C2H under author direction. MIEVM nodes: Claude, DeepSeek, ChatGPT, Qwen (returns of 11 July 2026; the DeepSeek node additionally contributed the reduction remedy). Track-B context: Dr. Stergios Pellis (designation per Appendix B.6).

## References

1. Sprute, J.A. (2026). *Sound Holds the Band* (ERES-PELLIS-SHB-001 v2.2). ERES Institute. CC-BY 4.0.
2. Sprute, J.A. (2026). *The GAIA Construct Grid: Role, Protocol, Substrate* (ERES-GAIA-GRID-2026-001 v0.4). ERES Institute. CC-BY 4.0.
3. Pellis, S. (2026). *Spectral Ricci Flow of Information Geometry in Multiscale Entropic Collapse*. **Unpublished manuscript**, 481 pp., dated 10 July 2026. Greece. ORCID 0000-0002-7363-8254. Cited per the manuscript's own title page; no institutional affiliation is claimed thereon; no public locator (DOI or repository) exists as of 11 July 2026. Contribution designation: technical review and domain-specific commentary; expert consultation within a collaborative research dialogue (not peer review).
4. Pöschl, G., & Teller, E. (1933). Bemerkungen zur Quantenmechanik des anharmonischen Oszillators. *Zeitschrift für Physik*, 83, 143–151.
5. Griffiths, D.J., & Schroeter, D.F. (2018). *Introduction to Quantum Mechanics* (3rd ed.). Cambridge University Press.
6. ANSI/ASHRAE Standard 55. *Thermal Environmental Conditions for Human Occupancy*. ASHRAE.
7. Kuramoto, Y. (1984). *Chemical Oscillations, Waves, and Turbulence*. Springer. (Analogy only, per SHB v2.0.)
