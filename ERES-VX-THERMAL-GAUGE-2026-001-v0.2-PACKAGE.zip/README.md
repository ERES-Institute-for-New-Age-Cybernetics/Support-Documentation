# ERES-VX-THERMAL-GAUGE-2026-001 v0.2 — "The Shape of the Well"
Post-MIEVM revision (N.EXT of v0.1). CC-BY 4.0 — Joseph A. Sprute, ERES Institute.

Contents:
- ERES-VX-THERMAL-GAUGE-2026-001-v0.2.md  — Markdown master (math in LaTeX)
- ERES-VX-THERMAL-GAUGE-2026-001-v0.2.pdf — PDF companion (10 pp., math in Unicode)
- eres_vx_thermal_gauge_validation.py     — validation suite (T1–T5, 16 checks,
  confirm/falsify separated; run: python3 eres_vx_thermal_gauge_validation.py;
  exit 0 = PASS). Requires numpy, scipy. Verified 16/16 PASS, seed 20260711.
- figure1.png                             — Figure 1 (well + Thermal Gauge band)

v1.0 gate (10-10 DETAIL, per §9): TheWall/TheMall discrimination suite for G;
real-data run (NOAA/NREL normals × benchmark energy); MIEVM re-pass on v0.2
with author-hardware reproduction reports.
