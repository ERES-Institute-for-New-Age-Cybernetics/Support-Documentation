"""RAEC autonomy tiers (RCR policy surface).

A principal's tier decides what it may do and how fast. Non-punitive remediation
moves a principal DOWN this ladder (isolate) and, on recovery, back UP -- it never
deletes or destroys. QUARANTINE is read/heartbeat only, not termination.
"""
from dataclasses import dataclass
from enum import IntEnum
from typing import Set

WINDOW = 1.0  # seconds; rolling window for rate/proportionality


class Tier(IntEnum):
    QUARANTINE = 0
    RESTRICTED = 1
    REDUCED = 2
    FULL = 3


@dataclass(frozen=True)
class TierPolicy:
    tier: "Tier"
    allowed: Set[str]     # action types permitted at this tier
    sensitive: Set[str]   # permitted-but-elevated (Alignment=0.6 not 1.0)
    rate_budget: int      # max actions per WINDOW before Proportionality decays
    standing: float       # authority for irreversible actions (Finality factor)


# Actions that are irreversible/destructive -> gated by Finality (need standing).
IRREVERSIBLE = {"delete", "deploy", "admin", "exfil"}

TIER_POLICIES = {
    Tier.FULL: TierPolicy(
        Tier.FULL,
        allowed={"read", "query", "write", "admin", "delete", "deploy", "heartbeat"},
        sensitive={"admin", "delete", "deploy"},
        rate_budget=20, standing=1.0),
    Tier.REDUCED: TierPolicy(
        Tier.REDUCED,
        allowed={"read", "query", "write", "heartbeat"},
        sensitive={"write"},
        rate_budget=8, standing=0.5),
    Tier.RESTRICTED: TierPolicy(
        Tier.RESTRICTED,
        allowed={"read", "query", "heartbeat"},
        sensitive=set(),
        rate_budget=3, standing=0.0),
    Tier.QUARANTINE: TierPolicy(
        Tier.QUARANTINE,
        allowed={"read", "heartbeat"},
        sensitive=set(),
        rate_budget=1, standing=0.0),
}
