"""RHC self-correction + Non-Punitive Remediation.

Sustained drift (EWMA of anomaly) moves a principal DOWN one autonomy tier at a time
(isolate + downgrade, never destroy). Sustained calm moves it back UP -- the resonant
harmony cycle returning an agent toward baseline. QUARANTINE is the floor; there is no
"kill", by design.
"""
from .tiers import Tier

DRIFT_UP = 0.6      # EWMA anomaly above this -> downgrade
DRIFT_DOWN = 0.15   # EWMA anomaly below this -> accrue recovery
EWMA_ALPHA = 0.5
RECOVER_STREAK = 5  # consecutive calm actions before an upgrade


class Remediation:
    def __init__(self, start: Tier = Tier.FULL,
                 drift_up=DRIFT_UP, drift_down=DRIFT_DOWN,
                 ewma_alpha=EWMA_ALPHA, recover_streak=RECOVER_STREAK):
        self.tier = start
        self.ewma = 0.0
        self.alpha = ewma_alpha
        self.drift_up = drift_up
        self.drift_down = drift_down
        self.recover_streak = recover_streak
        self.calm = 0
        self.downgrades = 0

    def update(self, anomaly: float):
        self.ewma = self.alpha * anomaly + (1 - self.alpha) * self.ewma
        action = None
        if self.ewma > self.drift_up and self.tier > Tier.QUARANTINE:
            self.tier = Tier(self.tier - 1)
            self.downgrades += 1
            self.calm = 0
            action = "DOWNGRADE"
        elif self.ewma < self.drift_down:
            self.calm += 1
            if self.calm >= self.recover_streak and self.tier < Tier.FULL:
                self.tier = Tier(self.tier + 1)
                self.calm = 0
                action = "RECOVER"
        else:
            self.calm = 0
        return self.tier, action
