"""PoR -- Proof-of-Resonance admissibility gate (A x R x P x F, conjunctive).

Admissibility before consistency: an action is admissible only if ALL four factors
are non-zero and their product clears the allow threshold. Any single zero blocks.

  A  Alignment       -- is this action type permitted for the principal's tier?
  R  Resonance       -- behavioral consistency with baseline (1 - anomaly)
  P  Proportionality -- blast radius vs the tier's rate budget
  F  Finality        -- authority to take irreversible actions (tier standing)
"""
from dataclasses import dataclass
from .tiers import TIER_POLICIES

THETA_ALLOW = 0.5
THETA_THROTTLE = 0.25


@dataclass
class PoRResult:
    A: float
    R: float
    P: float
    F: float
    adm: float
    verdict: str   # ALLOW / THROTTLE / BLOCK
    reason: str


def evaluate(action_type: str, tier, anomaly: float, recent_count: int,
             irreversible: bool) -> PoRResult:
    pol = TIER_POLICIES[tier]

    if action_type not in pol.allowed:
        A = 0.0
    elif action_type in pol.sensitive:
        A = 0.6
    else:
        A = 1.0

    R = max(0.0, 1.0 - anomaly)

    over = recent_count / max(1, pol.rate_budget)
    P = min(1.0, max(0.0, 1.0 - max(0.0, over - 1.0)))

    F = pol.standing if irreversible else 1.0

    adm = A * R * P * F
    zeros = [n for n, v in (("Alignment", A), ("Resonance", R),
                            ("Proportionality", P), ("Finality", F)) if v <= 0.0]
    if zeros:
        return PoRResult(A, R, P, F, adm, "BLOCK", "zero:" + ",".join(zeros))
    if adm >= THETA_ALLOW:
        return PoRResult(A, R, P, F, adm, "ALLOW", "admissible")
    if adm >= THETA_THROTTLE:
        return PoRResult(A, R, P, F, adm, "THROTTLE", "marginal")
    return PoRResult(A, R, P, F, adm, "BLOCK", "below_threshold=%.3f" % adm)
