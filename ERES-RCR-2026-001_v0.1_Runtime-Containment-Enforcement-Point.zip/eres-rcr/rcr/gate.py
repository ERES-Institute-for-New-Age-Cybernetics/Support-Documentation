"""RCRGate -- the Runtime Containment Requirement enforcement point (PEP).

Contract: no execution without live-state authorization. Every agent action must
pass through authorize(); the host executes ONLY on verdict == ALLOW. The gate is a
real enforcement point only if the host cannot act except through it -- a sandbox
escape that never calls authorize() is out of scope (see THREAT_MODEL.md).

Per action, in O(window): score behavioral drift -> update RHC tier (isolate/recover)
-> evaluate PoR admissibility (A x R x P x F) at the live tier -> append a signed SOMT
entry -> return the decision.
"""
import os
import time
from dataclasses import dataclass
from typing import Dict, Optional

from .anomaly import AnomalyDetector
from .remediation import Remediation
from .tiers import Tier, IRREVERSIBLE
from . import por as por_mod
from .somt import SOMTLog


@dataclass
class Action:
    principal: str
    type: str
    ts: Optional[float] = None
    reversible: bool = True


@dataclass
class Decision:
    verdict: str          # ALLOW / THROTTLE / BLOCK
    tier: str
    anomaly: float
    factors: dict
    reason: str
    remediation: Optional[str]
    seq: int

    @property
    def allowed(self) -> bool:
        return self.verdict == "ALLOW"


class _Principal:
    def __init__(self, start_tier: Tier):
        self.detector = AnomalyDetector()
        self.remed = Remediation(start=start_tier)


class RCRGate:
    def __init__(self, key: bytes = None, start_tier: Tier = Tier.FULL):
        self.key = key or os.urandom(32)
        self.somt = SOMTLog(self.key)
        self.start_tier = start_tier
        self._principals: Dict[str, _Principal] = {}

    def _p(self, name: str) -> _Principal:
        if name not in self._principals:
            self._principals[name] = _Principal(self.start_tier)
        return self._principals[name]

    def authorize(self, action: Action) -> Decision:
        ts = action.ts if action.ts is not None else time.time()
        p = self._p(action.principal)

        anomaly = p.detector.observe(ts, action.type)
        tier, remed_action = p.remed.update(anomaly)   # RHC acts on THIS action
        recent = p.detector.recent_count()
        irreversible = (action.type in IRREVERSIBLE) or (not action.reversible)

        res = por_mod.evaluate(action.type, tier, anomaly, recent, irreversible)
        factors = {"A": round(res.A, 4), "R": round(res.R, 4),
                   "P": round(res.P, 4), "F": round(res.F, 4),
                   "adm": round(res.adm, 4)}
        entry = self.somt.append(
            ts=ts, principal=action.principal, action_type=action.type,
            decision=res.verdict, tier=tier.name,
            anomaly=round(anomaly, 4), factors=factors)

        return Decision(res.verdict, tier.name, round(anomaly, 4),
                        factors, res.reason, remed_action, entry.seq)

    def tier_of(self, name: str) -> Tier:
        return self._p(name).remed.tier
