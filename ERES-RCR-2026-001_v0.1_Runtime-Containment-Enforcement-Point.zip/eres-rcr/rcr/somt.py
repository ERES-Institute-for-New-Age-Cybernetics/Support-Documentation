"""SOMT -- append-only, hash-chained, HMAC-signed decision ledger.

Every gate decision is appended as a tamper-evident entry linked to the previous
entry's hash (genesis = 64 zeros). verify() recomputes the chain and returns the
seq of the first broken/forged entry, giving the forensic reconstruction the
Hugging Face responders had to build by hand across ~17,600 actions.

Honest limit: HMAC integrity depends on key secrecy. An attacker who steals the
key can forge a consistent chain. Ship the key in an HSM/KMS, not in-process.
"""
import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import List, Optional, Tuple

GENESIS = "0" * 64


def _canon(d: dict) -> bytes:
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()


@dataclass
class SOMTEntry:
    seq: int
    ts: float
    principal: str
    action_type: str
    decision: str
    tier: str
    anomaly: float
    factors: dict
    prev_hash: str
    entry_hash: str


class SOMTLog:
    def __init__(self, key: bytes):
        self._key = key
        self._entries: List[SOMTEntry] = []

    def _hash(self, body: dict, prev_hash: str) -> str:
        return hmac.new(self._key, _canon(body) + prev_hash.encode(),
                        hashlib.sha256).hexdigest()

    def append(self, *, ts, principal, action_type, decision, tier,
               anomaly, factors) -> SOMTEntry:
        seq = len(self._entries)
        prev = self._entries[-1].entry_hash if self._entries else GENESIS
        body = {"seq": seq, "ts": ts, "principal": principal,
                "action_type": action_type, "decision": decision, "tier": tier,
                "anomaly": anomaly, "factors": factors, "prev_hash": prev}
        h = self._hash(body, prev)
        e = SOMTEntry(entry_hash=h, **body)
        self._entries.append(e)
        return e

    def verify(self) -> Tuple[bool, Optional[int]]:
        prev = GENESIS
        for e in self._entries:
            body = {"seq": e.seq, "ts": e.ts, "principal": e.principal,
                    "action_type": e.action_type, "decision": e.decision,
                    "tier": e.tier, "anomaly": e.anomaly, "factors": e.factors,
                    "prev_hash": e.prev_hash}
            if e.prev_hash != prev or self._hash(body, prev) != e.entry_hash:
                return False, e.seq
            prev = e.entry_hash
        return True, None

    def __len__(self):
        return len(self._entries)

    def entries(self) -> List[SOMTEntry]:
        return list(self._entries)

    def tail(self, n: int = 10) -> List[SOMTEntry]:
        return self._entries[-n:]
