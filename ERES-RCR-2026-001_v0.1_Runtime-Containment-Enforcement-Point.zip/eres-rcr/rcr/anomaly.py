"""Per-principal behavioral drift detector (the signal that feeds Resonance/RHC).

The Hugging Face-class attack was thousands of low-signal actions at machine speed
with no signature. This detector scores two behavioral deviations per action, in O(window):
  * rate deviation   -- action rate vs learned baseline (burst detection)
  * concentration    -- one action type dominating vs learned mix (bulk detection)
anomaly = max(rate_anomaly, concentration_anomaly), in [0, 1].

Honest limits: baseline is learned from early traffic (poisonable), and an attacker
who stays under baseline rate and type-mix is invisible to this signal by design.
"""
from collections import deque, Counter
from .tiers import WINDOW

RATE_SENS = 3.0        # multiples of baseline rate that saturate the rate signal
LEARN_ACTIONS = 20     # actions trusted while baseline is established


class AnomalyDetector:
    def __init__(self, learn_actions: int = LEARN_ACTIONS):
        self.events = deque()          # (ts, action_type)
        self.baseline_rate = None
        self.baseline_conc = None
        self.learn_actions = learn_actions
        self.n = 0

    def _trim(self, now: float):
        while self.events and now - self.events[0][0] > WINDOW:
            self.events.popleft()

    def observe(self, ts: float, atype: str) -> float:
        self.events.append((ts, atype))
        self._trim(ts)
        self.n += 1

        recent = self.events
        count = len(recent)
        rate = count / WINDOW
        types = Counter(t for _, t in recent)
        conc = (max(types.values()) / count) if count else 0.0

        if self.n <= self.learn_actions:
            # establish baseline as the calm-traffic envelope
            self.baseline_rate = rate if self.baseline_rate is None else max(self.baseline_rate, rate)
            self.baseline_conc = conc if self.baseline_conc is None else max(self.baseline_conc, conc)
            return 0.0

        br = max(self.baseline_rate or 0.0, 0.5)
        rate_anom = min(max((rate / br - 1.0) / RATE_SENS, 0.0), 1.0)

        bc = self.baseline_conc if self.baseline_conc is not None else 1.0
        conc_anom = 0.0 if bc >= 1.0 else min(max((conc - bc) / (1.0 - bc), 0.0), 1.0)

        return max(rate_anom, conc_anom)

    def recent_count(self) -> int:
        return len(self.events)
