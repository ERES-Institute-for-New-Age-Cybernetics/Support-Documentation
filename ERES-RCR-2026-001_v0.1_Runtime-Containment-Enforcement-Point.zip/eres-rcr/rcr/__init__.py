"""ERES-RCR -- Runtime Containment Requirement enforcement point.

A working, tested policy enforcement point for agentic actions: PoR admissibility,
behavioral drift detection, RHC non-punitive containment, and a signed SOMT ledger.
This is a mitigation control for machine-speed bulk-action abuse, not a guarantee.
"""
from .gate import RCRGate, Action, Decision
from .tiers import Tier

__all__ = ["RCRGate", "Action", "Decision", "Tier"]
__version__ = "0.1.0"
