# ERES-RCR — Threat model (v0.1)

The point of this file is that the control's limits are stated as plainly as its claims.
A gate whose blind spots are hidden is worse than no gate.

## In scope (mitigated)
- A compromised or misaligned agent **principal that routes its actions through the gate**
  and issues them at machine speed / in bulk. Drift detection + PoR + RHC throttle, block,
  downgrade, and finally quarantine it within ~10 actions, with a signed audit trail.
- Irreversible/destructive actions by a downgraded principal — blocked via the Finality
  factor (standing drops with tier).
- After-the-fact forensics — the SOMT ledger is an ordered, tamper-evident record.

## Out of scope (NOT mitigated) — by design in v0.1
1. **Gate bypass.** The PEP only governs actions that call `authorize()`. A sandbox escape
   or a direct resource path that never hits the gate is invisible to it. RCR reduces blast
   radius; it does not replace sandboxing, authn, or network egress control.
2. **Vulnerability exploitation itself.** RCR does not patch bugs or stop the initial
   exploit; it limits how much an attacker can do once acting through the gate.
3. **Low-and-slow attackers.** A principal staying under baseline rate and using permitted
   action types (e.g. bulk `read`) produces near-zero anomaly and is not contained. This is
   demonstrated in `demo_attack.py` step 5 and asserted in the test suite.
4. **Content-level abuse.** The gate reasons over action *type*, *rate*, and *reversibility* —
   not payload contents. Exfiltration via permitted reads of sensitive data is not detected.
5. **Baseline poisoning.** The baseline is learned from early traffic; an attacker who is
   noisy during the learning window can raise the "normal" envelope. Mitigation (not in v0.1):
   supply baselines out-of-band / freeze them / require attestation.
6. **Ledger key compromise.** SOMT integrity is HMAC-based; an attacker who steals the key
   can forge a self-consistent chain. Keep the key in an HSM/KMS; consider append-only
   external anchoring for high-assurance use.

## Assumptions
- Every governed action is mediated by `authorize()` and the host honors non-ALLOW verdicts.
- The gate process and its key are more trusted than the agent it governs.
- Per-principal identity is meaningful (a principal can't cheaply mint new identities to
  reset its baseline/tier — Sybil resistance is the caller's responsibility).

## Honest positioning
This is a v0.1 mitigation control, not a proof of safety. It converts one ERES governance
pattern into a running, testable enforcement point and states exactly where it stops.
