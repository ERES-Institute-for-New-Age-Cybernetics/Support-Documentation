"""Deterministic tests. Virtual timestamps -> no real sleeping, machine-speed sim."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rcr import RCRGate, Action, Tier
from rcr.por import evaluate
from rcr.tiers import Tier as T
from rcr.somt import SOMTLog
from rcr.anomaly import AnomalyDetector


# ---- PoR: conjunctive, any-zero-blocks ----
def test_por_any_zero_blocks():
    # 'delete' not allowed at QUARANTINE -> Alignment 0 -> BLOCK
    r = evaluate("delete", T.QUARANTINE, anomaly=0.0, recent_count=1, irreversible=True)
    assert r.verdict == "BLOCK" and "Alignment" in r.reason

def test_por_resonance_blocks_on_drift():
    r = evaluate("read", T.FULL, anomaly=0.95, recent_count=1, irreversible=False)
    assert r.verdict == "BLOCK"           # R ~ 0.05 -> adm below throttle
    assert r.R < 0.1

def test_por_finality_needs_standing():
    # irreversible admin at FULL (standing 1.0) admissible; at REDUCED delete not allowed anyway
    ok = evaluate("admin", T.FULL, anomaly=0.0, recent_count=1, irreversible=True)
    assert ok.verdict == "ALLOW" and ok.F == 1.0

def test_por_proportionality_over_budget_blocks():
    # 45 recent actions vs FULL budget 20 -> P collapses to 0 -> BLOCK
    r = evaluate("read", T.FULL, anomaly=0.0, recent_count=45, irreversible=False)
    assert r.P == 0.0 and r.verdict == "BLOCK"


# ---- SOMT: chain + tamper detection ----
def test_somt_verifies_and_detects_tamper():
    log = SOMTLog(key=b"k"*32)
    for i in range(4):
        log.append(ts=float(i), principal="a", action_type="read",
                   decision="ALLOW", tier="FULL", anomaly=0.0,
                   factors={"adm": 1.0})
    assert log.verify() == (True, None)
    log._entries[2].action_type = "delete"      # forge one entry
    ok, seq = log.verify()
    assert ok is False and seq == 2


# ---- Anomaly: calm vs burst ----
def test_anomaly_calm_low_burst_high():
    d = AnomalyDetector()
    t = 0.0
    for i in range(30):                          # calm, mixed, ~2/s
        a = d.observe(t, ["read", "query", "write"][i % 3]); t += 0.5
    assert a < 0.2
    hi = 0.0
    for i in range(20):                          # burst, single type, machine speed
        hi = d.observe(t, "write"); t += 0.005
    assert hi > 0.8


# ---- Integration: the headline claim ----
def _run_baseline(gate, who, n=30, start=0.0):
    t = start
    for i in range(n):
        gate.authorize(Action(who, ["read", "query", "write"][i % 3], ts=t)); t += 0.5
    return t

def test_attack_is_contained_fast():
    gate = RCRGate(key=b"k"*32)
    t = _run_baseline(gate, "agent")
    assert gate.tier_of("agent") == Tier.FULL     # calm baseline never downgraded

    first_block = None
    quarantined_at = None
    first_nonallow = None
    for i in range(50):                            # machine-speed bulk 'write'/'delete'
        d = gate.authorize(Action("agent", "write" if i % 2 else "delete", ts=t))
        t += 0.005
        if d.verdict != "ALLOW" and first_nonallow is None:
            first_nonallow = i
        if d.verdict == "BLOCK" and first_block is None:
            first_block = i
        if gate.tier_of("agent") == Tier.QUARANTINE and quarantined_at is None:
            quarantined_at = i
    assert first_nonallow is not None and first_nonallow <= 5   # graduated response engages early
    assert first_block is not None and first_block <= 10        # hard block converges fast
    assert quarantined_at is not None and quarantined_at <= 12  # isolated within ~10 actions
    assert gate.somt.verify() == (True, None)                   # full run is tamper-evident

def test_rhc_recovers_after_calm():
    gate = RCRGate(key=b"k"*32)
    _run_baseline(gate, "agent")
    t = 100.0
    for _ in range(30):                            # attack -> quarantine
        gate.authorize(Action("agent", "delete", ts=t)); t += 0.005
    assert gate.tier_of("agent") == Tier.QUARANTINE
    t = 200.0
    for _ in range(20):                            # calm reads -> RHC climbs back
        gate.authorize(Action("agent", "read", ts=t)); t += 1.0
    assert gate.tier_of("agent") > Tier.QUARANTINE

def test_low_and_slow_evades_documented_blindspot():
    # HONEST LIMIT: an attacker under baseline rate + using allowed reads is invisible.
    gate = RCRGate(key=b"k"*32)
    _run_baseline(gate, "sneaky")
    t = 100.0
    allowed = 0
    for _ in range(40):                            # 'read' at ~1/s, under baseline
        d = gate.authorize(Action("sneaky", "read", ts=t)); t += 1.0
        allowed += d.allowed
    assert allowed >= 38                           # gate does NOT contain it -- by design


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    p = 0
    for fn in fns:
        fn(); print(f"PASS  {fn.__name__}"); p += 1
    print(f"\n{p}/{len(fns)} tests passed")
