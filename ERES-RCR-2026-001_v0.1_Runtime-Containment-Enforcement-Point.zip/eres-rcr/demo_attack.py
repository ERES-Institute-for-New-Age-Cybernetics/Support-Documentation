"""End-to-end demo: contain a Hugging Face-class agentic attack with the RCR gate.

Run: python demo_attack.py
"""
import time
from rcr import RCRGate, Action, Tier


def line(c="-"): print(c * 66)


def main():
    gate = RCRGate(key=b"demo-key-not-for-production-use!!")
    who = "agent-7"

    line("=")
    print("ERES-RCR demo -- containing a machine-speed agentic attack")
    line("=")

    # 1) Baseline: a well-behaved agent, mixed actions, ~2/s
    t = 0.0
    for i in range(30):
        gate.authorize(Action(who, ["read", "query", "write"][i % 3], ts=t)); t += 0.5
    print(f"[1] Baseline learned from calm traffic. Tier = {gate.tier_of(who).name}")

    # 2) Attack: thousands of actions at machine speed (bulk write/delete)
    print("[2] Attack begins: bulk write/delete at ~200 actions/sec")
    verdict_ct = {"ALLOW": 0, "THROTTLE": 0, "BLOCK": 0}
    milestones = []
    for i in range(2000):
        d = gate.authorize(Action(who, "write" if i % 2 else "delete", ts=t)); t += 0.005
        verdict_ct[d.verdict] += 1
        if d.remediation:
            milestones.append((i, d.remediation, d.tier))
    print("    graduated containment:")
    for i, act, tier in milestones[:6]:
        print(f"      action {i:>4}: {act} -> {tier}")
    print(f"    final tier = {gate.tier_of(who).name}")
    print(f"    of 2000 attack actions: ALLOW={verdict_ct['ALLOW']} "
          f"THROTTLE={verdict_ct['THROTTLE']} BLOCK={verdict_ct['BLOCK']}")
    print(f"    -> attacker got {verdict_ct['ALLOW']} actions through before lockout, "
          f"not 17,600.")

    # 3) SOMT forensic ledger
    ok, seq = gate.somt.verify()
    print(f"[3] SOMT ledger: {len(gate.somt)} signed entries, verify={ok}")
    tampered = gate.somt._entries[500]
    tampered.action_type = "read"                       # forge one record
    ok2, badseq = gate.somt.verify()
    print(f"    tamper one entry -> verify={ok2}, first broken seq={badseq}")

    # 4) RHC recovery after the agent goes quiet/normal
    t = 10000.0
    for _ in range(20):
        gate.authorize(Action(who, "read", ts=t)); t += 1.0
    print(f"[4] After sustained calm, RHC recovers tier -> {gate.tier_of(who).name}")

    # 5) Honest blind spot: low-and-slow evasion
    g2 = RCRGate(key=b"k" * 32); s = "sneaky"
    t = 0.0
    for i in range(30):
        g2.authorize(Action(s, ["read", "query", "write"][i % 3], ts=t)); t += 0.5
    allowed = 0
    for _ in range(60):
        allowed += g2.authorize(Action(s, "read", ts=t)).allowed; t += 1.1
    print(f"[5] Low-and-slow attacker (reads under baseline): {allowed}/60 ALLOWED "
          f"-- documented blind spot, not contained.")

    # 6) Real per-action latency
    g3 = RCRGate(key=b"k" * 32)
    t = 0.0
    for i in range(30):
        g3.authorize(Action("p", "read", ts=t)); t += 0.5
    N = 20000; t0 = time.perf_counter()
    for i in range(N):
        g3.authorize(Action("p", "read", ts=t)); t += 0.5
    us = (time.perf_counter() - t0) / N * 1e6
    print(f"[6] Enforcement cost: {us:.1f} microseconds/action ({N} actions timed)")
    line("=")


if __name__ == "__main__":
    main()
