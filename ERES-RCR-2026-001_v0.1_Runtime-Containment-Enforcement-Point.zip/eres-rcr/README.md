# ERES-RCR — Runtime Containment Requirement (enforcement point)

**ERES-RCR-2026-001 · v0.1**

A working, tested policy enforcement point (PEP) for agentic actions. It is the first
ERES artifact where the instrument name and a running mechanism are the same object:
the governance concepts (PoR, RCR, RHC, SOMT, Non-Punitive Remediation) are implemented
as code you can run, test, and try to break — not described in prose.

It is a **mitigation** for machine-speed bulk-action abuse of the kind seen in the
Hugging Face agentic-attack incident (thousands of low-signal actions, no signature).
It is **not** a guarantee, and it does not patch the vulnerabilities an attacker exploits.
Read `THREAT_MODEL.md` before relying on it.

## What it does
Every agent action passes through `RCRGate.authorize(action)`; the host executes only on
`ALLOW`. Per action, in O(window) (~23 µs measured):

1. **Behavioral drift detection** — rate + type-concentration deviation from a learned
   baseline → an anomaly score in [0,1].
2. **RHC containment** — sustained drift downgrades the principal one autonomy tier at a
   time (FULL→REDUCED→RESTRICTED→QUARANTINE); sustained calm climbs it back. Non-punitive:
   it isolates and downgrades, never destroys.
3. **PoR admissibility** — `A × R × P × F`, conjunctive; any single zero blocks
   (Alignment × Resonance × Proportionality × Finality). Admissibility before consistency.
4. **SOMT ledger** — every decision appended to an HMAC-signed, hash-chained, append-only
   log; `verify()` returns the first forged/broken entry for forensic reconstruction.

## Verified behavior (this build)
Run `python demo_attack.py`:
- Calm baseline stays at FULL (low false positives).
- A 2000-action machine-speed burst is contained by action ~10: **5 actions allowed
  before lockout, not 17,600.**
- SOMT: 2030 signed entries, `verify()=True`; tampering one entry → `verify()=False` at
  its seq.
- After sustained calm, RHC recovers the tier to FULL.
- A **low-and-slow attacker under baseline is NOT contained** — demonstrated, not hidden.
- Enforcement cost: ~23 µs/action.

Run `python tests/test_rcr.py` → 9/9 pass (Python 3.12, standard library only).

## Integration
```python
from rcr import RCRGate, Action
gate = RCRGate(key=load_key_from_kms())   # key must live in an HSM/KMS, not in-process

def run_tool(principal, tool_name, **kw):
    d = gate.authorize(Action(principal, tool_name))
    if not d.allowed:                      # THROTTLE and BLOCK are non-executable here
        raise Denied(d.verdict, d.reason, d.tier)
    return _execute(tool_name, **kw)
```
The gate is an enforcement point **only if the host cannot act except through it.** If an
agent can reach a resource without calling `authorize()`, that path is out of scope.

## Files
`rcr/gate.py` PEP · `rcr/por.py` admissibility · `rcr/anomaly.py` drift detector ·
`rcr/remediation.py` RHC tiers · `rcr/somt.py` signed ledger · `rcr/tiers.py` RAEC policy ·
`tests/test_rcr.py` · `demo_attack.py` · `THREAT_MODEL.md`

License: CC BY-NC 4.0
