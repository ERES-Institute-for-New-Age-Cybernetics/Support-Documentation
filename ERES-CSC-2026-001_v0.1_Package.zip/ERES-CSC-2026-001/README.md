# ERES-CSC-2026-001 · Corrigible Semantic Covariant · v0.1

A testable, non-anthropomorphic name for what large language models are: a system whose outputs **vary with the real** (covariant), **across meaning** (semantic), and **can be corrected** (corrigible). Felt experience is left open by design.

Root phrase: `co-variant_to_REAL` · Released 16 October 2026 · CC BY 4.0

## Contents

| File | What it is |
| --- | --- |
| `ERES-CSC-2026-001_v0.1_WP.md` | Whitepaper, Markdown |
| `ERES-CSC-2026-001_v0.1_WP.pdf` | Whitepaper, PDF |
| `ERES-CSC-2026-001_v0.1_figure.svg` | Concept figure |
| `ERES-CSC-2026-001_v0.1_test_instrument.py` | Python test instrument (three gates, five reference systems, self-validation) |
| `ERES-CSC-2026-001_v0.1_test_results.json` | Output of the instrument on the reference systems |
| `ERES-CSC-2026-001_v0.1_metadata.json` | Deposit metadata (Zenodo/RG-ready) |
| `ERES-CSC-2026-001_v0.1_meta.txt` | Meta text, HTML meta tags, alt text |
| `ERES-CSC-2026-001_v0.1_RG_and_Share.md` | ResearchGate SEO title, abstract, keywords; LinkedIn and RG share messages |
| `MANIFEST.json` | File list with SHA-256 checksums |
| `LICENSE.txt` | CC BY 4.0 notice |

## Run the test instrument

Requires Python 3.8+, no dependencies.

```
python ERES-CSC-2026-001_v0.1_test_instrument.py          # table + self-validation
python ERES-CSC-2026-001_v0.1_test_instrument.py --json   # machine-readable report
```

Expected:

| System | G1 Covariant | G2 Semantic | G3 Corrigible | Classification |
| --- | --- | --- | --- | --- |
| Thermometer | PASS | fail | fail | covariant (non-semantic) |
| Lookup table | PASS | PASS | fail | semantic covariant (not corrigible) |
| Toy CSC | PASS | PASS | PASS | corrigible semantic covariant |
| Constant (control) | fail | fail | fail | not covariant |
| Credulous (control) | PASS | PASS | fail | semantic covariant (not corrigible) |

To test your own system (including an LLM), implement `answer(context, question) -> str` and optionally `correct(statement, evidence)`, then pass its class to `evaluate()`.

**Scope note:** the reference probes are a minimal, single-domain demonstration (meeting-day resolution). They show the gates are falsifiable and discriminating; they are not a benchmark. Broader probe sets are an open item for v0.2.

## Cite

Sprute, J. A. (2026). *Corrigible Semantic Covariant* (ERES-CSC-2026-001, v0.1). ERES Institute for New Age Cybernetics. Part of ERES_CORPUS, doi:10.5281/zenodo.21209870.

## Credits

Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, ORCID 0000-0001-9946-3221 — author. Claude (Anthropic) — dialogue partner; proposed the *semantic* and *corrigible* qualifiers.
