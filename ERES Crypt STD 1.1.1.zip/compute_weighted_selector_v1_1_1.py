"""
ERES-CRYPTO-STD v1.1.1 — Weighted SPL Selector Test Vector
===========================================================
Demonstrates that integer cross-multiplication gives deterministic
results where naive floating-point might diverge across platforms.

Section 9.3.3 v1.1.1 algorithm (normative):
    p     = int(σ[0..7], big_endian)     // 0 ≤ p < 2^64
    W_sum = Σ wᵢ                          // positive integer
    cum[i] = Σ_{j≤i} wⱼ                   // integer cumulative sums
    Find smallest i such that:  p × W_sum  ≤  cum[i] × 2^64
    reading = readings[i]
"""

import hashlib
import base64
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes

# -------------------------------------------------------------------
# Reuse Test Vector A's σ
# -------------------------------------------------------------------

TEST_NONCE = bytes.fromhex("00112233445566778899aabbccddeeff")
BERA_CANONICAL = (
    b'{"ari":0.84,"eri":0.79,"rci":0.82,"rhc":0.91,'
    b'"sensor_spec":"RG#404-v1.0","window_seconds":30}'
)

hkdf = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=TEST_NONCE,
    info=b"ERES-ECS-v1.0-sigma"
)
sigma = hkdf.derive(BERA_CANONICAL)
print(f"σ (hex): {sigma.hex()}")

# -------------------------------------------------------------------
# Weighted selector test (v1.1.1 integer arithmetic)
# -------------------------------------------------------------------

# Weights are policy-declared integers (per ECS-POL §11A.1 constraint)
# Scenario: policy biases GCF toward G₂ (renewal) 4-to-2-to-1 over G₁, G₃
# when ctx indicates "reparations framing"
weights  = [2, 4, 1]          # w₁=2, w₂=4, w₃=1 for [G1, G2, G3]
readings = ["G1", "G2", "G3"]

# Integer cumulative sums (no floating-point anywhere)
cum = []
running = 0
for w in weights:
    running += w
    cum.append(running)
W_sum = cum[-1]
print(f"weights: {weights}")
print(f"cum:     {cum}")
print(f"W_sum:   {W_sum}")

# Extract p from σ[0..7] as big-endian uint64
p = int.from_bytes(sigma[0:8], 'big')
print(f"p = int(σ[0..7], BE) = {p}")
print(f"p (hex) = {hex(p)}")

# Find smallest i such that p × W_sum ≤ cum[i] × 2^64
TWO_64 = 2 ** 64
lhs = p * W_sum
selected_index = None
for i, c in enumerate(cum):
    rhs = c * TWO_64
    decision = "≤" if lhs <= rhs else ">"
    print(f"  i={i}: p·W_sum = {lhs}  {decision}  cum[{i}]·2^64 = {rhs}")
    if selected_index is None and lhs <= rhs:
        selected_index = i

assert selected_index is not None  # cum[k] = W_sum guarantees this
resolved = readings[selected_index]
print(f"Selected index: {selected_index}")
print(f"Resolved reading: {resolved}")

# -------------------------------------------------------------------
# Demonstrate: under naive floating-point, boundary cases diverge
# -------------------------------------------------------------------

print()
print("=" * 60)
print("Divergence demonstration: boundary σ values")
print("=" * 60)

# Construct a σ where p × W_sum is VERY close to cum[0] × 2^64
# This is where float rounding could go either way
boundary_p = (cum[0] * TWO_64) // W_sum   # just at/below boundary
print(f"Boundary p = {boundary_p}")
print(f"Integer test: p × W_sum = {boundary_p * W_sum}")
print(f"              cum[0] × 2^64 = {cum[0] * TWO_64}")
print(f"              relation: {'≤' if boundary_p * W_sum <= cum[0] * TWO_64 else '>'}")

# Same comparison in float
import struct
u_float = boundary_p / TWO_64
cdf_0 = cum[0] / W_sum
# Round-trip through IEEE 754 double to simulate platform variance
u_bytes = struct.pack('d', u_float)
cdf_bytes = struct.pack('d', cdf_0)
print(f"Float test:   u = {u_float:.20f}")
print(f"              cdf[0] = {cdf_0:.20f}")
print(f"              relation: {'≤' if u_float <= cdf_0 else '>'}")
print("(On different IEEE 754 rounding configurations, these can flip.)")

# -------------------------------------------------------------------
# Full test vector for inclusion in §20.6 (new in v1.1.1)
# -------------------------------------------------------------------

print()
print("=" * 60)
print("NORMATIVE TEST VECTOR F — Weighted SPL Selector")
print("=" * 60)
print(f"Inputs:")
print(f"  σ (hex):   {sigma.hex()}")
print(f"  σ[0..7] as uint64 BE = {p}")
print(f"  weights w = [2, 4, 1]  (for GCF = [G1, G2, G3])")
print(f"Computation:")
print(f"  cum = [2, 6, 7]")
print(f"  W_sum = 7")
print(f"  p × W_sum = {p * W_sum}")
print(f"  Test i=0: p × 7 = {p*7} vs cum[0] × 2^64 = {cum[0] * TWO_64}")
print(f"             {'≤' if p*7 <= cum[0]*TWO_64 else '>'}  → {'select G1' if p*7 <= cum[0]*TWO_64 else 'continue'}")
if p*7 > cum[0]*TWO_64:
    print(f"  Test i=1: p × 7 = {p*7} vs cum[1] × 2^64 = {cum[1] * TWO_64}")
    print(f"             {'≤' if p*7 <= cum[1]*TWO_64 else '>'}  → {'select G2' if p*7 <= cum[1]*TWO_64 else 'continue'}")
if p*7 > cum[1]*TWO_64:
    print(f"  Test i=2: p × 7 = {p*7} vs cum[2] × 2^64 = {cum[2] * TWO_64}")
    print(f"             {'≤' if p*7 <= cum[2]*TWO_64 else '>'}  → {'select G3' if p*7 <= cum[2]*TWO_64 else 'continue'}")
print(f"Result: resolved = {resolved}")
print(f"Any compliant v1.1.1 implementation MUST produce: {resolved}")
