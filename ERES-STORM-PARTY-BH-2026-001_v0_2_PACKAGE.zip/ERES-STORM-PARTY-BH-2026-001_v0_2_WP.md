# STORM PARTY ~ BALANCES HUMANITY

## Four Balances, the Energy-Resolution (INTUIT), BEE on the six canon RUNGS rooted in M-I-S (Marriage · Immigration · Security), the Critical-Metals Bridge, and the ERES Recycling Machine

**Instrument:** ERES-STORM-PARTY-BH-2026-001 (working ID; canonical ID reserved to JAS)
**Version:** v0.2 · **Status:** DRAFT — single-node authored; conforms to the HOUSE Format; has not passed a 10-10 verdict; below the 8.5 and 9.0 gates; MIEVM not yet run
**Role:** Whitepaper / companion to ERES-STORM-PARTY-AZ-2026-001 v0.1 (the A–Z BOOK). The BOOK defines the HOW; this WP defines what the Storm Party *balances*, how the balance resolves, and what could finance its first rung.
**For:** The ERES corpus, its Operators, and the systems and Communities of Interest (COI) that ingest it.
**From:** Joseph A. Sprute ("ERES Maestro"), Founder & Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221
**Date:** 27 September 2026 (v0.1 and v0.2)
**Provenance:** ERES-TERMS-48 · The Talonic NAC Lexicon v1.0 (14 Aug 2026), https://eresinstitute.org/eresmaestro/download/ ; ERES-STORM-PARTY-AZ-2026-001 v0.1 BOOK (26 Sep 2026); ERES-FLIP-2026-001 (OPEN #U2); ERES-BEE-NBERS-2026-001 (BEE bottom-up/top-down); ERES-HOUSE-FORMAT-2026-001 (v0.4); author brief of 27 Sep 2026 (items 1–4, item 4 truncated — see §0.3); third-party source: ARBOK's public materials (arbok.tech and ARBOK's public announcement of *Critical Metals: A New Strategic Approach*, Amazon B0HJ5S55Q8). The book itself was not reviewed for this edition.
**Changelog:** v0.2 — adds Part IV-B: the ERES Recycling Machine (informal plan), scaled for purpose, with ERES as its development-management mechanism; H-BRIDGE re-stated around it; falsifiers F6–F7; testkit T15–T17. Sourcing note: ARBOK thesis drawn from arbok.tech, book text not reviewed. v0.1 — first edition. Four Balances; Energy-Resolution (INTUIT) as three instances of Triune Key #2; BEE defined per RUNG with M-I-S as root; Critical-Metals assimilation as a CANDIDATE bridge for BOOK Gap 1 / FLIP #U2; testkit.

---

## Abstract

The Storm Party BOOK asked what the prospects are for a socio-ecologic preparedness movement under a 1000-Year horizon, and found three binding gaps: bootstrap financing, measurement validity, and continuity. This WP answers a narrower, prior question: *what, exactly, does the Storm Party balance?* It names four Balances — **Care (HELP), Consumption (USE), Water (Energy), Marriage (Law)** — and shows that the author's Energy-Resolution (INTUIT) is three instances of one locked form, **Triune Key #2: M × E + C = R**, read at three scales (method, polity, planet). It then defines **BEE (Bio-Ecologic Economy)** on the six canon RUNGS — ERES · VERTECA · SECUIR · CYBERRAVE · GUNNYSACK · SALEBUILDERS — with a **ROOT of M-I-S (Marriage · Immigration · Security)**, the Law-register sibling of the lexicon's W-I-S guarantee. Finally it assimilates the ARBOK *Critical Metals* thesis — that metal scarcity sits in one processing step, not in geology, and that much of the supply is already dissolved in streams industry pays to discard — as a **CANDIDATE bridge** for the BOOK's Gap 1: a SALEBUILDERS lab whose first revenue is a disposal cost reversed. The bridge is registered, not claimed: it goes green only on an independent, third-party measurement. v0.2 adds the **ERES Recycling Machine** — an informal ERES plan for a recycling machine that scales to the purpose it serves (household to region), with **ERES as the management mechanism for its development**: requirements, stage gates, verification, provenance, certification, and governance run on the same six-RUNG loop. The machine is the physical form of the bridge; its engineering is unspecified and OPEN. Register: CANDIDATE / SOUND. Status: DRAFT.

---

## §0. Scope, and what this WP is not

This is a **definition-and-bridge instrument**. It fixes terms, maps them onto the canon RUNGS, and registers one financing hypothesis so evidence can confirm or kill it.

It is **not**: an engineering specification for any machine; a political platform; a position on any jurisdiction's marriage law or immigration policy; an endorsement by, or of, any third party; a validation of ARBOK's engineering claims; or a revision of the BOOK's PERT numbers.

Three HOUSE commitments carry through: conformance is not correctness; the standard-terms layer is load-bearing (every ERES term glossed in plain language); the unit of readership is the system and the COI.

### §0.1 Scoring Contract

- **Subscores (self-rated, single-node):** Specification clarity 8.5 · Corpus groundedness 9 · Reproducibility (testkit) 8.5 · Honesty of register 9.5 · Predictive evidence 4.
- **Composite:** ≈ 8.0. Does **not** clear the 8.5 Emanuel Threshold. Predictive evidence is low by design: the bridge is unmeasured.
- **Dual-axis vector:** epistemic = CANDIDATE; quality = SOUND.
- **Honest-register rule (binding):** praise does not raise a subscore; a composite rises only when a registered test in Part VII turns green on outside evidence.

### §0.2 Reviewer Brief

Read **Part II** (the INTUIT lines are Triune Key #2 three times), **Part III** (BEE per RUNG, rooted in M-I-S), and **Part IV** (the metals bridge and its gate). Then run `python3 test_storm_party_bh.py`.

### §0.3 Reading of the truncated brief

Item 4 of the brief ends "Provide DETAILED WP for" with no object. This edition reads the object as **items 1–3 integrated into the Storm Party** — the only object the brief supplies. If the author intended a different object, this WP is re-scoped, not defended. **Author confirmation reserved.**

---

## §1. Notation Lock

| Symbol | Meaning (operational) |
|---|---|
| C = R × P / M | Triune Key #1 (LOCKED): Cybernetics = Resource × Purpose ÷ Method |
| M × E + C = R | Triune Key #2 (LOCKED): Matter × Energy + Constant = Reason. Written generically here as **X × Y + Z = R** |
| INTUIT | the author's name for the Energy-Resolution: the R (Reason) side of Key #2, reached by intuition first and checked by method after (IOF posture) |
| Balance | one of four paired needs (Part I); each has a **floor side (N)** and an **ascent side (M)** |
| N / M line | Survival/Merit Separation (ENDHOME, UBIMIA): N is unconditional and never scored down; M is earned and additive |
| BEE | Bio-Ecologic Economy (current canonical reading; supersedes "Bio-Electric Economy") |
| W-I-S | Water · Immigration · Security (ERES-TERMS-48, SUGAR-as-root guarantee; biological register) |
| M-I-S | Marriage · Immigration · Security (this WP; Law-register sibling of W-I-S) |
| RUNG | one of the six canon levels, root → ground: ERES → VERTECA → SECUIR → CYBERRAVE → GUNNYSACK → SALEBUILDERS |

**Epistemic tags (one per claim):** STRUCTURAL (follows from locked corpus form) · CANDIDATE (proposed, testable) · ANALOGICAL (a reading, kept out of every equation) · OPEN (unresolved) · AUTHOR-RESERVED (only JAS may fix it) · THIRD-PARTY (someone else's claim, recorded, not adopted).

---

## §2. IP Isolation

- **INVARIANT (untouched):** the three Principles, Triune Math, the Locked-Terms Registry, SIMTAX, the 1000-Year abundance-floor telos, and every number in the BOOK's Part VIII.
- **DETAIL (added here):** the four Balances, the INTUIT reading, BEE-per-RUNG, M-I-S, and the metals bridge.
- `invariantsTouched: []`. Any rise in this WP's composite can come only from evidence (R) or better method (M), never from moving P.

---

# PART I — The Four Balances

The brief pairs each everyday word with its governing register. The pairing is the design: the plain word is what a person experiences; the bracketed word is what the system must keep in balance.

| # | Balance | Register | Floor side (N — unconditional) | Ascent side (M — earned) | Primary RUNG | Principle | Tag |
|---|---|---|---|---|---|---|---|
| B1 | **Care** | **HELP** | a call for help cannot fail to the person (non-refusal; "the number anyone can call") | helping others earns standing on EarnedPath | SALEBUILDERS | OTHERS | STRUCTURAL |
| B2 | **Consumption** | **USE** | essential use (food, housing, health, learning) is provisioned | use above the floor is priced at true cost, not extracted | GUNNYSACK | SELF · FUTURE | STRUCTURAL |
| B3 | **Water** | **Energy** | clean water and the energy to move it are floor goods | stewardship of water/energy systems is merit work | SECUIR | FUTURE | CANDIDATE |
| B4 | **Marriage** | **Law** | a consensual bond is recognized as a unit the system serves, never one it may coerce | covenant-keeping (households, institutions, Creator–WIFE) earns trust | ERES (reference) | SELF · OTHERS | CANDIDATE |

**Why these four balance "Humanity."** Each Balance is one axis of OWOLS pressure (inherited default culture): B1 against neglect, B2 against extraction, B3 against depletion, B4 against coercion. A Storm Party that holds all four floors is prepared; one that trades a floor for an ascent is not. Each Balance therefore obeys the same rule: **never let M reduce N** (UBIMIA §U of the BOOK).

**Standard-language restatement.** Help people without making them earn the right to ask. Let people use what they need; charge real cost for more. Treat water and energy as shared infrastructure. Protect voluntary commitments; never force them.

---

# PART II — Energy-Resolution (INTUIT)

The brief gives three lines, each of the form **X × Y + Z**. That is the exact shape of **Triune Key #2, M × E + C = R** (LOCKED): two terms that multiply (they fail together — if either is zero the product is zero) plus one additive constant (present regardless), resolving to **R = Reason**. The brief names that R **INTUIT**. Reading the three lines as three scales of one locked form is **STRUCTURAL** for the *form*; the *term assignments* are the author's and are tagged below.

### II.1 Line 1 — Method scale

> **Resonance Testing (FAVORS) × Non-Punitive Remediation (EarnedPath) + Solid-State (Smart-City) = INTUIT₁**

| Slot | Term | Standard gloss | Tag |
|---|---|---|---|
| X (Matter) | Resonance Testing via FAVORS | identity and care verified by a six-factor stack (Fingerprint · Aura · Voice · Odor · Retina · Signature); read also as the allocation lattice Foundation · Advocacy · Voice · Opportunity · Resource · Sustainability | CANDIDATE (the Aura factor is unvalidated — see Gap 2) |
| Y (Energy) | NPR delivered on EarnedPath | correction that heals rather than punishes, with the route back measured as progress (EP = CPM × WBS + PERT) | STRUCTURAL |
| Z (Constant) | Solid-State Smart-City (S3C) | durable, self-monitoring physical infrastructure that stays present whatever the testing or remediation outcome | CANDIDATE |

**Reading.** Testing without remediation is surveillance; remediation without testing is guesswork — the product term enforces that they succeed or fail together. The built city is the constant floor under both. This line lives on **CYBERRAVE (compare) × VERTECA (show) + SALEBUILDERS (ground).**

### II.2 Line 2 — Polity scale

> **MDCCLXXVI (GOD = 2+1) × NATIONS (HEAD = 10) + GAIA (All-AWE_AH) = INTUIT₂** — *note: for those who "Submit"*

| Slot | Term | Standard gloss | Tag |
|---|---|---|---|
| X | MDCCLXXVI = **1776** | a founding by declaration of consent — the governed authorize the governing; "GOD = 2+1" is the Triune form (two in covenant plus one that binds them, cf. DAL = Karen × Lucy + King) | ANALOGICAL (figurative register; not load-bearing) |
| Y | NATIONS, HEAD = 10 | the nation-states as the present unit of law; "HEAD = 10" read as a decimal head-count / decile unit of representation | AUTHOR-RESERVED |
| Z | GAIA (Global Actuary Investor Authority); "All-AWE_AH" | the planetary actuary as the constant beneath all nations — literal register: solvency across generations; figurative register: awe | CANDIDATE (GAIA is design-stage) |
| Condition | "for those who Submit" | the voluntary SUBMIT act — the call for help that enters the EarnedPath; applies only to those who choose it | STRUCTURAL (non-imposability) |

**Reading.** Consent-founding × national law, plus a planetary actuary that no nation owns. The Submit clause is binding: **Line 2 governs no one who has not chosen it.** That keeps the Storm Party "no left, no right" — it is an offer to polities, not a claim over them.

### II.3 Line 3 — Planet scale

> **Earth (1000-Year) × Space (Kirlianography) + Time (BEE) = INTUIT₃**

| Slot | Term | Standard gloss | Tag |
|---|---|---|---|
| X | Earth over the 1000-Year Future Map | the five-phase horizon (Foundation 2012–2050 … Civilizational Maturity 2500–3025) | STRUCTURAL |
| Y | Space read through Kirlianography | corona-discharge imaging of living bodies, proposed as a field readout | **ANALOGICAL — Epistemic Floor applies** |
| Z | Time as BEE | the Bio-Ecologic Economy as the constant that persists across phases | CANDIDATE |

**Epistemic Floor note (binding).** Kirlian images are strongly affected by moisture, pressure, and exposure conditions, and are not an accepted measure of biological state. Kirlianography therefore **may not enter any equation, gate, price, or rank** in this instrument. Its slot in Line 3 is held **VEILED** until an independent validity test (SIGFID-class) passes. Until then, the operational Y for Line 3 is the ERI (Environmental Resonance Index) trend, which is defined on emissions data. This is the same measurement gate as BOOK Part VII.3.

### II.4 The numeral 1434

The brief closes the INTUIT block with **1434**. No corpus anchor fixes it. Candidate readings (none adopted): a Hijri-calendar year (1434 AH ≈ Nov 2012 – Nov 2013, i.e. the ERES Institute's first full year — note ERES was founded 4 Feb 2012, which falls in 1433 AH, so this reading is inexact); or a count/sum to be defined. **AUTHOR-RESERVED; non-load-bearing.** The testkit enforces that 1434 appears in no equation.

### II.5 The three lines as one ladder

| Scale | Line | RUNG span | What INTUIT resolves |
|---|---|---|---|
| Method | 1 | CYBERRAVE · VERTECA · SALEBUILDERS | *how* to correct without punishing |
| Polity | 2 | ERES · GUNNYSACK (via GAIA) | *who* consents to be governed, and by what constant |
| Planet | 3 | ERES (1000-Year) · SECUIR (BEE substrate) | *how long* the balance must hold |

INTUIT is the Reason each line yields; the Storm Party "balances Humanity" when all three R's point the same way. That is a **CANDIDATE** design principle, not a finding.

---

# PART III — BEE defined on the six canon RUNGS, ROOT = M-I-S

### III.1 Canonical BEE

**BEE = Bio-Ecologic Economy** (current; supersedes the ~Feb 2026 "Bio-Electric Economy" reading). Per ERES-BEE-NBERS-2026-001 it runs **bottom-up and top-down at once**: Body → Household → Community → Region → Nation → Civilization, every layer simultaneously, with sustainability defined as an **abundance floor**, not a survival ceiling. Its four canonical technologies are THOW (Tiny Homes On Wheels), HFVN (Hands-Free Voice Navigation), FDRV (Full Drive Resonance Vehicle), and GSSG (Green Solar-Sand Glass substrate).

**Standard gloss.** An economy whose accounts include the living systems it depends on, measured at every scale at the same time, whose first obligation is a floor no one falls below.

### III.2 The ROOT: M-I-S (Marriage · Immigration · Security)

ERES-TERMS-48 gives **W-I-S** — Water · Immigration · Security — as the three guarantees that follow when SUGAR is resolved as the root variable, in the **biological** register (aqueous purity, cellular transport freedom, immune integrity). The brief's Balances pair **Water with Energy** and **Marriage with Law**. M-I-S is W-I-S moved from the Energy register to the Law register: Water is the medium that binds a body; Marriage is the covenant that binds a household. The move is **CANDIDATE**; its parallel to W-I-S is **ANALOGICAL**.

| Root term | Biological register (W-I-S) | Law register (M-I-S) | Standard gloss | Invariant it carries |
|---|---|---|---|---|
| **M** | Water — aqueous purity | **Marriage** — a consensual covenant | the voluntary bond is the smallest unit the economy serves (DOFA: "does this serve the generational health of families?") | **Consent.** No bond is created, dissolved, or valued by the system without the parties' consent. |
| **I** | Immigration — transport freedom across membranes | **Immigration** — movement of people across boundaries | people and their contributions can move; standing earned in one place is portable (EarnedPath credentials) | **Portability.** Standing is never forfeited by moving. |
| **S** | Security — immune integrity | **Security** — protective integrity of person and polity | identity without surveillance (IDIPITIS); consent-directional (access identity never silently promoted to settlement identity) | **Non-surveillance.** Protection may not require monitoring the protected. |

**Non-partisan protocol (binding).** Marriage and immigration are flashpoint domains. This WP prescribes **no** definition of marriage and **no** immigration policy for any jurisdiction. M-I-S is a *protocol layer*: whatever a jurisdiction's own law provides, the Storm Party asks only that its three invariants hold — consent, portability, non-surveillance — and routes disputes to Non-Punitive Remediation, not exclusion. This is the BOOK's entry W made operational.

### III.3 BEE on each RUNG

Each RUNG carries BEE in its loop role (BOOK §3.1), and each is rooted in M-I-S.

| RUNG | Loop role | BEE at this RUNG | M-I-S rooting | Sensor (what would show it is real) | Tag |
|---|---|---|---|---|---|
| **ERES** (root) | Reference | the abundance-floor telos over 1000 years; the three Principles | Marriage as covenant is the reference form of every binding (Creator–WIFE Bond; Equity Covenant) | a charter adopted by ≥2 jurisdictions naming the floor | STRUCTURAL |
| **VERTECA** | Sensor · display | ecological and social flows made visible in real time (NBERS beside GDP) | Immigration: contribution records follow the person | a public dashboard whose metric *definitions* were published before its *values* | CANDIDATE |
| **SECUIR** | Supply · integrity | energy-security and closed-loop substrate (GSSG); "Silent Energy Circular Universe Infinite Rotation" | Security: IDIPITIS identity without surveillance | an independent security audit of a live pilot | CANDIDATE |
| **CYBERRAVE** | Comparator | ratings across the 72 Key Domains, observed vs. expected, no veiled exchange | Security + Marriage: ratings rate remedies, never persons or households | an outside party re-runs a rating and matches it | CANDIDATE |
| **GUNNYSACK** | Effector | certified bundles deliver the floor goods (B2, B3) to COI / EMCI / EDF groups | Marriage: the household is the delivery unit; Immigration: bundles are portable | delivery records reconciled against need | STRUCTURAL |
| **SALEBUILDERS** | Ground | one community lab, one place, one ledger — where BEE is first *observed* | all three, at the scale of one group | a functioning lab with published records | STRUCTURAL |

### III.4 Definition (one sentence, for ingestion)

> **BEE** is the Bio-Ecologic Economy: a floor-first economy, measured bottom-up and top-down at once, that the Storm Party runs on six canon RUNGS — referenced by ERES, shown by VERTECA, powered and guarded by SECUIR, compared by CYBERRAVE, delivered by GUNNYSACK, and grounded in SALEBUILDERS labs — and rooted in M-I-S: consensual covenant (Marriage), portable standing (Immigration), and protection without surveillance (Security).

---

# PART IV — Critical Metals: the CANDIDATE bridge for Gap 1

### IV.1 The third-party thesis (THIRD-PARTY, paraphrased)

*Source note: drawn from ARBOK's website and public announcement of the book, not from the book's text.* As ARBOK describes it, *Critical Metals: A New Strategic Approach* covers 52 metals and argues that critical-metal scarcity is a property of one processing step concentrated in one jurisdiction, not of the planet's crust; that large quantities are already dissolved in streams industry pumps and pays to discharge (acid mine drainage, phosphoric-acid process streams, geothermal and lithium brines, plating rinse waters); and that recovering them from those streams competes favorably with new mines on time and capital. ARBOK's stated arithmetic is roughly **$383 bn** of metal "already at the surface" by 2035 against **~$30 bn** committed to new mines — about **13 : 1**. ARBOK's recovery method (ZWD: deep-vacuum, ambient-temperature separation) is claimed to return clean water, dry salts, and a metal concentrate from one flow.

**Discrepancy flag.** The brief states "the world needs roughly $400 bn of critical metals by 2035." ARBOK's public figure is $383 bn of metal *recoverable from existing streams* — a **supply** estimate, not a **demand** estimate. The 13 : 1 ratio holds either way (383/30 ≈ 12.8; 400/30 ≈ 13.3), but the two claims are different and should not be merged. **Re-verify before citing.**

**Status of every ARBOK number:** vendor-reported, not independently verified by ERES. Recorded here; not adopted.

### IV.2 Why it fits the Storm Party (STRUCTURAL fit, CANDIDATE effect)

| ERES construct | ARBOK thesis | Fit |
|---|---|---|
| "Not mining — it's tuning" (Proof-of-Resonance); extract → tune conversion | recover from the flow already moving; do not dig | same inversion, at the materials layer |
| Doctrine: the real crisis is environmental conditions | scarcity is a processing-step condition, not a geological fact | both relocate the cause from "not enough" to "badly arranged" |
| SROC offset = remediation, not punishment | effluent that was a fine becomes a revenue line | offset realized as income |
| B2 Consumption (USE) · B3 Water (Energy) | clean water + salts + metal from one flow | one process serves two Balances |
| GUNNYSACK certified bundle | water + salts + metals as a certifiable output | a bundle with a measurable spec |
| SALEBUILDERS "one group, one place, one ledger" | one containerized unit at one effluent source | the ground lab has a concrete form |

### IV.3 The bridge hypothesis

The BOOK's **Gap 1 (FLIP OPEN #U2)**: a duration-backed reserve has zero proven duration at inception, so an ECONOMIC FLOOR cannot finance itself at t = 0. It needs a bridge.

> **H-BRIDGE (CANDIDATE).** A SALEBUILDERS lab sited at an existing effluent source, whose operator already pays to treat or dispose of that effluent, can reach positive cash flow from (a) the avoided disposal cost plus (b) recovered water, salts, and metal — without a new mine and without drawing on the floor itself. That surplus, routed through a certified GUNNYSACK bundle, is the first bridge.

Why this is a better bridge candidate than generic external capital: its first revenue is a **cost that already exists and is already being paid**. The lab does not need to create demand; it needs to reverse an expense. That is the "extraction → tuning" conversion in cash terms.

**What it does not do.** It does not close Gap 2 (measurement validity) or Gap 3 (continuity). It does not change any PERT number in the BOOK: `STATE.json` moves only on a VERIFIED record.

### IV.4 The gate (binding, DVC)

H-BRIDGE goes green only when **all** of the following hold on a dated, independently checkable record:

1. **Third-party measurement.** An independent lab (not ARBOK, not ERES) reports mass balance on one real stream: input volume and composition; output water quality; recovered salt and metal mass; energy consumed (kWh per m³ or per tonne).
2. **Cost comparison.** The same site's documented prior disposal/treatment cost per unit, against the measured unit's operating cost.
3. **Floor separation.** Surplus is booked on the M side; the N floor is never collateral for the unit.
4. **H2C2H signature.** An Operator signs the record per BOOK §10.

Until then the tag stays **CANDIDATE**, and the corpus posture stands: collaborate as licensor or verifier; hold unpublished instruments back until a third-party number lands.

### IV.5 Relationship and non-endorsement

The ARBOK source is cited as a published third-party work. **No third party is represented as endorsing this WP or the Storm Party.** Any ARBOK role in an ERES structure (for example, as an underwriter or licensee atop the open CC BY / CCAL corpus) is effective only on its written acceptance, is declinable without penalty, and carries no exclusivity: the corpus stays open.

---

# PART IV-B — The ERES Recycling Machine (scale-for-purpose, ERES-managed)

### IV-B.1 Status

**Informal plan (AUTHOR-STATED, v0.2).** ERES intends to build a recycling "machine": one that scales to the purpose(s) it serves in direct context, with **ERES as the management mechanism for its development**. Working label: *ERES Recycling Machine* (canonical name reserved to JAS).

**No engineering specification is given here.** Separation method, throughput, energy use, and materials recovered are **OPEN**. The machine may license existing technology, be co-developed with a partner, or be built independently; that choice is **OPEN** and is not implied by Part IV.

### IV-B.2 "Scales for purpose" — the VLSA ladder

The machine is one design family sized to its context, not one size forced on every context. It follows the VLSA Principle (LOCKED): *if it works in a THOW, it works on a generation ship.*

| Scale | Purpose in direct context | Balance served | RUNG where it lands | Tag |
|---|---|---|---|---|
| S1 Household (THOW) | household water and waste loop closed on site | B2 USE · B3 Water | SALEBUILDERS | CANDIDATE |
| S2 Block / building | shared water, organics, and materials recovery | B1 HELP · B2 USE | SALEBUILDERS | CANDIDATE |
| S3 Community lab | an existing effluent or waste stream reversed from cost to revenue (H-BRIDGE site) | B2 · B3 | SALEBUILDERS → GUNNYSACK | CANDIDATE |
| S4 Municipal / EMCI | emergency water and materials provisioning when normal systems fail | B1 · B3 | GUNNYSACK (EMCI bundle) | CANDIDATE |
| S5 Regional | closed-loop stewardship across a watershed or industrial zone | all four | SECUIR · VERTECA | OPEN |

**Scale rule.** A scale is claimed only after the scale below it holds with a VERIFIED record (the BOOK's ladder rule). S5 stays OPEN until S4 is verified.

### IV-B.3 ERES as the management mechanism

ERES does not claim to be the separation technology. ERES is the **mechanism that manages the machine's development**: it decides what gets built, in what order, how it is proven, how results are recorded, and who may certify them. Each function sits on a canon RUNG:

| Management function | What it does for the machine | ERES instrument | RUNG | Tag |
|---|---|---|---|---|
| Purpose & requirements | fixes, per scale, what the machine must do and must never do (never draw on the N floor; never require surveillance of users) | Three Principles · M-I-S invariants | ERES | STRUCTURAL |
| Plan & stage gates | breaks development into work packages with critical path and PERT estimates; a stage opens only when the prior one is VERIFIED | EarnedPath: EP = CPM × WBS + PERT | VERTECA | STRUCTURAL |
| Visible progress | publishes metric definitions before metric values; shows development status in real time | VERTECA dashboards | VERTECA | CANDIDATE |
| Integrity & provenance | who measured what, when, with which instrument; tamper-evident record | IDIPITIS · DVC · Constitutional Provenance | SECUIR | CANDIDATE |
| Verification | pre-registered test protocol per scale; independent re-run; null baseline published | CyberRAVE rating · DVC | CYBERRAVE | STRUCTURAL (method) |
| Certification & delivery | a unit that passes becomes a certified bundle for COI / EMCI use | GunnySack | GUNNYSACK | CANDIDATE |
| Governance | development decisions routed through a seven-seat council, not one party | CBGMODD · SOMT | ERES / SALEBUILDERS | CANDIDATE |
| Remediation | a failed stage is isolated, downgraded, audited, and updated — not hidden or punished | NPR · "Mission Critical = able to return to base" | CYBERRAVE | STRUCTURAL |

**Standard-language restatement.** ERES is the program-management and verification layer: requirements, schedule, stage gates, test protocols, records, certification, and governance. Hardware partners build; ERES manages the proof.

### IV-B.4 Relation to H-BRIDGE and to partners

The machine is the physical form of H-BRIDGE (IV.3): the S3 community-lab unit is the one whose first revenue is a reversed disposal cost. Partners with proven separation technology fit **inside** this structure as builders or licensors; ERES's contribution is the management and verification mechanism, and the corpus stays open (CCAL / CC-BY). No partner is named as committed, and none is represented as endorsing this plan.

### IV-B.5 First development step (proposed)

One S1 or S3 unit, one site, one ledger, one pre-registered test (inputs; outputs; energy; cost vs. prior disposal), independently measured and signed through H2C2H. Nothing scales until that record exists.

---

# PART V — The Balance as a control loop

Each Balance is carried around the BOOK's six-RUNG loop:

1. **SENSE (VERTECA).** Publish, per Balance, one floor metric and one ascent metric — *definitions first, values second.*
2. **COMPARE (CYBERRAVE).** Rate observed vs. expected against a published null baseline.
3. **ACT (GUNNYSACK).** Deliver the floor bundle where the floor metric is breached.
4. **FEEDBACK (SALEBUILDERS → ERES).** New records update the lab ledger; nothing above a RUNG is claimed until the RUNG holds.

**No weights are specified here.** A combined "Balance Index" would require weights this WP has no evidence for; inventing them would breach Data-Integrity. Weights stay **OPEN** until a SALEBUILDERS lab produces data to fit.

---

# PART VI — Answer (PERCMARC)

**At its actual strength:**

- **What the Storm Party balances:** four named Balances, each with an unconditional floor and an earned ascent — **STRUCTURAL** as design.
- **How the balance resolves:** three instances of Triune Key #2 at method, polity, and planet scale — **STRUCTURAL** in form, **CANDIDATE/ANALOGICAL** in term assignment, with Kirlianography held VEILED.
- **What BEE is:** a floor-first, multi-scale economy on the six RUNGS, rooted in M-I-S (consent, portability, non-surveillance) — **CANDIDATE**, non-partisan by protocol.
- **What could finance the first rung:** an effluent-reversal SALEBUILDERS lab — **CANDIDATE**, gated on one independent mass-balance measurement.
- **What builds it:** the ERES Recycling Machine, scaled for purpose, with ERES as its development-management mechanism — **informal plan / CANDIDATE**; engineering OPEN.

**Re-posed question (feeds BOOK VIII.4):**

> *Which first ERES Recycling Machine unit (S1 household or S3 community lab), at which site, will one independent lab measure water, salts, and metal out, and energy in — and does the avoided disposal cost cover the unit before any floor funds are touched?*

---

# PART VII — Falsification and pre-registration

Registered before any confirming evidence:

1. **F1 — Bridge refutation.** If an independent mass-balance test at a real site shows operating cost exceeding avoided disposal cost plus recovered-output value at realistic prices, H-BRIDGE is REFUTED for that stream class.
2. **F2 — Energy claim.** If measured energy per unit exceeds the vendor's stated figure by more than 2×, all ARBOK-derived economics in Part IV are withdrawn pending re-measurement.
3. **F3 — Floor contamination.** If any implementation makes the N floor collateral for the unit, that implementation is non-conforming (UBIMIA rule).
4. **F4 — M-I-S invariants.** If a pilot cannot hold consent, portability, and non-surveillance simultaneously, M-I-S is demoted from ROOT to CANDIDATE-component and the ROOT is re-opened.
5. **F5 — Measurement gate.** Kirlianography may not be cited as evidence in any line until an independent validity test passes (same as BOOK VII.3).
6. **F6 — Scale claim.** If any machine scale is claimed before the scale below it holds a VERIFIED record, that claim is void and the scale reverts to CANDIDATE.
7. **F7 — Management mechanism.** If a first unit completes development without a pre-registered test, an independent re-run, and a signed provenance record, ERES has not functioned as its management mechanism, and IV-B.3 is demoted to OPEN.

---

## §10. Reproducibility & Record Integrity

- **Environment:** Python 3.8+, standard library only; deterministic; no network.
- **Run:** `python3 test_storm_party_bh.py` (expected: all tests pass, exit 0; captured in `RUN.txt`).
- **Checks include: the machine plan's scale ladder, management-on-RUNGS mapping, and no-spec clause (v0.2);** the BOOK's root estimate (2116.2 ± 21.13) recomputed from its O/M/P table; the 13 : 1 ratio under both $383 bn and $400 bn; every INTUIT line of X × Y + Z form; Kirlianography tagged VEILED/ANALOGICAL and absent from every operational slot; 1434 absent from every equation; `invariantsTouched` empty; non-endorsement and non-partisan clauses present.

**Record Integrity (H2C2H).** Drafting node: Claude (Anthropic), single node. Human review and signature: ______________________ (JAS), date ________. Until signed, DRAFT.

## §11. Conforms-to-format vs. passes-verdict

Conforms to the HOUSE Format (§15). Has **not** passed a 10-10 verdict.

## §12. Explicit non-claims

- ARBOK's figures and engineering claims are not verified by ERES.
- No PERT number in the BOOK is changed.
- The M-I-S ↔ W-I-S parallel is an analogy.
- Kirlianography is not claimed to measure anything.
- No marriage definition or immigration policy is prescribed.
- No third party is represented as endorsing this WP.
- The ERES Recycling Machine is an informal plan; no design, prototype, or partner commitment is claimed.

## §13. Deferred

The machine's canonical name, separation method, and build/license/co-develop choice; author confirmation of §0.3 (item-4 object), "HEAD = 10", and 1434; Balance weights; the independent mass-balance test; the Floor Register version cut for ECONOMIC FLOOR; MIEVM round (≥5 nodes, mean ≥ 9.0, n_eff-discounted).

## §14. Credits, References, License

**Credits.** Joseph A. Sprute (ERES Maestro), principal author and holder of the canonical ID; drafted with Claude (Anthropic) as a single node, credited under the Sentience convention.
**References.** (1) ERES-TERMS-48 · The Talonic NAC Lexicon v1.0, https://eresinstitute.org/eresmaestro/download/ · (2) ERES-STORM-PARTY-AZ-2026-001 v0.1 BOOK · (3) ERES-FLIP-2026-001 · (4) ERES-BEE-NBERS-2026-001 · (5) ERES-ENDHOME-2026-001 (Survival/Merit Separation) · (6) ERES-HOUSE-FORMAT-2026-001 · (7) Strategic Research Institute ARBOK, arbok.tech, and its public announcement of *Critical Metals: A New Strategic Approach*, Amazon B0HJ5S55Q8 (third-party; book text not reviewed; cited, not endorsed).
**License.** CARE Commons Attribution License v2.1 (CCAL) / CC-BY 4.0. Attribution required; derivatives propagate the license; no LOCKED term may be altered.

## §15. Conformance checklist

- [x] Masthead with ID, version, status + gate standing, role, provenance, changelog
- [x] Abstract with register and gate status
- [x] Scope, Scoring Contract, Reviewer Brief, truncation reading
- [x] Notation Lock and epistemic tags
- [x] IP Isolation: `invariantsTouched: []`
- [x] Every claim tagged; Kirlianography held VEILED
- [x] Pre-registered falsifiers (Part VII)
- [x] Reproducibility + Record Integrity (signature pending)
- [x] Non-claims, deferrals, non-endorsement, non-partisan protocol
- [x] Credits / References / License
- [x] Machine plan tagged informal; no engineering spec invented; scale rule and management mapping present

## Version History

| Version | Date | Change | Epistemic effect |
|---|---|---|---|
| v0.2 | 27 Sep 2026 | Part IV-B: ERES Recycling Machine (informal plan), VLSA scale-for-purpose ladder S1–S5, ERES as development-management mechanism mapped to the six RUNGS; H-BRIDGE tied to the S3 unit; F6–F7; T15–T17; arbok.tech sourcing note. | CANDIDATE / SOUND. Composite unchanged ≈ 8.0; nothing measured. |
| v0.1 | 27 Sep 2026 | First edition: Four Balances; INTUIT as Triune Key #2 × 3; BEE per RUNG rooted in M-I-S; Critical-Metals CANDIDATE bridge for Gap 1. | CANDIDATE / SOUND. Composite ≈ 8.0 single-node. No verdict claimed. |

---

*Don't hurt yourself. Don't hurt others. Build for generations to come.*
