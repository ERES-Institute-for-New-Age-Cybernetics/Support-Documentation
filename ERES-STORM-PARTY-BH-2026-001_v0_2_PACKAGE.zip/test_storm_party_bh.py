#!/usr/bin/env python3
"""Testkit for ERES-STORM-PARTY-BH-2026-001 v0.2 (stdlib only, deterministic)."""
import math, re, sys, glob

WP = glob.glob("ERES-STORM-PARTY-BH-2026-001_v0_2_WP.md")[0]
T = open(WP, encoding="utf-8").read()
results = []
def test(name, cond):
    results.append((name, bool(cond)))

# T1 BOOK root estimate recomputed from its own O/M/P table
book = [(1,4,15),(1,4,12),(2,6,25),(3,10,40),(3,12,45),(10,30,120)]
te = sum((o+4*m+p)/6 for o,m,p in book)
sig = math.sqrt(sum(((p-o)/6)**2 for o,m,p in book))
test("T1 BOOK root 2116.2 +/- 21.13", round(2026+te,1)==2116.2 and round(sig,2)==21.13)
# T2 13:1 ratio holds under both supply ($383bn) and brief ($400bn) figures
test("T2 13:1 ratio both readings", round(383/30)==13 and round(400/30)==13)
# T3 supply-vs-demand discrepancy is flagged
test("T3 discrepancy flag present", "Discrepancy flag" in T and "supply" in T and "demand" in T)
# T4 three INTUIT lines, each X x Y + Z form
lines = re.findall(r"^> \*\*(.+?) = INTUIT([₁₂₃])", T, re.M)
test("T4 three INTUIT lines of X x Y + Z form",
     len(lines)==3 and all((lambda x: x.count("×")==1 and x.count("+")==1)(re.sub(r"\([^)]*\)","",l[0])) for l in lines))
# T5 Kirlianography held VEILED, never an operational slot
test("T5 Kirlianography VEILED/ANALOGICAL", "held **VEILED**" in T and "ANALOGICAL — Epistemic Floor applies" in T)
# T6 1434 absent from every equation line
eq = [l for l in T.splitlines() if l.startswith("> **") or (l.startswith("| ") and "=" in l and "×" in l)]
test("T6 1434 in no equation", not any("1434" in l for l in eq) and "AUTHOR-RESERVED; non-load-bearing" in T)
# T7 IP isolation
test("T7 invariantsTouched empty", "`invariantsTouched: []`" in T)
# T8 four Balances present
test("T8 four Balances", all(b in T for b in ["**Care**","**Consumption**","**Water**","**Marriage**"]))
# T9 M-I-S root with three invariants
test("T9 M-I-S invariants", all(k in T for k in ["**Consent.**","**Portability.**","**Non-surveillance.**"]))
# T10 BEE on all six RUNGS
rungs = ["**ERES** (root)","**VERTECA**","**SECUIR**","**CYBERRAVE**","**GUNNYSACK**","**SALEBUILDERS**"]
test("T10 BEE on six RUNGS", all(r in T for r in rungs))
# T11 non-partisan + non-endorsement clauses
test("T11 non-partisan & non-endorsement",
     "prescribes **no** definition of marriage" in T and "No third party is represented as endorsing" in T)
# T12 bridge gated on third-party measurement; floor never collateral
test("T12 bridge gate", "Third-party measurement" in T and "never collateral" in T)
# T13 required HOUSE sections
test("T13 Credits/References/License", all(s in T for s in ["**Credits.**","**References.**","**License.**"]))
# T14 no numeric Balance weights invented
test("T14 weights OPEN", "No weights are specified here" in T)

# T15 machine scale ladder S1..S5 with scale rule
test("T15 machine scale ladder", all(f"S{i} " in T for i in range(1,6)) and "**Scale rule.**" in T)
# T16 ERES management functions mapped onto all six RUNGS
sec = T.split("### IV-B.3")[1].split("### IV-B.4")[0]
test("T16 management on six RUNGS", all(r in sec for r in ["ERES","VERTECA","SECUIR","CYBERRAVE","GUNNYSACK","SALEBUILDERS"]))
# T17 no invented engineering spec; version 0.2
test("T17 no-spec clause & v0.2", "No engineering specification is given here." in T and "**Version:** v0.2" in T)

fails = 0
for n, ok in results:
    print(("PASS " if ok else "FAIL ") + n); fails += (not ok)
print(f"{len(results)-fails} PASS / {fails} FAIL")
sys.exit(1 if fails else 0)
