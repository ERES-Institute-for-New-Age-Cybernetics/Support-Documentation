#!/usr/bin/env python3
"""ERES-HINGE-9505-WP-2026-001 v2 structural testkit (stdlib only).

Tests arithmetic, register discipline and document hygiene; nothing empirical.
Load-bearing empirical items are SKIPPED until demonstrated.
"""
import math, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
MD = os.path.join(HERE, "ERES-HINGE-9505-WP-2026-001.md")
G, C, P = 0.97, 0.01, 0.02
TARGET, STRETCH, ASPIRATION = 0.95, 0.97, 0.98
results = []

def rg(yg, yp, yc=0.0):
    return G * yg + C * yc + P * yp

def check(name, cond):
    results.append(("PASS" if cond else "FAIL", name))

def skip(name, why):
    results.append(("SKIP", f"{name} -- {why}"))

check("T1 mass split sums to 1", abs(G + C + P - 1) < 1e-12)
check("T2 table: low/mid/high = 92.8/94.5/96.3",
      [round(100 * rg(*a), 1) for a in [(.95, .30), (.965, .45), (.98, .60)]] == [92.8, 94.5, 96.3])
check("T3 confirm: high case meets 95/5", rg(.98, .60) >= TARGET)
check("T4 refuse: mid case misses 95/5", rg(.965, .45) < TARGET)
check("T5 stretch needs ~99% glass: 99% passes, 98% fails",
      rg(.99, .60) >= STRETCH and rg(.98, .60) < STRETCH)
check("T6 carbon ceiling: perfect glass+payload capped at 99%", abs(rg(1.0, 1.0) - (1 - C)) < 1e-12)
check("T7 carbon counted as Make-up (y_c = 0) in the model", rg(.98, .6) == rg(.98, .6, 0.0))
check("T8 system figure = process x take-back",
      round(100 * rg(.98, .60) * 0.95, 1) == 91.4)
check("T9 decay half-life at 95% ~ 13.5 cycles", round(math.log(.5) / math.log(TARGET), 1) == 13.5)

REG = {"Literal": True, "Figurative": False, "Subjective": False}
check("T10 register-lock: only Literal is evidence",
      REG["Literal"] and not REG["Figurative"] and not REG["Subjective"])

with open(MD, encoding="utf-8") as f:
    low = f.read().lower()
check("T11 Regenerable defined with same-strength test",
      "recoverable after breakdown at the same strength" in low)
check("T12 three tiers declared",
      "95/5 regenerable is the empirical target" in low and "97/3 is the stretch target" in low
      and "98/2 is aspirational" in low)
check("T13 no Rg/Mk collision label '95r/5m'", "95r/5m" not in low.replace(" ", ""))
check("T14 payload removable module specified", "removable module" in low)
check("T15 canonical GSSG expansion present", "green solar-sand glass with infused graphene" in low)
check("T16 zero 'foundation' strings", "foundation" not in low)

skip("S1 remelted GSSG glass regenerates at strength (>=97%)", "awaits Phase-0 coupon remelt")
skip("S2 graphene weight fraction <= 1%", "awaits Phase-0 measurement")
skip("S3 payload removable without compromising seam", "awaits design and Phase-1")
skip("S4 take-back rate achieved in practice", "awaits Phase-1 cycle")

for s, n in results:
    print(f"[{s}] {n}")
k = {s: sum(r[0] == s for r in results) for s in ("PASS", "FAIL", "SKIP")}
print(f"\n{k['PASS']} PASS / {k['FAIL']} FAIL / {k['SKIP']} SKIP")
sys.exit(1 if k["FAIL"] else 0)
