# ERES-WP-005-2026 v0.1 — Deposit Package (DRAFT)

**The Spectral Operator as Derived Decomposition Layer** — casting Dr. Stergios
Pellis's Quantum Error Operator into the SCALULAR diagnostic stack, and what a
second independent physical domain does to primitive P3.

## Contents
- `ERES-WP-005-2026_Pellis-SpectralOperator-QEC-SCALULAR-Transmission_v0.1-DRAFT.md`
  — the transmission (assimilates the WP-003 Bentley method; primitive test;
  SCALULAR casting; P3 cross-domain finding; rating; conditions).
- `eres_wp005_testkit.py` — pre-registered falsifiable test kit, **zero
  dependencies** (internal shifted-QR complex eigenvalue solver; stdlib only).
- `RUN.txt` — captured output of a fresh test run.
- `MANIFEST.json` — SHA-256 of every file above.

## Verify
```
python3 eres_wp005_testkit.py          # expect 8/8 PASS, exit 0
```
Recompute checksums and compare to MANIFEST.json.

## Epistemic status (binding)
- Foundational spectral-operator mathematics are Dr. Pellis's (*Pellis Spectral
  Operator Theory*); ERES supplies only the diagnostic-architecture casting
  (Layer Doctrine; Credit Protocol). Cited as unpublished manuscript, locator
  "Greece".
- Self-rated **8.7/10 single-node** — clears the 8.5 (Emanuel) gate, sits
  **below the 9.0 (Stergios) gate**. DRAFT; not for external citation as
  endorsement.
- The kit certifies **structure only**. Everything in it is synthetic; per
  standing ERES rule, synthetic results cannot confirm or refute the physical
  claim, and the kit does **not** move the 9.0 gate. The physical test is
  `rho_S = Corr(S_phi, P_logical)` on real hardware (Pellis paper §15/§17).
