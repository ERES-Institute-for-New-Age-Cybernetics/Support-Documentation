# ResearchGate submission — ERES-RRH-2026-001 v0.1

**Title:** Regulatory Root Hardening: Stress-Testing a Human-Terminated Governance Stack Against the EU AI Act, GDPR, and eIDAS 2.0

**Type:** Preprint / working paper, with code

**Author:** Joseph A. Sprute (ORCID 0000-0001-9946-3221), ERES Institute for New Age Cybernetics

**Abstract:** Use Section "Abstract" of the whitepaper verbatim.

**Keywords:** AI governance; EU AI Act Article 5; social scoring; GDPR Article 22; biometric data; blockchain and right to erasure; emotion recognition; eIDAS 2.0; threat modeling; compliance by design

**Disclosed review status:** Not peer reviewed. Not MIEVM-rated. AI-assisted drafting (Claude). Not legal advice. External EU counsel review (O5) not yet performed.

**Acknowledgement:** Threat model adapted from a public critique by Christopher Neitzert (LinkedIn, Sep 2026). No endorsement implied.

**Suggested citation:** Sprute, J. A. (2026). *Regulatory Root Hardening: Stress-Testing a Human-Terminated Governance Stack Against the EU AI Act, GDPR, and eIDAS 2.0* (ERES-RRH-2026-001, v0.1). ERES Institute for New Age Cybernetics.

**License:** CC BY 4.0 / CCAL v2.1
