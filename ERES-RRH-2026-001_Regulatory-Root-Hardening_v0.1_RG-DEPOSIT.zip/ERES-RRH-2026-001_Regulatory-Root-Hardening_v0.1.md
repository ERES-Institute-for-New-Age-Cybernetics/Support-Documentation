# ERES-RRH-2026-001 — Regulatory Root Hardening

**Stress-Testing a Human-Terminated Governance Stack Against the EU AI Act, GDPR, and eIDAS 2.0**

Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221
Version 0.1 PROPOSED · pre-canonical · NOT MIEVM-rated · ID pending author confirmation · 24 September 2026
Companion to ERES-ARH-2026-001 (Adversarial Root Hardening)

## Abstract

ERES-ARH-2026-001 hardened the ERES root against a modeled attacker. This instrument hardens it against a different adversary: law already in force. The threat model is taken, with credit, from a public critique arguing that ERES, if deployed in the European Union, would collide with the AI Act, the GDPR, and the design principles of eIDAS 2.0. We restate that critique at its asserted strength, which is a conditional, structural claim about deployment in the EU, not a claim that ERES is unlawful everywhere or unlawful as written. We then split it into five declared collisions (R1–R5) plus one alignment test (R6). Each collision is mapped to the ERES component it strikes, to any mitigation the corpus already holds, and to a required hardening (H1–H6). The key existing mitigation is the Humane Invariant: the UBIMIA floor (N) is never decremented, so only the Meritcoin reserve (M) is exposed to scoring. That narrows, but does not close, the social-scoring and automated-decision fronts. The instrument is framed by ERES's own GERP identity C = R·P/M: once law is in force (C), its rules (R) fix the perimeter (P), and ERES is scored against that perimeter by BEST/SOUND/GOOD metrics (M). A stdlib-only harness encodes each collision as a falsifiable rule. The harness confirms that the as-critiqued configuration trips all five collisions and that the hardened v0.1 specification clears them at the specification level. Five items remain OPEN, including whether cross-context merit aggregation is compatible with ERES's unified-ledger design at all, and external legal review. That last item cannot be discharged by any model and is the empirical gate. Nothing here is legal advice or a compliance verdict.

## 0. Status and boundary

- Green in the harness means the SPECIFICATION clears a MODELED reading of the cited provisions. It is not legal compliance, not a conformity assessment, and not a regulator's or court's view.
- The harness exposes no `is_compliant`, `is_lawful`, or `is_safe` verdict, by design (same discipline as ARH).
- The legal citations are to primary instruments and published guidance as of September 2026. Interpretation of prohibited practices remains contested and will develop through case law.

## 1. Provenance of the threat model

The threat model originates in a public LinkedIn comment by Christopher Neitzert (September 2026), in a thread on AI regulation. It is paraphrased here and credited as the source of fronts R1–R5. The claim's asserted strength is **conditional and structural**: *if deployed in the EU*, specific ERES components *would collide* with named provisions. He did not assert that ERES is unlawful as a text, nor unlawful outside the EU. This instrument engages that claim at that strength and no stronger.

Neitzert named four fronts. This instrument separates the automated-decision front (GDPR Art. 22) from social scoring (AI Act Art. 5(1)(c)), because they have different tests and different fixes. That gives five collisions. His eIDAS 2.0 point is treated as R6, an alignment test rather than a prohibition.

## 2. Frame: external law as the perimeter

In GERP form, C = R·P/M. Read at this instrument's layer:

- **C**: a law in force (Regulation (EU) 2024/1689, the AI Act, as amended by Regulation (EU) 2026/1744; Regulation (EU) 2016/679, the GDPR; Regulation (EU) 2024/1183, eIDAS 2.0).
- **R**: the specific rules (the articles cited below).
- **P**: the perimeter those rules draw around admissible designs.
- **M**: BEST/SOUND/GOOD scoring of ERES against P.

The perimeter is set externally. ERES does not negotiate P. It either fits inside it, redesigns to fit, or declares the gap OPEN.

## 3. Threat model: declared collisions

| ID | Collision | Instrument | ERES component struck |
|---|---|---|---|
| R1 | Social scoring with cross-context or disproportionate detriment | AI Act Art. 5(1)(c), applicable since 2 Feb 2025 | Meritcoin (M) reserve, CBGMODD, EarnedPath, FAVORS × 72-industry aggregation |
| R2 | Solely automated decision with legal or similarly significant effect | GDPR Art. 22; CJEU C-634/21 (SCHUFA, 2023) | M-decrement under Proof-of-Resonance; GAIA Benchmark standing |
| R3 | Biometric data for unique identification; consent not freely given if refusal costs livelihood | GDPR Arts. 9, 7(4), Recital 43; AI Act Annex III(1), Art. 5(1)(g) | FAVORS six-modal vector (Floor Register Row 1 Biometric Floor) |
| R4 | Immutable ledger vs rectification, erasure, storage limitation, data protection by design | GDPR Arts. 16, 17, 5(1)(e), 25; EDPB Guidelines 02/2025 v2.0 (7 Jul 2026) | GraceChain / PoR posterity ledger |
| R5 | Emotion recognition in workplace or education; health-data inference | AI Act Art. 5(1)(f); GDPR Art. 9 | HPE stress = color real-time readout; Paineology |
| R6 | Alignment with EUDI Wallet principles: user control, selective disclosure, no cross-use profiling | eIDAS 2.0 (Reg. 2024/1183) | Identity layer (FAVORS, IDIPITIS) |

Where the use falls outside Art. 5 but touches employment (Annex III(4)) or eligibility for public assistance (Annex III(5)(a)), it is high-risk. Under Regulation (EU) 2026/1744, stand-alone Annex III obligations apply from 2 December 2027. The Art. 5 prohibitions were not deferred.

## 4. Per-front analysis

### R1 — Social scoring

**Collision.** Art. 5(1)(c) prohibits evaluating or classifying people over time by social behaviour or personal characteristics where the resulting score leads to detrimental treatment in contexts unrelated to where the data were generated, or treatment that is unjustified or disproportionate. It applies to public and private actors.

**Existing mitigation.** The Humane Invariant (GAIA Benchmarks v0.3; UBIMIA/ENDHOME Survival–Merit Separation) holds that N, the UBIMIA floor, is never decremented. Survival income is therefore not gated by merit. This defeats the strongest reading of "merit scoring that gates income."

**Residual.** M is still a scored economic standing. If behaviour recorded in one domain (for example, one of the 72 industries or a FAVORS signal) moves M, and M then affects treatment in another domain, that is the cross-context pattern the article targets.

**Hardening H1.** Merit is context-bound. A score generated in domain d may only affect treatment in domain d. There is no unified cross-domain score with downstream effect. Any M effect must be proportionate to the recorded conduct and explainable in those terms.

**Design tension.** H1 may conflict with ERES's single-ledger, planetary-scale reserve design. Whether a unified M can exist lawfully in the EU is OPEN (O1). This is a real design decision, not a drafting fix.

### R2 — Solely automated decisions

**Collision.** Art. 22 gives a right not to be subject to a decision based solely on automated processing that produces legal or similarly significant effects. In SCHUFA, the CJEU held that a score can itself be such a decision where a third party draws strongly on it.

**Existing mitigation.** ERES is specified as human-terminated (ARH T3; PlayNAC). That is the right shape.

**Hardening H2.** Every M-affecting decision requires meaningful human review, meaning a reviewer with authority and competence to change the outcome, not a rubber stamp. It also requires a stated explanation and a contest channel. ARH O4 (human liveness modeled, not realized) carries over.

### R3 — Biometric identity layer

**Collision.** Biometric data processed to uniquely identify a person is special-category data (Art. 9). Explicit consent is the likely basis, but consent is not freely given where refusal carries detriment (Art. 7(4), Recital 43). If FAVORS enrolment is a condition of participation or earning, consent fails. Remote 1:N identification is high-risk under the AI Act. Categorisation that infers protected traits is prohibited under Art. 5(1)(g).

**Hardening H3.**
- Provide a non-biometric path with no detriment: equal access to N and M without FAVORS.
- Use 1:1 verification only (confirming a claimed identity), which is excluded from the Annex III(1) high-risk category. No 1:N search.
- Store templates on-device or in the user's wallet, never on the ledger.
- No inference of protected characteristics from any FAVORS modality.

### R4 — Posterity ledger

**Collision.** An append-only ledger cannot natively honour rectification or erasure. EDPB Guidelines 02/2025 (v2.0, adopted 7 July 2026) advise against storing personal data on-chain. They also treat public keys and hashes linked to persons as potentially personal data, and recommend a DPIA and a preference for permissioned designs.

**Hardening H4.**
- Keep personal data off-chain in an erasable store.
- Put on-chain only non-linkable commitments, or commitments whose linking key is destroyed on erasure (crypto-shredding).
- Use a permissioned chain with defined controller roles.
- Attach retention limits to every record class.

**Residual.** Whether commitment-plus-shredding satisfies Art. 17 in practice is OPEN (O2). The EDPB's position leaves this uncertain.

### R5 — Physiological-state readout

**Collision.** Art. 5(1)(f) prohibits AI systems that infer emotions of people in the workplace or in education, except for medical or safety reasons. A stress readout computed from biometric signals, used by an employer or educator, is squarely in scope. Independently, physiological-state data is likely health data under GDPR Art. 9.

**Hardening H5.**
- The HPE readout is self-held by the person.
- It is never available to an employer or educational institution, and never feeds M.
- It is used only under a medical or safety basis where it is used institutionally at all.

**Residual.** Whether the stress = color readout counts as "emotion" within the AI Act definition is OPEN (O3). The hardening assumes it does.

### R6 — eIDAS 2.0 alignment

**Test.** The European Digital Identity Wallet is built on user control, selective disclosure, and no tracking or profiling across uses.

**Hardening H6.** The ERES identity layer issues attestations into a wallet the user controls, discloses only the attribute needed per transaction, and keeps no cross-use linkage. Where H1–H5 hold, R6 largely follows. Where ERES requires cross-use linkage, R6 fails, and that failure is informative about R1.

## 5. Harness

`eres_rrh_test_instrument.py` (stdlib only) encodes each collision as a rule over a component configuration. It returns findings, never a verdict. It runs three configurations:

- **AS_CRITIQUED**: ERES as read by the critique. It must trip R1–R5, which proves the rules can fail.
- **HARDENED_V01**: H1–H6 applied. It must clear R1–R6 at the specification level.
- **UNIFIED_M**: hardened, but with a unified cross-domain M retained. It trips R1 (and R6 via cross-use linkage) while R2–R5 stay clear, which isolates the O1 design tension.

It also carries a regression baseline (expected finding counts per configuration per front), a self-SHA-256 printout, and a `--report` mode. Figure 1 is generated by the harness from live findings (`--figure`), not drawn by hand, so the figure cannot drift from the tested rules.

Result: 21 tests, 16 pass, 5 skip (the five OPEN items), regression self-diff none, exit 0.

![Figure 1](ERES-RRH-2026-001_Figure1_Findings-Matrix_v0.1.svg)

The OPEN items stay SKIP until closed. The suite greens fully only when the OPEN items close, the same discipline as ARH and CPROV.

## 6. OPEN items

- **O1**: Can a unified, cross-domain M reserve exist under Art. 5(1)(c)? This is a design decision for the author; H1 as written says no.
- **O2**: Does commitment-plus-crypto-shredding satisfy Art. 17 under EDPB 02/2025 v2.0?
- **O3**: Is the HPE stress readout "emotion recognition" within the AI Act definition, or health-only?
- **O4**: Annex III high-risk conformity (employment and public-assistance uses) from 2 December 2027. This is a process obligation and cannot be simulated.
- **O5**: External legal review by qualified EU data-protection and AI Act counsel. This is not simulable, and it is the sole gate Claude cannot stand in for.

## 7. What this instrument does not claim

- It does not claim ERES is compliant, lawful, or unlawful in any jurisdiction.
- It does not claim the critique is correct in every particular. It adopts it as a threat model.
- It does not endorse the critique's broader political claims about the thread's original topic.
- It is not legal advice.

## Credits, references, license

**Threat-model source.** Christopher Neitzert, public LinkedIn comment, September 2026 (paraphrased; credited as origin of R1–R5). His crediting here implies no endorsement of ERES.

**Primary instruments.**
- Regulation (EU) 2024/1689 (AI Act), Arts. 5, 6, Annex III.
- Regulation (EU) 2026/1744 (Digital Omnibus on AI), which defers stand-alone Annex III high-risk obligations to 2 December 2027.
- Regulation (EU) 2016/679 (GDPR), Arts. 5, 7, 9, 16, 17, 22, 25, Recital 43.
- Regulation (EU) 2024/1183 (eIDAS 2.0).

**Case law and guidance.**
- CJEU C-634/21, *OQ v Land Hessen (SCHUFA)*, 7 Dec 2023.
- EDPB Guidelines 02/2025 on processing of personal data through blockchain technologies, v2.0, adopted 7 Jul 2026.

**Internal ERES corpus.** ERES-ARH-2026-001; ERES-FLOOR-REGISTER-2026-001; ERES-PELLIS-GAIA-BENCHMARKS-2026-001 v0.3 (Humane Invariant); ERES HPE frame; PlayNAC.

**License.** CC BY 4.0 / CCAL v2.1. Sole author: Joseph A. Sprute. AI-assisted drafting (Claude); pre-MIEVM; pre-ratification.
