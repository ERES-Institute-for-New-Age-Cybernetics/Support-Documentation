#!/usr/bin/env python3
"""ERES-RRH-2026-001 Regulatory Root Hardening — adversarial harness v0.1.

Stdlib only. Encodes each declared collision (R1-R6) as a rule over a
component configuration and returns FINDINGS, never a verdict.

BOUNDARY: green = the SPECIFICATION clears a MODELED reading of the cited
provisions. It is NOT legal compliance, NOT a conformity assessment, NOT
legal advice. This module deliberately exposes no is_compliant / is_lawful /
is_safe function.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sys
import unittest
from dataclasses import dataclass, replace
from typing import List


@dataclass(frozen=True)
class Config:
    name: str
    # R1 social scoring (AI Act Art. 5(1)(c))
    floor_decrementable: bool          # can N (UBIMIA floor) be reduced by score?
    cross_context_effect: bool         # score from domain d affects treatment in domain d'
    effect_proportionate: bool         # detriment proportionate + explainable
    # R2 automated decisions (GDPR Art. 22)
    solely_automated_significant: bool
    meaningful_human_review: bool
    contest_channel: bool
    # R3 biometrics (GDPR Art. 9, 7(4); AI Act Annex III(1), 5(1)(g))
    biometric_required_for_participation: bool
    non_biometric_path_no_detriment: bool
    biometric_one_to_many: bool
    templates_on_ledger: bool
    infers_protected_traits: bool
    # R4 ledger (GDPR Arts. 16, 17, 5(1)(e), 25; EDPB 02/2025 v2.0)
    personal_data_on_chain: bool
    linkable_commitments_without_shred: bool
    retention_limits: bool
    # R5 emotion recognition (AI Act 5(1)(f)) + health data
    physio_readout_to_employer_or_educator: bool
    physio_feeds_merit: bool
    medical_or_safety_basis: bool
    # R6 eIDAS 2.0 alignment
    user_held_wallet: bool
    selective_disclosure: bool
    cross_use_linkage: bool


def check_r1(c: Config) -> List[str]:
    f = []
    if c.floor_decrementable:
        f.append("R1: survival floor N decremented by score")
    if c.cross_context_effect:
        f.append("R1: cross-context detrimental treatment (Art. 5(1)(c)(i))")
    if not c.effect_proportionate:
        f.append("R1: detriment not proportionate/explainable (Art. 5(1)(c)(ii))")
    return f


def check_r2(c: Config) -> List[str]:
    f = []
    if c.solely_automated_significant and not c.meaningful_human_review:
        f.append("R2: solely automated significant decision without meaningful review")
    if not c.contest_channel:
        f.append("R2: no contest channel (Art. 22(3))")
    return f


def check_r3(c: Config) -> List[str]:
    f = []
    if c.biometric_required_for_participation or not c.non_biometric_path_no_detriment:
        f.append("R3: consent not freely given (Art. 7(4)) - no detriment-free alternative")
    if c.biometric_one_to_many:
        f.append("R3: 1:N biometric identification (Annex III(1) high-risk)")
    if c.templates_on_ledger:
        f.append("R3: biometric templates on ledger")
    if c.infers_protected_traits:
        f.append("R3: biometric categorisation of protected traits (Art. 5(1)(g))")
    return f


def check_r4(c: Config) -> List[str]:
    f = []
    if c.personal_data_on_chain:
        f.append("R4: personal data on immutable chain (Arts. 16/17)")
    if c.linkable_commitments_without_shred:
        f.append("R4: linkable commitments with no erasure path")
    if not c.retention_limits:
        f.append("R4: no storage limitation (Art. 5(1)(e))")
    return f


def check_r5(c: Config) -> List[str]:
    f = []
    if c.physio_readout_to_employer_or_educator and not c.medical_or_safety_basis:
        f.append("R5: emotion inference in workplace/education (Art. 5(1)(f))")
    if c.physio_feeds_merit:
        f.append("R5: health/physiological data feeds merit score")
    return f


def check_r6(c: Config) -> List[str]:
    f = []
    if not c.user_held_wallet:
        f.append("R6: identity not user-held")
    if not c.selective_disclosure:
        f.append("R6: no selective disclosure")
    if c.cross_use_linkage:
        f.append("R6: cross-use linkage/profiling")
    return f


CHECKS = {"R1": check_r1, "R2": check_r2, "R3": check_r3,
          "R4": check_r4, "R5": check_r5, "R6": check_r6}


def findings(c: Config) -> dict:
    """Return {front: [findings]}. Deliberately not a verdict."""
    return {k: fn(c) for k, fn in CHECKS.items()}


AS_CRITIQUED = Config(
    name="AS_CRITIQUED",
    floor_decrementable=False,  # Humane Invariant already holds in corpus
    cross_context_effect=True, effect_proportionate=False,
    solely_automated_significant=True, meaningful_human_review=False,
    contest_channel=False,
    biometric_required_for_participation=True,
    non_biometric_path_no_detriment=False, biometric_one_to_many=True,
    templates_on_ledger=True, infers_protected_traits=False,
    personal_data_on_chain=True, linkable_commitments_without_shred=True,
    retention_limits=False,
    physio_readout_to_employer_or_educator=True, physio_feeds_merit=True,
    medical_or_safety_basis=False,
    user_held_wallet=False, selective_disclosure=False, cross_use_linkage=True,
)

HARDENED_V01 = Config(
    name="HARDENED_V01",
    floor_decrementable=False,
    cross_context_effect=False, effect_proportionate=True,           # H1
    solely_automated_significant=True, meaningful_human_review=True,  # H2
    contest_channel=True,
    biometric_required_for_participation=False,                       # H3
    non_biometric_path_no_detriment=True, biometric_one_to_many=False,
    templates_on_ledger=False, infers_protected_traits=False,
    personal_data_on_chain=False, linkable_commitments_without_shred=False,  # H4
    retention_limits=True,
    physio_readout_to_employer_or_educator=False, physio_feeds_merit=False,  # H5
    medical_or_safety_basis=False,
    user_held_wallet=True, selective_disclosure=True, cross_use_linkage=False,  # H6
)

UNIFIED_M = replace(HARDENED_V01, name="UNIFIED_M", cross_context_effect=True,
                    cross_use_linkage=True)

OPEN = {
    "O1": "Unified cross-domain M under Art. 5(1)(c) - author design decision",
    "O2": "Commitment + crypto-shredding vs Art. 17 under EDPB 02/2025 v2.0",
    "O3": "HPE stress readout = 'emotion' under AI Act definition?",
    "O4": "Annex III high-risk conformity from 2 Dec 2027 - process, not simulable",
    "O5": "External EU counsel review - not simulable by any model",
}


# ---- Regression baseline: expected finding COUNTS per config per front ----
EXPECTED = {
    "AS_CRITIQUED": {"R1": 2, "R2": 2, "R3": 3, "R4": 3, "R5": 2, "R6": 3},
    "HARDENED_V01": {"R1": 0, "R2": 0, "R3": 0, "R4": 0, "R5": 0, "R6": 0},
    "UNIFIED_M":    {"R1": 1, "R2": 0, "R3": 0, "R4": 0, "R5": 0, "R6": 1},
}
CONFIGS = (AS_CRITIQUED, HARDENED_V01, UNIFIED_M)
FRONT_LABELS = {"R1": "Social scoring", "R2": "Automated decisions",
                "R3": "Biometric identity", "R4": "Posterity ledger",
                "R5": "Emotion / health", "R6": "eIDAS alignment"}


def self_sha256() -> str:
    with open(os.path.abspath(__file__), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def regression_diff() -> list:
    """Diff live finding counts against EXPECTED. Empty list = no drift."""
    drift = []
    for c in CONFIGS:
        for k, v in findings(c).items():
            if len(v) != EXPECTED[c.name][k]:
                drift.append(f"{c.name}/{k}: expected {EXPECTED[c.name][k]}, got {len(v)}")
    return drift


def report() -> str:
    out = []
    for c in CONFIGS:
        out.append(f"== {c.name} ==")
        for k, v in findings(c).items():
            out.append(f"  {k} {FRONT_LABELS[k]:<20} " + ("clear" if not v else f"{len(v)} finding(s)"))
            out.extend(f"      - {x}" for x in v)
    out.append("OPEN: " + ", ".join(OPEN))
    return "\n".join(out)


def figure_svg() -> str:
    """Figure 1, generated from live findings (not hand-drawn)."""
    W, cw, rh, x0, y0 = 720, 150, 34, 190, 70
    red, grn, amb = "#c0392b", "#2e8b57", "#d68910"
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="400" viewBox="0 0 {W} 400" font-family="DejaVu Sans, Arial, sans-serif">',
         '<rect width="100%" height="100%" fill="#ffffff"/>',
         '<text x="20" y="30" font-size="16" font-weight="bold" fill="#1f3a5f">ERES-RRH-2026-001 v0.1 - Figure 1: collision findings by configuration</text>',
         '<text x="20" y="50" font-size="11" fill="#555">Generated by eres_rrh_test_instrument.py from live findings. Cell = number of findings.</text>']
    for j, c in enumerate(CONFIGS):
        p.append(f'<text x="{x0 + j*cw + cw/2}" y="{y0}" font-size="12" font-weight="bold" text-anchor="middle">{c.name}</text>')
    for i, k in enumerate(FRONT_LABELS):
        y = y0 + 12 + i*rh
        p.append(f'<text x="20" y="{y + 22}" font-size="12">{k}  {FRONT_LABELS[k]}</text>')
        for j, c in enumerate(CONFIGS):
            n = len(findings(c)[k])
            col = grn if n == 0 else (amb if c.name == "UNIFIED_M" else red)
            lab = "clear" if n == 0 else f"{n} finding" + ("s" if n > 1 else "")
            p.append(f'<rect x="{x0 + j*cw + 6}" y="{y}" width="{cw-12}" height="{rh-6}" rx="4" fill="{col}"/>')
            p.append(f'<text x="{x0 + j*cw + cw/2}" y="{y + 18}" font-size="11" fill="#fff" text-anchor="middle">{lab}</text>')
    yb = y0 + 12 + 6*rh + 14
    p.append(f'<text x="20" y="{yb}" font-size="11" fill="#333">Amber = O1 design tension (unified cross-domain M). OPEN: O1-O5 (SKIP in harness).</text>')
    p.append(f'<rect x="20" y="{yb + 14}" width="{W-40}" height="30" fill="#f3f3f3" stroke="#999"/>')
    p.append(f'<text x="{W/2}" y="{yb + 34}" font-size="11" text-anchor="middle" fill="#333">BOUNDARY: specification vs modeled reading of cited provisions - not legal compliance, not legal advice</text>')
    p.append("</svg>")
    return "\n".join(p)


class TestRegression(unittest.TestCase):
    def test_no_drift_from_baseline(self):
        self.assertEqual(regression_diff(), [])
    def test_figure_matches_findings(self):
        svg = figure_svg()
        self.assertEqual(svg.count("clear</text>"),
                         sum(1 for c in CONFIGS for v in findings(c).values() if not v))


class TestFalsifiers(unittest.TestCase):
    """AS_CRITIQUED must trip R1-R5: proves each rule can fail."""
    def test_r1_trips(self): self.assertTrue(check_r1(AS_CRITIQUED))
    def test_r2_trips(self): self.assertTrue(check_r2(AS_CRITIQUED))
    def test_r3_trips(self): self.assertTrue(check_r3(AS_CRITIQUED))
    def test_r4_trips(self): self.assertTrue(check_r4(AS_CRITIQUED))
    def test_r5_trips(self): self.assertTrue(check_r5(AS_CRITIQUED))
    def test_r6_trips(self): self.assertTrue(check_r6(AS_CRITIQUED))


class TestHardened(unittest.TestCase):
    """HARDENED_V01 clears R1-R6 at the specification level."""
    def test_all_clear(self):
        for k, v in findings(HARDENED_V01).items():
            with self.subTest(front=k):
                self.assertEqual(v, [])


class TestIsolation(unittest.TestCase):
    """UNIFIED_M isolates the O1 tension: only R1 (and R6 linkage) trip."""
    def test_unified_m_trips_r1(self):
        self.assertIn("R1: cross-context detrimental treatment (Art. 5(1)(c)(i))",
                      check_r1(UNIFIED_M))
    def test_unified_m_leaves_r2_to_r5_clear(self):
        for k in ("R2", "R3", "R4", "R5"):
            self.assertEqual(CHECKS[k](UNIFIED_M), [], k)


class TestInvariants(unittest.TestCase):
    def test_humane_invariant_held_in_every_config(self):
        for c in (AS_CRITIQUED, HARDENED_V01, UNIFIED_M):
            self.assertFalse(c.floor_decrementable, c.name)
    def test_floor_decrement_would_trip_r1(self):
        self.assertTrue(check_r1(replace(HARDENED_V01, floor_decrementable=True)))
    def test_medical_basis_lifts_r5_workplace_finding(self):
        c = replace(HARDENED_V01, physio_readout_to_employer_or_educator=True,
                    medical_or_safety_basis=True)
        self.assertEqual(check_r5(c), [])
    def test_no_verdict_function_exposed(self):
        mod = sys.modules[__name__]
        for bad in ("is_compliant", "is_lawful", "is_safe", "is_legal"):
            self.assertFalse(hasattr(mod, bad), bad)
    def test_findings_is_not_boolean(self):
        self.assertIsInstance(findings(HARDENED_V01), dict)


class TestOpen(unittest.TestCase):
    """OPEN items SKIP until closed; suite greens fully only when they do."""
    def test_o1(self): self.skipTest(OPEN["O1"])
    def test_o2(self): self.skipTest(OPEN["O2"])
    def test_o3(self): self.skipTest(OPEN["O3"])
    def test_o4(self): self.skipTest(OPEN["O4"])
    def test_o5(self): self.skipTest(OPEN["O5"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="ERES-RRH-2026-001 harness")
    ap.add_argument("--report", action="store_true", help="print findings per config")
    ap.add_argument("--figure", metavar="PATH", help="write Figure 1 SVG")
    a, rest = ap.parse_known_args()
    print(__doc__.strip().splitlines()[0])
    print("BOUNDARY: specification vs modeled reading; not legal advice.")
    print("self-SHA-256:", self_sha256(), "\n")
    if a.report:
        print(report()); sys.exit(0)
    if a.figure:
        open(a.figure, "w").write(figure_svg()); print("wrote", a.figure); sys.exit(0)
    result = unittest.main(argv=[sys.argv[0]] + rest, exit=False, verbosity=2).result
    drift = regression_diff()
    print("regression self-diff:", "none" if not drift else drift)
    sys.exit(0 if result.wasSuccessful() and not drift else 1)
