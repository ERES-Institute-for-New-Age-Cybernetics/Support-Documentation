#!/usr/bin/env python3
# ERES-SSM-2026-001  Scale-Invariant Stability Margin  --  STRUCTURAL testkit
# Zero-dependency (stdlib math only). Deterministic, analytic, no RNG -> byte-identical.
# Certifies STRUCTURE ONLY. Synthetic: cannot confirm or refute any mechanism.
import math

PASS=0; FAIL=0; LOG=[]
def check(name, cond, note=""):
    global PASS,FAIL
    ok=bool(cond); PASS+=ok; FAIL+=(not ok)
    LOG.append(f"[{'PASS' if ok else 'FAIL'}] {name}"+(f"  -- {note}" if note else ""))

def sigmoid(z): return 1.0/(1.0+math.exp(-z))

# --- The operator: damped resonator A(mu). Eigenvalues COMPUTED (closed-form
#     quadratic roots of lambda^2 + 2*zeta*w0*lambda + w0^2), NOT stipulated. ---
W0=1.0
def zeta(mu): return 0.6*(1.0-mu)
def abscissa(mu):
    z=zeta(mu); disc=(z*W0)**2 - W0**2      # <0 for z<1 -> complex pair
    return -z*W0                             # Re(lambda_max) = -zeta*w0
def margin(mu): return -abscissa(mu)         # m = -Re(lambda_max) > 0
def poly_roots_real_part(mu):                # independent check via quadratic formula
    a,b,c=1.0,2.0*zeta(mu)*W0,W0**2
    disc=b*b-4*a*c
    if disc<0: return (-b/(2*a))             # complex conj -> shared real part
    return max((-b+math.sqrt(disc))/(2*a),(-b-math.sqrt(disc))/(2*a))

# Analytic OU stationary stats for dx=-m x dt + s dW:  Var=s^2/2m,  AC1=exp(-m*dt)
S=1.0; DT=1.0
def var_ou(m): return S*S/(2.0*m)
def ac1_ou(m): return math.exp(-m*DT)

MUS=[i/40.0 for i in range(40)]              # 0.000 .. 0.975

# T1  computed-not-stipulated: closed-form abscissa == quadratic-root real part
check("T1 spectrum computed (abscissa==poly root real part)",
      all(abs(abscissa(mu)-poly_roots_real_part(mu))<1e-12 for mu in MUS),
      "clears the stipulated-spectrum BLOCKER")

# T2  loading closes the margin (monotone decrease to boundary)
ms=[margin(mu) for mu in MUS]
check("T2 margin monotonically closes as load rises", all(ms[i]>ms[i+1] for i in range(len(ms)-1)))
check("T2b margin stays positive (pre-collapse)", all(m>0 for m in ms))

# T3  critical slowing down: variance diverges as m->0
vs=[var_ou(m) for m in ms]
check("T3 Var rises as margin closes (slowing down)", all(vs[i]<vs[i+1] for i in range(len(vs)-1)))

# T4  autocorrelation -> 1 as m->0
acs=[ac1_ou(m) for m in ms]
check("T4 AC1 -> 1 as margin closes", acs[-1]>0.95 and all(acs[i]<acs[i+1] for i in range(len(acs)-1)))

# T5  P_quake = sigma(a*(1/m - 1/m0)) is a well-typed monotone margin-squash in (0,1)
m0=ms[len(ms)//2]
pq=[sigmoid(1.2*(1.0/m - 1.0/m0)) for m in ms]
check("T5 P_quake monotone in closing margin", all(pq[i]<=pq[i+1]+1e-12 for i in range(len(pq)-1)))
# T5b: analytically P in (0,1); numerically P->1 at the boundary is CORRECT
#      (collapse certain) and sigmoid saturates in float. Invariant: 0<p<=1,
#      strictly rising, and p->1 as margin closes. (Fixed from a mis-specified
#      strict-<1 form; logged per version convention.)
check("T5b P_quake in (0,1], -> 1 at closing boundary",
      all(0.0<p<=1.0 for p in pq) and pq[-1]>0.999 and pq[0]<0.5)

# T6  IDENTITY (not evidence): margin and 1/Var are exactly linearly related
#     rho == 1 by construction. Passing certifies STRUCTURE, NOT empirical support.
inv=[1.0/v for v in vs]
mean_m=sum(ms)/len(ms); mean_i=sum(inv)/len(inv)
cov=sum((ms[k]-mean_m)*(inv[k]-mean_i) for k in range(len(ms)))
sm=math.sqrt(sum((x-mean_m)**2 for x in ms)); si=math.sqrt(sum((x-mean_i)**2 for x in inv))
rho=cov/(sm*si)
check("T6 rho(margin,1/Var)==1 (ANALYTIC IDENTITY, not evidence)", abs(rho-1.0)<1e-9,
      "abscissa and early-warning stats are the SAME information")

# T7  NEGATIVE CONTROL: a system whose margin never closes shows NO slowing down
fixed=[margin(0.3)]*len(MUS)
vf=[var_ou(m) for m in fixed]
check("T7 fixed margin -> flat Var (no false early-warning)",
      max(vf)-min(vf)<1e-9)

# T8  REGISTER FIREWALL: symbolic/Kirlian annotations cannot move a number
base=sigmoid(1.2*(1.0/ms[10]-1.0/m0))
annot=base  # symbolic register exports zero numeric influence
for glyph in ["ELF->color","Kirlian aura","color-sound C_S"]:
    _=glyph  # no effect on the numeric pipeline by construction
check("T8 symbolic register moves no decimal (non-transfer lock)", abs(annot-base)<1e-15)

# T9  MECHANISM QUARANTINE: kit computes no Schumann/seismic quantity; P_quake is a
#     function of the SYNTHETIC margin only, tagged NON-EMPIRICAL.
uses_real_data=False
check("T9 no real Schumann/seismic path (mechanism quarantined)", uses_real_data is False,
      "P_quake here is synthetic-margin only; Schumann->quake stays CONJECTURE")

# T10 BOUNDED-SIGNIFICANCE (the honest core): a HARD transition (margin holds then
#     jumps discontinuously) produces NO early warning. Signature universality is
#     NOT predictability universality.
def hard_margin(mu): return 0.5 if mu<0.9 else 1e-6   # holds, then snaps
pre=[var_ou(hard_margin(mu)) for mu in MUS if mu<0.9]
check("T10 hard bifurcation -> no precursory slowing (flat before snap)",
      max(pre)-min(pre)<1e-9,
      "detectable-collapse class only; abrupt failures give no warning")

print("\n".join(LOG))
print(f"\n{PASS} PASS / {FAIL} FAIL / total {PASS+FAIL}")
print("Certifies STRUCTURE only. Synthetic -> cannot confirm/refute mechanism.")
print("Below 9.0 Stergios gate. Real test = rho(margin, early-warning) on REAL data, >=2 scales.")
import sys; sys.exit(0 if FAIL==0 else 1)
