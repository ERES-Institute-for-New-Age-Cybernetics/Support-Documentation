# Consolidated Open Questions for Dr. Pellis

**Document ID:** Pellis Next-2, Appendix A — v1.0
**Date:** June 21, 2026
**Purpose:** A single, reply-friendly list of every open item across the three response notes (Prongs 1–3) where your judgment, not ours, is the next step. Answer any subset; a partial answer, a correction to the question itself, or "open in my own work too" are all useful.

---

### Prong 1 — Spectral grounding

**Q1.** In *Spectral–Fractal Phase Transitions in Cardiac Dynamics from ECG Operator Flows*: §2.5 (eq. 69–70) defines the stability criterion using **sup** Re(λ); §2.7 (eq. 99–101) defines the critical manifold M_c using **min/inf** Re(λ). Is this a notational slip (max intended at eq. 99), or an intentional convention shift between sections that we're not reading correctly?

**Q2.** Does the cardiac critical manifold (eq. 99–101) exhibit the exceptional-point signature derived in *Spectral Collapse as a Universal Mechanism for Quantum Criticality* (√ε branch exponent, eq. 455–458; Petermann-factor divergence, eq. 460–461; Jordan-block growth law, eq. 463) — or is the degeneracy at M_c a regular, non-exceptional crossing? This is directly testable by your own S2 exponent-recovery criterion against simulated or recorded data.

**Q3.** Is L̂(t) confirmed to have discrete spectrum on the manifold relevant to §2.7, such that sup Re(λ) is actually attained rather than an unattained supremum? We've flagged this as an assumption, unverified on our end.

### Prong 3 — Type I/II calibration

**Q4.** Is there a tighter, operator-specific derivation of the Petermann-factor scaling K(ε) for the non-self-adjoint cardiac operator L̂(t) — rather than the generic second-order exceptional-point / two-level-laser scaling (K ~ ε^(−1/2)) we've borrowed from standard non-Hermitian physics?

**Q5.** What amplification ceiling K_crit would you consider clinically/scientifically defensible for treating a near-threshold spectral reading as untrustworthy? This is the number required to actually calibrate the containment gate's Z_threshold — currently a named but uncalibrated placeholder on our side.

---

*These five questions are the complete set of items in the three attached technical notes (Prongs 1–3) that are explicitly marked as requiring your input rather than ours. Everything else in those notes is either resolved on our side or flagged as our own open item, not yours.*

---

## License

CC BY 4.0 (Creative Commons Attribution 4.0 International).

## Credits

Joseph Allen Sprute (JAS), ERES Institute — direction. Claude (Sonnet 4.6, Anthropic) — extraction and consolidation from the three source notes.

## References

See Pellis Next-2 v1.0 (cover document), §References.
