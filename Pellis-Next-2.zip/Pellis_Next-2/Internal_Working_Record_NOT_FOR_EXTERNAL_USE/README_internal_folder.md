# Internal Working Record — NOT for External Use

This folder is included in the download zip for Joseph A. Sprute's own record-keeping only. Nothing here should be forwarded to Stergios Pellis or any external party in its current form.

| File | What it is | Why it's held back |
|---|---|---|
| `Prong1_v0.1_SUPERSEDED_provenance.pdf` | First draft of the PSCI-hat spectral bridge, built against a generic stand-in operator | Superseded by v0.2 (sent), which rebuilds on Pellis's actual cited operator. Kept for provenance/transparency only. |
| `ERES-Pellis-Spectral-Bridge-CenterBalance-MATH_internal_working_note.pdf` | Toy-model (2×2 Jacobian) demonstration of exceptional-point structure using ERES's own "Balancing Life's Extremes" optimization model | Self-labeled "internal use," "not yet packaged for Pellis pending Track B sequencing." Approach superseded in practice by Prong 1 v0.2's direct anchor to Pellis's own operator. |
| `ERES-ZEUS-N(Z)-section_HYPOTHESIZED_internal.md` / `.pdf` | A bounded normality-defect index (N(Z)) drafted for insertion into the CenterBalance-MATH document | Travels with CenterBalance-MATH; same hold. Two open calibration items still pending. (Kept in both formats, matching Pellis Next-1.) |
| `ERES-EXTERNAL-CONSTRAINT-TEST-2026-001_audit_ledger.pdf` | Internal pass/fail audit applying a derived-vs-constructed rigor test to recent claims (5 pass, 4 fail, 2 flagged) | Archival/self-audit document. Contains fail-ratings on some internally-constructed numerology claims unrelated to the Pellis collaboration. Per standing practice, documents like this should not be recirculated even with the fail-rating attached, since the rating can separate from the claim over time. |

**If any of these are wanted in a future external send:** CenterBalance-MATH and ZEUS/N(Z) are the more natural next contribution after Pellis responds to the current package — both are reasonably self-contained and could go out cleanly with their own cover note once Track B is further along. The audit ledger should remain internal regardless.
