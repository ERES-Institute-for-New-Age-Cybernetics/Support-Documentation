# ERES-PELLIS-EMCI-REEPER-2026-001 v0.1 — Package README

**REEPER** — Relative-Energy Equal-Pay / Emergency Response — proposed as the **Foundation for EMCI**.
Author: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics. License: CC BY 4.0.
Disposition: **DRAFT**, author-side single node, **HELD** pending Dr. Pellis's confirmation and external review.

## What this package is (and is not)

It **is** a governance specification plus a falsifier harness that encodes the
specification's structural claims as runnable assertions. It **is not** an
empirical result, a policy simulator, or a claim that REEPER "works." Nothing
is derived from telemetry.

- **Grade:** GOOD (claim) / SOUND-candidate (specification). *Nothing derived ⇒ none BEST.*
- **Correspondence:** ANALOGICAL. Pellis detection math is foundational (Layers 1–2); the governance application is ERES's (Layers 3–4) and is **not** endorsed by Dr. Pellis.
- **Non-transfer lock:** the physiology→infrastructure early-warning transfer is *proposable, not assertable* (ERES-SSM / The MARGIN). Only falsifier **F1** on real ≥2-scale telemetry lifts the detect layer off ANALOGICAL — and it is a **SKIP** here.
- **Gate:** clears 8.5 (Emanuel, diligence-ready); below 9.0 (Stergios), like every Pellis-facing instrument in the corpus.

## Files

| File | Role |
|---|---|
| `ERES-PELLIS-EMCI-REEPER-2026-001_v0_1.md` | The instrument (detect→route→distribute; the floor; the M/N invariant; falsifiers) |
| `eres_reeper_testkit.py` | Zero-dependency stdlib falsifier harness (12 PASS / 0 FAIL / 3 SKIP, exit 0) |
| `RUN.txt` | Captured harness output |
| `README.md` | This file |
| `MANIFEST.json` | SHA-256 of every file |

Reproduce: `python3 eres_reeper_testkit.py` (Python 3.10+, standard library only). Exit 0 = structure consistent.

## Claim → test traceability

| Instrument claim | Falsifier | Test |
|---|---|---|
| DETECT reads a spectral abscissa **computed**, not stipulated (§2) | — | T1 |
| FCEWI rises monotonically toward collapse (§2) | — | T2 |
| DETECT gives a **positive early-warning horizon** (§2) — could be null | — | T3 (load-bearing) |
| A healthy tile raises **no false alarm** (§2) | — | T4 (negative control) |
| ROUTE is **non-unilateral** — no single seat/factor authorizes (§3) | F4 | T5 |
| REEP never decrements the **N-floor** (§4, §7) | F3 | T6 |
| Admission is **non-refusable** for all callers (§3, §5) | F2 | T7 |
| **Survival/Merit separation** — entry unconditional, ascent merit-gated (§5) | F3, F6 | T8 |
| EarnedPath is **directional** — no skip/back (§5) | F6 | T9 |
| The FCEWS→EMCI empirical transfer is **quarantined in code** (§0, §8) | F5 | T10 |
| Every "foundational" credit string is **Pellis-scoped** (§A) | — | T11 |
| Grade carries **no BEST claim**; states "nothing derived" (§0) | F5 | T12 |
| ρ(FCEWI, real deterioration), ≥2 scales — **the only ANALOGICAL-lifter** (§9 F1) | F1 | **SKIP** (no data) |
| Independent ≥5-node MIEVM round (§10) | — | **SKIP** (author-side) |
| LLPM↔tile binding protocol (§11.4) | — | **SKIP** (OPEN in EMCI-SLA) |

The three SKIPs are the honest gap, not passes. T3 is the load-bearing one: an
early-warning claim that could have come out null and did not, on a computed
operator. It certifies STRUCTURE only — a shared dynamical shape — never that
the shape predicts real EMCI collapse. That is F1's job, and F1 is not run.

## Provenance note

REEPER assimilates **archivedwl-407** (ERES-ENDHOME-2026-001 v2.0 instrument +
testkit) as its domain precedent. ENDHOME already contains the detect→route→
provision loop for the homelessness domain — the I(t) early-warning band, the Γ
admission gate, the Attention-Routing Theorem, the Population Law, and the
Survival/Merit Separation. REEPER inherits those rather than reinventing them,
and asks only whether the scalar inflow signal generalizes to a cross-scale
coherence-collapse index over EMCI tiles. That single new question is held
ANALOGICAL.
