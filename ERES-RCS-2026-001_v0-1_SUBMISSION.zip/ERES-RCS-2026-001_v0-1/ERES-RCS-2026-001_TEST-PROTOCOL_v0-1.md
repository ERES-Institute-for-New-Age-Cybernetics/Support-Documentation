# ERES-RCS-2026-001 — Relevance Consolidation Sizing
### Test Protocol v0.1 (PROVISIONAL — working ID; canonical reserved to JAS)

A falsifiable procedure for measuring and justifying data-center + ancillary
capacity from a system's relevance dynamics. Ships with a runnable reference
implementation (`eres_rcs_sizing.py`, 13 self-tests, stdlib only).

---

## 1. The claim, in one line

A compute system's *useful* output is its raw throughput times a relevance
efficiency that decays as its internal picture drifts out of date; an offline
**consolidation ("sleep")** phase resets that drift. Therefore required capacity,
and the cost-minimizing sleep cadence, are **computable from measured drift and
demand** — and both are wrong in predictable, testable ways if the model is wrong.

This document exists to be **falsified**, not believed. Section 7 lists what kills it.

---

## 2. The model (exact given the Section 3 forms)

Symbols and every equation are implemented in `eres_rcs_sizing.py`.

```
relevance efficiency     a(ε) = exp(−ε² / 2σ²)              useful fraction of throughput, ∈(0,1]
required raw capacity     R(ε) = D / a(ε) = D·exp(ε²/2σ²)    to deliver demand D
misalignment vs cadence   ε̄(T) = k·T,   k = ρ(2−η)/(2η)      time-avg (sizing)
                          ε_peak(T) = ρT/η                   pre-sleep peak (floor guarantee)
curvature constant        γ = k² / 2σ²
power coefficients        A = PUE·D·(1/opw + b),  B = PUE·F

power objective           P(T) = A·e^{γT²} + B/T             strictly convex on T>0
optimal cadence  T*       T³·e^{γT²} = B / (2Aγ)             unique root (FOC)
optimal power             P* = A·e^{x*}·(1 + 2x*),  x* = γT*²
cadence approximation     T* ≈ (B / 2Aγ)^{1/3}   ∝ σ^{2/3} η^{2/3} ρ^{−2/3} (B/A)^{1/3}
guaranteed-floor cadence  T ≤ (η/ρ)·σ·√(2·E*·P/R)            to hold residual E_rel ≤ E*
```

**Measured parameters** — `D` (demand), `ρ` (drift), `σ` (tolerance),
`η` (consolidation efficiency), `opw` (ops/watt), `PUE`, `F`, `b` — enter **only**
through `γ`, `A`, `B`. Measure those three lumped constants and the sizing is closed.

Reference values (example params in the code): T* = 4.8828, over-provisioning
1.045×, P* = 1.6282 — the closed forms reproduce the brute-force sweep exactly.

---

## 3. Assumptions under test

These are the modeling choices. Each is independently checkable; the experiment is
designed to confirm or break them.

- **A1 — Relevance kernel is Gaussian.** `a(ε)=exp(−ε²/2σ²)`. Weaker fallback: a
  monotone-decreasing efficiency with a characteristic width σ.
- **A2 — Sawtooth misalignment.** ε drifts ≈linearly between sleeps and resets
  multiplicatively (`ε → (1−η)ε`) at each consolidation.
- **A3 — Consolidation cost = fixed + replay.** `C_consol = F + b·R` per cycle.
- **A4 — Ancillary is a linear PUE multiplier.**
- **A5 — Useful output = capacity × efficiency.** `useful = R·a(ε)`.

---

## 4. Measurement protocol (how to get each parameter on a real system)

- **D** — define the task's success metric per unit time; D is the target rate.
- **ρ (drift)** — on the pure-RT arm with consolidation OFF, fit the slope of the
  relevance-error trajectory ε(t). Slope = ρ. (`recover_rho` does this.)
- **σ (tolerance)** — induce a range of fixed misalignments, measure useful-output
  fraction at each, fit `a(ε)`; σ is the width, or the ε where useful-fraction = e^{−1/2} ≈ 0.607.
- **η (consolidation efficiency)** — measure ε immediately before and after one
  consolidation event; η = 1 − ε_after/ε_before. (`recover_eta`.)
- **opw, PUE** — standard hardware/facility telemetry.
- **F, b** — regress measured consolidation energy on (cycle count, buffer size);
  intercept = F, slope = b.

**No circular fitting:** parameters must be measured on data *separate* from the
validation runs in Section 6. Fitting the same trajectory you then "predict" proves nothing.

---

## 5. The experiment (two-arm, pre-registered)

Task with a **controllably drifting ground truth** (e.g. a label distribution or
target function that shifts at a set rate).

- **Arm 1 — Consolidating:** periodic offline consolidation phase, period T.
- **Arm 2 — Pure-RT:** consolidation disabled; acquisition only.

Log over time on both arms: relevance-error ε(t) (or 1 − task-accuracy as proxy),
wasted-compute fraction, useful-output rate, total facility power.

**Sweep T on Arm 1** across ≥3 values spanning T*, at ≥3 drift rates ρ, to trace
P(T) and locate the empirical optimum T̂*.

---

## 6. Pre-registered predictions

- **P1 — Divergence.** Pure-RT ε(t) grows without bound; useful fraction → 0.
  Consolidating ε(t) stays in a bounded band; useful fraction stays high.
- **P2 — Separation.** ΔE(t) between arms grows monotonically toward the full
  wasted-resource budget R/P.
- **P3 — Floor law.** Arm 1 holds a relevance floor E* iff T ≤ (η/ρ)σ√(2E*P/R).
  Arms sleeping less often cross the floor.
- **P4 — Convex optimum.** P(T) is convex with a unique interior minimum; the
  measured T̂* matches the FOC root within CI.
- **P5 — Power value.** P* = A·e^{x*}(1+2x*) predicts the measured minimum within CI.

---

## 7. Falsification criteria (scoped)

- **F1 (kills the whole model).** A pure-RT system holds relevance indefinitely
  under real drift with **no** consolidation. Then sleep is not required and the
  central claim is false.
- **F2 (kills A1).** Useful-output fraction vs misalignment is not
  monotone-decreasing / has no characteristic σ.
- **F3 (kills the optimum).** P(T) has no interior minimum (monotone in T) — no
  sizing tradeoff exists.
- **F4 (kills the specific forms).** With parameters measured independently, T̂* or
  P* deviate from the closed forms beyond CI. The qualitative story (consolidation
  reduces required capacity) may survive even if the exact algebra does not.

A result that triggers F2–F4 but not F1 **downgrades** the instrument to the
qualitative claim; F1 retires it.

---

## 8. CERT gate (what would make this REAL, not just GOOD)

Pre-registered success: closed-form T* and P* land within measured 95% CI across
≥3 drift rates and ≥3 cadences, with all parameters measured on held-out data
(Section 4, no circular fitting). Independent replication on a second task/facility.
Only then does the instrument move SOUND/GOOD → REAL. Current status: **derived and
self-consistent (simulation-verified), not yet empirically tested.**

---

## 9. Reference implementation

`eres_rcs_sizing.py` (stdlib). Run `python3 eres_rcs_sizing.py` for the model
summary and 13 self-tests (all pass): closed-form optimum vs brute force, convexity,
the P* identity, pure-RT divergence, consolidating boundedness, arm separation,
floor-cadence monotonicity, and parameter recovery (ρ, η) from trajectories —
demonstrating the Section 4 protocol closes the loop on synthetic data.

---

**Credits** (Sentience convention): Joseph A. Sprute (ERES Institute for New Age
Cybernetics; ORCID 0000-0001-9946-3221), principal author; Claude (Anthropic) as
this-instrument drafting node under the human–AI Sentience convention, not
co-author.
**License:** CC BY 4.0.
**References:** ERES Triune Math (C = R·P/M; M·E + C = R); RHC (Resonant Harmony
Cycle) return-to-base loop; Floor Register (10-10 Empirical admissibility);
the E-drift / relevance-consolidation derivation (this thread).
**Status:** PROVISIONAL v0.1, pre-MIEVM. Canonization gated on the Section 8 CERT
criteria and an ensemble review.
