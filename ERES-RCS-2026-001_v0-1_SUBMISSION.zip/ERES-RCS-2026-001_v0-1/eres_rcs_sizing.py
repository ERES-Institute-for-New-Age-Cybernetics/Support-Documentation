"""
ERES-RCS-2026-001  -  Relevance Consolidation Sizing  -  reference implementation v0.1
================================================================================
Turns the "sleep/consolidation cadence -> data-center capacity" model into runnable,
falsifiable code. Two things live here:

  1. The MODEL (closed form): relevance-efficiency, required capacity, the power
     objective P(T), its unique optimum T*, and the guaranteed-floor cadence T_max.
  2. The EXPERIMENT (simulation + parameter recovery): simulate a consolidating arm
     and a pure-RT arm under drift, and recover the drift/consolidation parameters
     from a trajectory -- demonstrating the measurement protocol closes the loop.

All stdlib. Run `python3 eres_rcs_sizing.py` to execute the self-tests.
Working ID; canonical reserved to JAS. License CC BY 4.0.
"""

import math

# ----------------------------------------------------------------------------
# MODEL PARAMETERS (each must be MEASURED on a real system; see the .md protocol)
#   D    demand: relevant-mind-work per unit time (task success rate target)
#   opw  useful ops per watt (throughput per watt) of the compute
#   rho  environmental drift rate (misalignment accrued per unit time, unconsolidated)
#   sigma relevance tolerance (Gaussian width of the efficiency kernel)
#   eta  consolidation efficiency in (0,1]: fraction of misalignment a sleep removes
#   PUE  ancillary multiplier (cooling + power distribution), >= 1
#   F    fixed consolidation cost per sleep cycle
#   b    per-capacity replay cost during consolidation
# ----------------------------------------------------------------------------

EXAMPLE = dict(D=1.0, opw=1.0, rho=0.10, sigma=1.0, eta=0.90, PUE=1.30, F=0.50, b=0.10)


# ---- lumped constants (all measured params enter ONLY through these) --------

def k_drift(rho, eta):
    """Misalignment growth per unit cadence (time-avg). eps_bar(T) = k * T."""
    return rho * (2.0 - eta) / (2.0 * eta)

def gamma(rho, eta, sigma):
    """Curvature constant: a(T) = exp(-gamma T^2), R(T) = D exp(gamma T^2)."""
    k = k_drift(rho, eta)
    return (k * k) / (2.0 * sigma * sigma)

def A_coef(PUE, D, opw, b):
    """Capacity-coupled power coefficient in P(T) = A e^{gamma T^2} + B/T."""
    return PUE * D * (1.0 / opw + b)

def B_coef(PUE, F):
    """Fixed-consolidation power coefficient in P(T)."""
    return PUE * F


# ---- static relations -------------------------------------------------------

def relevance_efficiency(eps, sigma):
    """a(eps) = exp(-eps^2 / 2 sigma^2). Useful fraction of throughput. In (0,1]."""
    return math.exp(-(eps * eps) / (2.0 * sigma * sigma))

def required_capacity(eps, D, sigma):
    """R(eps) = D / a(eps) = D exp(eps^2/2sigma^2). Raw capacity to deliver demand D."""
    return D / relevance_efficiency(eps, sigma)

def eps_bar(T, rho, eta):
    """Steady-state TIME-AVERAGE misalignment at cadence T (used for power sizing)."""
    return k_drift(rho, eta) * T

def eps_peak(T, rho, eta):
    """Steady-state PEAK (pre-sleep) misalignment at cadence T (used for floor guarantee)."""
    return rho * T / eta


# ---- power objective and its optimum ---------------------------------------

def facility_power(T, p):
    """P(T) = A e^{gamma T^2} + B/T   (PUE folded into A,B). Strictly convex on T>0."""
    g = gamma(p['rho'], p['eta'], p['sigma'])
    A = A_coef(p['PUE'], p['D'], p['opw'], p['b'])
    B = B_coef(p['PUE'], p['F'])
    return A * math.exp(g * T * T) + B / T

def _dP_dT(T, p):
    g = gamma(p['rho'], p['eta'], p['sigma'])
    A = A_coef(p['PUE'], p['D'], p['opw'], p['b'])
    B = B_coef(p['PUE'], p['F'])
    return A * math.exp(g * T * T) * (2.0 * g * T) - B / (T * T)

def optimal_cadence(p):
    """Unique T* minimizing P(T): the root of dP/dT (bisection). Convexity => unique."""
    # bracket: dP/dT < 0 for small T, > 0 for large T
    lo = 1e-9
    hi = 1.0
    # expand hi until derivative turns positive (cap gamma*T^2 to avoid overflow)
    g = gamma(p['rho'], p['eta'], p['sigma'])
    while _dP_dT(hi, p) < 0.0 and g * hi * hi < 300.0:
        hi *= 2.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if _dP_dT(mid, p) > 0.0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)

def optimal_power(p):
    """Closed-form minimum: P* = A e^{x*} (1 + 2 x*), x* = gamma T*^2."""
    T = optimal_cadence(p)
    g = gamma(p['rho'], p['eta'], p['sigma'])
    A = A_coef(p['PUE'], p['D'], p['opw'], p['b'])
    x = g * T * T
    return A * math.exp(x) * (1.0 + 2.0 * x)

def cadence_cube_root_approx(p):
    """T* ~ (B / 2 A gamma)^(1/3), valid when gamma T*^2 << 1."""
    g = gamma(p['rho'], p['eta'], p['sigma'])
    A = A_coef(p['PUE'], p['D'], p['opw'], p['b'])
    B = B_coef(p['PUE'], p['F'])
    return (B / (2.0 * A * g)) ** (1.0 / 3.0)

def cadence_for_floor(Estar, p, RP=1.0):
    """Max cadence holding relevance-residual E_rel <= Estar (peak eps, small-angle):
       T_max = (eta/rho) * sigma * sqrt(2 Estar P / R). RP = R/P ceiling (default 1)."""
    return (p['eta'] / p['rho']) * p['sigma'] * math.sqrt(2.0 * Estar / RP)


# ---- experiment: simulate the two arms and recover parameters --------------

def simulate(T, p, horizon, dt=0.05, consolidate=True):
    """Return (times, eps, E_rel_normalized) under drift deps/dt=rho with
       multiplicative resets eps*=(1-eta) at each multiple of T (if consolidate)."""
    ts, es, Es = [], [], []
    eps = 0.0
    n = int(round(horizon / dt))
    next_sleep = T
    for i in range(n + 1):
        t = i * dt
        eps += p['rho'] * dt
        if consolidate and t >= next_sleep - 1e-12:
            eps *= (1.0 - p['eta'])
            next_sleep += T
        ts.append(t)
        es.append(eps)
        Es.append(1.0 - relevance_efficiency(eps, p['sigma']))  # normalized E_rel, R/P=1
    return ts, es, Es

def recover_rho(times, eps):
    """Estimate drift rho as the least-squares slope of eps(t) on a NON-consolidating
       (pure-RT) trajectory. Demonstrates the measurement protocol for rho."""
    n = len(times)
    mt = sum(times) / n
    me = sum(eps) / n
    num = sum((times[i] - mt) * (eps[i] - me) for i in range(n))
    den = sum((times[i] - mt) ** 2 for i in range(n))
    return num / den

def recover_eta(eps_before, eps_after):
    """Estimate consolidation efficiency from one sleep event: eta = 1 - after/before."""
    return 1.0 - eps_after / eps_before


# ----------------------------------------------------------------------------
# SELF-TESTS
# ----------------------------------------------------------------------------

def _tests():
    import unittest

    class T(unittest.TestCase):
        p = EXAMPLE

        def test_efficiency_bounds(self):
            self.assertAlmostEqual(relevance_efficiency(0.0, 1.0), 1.0)
            self.assertLess(relevance_efficiency(5.0, 1.0), 0.01)

        def test_capacity_identity(self):
            # computer = mind at eps=0: no over-provisioning
            self.assertAlmostEqual(required_capacity(0.0, 1.0, 1.0), 1.0)

        def test_optimum_matches_reference(self):
            Tstar = optimal_cadence(self.p)
            self.assertAlmostEqual(Tstar, 4.8828, places=3)

        def test_power_closed_form_matches_objective(self):
            Tstar = optimal_cadence(self.p)
            self.assertAlmostEqual(facility_power(Tstar, self.p),
                                   optimal_power(self.p), places=6)

        def test_optimal_power_value(self):
            self.assertAlmostEqual(optimal_power(self.p), 1.6282, places=3)

        def test_convex_unique_min(self):
            Tstar = optimal_cadence(self.p)
            p0 = facility_power(Tstar, self.p)
            self.assertLess(p0, facility_power(Tstar * 0.5, self.p))
            self.assertLess(p0, facility_power(Tstar * 2.0, self.p))

        def test_cube_root_approx_close(self):
            # within 2% in the well-aligned regime
            self.assertLess(abs(cadence_cube_root_approx(self.p) /
                                optimal_cadence(self.p) - 1.0), 0.02)

        def test_pure_rt_diverges(self):
            _, es, _ = simulate(5.0, self.p, horizon=60, consolidate=False)
            self.assertGreater(es[-1], es[0] + 5.0)  # unbounded growth

        def test_consolidating_bounded(self):
            _, es, _ = simulate(5.0, self.p, horizon=200, consolidate=True)
            self.assertLess(max(es), eps_peak(5.0, self.p['rho'], self.p['eta']) + 0.05)

        def test_separation_grows(self):
            _, _, Ec = simulate(5.0, self.p, horizon=60, consolidate=True)
            _, _, Er = simulate(5.0, self.p, horizon=60, consolidate=False)
            self.assertGreater(Er[-1] - Ec[-1], 0.5)  # arms separate

        def test_floor_cadence_monotonicity(self):
            base = cadence_for_floor(0.05, self.p)
            faster_drift = dict(self.p); faster_drift['rho'] *= 2
            self.assertLess(cadence_for_floor(0.05, faster_drift), base)  # drift up -> sleep more

        def test_recover_rho(self):
            ts, es, _ = simulate(5.0, self.p, horizon=40, consolidate=False)
            self.assertAlmostEqual(recover_rho(ts, es), self.p['rho'], places=3)

        def test_recover_eta(self):
            # peak just before a sleep vs value just after
            before = eps_peak(5.0, self.p['rho'], self.p['eta'])
            after = before * (1.0 - self.p['eta'])
            self.assertAlmostEqual(recover_eta(before, after), self.p['eta'], places=6)

    suite = unittest.TestLoader().loadTestsFromTestCase(T)
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    p = EXAMPLE
    print("ERES-RCS-2026-001 reference model  (example parameters)")
    print(f"  gamma={gamma(p['rho'],p['eta'],p['sigma']):.6g}  "
          f"A={A_coef(p['PUE'],p['D'],p['opw'],p['b']):.4g}  B={B_coef(p['PUE'],p['F']):.4g}")
    Tstar = optimal_cadence(p)
    x = gamma(p['rho'], p['eta'], p['sigma']) * Tstar * Tstar
    print(f"  T*        = {Tstar:.4f}   (cube-root approx {cadence_cube_root_approx(p):.4f})")
    print(f"  a(eps*)   = {math.exp(-x):.4f}   over-provisioning = {math.exp(x):.4f}x")
    print(f"  P*        = {optimal_power(p):.4f}   (= facility_power(T*) = {facility_power(Tstar,p):.4f})")
    print(f"  T_max(E*=0.05) = {cadence_for_floor(0.05,p):.3f}   T_max(E*=0.10) = {cadence_for_floor(0.10,p):.3f}")
    print()
    _tests()
