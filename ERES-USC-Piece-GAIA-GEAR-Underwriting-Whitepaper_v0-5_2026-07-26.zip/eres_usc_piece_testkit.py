#!/usr/bin/env python3
"""
eres_usc_piece_testkit.py  v0.1
Companion structural test suite for ERES-USC-PIECE-2026-001 v0.4.

SCOPE (honest): these tests check STRUCTURAL invariants of the Piece-Set —
the rules the instrument declares about itself. They do NOT test any empirical
claim (life-support continuity, coverage adequacy, whether the USC apparatus
can be built). Those stay CONJECTURE by construction and are out of scope here.
A green run is evidence of internal coherence, not of empirical truth.

stdlib only. Exit 0 iff all structural invariants hold.
"""
import sys

TESTS_SPEC_VERSION = (0, 2, 0)
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))


# ---------------------------------------------------------------------------
# Model: the minimal objects the instrument declares
# ---------------------------------------------------------------------------

VEILED = object()  # the distinguished non-numeric credit state (never a number)


class Credit:
    """A credit may be VEILED (no coerced magnitude) or hold an honest number."""
    def __init__(self, state):
        self.state = state  # VEILED or a real number


def credit_operation(credit, mode):
    """
    #V1 VEILED-C rule, canon-forced by F3 (arithmetic substitution of earned
    magnitude is a spec violation). Two modes:
      - 'qualify': credit gates issuance as a boolean; VEILED is preserved. OK.
      - 'convert': credit is turned into a token magnitude. FORBIDDEN if VEILED.
    Returns a token descriptor or raises SpecViolation.
    """
    if mode == "qualify":
        return {"issued": True, "magnitude": None, "veiled_preserved": credit.state is VEILED}
    if mode == "convert":
        if credit.state is VEILED:
            raise SpecViolation("F3: cannot substitute magnitude for a VEILED credit")
        return {"issued": True, "magnitude": credit.state, "veiled_preserved": False}
    raise ValueError("unknown mode")


class SpecViolation(Exception):
    pass


# Floors: three distinct, non-conflatable objects
FLOORS = {
    "science_commons": {"kind": "magnitude", "reservable": True},
    "hfvn_access":     {"kind": "access",    "reservable": False},
    "ag_abundance":    {"kind": "magnitude", "reservable": True},
}

# Pieces: family = number of structural positions
PIECES = {
    "P1_USC":  {"family": "triad", "slots": 3},   # M x E + C = R
    "P4_BEE":  {"family": "triad", "slots": 3},   # GSSG x FDRV + HFVN = THOW
    "P6_TETRA": {"family": "tetra", "vertices": 4},  # SSHP SSLA SSPS SSST
}

TETRA_VERTICES = {"SSHP", "SSLA", "SSPS", "SSST"}


def tetra_closes(present):
    """CERT-TETRA is conjunctive: closes iff all four vertices present."""
    return set(present) == TETRA_VERTICES


def conjunctive_core(a, b):
    """x-core: if either factor is 0, the product is 0 (no compensation)."""
    return a * b


def net_paine(reduced, induced):
    """
    P3 #P1: Merit rewards NET suffering reduced against baseline, with an
    induce-then-relieve exclusion. Inducing to later relieve nets to <= 0.
    """
    delta = reduced - induced
    return max(delta, 0.0) if induced > 0 else reduced


def reserve_against(floor_name):
    """P5: reserve may strike ONLY against a reservable magnitude floor."""
    f = FLOORS[floor_name]
    if f["kind"] != "magnitude" or not f["reservable"]:
        raise SpecViolation(f"cannot reserve against {floor_name} ({f['kind']})")
    return True


def teach_coverage(duration_proven_years, horizon_required_years):
    """
    P5 GRIST (te(a)ch reframing): reserve is denominated in DURATION of proven
    coherence, not priced magnitude. Coverage holds iff proven >= required.
    Honest consequence (#U2): a not-yet-built system has proven == 0, so at
    inception coverage is NOT satisfiable. The reframing supplies a UNIT for
    the reserve; it does NOT discharge the underwriting requirement at t=0.
    """
    return duration_proven_years >= horizon_required_years


# DVC ledger: (claim, tag). Empirical claims must not be tagged CANONICAL.
DVC = [
    ("GCF/EDF canonical primitives", "CANONICAL"),
    ("USC = technical Collector = How", "CONSTRUCTED"),
    ("USC apparatus buildable", "CONJECTURE"),
    ("Piece maps onto M x E + C = R", "CONSTRUCTED"),
    ("life-support exposure priced", "CONJECTURE"),
    ("CERT-TETRA closure", "CONSTRUCTED"),
]
EMPIRICAL_CLAIMS = {"USC apparatus buildable", "life-support exposure priced"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

# t1 - VEILED credit cannot be converted to magnitude (F3 forecloses it)
try:
    credit_operation(Credit(VEILED), "convert")
    check("t1 VEILED-C convert forbidden", False, "conversion was allowed")
except SpecViolation:
    check("t1 VEILED-C convert forbidden", True)

# t2 - VEILED credit CAN qualify issuance, staying VEILED
r = credit_operation(Credit(VEILED), "qualify")
check("t2 VEILED-C qualify preserves veil",
      r["issued"] and r["magnitude"] is None and r["veiled_preserved"])

# t3 - an honest (non-VEILED) number may convert (rule is about VEILED only)
r = credit_operation(Credit(7.0), "convert")
check("t3 non-VEILED may convert", r["magnitude"] == 7.0)

# t4 - the two +C floors are distinct kinds (access vs magnitude), not merged
check("t4 access-floor != magnitude-floor",
      FLOORS["hfvn_access"]["kind"] != FLOORS["science_commons"]["kind"])

# t5 - three distinct floors registered
check("t5 three distinct floors", len(FLOORS) == 3 and len({id(v) for v in FLOORS.values()}) == 3)

# t6 - reserve strikes against magnitude floors only, never access floor
ok = reserve_against("science_commons")
try:
    reserve_against("hfvn_access")
    ok = False
except SpecViolation:
    pass
check("t6 reserve magnitude-only", ok)

# t7 - family discipline: triads have 3 slots, tetra has 4 vertices
check("t7 triad=3 tetra=4",
      PIECES["P1_USC"]["slots"] == 3 and PIECES["P4_BEE"]["slots"] == 3
      and PIECES["P6_TETRA"]["vertices"] == 4)

# t8 - CERT-TETRA is conjunctive: missing any vertex => not closed
check("t8 tetra closes iff complete",
      tetra_closes({"SSHP", "SSLA", "SSPS", "SSST"})
      and not tetra_closes({"SSHP", "SSLA", "SSPS"}))

# t9 - conjunctive core collapses on either zero
check("t9 conjunctive collapse",
      conjunctive_core(3, 4) == 12 and conjunctive_core(0, 4) == 0 and conjunctive_core(3, 0) == 0)

# t10 - induce-then-relieve nets out; honest reduction survives
check("t10 induce-then-relieve excluded",
      net_paine(5, 0) == 5 and net_paine(5, 5) == 0 and net_paine(5, 8) == 0)

# t11 - DVC hygiene: no empirical claim tagged CANONICAL
bad = [c for (c, t) in DVC if c in EMPIRICAL_CLAIMS and t == "CANONICAL"]
check("t11 no empirical claim tagged CANONICAL", not bad, str(bad))

# t12 - honest-rating gate: while any CONJECTURE remains, no empirical 10-10
has_conjecture = any(t == "CONJECTURE" for (_, t) in DVC)
claims_empirical_ten_ten = False  # the instrument does NOT self-claim it
check("t12 no empirical 10-10 while CONJECTURE open",
      not (has_conjecture and claims_empirical_ten_ten))


# t13 - te(a)ch accrual gap: reserve-as-duration does NOT close underwriting
#        at inception. proven=0 for a not-yet-built city => not covered;
#        coverage holds only once duration is genuinely accrued.
check("t13 te(a)ch accrual gap real",
      teach_coverage(1000, 1000) is True
      and teach_coverage(0, 1000) is False        # flying city at inception
      and teach_coverage(14, 1000) is False)       # ERES founded 2012 ~ 14y

# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
passed = sum(1 for _, ok, _ in results if ok)
failed = sum(1 for _, ok, _ in results if not ok)
print(f"ERES-USC-PIECE-2026-001 structural testkit  spec {TESTS_SPEC_VERSION}")
print(f"SCOPE: structural invariants only; empirical claims out of scope (stay CONJECTURE).")
print("-" * 68)
for name, ok, detail in results:
    line = f"[{'PASS' if ok else 'FAIL'}] {name}"
    if detail and not ok:
        line += f"   <- {detail}"
    print(line)
print("-" * 68)
print(f"{passed} pass · {failed} fail  (of {len(results)})")
sys.exit(0 if failed == 0 else 1)
