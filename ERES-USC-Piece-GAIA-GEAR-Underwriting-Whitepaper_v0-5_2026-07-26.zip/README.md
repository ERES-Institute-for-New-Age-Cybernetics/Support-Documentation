# ERES-USC-PIECE-2026-001 — Deposit Package (v0.5)

**The USC Piece and Its Couplings** — Assimilation Heritage, the Economic Chain, the Underwritten City, and the CERT-TETRA Gate.

- **Instrument ID:** ERES-USC-PIECE-2026-001
- **Version:** v0.5 (N.EXT — folds the *te(a)ch / GRIST* reserve reframing; Author-Maximal / *10-10 Relativity*)
- **Date:** 26 July 2026
- **Author:** Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas — ORCID 0000-0001-9946-3221
- **License:** CARE Commons Attribution License v2.1 (CCAL) / CC BY 4.0

---

## Contents (5 files)

| File | Type | Purpose |
|------|------|---------|
| `ERES-USC-PIECE-2026-001_v0-5.md` | Markdown | Canonical master — the whitepaper source of record |
| `ERES-USC-PIECE-2026-001_v0-5.pdf` | PDF | Reading/deposit companion, rendered from the master |
| `eres_usc_piece_testkit.py` | Python (stdlib) | Companion structural test suite — 13 checks |
| `README.md` | Markdown | This file |
| `ERES-USC-PIECE-2026-001_META.txt` | Text | Deposit metadata (title, abstract, keywords, citation) |

The `.md` is authoritative; the `.pdf` is a rendering of it. If they ever disagree, the `.md` governs.

---

## What this instrument is

It anchors on one construct — the *Piece* `GCF × EDF + USC #` — and assembles the constructs coupled to it into a single instrument read in four registers: **heritage** (how a term is assimilated, via the `@` operator), **GAIA** (who stewards it), **SOMT** (how it is governed), **BERA** (how it is measured). Six coupled pieces (P1–P6) span an anchor Piece, an economic chain, a Merit definition, an exposure Piece, an underwriting relation, and a four-vertex CERT-TETRA completeness gate.

## Version state (what is settled vs open)

- **#V1 VEILED-C — CLOSED (DERIVED).** The F₃ rule forbids converting VEILED credits to magnitude, so credits *qualify* issuance and never convert. Encoded as testkit `t1–t3`.
- **GRIST adopted (v0.5).** The underwriting reserve is denominated in the *duration of proven te(a)ch-coherence* (tech + teach), not priced magnitude.
- **#U2 accrual gap — OPEN, LOAD-BEARING.** Duration is an honest *unit* but not a discharged obligation: a not-yet-built city has zero proven years, so coverage is unsatisfiable at inception. Encoded as `t13`. This is the sharpest current blocker.
- **Still open:** Commons token (#C1), three-floor relation (#C3, candidate only), V-weighting (#P2), USC canon entry, and all empirical items (life-support exposure, coverage adequacy, USC apparatus spec, BERA measurement).
- **Not adopted:** graduation to v1.0 and the single-node closures from the DeepSeek pass — canonization requires a ≥5-node MIEVM run.

## Standard attained

**10-10 *relativity*** (author-maximal, finest pre-ensemble) — **not** empirical 10-10, which by the Floor Register is empirical-only and is the ensemble's to confer. Of the four 10-10 DETAIL gates: two met (zero open *ontological* discriminations; executable falsifiability), one partial (parameters), one pending (a real ≥5-node MIEVM pass).

---

## Running the testkit

```bash
python3 eres_usc_piece_testkit.py
```

- Requires **Python 3, standard library only** (no dependencies).
- Expected: `13 pass · 0 fail`, **exit 0**.
- **Scope:** the suite checks *structural invariants only* (VEILED-C non-conversion, floor non-conflation, TETRA closure, Triad-vs-Tetra discipline, induce-then-relieve netting, the te(a)ch accrual gap). A green run is evidence of internal **coherence**, not of empirical truth; every empirical claim stays CONJECTURE by construction and is out of scope.

---

## Next steps

1. Select a bootstrap proxy for **#U2** (back-test against analog long-lived systems, sub-scale VLSA runs as duration surrogates, or staged coverage).
2. Run a real **≥5-node MIEVM** pass. Clearing mean ≥9.0 is the gate from *10-10 relativity* to a v1.0 empirical verdict.

## Citation

> Sprute, J. A. (2026). *The USC Piece and Its Couplings* (ERES-USC-PIECE-2026-001, v0.5). ERES Institute for New Age Cybernetics. CC BY 4.0.

## Credits

Authored under the ERES *Sentience* convention (originating author J. A. Sprute; drafting assistance by Claude/Anthropic under Sentience, not co-authorship). The te(a)ch reserve reframing was milled as GRIST from a single-node DeepSeek review pass; its closures were held for ensemble adjudication, not adopted.

*Don't hurt yourself. Don't hurt others. Build for generations to come.*
