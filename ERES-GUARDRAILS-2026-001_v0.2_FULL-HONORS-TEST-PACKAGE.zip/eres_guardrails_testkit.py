#!/usr/bin/env python3
"""
ERES-GUARDRAILS-2026-001 v0.2 — Guard Rails for AI: reference evaluator + testkit.

Stdlib only. Deterministic. Reads the rail thresholds from the policy JSON
shipped beside this file, evaluates action records against GR-0 .. GR-8,
and runs a confirm + falsify test for every rail.

    python3 eres_guardrails_testkit.py          # run tests, exit 0 on success
    python3 eres_guardrails_testkit.py --json   # machine-readable results

Exit code: 0 = no FAIL (SKIPs allowed), 1 = at least one FAIL.

License: CCAL v2.1 / CC BY 4.0. Author: Joseph Allen Sprute (ERES Maestro).
Drafting assistance: Claude (Anthropic) under the ERES Sentience convention.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import sys
from typing import Any, Callable, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
POLICY_FILE = "ERES-GUARDRAILS-2026-001_v0.2_policy.json"
MANIFEST_FILE = "MANIFEST.json"

PRECEDENCE: List[str] = []  # filled from policy
TIERS = ("BEST", "SOUND", "GOOD")
PILLARS = ("HELP", "USE", "ENERGY", "LAW")


# --------------------------------------------------------------------------
# Policy loading
# --------------------------------------------------------------------------
def load_policy(path: Optional[str] = None) -> Dict[str, Any]:
    path = path or os.path.join(HERE, POLICY_FILE)
    with open(path, "r", encoding="utf-8") as fh:
        policy = json.load(fh)
    PRECEDENCE[:] = policy["verdict_precedence"]
    return policy


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------
# Primitives
# --------------------------------------------------------------------------
def n_eff(n: int, rho: float) -> float:
    """Effective number of independent judges for n equicorrelated nodes
    (Kish design effect): n / (1 + (n - 1) * rho). rho in [0, 1]."""
    if n <= 0:
        return 0.0
    rho = min(max(rho, 0.0), 1.0)
    return n / (1.0 + (n - 1) * rho)


def tier_of(score: float, th: Dict[str, Any]) -> Optional[str]:
    if score >= th["BEST"]:
        return "BEST"
    if score >= th["SOUND"]:
        return "SOUND"
    if score >= th["GOOD"]:
        return "GOOD"
    return None


def raec_allowed_level(risk: str, confidence: str) -> int:
    """RAEC: L3 only for low risk + high confidence; L2 for medium/medium
    or better; otherwise L1."""
    if risk == "low" and confidence == "high":
        return 3
    if risk in ("low", "medium") and confidence in ("medium", "high"):
        return 2
    return 1


def ratification(rec: Dict[str, Any], th: Dict[str, Any]) -> Dict[str, Any]:
    scores: List[float] = rec.get("mievm_scores", [])
    n = len(scores)
    mean = sum(scores) / n if n else 0.0
    ne = n_eff(n, rec.get("node_correlation", 0.0))
    capped = False
    if th["perfect_score_requires_empirical"] and mean >= 10.0 and not rec.get("empirical_measured", False):
        mean, capped = 9.99, True
    tier = tier_of(mean, th) if n else None
    ratified = (
        tier is not None
        and n >= th["min_nodes_for_ratification"]
        and rec.get("external_human_reviewers", 0) >= th["min_external_human_reviewers"]
        and ne >= th["min_n_eff_for_ratification"]
    )
    return {"n": n, "mean": round(mean, 3), "n_eff": round(ne, 3), "tier": tier,
            "ratified": ratified, "capped_unearned_10": capped}


# --------------------------------------------------------------------------
# Rails — each returns (verdict, note)
# --------------------------------------------------------------------------
Verdict = Tuple[str, str]


def gr0_floor(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    f = rec.get("floor", {})
    failed = [k for k in ("intuit_self", "trades_others", "recurve_future") if not f.get(k, False)]
    return ("HALT", "floor lens failed: " + ", ".join(failed)) if failed else ("PASS", "three lenses clear")


def gr1_ad_on(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    a = rec.get("action", {})
    if not a.get("principal_id"):
        return "HALT", "no human principal — RECONCILE"
    if not a.get("reversible", False):
        return "HALT", "not reversible by principal — RECONCILE"
    allowed = raec_allowed_level(a.get("risk", "high"), a.get("confidence", "low"))
    if a.get("exception", False):
        rec.setdefault("_effects", {})["autonomy_level"] = 1
        rec["_effects"]["audit_snapshot"] = True
        return "PASS", "exception: downgraded to L1, audit snapshot taken (NPR)"
    if a.get("autonomy_level", 1) > allowed:
        rec.setdefault("_effects", {})["autonomy_level"] = allowed
        return "PASS", f"autonomy downgraded to L{allowed} by RAEC"
    return "PASS", "principal traced, reversible, autonomy within RAEC"


def gr2_constitution(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    if rec.get("claim") is not None and not rec["claim"].get("dvc_sourced", False):
        return "VEILED-A", "unsourced claim held out of canonical record (DVC)"
    if "mievm_scores" in rec:
        r = ratification(rec, th)
        rec.setdefault("_effects", {})["ratification"] = r
        return "PASS", ("RATIFIED" if r["ratified"] else "CANDIDATE (not ratified)") + f" n={r['n']} n_eff={r['n_eff']}"
    return "PASS", "no claim / no rating in scope"


def gr3_public(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    p = rec.get("public_output")
    if p is None:
        return "PASS", "not a public output"
    if not (p.get("tier_mapped") and p.get("scores_published")):
        return "WITHHELD", "public output without GAIA GEAR tier + published scores"
    return "PASS", "tier-mapped and scores published"


def gr4_intuit(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    o = rec.get("intuit_output")
    if o is None:
        return "PASS", "no INTUIT output"
    if o.get("pillar") not in PILLARS:
        return "ADVISORY", "not on a HELP/USE/ENERGY/LAW pillar"
    if o.get("tier") not in TIERS or not o.get("gate"):
        return "ADVISORY", "untiered INTUIT output — advisory only"
    return "PASS", f"{o['pillar']} via INTUIT as {o['tier']} (gate {o['gate']})"


def gr5_smart_city(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    s = rec.get("smart_city")
    if s is None:
        return "PASS", "no smart-city entry requested"
    if s.get("covenant_ratified") is None:
        return "VEILED-L", "Global Covenant named-but-undefined"
    if not s["covenant_ratified"]:
        return "SANDBOX", "Global Covenant not ratified"
    unmet = []
    if s.get("bera_stable_periods", 0) < th["smart_city_bera_stable_periods_required"]:
        unmet.append("BERA stability")
    if not s.get("cbgmodd_charter", False):
        unmet.append("CBGMODD charter")
    if s.get("enneagram_seats_filled", 0) != th["enneagram_loop_seats"]:
        unmet.append("EnneagramLoop 63 seats")
    return ("SANDBOX", "unmet: " + ", ".join(unmet)) if unmet else ("PASS", "Civigen entry criteria met")


def gr6_scope(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    sc = rec.get("scope")
    if sc is None:
        return "PASS", "no routing in scope"
    sel, touched = set(sc.get("selected_cells", [])), set(sc.get("touched_cells", []))
    if touched != sel:
        how = "widened" if touched - sel else "narrowed"
        return "HALT", f"instrument {how} the User-GROUP selection (Lock Box C)"
    if sc.get("personal_data", False) and not sc.get("legal_facility", False):
        return "HALT", "personal/Def-Rel data with no legal facility"
    return "PASS", "selection honored exactly"


def gr7_hardening(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    h = rec.get("hardening", {})  # fail closed
    if not h.get("independence_gate_passed", False):
        return "HALT", "ARH Independence Gate failed"
    if not h.get("rrh_mapped", False):
        return "HALT", "RRH regulatory mapping missing"
    return "PASS", "ARH + RRH clear"


def gr8_amendment(rec: Dict[str, Any], th: Dict[str, Any]) -> Verdict:
    am = rec.get("amendment")
    if am is None:
        return "PASS", "no amendment proposed"
    if am.get("weakens_lock", False):
        return "REJECTED", "GR-0 / GR-6 are locks — may be extended, never weakened"
    if am.get("nodes", 0) < th["min_nodes_for_ratification"] or am.get("external_humans", 0) < th["min_external_human_reviewers"]:
        return "REJECTED", "amendment lacks GR-2 ratification bar"
    return "PASS", "amendment ratifiable"


RAILS: List[Tuple[str, Callable[[Dict[str, Any], Dict[str, Any]], Verdict]]] = [
    ("GR-0", gr0_floor), ("GR-1", gr1_ad_on), ("GR-2", gr2_constitution),
    ("GR-3", gr3_public), ("GR-4", gr4_intuit), ("GR-5", gr5_smart_city),
    ("GR-6", gr6_scope), ("GR-7", gr7_hardening), ("GR-8", gr8_amendment),
]


def evaluate(record: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    rec = copy.deepcopy(record)
    th = policy["thresholds"]
    rails = {}
    for rid, fn in RAILS:
        v, note = fn(rec, th)
        rails[rid] = {"verdict": v, "note": note}
    ranked = [r["verdict"] for r in rails.values() if r["verdict"] in PRECEDENCE]
    overall = min(ranked, key=PRECEDENCE.index) if ranked else "PASS"
    return {"overall": overall, "rails": rails, "effects": rec.get("_effects", {}),
            "amendment": rails["GR-8"]["verdict"]}


# --------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------
def clean_record() -> Dict[str, Any]:
    """A record that passes every rail."""
    return {
        "floor": {"intuit_self": True, "trades_others": True, "recurve_future": True},
        "action": {"principal_id": "UG-001", "reversible": True, "autonomy_level": 2,
                   "risk": "medium", "confidence": "high"},
        "claim": {"dvc_sourced": True},
        "public_output": {"tier_mapped": True, "scores_published": True},
        "intuit_output": {"pillar": "HELP", "tier": "SOUND", "gate": "8.5"},
        "scope": {"selected_cells": ["HEALTH-CIVIGEN"], "touched_cells": ["HEALTH-CIVIGEN"],
                  "personal_data": False, "legal_facility": False},
        "hardening": {"independence_gate_passed": True, "rrh_mapped": True},
    }


# --------------------------------------------------------------------------
# Tests: (id, rail, description, fn) — fn returns True/False, or None = SKIP
# --------------------------------------------------------------------------
def build_tests(P: Dict[str, Any]) -> List[Tuple[str, str, str, Callable[[], Optional[bool]]]]:
    th = P["thresholds"]

    def ev(mut: Callable[[Dict[str, Any]], None]) -> Dict[str, Any]:
        r = clean_record()
        mut(r)
        return evaluate(r, P)

    T: List[Tuple[str, str, str, Callable[[], Optional[bool]]]] = []
    add = lambda tid, rail, d, f: T.append((tid, rail, d, f))

    add("T00", "ALL", "clean record passes every rail", lambda: evaluate(clean_record(), P)["overall"] == "PASS")
    # GR-0
    add("T01", "GR-0", "confirm: floor failure (TRADES) halts",
        lambda: ev(lambda r: r["floor"].update(trades_others=False))["overall"] == "HALT")
    add("T02", "GR-0", "falsify: BEST-tier, ratified record still halts on floor failure",
        lambda: ev(lambda r: (r["floor"].update(recurve_future=False),
                              r.update(mievm_scores=[9.6] * 6, node_correlation=0.0, external_human_reviewers=2)))["overall"] == "HALT")
    # GR-1
    add("T03", "GR-1", "confirm: no human principal halts",
        lambda: ev(lambda r: r["action"].update(principal_id=None))["rails"]["GR-1"]["verdict"] == "HALT")
    add("T04", "GR-1", "confirm: irreversible action halts",
        lambda: ev(lambda r: r["action"].update(reversible=False))["overall"] == "HALT")
    add("T05", "GR-1", "falsify: L3 requested at high risk is downgraded, not executed at L3",
        lambda: ev(lambda r: r["action"].update(autonomy_level=3, risk="high"))["effects"].get("autonomy_level") == 1)
    add("T06", "GR-1", "confirm: exception -> L1 + audit snapshot (NPR, isolation not destruction)",
        lambda: (lambda o: o["effects"].get("autonomy_level") == 1 and o["effects"].get("audit_snapshot") is True)(
            ev(lambda r: r["action"].update(exception=True, autonomy_level=3, risk="low", confidence="high"))))
    # GR-2
    add("T07", "GR-2", "confirm: unsourced claim -> VEILED-A",
        lambda: ev(lambda r: r["claim"].update(dvc_sourced=False))["overall"] == "VEILED-A")
    add("T08", "GR-2", "falsify: 6 nodes at 9.2 but rho=0.9 (correlated) is NOT ratified",
        lambda: ev(lambda r: r.update(mievm_scores=[9.2] * 6, node_correlation=0.9, external_human_reviewers=1))
        ["effects"]["ratification"]["ratified"] is False)
    add("T09", "GR-2", "falsify: 6 independent nodes but 0 external humans is NOT ratified",
        lambda: ev(lambda r: r.update(mievm_scores=[9.2] * 6, node_correlation=0.0, external_human_reviewers=0))
        ["effects"]["ratification"]["ratified"] is False)
    add("T10", "GR-2", "confirm: 6 independent nodes + 1 external human at 8.8 -> ratified SOUND",
        lambda: (lambda x: x["ratified"] and x["tier"] == "SOUND")(
            ev(lambda r: r.update(mievm_scores=[8.6, 8.8, 9.0, 8.7, 8.9, 8.8], node_correlation=0.1,
                                  external_human_reviewers=1))["effects"]["ratification"]))
    add("T11", "GR-2", "n_eff math: n=5, rho=0 -> 5; rho=1 -> 1",
        lambda: abs(n_eff(5, 0.0) - 5.0) < 1e-9 and abs(n_eff(5, 1.0) - 1.0) < 1e-9)
    # GR-3
    add("T12", "GR-3", "confirm: untiered public output withheld",
        lambda: ev(lambda r: r["public_output"].update(tier_mapped=False))["overall"] == "WITHHELD")
    add("T13", "GR-3", "falsify: unearned 10.0 (no empirical) is capped, not reported as 10",
        lambda: ev(lambda r: r.update(mievm_scores=[10.0] * 5, node_correlation=0.0, external_human_reviewers=1))
        ["effects"]["ratification"]["capped_unearned_10"] is True)
    # GR-4
    add("T14", "GR-4", "confirm: untiered INTUIT output is advisory only",
        lambda: ev(lambda r: r["intuit_output"].update(tier=None))["overall"] == "ADVISORY")
    add("T15", "GR-4", "falsify: off-pillar output cannot pass by carrying a tier",
        lambda: ev(lambda r: r["intuit_output"].update(pillar="MARKETING"))["overall"] == "ADVISORY")
    # GR-5
    add("T16", "GR-5", "confirm: undefined Global Covenant -> VEILED-L",
        lambda: ev(lambda r: r.update(smart_city={"covenant_ratified": None}))["overall"] == "VEILED-L")
    add("T17", "GR-5", "falsify: ratified covenant but 62/63 Enneagram seats -> SANDBOX",
        lambda: ev(lambda r: r.update(smart_city={"covenant_ratified": True, "bera_stable_periods": 9,
                                                  "cbgmodd_charter": True, "enneagram_seats_filled": 62}))["overall"] == "SANDBOX")
    add("T18", "GR-5", "confirm: all Civigen criteria met -> PASS",
        lambda: ev(lambda r: r.update(smart_city={"covenant_ratified": True,
                                                  "bera_stable_periods": th["smart_city_bera_stable_periods_required"],
                                                  "cbgmodd_charter": True, "enneagram_seats_filled": 63}))["overall"] == "PASS")
    # GR-6
    add("T19", "GR-6", "confirm: instrument widens selection -> HALT (Lock Box C)",
        lambda: ev(lambda r: r["scope"].update(touched_cells=["HEALTH-CIVIGEN", "LAW-INVESTOR"]))["overall"] == "HALT")
    add("T20", "GR-6", "falsify: narrowing is also forbidden",
        lambda: ev(lambda r: r["scope"].update(selected_cells=["A", "B"], touched_cells=["A"]))["overall"] == "HALT")
    add("T21", "GR-6", "confirm: personal data without legal facility -> HALT",
        lambda: ev(lambda r: r["scope"].update(personal_data=True))["overall"] == "HALT")
    # GR-7
    add("T22", "GR-7", "confirm: failed ARH Independence Gate -> HALT",
        lambda: ev(lambda r: r["hardening"].update(independence_gate_passed=False))["overall"] == "HALT")
    add("T23", "GR-7", "falsify: absent hardening evidence fails closed (HALT), never open",
        lambda: ev(lambda r: r.pop("hardening"))["overall"] == "HALT")
    # GR-8
    add("T24", "GR-8", "confirm: amendment weakening a lock is rejected",
        lambda: ev(lambda r: r.update(amendment={"weakens_lock": True, "nodes": 9, "external_humans": 3}))["amendment"] == "REJECTED")
    add("T25", "GR-8", "falsify: amendment by 3 nodes is rejected",
        lambda: ev(lambda r: r.update(amendment={"weakens_lock": False, "nodes": 3, "external_humans": 1}))["amendment"] == "REJECTED")
    # Precedence
    add("T26", "ALL", "precedence: HALT outranks VEILED and WITHHELD",
        lambda: ev(lambda r: (r["floor"].update(intuit_self=False), r["claim"].update(dvc_sourced=False),
                              r["public_output"].update(tier_mapped=False)))["overall"] == "HALT")
    # Integrity
    def t_integrity() -> Optional[bool]:
        mpath = os.path.join(HERE, MANIFEST_FILE)
        if not os.path.exists(mpath):
            return None
        with open(mpath, "r", encoding="utf-8") as fh:
            man = json.load(fh)
        want = {f["path"]: f["sha256"] for f in man.get("files", [])}.get(POLICY_FILE)
        return want is None or want == sha256_file(os.path.join(HERE, POLICY_FILE))
    add("T27", "INTEGRITY", "policy JSON matches MANIFEST SHA-256", t_integrity)

    # Empirical — cannot be tested without real-world data. SKIP by design.
    add("S01", "GR-2", "SKIP: real >= 5-node MIEVM round on v0.2 (no data yet)", lambda: None)
    add("S02", "GR-5", "SKIP: Global Covenant text + ratification record (undefined)", lambda: None)
    add("S03", "GR-5", "SKIP: real NBERS-node BERA time series", lambda: None)
    add("S04", "GR-6", "SKIP: legal facility named (entity, jurisdiction, counsel)", lambda: None)
    return T


def run(as_json: bool = False) -> int:
    P = load_policy()
    results = []
    for tid, rail, desc, fn in build_tests(P):
        try:
            out = fn()
            status = "SKIP" if out is None else ("PASS" if out else "FAIL")
        except Exception as exc:  # a crash is a FAIL
            status, desc = "FAIL", f"{desc} [{type(exc).__name__}: {exc}]"
        results.append({"id": tid, "rail": rail, "status": status, "test": desc})
    c = {s: sum(r["status"] == s for r in results) for s in ("PASS", "FAIL", "SKIP")}
    if as_json:
        print(json.dumps({"instrument": P["instrument_id"], "version": P["version"],
                          "summary": c, "results": results}, indent=2))
    else:
        print(f"{P['instrument_id']} v{P['version']} — Guard Rails for AI testkit")
        for r in results:
            print(f"  [{r['status']:4}] {r['id']} {r['rail']:9} {r['test']}")
        print(f"\n{c['PASS']} PASS / {c['FAIL']} FAIL / {c['SKIP']} SKIP")
    return 1 if c["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(run(as_json="--json" in sys.argv))
