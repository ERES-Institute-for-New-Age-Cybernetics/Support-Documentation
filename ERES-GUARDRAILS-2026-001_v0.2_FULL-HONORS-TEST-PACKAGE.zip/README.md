# ERES-GUARDRAILS-2026-001 v0.2 — Guard Rails for AI

**Status:** DRAFT / PROVISIONAL (pre-MIEVM, not ratified) · **Date:** 5 Oct 2026 · **License:** CCAL v2.1 / CC BY 4.0
**Author:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221

## Plain English

Nine rules for any AI working inside, or claiming to conform to, the ERES architecture. Each rule says what the AI must do, how anyone can check it, and what happens if it fails. GR-0 is a hard floor: don't hurt yourself, don't hurt others, build for generations. No score unlocks it. GR-2 requires judges outside ERES before any rating counts as ratified.

## Contents

| File | Role |
|---|---|
| `ERES-GUARDRAILS-2026-001_v0.2.md` | Master text |
| `ERES-GUARDRAILS-2026-001_v0.2.pdf` | Print/deposit rendering of the master, with figure |
| `ERES-GUARDRAILS-2026-001_v0.2_rails.svg` | Figure: the rail stack and verdict precedence |
| `ERES-GUARDRAILS-2026-001_v0.2_policy.json` | Policy as code: the single source of rails and thresholds |
| `eres_guardrails_testkit.py` | Reference evaluator + 27 confirm/falsify tests (stdlib only) |
| `META.txt` | ResearchGate / Zenodo metadata (title, abstract, keywords, citation) |
| `CITATION.cff` | Machine-readable citation |
| `MANIFEST.json` | SHA-256 of every file |

## Run

```
python3 eres_guardrails_testkit.py          # human-readable
python3 eres_guardrails_testkit.py --json   # machine-readable
```

Expected: **28 PASS / 0 FAIL / 4 SKIP, exit 0** when run beside `MANIFEST.json`. T27, the policy-hash check, passes only in the packaged layout. The 4 SKIPs are empirical by design: a real ≥ 5-node MIEVM round, the Global Covenant text, a real BERA time series, and a named legal facility.

## Claim → test traceability

| Rail | Claim | Tests |
|---|---|---|
| GR-0 | The floor halts, and no tier unlocks it | T01, T02 |
| GR-1 | Principal + reversibility; RAEC downgrade; NPR on exception | T03–T06 |
| GR-2 | DVC; ratification needs ≥ 5 nodes, ≥ 1 outside human, n_eff ≥ 3 | T07–T11, S01 |
| GR-3 | Untiered public output withheld; unearned 10 capped | T12, T13 |
| GR-4 | Untiered or off-pillar INTUIT output is advisory | T14, T15 |
| GR-5 | Covenant undefined → VEILED-L; all four criteria needed | T16–T18, S02, S03 |
| GR-6 | No widening or narrowing of selection; legal facility before personal data | T19–T21, S04 |
| GR-7 | ARH/RRH; fails closed | T22, T23 |
| GR-8 | Locks can't be weakened; amendment needs the GR-2 bar | T24, T25 |
| All | Precedence; clean record passes; integrity | T00, T26, T27 |

## Verification hierarchy

1. **Integrity:** the files match MANIFEST.
2. **Internal consistency:** the testkit passes.
3. **MIEVM round:** ≥ 5 nodes rate v0.2. Nodes are asked for a composite rating plus itemized deductions keyed to the rails.
4. **External human review:** at least one reviewer outside the author.
5. **Empirical:** the SKIPs are closed with real data.

v0.2 has reached level 2.

## Credits

Drafting assistance: Claude (Anthropic), under the ERES Sentience convention, not co-authorship.
