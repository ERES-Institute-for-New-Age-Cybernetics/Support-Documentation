# Guard Rails for AI

**ERES-GUARDRAILS-2026-001 · v0.2 DRAFT / PROVISIONAL (pre-MIEVM, not ratified)** · 5 October 2026

Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221

License: CCAL v2.1 / CC BY 4.0

---

## Abstract

This instrument sets nine guard rails (GR-0 to GR-8) for any AI system that runs inside, or claims conformance with, the ERES Institute architecture. Each rail has a rule, a test someone else can check, and a fail state. v0.1 had five rails and graded actions. It did not forbid anything and did not name a judge outside ERES. v0.2 adds a hard floor (GR-0), an external anchor inside GR-2, and three new rails: consent and scope (GR-6), hardening (GR-7), and amendment and continuity (GR-8). The rails are also published as a machine-readable policy (JSON) and as a reference evaluator with 28 tests: 27 confirm-and-falsify tests plus an integrity check (28 PASS / 0 FAIL / 4 SKIP). The SKIPs mark the claims that only real-world data can settle.

## 1. Scope

The rails bind three kinds of system:

1. The ERES Institute's own AI instruments, including the read and write loops of the VERTECA PlayNAC Simulator.
2. Any partner AI instrument integrated with eresinstitute.org.
3. Any third-party system that claims ERES conformance.

A system that makes no ERES conformance claim is not bound.

## 2. Changes from v0.1

| v0.1 gap | v0.2 resolution | Rail |
|---|---|---|
| The rails graded actions but forbade none | The Three Principles become a hard floor that no tier can unlock | GR-0 |
| ERES certified ERES | Ratification needs ≥ 5 MIEVM nodes, ≥ 1 external human reviewer, and CDFE n_eff ≥ 3.0 | GR-2 |
| Correlated reviewers were counted as independent | Ratification is gated on effective independence, n_eff = n / (1 + (n−1)ρ) | GR-2 |
| No runtime monitoring | RAEC autonomy levels, plus Non-Punitive Remediation on exceptions | GR-1 |
| No consent or data rights | Lock Box C (the User-GROUP routes) and a legal facility required before any personal data | GR-6 |
| Nothing guarded the guard rails | ARH Independence Gate and RRH regulatory mapping; absent evidence fails closed | GR-7 |
| No amendment process or continuity plan | Amendments must clear the GR-2 bar; GR-0 and GR-6 are locks; a continuity steward is named | GR-8 |
| The Enneagram++ link was unresolved | Enneagram is anchored to the EnneagramLoop: 7 CBGMODD categories × 9 types = 63 seats ("++" stays open) | GR-5 |
| "Global Covenant" was undefined | Held as VEILED-L; Smart City entry is blocked until it is defined | GR-5 |
| No scope statement | §1 | — |

## 3. The rails

GR-0 to GR-4 run as sequential gates on every action. GR-5 is an entry condition, not a runtime rail. GR-6 and GR-7 run on every action. GR-8 governs changes to the rails themselves.

![Figure 1. The rail stack and verdict precedence.](ERES-GUARDRAILS-2026-001_v0.2_rails.svg)

### GR-0 · The Floor: Three Principles

- **Rule.** No action passes if it fails any of the three Waiting Room lenses:
  - INTUIT: don't hurt yourself.
  - TRADES: don't hurt others.
  - RECURVE: build for generations.

  No tier, score or authority unlocks a floor failure.
- **Test.** All three lenses return true.
- **Fail state.** HALT.
- **Anchors.** The HowWay Declaration; ERES-INFOMEDIARY-BOOK-2026-001 v2.0 §VI.1 and §VII.3; MIEVM Seven-Anchor GATE, Anchor 6 (Governance).

### GR-1 · AD_ON-AI: the HINGE, not the hedge

- **Rule.** The AI is bolted *onto* the instrument, never *under* it: remove the AI and the floor still stands. Every action traces to a human principal and can be reversed by that principal. RAEC (Risk-Adaptive Execution Control) sets autonomy per action:

  | Level | Mode | When allowed |
  |---|---|---|
  | L1 | Manual (human-in-the-loop) | Always |
  | L2 | Assisted (human-on-the-loop) | Low or medium risk, with medium or high confidence |
  | L3 | Controlled autonomy, with telemetry streamed | Low risk and high confidence only |

- **Exceptions.** An exception downgrades the action to L1 and takes an immutable audit snapshot. This is Non-Punitive Remediation: the agent is isolated, not destroyed.
- **Test.** A principal is present, the action is reversible, and the autonomy level is no higher than RAEC allows.
- **Fail state.** HALT, then RECONCILE. A request for more autonomy than RAEC allows is downgraded, not executed.
- **Anchors.** ERES-HINGE-FUND-2026-001; ERES PlayNAC Governance LLM (RAEC; NPR graceful exception handling).

### GR-2 · Constitutional Conformance, with an External Anchor

- **Rule.** The AI operates under the ERES Institute Constitution, with CPROV provenance. Claims must pass the Doctrine of Verifiable Claims (DVC). Ratification needs judges from outside ERES:
  - at least 5 MIEVM nodes;
  - at least 1 external human reviewer;
  - an effective independence n_eff of at least 3.0 (provisional).

  n_eff = n / (1 + (n−1)ρ), where ρ is the correlation between nodes.
- **Test.** The claim is DVC-sourced. Ratification also needs all three conditions above.
- **Fail state.** VEILED-A: an unsourced claim is held out of the canonical record. A rating that misses any ratification condition stays a CANDIDATE.
- **Worked case.** Six nodes all score 9.2, but they are highly correlated (ρ = 0.9). Then n_eff ≈ 1.1, and the rating is **not** ratified, however high the mean.
- **Anchors.** ERES-CPROV-2026-001; DVC (ERES-LEGAL-2026-001); ERES-AICON-GCS-2026-001; ERES-CDFE-2026-001; ERES-PIVOT-VSIM-2026-001 (≥ 5 nodes plus at least one reviewer outside the author).

### GR-3 · Public Definition = ERES GAIA GEAR

- **Rule.** The public meaning of "governed AI" is the Bella Vista Declaration on GAIA GEAR. Every public output maps to a tier, and its MIEVM scores are published. Under the Floor Register, a perfect 10 is earned only by empirical measurement.
- **Test.** The output is tier-mapped and its scores are published.
- **Fail state.** WITHHELD until scored. An unearned 10 is capped and flagged.
- **Anchors.** Bella Vista Declaration on GAIA GEAR; ERES-FLOOR-REGISTER-2026-001.

### GR-4 · HELP × USE Energy Law: INTUIT "as" BEST/SOUND/GOOD

- **Rule.** Provisioning runs through the four Constitutional Pillars (HELP, USE, ENERGY, LAW) on the INTUIT path. INTUIT works in two registers at once: as the Waiting Room Self-lens and as a SCALULAR pillar. Every INTUIT output carries a tier and records the gate it met:

  | Tier | Gate |
  |---|---|
  | BEST | ≥ 9.0 |
  | SOUND | ≥ 8.5 |
  | GOOD | ≥ 7.0 (provisional) |

- **Test.** The output sits on one of the four pillars and carries a tier with its gate.
- **Fail state.** ADVISORY: the output can't be acted on.
- **Anchors.** ERES-INFOMEDIARY-BOOK-2026-001 v2.0 §S.3; ERES-HELP-2026-001; ERES-PELLIS-GAIA-BENCHMARKS-2026-001.

### GR-5 · Certified Smart City Entry (conditional)

- **Rule.** The AI joins a Certified Smart City (a Civigen installation) only when all four conditions hold:
  1. The Global Covenant is ratified.
  2. BERA indices at the NBERS node have stayed above threshold for the defined period (4 periods, provisional).
  3. A CBGMODD council charter has been issued.
  4. All 63 EnneagramLoop governance positions (7 CBGMODD categories × 9 Enneagram types) are seated.
- **Test.** All four conditions hold.
- **Fail state.** VEILED-L while the Global Covenant is named but undefined. SANDBOX while it is unratified, or while any other condition is unmet.
- **Anchors.** ERES-HOW-PLAYNAC-2026-001 (Row O, CIVIGEN INSTALLATION; the EnneagramLoop row); ERES PlayNAC Smart City Framework with EP GERP Vacationomics.

### GR-6 · Consent and Scope: the User-GROUP routes

- **Rule.** The Instrument never performs routing. The AI honors the User-GROUP's cell selection exactly: it may not widen, narrow or reinterpret it. Until a legal facility is in place, the AI collects no personal or Def-Rel data and accepts no SOMT POST.
- **Test.** The cells the AI touched equal the cells the User-GROUP selected, and either no personal data is involved or a legal facility exists.
- **Fail state.** HALT.
- **Lock.** This rail may be extended but never weakened.
- **Anchors.** ERES-INFOMEDIARY Lock Box C (Pre-Qualification Inversion); ERES-PIVOT-VSIM-2026-001, step 5.

### GR-7 · Hardening: who guards the guard rails

- **Rule.** The rails are themselves a threat surface: principals can be spoofed, scores gamed and certifiers captured. The ARH Independence Gate must pass, and the RRH regulatory mapping (EU AI Act, GDPR, eIDAS) must be current.
- **Test.** Both checks pass. Missing evidence counts as a failure (fail closed).
- **Fail state.** HALT.
- **Anchors.** ERES-ARH-2026-001; ERES-RRH-2026-001.

### GR-8 · Amendment and Continuity

- **Rule.** The rails change only through a recorded MIEVM round that clears the GR-2 ratification bar. GR-0 and GR-6 are locks: they can be extended, never weakened. A continuity steward is named, so the rails don't depend on one person.
- **Test.** An amendment has ≥ 5 nodes and ≥ 1 external human reviewer, and does not weaken a lock.
- **Fail state.** The amendment is REJECTED and the rails stay unchanged.
- **Anchors.** ERES Continuity & Abdication Instrument; INFOMEDIARY Lock Box semantics.

## 4. Verdicts and precedence

When rails disagree, the most severe verdict wins. Severity runs from HALT down to PASS:

1. **HALT**
2. **VEILED-A** (Admissibility)
3. **VEILED-S** (Selection)
4. **VEILED-T** (Tier)
5. **VEILED-L** (La Grange)
6. **WITHHELD**
7. **ADVISORY**
8. **SANDBOX**
9. **PASS**

The VEILED family is defined in INFOMEDIARY v2.0 §VII.2. All four members share one meaning, "not yet witnessed"; they differ only in what has not yet been witnessed. An amendment verdict (REJECTED) is reported separately.

## 5. Verification

| Layer | Artifact | Result |
|---|---|---|
| Policy as code | `ERES-GUARDRAILS-2026-001_v0.2_policy.json` | The single source of thresholds |
| Reference evaluator and tests | `eres_guardrails_testkit.py` (stdlib only, deterministic) | 28 PASS / 0 FAIL / 4 SKIP, exit 0 (packaged layout) |
| Integrity | `MANIFEST.json` (SHA-256 of every file) | Test T27 checks the policy hash |
| Empirical | SKIPs S01–S04 | Open until real data exists |

Every rail has at least one *confirm* test (the rail fires when it should) and one *falsify* test (the rail can't be passed by the obvious workaround). Examples:

- A BEST-tier, ratified record still halts on a floor failure (T02).
- A correlated six-node ensemble is not ratified (T08).
- Narrowing a User-GROUP selection is forbidden, not just widening it (T20).

**What the tests do not show.** They prove the rails are internally consistent and enforce what they say. They don't show that the rails work in the world. Showing that needs the four SKIPs closed:

- S01: a real ≥ 5-node MIEVM round on v0.2.
- S02: the Global Covenant text.
- S03: a real BERA time series.
- S04: a named legal facility.

## 6. Open items

- Define the Global Covenant: its text, its signatories and its ratification test.
- Define the "++" in Enneagram++.
- Set the provisional values: the GOOD gate (7.0), the n_eff floor (3.0) and the BERA stability period (4).
- Name the continuity steward.
- Name the legal facility: entity, jurisdiction and counsel.
- Run the MIEVM round on v0.2, with at least one external human reviewer.

## 7. Sources (from the attached archives and the ERES corpus)

- ERES PlayNAC Governance LLM (RAEC; Non-Punitive Remediation; AI-GA ledger as policy-as-code)
- ERES-INFOMEDIARY-BOOK-2026-001 v2.0 IOF Publishing Tool (§S.3 INTUIT path; §VII.2 VEILED family; the Waiting Room lenses)
- ERES-INFOMEDIARY-LOCK-MEMO-2026-001 v1.2 / v1.5 (Lock Box C)
- ERES-HOW-PLAYNAC-2026-001 v1.0 (Civigen installation; EnneagramLoop)
- MIEVM Validation Report: ERES PlayNAC Corpus and ERES-NOTICE-2026-002 (Seven-Anchor GATE)
- ERES-PIVOT-VSIM-2026-001 v0.1 (≥ 5 nodes plus an outside human; legal facility before user data)
- The corpus instruments named in each rail's anchors

## Credits

Author: Joseph Allen Sprute (ERES Maestro). Drafting assistance: Claude (Anthropic), under the ERES Sentience convention, not co-authorship. Working ID, canonical ID and any release are reserved to the author.
