"""ERES-CDFE-2026-001 v0.2 — demonstrations. Synthetic data.
Proves the ENGINE COMPUTES what was defined; verifies no real claim.
For pass/fail verification run tests.py instead."""

import numpy as np
from favors_cov import FavorsCov

rng = np.random.default_rng(4)
def hr(t): print("\n" + "=" * 66 + "\n" + t + "\n" + "=" * 66)

hr("1. DISCOUNT: three INDEPENDENT procedures vs three NEAR-DUPLICATES")
eng = FavorsCov(theta=2.5, tau_pair=6.0)
for n in range(200):
    for p in "ABC": eng.record(f"h{n}", p, rng.choice([+1, -1]))
    base = rng.choice([+1, -1])
    for p in "DEF": eng.record(f"h{n}", p, base if rng.random() < 0.97 else -base)
for p in "ABC": eng.record("indep_item", p, +1)
for p in "DEF": eng.record("dup_item", p, +1)
print(f"  indep_item  n_eff = {eng.n_eff('indep_item'):.2f} -> {eng.band('indep_item')}")
print(f"  dup_item    n_eff = {eng.n_eff('dup_item'):.2f} -> {eng.band('dup_item')}")

hr("2. REVERSIBILITY: a hidden common mode is discovered; the item FALLS")
eng2 = FavorsCov(theta=2.5, tau_pair=4.0)
for n in range(6):
    for p in "PQR": eng2.record(f"e{n}", p, rng.choice([+1, -1]))
for p in "PQR": eng2.record("claim_X", p, +1)
before, bb = eng2.n_eff("claim_X"), eng2.band("claim_X")
for n in range(400):
    b = rng.choice([+1, -1])
    eng2.record(f"L{n}", "P", b)
    eng2.record(f"L{n}", "Q", b if rng.random() < 0.99 else -b)
    eng2.record(f"L{n}", "R", rng.choice([+1, -1]))
after, ab = eng2.n_eff("claim_X"), eng2.band("claim_X")
print(f"  before: n_eff = {before:.2f} -> {bb}")
print(f"  after:  n_eff = {after:.2f} -> {ab}   ({'DEMOTED' if bb=='FLOOR' and ab!='FLOOR' else 'no change'})")

hr("3. YOUNG vs MATURE: thin history is more conservative")
def neff_at(nh):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(nh):
        for p in "ABC": e.record(f"h{n}", p, rng.choice([+1, -1]))
    for p in "ABC": e.record("item", p, +1)
    return e.n_eff("item")
for N in (2, 8, 40, 300):
    x = neff_at(N)
    print(f"  N={N:>4}  n_eff={x:.2f}  {'FLOOR' if x>=2.5 else 'ASPIRATION'}")

hr("4. AURA IS A POINTER: high salience, zero earned verification")
eng4 = FavorsCov(theta=2.5)
eng4.set_salience("hot_conjecture", 9999)
print(f"  hot_conjecture  aura=9999  n_eff={eng4.n_eff('hot_conjecture'):.2f} -> {eng4.band('hot_conjecture')}")

hr("5. GROUND TRUTH (v0.2): error-covariance separates honest agreement")
# S,T each ~90% accurate with INDEPENDENT errors: they agree often, but only
# because both are usually right. Verdict-cov over-penalizes; error-cov restores.
def st(with_truth):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(300):
        y = rng.choice([+1, -1])
        e.record(f"h{n}", "S", y if rng.random() < 0.9 else -y)
        e.record(f"h{n}", "T", y if rng.random() < 0.9 else -y)
        if with_truth: e.set_truth(f"h{n}", y)
    e.record("item_ST", "S", +1); e.record("item_ST", "T", +1)
    return e.n_eff("item_ST")
print(f"  verdict-only  n_eff = {st(False):.2f}   (agreement read as redundancy)")
print(f"  truth-aware   n_eff = {st(True):.2f}   (independent errors -> credit restored)")

hr("6. HONESTY DIAGNOSTIC (v0.2): where the conservative prior is load-bearing")
eng6 = FavorsCov()
eng6.record("i1", "X", +1); eng6.record("i1", "Y", +1)   # X,Y co-applied
eng6.record("i2", "Z", +1)                                # Z never with X,Y
d = eng6.diagnostics()
print(f"  labeled_fraction = {d['labeled_fraction']}")
print(f"  pairs on prior (independence ASSUMED, not measured): "
      f"{d['pairs_prior_dominated']}/{d['pairs_total']}")
for a, b, ev in d["prior_pairs"]:
    print(f"    ({a},{b}) evidence={ev}  <- co-apply them to earn a measured value")
print()
