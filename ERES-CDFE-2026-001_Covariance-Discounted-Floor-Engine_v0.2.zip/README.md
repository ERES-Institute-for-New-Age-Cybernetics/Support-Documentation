# ERES-CDFE-2026-001 — Covariance-Discounted Floor Engine (v0.2)

**Instrument name:** Covariance-Discounted Floor Engine (CDFE)
**Core quantity:** `n_eff` — the effective-independent verification count
**Status:** v0.2, pre-canonical. Runnable, test-covered. At `x = 0` by its own
Epistemic-Floor standard until a real Biosystem history accumulates. Canonization
gated on MIEVM.

## What it is

A truth axis with resonance walled out by construction. An item's standing is
`n_eff`: the number of *genuinely independent* verification procedures it has
survived, where independence is not asserted but **measured** as the accumulated
covariance across the FAVORS Biosystem's verification history.

- **x (abscissa)** = `n_eff`, effective-independent procedures survived.
- **Credit** = position on x. Earned only by surviving procedures; resonance buys zero.
- **EarnedPath** = the threshold `theta`. Cross it and an item promotes into the Floor.
- **Floor / Aspiration / Resonance** are x-bands: promoted / rising / off-axis.
- **Aura** = a pointer (salience) that flags where to look. It never enters `n_eff`.

`n_eff` uses the Galwey (2009) effective-number-of-independent-tests estimator on
the correlation eigenspectrum of the procedures that passed an item:
`M_eff = (Σ sqrt(λ_i))² / Σ λ_i` — 1 when the passing procedures are perfectly
correlated, equal to the raw count when mutually independent.

## What changed in v0.2 (cross-model review closed three weaknesses)

1. **Ground-truth-aware error covariance.** What matters is whether procedures
   *make correlated errors* (fail together), not whether their verdicts merely
   co-move. Where an item's outcome is known (`set_truth`), the pair correlation
   is computed from **error** indicators; where unknown, it falls back to verdict
   co-movement — the proxy, explicitly down-weighted. This lets the engine tell
   *honest agreement* (procedures that agree because both are right) from *shared
   error* (procedures that agree because they share a blind spot). Demo 5:
   verdict-only reads two independent-but-agreeing procedures as redundant
   (`n_eff 1.75`); ground truth restores the credit (`1.99`).

2. **Per-pair overlap-confidence shrinkage.** The old code applied one global
   shrink and silently assumed near-total correlation for any never-co-applied
   pair. Now each pair is shrunk toward the conservative prior in proportion to
   *its own* evidence, and `diagnostics()` **names** every pair whose independence
   is assumed rather than measured. The prior is now visible, not hidden — and the
   fix is concrete: co-apply the two procedures on shared items to earn a measured
   value. A single shared item is deliberately not enough (≥2 to estimate a
   correlation).

3. **Assertion test suite (`tests.py`).** Independent verification is now running
   one file, not trusting a printed log. Eight invariants; exits non-zero on any
   failure.

## Verify it yourself

    python3 tests.py     # 8 assertions, exits 0 only if all pass
    python3 demo.py      # narrated walkthrough (output in demo_output.txt)

## Honest scope — still load-bearing

- Ground truth is **partial and itself fallible**; unlabeled items still run on
  the verdict proxy. Every `n_eff` remains an **upper bound**, tightening as
  labeled history accumulates.
- A green test run demonstrates the **mechanism computes as specified**. It
  certifies no claim true. "Floor" means *survived the most independent tests we
  could construct and no shared channel found yet* — never *true*.
- The conservative prior for unknown pairs is a deliberate choice, not a theorem:
  it under-credits rather than over-credits. `diagnostics()` exposes exactly where
  it is doing the work so the tradeoff is auditable.

## Files
- `favors_cov.py` — the engine (intake, ground-truth-aware covariance, `n_eff`,
  bands, per-pair shrinkage, `diagnostics`, `recompute`).
- `tests.py` — eight-invariant assertion suite.
- `demo.py` — six narrated demonstrations.
- `demo_output.txt` — captured run.

## Provenance
Derived across an epistemic construction at the ERES Institute for New Age
Cybernetics. Names — CDFE, `n_eff`, EarnedPath — are proposed and bind drafting
immediately; canonical adoption is by ERES register cut.
