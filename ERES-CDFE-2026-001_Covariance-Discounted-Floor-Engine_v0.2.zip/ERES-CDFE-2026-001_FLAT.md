# ERES-CDFE-2026-001 v0.2 — Covariance-Discounted Floor Engine
# FLAT TRANSMISSION BUNDLE (single plaintext file; paste into any LLM).
# Files inline: README.md, favors_cov.py, tests.py, tests_output.txt, demo.py, demo_output.txt

================================================================
FILE 1/6 — README.md
================================================================
# ERES-CDFE-2026-001 — Covariance-Discounted Floor Engine (v0.2)

**Instrument name:** Covariance-Discounted Floor Engine (CDFE)
**Core quantity:** `n_eff` — the effective-independent verification count
**Status:** v0.2, pre-canonical. Runnable, test-covered. At `x = 0` by its own
Epistemic-Floor standard until a real Biosystem history accumulates. Canonization
gated on MIEVM.

## What it is

A truth axis with resonance walled out by construction. An item's standing is
`n_eff`: the number of *genuinely independent* verification procedures it has
survived, where independence is not asserted but **measured** as the accumulated
covariance across the FAVORS Biosystem's verification history.

- **x (abscissa)** = `n_eff`, effective-independent procedures survived.
- **Credit** = position on x. Earned only by surviving procedures; resonance buys zero.
- **EarnedPath** = the threshold `theta`. Cross it and an item promotes into the Floor.
- **Floor / Aspiration / Resonance** are x-bands: promoted / rising / off-axis.
- **Aura** = a pointer (salience) that flags where to look. It never enters `n_eff`.

`n_eff` uses the Galwey (2009) effective-number-of-independent-tests estimator on
the correlation eigenspectrum of the procedures that passed an item:
`M_eff = (Σ sqrt(λ_i))² / Σ λ_i` — 1 when the passing procedures are perfectly
correlated, equal to the raw count when mutually independent.

## What changed in v0.2 (cross-model review closed three weaknesses)

1. **Ground-truth-aware error covariance.** What matters is whether procedures
   *make correlated errors* (fail together), not whether their verdicts merely
   co-move. Where an item's outcome is known (`set_truth`), the pair correlation
   is computed from **error** indicators; where unknown, it falls back to verdict
   co-movement — the proxy, explicitly down-weighted. This lets the engine tell
   *honest agreement* (procedures that agree because both are right) from *shared
   error* (procedures that agree because they share a blind spot). Demo 5:
   verdict-only reads two independent-but-agreeing procedures as redundant
   (`n_eff 1.75`); ground truth restores the credit (`1.99`).

2. **Per-pair overlap-confidence shrinkage.** The old code applied one global
   shrink and silently assumed near-total correlation for any never-co-applied
   pair. Now each pair is shrunk toward the conservative prior in proportion to
   *its own* evidence, and `diagnostics()` **names** every pair whose independence
   is assumed rather than measured. The prior is now visible, not hidden — and the
   fix is concrete: co-apply the two procedures on shared items to earn a measured
   value. A single shared item is deliberately not enough (≥2 to estimate a
   correlation).

3. **Assertion test suite (`tests.py`).** Independent verification is now running
   one file, not trusting a printed log. Eight invariants; exits non-zero on any
   failure.

## Verify it yourself

    python3 tests.py     # 8 assertions, exits 0 only if all pass
    python3 demo.py      # narrated walkthrough (output in demo_output.txt)

## Honest scope — still load-bearing

- Ground truth is **partial and itself fallible**; unlabeled items still run on
  the verdict proxy. Every `n_eff` remains an **upper bound**, tightening as
  labeled history accumulates.
- A green test run demonstrates the **mechanism computes as specified**. It
  certifies no claim true. "Floor" means *survived the most independent tests we
  could construct and no shared channel found yet* — never *true*.
- The conservative prior for unknown pairs is a deliberate choice, not a theorem:
  it under-credits rather than over-credits. `diagnostics()` exposes exactly where
  it is doing the work so the tradeoff is auditable.

## Files
- `favors_cov.py` — the engine (intake, ground-truth-aware covariance, `n_eff`,
  bands, per-pair shrinkage, `diagnostics`, `recompute`).
- `tests.py` — eight-invariant assertion suite.
- `demo.py` — six narrated demonstrations.
- `demo_output.txt` — captured run.

## Provenance
Derived across an epistemic construction at the ERES Institute for New Age
Cybernetics. Names — CDFE, `n_eff`, EarnedPath — are proposed and bind drafting
immediately; canonical adoption is by ERES register cut.


================================================================
FILE 2/6 — favors_cov.py   (the engine)
================================================================
```python
"""
ERES-CDFE-2026-001 — Covariance-Discounted Floor Engine  (v0.2)
Core quantity: n_eff, the effective-independent verification count.

v0.2 changes, addressing the three open weaknesses from cross-model review:

  (1) GROUND-TRUTH-AWARE COVARIANCE. What matters for independence is whether
      procedures make CORRELATED ERRORS (fail together), not whether their
      verdicts merely co-move. Where an item's true outcome is known, the pair
      correlation is computed from ERROR indicators; where it is unknown, it
      falls back to verdict co-movement (the proxy). The two are blended by how
      much evidence of each kind exists, and verdict-covariance is explicitly
      down-weighted as the weaker signal. This narrows the proxy gap wherever
      labels exist — it does not close it for unlabeled regions.

  (2) PER-PAIR OVERLAP-CONFIDENCE SHRINKAGE. The old code applied one global
      shrink and silently assumed near-total correlation for any pair that had
      never been co-applied. Now each pair is shrunk toward the conservative
      prior in proportion to how thin ITS OWN evidence is. A pair richly
      co-observed as independent keeps its measured value; a pair with no shared
      history sits on the prior — and diagnostics() names exactly which pairs are
      prior-dominated, so the reviewer sees where the assumption is load-bearing.
      The escape is concrete: to promote a pair from assumed-correlated to
      measured-independent, co-apply the two procedures on shared items.

  (3) An assertion test suite (tests.py) so independent verification is a matter
      of RUNNING the code, not trusting a printed log.

HONEST SCOPE (unchanged, and still load-bearing):
  * Even with labels, ground truth is partial and itself fallible. Unlabeled
    items still run on the verdict proxy. Every n_eff remains an UPPER BOUND on
    true effective independence, tightening as labeled history accumulates.
  * A green test run demonstrates the MECHANISM computes as specified. It
    certifies no real-world claim true.
"""

import numpy as np


class FavorsCov:
    def __init__(self, theta=2.5, tau_pair=6.0, rho_conservative=0.95,
                 proxy_weight=0.5):
        # theta:            EarnedPath promotion threshold on n_eff
        # tau_pair:         per-pair evidence at which shrink weight = 1/2
        # rho_conservative: prior correlation for pairs with thin/no evidence
        #                   ("assume correlated until proven independent")
        # proxy_weight:     how much a unit of VERDICT evidence counts relative
        #                   to a unit of ERROR (ground-truth) evidence, in (0,1].
        #                   < 1 because verdict co-movement is the weaker proxy.
        self.theta = theta
        self.tau_pair = tau_pair
        self.rho_conservative = rho_conservative
        self.proxy_weight = proxy_weight
        self.procedures = []
        self.items = {}        # item -> {proc: +1 pass / -1 fail}
        self.truth = {}        # item -> +1 true / -1 false   (partial, optional)
        self.salience = {}     # item -> aura pointer (NON-WARRANT)

    # ---- intake ---------------------------------------------------------
    def add_procedure(self, name):
        if name not in self.procedures:
            self.procedures.append(name)

    def record(self, item, proc, verdict):
        self.add_procedure(proc)
        self.items.setdefault(item, {})[proc] = int(verdict)

    def set_truth(self, item, y):
        """Ground-truth outcome for an item: +1 true, -1 false. Optional/partial.
        Enables ERROR-covariance on the items that have it."""
        self.truth[item] = int(y)

    def set_salience(self, item, value):
        self.salience[item] = float(value)   # aura: points, never promotes

    # ---- pairwise correlation ------------------------------------------
    @staticmethod
    def _corr(x, y):
        """Pearson r and usable-sample-size; (0.0, 0) when degenerate."""
        if len(x) >= 2 and x.std() > 0 and y.std() > 0:
            return float(np.corrcoef(x, y)[0, 1]), len(x)
        return 0.0, 0

    def _pair(self, a, b):
        """Blended, shrunk correlation for one procedure pair, plus its evidence.
        Error correlation (from labeled items) is the real signal; verdict
        correlation (from all co-applied items) is the down-weighted proxy."""
        va, vb, ea, eb = [], [], [], []
        for item, verds in self.items.items():
            if a in verds and b in verds:
                va.append(verds[a]); vb.append(verds[b])
                if item in self.truth:
                    y = self.truth[item]
                    ea.append(0 if verds[a] == y else 1)
                    eb.append(0 if verds[b] == y else 1)
        r_ver, n_ver = self._corr(np.array(va, float), np.array(vb, float))
        r_err, n_err = self._corr(np.array(ea, float), np.array(eb, float))

        w_err = n_err                         # full weight: the signal we want
        w_ver = self.proxy_weight * n_ver     # discounted: the proxy
        if w_err + w_ver == 0:
            return self.rho_conservative, 0.0  # no usable data -> conservative
        r_obs = (w_err * r_err + w_ver * r_ver) / (w_err + w_ver)
        evidence = w_err + w_ver
        alpha = self.tau_pair / (self.tau_pair + evidence)  # ->1 thin, ->0 rich
        r = (1 - alpha) * r_obs + alpha * self.rho_conservative
        return float(np.clip(r, -1, 1)), float(evidence)

    def _correlation(self):
        P = self.procedures
        k = len(P)
        R = np.eye(k)
        E = np.zeros((k, k))
        for i in range(k):
            for j in range(i + 1, k):
                r, e = self._pair(P[i], P[j])
                R[i, j] = R[j, i] = r
                E[i, j] = E[j, i] = e
        return _nearest_psd(R), P, E

    # ---- the quantity: n_eff -------------------------------------------
    def n_eff(self, item):
        """Galwey (2009) effective number of independent tests from the
        correlation eigenspectrum of the procedures that PASSED this item:
            M_eff = (sum sqrt(lambda_i))^2 / sum(lambda_i)."""
        R, P, _ = self._correlation()
        passing = [p for p, v in self.items.get(item, {}).items() if v == +1]
        if not passing:
            return 0.0
        idx = [P.index(p) for p in passing]
        lam = np.clip(np.linalg.eigvalsh(R[np.ix_(idx, idx)]), 0, None)
        s = lam.sum()
        return float((np.sqrt(lam).sum() ** 2) / s) if s > 0 else 0.0

    def band(self, item):
        x = self.n_eff(item)
        if x >= self.theta:
            return "FLOOR"
        if x > 0:
            return "ASPIRATION"
        return "RESONANCE/OFF-AXIS"

    # ---- diagnostics ----------------------------------------------------
    def diagnostics(self, prior_evidence_floor=1.0):
        """Surface where the conservative prior is doing the work. Any pair whose
        evidence is below prior_evidence_floor is 'prior-dominated' — its
        independence is ASSUMED, not measured. Co-apply that pair to fix it."""
        _, P, E = self._correlation()
        prior_pairs = []
        for i in range(len(P)):
            for j in range(i + 1, len(P)):
                if E[i, j] < prior_evidence_floor:
                    prior_pairs.append((P[i], P[j], round(float(E[i, j]), 2)))
        n_pairs = len(P) * (len(P) - 1) // 2
        labeled = sum(1 for it in self.items if it in self.truth)
        return {
            "n_items": len(self.items),
            "labeled_items": labeled,
            "labeled_fraction": round(labeled / len(self.items), 3) if self.items else 0.0,
            "pairs_total": n_pairs,
            "pairs_prior_dominated": len(prior_pairs),
            "prior_pairs": prior_pairs,
        }

    def recompute(self):
        d = self.diagnostics()
        return {
            "labeled_fraction": d["labeled_fraction"],
            "pairs_prior_dominated": f"{d['pairs_prior_dominated']}/{d['pairs_total']}",
            "items": {it: {"n_eff": round(self.n_eff(it), 3), "band": self.band(it),
                           "aura": self.salience.get(it, 0.0)}
                      for it in sorted(self.items)},
        }


def _nearest_psd(A):
    """Project a symmetric matrix to the nearest PSD correlation matrix."""
    B = (A + A.T) / 2
    w, V = np.linalg.eigh(B)
    B = (V * np.clip(w, 0, None)) @ V.T
    d = np.sqrt(np.clip(np.diag(B), 1e-12, None))
    B = B / np.outer(d, d)
    np.fill_diagonal(B, 1.0)
    return B

```

================================================================
FILE 3/6 — tests.py   (8-invariant assertion suite; run to verify)
================================================================
```python
"""Assertion suite for ERES-CDFE-2026-001 v0.2.
Run this to VERIFY the mechanism yourself: `python3 tests.py`.
Exits non-zero if any invariant fails. Independent verification = running it,
not trusting a printed log."""

import sys
import numpy as np
from favors_cov import FavorsCov

rng = np.random.default_rng(4)
PASS, FAIL = [], []

def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))


# --- Invariant 1: discount, not tally ---------------------------------------
eng = FavorsCov(theta=2.5, tau_pair=6.0)
for n in range(200):
    for p in "ABC": eng.record(f"h{n}", p, rng.choice([+1, -1]))
    base = rng.choice([+1, -1])
    for p in "DEF": eng.record(f"h{n}", p, base if rng.random() < 0.97 else -base)
for p in "ABC": eng.record("indep_item", p, +1)
for p in "DEF": eng.record("dup_item", p, +1)
xi, xd = eng.n_eff("indep_item"), eng.n_eff("dup_item")
check("independent trio ~ 3 and promotes", xi >= 2.7 and eng.band("indep_item") == "FLOOR", f"n_eff={xi:.2f}")
check("near-duplicate trio ~ 1-2 and stays out", xd < 2.5 and eng.band("dup_item") != "FLOOR", f"n_eff={xd:.2f}")


# --- Invariant 2: reversibility on discovered common mode -------------------
eng2 = FavorsCov(theta=2.5, tau_pair=4.0)
for n in range(6):
    for p in "PQR": eng2.record(f"e{n}", p, rng.choice([+1, -1]))
for p in "PQR": eng2.record("claim_X", p, +1)
before, bb = eng2.n_eff("claim_X"), eng2.band("claim_X")
for n in range(400):
    b = rng.choice([+1, -1])
    eng2.record(f"L{n}", "P", b)
    eng2.record(f"L{n}", "Q", b if rng.random() < 0.99 else -b)
    eng2.record(f"L{n}", "R", rng.choice([+1, -1]))
after, ab = eng2.n_eff("claim_X"), eng2.band("claim_X")
check("common mode found -> n_eff falls", after < before, f"{before:.2f}->{after:.2f}")
check("fall crosses threshold -> demotion", bb == "FLOOR" and ab != "FLOOR", f"{bb}->{ab}")


# --- Invariant 3: young history is more conservative -----------------------
def neff_at(nh):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(nh):
        for p in "ABC": e.record(f"h{n}", p, rng.choice([+1, -1]))
    for p in "ABC": e.record("item", p, +1)
    return e.n_eff("item")
young, mature = neff_at(2), neff_at(300)
check("young n_eff <= mature n_eff", young <= mature + 1e-9, f"N2={young:.2f} N300={mature:.2f}")


# --- Invariant 4: aura never promotes --------------------------------------
eng4 = FavorsCov(theta=2.5)
eng4.set_salience("hot", 9999)
check("salience 9999 stays off-axis", eng4.n_eff("hot") == 0.0 and eng4.band("hot") == "RESONANCE/OFF-AXIS")


# --- Invariant 5 (NEW): error covariance separates honest agreement from
# shared error. Two procedures S,T are each ~90% accurate with INDEPENDENT
# errors. They agree often -- but only because both are usually right, not
# because they share a blind spot. Verdict-covariance sees the agreement and
# wrongly discounts them as redundant; ground-truth error-covariance reveals
# their errors are uncorrelated and RESTORES the independence credit.
def build(with_truth):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(300):
        y = rng.choice([+1, -1])
        s = y if rng.random() < 0.9 else -y
        t = y if rng.random() < 0.9 else -y   # errors independent of S's
        e.record(f"h{n}", "S", s); e.record(f"h{n}", "T", t)
        if with_truth:
            e.set_truth(f"h{n}", y)
    e.record("item_ST", "S", +1); e.record("item_ST", "T", +1)
    return e.n_eff("item_ST")
blind = build(with_truth=False)   # verdict-only: conflates agreement with redundancy
seeing = build(with_truth=True)   # truth-aware: sees errors are independent
check("error-cov restores credit verdict-cov wrongly discounted",
      seeing > blind + 0.1, f"verdict-only={blind:.2f}  truth-aware={seeing:.2f}")


# --- Invariant 6 (NEW): prior-dominated pairs are named, not hidden --------
eng6 = FavorsCov()
eng6.record("i1", "X", +1); eng6.record("i1", "Y", +1)   # X,Y co-applied once
eng6.record("i2", "Z", +1)                                # Z never with X or Y
d = eng6.diagnostics()
prior_set = {frozenset((a, b)) for a, b, _ in d["prior_pairs"]}
check("no-shared-history pairs flagged prior-dominated",
      frozenset(("X", "Z")) in prior_set and frozenset(("Y", "Z")) in prior_set,
      f"{d['pairs_prior_dominated']}/{d['pairs_total']} on prior")


print("\n" + "=" * 60)
print(f"RESULT: {len(PASS)} passed, {len(FAIL)} failed")
print("=" * 60)
sys.exit(1 if FAIL else 0)

```

================================================================
FILE 4/6 — tests_output.txt   (captured PASS/FAIL run)
================================================================
  [PASS] independent trio ~ 3 and promotes  (n_eff=2.97)
  [PASS] near-duplicate trio ~ 1-2 and stays out  (n_eff=1.94)
  [PASS] common mode found -> n_eff falls  (2.71->2.25)
  [PASS] fall crosses threshold -> demotion  (FLOOR->ASPIRATION)
  [PASS] young n_eff <= mature n_eff  (N2=1.63 N300=3.00)
  [PASS] salience 9999 stays off-axis
  [PASS] error-cov restores credit verdict-cov wrongly discounted  (verdict-only=1.77  truth-aware=1.99)
  [PASS] no-shared-history pairs flagged prior-dominated  (3/3 on prior)

============================================================
RESULT: 8 passed, 0 failed
============================================================


================================================================
FILE 5/6 — demo.py   (six narrated demonstrations)
================================================================
```python
"""ERES-CDFE-2026-001 v0.2 — demonstrations. Synthetic data.
Proves the ENGINE COMPUTES what was defined; verifies no real claim.
For pass/fail verification run tests.py instead."""

import numpy as np
from favors_cov import FavorsCov

rng = np.random.default_rng(4)
def hr(t): print("\n" + "=" * 66 + "\n" + t + "\n" + "=" * 66)

hr("1. DISCOUNT: three INDEPENDENT procedures vs three NEAR-DUPLICATES")
eng = FavorsCov(theta=2.5, tau_pair=6.0)
for n in range(200):
    for p in "ABC": eng.record(f"h{n}", p, rng.choice([+1, -1]))
    base = rng.choice([+1, -1])
    for p in "DEF": eng.record(f"h{n}", p, base if rng.random() < 0.97 else -base)
for p in "ABC": eng.record("indep_item", p, +1)
for p in "DEF": eng.record("dup_item", p, +1)
print(f"  indep_item  n_eff = {eng.n_eff('indep_item'):.2f} -> {eng.band('indep_item')}")
print(f"  dup_item    n_eff = {eng.n_eff('dup_item'):.2f} -> {eng.band('dup_item')}")

hr("2. REVERSIBILITY: a hidden common mode is discovered; the item FALLS")
eng2 = FavorsCov(theta=2.5, tau_pair=4.0)
for n in range(6):
    for p in "PQR": eng2.record(f"e{n}", p, rng.choice([+1, -1]))
for p in "PQR": eng2.record("claim_X", p, +1)
before, bb = eng2.n_eff("claim_X"), eng2.band("claim_X")
for n in range(400):
    b = rng.choice([+1, -1])
    eng2.record(f"L{n}", "P", b)
    eng2.record(f"L{n}", "Q", b if rng.random() < 0.99 else -b)
    eng2.record(f"L{n}", "R", rng.choice([+1, -1]))
after, ab = eng2.n_eff("claim_X"), eng2.band("claim_X")
print(f"  before: n_eff = {before:.2f} -> {bb}")
print(f"  after:  n_eff = {after:.2f} -> {ab}   ({'DEMOTED' if bb=='FLOOR' and ab!='FLOOR' else 'no change'})")

hr("3. YOUNG vs MATURE: thin history is more conservative")
def neff_at(nh):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(nh):
        for p in "ABC": e.record(f"h{n}", p, rng.choice([+1, -1]))
    for p in "ABC": e.record("item", p, +1)
    return e.n_eff("item")
for N in (2, 8, 40, 300):
    x = neff_at(N)
    print(f"  N={N:>4}  n_eff={x:.2f}  {'FLOOR' if x>=2.5 else 'ASPIRATION'}")

hr("4. AURA IS A POINTER: high salience, zero earned verification")
eng4 = FavorsCov(theta=2.5)
eng4.set_salience("hot_conjecture", 9999)
print(f"  hot_conjecture  aura=9999  n_eff={eng4.n_eff('hot_conjecture'):.2f} -> {eng4.band('hot_conjecture')}")

hr("5. GROUND TRUTH (v0.2): error-covariance separates honest agreement")
# S,T each ~90% accurate with INDEPENDENT errors: they agree often, but only
# because both are usually right. Verdict-cov over-penalizes; error-cov restores.
def st(with_truth):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(300):
        y = rng.choice([+1, -1])
        e.record(f"h{n}", "S", y if rng.random() < 0.9 else -y)
        e.record(f"h{n}", "T", y if rng.random() < 0.9 else -y)
        if with_truth: e.set_truth(f"h{n}", y)
    e.record("item_ST", "S", +1); e.record("item_ST", "T", +1)
    return e.n_eff("item_ST")
print(f"  verdict-only  n_eff = {st(False):.2f}   (agreement read as redundancy)")
print(f"  truth-aware   n_eff = {st(True):.2f}   (independent errors -> credit restored)")

hr("6. HONESTY DIAGNOSTIC (v0.2): where the conservative prior is load-bearing")
eng6 = FavorsCov()
eng6.record("i1", "X", +1); eng6.record("i1", "Y", +1)   # X,Y co-applied
eng6.record("i2", "Z", +1)                                # Z never with X,Y
d = eng6.diagnostics()
print(f"  labeled_fraction = {d['labeled_fraction']}")
print(f"  pairs on prior (independence ASSUMED, not measured): "
      f"{d['pairs_prior_dominated']}/{d['pairs_total']}")
for a, b, ev in d["prior_pairs"]:
    print(f"    ({a},{b}) evidence={ev}  <- co-apply them to earn a measured value")
print()

```

================================================================
FILE 6/6 — demo_output.txt   (captured demo run)
================================================================

==================================================================
1. DISCOUNT: three INDEPENDENT procedures vs three NEAR-DUPLICATES
==================================================================
  indep_item  n_eff = 2.97 -> FLOOR
  dup_item    n_eff = 1.94 -> ASPIRATION

==================================================================
2. REVERSIBILITY: a hidden common mode is discovered; the item FALLS
==================================================================
  before: n_eff = 2.71 -> FLOOR
  after:  n_eff = 2.25 -> ASPIRATION   (DEMOTED)

==================================================================
3. YOUNG vs MATURE: thin history is more conservative
==================================================================
  N=   2  n_eff=1.63  ASPIRATION
  N=   8  n_eff=2.45  ASPIRATION
  N=  40  n_eff=2.96  FLOOR
  N= 300  n_eff=2.99  FLOOR

==================================================================
4. AURA IS A POINTER: high salience, zero earned verification
==================================================================
  hot_conjecture  aura=9999  n_eff=0.00 -> RESONANCE/OFF-AXIS

==================================================================
5. GROUND TRUTH (v0.2): error-covariance separates honest agreement
==================================================================
  verdict-only  n_eff = 1.75   (agreement read as redundancy)
  truth-aware   n_eff = 1.99   (independent errors -> credit restored)

==================================================================
6. HONESTY DIAGNOSTIC (v0.2): where the conservative prior is load-bearing
==================================================================
  labeled_fraction = 0.0
  pairs on prior (independence ASSUMED, not measured): 3/3
    (X,Y) evidence=0.0  <- co-apply them to earn a measured value
    (X,Z) evidence=0.0  <- co-apply them to earn a measured value
    (Y,Z) evidence=0.0  <- co-apply them to earn a measured value


