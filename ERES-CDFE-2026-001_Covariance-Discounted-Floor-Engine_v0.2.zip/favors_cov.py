"""
ERES-CDFE-2026-001 — Covariance-Discounted Floor Engine  (v0.2)
Core quantity: n_eff, the effective-independent verification count.

v0.2 changes, addressing the three open weaknesses from cross-model review:

  (1) GROUND-TRUTH-AWARE COVARIANCE. What matters for independence is whether
      procedures make CORRELATED ERRORS (fail together), not whether their
      verdicts merely co-move. Where an item's true outcome is known, the pair
      correlation is computed from ERROR indicators; where it is unknown, it
      falls back to verdict co-movement (the proxy). The two are blended by how
      much evidence of each kind exists, and verdict-covariance is explicitly
      down-weighted as the weaker signal. This narrows the proxy gap wherever
      labels exist — it does not close it for unlabeled regions.

  (2) PER-PAIR OVERLAP-CONFIDENCE SHRINKAGE. The old code applied one global
      shrink and silently assumed near-total correlation for any pair that had
      never been co-applied. Now each pair is shrunk toward the conservative
      prior in proportion to how thin ITS OWN evidence is. A pair richly
      co-observed as independent keeps its measured value; a pair with no shared
      history sits on the prior — and diagnostics() names exactly which pairs are
      prior-dominated, so the reviewer sees where the assumption is load-bearing.
      The escape is concrete: to promote a pair from assumed-correlated to
      measured-independent, co-apply the two procedures on shared items.

  (3) An assertion test suite (tests.py) so independent verification is a matter
      of RUNNING the code, not trusting a printed log.

HONEST SCOPE (unchanged, and still load-bearing):
  * Even with labels, ground truth is partial and itself fallible. Unlabeled
    items still run on the verdict proxy. Every n_eff remains an UPPER BOUND on
    true effective independence, tightening as labeled history accumulates.
  * A green test run demonstrates the MECHANISM computes as specified. It
    certifies no real-world claim true.
"""

import numpy as np


class FavorsCov:
    def __init__(self, theta=2.5, tau_pair=6.0, rho_conservative=0.95,
                 proxy_weight=0.5):
        # theta:            EarnedPath promotion threshold on n_eff
        # tau_pair:         per-pair evidence at which shrink weight = 1/2
        # rho_conservative: prior correlation for pairs with thin/no evidence
        #                   ("assume correlated until proven independent")
        # proxy_weight:     how much a unit of VERDICT evidence counts relative
        #                   to a unit of ERROR (ground-truth) evidence, in (0,1].
        #                   < 1 because verdict co-movement is the weaker proxy.
        self.theta = theta
        self.tau_pair = tau_pair
        self.rho_conservative = rho_conservative
        self.proxy_weight = proxy_weight
        self.procedures = []
        self.items = {}        # item -> {proc: +1 pass / -1 fail}
        self.truth = {}        # item -> +1 true / -1 false   (partial, optional)
        self.salience = {}     # item -> aura pointer (NON-WARRANT)

    # ---- intake ---------------------------------------------------------
    def add_procedure(self, name):
        if name not in self.procedures:
            self.procedures.append(name)

    def record(self, item, proc, verdict):
        self.add_procedure(proc)
        self.items.setdefault(item, {})[proc] = int(verdict)

    def set_truth(self, item, y):
        """Ground-truth outcome for an item: +1 true, -1 false. Optional/partial.
        Enables ERROR-covariance on the items that have it."""
        self.truth[item] = int(y)

    def set_salience(self, item, value):
        self.salience[item] = float(value)   # aura: points, never promotes

    # ---- pairwise correlation ------------------------------------------
    @staticmethod
    def _corr(x, y):
        """Pearson r and usable-sample-size; (0.0, 0) when degenerate."""
        if len(x) >= 2 and x.std() > 0 and y.std() > 0:
            return float(np.corrcoef(x, y)[0, 1]), len(x)
        return 0.0, 0

    def _pair(self, a, b):
        """Blended, shrunk correlation for one procedure pair, plus its evidence.
        Error correlation (from labeled items) is the real signal; verdict
        correlation (from all co-applied items) is the down-weighted proxy."""
        va, vb, ea, eb = [], [], [], []
        for item, verds in self.items.items():
            if a in verds and b in verds:
                va.append(verds[a]); vb.append(verds[b])
                if item in self.truth:
                    y = self.truth[item]
                    ea.append(0 if verds[a] == y else 1)
                    eb.append(0 if verds[b] == y else 1)
        r_ver, n_ver = self._corr(np.array(va, float), np.array(vb, float))
        r_err, n_err = self._corr(np.array(ea, float), np.array(eb, float))

        w_err = n_err                         # full weight: the signal we want
        w_ver = self.proxy_weight * n_ver     # discounted: the proxy
        if w_err + w_ver == 0:
            return self.rho_conservative, 0.0  # no usable data -> conservative
        r_obs = (w_err * r_err + w_ver * r_ver) / (w_err + w_ver)
        evidence = w_err + w_ver
        alpha = self.tau_pair / (self.tau_pair + evidence)  # ->1 thin, ->0 rich
        r = (1 - alpha) * r_obs + alpha * self.rho_conservative
        return float(np.clip(r, -1, 1)), float(evidence)

    def _correlation(self):
        P = self.procedures
        k = len(P)
        R = np.eye(k)
        E = np.zeros((k, k))
        for i in range(k):
            for j in range(i + 1, k):
                r, e = self._pair(P[i], P[j])
                R[i, j] = R[j, i] = r
                E[i, j] = E[j, i] = e
        return _nearest_psd(R), P, E

    # ---- the quantity: n_eff -------------------------------------------
    def n_eff(self, item):
        """Galwey (2009) effective number of independent tests from the
        correlation eigenspectrum of the procedures that PASSED this item:
            M_eff = (sum sqrt(lambda_i))^2 / sum(lambda_i)."""
        R, P, _ = self._correlation()
        passing = [p for p, v in self.items.get(item, {}).items() if v == +1]
        if not passing:
            return 0.0
        idx = [P.index(p) for p in passing]
        lam = np.clip(np.linalg.eigvalsh(R[np.ix_(idx, idx)]), 0, None)
        s = lam.sum()
        return float((np.sqrt(lam).sum() ** 2) / s) if s > 0 else 0.0

    def band(self, item):
        x = self.n_eff(item)
        if x >= self.theta:
            return "FLOOR"
        if x > 0:
            return "ASPIRATION"
        return "RESONANCE/OFF-AXIS"

    # ---- diagnostics ----------------------------------------------------
    def diagnostics(self, prior_evidence_floor=1.0):
        """Surface where the conservative prior is doing the work. Any pair whose
        evidence is below prior_evidence_floor is 'prior-dominated' — its
        independence is ASSUMED, not measured. Co-apply that pair to fix it."""
        _, P, E = self._correlation()
        prior_pairs = []
        for i in range(len(P)):
            for j in range(i + 1, len(P)):
                if E[i, j] < prior_evidence_floor:
                    prior_pairs.append((P[i], P[j], round(float(E[i, j]), 2)))
        n_pairs = len(P) * (len(P) - 1) // 2
        labeled = sum(1 for it in self.items if it in self.truth)
        return {
            "n_items": len(self.items),
            "labeled_items": labeled,
            "labeled_fraction": round(labeled / len(self.items), 3) if self.items else 0.0,
            "pairs_total": n_pairs,
            "pairs_prior_dominated": len(prior_pairs),
            "prior_pairs": prior_pairs,
        }

    def recompute(self):
        d = self.diagnostics()
        return {
            "labeled_fraction": d["labeled_fraction"],
            "pairs_prior_dominated": f"{d['pairs_prior_dominated']}/{d['pairs_total']}",
            "items": {it: {"n_eff": round(self.n_eff(it), 3), "band": self.band(it),
                           "aura": self.salience.get(it, 0.0)}
                      for it in sorted(self.items)},
        }


def _nearest_psd(A):
    """Project a symmetric matrix to the nearest PSD correlation matrix."""
    B = (A + A.T) / 2
    w, V = np.linalg.eigh(B)
    B = (V * np.clip(w, 0, None)) @ V.T
    d = np.sqrt(np.clip(np.diag(B), 1e-12, None))
    B = B / np.outer(d, d)
    np.fill_diagonal(B, 1.0)
    return B
