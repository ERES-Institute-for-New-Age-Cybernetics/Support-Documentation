"""Assertion suite for ERES-CDFE-2026-001 v0.2.
Run this to VERIFY the mechanism yourself: `python3 tests.py`.
Exits non-zero if any invariant fails. Independent verification = running it,
not trusting a printed log."""

import sys
import numpy as np
from favors_cov import FavorsCov

rng = np.random.default_rng(4)
PASS, FAIL = [], []

def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))


# --- Invariant 1: discount, not tally ---------------------------------------
eng = FavorsCov(theta=2.5, tau_pair=6.0)
for n in range(200):
    for p in "ABC": eng.record(f"h{n}", p, rng.choice([+1, -1]))
    base = rng.choice([+1, -1])
    for p in "DEF": eng.record(f"h{n}", p, base if rng.random() < 0.97 else -base)
for p in "ABC": eng.record("indep_item", p, +1)
for p in "DEF": eng.record("dup_item", p, +1)
xi, xd = eng.n_eff("indep_item"), eng.n_eff("dup_item")
check("independent trio ~ 3 and promotes", xi >= 2.7 and eng.band("indep_item") == "FLOOR", f"n_eff={xi:.2f}")
check("near-duplicate trio ~ 1-2 and stays out", xd < 2.5 and eng.band("dup_item") != "FLOOR", f"n_eff={xd:.2f}")


# --- Invariant 2: reversibility on discovered common mode -------------------
eng2 = FavorsCov(theta=2.5, tau_pair=4.0)
for n in range(6):
    for p in "PQR": eng2.record(f"e{n}", p, rng.choice([+1, -1]))
for p in "PQR": eng2.record("claim_X", p, +1)
before, bb = eng2.n_eff("claim_X"), eng2.band("claim_X")
for n in range(400):
    b = rng.choice([+1, -1])
    eng2.record(f"L{n}", "P", b)
    eng2.record(f"L{n}", "Q", b if rng.random() < 0.99 else -b)
    eng2.record(f"L{n}", "R", rng.choice([+1, -1]))
after, ab = eng2.n_eff("claim_X"), eng2.band("claim_X")
check("common mode found -> n_eff falls", after < before, f"{before:.2f}->{after:.2f}")
check("fall crosses threshold -> demotion", bb == "FLOOR" and ab != "FLOOR", f"{bb}->{ab}")


# --- Invariant 3: young history is more conservative -----------------------
def neff_at(nh):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(nh):
        for p in "ABC": e.record(f"h{n}", p, rng.choice([+1, -1]))
    for p in "ABC": e.record("item", p, +1)
    return e.n_eff("item")
young, mature = neff_at(2), neff_at(300)
check("young n_eff <= mature n_eff", young <= mature + 1e-9, f"N2={young:.2f} N300={mature:.2f}")


# --- Invariant 4: aura never promotes --------------------------------------
eng4 = FavorsCov(theta=2.5)
eng4.set_salience("hot", 9999)
check("salience 9999 stays off-axis", eng4.n_eff("hot") == 0.0 and eng4.band("hot") == "RESONANCE/OFF-AXIS")


# --- Invariant 5 (NEW): error covariance separates honest agreement from
# shared error. Two procedures S,T are each ~90% accurate with INDEPENDENT
# errors. They agree often -- but only because both are usually right, not
# because they share a blind spot. Verdict-covariance sees the agreement and
# wrongly discounts them as redundant; ground-truth error-covariance reveals
# their errors are uncorrelated and RESTORES the independence credit.
def build(with_truth):
    e = FavorsCov(theta=2.5, tau_pair=6.0)
    for n in range(300):
        y = rng.choice([+1, -1])
        s = y if rng.random() < 0.9 else -y
        t = y if rng.random() < 0.9 else -y   # errors independent of S's
        e.record(f"h{n}", "S", s); e.record(f"h{n}", "T", t)
        if with_truth:
            e.set_truth(f"h{n}", y)
    e.record("item_ST", "S", +1); e.record("item_ST", "T", +1)
    return e.n_eff("item_ST")
blind = build(with_truth=False)   # verdict-only: conflates agreement with redundancy
seeing = build(with_truth=True)   # truth-aware: sees errors are independent
check("error-cov restores credit verdict-cov wrongly discounted",
      seeing > blind + 0.1, f"verdict-only={blind:.2f}  truth-aware={seeing:.2f}")


# --- Invariant 6 (NEW): prior-dominated pairs are named, not hidden --------
eng6 = FavorsCov()
eng6.record("i1", "X", +1); eng6.record("i1", "Y", +1)   # X,Y co-applied once
eng6.record("i2", "Z", +1)                                # Z never with X or Y
d = eng6.diagnostics()
prior_set = {frozenset((a, b)) for a, b, _ in d["prior_pairs"]}
check("no-shared-history pairs flagged prior-dominated",
      frozenset(("X", "Z")) in prior_set and frozenset(("Y", "Z")) in prior_set,
      f"{d['pairs_prior_dominated']}/{d['pairs_total']} on prior")


print("\n" + "=" * 60)
print(f"RESULT: {len(PASS)} passed, {len(FAIL)} failed")
print("=" * 60)
sys.exit(1 if FAIL else 0)
