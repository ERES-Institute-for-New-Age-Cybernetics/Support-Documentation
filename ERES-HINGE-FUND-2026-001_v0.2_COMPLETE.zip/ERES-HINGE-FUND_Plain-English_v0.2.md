# The ERES HINGE Fund, in Plain English

*A short, plain-language description of why it exists, what it is, and how it is meant to work. This is version 0.2 — the same design, refined after several independent AI reviewers checked it and pointed out where it needed to be clearer. This is a description of an idea and a design — not an investment offer, not a promise of returns, and not a fund you can put money into today. The last pages are honest about what still has to be proven.*

---

## Why it exists

Most money in the world is made by betting on things going wrong, or by owning something scarce and charging people for access to it. A hedge fund is the clearest example. It looks for weakness — a company that might fail, a price that might fall, a risk somebody wants to get rid of — and it takes the other side of that weakness for a fee. There is nothing secret about this. It is simply how the ordinary financial machine is built: find fragility, price it, and keep the difference.

The problem is that this machine quietly rewards the wrong thing. It does best when things stay scarce, fragile, and a little broken, because scarcity and fragility are what it sells. If everyone had enough, and if things stopped breaking, a lot of that machine would have nothing left to do.

The ERES work has spent years arguing for the opposite direction. Its whole way of thinking flips the usual story: value should come from mending and providing, not from extracting; from things holding together, not from things falling apart; and from abundance rising, not from scarcity being defended. In that way of thinking, a payment is meant to close a real gap somewhere, not to pile up in one person's account. And the price you can charge for something scarce is expected to fall as that thing becomes plentiful — which is exactly what you want to happen.

If you take that seriously, you eventually notice that a piece is missing. All the ideas point toward a particular kind of money instrument — one that earns by helping things stay whole and by making things plentiful — but nobody had actually named that instrument. The HINGE Fund is that missing piece, finally given a name.

The name itself carries the whole idea. A *hedge* fund hedges: it bets against, it protects itself, it offloads risk onto someone else. A *HINGE* fund hinges: it joins things together, it holds, it repairs. One letter, and the entire direction of the thing reverses.

## What it is

Underneath every fund there is some real thing it is built around. For the HINGE Fund, that thing is a physical object the ERES work calls **the HINGE** — a special kind of connector, or seam, meant to join structures together. What makes it unusual is that it is designed to heal itself. An ordinary joint is the weakest point of any structure; it wears out, and the bigger the structure, the more surely the joints are where it fails first. The HINGE is meant to do the reverse: to repair its own small cracks over time, so that instead of slowly wearing out, it actually lasts *longer* the more it is used and cared for.

That single property is what makes it a good thing to build a fund around. Nearly every asset in the world loses value as it is used — a car, a machine, a road. An asset that gains life by being used turns the usual arithmetic on its head. If the thing you are underwriting gets *better* over time instead of worse, then you no longer need scarcity or breakage to make the numbers work.

So the fund is, in the simplest terms, a way of backing the building and upkeep of these self-healing joints — starting small, at the scale of farms and simple shelters, and reaching up, in principle, to very large structures. It backs them with a promise, and that promise is the second unusual part.

Ordinary funds keep a reserve measured in money — a pile of cash held back against things going wrong. The HINGE Fund's reserve is measured differently: in **proven, tested time**. Its backing is the demonstrated track record of coupling that has actually held and actually healed, over real stretches of time. This matters more than it sounds. Because the reserve is counted in *proven duration* rather than in a dollar figure, it cannot be quietly inflated by clever accounting or by trading paper claims back and forth. You either have the history of things holding together, or you do not. That is a much harder thing to fake than a number on a balance sheet.

The third part is the one people usually ask about first: the artificial intelligence. In this design the AI is deliberately an **add-on**, and the name says so — *AD_ON-AI*, an AI bolted **onto** the instrument, never placed **underneath** it. Its job is to be the fund's careful clerk and inspector. It reads the condition of the joints, it checks every proposed use of money against a set of fixed rules, it keeps an honest and unerasable record of every decision, and it prices that reserve of proven time. What it does *not* do is run the show. It is an actuary and an auditor, not the owner.

There is a plain test for whether the AI is really just an add-on: turn it off, and see what happens to the people who depend on the system. In this design, if the AI goes dark, the most important thing must still stand — the plain safety floor, the guarantee that a person in real trouble still gets real help. If switching off the computer could switch off someone's safety, then the computer was never an add-on; it had quietly become the ground everyone was standing on, and the design forbids that. The floor holds with the AI on or off. That is the line that keeps the AI a helper rather than a gatekeeper.

## How it is meant to work

Start with that floor, because everything else sits above it. Underneath the whole fund is an unconditional safety line — the ERES idea of "a number anyone can call for real help," a guarantee of basic provision that works even for someone with no money at all. The fund is never allowed to touch this floor. It cannot spend it, score it, ration it, or take it away from anyone, for any reason. All of the fund's actual activity happens in a separate layer *above* the floor, where effort and contribution are rewarded. Keeping those two layers strictly apart is the single rule that most separates this from an ordinary fund: no matter how the investments go, nobody's basic safety is ever on the table.

With the floor protected, the fund does its work through a simple relationship: how much backing it holds, divided by how much it has out in the world. The backing is that reserve of proven time. The exposure is the set of joints it is currently supporting. And here the self-healing property quietly helps, because a joint that is actively mending itself is a smaller risk than a joint just sitting there waiting to fail. As the things it backs get healthier, the fund's exposure gets lighter on its own.

Then there is the question of where any gain actually comes from — and this is where the flip becomes concrete rather than poetic. Three plain forces do the work. First, as the useful things the fund helps create become more plentiful, the price anyone can charge to hoard them drifts down toward nothing; the fund's own success eats away at scarcity instead of feeding it. Second, as more of these joints get built, they get cheaper and better to make, the way almost everything does once people have made a lot of it. Third, the joints themselves last longer as they heal, which quietly pays back the fund's promise from the asset side rather than from someone's pocket. Add those together and you get a return that comes from abundance rising and from things not breaking — not from anyone being squeezed.

Every actual decision to put money somewhere has to pass through a gate before it happens. The gate checks a handful of conditions at once — is this aligned with the stated purpose, is it in tune with the real conditions on the ground, is it proportionate, is the risk of an irreversible mistake acceptable — and if any single one of those fails, the money does not move. It is a deliberately strict door: it is much easier to stop a bad allocation than to unwind one after the fact. Above that gate, no single voice, human or machine, gets to approve things alone; a mixed group has to agree, and every step is written into a permanent record that cannot be quietly edited later. The clerk-AI prices and proposes; it never gets to decide by itself, and it never gets to pocket what it audits. Its job is to keep things in tune, not to skim.

That, in one breath, is how it is meant to work: a protected safety floor that the fund can never touch; above it, a promise measured in proven time rather than in dollars, spread across self-healing joints that grow more valuable as they are used; a strict rule-checked gate on every move; and a return that arrives because things are becoming plentiful and staying whole, with an add-on AI keeping the books honest but never taking the wheel.

## What got clearer in this version

Several independent reviewers read the first version and agreed it was honest and well put together, but they pushed on one fair question: it named the chicken-and-egg problem at the start without offering any way through it. This version offers two possible ways through — and is careful to call them possibilities, not solutions.

The first possible route is to let a brand-new joint borrow, at a discount, the proven track record of the *material* it is made from. The base material has already been studied for years, so its behaviour is real and known even before any particular joint has a history of its own. The new joint would lean on that borrowed history only at the very start, clearly labelled as borrowed, and would have to give it up as it earns a real history of its own. The second route is stricter and simpler: don't let the fund start at all until one real joint has actually been built and measured, even briefly. On that path, the very first real measurement *is* the starting seed, and nothing is borrowed or assumed.

The reviewers also noticed something useful: the hard unproven parts are not really separate problems. If you could once measure the true condition of a real joint, that single measurement would show the joint genuinely heals, and that same measurement would give the fund its honest starting seed. So there is really one key that unlocks the rest — one real, careful measurement of one real joint. That is the single most valuable thing anyone could do to move this from a blueprint toward something real.

A few smaller things were tightened too: the way the fund measures its own risk was made properly circular-free (it always looks at last cycle's healing, never this cycle's, so the numbers settle instead of chasing themselves); the rule that the AI inspector can never quietly pay itself was turned from a promise into a checkable mechanism; and the parts a real fund would still need — its legal home, who its members are, how money comes in and goes out, how the people running it get paid — were written down openly as things not yet worked out, rather than left unspoken.

## Why the word "works" is in quotes

It would be dishonest to end without saying plainly what is real today and what is not. The design is coherent, and every piece of it is drawn from work that already exists. But three of the most important parts are not yet proven, and the fund cannot truly "work" until they are.

The first and biggest gap is a chicken-and-egg problem right at the start. The fund's reserve is measured in the proven, tested time that its joints have held together — but a joint that has not been built yet has *no* track record at all. At the very beginning there is nothing to measure, which means there is nothing to back the fund with on day one. Until someone works out an honest way to get the thing started without cheating and pretending the track record already exists, the fund is a design, not a going concern. This is the single most important thing still to solve.

The second gap is the physical joint itself. The self-healing connector is a serious proposal, but it has not yet been built and tested at the scale that matters. If it turns out it does not actually heal the way the design hopes, then the whole "asset that improves with use" idea weakens, and much of the appeal goes with it.

The third gap is measurement. The fund leans on being able to read the true condition of these joints in a way that different, independent inspectors would all agree on — a real fact about the world, not just a number someone declared. That kind of honest, agreed-upon reading has not yet been demonstrated either. Until it is, the reserve is a well-shaped placeholder rather than a measured quantity.

None of this is hidden in the design, and none of it is dressed up. The fund is, at this stage, a careful and honest blueprint for a genuinely different kind of money instrument — one built to profit from mending and abundance instead of from fragility and scarcity. Whether it truly works, rather than works on paper, depends entirely on closing those three gaps with real evidence. That is the honest state of it, and stating it plainly is part of the design too.

---

*ERES Institute for New Age Cybernetics. A plain-language companion to the technical instrument ERES-HINGE-FUND-2026-001 (v0.2, provisional). Shared under CARE Commons Attribution License v2.1 / CC BY 4.0. Not an offer of securities or investment advice.*
