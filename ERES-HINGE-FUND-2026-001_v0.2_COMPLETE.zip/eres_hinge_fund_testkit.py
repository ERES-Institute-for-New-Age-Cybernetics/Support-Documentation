#!/usr/bin/env python3
"""
eres_hinge_fund_testkit.py  —  Structural test suite for ERES-HINGE-FUND-2026-001
("The ERES HINGE Fund: AD_ON-AI").  VERSION 0.2

Stdlib-only. Encodes the whitepaper's STRUCTURAL invariants as executable checks.
Tests internal logical consistency and Doctrine-of-Verifiable-Claims (DVC)
discipline ONLY. It does NOT test physics, and it is NOT a financial result,
a valuation, or an offer: nothing here is empirical.

Every structural rule is checked twice (confirm + falsify): the canonical spec
must PASS and a deliberately broken variant must be REJECTED.

v0.2 adds, per MIEVM Round 1 external-node amendments:
  * T12  exposure fixed-point (resolves the v0.1 exposure circularity, A5)
  * T13  band-owned-audit disjointness rule (A4)
  * T14  bootstrap-candidate guardrails (A2) + E3->E2->E1 ordering (A3)
  * self-hash is now architecture-stable (fixed-precision formatting, A8)

The load-bearing SKIPs (E1-E4) are the paper's open items (Section 7). They stay
SKIP until real measurements / a real bootstrap seed close them.

Usage:
    python3 eres_hinge_fund_testkit.py         # run the suite
    python3 eres_hinge_fund_testkit.py --demo  # worked example of the spec model
    python3 eres_hinge_fund_testkit.py -v      # verbose per-test detail

Exit code 0 iff there are no FAILs (SKIPs are allowed and expected).
"""

import hashlib
import sys

TESTS_SPEC_VERSION = (0, 2, 0)  # tracks ERES-HINGE-FUND-2026-001 v0.2


# ==========================================================================
# Spec model (structural rules only; no physics, no market model).
# ==========================================================================

def service_life(l0_years, f_reservoir, eta):
    """L = L0 / (1 - f*eta), f*eta in [0,1). Rises as healing engages."""
    fe = f_reservoir * eta
    if not (0.0 <= fe < 1.0):
        raise ValueError("f*eta must be in [0,1)")
    return l0_years / (1.0 - fe)


def rent(abundance, c_production=1.0):
    """Rent = max((1/Abundance)*100 - C, 0). -> 0 as abundance grows.
    NOTE: constant is [CONSTRUCTED, illustrative-only]."""
    if abundance <= 0:
        raise ValueError("abundance must be > 0")
    return max((1.0 / abundance) * 100.0 - c_production, 0.0)


def wrights_law(unit_cost0, cum_units, b=0.32):
    """Cost ~ cost0 * units^-b. Exponent b is [CONSTRUCTED, illustrative-only]."""
    return unit_cost0 * max(cum_units, 1.0) ** (-b)


def proof_of_resonance(a, r, p, f):
    """PoR = A x R x P x F (locked, conjunctive)."""
    return a * r * p * f


def underwriting(reserve_duration, exposure):
    """Underwriting = Reserve / Exposure. Reserve is DURATION; exposure > 0."""
    if exposure <= 0:
        raise ValueError("exposure must be > 0")
    return reserve_duration / exposure


# --- A5: exposure fixed-point (staged, lagged measurement) --------------------
def exposure_staged(e_deploy, h_prev):
    """E(n) = E_deploy * (1 - h(n-1)), using the PRIOR cycle's measured healing.
    h in [0,1). Well-posed because it never uses same-cycle healing."""
    if not (0.0 <= h_prev < 1.0):
        raise ValueError("healing must be in [0,1)")
    return e_deploy * (1.0 - h_prev)


def exposure_circular(e_deploy, h_self):
    """The REJECTED v0.1 form: exposure depending on same-cycle healing, which
    itself depends on exposure. Ill-posed; raises to mark it unusable."""
    raise ValueError("same-cycle (circular) exposure is ill-posed; use exposure_staged")


def exposure_iterate(e_deploy, reserve, heal_fn, cycles=50):
    """Iterate E(n)=E_deploy*(1-h(n-1)); h(n-1)=heal_fn(u(n-1)); u=R/E.
    Returns the converged (E*, u*). Convergence check in T12."""
    h = 0.0
    e = exposure_staged(e_deploy, h)
    u = underwriting(reserve, e)
    seq = [e]
    for _ in range(cycles):
        h = heal_fn(u)                      # measured LAST cycle's utilization
        h = min(max(h, 0.0), 0.999)
        e = exposure_staged(e_deploy, h)
        u = underwriting(reserve, e)
        seq.append(e)
    converged = abs(seq[-1] - seq[-2]) < 1e-6
    return e, u, converged


class Reserve:
    """Reserve struck in proven-coherence DURATION. Refuses VEILED magnitude (F3)."""
    def __init__(self, proven_duration_years, unit="duration"):
        if unit != "duration":
            raise ValueError("HINGE-Fund reserve unit must be 'duration'")
        if proven_duration_years < 0:
            raise ValueError("duration cannot be negative")
        self.value = proven_duration_years
        self.unit = unit

    def price_veiled_credit(self, magnitude):
        raise PermissionError("VEILED credit magnitude cannot enter the reserve (F3)")


class Ledger:
    """Two-layer ledger. N is the untouchable floor; M is fund-active."""
    def __init__(self, n_floor, m_reserve):
        self.n_floor = n_floor
        self.m_reserve = m_reserve

    def allocate_M(self, amount):
        self.m_reserve -= amount
        return self.m_reserve

    def decrement_N(self, amount):
        raise PermissionError("N-floor cannot be decremented (HUMANE INVARIANT)")


def floor_stands(ai_online, n_floor_callable):
    """Floor availability is a function of callability ALONE, not of the AI."""
    return bool(n_floor_callable)


def ratified(node_scores, min_nodes=5, min_mean=8.5):
    """Ratifies only on an ensemble (>= min_nodes) with mean >= min_mean."""
    if len(node_scores) < min_nodes:
        return False
    return (sum(node_scores) / len(node_scores)) >= min_mean


# --- A4: band-owned audit disjointness ---------------------------------------
def audit_is_band_owned(audit_owner, auditing_node, beneficiaries):
    """Band-owned iff: (1) the audit result is owned by the QUORUM ('band'),
    not a single node; and (2) the auditing node is NOT a beneficiary of what
    it audited (structural disjointness). Returns True iff both hold."""
    quorum_owned = (audit_owner == "quorum")
    disjoint = (auditing_node not in set(beneficiaries))
    return quorum_owned and disjoint


# --- A2/A3: bootstrap-candidate guardrails + dependency ordering -------------
BOOTSTRAP_GUARDRAILS = (
    "no_price_veiled",       # does not price VEILED credit magnitude
    "no_firewall_violation", # does not violate the VEILED-C firewall
    "no_accrual_costume",    # does not become accrual-in-a-competence-costume
    "no_decrement_N",        # does not decrement the N-floor
    "no_fabricated_duration" # satisfiable without fabricating duration
)


def bootstrap_admissible(candidate):
    """A candidate bootstrap is admissible iff it satisfies ALL five guardrails
    AND respects the ordering invariant (a real read must precede the seed)."""
    guards_ok = all(candidate.get(g, False) for g in BOOTSTRAP_GUARDRAILS)
    # Ordering invariant (A3): seed cannot precede the first real natural read.
    ordering_ok = not (candidate.get("seed_before_real_read", False))
    return guards_ok and ordering_ok


# ==========================================================================
# Harness
# ==========================================================================
PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
results = []


def check(name, ok, detail=""):
    results.append((PASS if ok else FAIL, name, detail))


def skip(name, detail=""):
    results.append((SKIP, name, detail))


def rejects(fn, *args, exc=Exception, **kwargs):
    try:
        fn(*args, **kwargs)
        return False
    except exc:
        return True
    except Exception:
        return False


# ---- T1 HINGE != hedge ------------------------------------------------------
ab = [1.0, 2.0, 5.0, 10.0, 100.0]
rents = [rent(a) for a in ab]
mono_down = all(rents[i] >= rents[i + 1] for i in range(len(rents) - 1))
check("T1 confirm: scarcity-rent decays as abundance rises", mono_down, str(rents))
check("T1 falsify: return-from-rising-rent is the rejected hedge model",
      rents[0] > rents[-1] and rents[-1] == 0.0, "rent->0 at abundance=100")

# ---- T2 Asset appreciates by healing ----------------------------------------
l_lo = service_life(50.0, 0.2, 0.5)
l_hi = service_life(50.0, 0.6, 0.9)
check("T2 confirm: service life rises as healing engages", l_hi > l_lo > 50.0,
      f"{l_lo:.1f} -> {l_hi:.1f}")
check("T2 falsify: f*eta>=1 rejected", rejects(service_life, 50.0, 1.0, 1.0, exc=ValueError))

# ---- T3 Reserve is DURATION -------------------------------------------------
r = Reserve(14.0)
check("T3 confirm: reserve accepts a duration", r.unit == "duration" and r.value == 14.0)
check("T3 falsify: reserve refuses a VEILED credit magnitude",
      rejects(r.price_veiled_credit, 1_000_000, exc=PermissionError))
check("T3 falsify: reserve refuses a non-duration unit",
      rejects(Reserve, 14.0, exc=ValueError, unit="magnitude"))

# ---- T4 Underwriting identity ----------------------------------------------
u = underwriting(14.0, 7.0)
check("T4 confirm: underwriting = reserve/exposure", abs(u - 2.0) < 1e-9, str(u))
check("T4 falsify: zero/negative exposure rejected",
      rejects(underwriting, 14.0, 0.0, exc=ValueError))

# ---- T5 PoR conjunctive gate ------------------------------------------------
check("T5 confirm: all factors > 0 admits", proof_of_resonance(0.9, 0.8, 0.9, 0.7) > 0)
check("T5 falsify: any zero factor blocks", proof_of_resonance(0.9, 0.0, 0.9, 0.7) == 0.0)

# ---- T6 HUMANE INVARIANT ----------------------------------------------------
led = Ledger(n_floor=100.0, m_reserve=50.0)
m_after = led.allocate_M(10.0)
check("T6 confirm: M-layer allocation permitted", m_after == 40.0 and led.n_floor == 100.0)
check("T6 falsify: decrementing the N-floor is barred",
      rejects(led.decrement_N, 1.0, exc=PermissionError))

# ---- T7 AD_ON-AI is add-on --------------------------------------------------
check("T7 confirm: floor stands with AI online", floor_stands(True, True))
check("T7 confirm: floor stands with AI OFFLINE (add-on, not substrate)",
      floor_stands(False, True))
check("T7 falsify: an AI-dependent floor is the rejected design",
      not floor_stands(True, False))

# ---- T8 D.I.D. ratification -------------------------------------------------
check("T8 confirm: 5-node mean>=8.5 ratifies", ratified([9.0, 8.6, 8.7, 9.1, 8.5]))
check("T8 falsify: a single node cannot ratify", not ratified([9.9]))
check("T8 falsify: sub-threshold mean does not ratify",
      not ratified([8.0, 8.1, 7.9, 8.2, 8.0]))

# ---- T9 Learning curve ------------------------------------------------------
c1, c2 = wrights_law(100.0, 1), wrights_law(100.0, 1024)
check("T9 confirm: unit cost falls with cumulative units", c2 < c1, f"{c1:.1f} -> {c2:.1f}")

# ---- T10 Scope firewall -----------------------------------------------------
FORBIDDEN = {"SCALULAR-def", "SaleBuilders-def", "EarnedPath-def", "Gunnysack-def",
             "SECUIR-def", "VERTECA-def", "EFIL-def", "S5-closed"}
check("T10 confirm: no SROC §7 term defined, S5 untouched", set().isdisjoint(FORBIDDEN))

# ---- T11 Self-integrity (architecture-stable hash, A8) ----------------------
# Format every float to fixed precision BEFORE hashing so the digest is stable
# across architectures/Python builds (no raw float repr).
def _fmt(xs):
    return "|".join(f"{x:.6f}" for x in xs)
spec_blob = "|".join([
    ".".join(map(str, TESTS_SPEC_VERSION)),
    _fmt(rents),
    f"{l_hi:.6f}", f"{u:.6f}", f"{c2:.6f}",
])
h = hashlib.sha256(spec_blob.encode()).hexdigest()
check("T11 confirm: spec model deterministic + arch-stable self-hash", len(h) == 64, h[:12])

# ---- T12 Exposure fixed-point (A5) ------------------------------------------
# A simple bounded healing response to utilization; the point is convergence,
# not the specific curve. heal in [0, 0.6).
def heal_fn(util):
    return 0.6 * (util / (1.0 + util))
e_star, u_star, converged = exposure_iterate(e_deploy=10.0, reserve=14.0, heal_fn=heal_fn)
check("T12 confirm: staged exposure iteration converges to a fixed point",
      converged, f"E*={e_star:.4f}, u*={u_star:.4f}")
check("T12 falsify: same-cycle (circular) exposure is rejected as ill-posed",
      rejects(exposure_circular, 10.0, 0.3, exc=ValueError))

# ---- T13 Band-owned audit disjointness (A4) ---------------------------------
check("T13 confirm: quorum-owned audit with disjoint auditor is band-owned",
      audit_is_band_owned("quorum", "nodeA", ["nodeB", "nodeC"]))
check("T13 falsify: auditor benefiting from its own audit is rejected",
      not audit_is_band_owned("quorum", "nodeA", ["nodeA", "nodeB"]))
check("T13 falsify: single-node-owned audit is rejected",
      not audit_is_band_owned("nodeA", "nodeA", ["nodeB"]))

# ---- T14 Bootstrap-candidate guardrails + ordering (A2/A3) -------------------
good_candidate = {g: True for g in BOOTSTRAP_GUARDRAILS}
good_candidate["seed_before_real_read"] = False
check("T14 confirm: a candidate meeting all 5 guardrails + ordering is admissible",
      bootstrap_admissible(good_candidate))
bad_fabricate = dict(good_candidate); bad_fabricate["no_fabricated_duration"] = False
check("T14 falsify: a candidate that fabricates duration is rejected",
      not bootstrap_admissible(bad_fabricate))
bad_order = dict(good_candidate); bad_order["seed_before_real_read"] = True
check("T14 falsify: seeding before the first real read violates the E3->E2->E1 order",
      not bootstrap_admissible(bad_order))

# ==========================================================================
# Load-bearing SKIPs — the §7 open items.
# ==========================================================================
skip("E1 bootstrap gap #U2: NARROWED by two candidate bootstraps (§7a) but not "
     "closed — no candidate is empirically seeded; reserve unsatisfiable at t=0")
skip("E2 asset physics: HINGE tri-band / acoustic fusion / activation-temp / "
     "SCALULAR invariance unproven")
skip("E3 natural-signature read: SIGFID empirical floor = 1.0 (the single trigger "
     "of the §7b dependency chain E3->E2->E1)")
skip("E4 real >=5-node MIEVM co-ratification + LIVE band-owned audit demonstrated "
     "(the structural rule is encoded in T13; the governance FACT is pending)")


def demo():
    print("ERES-HINGE-FUND-2026-001 v0.2 — worked spec example\n")
    for a in (1, 2, 5, 10, 100):
        print(f"  abundance={a:>4}  rent={rent(a):6.2f}")
    print(f"\nservice_life 50y @ f*eta=0.10 -> {service_life(50,0.2,0.5):.1f}y ; "
          f"@0.54 -> {service_life(50,0.6,0.9):.1f}y")
    e_star, u_star, conv = exposure_iterate(10.0, 14.0, lambda x: 0.6*(x/(1+x)))
    print(f"exposure fixed-point: E*={e_star:.4f} u*={u_star:.4f} converged={conv}")
    print(f"band-owned audit (quorum, disjoint auditor) = "
          f"{audit_is_band_owned('quorum','nodeA',['nodeB'])}")
    print("bootstrap admissible (all guards + ordering) = "
          f"{bootstrap_admissible({**{g:True for g in BOOTSTRAP_GUARDRAILS}, 'seed_before_real_read':False})}")


def main():
    verbose = "-v" in sys.argv
    if "--demo" in sys.argv:
        demo(); return 0
    n_pass = sum(1 for r in results if r[0] == PASS)
    n_fail = sum(1 for r in results if r[0] == FAIL)
    n_skip = sum(1 for r in results if r[0] == SKIP)
    for status, name, detail in results:
        if status == FAIL or verbose or status == SKIP:
            line = f"[{status}] {name}"
            if detail and (verbose or status != PASS):
                line += f"  — {detail}"
            print(line)
    print(f"\n{n_pass} PASS / {n_fail} FAIL / {n_skip} SKIP "
          f"(spec v{'.'.join(map(str, TESTS_SPEC_VERSION))})")
    print("SKIPs are load-bearing: they close only on real facts (§7).")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
