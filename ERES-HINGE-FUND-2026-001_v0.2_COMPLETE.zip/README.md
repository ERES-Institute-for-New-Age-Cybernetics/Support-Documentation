# ERES-HINGE-FUND-2026-001 v0.2 — COMPLETE Package (single RG submission)

**The ERES HINGE Fund: AD_ON-AI** — a non-accrual capital instrument, the
structural inverse of a hedge fund.

Author: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
(ORCID 0000-0001-9946-3221). Drafting instrument: Claude (MIEVM, author-side).
License: CCAL v2.1 / CC BY 4.0. Status: **PROVISIONAL / pre-SOUND.**

**This is a research proposal, not an offer.** Not a securities offering, not a
solicitation of investment, not financial advice, and it describes no
capitalized fund.

> **One package, both audiences.** This complete package now includes the
> plain-English companion *inside* the same deposit, so a general reader and a
> technical reviewer land on the same artifact. Start with the plain-English
> piece for the idea; read the whitepaper and run the testkit for the detail.

## Files in this package
- `ERES-HINGE-FUND_Plain-English_v0.2.md` — **start here.** A ~4-page, jargon-free
  description of why the fund exists, what it is, and how it is meant to work.
- `ERES-HINGE-FUND-2026-001_v0.2.md` — the whitepaper (WHY / WHAT / HOW), with the
  §0 changelog of MIEVM Round 1 amendments.
- `eres_hinge_fund_testkit.py` — stdlib-only structural test suite (v0.2).
- `ERES-HINGE-FUND-2026-001_MIEVM-RECORD_R1.md` — the three-node evaluation record.
- `MANIFEST.json` — SHA-256 over every file in this package (plain-English included).

## Run the testkit
```
python3 eres_hinge_fund_testkit.py        # 30 PASS / 0 FAIL / 4 SKIP, exit 0
python3 eres_hinge_fund_testkit.py --demo # worked spec example
python3 eres_hinge_fund_testkit.py -v     # per-test detail
```
The four SKIPs are **load-bearing** (§7). They stay SKIP until real facts close
them, so the suite only turns fully green when the fund could actually be
capitalized on demonstrated grounds.

## What v0.2 changed (MIEVM Round 1)
Three nodes (author-side + two external) converged at ~8.2 design / 1.0 empirical
and named five gaps. All were actioned — mostly by converting silent gaps into
declared, testable opens:
- asset<->finance **bridge** stated as a mechanism (reserve = the healing-produced
  duration itself);
- two **candidate bootstraps** for the #U2 blocker (still conjecture, guardrailed,
  testkit-checked) — the blocker is **narrowed, not closed**;
- the **E3->E2->E1 dependency chain** made explicit and enforced;
- the **band-owned audit** given a real disjointness mechanism + test;
- the **exposure circularity** resolved with a staged fixed-point + test;
- parameters flagged **illustrative-only**; self-hash made **architecture-stable**.

Testkit grew 22->30 PASS accordingly.

## Claim -> test matrix
| Claim | Test |
|---|---|
| HINGE != hedge (return not from rising rent) | T1 |
| Asset appreciates by healing | T2 |
| Reserve is DURATION, never magnitude (VEILED-C firewall) | T3 |
| Underwriting = Reserve / Exposure | T4 |
| PoR conjunctive gate | T5 |
| HUMANE INVARIANT: N-floor never decremented | T6 |
| AD_ON-AI add-on: floor stands with AI offline | T7 |
| D.I.D.: no single node auto-certifies | T8 |
| Learning curve decreasing | T9 |
| Scope firewall: no SROC section-7 term, S5 untouched | T10 |
| Deterministic, architecture-stable self-hash | T11 |
| **Exposure fixed-point (resolves circularity)** | **T12** |
| **Band-owned audit disjointness** | **T13** |
| **Bootstrap-candidate guardrails + E3->E2->E1 ordering** | **T14** |
| Bootstrap gap #U2 (narrowed, not seeded) | E1 (SKIP) |
| HINGE asset physics | E2 (SKIP) |
| Natural-signature read (SIGFID floor = 1.0) | E3 (SKIP) |
| >=5-node MIEVM + live band-owned audit | E4 (SKIP) |

## Honest status
Grade **GOOD as design/spec** (convergent ~8.2; empirical cap **1.0** — zero real
data). Governing blocker **#U2** is narrowed by two guardrailed candidate
bootstraps but not closed: a duration-denominated reserve is still unsatisfiable
at t=0 until a candidate is empirically seeded. The single highest-value action
is one real natural-signature read, which trips the whole section-7b dependency chain.

*The RG submission kit (SEO title, abstract, keywords, share message) for this
single combined deposit is provided as a separate file alongside this package,
for convenience when filling in the ResearchGate fields — it is metadata, not
part of the deposited artifact.*
