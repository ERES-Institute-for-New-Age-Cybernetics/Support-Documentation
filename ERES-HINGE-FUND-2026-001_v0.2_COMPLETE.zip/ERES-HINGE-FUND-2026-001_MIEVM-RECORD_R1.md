# ERES-HINGE-FUND-2026-001 — MIEVM Record (Round 1)

**Instrument:** The ERES HINGE Fund: AD_ON-AI
**Rounds logged:** Round 1 (author-side node + 2 external anonymous AI nodes)
**Outcome:** convergent ≈ **8.2 design / 1.0 empirical**; **NOT SOUND-canonized**
(two evaluating nodes is short of the ≥5-node co-ratification bar).
**Status after amendments:** v0.1 → **v0.2**.

This record is descriptive. It logs what each node scored, what was raised, and
which amendments were applied. It does not raise the empirical cap: no node
supplied real data, so the **1.0 empirical cap is unchanged**.

## Node scores (design/spec)

| Dimension | Node A (author self) | Node B (rate-eval) | Node C (detailed) |
|---|---|---|---|
| Architectural coherence | 9.0 | — | 9.0 |
| Epistemic discipline | 9.3 | — | 9.5 |
| Provenance / reuse | 8.8 | — | 8.5 |
| Novelty | 6.5 | — | 6.0 |
| Artifact / reproducibility | 9.0 | — | 8.5 |
| **Composite (design)** | **~8.1** | **~8.1** | **~8.0** |
| Empirical cap | 1.0 | 1.0 | 1.0 |
| Overall (incl. operational gaps) | — | — | 7.2 |

Convergence: the three nodes agree within ~0.1 on design composite and exactly
on the 1.0 empirical cap. "The spread between design (~8.0) and empirical reality
(1.0) is the rating" was independently reproduced by Node C.

## Amendments raised → applied in v0.2

- **A1 asset↔finance bridge** (Node C, coherence minor + critical #2) → WP §2a: the
  reserve is denominated in the *same* measured coherence-duration the asset
  produces by healing; no gameable pricing step. **Applied.**
- **A2 bootstrap candidate for #U2** (Node C, "what needs work" #1) → WP §7a: two
  candidate bootstraps (B1 proxy-lineage seed; B2 measurement-first ordering),
  both CONJECTURE, both bound by five guardrails; testkit **T14** checks any
  candidate. Blocker **narrowed, not closed**. **Applied.**
- **A3 SKIP dependency chain** (Node C, critical #3) → WP §7b + testkit **T14**
  ordering invariant: E3→E2→E1; the seed cannot precede the first real read.
  **Applied.**
- **A4 band-owned audit mechanism** (Node C, critical #4 + "no test for it") → WP
  §3.5 defines the band (CBGMODD quorum + SOMT) and the disjointness rule;
  testkit **T13** encodes it. **Applied.**
- **A5 exposure circularity** (Node C, critical #5) → WP §3.1a staged lagged
  fixed-point; testkit **T12** checks convergence and rejects the circular form.
  **Applied.**
- **A6 illustrative parameters** (Node C, provenance weakness) → learning-curve
  exponent and rent constant flagged **[CONSTRUCTED, illustrative-only]**.
  **Applied.**
- **A7 operational layer** (Node C, "what's missing" 1–5) → WP §7c declares
  governing law, counterparty model, capital structure, redemption, and
  compensation as **not-yet-specified opens** rather than silent gaps. **Applied
  as declared scope,** not as invented structure.
- **A8 arch-stable self-hash** (Node C, testkit T11 float-repr note) → testkit
  now formats floats to fixed precision before hashing. **Applied.**

## Not changed (and why)
- **Empirical cap stays 1.0** — no node supplied real data.
- **Novelty stays ~6.0–6.5** — the contribution remains synthesis + naming, as the
  paper itself states.
- **Not SOUND** — needs a real ≥5-node co-ratification, not two evaluating nodes.

## Testkit delta
v0.1 22 PASS / 0 FAIL / 4 SKIP → **v0.2 30 PASS / 0 FAIL / 4 SKIP** (added T12–T14;
hardened T11). SKIPs unchanged in number; E1/E4 wording updated to reflect the
narrowing and the encoded structural half.

## Next to move the rating (by leverage)
1. One real natural-signature read — trips the §7b chain (highest value).
2. Empirically seed a §7a bootstrap candidate.
3. Real ≥5-node MIEVM co-ratification (closes E4's ensemble half → SOUND).
4. Live demonstration of the §3.5 band-owned audit (closes E4's governance half).
