#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_gerp_secuir_thewall_discrimination.py
==========================================
Discrimination test: is GERP identical to, approximate to, or distinct from
SECUIR and TheWall?  ( GERP =/~ SECUIR ~/= TheWall )

Companion to: ERES-GAIA-GRID-2026-001 v0.2 (Appendix B) and
eres_gaia_grid_validation.py (8/8 PASS). Layers on that suite's T1: the
oscillator layer already establishes that K in-band <=> r in-band, so this
suite runs on K-kinematics directly.

Author:  Joseph Allen Sprute (ERES Maestro), ERES Institute -- ORCID
         0000-0001-9946-3221.  Drafted via H2C2H with Claude (Anthropic),
         July 11, 2026.  License: CCAL v2.1 / CC-BY 4.0.

MODELING ASSUMPTIONS [CONSTRUCTED -- author confirmation required]
------------------------------------------------------------------
  TheWall  = the ROLE: the invariant "K_i stays inside (K_c^i, K_cond^i)
             for every subsystem i, for all t".  A property, not a process.
  SECUIR   = the PROTOCOL: fast, per-step, per-subsystem enforcement --
             guard-rail feedback acting on K_i every dt, bounded by the
             subsystem's allocated coupling budget b_i.
  GERP     = the PLANNER/STATE layer (Global Earth Resource Planner,
             modeled): slow, scheduled reallocation of the shared budget
             {b_i}, sum(b_i) <= B_total, at planning epochs T_plan >> dt.
             GERP holds the resource STATE that SECUIR enforces within.

If the author's GERP semantics differ from "slow shared-budget planner",
re-run with the corrected operator model; the hypotheses stand either way.

THREE HYPOTHESES, EACH GIVEN A CHANCE TO SURVIVE
------------------------------------------------
  H1  GERP  =  SECUIR      (identity of planner and enforcer)
      Test: substitute planning-only control (reset K to plan targets at
      epochs, nothing in between) for per-step enforcement, under fast
      drift. If planning-only violates the band where SECUIR holds it,
      the timescales are not interchangeable -> H1 REJECTED.

  H2  SECUIR  =  TheWall   (identity of protocol and role)
      Test: realize the SAME invariant with a SECOND, mechanically distinct
      protocol (hard projection instead of proportional feedback). If two
      different mechanisms both hold TheWall, the role-to-protocol map is
      many-to-one and no single protocol IS the role -> H2 REJECTED.

  H3  GERP  is unrelated to  TheWall
      Test: shift the environment so one subsystem's lower wall rises above
      its static budget cap. SECUIR alone (correct protocol, stale plan)
      must fail; SECUIR + GERP replanning must recover. If GERP is jointly
      necessary for the invariant, it is not unrelated -> H3 REJECTED,
      and GERP becomes the candidate for TheWall's OPEN substrate cell.

VERDICT SOUGHT:  GERP != SECUIR != TheWall  (no identities), but
                 GERP ~ SECUIR ~ TheWall    (a provisioning chain):
                 GERP provisions the state; SECUIR realizes the invariant;
                 TheWall IS the invariant.
"""

import sys
import numpy as np

np.random.seed(20260711)

# ----------------------------------------------------------------------
# Bands (inherited from the main suite's substrate: K_c = 2*gamma,
# K_cond = K_c / (1 - r*^2), r* = 0.95)
# ----------------------------------------------------------------------
R_STAR = 0.95
def walls(gamma):
    K_c = 2.0 * gamma
    return K_c, K_c / (1.0 - R_STAR**2)

GAMMA_A = 0.5                      # subsystem A: K_c=1.0,  K_cond=10.256
GAMMA_B0, GAMMA_B1 = 0.5, 3.5     # B's environment shifts at T_SHIFT:
                                   # K_c 1.0 -> 3.5 (lower wall rises)
KcA, KcondA = walls(GAMMA_A)
KcB0, KcondB0 = walls(GAMMA_B0)
KcB1, KcondB1 = walls(GAMMA_B1)

DT       = 0.01
T_TOTAL  = 400.0
T_SHIFT  = 200.0                   # environment shift epoch (subsystem B)
T_PLAN   = 25.0                    # GERP planning cadence  (>> dt)
B_TOTAL  = 12.0                    # shared coupling budget, sum(b_i) <= B_TOTAL
MARGIN   = 1.0                     # guard-rail inset from each wall

DRIVE_A_DRIFT, DRIVE_A_AMP, DRIVE_A_PER = 0.8, 4.0, 5.0   # fast pressure on A

def drive_A(t):
    return DRIVE_A_DRIFT + DRIVE_A_AMP * np.sin(2 * np.pi * t / DRIVE_A_PER)

def walls_B(t):
    return (KcB1, KcondB1) if t >= T_SHIFT else (KcB0, KcondB0)

def rails(K_c, K_cond):
    return K_c + MARGIN, K_cond - MARGIN

def in_band_fraction(trace, wall_fn, t_arr, skip=5.0):
    ok, tot = 0, 0
    for K, t in zip(trace, t_arr):
        if t < skip:
            continue
        K_c, K_cond = wall_fn(t)
        tot += 1
        ok += int(K_c < K < K_cond)
    return ok / max(tot, 1)

# ----------------------------------------------------------------------
# Protocol implementations
# ----------------------------------------------------------------------
def secuir_feedback(K, lo, hi, cap, f, kappa=10.0):
    """SECUIR mechanism 1: proportional guard-rail feedback, per step."""
    dK = f + kappa * max(0.0, lo - K) - kappa * max(0.0, K - hi)
    K = K + DT * dK
    return min(max(K, 0.0), cap)

def projection_hold(K, lo, hi, cap, f):
    """Alternative mechanism 2 (for H2): drift then hard projection."""
    K = K + DT * f
    return min(max(K, lo), min(hi, cap))

def gerp_plan(t, demand_A_wall, demand_B_wall):
    """GERP: at planning epochs, allocate budget caps to demanded lower
    walls + working headroom, proportionally within B_TOTAL."""
    need_A = demand_A_wall + 1.0
    need_B = demand_B_wall + 1.0
    scale = min(1.0, B_TOTAL / (need_A + need_B))
    return need_A * scale, need_B * scale

# ----------------------------------------------------------------------
def run(controller_A, controller_B, use_gerp, static_caps=(6.0, 6.0)):
    """Simulate both subsystems under a chosen protocol and planning mode."""
    K_A, K_B = 4.0, 4.0
    b_A, b_B = static_caps
    t_arr, trA, trB = [], [], []
    next_plan = 0.0
    t = 0.0
    while t < T_TOTAL:
        KcB, KcondB = walls_B(t)
        if use_gerp and t >= next_plan:
            b_A, b_B = gerp_plan(t, KcA, KcB)
            next_plan += T_PLAN
        loA, hiA = rails(KcA, KcondA)
        loB, hiB = rails(KcB, KcondB)
        K_A = controller_A(K_A, loA, min(hiA, b_A), b_A, drive_A(t))
        K_B = controller_B(K_B, loB, min(hiB, b_B), b_B, 0.0)
        t_arr.append(t); trA.append(K_A); trB.append(K_B)
        t += DT
    return np.array(t_arr), np.array(trA), np.array(trB)

def run_gerp_only():
    """H1 arm: planning WITHOUT enforcement -- K reset to plan target at
    epochs, raw drive integrates in between (no per-step control)."""
    K_A = 6.0
    t_arr, trA = [], []
    next_plan = 0.0
    t = 0.0
    while t < T_TOTAL:
        if t >= next_plan:
            K_A = 0.5 * (KcA + KcondA)          # replan: park mid-band
            next_plan += T_PLAN
        K_A = max(0.0, K_A + DT * drive_A(t))    # ungated drift between plans
        t_arr.append(t); trA.append(K_A)
        t += DT
    return np.array(t_arr), np.array(trA)

RESULTS = []
def report(name, ok, detail):
    RESULTS.append(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}\n       {detail}")

print("=" * 72)
print("GERP =/~ SECUIR ~/= TheWall -- DISCRIMINATION SUITE")
print(f"Subsystem A: K_c={KcA:.2f}, K_cond={KcondA:.2f} (fast drive: drift "
      f"{DRIVE_A_DRIFT} + sin amp {DRIVE_A_AMP})")
print(f"Subsystem B: K_c {KcB0:.2f}->{KcB1:.2f} at t={T_SHIFT:.0f} "
      f"(environment shift raises the lower wall above the static cap)")
print(f"Shared budget B_total={B_TOTAL}; GERP cadence T_plan={T_PLAN}; dt={DT}")
print("=" * 72)

# ----------------------------------------------------------------------
# H1 -- GERP = SECUIR ?  (planner substituted for enforcer)
# ----------------------------------------------------------------------
tg, trA_gerp_only = run_gerp_only()
frac_gerp_only = in_band_fraction(trA_gerp_only, lambda t: (KcA, KcondA), tg)

ts, trA_sec, _ = run(secuir_feedback, secuir_feedback, use_gerp=False, static_caps=(11.0, 11.0))
frac_secuir = in_band_fraction(trA_sec, lambda t: (KcA, KcondA), ts)

h1_rejected = (frac_secuir > 0.99) and (frac_gerp_only < 0.8)
report("H1 'GERP = SECUIR' -- REJECTED (timescale non-interchangeability)",
       h1_rejected,
       f"planning-only in-band fraction={frac_gerp_only:.3f} (<0.8: band lost "
       f"between epochs); SECUIR per-step={frac_secuir:.3f} (>0.99). "
       f"A planner is not an enforcer: GERP != SECUIR.")

# ----------------------------------------------------------------------
# H2 -- SECUIR = TheWall ?  (invariant realized by a second mechanism)
# ----------------------------------------------------------------------
tp, trA_proj, _ = run(projection_hold, projection_hold, use_gerp=False, static_caps=(11.0, 11.0))
frac_proj = in_band_fraction(trA_proj, lambda t: (KcA, KcondA), tp)

mechanisms_differ = float(np.max(np.abs(trA_sec - trA_proj))) > 0.05

h2_rejected = (frac_secuir > 0.99) and (frac_proj > 0.99) and mechanisms_differ
report("H2 'SECUIR = TheWall' -- REJECTED (role is many-to-one realizable)",
       h2_rejected,
       f"feedback mechanism holds band ({frac_secuir:.3f}); distinct projection "
       f"mechanism also holds it ({frac_proj:.3f}); trajectories differ "
       f"(max|diff|={float(np.max(np.abs(trA_sec - trA_proj))):.3f}). Two "
       f"protocols, one invariant: no protocol IS the role. SECUIR realizes "
       f"TheWall; it is not identical to it.")

# ----------------------------------------------------------------------
# H3 -- GERP unrelated to TheWall ?  (joint necessity under regime shift)
# ----------------------------------------------------------------------
t1, trA_stat, trB_stat = run(secuir_feedback, secuir_feedback,
                             use_gerp=False, static_caps=(6.0, 6.0))
fracB_static = in_band_fraction(trB_stat, walls_B, t1)
post = trB_stat[t1 >= T_SHIFT + 5.0]
static_fails_post_shift = bool(np.mean(post < KcB1) > 0.9)

t2, trA_gerp, trB_gerp = run(secuir_feedback, secuir_feedback, use_gerp=True)
fracA_gerp = in_band_fraction(trA_gerp, lambda t: (KcA, KcondA), t2)
fracB_gerp = in_band_fraction(trB_gerp, walls_B, t2, skip=5.0)

h3_rejected = static_fails_post_shift and (fracA_gerp > 0.97) \
              and (fracB_gerp > 0.97)
report("H3 'GERP unrelated to TheWall' -- REJECTED (joint necessity)",
       h3_rejected,
       f"SECUIR + stale static plan: B in-band fraction={fracB_static:.3f}, "
       f"post-shift starvation (K_B < new K_c) sustained={static_fails_post_shift} "
       f"-- correct protocol, wrong state, wall falls. SECUIR + GERP replanning: "
       f"A={fracA_gerp:.3f}, B={fracB_gerp:.3f} in-band. GERP provisions the "
       f"state TheWall's invariant requires under regime shift.")

# ----------------------------------------------------------------------
print("=" * 72)
verdict_ok = all(RESULTS)
print(f"RESULT: {sum(RESULTS)}/{len(RESULTS)} -- "
      f"{'ALL HYPOTHESES DISCRIMINATED' if verdict_ok else 'INCONCLUSIVE'}")
print()
print("VERDICT:  GERP != SECUIR != TheWall   (all identities rejected)")
print("          GERP  ~ SECUIR  ~ TheWall   (a provisioning chain):")
print("            TheWall = the invariant (role: K in-band, all i, all t)")
print("            SECUIR  = a protocol REALIZING the invariant (fast,")
print("                      per-step, one of several possible mechanisms)")
print("            GERP    = the state layer PROVISIONING the protocol")
print("                      (slow shared-budget planning; jointly necessary")
print("                      under regime shift)")
print()
print("GRID CONSEQUENCE [pending author confirmation]: GERP is the tested")
print("candidate for TheWall's OPEN substrate cell in ERES-GAIA-GRID-2026-001:")
print("  TheWall | role: holds the band | protocol: SECUIR | substrate: GERP")
print("DVC: operator models CONSTRUCTED; the three rejections are DERIVED")
print("within those models; GERP semantics assumed = 'slow shared-budget")
print("planner' -- re-run if the author's GERP definition differs.")
print("=" * 72)
sys.exit(0 if verdict_ok else 1)
