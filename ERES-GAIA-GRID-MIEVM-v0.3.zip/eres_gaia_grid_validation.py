#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_gaia_grid_validation.py
============================
ERES GAIA Construct Grid -- Validation & Test Suite
Companion code to: ERES-GAIA-GRID-2026-001 v0.2 (Appendix B), which is itself
companion to ERES-PELLIS-SHB-001 v2.2 ("Sound Holds the Band", Figure 1).

Author:  Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age
         Cybernetics, Bella Vista, Arkansas -- ORCID 0000-0001-9946-3221
Drafted: via H2C2H with Claude (Anthropic), July 11, 2026
License: CCAL v2.1 / CC-BY 4.0

WHAT THIS SUITE TESTS
---------------------
Appendix B formalizes the five constructs as operators on the coupling
trajectory K(t) over a Kuramoto substrate. Each test below executes one
Appendix-B claim and reports PASS/FAIL. Exit code 0 iff all tests pass.

  T1  Band exists (inherited layer, DERIVED): three regimes on the K-axis --
      incoherence below K_c, resonance band, condensation above K_cond --
      with the empirical K_c matching the analytic mean-field value.
  T2  TheMall ungoverned (mining schedule): linear drift K' = mu breaches
      the upper wall at the predicted t_breach and drives r into condensation.
  T3  EarnedPath (governed ascent): saturating schedule with declared ceiling
      K_inf <= K_cond - m plateaus IN-BAND -- band-respecting, Prediction 2.
  T4  PlayNAC entry signature (Prediction 1): rising-r trajectory from the
      O(N^-1/2) noise floor into the band, versus stationary in-band hold.
  T5  Sentry margin law (DERIVED, closes S7 item 5 conditionally):
      m* = v * tau. 98/2 alarm prevents breach iff v <= 0.02*DeltaK/tau;
      both branches (safe drift, unsafe drift) are exercised.
  T6  GAIA governor (governor-not-judge): continuous feedback
      K' = f_drive - gamma*max(0, r - r_set) holds the band under TheMall
      pressure, while the ungoverned control breaches.
  T7  Handoff Pattern (Proposition 1, structural): protocol families are a
      closed-interval cover of the K-axis whose pairwise intersections are
      exactly the keeper points -- no gaps, no overlapping interiors.
  T8  Infinance (structural): transmission functional T(r) = 0 below K_c
      (real but unpriced substrate) and T > 0 in-band; the CF ladder is an
      ordering WITHOUT a functional, with its top boundary at K_c.

DVC TAGS: T1 checks a DERIVED literature result. T5 and T7 check results
DERIVED/stated in this instrument. T2's premise (commerce drifts linearly)
remains CONJECTURE -- the test verifies the implication, not the premise.
The CF tier index n* at the K_c crossing is a CONFIGURABLE awaiting the
author's declaration in ERES-CF-2026-001 (S7 open item 1); T8 tests the
structure, not the specific index.

Substrate: mean-field Kuramoto, Lorentzian g(omega) with half-width GAMMA,
so the analytic onset is K_c = 2*GAMMA and the partially-locked branch is
r(K) = sqrt(1 - K_c/K). Upper wall K_cond is declared via r* (SHB S4):
K_cond = K_c / (1 - r*^2). Deterministic seed; numpy only.
"""

import sys
import numpy as np

RNG_SEED = 20260711
np.random.seed(RNG_SEED)

# ----------------------------------------------------------------------
# Substrate parameters (inherited layer)
# ----------------------------------------------------------------------
N        = 1500          # oscillators
GAMMA    = 0.5           # Lorentzian half-width  ->  K_c = 2*GAMMA = 1.0
K_C      = 2.0 * GAMMA   # analytic lower wall (DERIVED, mean-field)
R_STAR   = 0.95          # declared condensation criterion r* (policy, SHB S4)
K_COND   = K_C / (1.0 - R_STAR**2)   # analytic upper wall from r(K) branch
DELTA_K  = K_COND - K_C  # band width
DT       = 0.02
NOISE_FLOOR = 1.0 / np.sqrt(N)       # O(N^-1/2) incoherent fluctuation level

# Frequencies: Lorentzian (Cauchy) sample, clipped for numerical sanity
OMEGA = GAMMA * np.tan(np.pi * (np.random.rand(N) - 0.5))
OMEGA = np.clip(OMEGA, -50, 50)


def order_parameter(theta):
    z = np.mean(np.exp(1j * theta))
    return np.abs(z), np.angle(z)


def simulate(K_schedule, T_total, theta0=None, record_every=5):
    """Mean-field Kuramoto: dtheta_i = omega_i + K(t)*r*sin(psi - theta_i).

    K_schedule: callable K(t, r) -> coupling at time t given current r
                (r is passed so governors can close the loop).
    Returns (t_arr, r_arr, K_arr, theta_final).
    """
    steps = int(T_total / DT)
    theta = (np.random.rand(N) * 2 * np.pi) if theta0 is None else theta0.copy()
    t_out, r_out, K_out = [], [], []
    r, psi = order_parameter(theta)
    for s in range(steps):
        t = s * DT
        K = K_schedule(t, r)
        r, psi = order_parameter(theta)
        theta = theta + DT * (OMEGA + K * r * np.sin(psi - theta))
        if s % record_every == 0:
            t_out.append(t); r_out.append(r); K_out.append(K)
    return np.array(t_out), np.array(r_out), np.array(K_out), theta


def tail_mean(x, frac=0.25):
    n = max(1, int(len(x) * frac))
    return float(np.mean(x[-n:]))


RESULTS = []

def report(name, ok, detail):
    RESULTS.append(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}\n       {detail}")


print("=" * 72)
print("ERES GAIA CONSTRUCT GRID -- VALIDATION SUITE")
print("Instrument: ERES-GAIA-GRID-2026-001 v0.2, Appendix B")
print(f"Substrate:  N={N}, Lorentzian gamma={GAMMA}  =>  K_c={K_C:.3f} (analytic)")
print(f"Walls:      r*={R_STAR}  =>  K_cond={K_COND:.3f}, band width DeltaK={DELTA_K:.3f}")
print(f"Noise floor O(N^-1/2) = {NOISE_FLOOR:.4f}   seed={RNG_SEED}")
print("=" * 72)

# ----------------------------------------------------------------------
# T1 -- Band exists: three regimes + analytic anchor (DERIVED layer)
# ----------------------------------------------------------------------
_, r_below, _, _ = simulate(lambda t, r: 0.5 * K_C, T_total=40)
_, r_in,    _, _ = simulate(lambda t, r: 2.0,        T_total=60)
_, r_above, _, _ = simulate(lambda t, r: K_COND * 1.15, T_total=60)

r_b = tail_mean(r_below); r_i = tail_mean(r_in); r_a = tail_mean(r_above)
r_analytic = np.sqrt(1 - K_C / 2.0)   # partially locked branch at K=2

t1_ok = (r_b < 4 * NOISE_FLOOR) and (abs(r_i - r_analytic) < 0.08) and (r_a >= R_STAR)
report("T1 band exists (Theorem 1 trace; analytic K_c anchor)",
       t1_ok,
       f"below wall r={r_b:.3f} (<{4*NOISE_FLOOR:.3f}); in-band r={r_i:.3f} "
       f"vs analytic {r_analytic:.3f}; above wall r={r_a:.3f} (>= r*={R_STAR})")

# ----------------------------------------------------------------------
# T2 -- TheMall ungoverned: linear drift, finite-time breach [implication]
# ----------------------------------------------------------------------
K0, MU = 1.5, 0.05
t_breach_pred = (K_COND - K0) / MU
t2t, t2r, t2K, _ = simulate(lambda t, r: K0 + MU * t, T_total=t_breach_pred + 40)
breach_idx = np.argmax(t2K >= K_COND)
t_breach_obs = t2t[breach_idx]
r_end_mall = tail_mean(t2r)
# monotone climb signature: r increases robustly over the run
smooth = np.convolve(t2r, np.ones(20) / 20, mode="valid")
monotone_frac = float(np.mean(np.diff(smooth) >= -1e-3))

t2_ok = (abs(t_breach_obs - t_breach_pred) < 2.0) and (r_end_mall >= R_STAR) \
        and (monotone_frac > 0.9)
report("T2 TheMall ungoverned drift -> condensation (mining schedule)",
       t2_ok,
       f"t_breach predicted {t_breach_pred:.1f}, observed {t_breach_obs:.1f}; "
       f"final r={r_end_mall:.3f} (>= r*); monotone fraction={monotone_frac:.2f} "
       f"[premise remains CONJECTURE; implication verified]")

# ----------------------------------------------------------------------
# T3 -- EarnedPath: saturating schedule is band-respecting (Prediction 2)
# ----------------------------------------------------------------------
K_INF = K_COND - 0.25 * DELTA_K     # declared ceiling with healthy reserve
MU_EP = 0.15

def earnedpath_K(t, r, _state={"K": K0}):
    _state["K"] += DT * MU_EP * (1 - _state["K"] / K_INF)
    return _state["K"]

t3t, t3r, t3K, _ = simulate(earnedpath_K, T_total=200)
supK = float(np.max(t3K)); r_ep = tail_mean(t3r)
# plateau signature: late-time slope of r ~ 0, and never condensed
late = t3r[int(0.75 * len(t3r)):]
slope = float(np.polyfit(np.arange(len(late)), late, 1)[0])

t3_ok = (supK <= K_COND) and (r_ep < R_STAR) and (r_ep > 0.3) and (abs(slope) < 5e-4)
report("T3 EarnedPath saturating ascent stays in-band (Prediction 2)",
       t3_ok,
       f"sup K={supK:.3f} <= K_cond={K_COND:.3f}; plateau r={r_ep:.3f} in-band "
       f"(< r*); late slope={slope:.2e} (~0: plateau, not climb)")

# ----------------------------------------------------------------------
# T4 -- PlayNAC entry signature vs in-band hold (Prediction 1)
# ----------------------------------------------------------------------
K_ENTRY_END = 2.0
def playnac_K(t, r):          # ramp from below K_c across the lower wall
    return 0.3 + (K_ENTRY_END - 0.3) * min(1.0, t / 60.0)

t4t, t4r, _, _ = simulate(playnac_K, T_total=100)
head = float(np.mean(t4r[: int(0.1 * len(t4r))]))
tail = tail_mean(t4r)
delta_entry = tail - head

_, hold_r, _, _ = simulate(lambda t, r: K_ENTRY_END, T_total=100)
hold_half = hold_r[len(hold_r)//2:]
delta_hold = float(abs(tail_mean(hold_half, 0.2) -
                       float(np.mean(hold_half[:max(1, len(hold_half)//5)]))))

t4_ok = (head < 4 * NOISE_FLOOR) and (delta_entry > 0.3) and (delta_hold < 0.1) \
        and (delta_entry > 3 * delta_hold)
report("T4 PlayNAC rising-r entry vs stationary in-band hold (Prediction 1)",
       t4_ok,
       f"entry: r {head:.3f} -> {tail:.3f} (Delta={delta_entry:.3f}); "
       f"hold drift |Delta|={delta_hold:.3f}; signatures distinguishable")

# ----------------------------------------------------------------------
# T5 -- Sentry margin law m* = v*tau (DERIVED; both branches)
# ----------------------------------------------------------------------
K_ALARM = K_C + 0.98 * DELTA_K
M_RESERVE = 0.02 * DELTA_K

def sentry_run(v_drift, tau_damp, damp_rate=2.0, T_total=400.0, dt=0.005):
    """Kinematics on K(t) alone: drift v until alarm; damping engages after
    latency tau; returns True if breach (K >= K_cond) ever occurs."""
    K, t, t_alarm = K_C + 0.5 * DELTA_K, 0.0, None
    while t < T_total:
        if t_alarm is None and K >= K_ALARM:
            t_alarm = t
        dK = v_drift
        if t_alarm is not None and (t - t_alarm) >= tau_damp:
            dK = v_drift - damp_rate            # governor response engaged
        K += dt * dK
        if K >= K_COND:
            return True
        if dK < 0 and K < K_ALARM:              # damped back below alarm: safe
            return False
        t += dt
    return False

TAU = 1.0
v_safe   = 0.5 * (0.02 * DELTA_K / TAU)   # v <= 0.02*DeltaK/tau  -> no breach
v_unsafe = 3.0 * (0.02 * DELTA_K / TAU)   # v  > 0.02*DeltaK/tau  -> breach

breach_safe   = sentry_run(v_safe, TAU)
breach_unsafe = sentry_run(v_unsafe, TAU)

t5_ok = (not breach_safe) and breach_unsafe
report("T5 Sentry margin law m* = v*tau (98/2 validity condition, DERIVED)",
       t5_ok,
       f"tau={TAU}, threshold v=0.02*DeltaK/tau={0.02*DELTA_K/TAU:.4f}; "
       f"safe drift v={v_safe:.4f} breach={breach_safe} (expect False); "
       f"unsafe drift v={v_unsafe:.4f} breach={breach_unsafe} (expect True)")

# ----------------------------------------------------------------------
# T6 -- GAIA governor holds the band under TheMall pressure
# ----------------------------------------------------------------------
R_SET, GOV_GAMMA, F_DRIVE = 0.85, 8.0, 0.05

def gaia_K(t, r, _state={"K": 2.0}):
    _state["K"] += DT * (F_DRIVE - GOV_GAMMA * max(0.0, r - R_SET))
    _state["K"] = max(_state["K"], 0.0)
    return _state["K"]

t6t, t6r, t6K, _ = simulate(gaia_K, T_total=300)
sup_r_gov = float(np.max(t6r[int(0.1*len(t6r)):]))
sup_K_gov = float(np.max(t6K))

def mall_K(t, r, _state={"K": 2.0}):     # ungoverned control: same drive, no damping
    _state["K"] += DT * F_DRIVE
    return _state["K"]

_, c_r, c_K, _ = simulate(mall_K, T_total=300)
control_breached = bool(np.max(c_K) >= K_COND and tail_mean(c_r) >= R_STAR)

t6_ok = (sup_r_gov < R_STAR) and (sup_K_gov < K_COND) and control_breached
report("T6 GAIA governor (feedback damping) holds band; ungoverned control breaches",
       t6_ok,
       f"governed: sup r={sup_r_gov:.3f} (< r*), sup K={sup_K_gov:.3f} (< K_cond); "
       f"ungoverned control breached={control_breached} (expect True)")

# ----------------------------------------------------------------------
# T7 -- Handoff Pattern: closed-interval cover, keeper-point intersections
# ----------------------------------------------------------------------
K_P = 2.0   # PlayNAC -> EarnedPath handoff point (in-band)
FAMILIES = {"ContextField": (0.0, K_C),
            "PlayNAC":      (K_C, K_P),
            "EarnedPath":   (K_P, K_INF)}
KEEPERS  = {"Avatar": K_C, "TheMall/EarnedPath-handoff": K_P}

iv = sorted(FAMILIES.values())
no_gaps      = all(abs(iv[i][1] - iv[i+1][0]) < 1e-12 for i in range(len(iv)-1))
no_overlap   = all(iv[i][1] <= iv[i+1][0] + 1e-12 for i in range(len(iv)-1))
covers       = (iv[0][0] == 0.0) and (abs(iv[-1][1] - K_INF) < 1e-12)
keepers_at_b = all(any(abs(kp - b) < 1e-12 for a, b in iv[:-1]) for kp in [K_C, K_P])
intersections_single = no_gaps and no_overlap   # closed intervals meeting at points

t7_ok = covers and intersections_single and keepers_at_b
report("T7 Handoff Pattern: interval cover with single-point keeper intersections",
       t7_ok,
       f"cover [0,{K_INF:.3f}] complete={covers}; gaps=none:{no_gaps}; "
       f"interior overlaps=none:{no_overlap}; keepers at boundaries={keepers_at_b} "
       f"[Proposition 1: 'cover is forced' remains open -- this tests consistency]")

# ----------------------------------------------------------------------
# T8 -- Infinance: T(r)=0 below K_c; CF ladder = ordering without functional
# ----------------------------------------------------------------------
def transmission(r):
    """Transmitted-value flux proxy: coherent power above noise floor, in-band only."""
    return max(0.0, r**2 - (2*NOISE_FLOOR)**2)

T_below = transmission(r_b)     # from T1's below-wall run
T_inband = transmission(r_i)    # from T1's in-band run

CF_TIER_BOUNDARIES = np.linspace(0.0, K_C, 8)   # 7 tiers on [0, K_c]
N_STAR = 7   # CONFIGURABLE placeholder -- author declaration pending (S7 item 1)
strictly_ordered = bool(np.all(np.diff(CF_TIER_BOUNDARIES) > 0))
top_at_Kc = abs(CF_TIER_BOUNDARIES[-1] - K_C) < 1e-12
# 'ordering without a functional': no transmission is defined on any tier
no_pricing_below = all(transmission(min(3*NOISE_FLOOR, 0.05)) == 0.0
                       for _ in CF_TIER_BOUNDARIES[:-1])

t8_ok = (T_below == 0.0) and (T_inband > 0.0) and strictly_ordered \
        and top_at_Kc and no_pricing_below
report("T8 Infinance: unpriced below K_c, priced in-band; CF ladder ordered, top=K_c",
       t8_ok,
       f"T(below)={T_below:.4f} (=0: real but unpriced); T(in-band)={T_inband:.4f} (>0); "
       f"7 tiers strictly ordered={strictly_ordered}; boundary(T_7)=K_c={top_at_Kc}; "
       f"n*={N_STAR} is a CONFIGURABLE pending ERES-CF-2026-001 declaration")

# ----------------------------------------------------------------------
print("=" * 72)
n_pass = sum(RESULTS)
verdict = "ALL TESTS PASS" if all(RESULTS) else "FAILURES PRESENT"
print(f"RESULT: {n_pass}/{len(RESULTS)} -- {verdict}")
print("DVC note: T1 verifies the inherited DERIVED layer; T5/T7 verify results")
print("derived/stated in ERES-GAIA-GRID-2026-001; T2's economic premise remains")
print("CONJECTURE (implication verified only). Exit 0 iff all pass.")
print("=" * 72)
sys.exit(0 if all(RESULTS) else 1)
