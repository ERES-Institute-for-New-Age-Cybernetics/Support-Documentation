#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES RATE Validation & Principle Suite
Companion to: ERES-ECONOMIC-THEORY-LINEAGE-2026-001 v2.0 (Book Edition)
"Spaceship Economics: The Lineage, the Floor, and the Band"

Author of Record: Joseph Allen Sprute (JAS), ERES Institute for New Age Cybernetics
License: CC-BY 4.0 / CCAL v2.1
Date: July 13, 2026

Purpose
-------
Executable falsifiability for the RATE engine:

    RATE = (CBGMODD x BERA) + FAVORS,  with CBGMODD = min(s_1..s_7)

and the pair-based tier map T(I, F) (floor gate first, band second).

Convention: exit code is the verdict (0 = PASS, 1 = FAIL) for MIEVM / CI use.
PASS = evidence, not proof. CONSTRUCTED tags stay until external reproduction.

Declared policy parameters (bounded, per the 98/2 precedent — the numbers are
policy; their validity formula m* = v_I * tau_gov is derived in Appendix B):
    F_MIN = 0.40   K_LO = 0.40   K_HI = 0.80
"""

import random
import sys

SEED = 20260713
F_MIN, K_LO, K_HI = 0.40, 0.40, 0.80

# ---------------------------------------------------------------- engine ---

def cbgmodd(seats):
    """Composition rule DERIVED from properties (A) capture nullity and
    (B) weakest-link sensitivity: forced to min over the power-mean family."""
    assert len(seats) == 7, "CBGMODD is a seven-seat council"
    assert all(0.0 <= s <= 1.0 for s in seats)
    return min(seats)

def cbgmodd_mean(seats):
    """The REJECTED composition rule, kept only as the discriminating null."""
    return sum(seats) / len(seats)

def rate(I, F):
    return I * F_placeholder(I, F)  # never used; guard against misuse

def compute(seats, bera, favors, rule=cbgmodd):
    assert 0.0 <= bera <= 1.0 and 0.0 <= favors <= 1.0
    I = rule(seats) * bera
    return I, favors, I + favors

def F_placeholder(I, F):
    raise RuntimeError("call compute(); RATE is derived, never set directly")

def tier(I, F):
    """Total, mutually exclusive tier map on the PAIR (I, F).
    Floor gate first (lexicographic), band second. RATE is a summary
    statistic, NOT the decision variable (RATE-degeneracy Proposition)."""
    if F < F_MIN:
        return "BELOW_FLOOR"
    if I < K_LO:
        return "GOOD"
    if I <= K_HI:
        return "SOUND"
    return "BEST_APPROACH"   # upper-wall flag per SHB Corollary 1, not a rank

TIER_ORDER = {"BELOW_FLOOR": 0, "GOOD": 1, "SOUND": 2, "BEST_APPROACH": 3}

# ----------------------------------------------------------------- tests ---

RESULTS = []

def check(name, ok, detail):
    RESULTS.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
    return ok

def t1_greenwash_null():
    """Six seats perfect, one captured. min must zero the institutional term;
    mean must NOT (this is the one-case discrimination between the rules)."""
    seats = [1, 1, 1, 1, 1, 1, 0]
    I_min, F, R = compute(seats, bera=0.9, favors=0.8, rule=cbgmodd)
    I_mean = cbgmodd_mean(seats) * 0.9
    ok = (I_min == 0.0) and (tier(I_min, F) != "SOUND") and (I_mean > K_LO)
    return check("T1 greenwash null", ok,
                 f"min->I={I_min:.3f} tier={tier(I_min, F)} (not SOUND); "
                 f"mean->I={I_mean:.3f} would false-SOUND")

def t2_rate_degeneracy():
    """Two nodes with EQUAL RATE must be able to land in different tiers:
    the tier map does not factor through the sum."""
    A = (0.9, 0.3)   # high institutional, breached floor
    B = (0.5, 0.7)   # in-band institutional, intact floor
    rA, rB = sum(A), sum(B)
    ok = (abs(rA - rB) < 1e-12) and tier(*A) == "BELOW_FLOOR" and tier(*B) == "SOUND"
    return check("T2 RATE-degeneracy pair", ok,
                 f"RATE_A=RATE_B={rA:.2f}; tier(A)={tier(*A)}, tier(B)={tier(*B)}")

def t3_partition_totality():
    """Every (I,F) in the unit square receives exactly one tier."""
    rng = random.Random(SEED)
    for _ in range(100_000):
        I, F = rng.random(), rng.random()
        t = tier(I, F)
        if t not in TIER_ORDER:
            return check("T3 partition totality", False, f"untierable ({I},{F})")
    # boundary points
    for I in (0.0, K_LO, K_HI, 1.0):
        for F in (0.0, F_MIN, 1.0):
            if tier(I, F) not in TIER_ORDER:
                return check("T3 partition totality", False, f"boundary hole ({I},{F})")
    return check("T3 partition totality", True,
                 "100k samples + boundary lattice: exactly one tier each")

def t4_floor_supremacy():
    """F < F_MIN forces BELOW_FLOOR regardless of institutional score —
    no compensation, closing the floor-masking hole."""
    rng = random.Random(SEED + 1)
    for _ in range(10_000):
        I = rng.random()
        F = rng.uniform(0.0, F_MIN - 1e-9)
        if tier(I, F) != "BELOW_FLOOR":
            return check("T4 floor supremacy", False, f"masked at I={I:.3f} F={F:.3f}")
    return check("T4 floor supremacy", True,
                 "10k breached-floor samples: BELOW_FLOOR at every I, incl. I=max")

def t5_monotonicity():
    """T is non-decreasing in each argument under the tier order."""
    rng = random.Random(SEED + 2)
    for _ in range(10_000):
        I1, I2 = sorted((rng.random(), rng.random()))
        F1, F2 = sorted((rng.random(), rng.random()))
        if TIER_ORDER[tier(I2, F1)] < TIER_ORDER[tier(I1, F1)]:
            return check("T5 monotonicity", False, "decreasing in I")
        if TIER_ORDER[tier(I1, F2)] < TIER_ORDER[tier(I1, F1)]:
            return check("T5 monotonicity", False, "decreasing in F")
    return check("T5 monotonicity", True, "10k ordered pairs: non-decreasing in I and F")

def t6_structural_lock():
    """Institutional zero: RATE collapses exactly to F (the additive constant
    survives). Arithmetic identity — confirm-side only; the empirical content
    lives in Prediction P2' (independence axiom), not here."""
    rng = random.Random(SEED + 3)
    for _ in range(1_000):
        F = rng.random()
        I, F_out, R = compute([0, 1, 1, 1, 1, 1, 1], bera=rng.random(), favors=F)
        if abs(R - F) > 1e-12 or I != 0.0:
            return check("T6 structural lock", False, "lock violated")
    return check("T6 structural lock", True,
                 "1k runs: I=0 => RATE == FAVORS exactly (+C survives)")

def t7_worked_examples():
    """Reproduce the v1.2 SRD worked examples, with tier assignment corrected
    to the pair map (Node A: GOOD not merely 'fails SOUND')."""
    IA, FA, RA = compute([1, 1, 1, 1, 1, 1, 0], bera=0.9, favors=0.8)
    IB, FB, RB = compute([0.8] * 7, bera=0.85, favors=0.9)
    ok = (RA == 0.8 and tier(IA, FA) == "GOOD"
          and abs(RB - 1.58) < 1e-12 and tier(IB, FB) == "SOUND")
    return check("T7 worked examples", ok,
                 f"Node A: RATE={RA:.2f} tier={tier(IA, FA)}; "
                 f"Node B: RATE={RB:.2f} tier={tier(IB, FB)}")

def t8_codomain():
    """RATE stays in [0,2]; components in [0,1]; schema bounds hold."""
    rng = random.Random(SEED + 4)
    for _ in range(10_000):
        seats = [rng.random() for _ in range(7)]
        I, F, R = compute(seats, bera=rng.random(), favors=rng.random())
        if not (0.0 <= I <= 1.0 and 0.0 <= F <= 1.0 and 0.0 <= R <= 2.0):
            return check("T8 codomain bounds", False, "out of bounds")
    return check("T8 codomain bounds", True, "10k random nodes: I,F in [0,1], RATE in [0,2]")

# ------------------------------------------------------------------ main ---

if __name__ == "__main__":
    print("=" * 72)
    print("ERES RATE Validation & Principle Suite")
    print("Instrument: ERES-ECONOMIC-THEORY-LINEAGE-2026-001 v2.0 (Book Edition)")
    print(f"Policy parameters: F_MIN={F_MIN}  band=[{K_LO}, {K_HI}]  seed={SEED}")
    print("=" * 72)
    tests = [t1_greenwash_null, t2_rate_degeneracy, t3_partition_totality,
             t4_floor_supremacy, t5_monotonicity, t6_structural_lock,
             t7_worked_examples, t8_codomain]
    passed = sum(bool(t()) for t in tests)
    print("-" * 72)
    verdict = "PASS" if passed == len(tests) else "FAIL"
    print(f"VERDICT: {verdict}  ({passed}/{len(tests)} tests)")
    print("PASS = evidence, not proof. Tags stay CONSTRUCTED until external")
    print("reproduction (MIEVM author-hardware run + real-data P1'/P2'/P3).")
    sys.exit(0 if verdict == "PASS" else 1)
