"""
ERES BERA SPECTRAL-GAP ESTIMATOR  —  wiring the four channels to the SR standard
================================================================================
Replaces the single synthetic x(t) with the four measured BERA channels and an
external Schumann-resonance reference. The critical-moment math is unchanged; only
the source of lambda-hat(t) changes.

    channels  X(t) = [ARI, ERI, RHC, RCI]      (the four BERA resonance metrics)
    reference s(t) = Schumann band-power        (7.83 Hz fundamental + harmonics)

Spectral gap, multivariate form. Fit a 1-step linear map over a rolling window:
        X(t+1) = B X(t) + noise
The leading eigenvalue mu_max(|.|) of B is the multivariate generalization of the
lag-1 autocorrelation. The recovery rate / spectral gap is

        lambda_hat(t) = -ln( mu_max(t) ) / dt          (mu_max -> 1  =>  lambda -> 0)

As the gap closes the system slows critically. Extrapolating the gap g = 1 - mu_max
linearly to zero gives the Critical_MOMENT  t*  before it happens.

The SR reference is the planetary STANDARD: each window's channel power is correlated
against s(t). A break in that coupling is the anomaly the literature reports across
three scales — solar/cosmic events DRIVE the cavity, seismic stress PERTURBS it
locally, human autonomic rhythm COUPLES to it. Same estimator, three scales.

License : CC-BY 4.0
Credits : ERES Institute for New Age Cybernetics (J. A. Sprute, Maestro);
          RCI co-developed with J. D. Butzbach.
References : BERA Measurement Specification v3.1; BERA Disruption Index;
            Alabdulgader et al. 2018 (Sci Rep); Hayakawa et al. (SR seismic precursors);
            Fdez-Arroyabe et al. 2020 (Sci Total Environ).
"""

from __future__ import annotations
import numpy as np


# ----------------------------------------------------------------------------- 
# Multivariate spectral gap from the four BERA channels
# ----------------------------------------------------------------------------- 
def leading_eigenvalue(window: np.ndarray) -> float:
    """mu_max of the VAR(1) map fitted over a window of shape (n, 4)."""
    X0, X1 = window[:-1].T, window[1:].T                 # 4 x (n-1)
    B = X1 @ X0.T @ np.linalg.pinv(X0 @ X0.T)            # 4 x 4 transition matrix
    return float(np.max(np.abs(np.linalg.eigvals(B))))


def sr_coupling(window: np.ndarray, sr_window: np.ndarray) -> float:
    """Coherence of the channels with the Schumann reference (the planetary standard)."""
    chan = window.mean(axis=1) - window.mean()
    sr = sr_window - sr_window.mean()
    denom = np.linalg.norm(chan) * np.linalg.norm(sr)
    return float(chan @ sr / denom) if denom > 0 else 0.0


def gap_series(channels: np.ndarray, sr: np.ndarray, win: int = 60, step: int = 4):
    """Roll the window; return now-index t, mu_max, gap g=1-mu_max, and SR coupling."""
    t, mu, coup = [], [], []
    for s in range(0, len(channels) - win, step):
        t.append(s + win)                                # window end = "now"
        mu.append(leading_eigenvalue(channels[s:s + win]))
        coup.append(sr_coupling(channels[s:s + win], sr[s:s + win]))
    return np.array(t), np.array(mu), 1 - np.array(mu), np.array(coup)


# ----------------------------------------------------------------------------- 
# BERA Disruption Index and the Critical_MOMENT deduction
# ----------------------------------------------------------------------------- 
def bera_disruption_index(gap: np.ndarray, coupling: np.ndarray) -> np.ndarray:
    """
    BDI rises toward 1 as the gap closes AND the SR coupling departs from baseline.
    proxy for spectral-gap closure; the two factors must agree to flag.
    """
    g0 = np.median(gap[: max(3, len(gap) // 4)])         # quiet-period baseline gap
    closing = np.clip(1 - gap / g0, 0, 1)                # 0 quiet -> 1 at the seam
    base_coup = np.median(coupling[: max(3, len(coupling) // 4)])
    decoupling = np.clip(np.abs(coupling - base_coup) / (abs(base_coup) + 1e-6), 0, 1)
    return np.clip(0.5 * closing + 0.5 * closing * decoupling, 0, 1)


def deduce_t_star(t: np.ndarray, gap: np.ndarray, tail: int = 8):
    """Linear-extrapolate the closing gap to zero -> the future critical moment t*."""
    tt, gg = t[-tail:], gap[-tail:]
    slope, intercept = np.polyfit(tt, gg, 1)
    if slope >= 0:                                        # gap not closing -> nothing imminent
        return None
    return -intercept / slope


# ----------------------------------------------------------------------------- 
# Synthetic approach-to-criticality (stands in for a real BERA + SR feed)
# ----------------------------------------------------------------------------- 
def synth(N=620, t_event=520, seed=1):
    rng = np.random.default_rng(seed)
    sr = 1.0 + 0.30 * np.sin(2 * np.pi * np.arange(N) / 40) + 0.05 * rng.standard_normal(N)
    a = np.minimum(0.99, 0.55 + 0.44 * (np.arange(N) / t_event))   # control rises -> mu~1
    X = np.zeros((N, 4))
    for k in range(1, N):
        X[k] = a[k] * X[k - 1] + 0.15 * (sr[k] - 1.0) + 0.10 * rng.standard_normal(4)
    return X, sr, t_event


if __name__ == "__main__":
    X, sr, t_event = synth()
    t, mu, gap, coup = gap_series(X, sr)
    bdi = bera_disruption_index(gap, coup)

    print("ERES BERA spectral-gap estimator  (channels: ARI ERI RHC RCI | ref: SR)")
    print("-" * 70)
    rho_crit = 0.55                                       # warning fires when BDI crosses
    fired = False
    for i in range(8, len(t)):
        if not fired and bdi[i] >= rho_crit:
            t_star = deduce_t_star(t[:i + 1], gap[:i + 1])
            now = t[i]
            print(f"WARNING at now={now}:  BDI={bdi[i]:.2f}  mu_max={mu[i]:.3f}  "
                  f"SR-coupling={coup[i]:+.2f}")
            if t_star:
                print(f"  deduced Critical_MOMENT  t* = {t_star:6.1f}   "
                      f"(true event = {t_event})   lead time = {t_star - now:5.1f} steps")
            fired = True
    print("-" * 70)
    print(f"final gap={gap[-1]:.3f}  mu_max={mu[-1]:.3f}  -> gap closing toward the seam")
