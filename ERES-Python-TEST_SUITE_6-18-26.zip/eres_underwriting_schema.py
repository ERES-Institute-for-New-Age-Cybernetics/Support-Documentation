"""
ERES UNDERWRITING SCHEMA  —  for the underwriting lane (Alexiou / GAIA)
================================================================================
A structured, auditable schema that RECEIVES a SOUND risk (the validated-indicator
hand-off from the understanding lane) and produces an underwriting decision. It
enforces the one rule that protects the whole pipeline:

        you cannot underwrite what you have not first made SOUND.

This is the actuarial scaffold the Global Actuary Investor Authority (GAIA, per
ERES Central Focus v3.1 Title VII Sec.702) would operate. It encodes no legal or
jurisdictional content — the TALONICS seating surface, enforceability, and treaty
form belong to EMA's own instruments. Pricing here is SCHEMATIC and CONSTRUCTED,
not real actuarial pricing; it shows the decision structure, not a rate book.

License : CC-BY 4.0   |   ERES Institute (J. A. Sprute, Maestro)
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum


class Band(str, Enum):
    GOOD = "GOOD"; SOUND = "SOUND"; BEST = "BEST"; UNRATED = "UNRATED"


# ----------------------------------------------------------------------------- 
# The hand-off artifact from the understanding lane (Pellis -> EMA)
# ----------------------------------------------------------------------------- 
@dataclass
class SoundRisk:
    risk_id: str
    exposure: float                 # R — capital / interest at stake
    mechanism: float                # P in [0,1] — established-mechanism strength
    validated: bool                 # did a pre-registered forecast PASS?
    lead_time_mean: float           # steps/time of warning before the event
    lead_time_ci: tuple             # (low, high) from the bootstrap
    false_positive_rate: float      # measured on matched controls

    def band(self) -> Band:
        """A risk is SOUND only once its mechanism is validated; else GOOD (or UNRATED)."""
        if self.exposure <= 0 or self.mechanism <= 0:
            return Band.UNRATED                     # no genuine two-pole risk object
        if self.validated and self.mechanism >= 0.5 and self.lead_time_mean > 0:
            return Band.SOUND
        return Band.GOOD


# ----------------------------------------------------------------------------- 
# The seating choice (stable vs unstable) sets Method-cost M
# ----------------------------------------------------------------------------- 
@dataclass
class Seat:
    name: str
    stable: bool                    # stable (triangular) seats are cheap to hold

    def method_cost(self) -> float:
        return 1.0 if self.stable else 6.0          # M: held cheaply vs continuously renewed


# ----------------------------------------------------------------------------- 
# The underwriting decision
# ----------------------------------------------------------------------------- 
@dataclass
class UnderwritingDecision:
    risk: SoundRisk
    seat: Seat
    fiduciary: str                  # the always-assigned backer (the stable seat holder)
    accrual_backing: float          # value pooled at the seat (Meritcoin / reserve)
    reserve_margin: float = 0.25    # fraction added on top of lead time for the reserve window

    # --- gate ---
    def admissible(self) -> tuple[bool, str]:
        b = self.risk.band()
        if b in (Band.UNRATED, Band.GOOD):
            return False, f"refused: risk is {b.value}, not SOUND — cannot underwrite (make it SOUND first)"
        if self.risk.false_positive_rate > 0.25:
            return False, f"refused: false-positive rate {self.risk.false_positive_rate:.2f} too high to price"
        return True, "admissible"

    # --- rating C = R x P / M ---
    def rating(self) -> float:
        return self.risk.exposure * self.risk.mechanism / self.seat.method_cost()

    def graded_band(self) -> Band:
        ok, _ = self.admissible()
        if not ok:
            return self.risk.band()
        # seated and admissible -> BEST only if the seat is stable (M minimized)
        return Band.BEST if self.seat.stable else Band.SOUND

    def reserve_window(self) -> float:
        """How far ahead reserves must be positioned = lead time + margin."""
        return self.risk.lead_time_mean * (1 + self.reserve_margin)

    def decision_record(self) -> dict:
        ok, why = self.admissible()
        return {
            "risk_id": self.risk.risk_id,
            "incoming_band": self.risk.band().value,
            "admissible": ok,
            "rationale": why,
            "rating_C": round(self.rating(), 3) if ok else None,
            "graded_band": self.graded_band().value,
            "seat": f"{self.seat.name} ({'stable' if self.seat.stable else 'unstable'})",
            "method_cost_M": self.seat.method_cost(),
            "fiduciary": self.fiduciary,
            "reserve_window": round(self.reserve_window(), 1) if ok else None,
            "accrual_backing": self.accrual_backing if ok else None,
            "lead_time": f"{self.risk.lead_time_mean} (CI {self.risk.lead_time_ci})",
        }

    def render(self) -> str:
        r = self.decision_record()
        lines = [f"UNDERWRITING RECORD — {r['risk_id']}",
                 f"  incoming band : {r['incoming_band']}",
                 f"  admissible    : {r['admissible']}  ({r['rationale']})"]
        if r["admissible"]:
            lines += [f"  rating C=RxP/M: {r['rating_C']}    graded band: {r['graded_band']}",
                      f"  seat / M      : {r['seat']}  /  M={r['method_cost_M']}",
                      f"  fiduciary     : {r['fiduciary']}",
                      f"  reserve window: {r['reserve_window']}   (lead time {r['lead_time']})",
                      f"  accrual back. : {r['accrual_backing']}"]
        return "\n".join(lines)


def blank_template() -> str:
    """An empty record for EMA to populate within TALONICS instruments."""
    return (
        "UNDERWRITING RECORD — <risk_id>\n"
        "  incoming SOUND artifact : <validated-indicator id, lead-time, FP-rate>\n"
        "  jurisdictional seat     : <TALONICS surface — EMA instrument>\n"
        "  fiduciary backer        : <always-assigned stable-seat holder>\n"
        "  reserve window          : <lead_time x (1+margin)>\n"
        "  accrual backing         : <Meritcoin / reserve pooled at seat>\n"
        "  rating C = R x P / M    : <exposure x mechanism / method-cost>\n"
        "  graded band             : <SOUND -> BEST once seated stably>\n"
    )


# ----------------------------------------------------------------------------- 
# Demonstration: a SOUND risk underwritten; an un-SOUND risk refused
# ----------------------------------------------------------------------------- 
if __name__ == "__main__":
    print("ERES Underwriting Schema  (gate: SOUND before BEST)\n" + "-" * 60)

    sound = SoundRisk(risk_id="RISK-A", exposure=8.0, mechanism=0.8, validated=True,
                      lead_time_mean=22.0, lead_time_ci=(15.0, 30.0), false_positive_rate=0.05)
    decision = UnderwritingDecision(sound, Seat("triangular-stable", stable=True),
                                    fiduciary="always-assigned Dignitary seat",
                                    accrual_backing=4.0)
    print(decision.render())

    print("-" * 60)
    not_sound = SoundRisk(risk_id="RISK-B", exposure=8.0, mechanism=0.8, validated=False,
                          lead_time_mean=22.0, lead_time_ci=(0, 0), false_positive_rate=0.05)
    refused = UnderwritingDecision(not_sound, Seat("unstable", stable=False),
                                   fiduciary="—", accrual_backing=0.0)
    print(refused.render())

    print("-" * 60)
    print("BLANK TEMPLATE (populate within TALONICS):\n")
    print(blank_template())
