"""
ERES APPARATUS  —  the third-seat transmission function  f : Duality -> IT
================================================================================
The apparatus is the third seat that completes an ordered pair (Action/Reaction,
Cause/Effect). It is not a pole; it is the contact-point made operational — the
mechanism through which two poles transmit. In the equation it is the Method (M)
and, read as a system, Cybernetics (C) itself:

        C = R x P / M      (Cybernetics = Resource x Purpose / Method)

    R  Resource : the two-body product of two GENUINE, OPPOSED poles
    P  Purpose  : the bidirection X (intact = 1.0, crossed-out/one-way = 0.0)
    M  Method   : station-keeping cost of the seat the third lands on

The apparatus delivers IT — the externalized, observable actual: the duality
made into a thing. Seated on a stable triangular point (L4/L5) IT accrues value
(Meritcoin); seated on the unstable collinear axis (L1/L2/L3) IT decays by the
half-life of ABLE (CA_n) unless re-energized by TEACH.

Incoherence is just a missing requirement — each failure branch below is one of
the six exhibits: a missing pole, mismatched poles, or a broken bidirection.

License : CC-BY 4.0
Credits : ERES Institute for New Age Cybernetics (J. A. Sprute, Maestro)
References : ERES Triune Math (C=RxP/M); Lagrange-point trifurcation model;
            CA_n half-life of ABLE; BERA / GraceChain renewal.
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math


# ----------------------------------------------------------------------------- 
# Poles and the duality (Resource R, Purpose P)
# ----------------------------------------------------------------------------- 
@dataclass(frozen=True)
class Pole:
    name: str
    charge: float            # sign = polarity; |charge| = strength (Resource contribution)


@dataclass(frozen=True)
class Duality:
    a: Pole
    b: Pole
    bidirection: float       # the X. 1.0 = Purpose intact, 0.0 = crossed-out / one-way

    def resource(self) -> float:
        """R = two-body product, but ONLY for genuinely opposed poles (opposite signs)."""
        if self.a.charge * self.b.charge >= 0:      # same sign or a zero -> not a real duality
            return 0.0
        return abs(self.a.charge) * abs(self.b.charge)

    def purpose(self) -> float:
        """P = bidirection X, clamped to [0, 1]. Broken/one-way -> 0."""
        return max(0.0, min(1.0, self.bidirection))


# ----------------------------------------------------------------------------- 
# Lagrange seats — where the third can hold
# ----------------------------------------------------------------------------- 
class Seat(Enum):
    L1 = "L1"; L2 = "L2"; L3 = "L3"     # collinear, UNSTABLE -> station-keeping (high M)
    L4 = "L4"; L5 = "L5"                # triangular, STABLE  -> value accrues (M minimal)
    NONE = "NONE"                       # no seat forms -> incoherent, IT escapes

STABLE = {Seat.L4, Seat.L5}

# Method-cost M per seat: stable seats are cheap to hold; collinear seats burn to hold.
METHOD_COST = {Seat.L4: 1.0, Seat.L5: 1.0, Seat.L1: 4.0, Seat.L2: 6.0, Seat.L3: 9.0}


# ----------------------------------------------------------------------------- 
# IT — the delivered actual
# ----------------------------------------------------------------------------- 
@dataclass
class IT:
    realized: bool           # did the apparatus deliver, or did the third escape?
    seat: Seat
    C: float                 # Cybernetics value = R x P / M
    grade: float             # mapped onto the Ref-Del 8.5-10 band (0 if incoherent)
    band: str                # GOOD / SOUND / BEST   (or INCOHERENT)
    accrues: bool            # True at stable seats (Meritcoin); False if it must be renewed
    note: str

    def __str__(self) -> str:
        if not self.realized:
            return f"IT(--escaped--)  {self.note}"
        tag = "accrues" if self.accrues else "decays (needs TEACH)"
        return (f"IT[{self.band:>10}]  seat={self.seat.value}  "
                f"C={self.C:6.3f}  grade={self.grade:5.2f}/10  {tag}")


# ----------------------------------------------------------------------------- 
# Coherence gate — the three requirements (failures = Exhibits A-F)
# ----------------------------------------------------------------------------- 
def diagnose(d: Duality) -> tuple[bool, str]:
    if d.a.charge == 0 or d.b.charge == 0:
        return False, "missing pole (Exhibit C)"
    if d.a.charge * d.b.charge > 0:
        return False, "poles not opposed (Exhibits A/B)"
    if d.purpose() <= 0:
        return False, "bidirection crossed out (Exhibit F)"
    return True, "coherent"


# ----------------------------------------------------------------------------- 
# Seat selection — choose the seat that MINIMIZES M (Best is the cheapest hold)
# ----------------------------------------------------------------------------- 
def choose_seat(d: Duality) -> Seat:
    balance = min(abs(d.a.charge), abs(d.b.charge)) / max(abs(d.a.charge), abs(d.b.charge))
    if balance >= 0.6 and d.purpose() >= 0.8:
        return Seat.L4                  # strong, balanced, fully bidirected -> stable seat
    if balance >= 0.3:
        return Seat.L1                  # holds, but on the unstable axis -> renewal needed
    return Seat.L3                      # lopsided -> furthest unstable seat, highest M


def grade(C: float) -> tuple[float, str]:
    """Map cybernetic value onto the 8.5-10 Ref-Del band; saturates toward 10 (Best)."""
    g = 8.5 + 1.5 * (1 - math.exp(-C / 6.0))
    band = "BEST" if g >= 9.5 else "SOUND" if g >= 9.0 else "GOOD"
    return round(g, 2), band


# ----------------------------------------------------------------------------- 
# THE APPARATUS  —  f
# ----------------------------------------------------------------------------- 
def apparatus(d: Duality) -> IT:
    """f : Duality -> IT.  Transmit the pair through the contact-point; deliver the actual."""
    ok, reason = diagnose(d)
    if not ok:
        return IT(False, Seat.NONE, 0.0, 0.0, "INCOHERENT", False, f"IT escapes: {reason}")

    seat = choose_seat(d)
    R, P, M = d.resource(), d.purpose(), METHOD_COST[seat]
    C = R * P / M
    g, band = grade(C)
    accrues = seat in STABLE
    note = ("stable seat: value accrues (Meritcoin)" if accrues
            else "unstable axis: decays unless renewed (TEACH)")
    return IT(True, seat, round(C, 3), g, band, accrues, note)


f = apparatus          # the function, as f


# ----------------------------------------------------------------------------- 
# CA_n decay and TEACH renewal
# ----------------------------------------------------------------------------- 
def ca_n(value: float, half_lives: float) -> float:
    """Half-life of ABLE: capability on an unstable seat decays as value * (1/2)**n."""
    return value * (0.5 ** half_lives)


def teach(it: IT, energy: float) -> IT:
    """Re-supply the Why: TEACH re-energizes an unstable seat, resetting CA_n for the cycle."""
    if it.accrues:
        return it                      # stable seats hold themselves; no teaching needed
    return IT(it.realized, it.seat, it.C, round(min(10.0, it.grade + energy), 2),
              it.band, it.accrues, "renewed via TEACH; CA_n reset this cycle")


# ----------------------------------------------------------------------------- 
# Demonstration
# ----------------------------------------------------------------------------- 
if __name__ == "__main__":
    print("ERES Apparatus  f : Duality -> IT\n" + "-" * 60)

    action_reaction = Duality(Pole("Action", +5.0), Pole("Reaction", -5.0), 1.0)
    cause_effect    = Duality(Pole("Cause",  +6.0), Pole("Effect",   -3.0), 0.9)
    x_crossed_out   = Duality(Pole("Action", +5.0), Pole("Reaction", -5.0), 0.0)
    not_opposed     = Duality(Pole("phi",    +4.0), Pole("Omega?",   +4.0), 1.0)

    print("Action<->Reaction   ", f(action_reaction))
    print("Cause<->Effect      ", f(cause_effect))
    print("X crossed out       ", f(x_crossed_out))
    print("poles not opposed   ", f(not_opposed))

    print("-" * 60)
    it = f(cause_effect)
    print("Cause<->Effect decays:", round(it.grade, 2),
          "-> after 2 half-lives:", round(ca_n(it.grade, 2), 2))
    print("Cause<->Effect + TEACH:", teach(it, energy=0.5))
