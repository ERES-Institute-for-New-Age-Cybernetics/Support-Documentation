#!/usr/bin/env python3
# =============================================================================
# ERES-GSSG-RAMPUP-2026-001  v0.1 DRAFT
# Executable ramp-up model: From Prisons to DeepSpace (Bottom-Up/Top-Down)
# Implements the PROPOSED math of ERES-GSSG-MATH-2026-001 v0.1
# Author: Joseph Allen Sprute (ERES Maestro) | Drafting instrument: Claude (MIEVM)
# License: CCAL v2.1 (CC-BY 4.0 compatible)
# Status: DRAFT — numbers illustrative; pending JAS ratification / MIEVM pass
# =============================================================================

import math
from dataclasses import dataclass

# ---------------------------- LOCKED CANON ----------------------------------
def earned_path(cpm: float, wbs: float, pert: float) -> float:
    """EP = CPM x WBS + PERT  (locked)"""
    return cpm * wbs + pert

def proof_of_resonance(a: float, r: float, p: float, f: float) -> float:
    """PoR = A x R x P x F  (locked, conjunctive: any zero -> zero)"""
    return a * r * p * f

def rci(p_omega_norm: float, ari_sys: float, vib_const: float) -> float:
    """RCI = P_Omega_norm x ARI_sys x VibConst  (locked)"""
    return p_omega_norm * ari_sys * vib_const

# ------------------------- PROPOSED v0.1 MODELS ------------------------------
def service_life(l0_years: float, f_reservoir: float, eta: float) -> float:
    """Sugar-Carbon Reservoir healing: L = L0 / (1 - f*eta), f*eta < 1"""
    return l0_years / (1.0 - f_reservoir * eta)

def dome(radius_m: float, thickness_m: float = 0.10, rho: float = 2200.0,
         pv_fraction: float = 0.30, pv_eff: float = 0.10,
         insolation_kwh_m2_yr: float = 2200.0):
    """Hemispherical GSSG dome: square-cube advantage A/V = 3/r"""
    area = 2 * math.pi * radius_m**2
    volume = (2/3) * math.pi * radius_m**3
    mass_kg = area * thickness_m * rho
    energy_gwh = area * pv_fraction * pv_eff * insolation_kwh_m2_yr / 1e6
    return dict(area_km2=area/1e6, volume_km3=volume/1e9,
                mass_Mt=mass_kg/1e9, energy_GWh_yr=energy_gwh,
                a_over_v=3/radius_m)

def rent(abundance: float, c_production: float = 1.0) -> float:
    """Economic Flip: P_extraction ~ 1/Abundance; Rent -> 0 as abundance grows"""
    return max((1.0/abundance) * 100.0 - c_production, 0.0)

def conflict_payoff(rent_val: float, p_capture: float = 0.5,
                    cost: float = 10.0) -> float:
    """IAM/IOF redemption term: E[conflict] = Rent*P(capture) - Cost"""
    return rent_val * p_capture - cost

def wrights_law(unit_cost0: float, cum_units: float, b: float = 0.32) -> float:
    """Learning curve: cost falls ~20%/doubling (b=0.32)"""
    return unit_cost0 * max(cum_units, 1.0) ** (-b)

# ------------------------------ RAMP-UP PHASES -------------------------------
@dataclass
class Phase:
    name: str
    years: str
    workforce: int        # NPR participants credentialed via EarnedPath
    output_kt_yr: float   # GSSG output, kilotonnes/year
    milestone: str

PHASES = [
    Phase("P0  Pilot (single NPR facility)",  "2027-2028",     150,     0.5,
          "First EarnedPath cohort; PoR audit chain live"),
    Phase("P1  Regional (5 facilities)",       "2029-2031",   1_200,     8.0,
          "Wright's-law cost decline visible; CCAL supply chain"),
    Phase("P2  First dome (r = 250 m)",        "2032-2035",   6_000,    60.0,
          "Terrestrial proof: agriculture + habitat under GSSG"),
    Phase("P3  Giant dome network (r = 1 km)", "2036-2045",  40_000,   600.0,
          "Empty Quarter feedstock-to-city; Rent -> 0 regionally"),
    Phase("P4  DeepSpace qualification",       "2046+",      25_000,   300.0,
          "f*eta certified; habitat glazing where no crew can reach"),
]

def main():
    print("=" * 78)
    print("ERES-GSSG-RAMPUP-2026-001 v0.1 DRAFT — From Prisons to DeepSpace")
    print("=" * 78)

    # --- Bottom-Up: one credentialed producer, illustrative units ---
    ep  = earned_path(cpm=0.9, wbs=12, pert=6.5)         # 12-node WBS mastery
    por = proof_of_resonance(a=0.95, r=0.90, p=0.92, f=0.97)
    print(f"\n[BOTTOM-UP] EarnedPath EP = 0.9x12 + 6.5 = {ep:.2f} merit-units")
    print(f"[BOTTOM-UP] PoR = 0.95x0.90x0.92x0.97 = {por:.3f} (conjunctive)")
    print(f"            -> zero any factor and PoR = "
          f"{proof_of_resonance(0.95, 0.0, 0.92, 0.97):.3f}: no faking product")

    # --- Material: self-healing service life ---
    L = service_life(l0_years=50, f_reservoir=0.15, eta=0.60)
    print(f"\n[MATERIAL]  L = 50/(1 - 0.15x0.60) = {L:.1f} yr "
          f"(+{(L/50-1)*100:.0f}% vs unhealed)")

    # --- Top-Down: dome geometry, square-cube advantage ---
    print("\n[TOP-DOWN]  Dome scaling (A/V = 3/r — bigger is cheaper per m3):")
    for r_m in (250, 1000, 4000):
        d = dome(r_m)
        print(f"   r={r_m:>4} m | envelope {d['area_km2']:7.2f} km2 | "
              f"GSSG {d['mass_Mt']:7.2f} Mt | {d['energy_GWh_yr']:8.0f} GWh/yr | "
              f"A/V={d['a_over_v']:.4f}")

    # --- Economic Flip + IAM/IOF redemption term ---
    print("\n[FLIP]      Abundance -> Rent -> E[conflict payoff]:")
    for ab in (1, 10, 100, 1000):
        rv = rent(ab)
        print(f"   Abundance x{ab:>4} | Rent = {rv:7.2f} | "
              f"E[conflict] = {conflict_payoff(rv):7.2f}"
              + ("   <- conflict economically irrational" 
                 if conflict_payoff(rv) < 0 else ""))

    # --- Phased ramp with Wright's-law unit cost ---
    print("\n[RAMP-UP]   Phases (workforce = NPR/EarnedPath credentialed):")
    cum_kt, cost0 = 0.0, 100.0
    for ph in PHASES:
        cum_kt += ph.output_kt_yr
        uc = wrights_law(cost0, cum_kt)
        print(f"   {ph.name:<36} {ph.years:<10} wf={ph.workforce:>6,} "
              f"out={ph.output_kt_yr:>6.1f} kt/yr  unit-cost={uc:5.1f}")
        print(f"      -> {ph.milestone}")

    print("\n" + "=" * 78)
    print("Sand becomes shelter. Prisoners become producers. "
          "Rivals become co-validators.")
    print("Redemption, engineered — not preached.   [CCAL v2.1 | DRAFT v0.1]")
    print("=" * 78)

if __name__ == "__main__":
    main()
