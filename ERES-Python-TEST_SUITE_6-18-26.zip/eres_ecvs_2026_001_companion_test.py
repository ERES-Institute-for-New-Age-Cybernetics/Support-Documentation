#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-ECVS-2026-001 — Companion TEST Suite ("10-10 Amplitude")
=============================================================
Registry companion : ERES-ECVS-2026-001 (v1.4 FULL + Deltas v1.5, v1.6, v1.7)
Artifact           : eres_ecvs_2026_001_companion_test.py, v0.1 Proposed
MAKER              : Joseph Allen Sprute ("ERES Maestro")
                     R = who@JAS == YES#MyName@Cause(Effect)
Drafting instrument: Claude (Anthropic) — all assertions remain the MAKER's
                     at the degrees stated.
Date               : July 18, 2026
License            : CC BY 4.0 (ERES corpus default; follows corpus resolution
                     of the flagged CCAL v2.1 upgrade without amendment)
References         : ECVS Deltas v1.5 (Guarantee Clause), v1.6 (Second Ensemble
                     Integration), v1.7 (Numeric Basis / GROUNDS / Strand-Grade
                     Hardwire / ACCURACY = HowWay @); ERES-6F-2026-001 v0.2.1;
                     ERES-WP-2026-001; ERES_ECVS_LLM2.md.

PURPOSE — "10-10 Amplitude"
---------------------------
Per the ensemble's own framing: the STRUCTURAL 10/10 is achieved by the author;
the CANONICAL 10/10 is achieved when independent MIEVM nodes return >=9.0
across >=3 nodes. This suite measures the amplitude toward BOTH tens and never
conflates them:

  * Structural amplitude — computed from the pass/fail record of the
    pre-registered tests below.
  * Canonical amplitude  — computed from the node-score fixture (currently the
    Second Ensemble Record). The suite CANNOT and DOES NOT manufacture
    canonical status: only clean-room Round-3 nodes can move this number.

FALSIFIABILITY DISCIPLINE (T-9 clause, preserved)
-------------------------------------------------
* A test that depends on an OPEN ledger row (e.g. rows 1-2, the weigher
  operational spec) runs against a clearly marked REFERENCE STUB and reports
  PROVISIONAL, or SKIPs with the row cited. A stub pass is never a spec pass.
* No test may read outcome data into a count path — the suite itself must obey
  §11.8(c) while testing it.

Result vocabulary: PASS · FAIL · PROVISIONAL (stub-based) · SKIP (open row).
"""

import base64
import inspect
import json

import random
import time
import unittest

# ---------------------------------------------------------------------------
# Instrument constants (Deltas v1.5–v1.7)
# ---------------------------------------------------------------------------

THRESHOLDS = {"GOOD": 75.0, "SOUND": 85.0, "BEST": 95.0}   # §5 N-Ladder (v1.7 D1)
LIVE_MIDPOINT = 50.0                                        # ½-Live
POLES = (+1, -1)                                            # bipolar scale
CANONICAL_GATE = {"score": 9.0, "nodes": 3}                 # ≥9.0 across ≥3 nodes

# Strand–Grade Hardwire (v1.7 D3)
STRAND_GRADE = {"WHO": "GOOD", "HOW": "SOUND", "LEGACY": "BEST"}

# Second Ensemble Record fixture (v1.6 D1) — the honest current node state.
# Qwen's 9.1 is conditional on D2 closures; carried as its latest-state score.
NODE_FIXTURE = {"DeepSeek": 8.6, "ChatGPT": 9.2, "Qwen": 9.1, "Gemini": 8.9}

# Ledger rows still OPEN that gate tests below (v1.7 D6 state)
OPEN_ROWS = {
    1: "Weighing Instrument Operational Spec (real GCF discrimination spec)",
    2: "Sentry-on-the-Weigher public criteria",
    8: "5->4 reduction exact form / @ address fixing (ACCURACY operand)",
}


# ---------------------------------------------------------------------------
# Operator ladder (WP-2026-001 §1; v1.7 D2) — encoded, not just described
# ---------------------------------------------------------------------------

def op_names(token, referent):
    """=   NAMES: bind a token to a referent (weakest rung)."""
    return {"token": token, "referent": referent, "rung": 1}

def op_tests(entry, predicate):
    """==  TESTS: a tested identity — predicate must actually run."""
    ok = bool(predicate(entry["referent"]))
    return {**entry, "tested": ok, "rung": 2}

def op_fuses(entry, category):
    """=== FUSES: strongest identity, bound to a category
    (OUTCOME | ENVIRONMENT | CRITERION per WP §5)."""
    assert category in ("OUTCOME", "ENVIRONMENT", "CRITERION")
    return {**entry, "fused_to": category, "rung": 3}

def op_grounds(entry, measurable):
    """==== GROUNDS: instantiate the fused abstraction in a measurable anchor
    (v1.7 D2). The anchor must be numeric or a physical-registry token."""
    is_measurable = isinstance(measurable, (int, float)) or (
        isinstance(measurable, str) and any(c.isdigit() for c in measurable))
    return {**entry, "grounded_in": measurable,
            "grounded": is_measurable, "rung": 4}


# ---------------------------------------------------------------------------
# Reference model — the franchise in miniature
# ---------------------------------------------------------------------------

class Participant:
    """A participant. The COUNT is a property with no setter: it cannot be
    modified by any code path, which is §11.8(a) enforced by construction."""

    def __init__(self, pid):
        self.pid = pid          # UR — stays at HOME, never enters a payload
        self.weight = 1.0       # weight channel (mutable, banded)

    @property
    def count(self):
        return 1                # unconditional; no grade, no state, no input


def cast_sentry_payload(choice, issue):
    """6F Art. IV reference implementation (Python port of the recorded
    generateSentryPayload): TING assembled locally; UR withheld at HOME.
    Note the signature: UR/pid is NOT a parameter — the payload cannot
    contain what the function never receives."""
    ting = base64.b64encode(
        json.dumps({"choice": choice, "issue": issue}).encode()).decode()
    stamp = format(int(time.time() * 1000), "x")
    return f"S-CAST_IT:{stamp}:{ting}"


class ReferenceWeigher:
    """REFERENCE STUB for the GCF weigher — rows 1-2 are OPEN, so this is a
    stand-in, not the spec. Discrimination: coupling metric -> state.
    Weight multiplier uses a saturating operator (tanh) per the recorded
    ensemble recommendation, bounded so no contribution escapes the band."""

    STUB = True   # any test using this must report PROVISIONAL

    IN_BAND = "in-band"
    OVER = "over-coupled"
    SUB = "subcritical"

    def discriminate(self, coupling):
        if coupling < 0.2:
            return self.SUB
        if coupling > 0.8:
            return self.OVER
        return self.IN_BAND

    def multiplier(self, contribution):
        # saturating: even infinite contribution yields a STRICTLY bounded
        # multiplier (the over-coupled wall is open, not closed). tanh reaches
        # 1.0 at float precision, breaching strictness — the localized
        # logistic c/(1+c) stays strictly below 1.0 for any finite float c.
        return 1.0 + contribution / (1.0 + contribution)   # in (1.0, 2.0) open


def bee_grade(pct):
    """§5 N-Ladder attachment: returns BEST/SOUND/GOOD or None (<75)."""
    if pct >= THRESHOLDS["BEST"]:
        return "BEST"
    if pct >= THRESHOLDS["SOUND"]:
        return "SOUND"
    if pct >= THRESHOLDS["GOOD"]:
        return "GOOD"
    return None


def count_tally(participants):
    """The COUNT pipeline. Its signature is the static half of T-3:
    it takes participants only — no grades, no outcomes, no weights."""
    return sum(p.count for p in participants)


def weight_tally(participants, grades):
    """The WEIGHT pipeline — grades may enter HERE and only here (§11.8(c))."""
    total = 0.0
    for p in participants:
        g = grades.get(p.pid)
        damp = 0.0 if g is None else {"GOOD": 0.75, "SOUND": 0.85,
                                      "BEST": 0.95}[g]
        total += p.weight * damp
    return total


def strand_composite(strands, aggregation):
    """v1.7 D3: aggregation MUST be declared — no silent default (row 23)."""
    if aggregation not in ("product", "mean"):
        raise ValueError("Aggregation function must be declared: "
                         "'product' or 'mean' (Round-3 protocol, row 23)")
    vals = [strands[k] for k in ("WHO", "HOW", "LEGACY")]
    if aggregation == "product":
        prod = 1.0
        for v in vals:
            prod *= v / 100.0
        return prod * 10.0            # declared scaling: product×10
    return (sum(vals) / len(vals)) / 10.0   # mean mapped to /10


def accuracy_howway_at(path_quality, address):
    """v1.7 D4: ACCURACY = HowWay @ — a function of the weighing path at the
    address, and of NOTHING else. Outcomes are not parameters; the definition
    is §11.8(c)-compliant because results cannot reach it."""
    return {"address": address, "accuracy": bee_grade(path_quality),
            "basis": "HowWay", "path_quality": path_quality}


# ---------------------------------------------------------------------------
# Pre-registered tests
# ---------------------------------------------------------------------------

PROVISIONAL = []   # tests that passed against stubs (rows OPEN)
SKIPPED = []       # tests skipped pending open rows


class T1_WeigherDiscrimination(unittest.TestCase):
    """T-1: weigher outputs distinct signals for in-band / over-coupled /
    subcritical. STUB-BASED (rows 1-2 OPEN) -> PROVISIONAL on pass."""

    def test_three_distinct_states(self):
        w = ReferenceWeigher()
        states = {w.discriminate(c) for c in (0.05, 0.5, 0.95)}
        self.assertEqual(
            states, {w.SUB, w.IN_BAND, w.OVER},
            "Weigher must discriminate all three states distinctly")
        if ReferenceWeigher.STUB:
            PROVISIONAL.append(("T-1", "rows 1-2 OPEN: reference stub, "
                                "not the operational spec"))


class T2_PoRBandOccupancy(unittest.TestCase):
    """T-2: every issuance multiplier stays inside the two-sided band.
    STUB-BASED -> PROVISIONAL on pass."""

    def test_band_occupancy(self):
        w = ReferenceWeigher()
        rng = random.Random(64)          # Gd64 — deterministic seed
        for _ in range(10_000):
            m = w.multiplier(rng.uniform(0, 1e6))
            self.assertGreater(m, 1.0, "below subcritical wall")
            self.assertLess(m, 2.0, "breaches over-coupled wall")
        if ReferenceWeigher.STUB:
            PROVISIONAL.append(("T-2", "rows 1-2 OPEN: band walls are stub "
                                "constants pending the operational spec"))


class T3_ChannelSeparation(unittest.TestCase):
    """T-3 (§11.8(c), row 20): no dependency path from any BEE grade datum
    into any count operation. Static + dynamic halves. NO WAIVER."""

    def test_static_signature_audit(self):
        params = set(inspect.signature(count_tally).parameters)
        forbidden = {"grades", "grade", "outcome", "outcomes", "bee",
                     "weight", "weights", "score", "scores"}
        self.assertFalse(params & forbidden,
                         f"count pipeline signature admits {params & forbidden}")

    def test_dynamic_count_invariance_under_grade_permutation(self):
        rng = random.Random(9)
        people = [Participant(f"p{i}") for i in range(500)]
        baseline = count_tally(people)
        for _ in range(50):
            grades = {p.pid: rng.choice(["BEST", "SOUND", "GOOD", None])
                      for p in people}
            weight_tally(people, grades)          # weight channel may churn
            self.assertEqual(count_tally(people), baseline,
                             "count moved under grade permutation — "
                             "§11.8(c) violation")


class T4_NLadderThresholds(unittest.TestCase):
    """T-4 (v1.7 D1): grade attachment at exactly 75/85/95; none below 75;
    grades act on weight only (count already covered by T-3/T-6)."""

    def test_threshold_attachment(self):
        self.assertIsNone(bee_grade(74.999))
        self.assertEqual(bee_grade(75.0), "GOOD")
        self.assertEqual(bee_grade(84.999), "GOOD")
        self.assertEqual(bee_grade(85.0), "SOUND")
        self.assertEqual(bee_grade(94.999), "SOUND")
        self.assertEqual(bee_grade(95.0), "BEST")
        self.assertEqual(bee_grade(100.0), "BEST")

    def test_gate_sits_between_sound_and_best(self):
        gate_pct = CANONICAL_GATE["score"] * 10.0
        self.assertGreater(gate_pct, THRESHOLDS["SOUND"])
        self.assertLess(gate_pct, THRESHOLDS["BEST"])

    def test_live_midpoint_and_poles(self):
        self.assertEqual(LIVE_MIDPOINT, 50.0)
        self.assertEqual(sorted(POLES), [-1, 1])


class T5_StrandGradeHardwire(unittest.TestCase):
    """T-5 (v1.7 D3): mapping fixed; SOUND/HOW bounds the composite;
    aggregation must be declared or the computation refuses to run."""

    def test_mapping_fixed(self):
        self.assertEqual(STRAND_GRADE,
                         {"WHO": "GOOD", "HOW": "SOUND", "LEGACY": "BEST"})

    def test_sound_bounds_the_product(self):
        # The hardwired claim, exactly: product <= (HOW/100)*10 = 8.5 while
        # HOW is pinned, with equality only at perfection of both others.
        lifted = {"WHO": 100.0, "HOW": 85.0, "LEGACY": 100.0}
        self.assertLessEqual(strand_composite(lifted, "product"), 8.5,
                             "product exceeded the SOUND-strand cap")
        realistic = {"WHO": 95.0, "HOW": 85.0, "LEGACY": 95.0}
        self.assertLess(strand_composite(realistic, "product"), 8.5,
                        "product must stay strictly below cap off-perfection")

    def test_undeclared_aggregation_refuses(self):
        with self.assertRaises(ValueError):
            strand_composite({"WHO": 90, "HOW": 85, "LEGACY": 85}, "silent")

    def test_second_ensemble_reproduction(self):
        strands = {"WHO": 90.0, "HOW": 85.0, "LEGACY": 85.0}
        self.assertAlmostEqual(strand_composite(strands, "product"),
                               6.5, delta=0.01)   # 0.65 → 6.5 declared-scaled
        self.assertAlmostEqual(strand_composite(strands, "mean"),
                               8.67, delta=0.01)  # ≈ DeepSeek's own 8.6


class T6_CountInvarianceAndFloor(unittest.TestCase):
    """T-6 (§11.8(a), NFR): count is 1 always — under damping, under no-grade,
    under attempted mutation. The floor is never stripped."""

    def test_count_is_property_without_setter(self):
        p = Participant("floor")
        with self.assertRaises(AttributeError):
            p.count = 0            # the attempt itself must fail

    def test_critical_damping_zeroes_weight_never_count(self):
        p = Participant("ri-critical")
        p.weight = 0.0             # RI Critical-domain damping (v1.6 D4)
        self.assertEqual(p.count, 1, "floor vote stripped — NFR violation")
        self.assertEqual(weight_tally([p], {p.pid: "BEST"}), 0.0)

    def test_ungraded_participant_keeps_count(self):
        p = Participant("ungraded")
        self.assertEqual(count_tally([p]), 1)


class T7_URWithholding(unittest.TestCase):
    """T-7 (6F Art. IV / VIII.3, row 19 mechanism): the Sentry payload cannot
    contain UR — statically (no parameter) and dynamically (no leakage)."""

    def test_static_no_ur_parameter(self):
        params = set(inspect.signature(cast_sentry_payload).parameters)
        self.assertFalse(params & {"pid", "ur", "identity", "participant"},
                         "payload function must never receive UR")

    def test_dynamic_payload_scan(self):
        p = Participant("UR-SECRET-7734")
        payload = cast_sentry_payload("option-A", "field-trial-siting")
        self.assertNotIn(p.pid, payload)
        decoded = base64.b64decode(payload.split(":")[2]).decode()
        self.assertNotIn(p.pid, decoded)
        self.assertTrue(payload.startswith("S-CAST_IT:"))


class T8_AccuracyHowWayAt(unittest.TestCase):
    """T-8 (v1.7 D4): ACCURACY = HowWay @ — a property of the way, provably
    independent of outcomes: perturb outcomes arbitrarily, accuracy holds."""

    def test_static_no_outcome_parameter(self):
        params = set(inspect.signature(accuracy_howway_at).parameters)
        self.assertFalse(params & {"outcome", "outcomes", "result", "results"},
                         "accuracy admits outcome data — §11.8(c) violation")

    def test_outcome_perturbation_invariance(self):
        rng = random.Random(95)   # NINE-FIVE seed, numerals in numeric register
        a0 = accuracy_howway_at(path_quality=85.0, address="@row8")
        for _ in range(100):
            _ = {"outcome": rng.random()}      # outcomes churn in the world
            a1 = accuracy_howway_at(path_quality=85.0, address="@row8")
            self.assertEqual(a1["accuracy"], a0["accuracy"])
        self.assertEqual(a0["accuracy"], "SOUND")

    def test_operand_open_row(self):
        SKIPPED.append(("T-8b", "row 8 OPEN: @ operand unconfirmed — "
                        "address-fixing sub-test deferred"))
        self.skipTest(OPEN_ROWS[8])


class T9_OperatorLadder(unittest.TestCase):
    """T-9-L: the four-rung ladder behaves — each rung strengthens, and
    GROUNDS demands a measurable anchor."""

    def test_full_ladder_on_the_numeric_basis(self):
        e = op_names("N", "P3-numeric-basis")
        e = op_tests(e, lambda r: r is not None)
        e = op_fuses(e, "CRITERION")
        e = op_grounds(e, 75.0)
        self.assertEqual(e["rung"], 4)
        self.assertTrue(e["tested"] and e["grounded"])

    def test_grounds_rejects_unmeasurable(self):
        e = op_grounds(op_names("X", "abstraction"), "pure-vibes")
        self.assertFalse(e["grounded"], "GROUNDS must fail on unmeasurable")


# ---------------------------------------------------------------------------
# Amplitude report
# ---------------------------------------------------------------------------

def amplitude_report(result):
    ran = result.testsRun
    failed = len(result.failures) + len(result.errors)
    skipped = len(result.skipped)
    passed = ran - failed - skipped
    structural = 10.0 * passed / max(ran - skipped, 1)

    nodes_over = {k: v for k, v in NODE_FIXTURE.items()
                  if v >= CANONICAL_GATE["score"]}
    gate_met = len(nodes_over) >= CANONICAL_GATE["nodes"]

    lines = [
        "",
        "=" * 68,
        "ERES-ECVS-2026-001 — 10-10 AMPLITUDE REPORT",
        "=" * 68,
        f"Tests run: {ran}   passed: {passed}   failed: {failed}   "
        f"skipped: {skipped}",
        "",
        f"STRUCTURAL AMPLITUDE : {structural:.1f} / 10",
        f"  provisional (stub-based, rows 1-2 OPEN): "
        f"{len(PROVISIONAL)} test(s)",
    ]
    for name, why in PROVISIONAL:
        lines.append(f"    - {name}: {why}")
    for name, why in SKIPPED:
        lines.append(f"  skipped: {name}: {why}")
    lines += [
        "",
        "CANONICAL AMPLITUDE  : gate = >=9.0 across >=3 independent nodes",
        f"  node fixture (Second Ensemble Record): {NODE_FIXTURE}",
        f"  nodes >= 9.0: {sorted(nodes_over)}  "
        f"({len(nodes_over)} of {CANONICAL_GATE['nodes']} required)",
        f"  GATE: {'MET' if gate_met else 'NOT MET'} — "
        + ("canonical" if gate_met else
           "this suite cannot move this number; only clean-room Round-3 "
           "nodes can (row 23)"),
        "",
        "10-10 STATUS: structural ten is author-reachable when rows 1-2 close",
        "and PROVISIONAL converts to spec-based PASS; canonical ten follows",
        "Round 3. The two tens are measured separately, by design.",
        "The count stays one.",
        "=" * 68,
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(
        __import__("__main__"))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print(amplitude_report(result))
