#!/usr/bin/env python3
"""
ERES-ONTOLOGY-EIGEN-PIPELINE-2026-001 v0.2 (DRAFT)
====================================================
Executable companion to ERES-ONTOLOGY-MATH-2026-001 v0.2 (Eigen of Rel-Def).

v0.2 changes (per 2026-07-06 ensemble workup + JAS rulings):
  * --protect CLI flag: comma-separated hub roots shielded from Lean-SIM
  * --ledger PATH: full quantitative reduction log written to JSON (the
    public reduction ledger required by the Zenodo protocol)
  * --sensitivity: one-at-a-time (OAT) traversal of the published weight
    grid (MATH paper section 3.2.1); reports rho_R range + hub-rank stability
  * Four-band rho_R verdict incl. the JAS-RULED 0.85 real-Registry
    acceptance threshold
  * Degenerate rho_R denominator now emits an explicit operational WARNING
  * Greedy backward elimination is the DEFINITION of the Lean-SIM criterion
    (not an approximation) per JAS closure ruling

Implements, in run order:
  [P]  Parser        : Registry `@=` lines -> typed edge triples (d_i, d_j, t)
  [A]  Adjacency     : weighted A per published weight schedule w(t)      [CONSTRUCTED]
  [SK] Split         : A = S + K; circulation fraction kappa = |K|_F/|A|_F [DERIVED]
  [C]  Centrality    : Perron-Frobenius dominant eigenpair of A            [DERIVED]
                       (with strongly-connected-component condensation report)
  [L]  Laplacian     : normalized Laplacian of S; spectrum nu_1..nu_n      [DERIVED]
  [T]  Cluster test  : spectral embedding (u_2..u_12) -> k-means(k=11)
                       -> chance-corrected Rand agreement rho_R vs Registry
                       partition; DERIVED/CONSTRUCTED/INCONCLUSIVE verdict
  [LS] Lean-SIM      : greedy spectral-truncation reduction with per-removal
                       marginal cost log Pi(D') and BEST/SOUND/GOOD keying
  [R]  Ruling pricer : first-order eigenvalue perturbation + Davis-Kahan
                       subspace bound for merge / tolerance-edge rulings

Vocabulary firewall (per ONTOLOGY-MODEL §7.5 and the flagged collision):
  - "ARI" is NEVER used for the Rand statistic (acronym reserved:
    Aura Resonance Index). The statistic is rho_R throughout.
  - No ERES-PELLIS controlled-vocabulary terms are used for this
    finite-dimensional structure matrix. A is not an evolution operator.

Usage:
  python eres_ontology_eigen_pipeline_v0_2.py --registry reg.txt --protect "STARTING-POINT,REGISTRY" --ledger ledger.json
  python eres_ontology_eigen_pipeline_v0_2.py --selftest [--sensitivity]

Input format (one edge per line; '#' comments allowed):
  @= SOURCE_ROOT | RELATION_TYPE | TARGET_ROOT
Cluster declarations (editorial partition, for the rho_R test):
  @cluster CLUSTER_NAME : ROOT_A, ROOT_B, ...

Dependencies: numpy only (k-means implemented locally; no sklearn).

License:  CC-BY 4.0 base <- CCAL v2.1 (CARE Commons Attribution License),
          ERES Institute Steward <- ERES-TCL v1.0 nested layer.
Credits:  Joseph Allen Sprute (ERES Maestro) - author of record, all rulings;
          Claude (Anthropic) - H2C2H drafting/validation node under MIEVM.
References: ERES-ONTOLOGY-MODEL-2026-001 v0.1; ERES-CLAUDE-REGISTRY-2026-001
          v0.1 (Zenodo DOI 10.5281/zenodo.21209870); Perron-Frobenius;
          Eckart-Young; Davis-Kahan; Hubert & Arabie (1985) for rho_R.
Status:   [W] WORKING. Weight schedule is a v0.1 design parameter and MUST
          be published alongside any computed result (ONTOLOGY-MODEL §6.1).
"""

import argparse
import sys
from collections import defaultdict

import numpy as np

# ---------------------------------------------------------------------------
# [A] Weight schedule -- CONSTRUCTED. Ship with every result.
# ---------------------------------------------------------------------------
WEIGHTS = {
    "defines":      3.0,
    "implements":   2.0,
    "cites":        1.0,
    "supersedes":   1.0,
    "measures":     2.0,
    "governs":      2.0,
    "feeds":        1.5,
    "co-locates":   0.5,   # structural co-location, explicitly not equivalence
    "same-similar": None,  # computed: 1/(1+eps_tol); eps read from 4th field
}
DEFAULT_SAME_SIMILAR_EPS = 0.25

# rho_R verdict bands (MATH v0.2 section 7.4). 0.85 acceptance = JAS-RULED
# 2026-07-06; 0.75/0.40 remain proposals.
RHO_ACCEPTANCE = 0.85          # JAS-ruled real-Registry acceptance threshold
RHO_DERIVED_FLOOR = 0.75
RHO_CONSTRUCTED_CEIL = 0.40

# Lean-SIM scorecard keying (proposal) -- preserved spectral content
SCORECARD = [("BEST", 0.95), ("SOUND", 0.85), ("GOOD", 0.75)]


# ---------------------------------------------------------------------------
# [P] Parser
# ---------------------------------------------------------------------------
def parse_registry(lines):
    """Parse @= edge lines and @cluster declarations.

    Returns (roots, edges, clusters):
      roots    : sorted list of root names
      edges    : list of (src, dst, rtype, weight)
      clusters : dict cluster_name -> set(root names)   (editorial partition)
    """
    edges, clusters, roots = [], {}, set()
    for ln, raw in enumerate(lines, 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("@cluster"):
            body = line[len("@cluster"):].strip()
            name, _, members = body.partition(":")
            clusters[name.strip()] = {m.strip() for m in members.split(",") if m.strip()}
            roots |= clusters[name.strip()]
        elif line.startswith("@="):
            parts = [p.strip() for p in line[2:].split("|")]
            if len(parts) < 3:
                print(f"  [parse] line {ln}: malformed, skipped: {line!r}")
                continue
            src, rtype, dst = parts[0], parts[1].lower(), parts[2]
            if rtype == "same-similar":
                eps = float(parts[3]) if len(parts) > 3 else DEFAULT_SAME_SIMILAR_EPS
                w = 1.0 / (1.0 + eps)
            elif rtype in WEIGHTS:
                w = WEIGHTS[rtype]
            else:
                print(f"  [parse] line {ln}: unknown relation type {rtype!r}, w=1.0")
                w = 1.0
            edges.append((src, dst, rtype, w))
            roots |= {src, dst}
    return sorted(roots), edges, clusters


def build_adjacency(roots, edges):
    idx = {r: i for i, r in enumerate(roots)}
    n = len(roots)
    A = np.zeros((n, n))
    for src, dst, rtype, w in edges:
        A[idx[src], idx[dst]] += w
        if rtype == "same-similar":          # tolerance edges are undirected
            A[idx[dst], idx[src]] += w
    return A, idx


# ---------------------------------------------------------------------------
# [SK] Symmetric / antisymmetric split
# ---------------------------------------------------------------------------
def split_SK(A):
    S = 0.5 * (A + A.T)
    K = 0.5 * (A - A.T)
    kappa = np.linalg.norm(K, "fro") / max(np.linalg.norm(A, "fro"), 1e-300)
    return S, K, kappa


# ---------------------------------------------------------------------------
# [C] Perron-Frobenius centrality + SCC condensation report
# ---------------------------------------------------------------------------
def tarjan_scc(A):
    n = len(A)
    adj = [np.nonzero(A[i])[0].tolist() for i in range(n)]
    index_ctr, stack, on_stack = [0], [], [False] * n
    index, lowlink = [-1] * n, [0] * n
    comps = []

    def strongconnect(v0):
        work = [(v0, 0)]
        while work:
            v, pi = work[-1]
            if pi == 0:
                index[v] = lowlink[v] = index_ctr[0]; index_ctr[0] += 1
                stack.append(v); on_stack[v] = True
            recurse = False
            for i in range(pi, len(adj[v])):
                w = adj[v][i]
                if index[w] == -1:
                    work[-1] = (v, i + 1); work.append((w, 0)); recurse = True; break
                elif on_stack[w]:
                    lowlink[v] = min(lowlink[v], index[w])
            if recurse:
                continue
            if lowlink[v] == index[v]:
                comp = []
                while True:
                    w = stack.pop(); on_stack[w] = False; comp.append(w)
                    if w == v: break
                comps.append(comp)
            work.pop()
            if work:
                u = work[-1][0]
                lowlink[u] = min(lowlink[u], lowlink[v])

    for v in range(n):
        if index[v] == -1:
            strongconnect(v)
    return comps


def perron_centrality(A, tol=1e-12, maxit=20000):
    """Dominant eigenpair by power iteration (A >= 0). Returns lam1, v1, w1."""
    n = len(A)
    B = A + 1e-9 * np.ones((n, n))          # tiny regularization -> primitivity
    v = np.ones(n) / n
    w = np.ones(n) / n
    lam = 0.0
    for _ in range(maxit):
        v_new = B @ v; v_new /= v_new.sum()
        w_new = B.T @ w; w_new /= w_new.sum()
        lam_new = float(v_new @ (B @ v_new)) / float(v_new @ v_new)
        if abs(lam_new - lam) < tol and np.abs(v_new - v).max() < tol:
            v, w, lam = v_new, w_new, lam_new
            break
        v, w, lam = v_new, w_new, lam_new
    return lam, v, w


# ---------------------------------------------------------------------------
# [L] Normalized Laplacian spectrum + spectral embedding
# ---------------------------------------------------------------------------
def laplacian_spectrum(S):
    deg = S.sum(axis=1)
    deg_safe = np.where(deg > 0, deg, 1.0)
    Dh = np.diag(1.0 / np.sqrt(deg_safe))
    L = np.eye(len(S)) - Dh @ S @ Dh
    nu, U = np.linalg.eigh(L)               # ascending
    return nu, U


def kmeans(X, k, seed=216, n_init=25, iters=200):
    """Plain k-means (Lloyd), best of n_init seeds. Local -- no sklearn."""
    rng = np.random.default_rng(seed)
    best_inertia, best_labels = np.inf, None
    n = len(X)
    for _ in range(n_init):
        centers = X[rng.choice(n, size=k, replace=False)].copy()
        labels = np.zeros(n, dtype=int)
        for _ in range(iters):
            d2 = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(-1)
            new_labels = d2.argmin(1)
            if (new_labels == labels).all():
                break
            labels = new_labels
            for c in range(k):
                pts = X[labels == c]
                if len(pts):
                    centers[c] = pts.mean(0)
        inertia = ((X - centers[labels]) ** 2).sum()
        if inertia < best_inertia:
            best_inertia, best_labels = inertia, labels.copy()
    return best_labels


def rho_R(labels_a, labels_b):
    """Chance-corrected Rand agreement (Hubert & Arabie 1985).
    NOTE: never abbreviated 'ARI' in ERES prose -- acronym reserved
    (Aura Resonance Index). Denoted rho_R per ONTOLOGY-MODEL vocabulary."""
    a = np.asarray(labels_a); b = np.asarray(labels_b)
    ua, ub = np.unique(a), np.unique(b)
    C = np.zeros((len(ua), len(ub)), dtype=np.int64)
    for i, x in enumerate(ua):
        for j, y in enumerate(ub):
            C[i, j] = int(((a == x) & (b == y)).sum())
    comb2 = lambda m: m * (m - 1) // 2
    sum_ij = sum(comb2(int(c)) for c in C.ravel())
    sum_a = sum(comb2(int(c)) for c in C.sum(1))
    sum_b = sum(comb2(int(c)) for c in C.sum(0))
    total = comb2(len(a))
    if total == 0:
        return 1.0
    expected = sum_a * sum_b / total
    max_idx = 0.5 * (sum_a + sum_b)
    denom = max_idx - expected
    if denom == 0:
        print("  [T] WARNING: rho_R denominator exactly zero -- test pool is "
              "mathematically degenerate (too small/uniform); returning 1.0 "
              "by convention. Do NOT treat as a pass.")
        return 1.0
    return (sum_ij - expected) / denom


# ---------------------------------------------------------------------------
# [LS] Lean-SIM greedy spectral truncation
# ---------------------------------------------------------------------------
def preserved_content(A_sub, sig_full_topk_sq, k):
    sig = np.linalg.svd(A_sub, compute_uv=False)
    return float((sig[:k] ** 2).sum() / max(sig_full_topk_sq, 1e-300))


def lean_sim_reduction(A, roots, k=11, eps=0.15, protect=()):
    """Greedy backward elimination. Per JAS ruling 2026-07-06 this greedy
    procedure IS the definition of the Lean-SIM criterion D* (MATH v0.2
    section 8.4), not an approximation to a combinatorial optimum.
    Returns the reduction log (public, quantitative)."""
    sig_full = np.linalg.svd(A, compute_uv=False)
    denom = float((sig_full[:k] ** 2).sum())
    alive = list(range(len(roots)))
    log = []
    Pi_now = 1.0
    while len(alive) > k + 1:
        best = None
        for cand in alive:
            if roots[cand] in protect:
                continue
            keep = [i for i in alive if i != cand]
            Pi_c = preserved_content(A[np.ix_(keep, keep)], denom, k)
            if Pi_c >= 1 - eps and (best is None or Pi_c > best[1]):
                best = (cand, Pi_c)
        if best is None:
            break
        cand, Pi_new = best
        log.append((roots[cand], Pi_now - Pi_new, Pi_new))
        Pi_now = Pi_new
        alive.remove(cand)
    tier = next((name for name, floor in SCORECARD if Pi_now >= floor), "SUB-GOOD")
    return alive, log, Pi_now, tier


# ---------------------------------------------------------------------------
# [R] Ruling pricer
# ---------------------------------------------------------------------------
def price_ruling(A, lam1, v1, w1, nu, delta_A, cluster_band=(1, 12)):
    """First-order dominant-eigenvalue shift + Davis-Kahan subspace bound."""
    d_lam = float(w1 @ (delta_A @ v1)) / max(float(w1 @ v1), 1e-300)
    rel = abs(d_lam) / max(lam1, 1e-300)
    lo, hi = cluster_band
    gap = float(nu[hi] - nu[hi - 1]) if hi < len(nu) else np.inf
    dk = np.linalg.norm(delta_A, 2) / max(gap, 1e-300)
    return rel, min(dk, 1.0), gap


# ---------------------------------------------------------------------------
# Self-test: synthetic 73-root registry with 11 planted clusters
# ---------------------------------------------------------------------------
def synthetic_registry(seed=216):
    """73 roots, 11 planted clusters (sizes 7x7 + 4x6), dense intra-cluster
    'defines/cites' edges, sparse inter-cluster 'cites', four hub roots wired
    corpus-wide to stand in for Starting Point / Registry / Triune Math / CCAL."""
    rng = np.random.default_rng(seed)
    sizes = [7] * 7 + [6] * 4
    assert sum(sizes) == 73
    lines, name_of, k0 = [], [], 0
    hubs = []
    for c, sz in enumerate(sizes):
        members = [f"ROOT-{c:02d}-{i}" for i in range(sz)]
        name_of.append(members)
        lines.append(f"@cluster CL{c:02d} : " + ", ".join(members))
        for i in range(sz):
            for j in range(sz):
                if i != j and rng.random() < 0.55:
                    t = "defines" if rng.random() < 0.4 else "cites"
                    lines.append(f"@= {members[i]} | {t} | {members[j]}")
        k0 += sz
    flat = [m for ms in name_of for m in ms]
    hubs = [name_of[0][0], name_of[1][0], name_of[2][0], name_of[3][0]]
    for h in hubs:                                  # corpus-wide hub wiring
        for m in rng.choice(flat, size=30, replace=False):
            if m != h:
                lines.append(f"@= {m} | cites | {h}")
                lines.append(f"@= {h} | defines | {m}")
    for _ in range(60):                             # sparse inter-cluster noise
        a, b = rng.choice(flat, size=2, replace=False)
        lines.append(f"@= {a} | cites | {b}")
    lines.append(f"@= {name_of[4][1]} | same-similar | {name_of[4][2]} | 0.25")
    return lines, hubs


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def run(lines, expected_hubs=None, protect_extra=None, ledger_path=None, quiet=False):
    roots, edges, clusters = parse_registry(lines)
    n = len(roots)
    print(f"\n[P] Parsed: {n} roots, {len(edges)} edges, "
          f"{len(clusters)} editorial clusters")
    A, idx = build_adjacency(roots, edges)

    S, K, kappa = split_SK(A)
    print(f"[SK] Circulation fraction kappa = {kappa:.4f}  "
          f"(0 = reciprocal, 1 = pure feed-forward)")

    comps = tarjan_scc(A)
    giant = max(comps, key=len)
    print(f"[C] SCC condensation: {len(comps)} components; "
          f"giant component holds {len(giant)}/{n} roots"
          + ("" if len(giant) == n else "  <-- definitionally isolated islands: FINDING"))

    lam1, v1, w1 = perron_centrality(A)
    order = np.argsort(-v1)
    print(f"[C] lambda_1 = {lam1:.4f}; top-7 definitional centrality (of {n}):")
    for r in order[:7]:
        print(f"      {v1[r]:.4f}  {roots[r]}")
    if expected_hubs:
        ranks = {h: int(np.where(order == idx[h])[0][0]) + 1 for h in expected_hubs}
        hit = all(rk <= max(7, int(0.1 * n)) for rk in ranks.values())
        print(f"[C] §7.2 top-decile prediction on hub roots: "
              f"{'PASS' if hit else 'FAIL'}  {ranks}")

    nu, U = laplacian_spectrum(S)
    kc_gap = len(clusters) if clusters else 11        # natural-count probe
    kc_gap = min(kc_gap, n - 1)
    if kc_gap >= 3:
        gap_at_k = nu[kc_gap] - nu[kc_gap - 1]
        mean_below = (nu[kc_gap - 1] - nu[1]) / max(kc_gap - 2, 1)
        print(f"[L] nu_2 (algebraic connectivity) = {nu[1]:.4f}; "
              f"gap nu_{kc_gap+1} - nu_{kc_gap} = {gap_at_k:.4f} vs mean spacing "
              f"below it {mean_below:.4f}"
              + ("  <-- spectral signature supports the editorial cluster count"
                 if mean_below > 0 and gap_at_k > 3 * mean_below else ""))
    else:
        print(f"[L] nu_2 (algebraic connectivity) = {nu[1]:.4f}; "
              f"registry too small for a cluster-count gap probe")

    verdict = "SKIPPED (no editorial partition supplied)"
    if clusters:
        kc = len(clusters)
        X = U[:, 1:kc + 1]
        X = X / np.maximum(np.linalg.norm(X, axis=1, keepdims=True), 1e-12)
        labels_spec = kmeans(X, kc)
        labels_reg = np.zeros(n, dtype=int)
        for c, (_, members) in enumerate(sorted(clusters.items())):
            for m in members:
                if m in idx:
                    labels_reg[idx[m]] = c
        r = rho_R(labels_spec, labels_reg)
        if r >= RHO_ACCEPTANCE:
            verdict = (f"rho_R = {r:.3f}  ->  UPGRADE toward DERIVED "
                       f"(meets JAS-ruled {RHO_ACCEPTANCE} acceptance threshold)")
        elif r >= RHO_DERIVED_FLOOR:
            verdict = (f"rho_R = {r:.3f}  ->  UPGRADE toward DERIVED (PROVISIONAL: "
                       f">= {RHO_DERIVED_FLOOR} floor, below {RHO_ACCEPTANCE} acceptance)")
        elif r < RHO_CONSTRUCTED_CEIL:
            verdict = f"rho_R = {r:.3f}  ->  remains CONSTRUCTED (editorial; < {RHO_CONSTRUCTED_CEIL})"
        else:
            verdict = (f"rho_R = {r:.3f}  ->  INCONCLUSIVE band; "
                       f"run weight-schedule sensitivity before re-test")
    print(f"[T] Cluster-recovery primitive test: {verdict}")

    protect = set(expected_hubs or []) | set(protect_extra or [])
    if protect:
        print(f"[LS] Protect list in force ({len(protect)} roots shielded): "
              + ", ".join(sorted(protect)))
    alive, log, Pi_final, tier = lean_sim_reduction(A, roots, k=min(11, n - 2),
                                                    eps=0.15, protect=protect)
    print(f"[LS] Lean-SIM greedy reduction: {n} -> {len(alive)} roots retained; "
          f"Pi = {Pi_final:.4f} -> scorecard tier {tier}")
    if log:
        print(f"     first removals (root, marginal cost, Pi after):")
        for name, cost, pi in log[:5]:
            print(f"       -{name:<18} cost {cost:+.4f}  Pi {pi:.4f}")
        print(f"     ... {len(log)} removals total (full log = public reduction log)")
    if ledger_path:
        import json
        ledger = {
            "instrument": "ERES-ONTOLOGY-EIGEN-PIPELINE-2026-001 v0.2",
            "date": "2026-07-06",
            "n_roots_initial": n, "n_roots_retained": len(alive),
            "k": min(11, n - 2), "eps": 0.15,
            "Pi_final": round(Pi_final, 6), "scorecard_tier": tier,
            "protect_list": sorted(protect),
            "weight_schedule": {k2: (v if v is not None else
                                f"1/(1+eps), default eps {DEFAULT_SAME_SIMILAR_EPS}")
                                for k2, v in WEIGHTS.items()},
            "removals": [{"root": nm, "marginal_cost": round(c, 6),
                          "Pi_after": round(pi, 6)} for nm, c, pi in log],
            "retained": [roots[i] for i in alive],
        }
        with open(ledger_path, "w") as f:
            json.dump(ledger, f, indent=2)
        print(f"[LS] Quantitative reduction ledger written -> {ledger_path}")

    # Ruling pricer demo: a tolerance edge between two arbitrary alive roots
    if len(alive) >= 2:
        i, j = alive[0], alive[1]
        dA = np.zeros_like(A)
        w_ss = 1.0 / (1.0 + DEFAULT_SAME_SIMILAR_EPS)
        dA[i, j] = dA[j, i] = w_ss
        rel, dk, gap = price_ruling(A, lam1, v1, w1, nu, dA,
                                    cluster_band=(1, max(kc_gap, 2)))
        kind = "LOAD-BEARING" if (rel > 0.01 or dk > 0.10) else "COSMETIC"
        print(f"[R] Ruling pricer (demo tolerance edge {roots[i]} ~ {roots[j]}): "
              f"|d lambda_1|/lambda_1 = {rel:.5f}; Davis-Kahan rotation <= {dk:.4f} "
              f"(cluster gap {gap:.4f})  ->  {kind}")
        print("     (1% centrality threshold JAS-RULED 2026-07-06; 0.10 rotation "
              "trigger remains a proposal. Pricing informs, JAS rules.)")

    print("\nWeight schedule in force (CONSTRUCTED -- ships with these results):")
    for t, w in WEIGHTS.items():
        print(f"    w({t}) = " + (f"{w}" if w else f"1/(1+eps), eps default {DEFAULT_SAME_SIMILAR_EPS}"))
    print("\nStatus: [W] WORKING. rho_R never abbreviated 'ARI' (reserved: "
          "Aura Resonance Index).")
    return {"rho_R": (r if clusters else None),
            "kappa": kappa, "lambda1": lam1,
            "hub_ranks": ({h: int(np.where(order == idx[h])[0][0]) + 1
                           for h in (expected_hubs or []) if h in idx})}


# ---------------------------------------------------------------------------
# [S] OAT weight-sensitivity traversal (MATH v0.2 section 3.2.1)
# ---------------------------------------------------------------------------
SENSITIVITY_GRID = {   # class -> (low, baseline, high); classes share a scale
    "defines": (2.0, 3.0, 4.0),
    "implements": (1.5, 2.0, 2.5), "measures": (1.5, 2.0, 2.5),
    "governs": (1.5, 2.0, 2.5),
    "feeds": (1.0, 1.5, 2.0),
    "cites": (0.5, 1.0, 1.5), "supersedes": (0.5, 1.0, 1.5),
    "co-locates": (0.25, 0.5, 0.75),
}
OAT_CLASSES = [("defines",), ("implements", "measures", "governs"),
               ("feeds",), ("cites", "supersedes"), ("co-locates",)]

def sensitivity_oat(lines, expected_hubs=None):
    """One-at-a-time traversal: perturb one relation class to low/high while
    others stay at baseline. Reports rho_R range and hub-rank stability.
    Full factorial deferred to the real-Registry run (MATH v0.2 sec 3.2.1)."""
    import io, contextlib
    baseline = dict(WEIGHTS)
    results = []
    print("\n=== [S] OAT WEIGHT-SENSITIVITY (published grid, MATH v0.2 3.2.1) ===")
    for classes in OAT_CLASSES:
        for which, slot in (("low", 0), ("high", 2)):
            for k2 in baseline:
                if baseline[k2] is not None:
                    WEIGHTS[k2] = SENSITIVITY_GRID[k2][1]
            for c in classes:
                WEIGHTS[c] = SENSITIVITY_GRID[c][slot]
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                res = run(lines, expected_hubs=expected_hubs)
            tag = "/".join(classes) + f" @{which}"
            results.append((tag, res))
            hr = res["hub_ranks"]; worst = max(hr.values()) if hr else None
            print(f"  {tag:<38} rho_R = {res['rho_R']:.3f}   "
                  f"kappa = {res['kappa']:.3f}   worst hub rank = {worst}")
    for k2 in baseline:                      # restore baseline
        WEIGHTS[k2] = baseline[k2]
    rhos = [r["rho_R"] for _, r in results if r["rho_R"] is not None]
    lo, hi = min(rhos), max(rhos)
    print(f"\n  rho_R range over OAT grid: [{lo:.3f}, {hi:.3f}]")
    if lo >= 0.70:
        print("  VERDICT: schedule ROBUST for the cluster test on this input "
              "(rho_R >= 0.70 across grid)")
    elif lo < 0.40:
        print("  VERDICT: schedule is DRIVING the result somewhere on the grid "
              "(rho_R < 0.40 observed) -- recalibrate before any claim")
    else:
        print("  VERDICT: MIXED stability -- inspect per-class rows above")
    print("  (OAT only; full factorial deferred to the real-Registry run.)")


def main():
    ap = argparse.ArgumentParser(description="ERES Eigen of Rel-Def pipeline v0.2")
    ap.add_argument("--registry", help="path to @= registry export")
    ap.add_argument("--selftest", action="store_true",
                    help="run on synthetic 73-root / 11-cluster registry")
    ap.add_argument("--protect",
                    help="comma-separated root names shielded from Lean-SIM removal")
    ap.add_argument("--ledger",
                    help="path to write the full quantitative reduction ledger (JSON)")
    ap.add_argument("--sensitivity", action="store_true",
                    help="run the OAT weight-sensitivity grid after the main pass")
    args = ap.parse_args()
    protect = ({h.strip() for h in args.protect.split(",") if h.strip()}
               if args.protect else set())
    if args.registry:
        with open(args.registry) as f:
            lines = f.read().splitlines()
        run(lines, protect_extra=protect, ledger_path=args.ledger)
        if args.sensitivity:
            sensitivity_oat(lines)
    elif args.selftest:
        print("=== SELF-TEST: synthetic 73-root registry, 11 planted clusters ===")
        lines, hubs = synthetic_registry()
        run(lines, expected_hubs=hubs, protect_extra=protect,
            ledger_path=args.ledger)
        if args.sensitivity:
            sensitivity_oat(lines, expected_hubs=hubs)
    else:
        ap.print_help(); sys.exit(1)


if __name__ == "__main__":
    main()
