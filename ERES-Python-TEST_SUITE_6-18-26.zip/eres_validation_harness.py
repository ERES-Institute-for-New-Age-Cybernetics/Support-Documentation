"""
ERES VALIDATION HARNESS  —  for the understanding lane (Pellis)
================================================================================
Turns the spectral-gap estimator into a *falsifiable* instrument. It does not
prove anything by itself; it provides the apparatus for a pre-registered forecast
on real data, with error bars and a false-positive control, so that one committed
prediction can pass or fail honestly.

Pairs with eres_bera_gap.py (the estimator). This file adds the science layer:
  1. PreRegistration  — lock every tunable parameter BEFORE seeing the outcome.
  2. bootstrap_t_star — a confidence interval on the deduced critical moment.
  3. false_positive_rate — fire-rate on matched non-event controls.
  4. evaluate         — pass/fail by the Part IV criteria of ERES-RISK-WP-2026-002.

Real data slots in via load_csv(): a CSV with columns ARI,ERI,RHC,RCI,SR.
This harness characterizes no one's research; it is a tool to point at your own.

License : CC-BY 4.0   |   ERES Institute (J. A. Sprute, Maestro)
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from eres_bera_gap import gap_series, bera_disruption_index, deduce_t_star, synth


# ----------------------------------------------------------------------------- 
# 1. Pre-registration: lock parameters before the outcome is known
# ----------------------------------------------------------------------------- 
@dataclass(frozen=True)
class PreRegistration:
    window: int          # rolling window length
    step: int            # window stride
    rho_crit: float      # BDI threshold that fires the warning
    t_star_pred: float   # the COMMITTED point forecast (set before seeing the event)
    delta: float         # half-width of the accepted error window [t*-d, t*+d]
    fp_bound: float      # maximum tolerated false-positive rate on controls
    n_boot: int = 300    # bootstrap resamples for the CI
    seed: int = 7

    def accepts(self, value: float) -> bool:
        return self.t_star_pred - self.delta <= value <= self.t_star_pred + self.delta


# ----------------------------------------------------------------------------- 
# 2. Forecast with a bootstrap confidence interval on t*
# ----------------------------------------------------------------------------- 
def forecast_once(channels, sr, pre: PreRegistration):
    t, mu, gap, coup = gap_series(channels, sr, win=pre.window, step=pre.step)
    bdi = bera_disruption_index(gap, coup)
    for i in range(8, len(t)):
        if bdi[i] >= pre.rho_crit:
            ts = deduce_t_star(t[: i + 1], gap[: i + 1])
            return {"fired": True, "now": int(t[i]), "t_star": ts, "bdi": float(bdi[i])}
    return {"fired": False, "now": None, "t_star": None, "bdi": float(bdi.max())}


def bootstrap_t_star(channels, sr, pre: PreRegistration):
    """Residual bootstrap: jitter the channels, recompute t*, return median and 90% CI."""
    rng = np.random.default_rng(pre.seed)
    scale = 0.05 * np.std(channels)
    draws = []
    for _ in range(pre.n_boot):
        jitter = rng.normal(0, scale, size=channels.shape)
        r = forecast_once(channels + jitter, sr, pre)
        if r["fired"] and r["t_star"] is not None:
            draws.append(r["t_star"])
    if len(draws) < pre.n_boot * 0.5:
        return None  # unstable forecast: did not fire reliably under resampling
    draws = np.array(draws)
    return {
        "median": float(np.median(draws)),
        "ci90": (float(np.percentile(draws, 5)), float(np.percentile(draws, 95))),
        "fire_fraction": len(draws) / pre.n_boot,
    }


# ----------------------------------------------------------------------------- 
# 3. False-positive control: how often do non-event series fire?
# ----------------------------------------------------------------------------- 
def false_positive_rate(control_channels, control_sr, pre: PreRegistration):
    """control_* : lists of (channels, sr) known to contain NO transition."""
    fires = sum(forecast_once(c, s, pre)["fired"] for c, s in zip(control_channels, control_sr))
    return fires / max(1, len(control_channels))


# ----------------------------------------------------------------------------- 
# 4. Evaluate against the Part IV criteria — pass/fail, honestly
# ----------------------------------------------------------------------------- 
def evaluate(pre: PreRegistration, boot, fp_rate: float, true_event: float):
    reasons = []
    if boot is None:
        return {"PASS": False, "reasons": ["forecast did not fire reliably under resampling"]}
    in_window = pre.accepts(boot["median"]) and pre.accepts(true_event)
    fp_ok = fp_rate <= pre.fp_bound
    if not in_window:
        reasons.append(
            f"event {true_event} / forecast {boot['median']:.1f} outside window "
            f"[{pre.t_star_pred - pre.delta:.0f}, {pre.t_star_pred + pre.delta:.0f}]")
    if not fp_ok:
        reasons.append(f"false-positive rate {fp_rate:.2f} exceeds bound {pre.fp_bound:.2f}")
    return {"PASS": in_window and fp_ok, "reasons": reasons or ["all criteria met"]}


# ----------------------------------------------------------------------------- 
# Real-data entry point (slot your CSV here)
# ----------------------------------------------------------------------------- 
def load_csv(path: str):
    """Expects columns ARI,ERI,RHC,RCI,SR. Returns (channels[N,4], sr[N])."""
    import csv
    rows = []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            rows.append([float(row[k]) for k in ("ARI", "ERI", "RHC", "RCI", "SR")])
    arr = np.array(rows)
    return arr[:, :4], arr[:, 4]


# ----------------------------------------------------------------------------- 
# Demonstration: a pre-registered forecast that PASSES, and one that FAILS
# ----------------------------------------------------------------------------- 
def _controls(n=12, seed=20):
    rng = np.random.default_rng(seed)
    cc, ss = [], []
    for _ in range(n):
        N = 620
        sr = 1.0 + 0.3 * np.sin(2 * np.pi * np.arange(N) / 40) + 0.05 * rng.standard_normal(N)
        X = np.zeros((N, 4))
        for k in range(1, N):                       # fixed sub-critical control -> no tipping
            X[k] = 0.70 * X[k - 1] + 0.15 * (sr[k] - 1.0) + 0.10 * rng.standard_normal(4)
        cc.append(X); ss.append(sr)
    return cc, ss


if __name__ == "__main__":
    X, sr, true_event = synth()                      # event series at t=520
    cc, ss = _controls()

    print("ERES Validation Harness  (pre-registered falsifiable forecast)\n" + "-" * 64)

    # A well-set pre-registration (committed before the outcome).
    pre = PreRegistration(window=60, step=4, rho_crit=0.55,
                          t_star_pred=480, delta=60, fp_bound=0.20)
    boot = bootstrap_t_star(X, sr, pre)
    fp = false_positive_rate(cc, ss, pre)
    verdict = evaluate(pre, boot, fp, true_event)
    print(f"pre-registered t*={pre.t_star_pred}±{pre.delta}, fp_bound={pre.fp_bound}")
    if boot:
        print(f"forecast median t*={boot['median']:.1f}  90% CI={boot['ci90'][0]:.0f}-"
              f"{boot['ci90'][1]:.0f}  fire-fraction={boot['fire_fraction']:.2f}")
    print(f"false-positive rate on {len(cc)} controls = {fp:.2f}")
    print(f"VERDICT: {'PASS' if verdict['PASS'] else 'FAIL'}  — {verdict['reasons'][0]}")

    print("-" * 64)
    # A deliberately over-tight window: the harness must be able to FAIL.
    strict = PreRegistration(window=60, step=4, rho_crit=0.55,
                             t_star_pred=515, delta=5, fp_bound=0.20)
    boot2 = bootstrap_t_star(X, sr, strict)
    verdict2 = evaluate(strict, boot2, fp, true_event)
    print(f"strict pre-reg t*={strict.t_star_pred}±{strict.delta}")
    print(f"VERDICT: {'PASS' if verdict2['PASS'] else 'FAIL'}  — {verdict2['reasons'][0]}")
