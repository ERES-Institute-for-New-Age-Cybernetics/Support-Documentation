"""Validation suite — ERES-RESONANCE-CREDIT-2026-001 v0.1 reward schedule.
Verdict = exit code. Properties P1-P8 must PASS. Null control N1 must FAIL-as-designed.
Adversarial probe A1 (sybil split) reports a finding either way.
"""
import sys, random

# ---------- schedule under test ----------
def W(r, rlo=0.05, rhi=0.60, k=1.0):
    if r < rlo: return 0.0
    if r <= rhi: return k * (r - rlo)
    return k * (rhi - rlo)

def rewards(rs, Es, qs, B_M=1.0, C=0.1, rlo=0.05, rhi=0.60, k=1.0, legal_leverage=None):
    # legal_leverage accepted and IGNORED by construction (C4)
    Ws = [W(r, rlo, rhi, k) for r in rs]
    denom = sum(w * e for w, e in zip(Ws, Es))
    out = []
    for w, e, q in zip(Ws, Es, qs):
        M = (w * B_M / denom) if denom > 0 else 0.0
        out.append(M * e + C * q)
    return out

# ---------- harness ----------
results = []
def check(name, cond, detail=""):
    results.append((name, cond, detail))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))

random.seed(20260715)

# P1 floor supremacy: zero resonance still pays exactly C; non-qualifying pays 0
R = rewards([0.0, 0.4, 0.3], [1, 1, 1], [1, 1, 1])
check("P1a zero-resonance qualifier receives exactly C", abs(R[0] - 0.1) < 1e-12, f"R={R[0]:.6f}")
R = rewards([0.0, 0.4, 0.3], [1, 1, 1], [0, 1, 1])
check("P1b non-qualifying corpus receives 0", abs(R[0]) < 1e-12)

# P2 additivity of C: dR/dC = q exactly, independent of M and E (100 random draws)
ok = True
for _ in range(100):
    rs = [random.random() for _ in range(4)]
    Es = [0.2 + 0.8 * random.random() for _ in range(4)]
    qs = [1, 1, 1, 0]
    C1, C2 = 0.05, 0.17
    Ra = rewards(rs, Es, qs, C=C1); Rb = rewards(rs, Es, qs, C=C2)
    for a, b, q in zip(Ra, Rb, qs):
        if abs((b - a) - q * (C2 - C1)) > 1e-10: ok = False
check("P2 Polyvalence Lock: dR/dC = q exactly, all random (M,E)", ok, "100 random economies")

# P3 in-band monotonicity, damped by E
r_base = [0.30, 0.25, 0.20]
lo = rewards(r_base, [1, 1, 1], [1, 1, 1])
hi = rewards([0.35, 0.25, 0.20], [1, 1, 1], [1, 1, 1])
check("P3a more in-band resonance -> strictly more reward", hi[0] > lo[0], f"{lo[0]:.4f} -> {hi[0]:.4f}")
fullE = rewards(r_base, [1.0, 1, 1], [1, 1, 1])
halfE = rewards(r_base, [0.5, 1, 1], [1, 1, 1])
check("P3b weaker evidence -> smaller earned component", halfE[0] < fullE[0], f"{fullE[0]:.4f} -> {halfE[0]:.4f}")
z = rewards([0.0, 0.25, 0.20], [0.5, 1, 1], [1, 1, 1])
check("P3c E-damping never touches the floor", abs(z[0] - 0.1) < 1e-12)

# P4 anti-monoculture: above the wall, marginal reward is exactly zero
a = rewards([0.70, 0.15, 0.10], [1, 1, 1], [1, 1, 1])
b = rewards([0.90, 0.15, 0.10], [1, 1, 1], [1, 1, 1])
check("P4 condensation wall: R(0.70) == R(0.90) exactly", abs(a[0] - b[0]) < 1e-12, f"both {a[0]:.4f}")

# P5 litigation invariance: legal posture cannot enter the schedule
x = rewards([0.4, 0.3], [1, 1], [1, 1], legal_leverage=0)
y = rewards([0.4, 0.3], [1, 1], [1, 1], legal_leverage=10**9)
check("P5 C4 invariance: R identical under any legal leverage", x == y)

# P6 conservation: sum(R) = B_M + C*Q to machine precision (uniform E; general E noted)
rs = [0.5, 0.3, 0.15, 0.0]; qs = [1, 1, 1, 1]
tot = sum(rewards(rs, [1, 1, 1, 1], qs, B_M=1.0, C=0.1))
check("P6 budget conservation: sum R == B_M + C*Q", abs(tot - (1.0 + 0.4)) < 1e-12, f"sum={tot:.12f}")

# P7 continuity at both knots (no payoff cliffs to game)
eps = 1e-9
c1 = abs(W(0.05 - eps) - W(0.05 + eps)) < 1e-6
c2 = abs(W(0.60 - eps) - W(0.60 + eps)) < 1e-6
check("P7 schedule continuous at r_lo and r_hi", c1 and c2)

# P8 non-negativity, all regimes
ok = all(min(rewards([random.random() for _ in range(5)],
                     [0.1 + 0.9 * random.random() for _ in range(5)],
                     [random.choice([0, 1]) for _ in range(5)])) >= -1e-12 for _ in range(200))
check("P8 no negative rewards in 200 random economies", ok)

# N1 NULL CONTROL (test-the-test): a wall-less schedule MUST fail the P4 checker
def W_broken(r, k=1.0): return k * r
def rewards_broken(rs):
    Ws = [W_broken(r) for r in rs]; d = sum(Ws)
    return [w / d + 0.1 for w in Ws]
a = rewards_broken([0.70, 0.15, 0.10]); b = rewards_broken([0.90, 0.15, 0.10])
check("N1 null control: wall-less schedule violates P4 (must differ)", abs(a[0] - b[0]) > 1e-6,
      f"broken schedule pays condensation: {a[0]:.4f} -> {b[0]:.4f}")

# A1 ADVERSARIAL PROBE — sybil split: does one corpus splitting into two profit?
print("\n--- A1 adversarial probe: sybil split ---")
rs0, Es0, qs0 = [0.40, 0.30, 0.20], [1, 1, 1], [1, 1, 1]
R0 = rewards(rs0, Es0, qs0)
before = R0[0]
rs1, Es1, qs1 = [0.20, 0.20, 0.30, 0.20], [1, 1, 1, 1], [1, 1, 1, 1]
R1 = rewards(rs1, Es1, qs1)
after = R1[0] + R1[1]
gain = after - before
print(f"corpus A whole  (r=0.40): R = {before:.4f}")
print(f"corpus A split (2x r=0.20): R = {after:.4f}   sybil gain = {gain:+.4f}")
sybil_resistant = gain <= 1e-9
check("A1 sybil resistance at v0.1 default parameters", sybil_resistant,
      "VULNERABLE — floor C doubles on split, exceeds earned loss k*r_lo" if not sybil_resistant else "")

# derived resistance bound: earned loss on split ~= k*r_lo * B_M/denom'; require C <= that
denom1 = sum(W(r) for r in rs1)
bound = 1.0 * 0.05 * 1.0 / denom1
print(f"derived condition: sybil-neutral requires C <= k*r_lo*B_M/denom' = {bound:.4f}; current C = 0.1000")

# ---------- verdict ----------
props = [ok_ for name, ok_, _ in results if name.startswith(("P", "N"))]
findings = [name for name, ok_, _ in results if name.startswith("A") and not ok_]
print("\n================ VERDICT ================")
print(f"properties + null control: {sum(props)}/{len(props)} PASS")
if findings:
    print(f"adversarial findings: {len(findings)} -> {findings}")
    print("schedule math HOLDS as specified; specification INCOMPLETE (sybil vector open).")
sys.exit(0 if all(props) else 1)
