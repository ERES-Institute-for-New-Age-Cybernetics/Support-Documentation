# ERES-CLEANSPACE-2026-001 v0.4 — Package

**Recycle Everything Made: What, Why, How and Where**
One loop and one recovery band (97/3–98/2) for every human-made thing, bound to coordinates through LLPM, applied first to the ERES corpus (the proof) and Earth orbit (Clean Space).

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · 19 October 2026
Status: PROPOSED · MIEVM Round 1 folded (on v0.1: 4 nodes, mean 7.39; SOUND not yet met) · License: CCAL v2.1 / CC-BY 4.0

## Contents

| File | What it is |
| --- | --- |
| `ERES-CLEANSPACE-2026-001_v0.4.md` | Master text, with Appendix C math (LaTeX) |
| `ERES-CLEANSPACE-2026-001_v0.4.pdf` | Typeset companion: formulas and both figures rendered |
| `ERES-CLEANSPACE-2026-001_v0.4_Fig1_Loop-and-Band.svg` | Figure 1: the loop and the 97/3–98/2 band |
| `ERES-CLEANSPACE-2026-001_v0.4_Fig2_One-Light-Two-Spaces.svg` | Figure 2: story image layout, "One Light, Two Spaces" |
| `ERES-CLEANSPACE-2026-001_v0.4_EVIDENCE_App1-Inventory_archivedwl-44-45.csv` | First real evidence: read-only inventory of two ERES archives (§4.5) |
| `eres_cleanspace_manifest.py` | Application 1 inventory tool (read-only) |
| `eres_cleanspace_where.py` | The "Where" layer: LLPM invariants I1, I2, I4, I5, I6 and the REEPER routing gate |
| `eres_cleanspace_testkit.py` | Test suite: 24 PASS / 0 FAIL / 5 SKIP, exit 0 |
| `RUN_RECORD.txt` | Test output from this sealed package |
| `META_TEXT.md` | Deposit title, abstract, keywords, share messages |
| `CITATION.cff` | Citation metadata |
| `MANIFEST.json` | SHA-256 of every file |

## Run

```
python3 eres_cleanspace_testkit.py                 # exit 0 = no FAIL
python3 eres_cleanspace_manifest.py PATH --out my_manifest [--doi doi.txt] [--deps deps.json] [--retire retire.txt]
```

Standard library only. Nothing is moved, renamed or deleted.

## What's new in v0.4

- **Where:** every resource and obligation sits at a coordinate in the LLPM POSTERITY Ledger. Its six invariants are hard rules. Most important: the ledger answers *what is at this coordinate*, never *where is this person* (I6).
- **Routing:** REEPER's conjunctive gate (any zero factor blocks) runs before the 4/5/6-of-7 quorum.
- **Evidence:** the first real inventory (28 items, 9 orphans, a filename collision, an overwritten README, stale license and vocabulary).
- **Math:** Proposition 2, tile ratios aggregate exactly to the global ratio; the no-surveillance property stated on the query interface.

## The five SKIPs (work still owed)

S1 real orbital catalogue data (F1) · S2 measured drift and latency (F2) · S3 full-corpus inventory with validated retirements · S4 MIEVM Round 2 · S5 person-layer VEIL cryptography (LLPM's hardest open item).
