# Recycle Everything Made: What, Why, How and Where

## One loop and one recovery band (97/3–98/2) for every human-made thing, bound to coordinates through LLPM, applied first to the ERES corpus (the proof) and Earth orbit (Clean Space)

**Instrument:** ERES-CLEANSPACE-2026-001 · **Version:** v0.4 (N.EXT of v0.3; "Where" bound to LLPM, REEPER gate folded, first real evidence) · **Date:** 19 October 2026  
**Status:** PROPOSED · author-maximal · MIEVM Round 1 folded (structural findings only) · target tier SOUND, not yet earned  
**Author:** Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221 · ERES Institute for New Age Cybernetics, Bella Vista, Arkansas  
**Companion files:** `eres_cleanspace_manifest.py` (Application 1 inventory tool) · `eres_cleanspace_testkit.py` (24 PASS / 0 FAIL / 5 SKIP, exit 0) · `ERES-CLEANSPACE-2026-001_v0.4_EVIDENCE_App1-Inventory_archivedwl-44-45.csv` (first real run)  
**License:** CCAL v2.1 / CC-BY 4.0 (governing CCAL text: DOI 10.5281/zenodo.23451312)

---

## Abstract

Every human-made thing raises four questions: what to recycle, why, how, and where. This instrument answers them once, for all of it. **What:** everything made — objects, mass and information — is in scope; nothing escapes the question, and anything unidentified is held, not ignored. **Why:** to keep each system inside its working band for generations; both walls fail, waste piling up below and a system that can never let anything go above. **How:** one loop — detect each item, route it to a named answerable party, and dispose of it as Recyclable, Held or Retired, never by unilateral deletion — held to the ERES Recycling band 97/3–98/2. Of what is resolved in a period, 97–98% returns to use and only 2–3% leaves by design; the same 2–3% is the Sentry return-to-base reserve, and the margin law m* = v·τ decides which edge a domain can use. An offset ledger pays for it: recycling earns credit, retirement only clears the debt. **Where:** every resource and obligation sits at a coordinate in the LLPM POSTERITY Ledger, whose six invariants become hard rules here — water stays commons, a missing floor attestation triggers care not eviction, and the ledger can say what is at a coordinate but never who is standing on it. Routing inherits REEPER's conjunctive gate: alignment, resonance, proportionality and finality risk must all be non-zero before any quorum may act. Two applications follow. Application 1 consolidates the ERES corpus, which ERES controls alone, and seals a citable manifest as proof of method. Application 2, Clean Space, sets out orbital consolidation as a governance concept, prompted by ESA's 2026 finding that its Health Index rose from about 4 to about 50 in one year and that active removal is now required. A stdlib test suite (24 PASS, 0 FAIL, 5 SKIP) checks every structural rule, including that the same rule serves any domain and that no query can locate a person. A first real inventory of two ERES archives (28 unique items) is included as evidence: it found a filename collision, an overwritten README, stale vocabulary and a license mismatch, and correctly reports the band as not yet reached. Cross-domain mappings are CONSTRUCTED; nothing is DERIVED, so nothing is BEST.

**Keywords:** recycling, circular economy, geospatial property ledger, privacy by design, no-surveillance, water commons, recovery ratio, 97/3, 98/2, reserve margin, end-of-life governance, extended producer responsibility, offset ledger, space debris, orbital consolidation, active debris removal, Kessler syndrome, Space Environment Health Index, in-orbit servicing, digital archive consolidation, research data provenance, SHA-256 manifest, Smart-Resonant Offset Contract, ERES Recycling Machine, ERES, 1000-Year Future Map, CCAL v2.1

---

## 0. Thesis — what, why, how and where to recycle everything made

The whole problem is one problem. What people make piles up faster than it is either kept useful or properly retired, and too much of it has no one who answers for it. Archives, orbits, landfills, buildings and data centres are cases of that one problem.

| Question | Answer | Where it lives in this instrument |
| --- | --- | --- |
| **What** to recycle | Everything made: objects, mass, information. Nothing is out of scope; anything unidentified is **Held**, never ignored | Detect step (§2.1); Held rule (§2.3) |
| **Why** recycle | To keep the system in its working band for generations. Not scarcity alone: both walls fail | SHB band (§1); three-principle gate, "don't hurt the future" (§2.4) |
| **How** to recycle | Detect → Route (conjunctive gate, then quorum) → Dispose; a named answerable party per item; the 97/3–98/2 band; the offset ledger | §2, §3, §5.4 |
| **Where** it is | At a coordinate in the LLPM POSTERITY Ledger. Resources and obligations are public; people are never located | §2.5 |

**Scope of "everything".** Everything made is *in scope*; not everything is *recycled*. The band asks that 97–98% of what is resolved comes back into use. The 2–3% that leaves is part of the design: some things are hazardous, dead, or carry no load, and a system that can never retire anything fails at the upper wall.

**"Recycle" in the broad sense.** Recyclable means returned to use by any route: kept live, repaired, serviced, refuelled, reused, remanufactured, or recovered as material. Material recovery is one route, not the definition.

**Status of the thesis.** The four answers are definitional for this instrument (CONSTRUCTED). Whether the 97/3–98/2 band is achievable in a given domain is empirical and is tested per application.

---

## 1. Introduction

The 1000-Year Future Map asks one question of any plan: does it keep the system inside its working band for generations? ERES treats recycling as that band problem, with two failure walls (ERES-PELLIS-SHB-001, Theorem 1). Below the band is incoherence: scattered, untracked, unowned things. Above it is condensation: a system so full or so locked that one failure spreads into the next. Clean means held between the walls.

Version 0.1 stated the loop for two spaces. Version 0.2 gave it a number: the ERES Recycling band 97/3–98/2. Version 0.3 states the general case. The loop and band are an instrument for recycling everything made; the ERES corpus and Earth orbit are its first two applications. The ERES Recycling Machine is the "how" at any scale: consolidation is recycling with a ledger.

**Governing proposition.** Clean is not the absence of things. It is the verified presence of accountable, recoverable and sustainable order. *(Adapted from the ChatGPT node in MIEVM Round 1.)*

**Why these two applications first.**

- **Application 1, the ERES corpus,** is the one domain ERES controls alone. It is cleaned first, and its sealed manifest is the proof of method (VLSA: works in a THOW = works on a generation ship).
- **Application 2, Earth orbit (Clean Space),** is where the cost of failing at the upper wall is clearest and most urgent: ESA reports that debris now grows even with zero new launches.
- **Coupled by method and sequence, not by cause.** Cleaning the corpus removes no object from orbit. Orbital consolidation depends on states, operators and funding. ERES supplies the governance design; others must enact it.

---

## 2. Body of Evidence — the general engine (the "how")

### 2.1 The loop

Detect → Route → Dispose. Every item exits as one of three dispositions:

| Disposition | Meaning | Corpus | Orbit |
| --- | --- | --- | --- |
| **Recyclable** (token issued) | Stays in service or returns to it | Live version; DOI'd version | Serviced, refuelled, reused, or material recycled |
| **Held** (AUTH = no, VEILED) | Under investigation; never turned away, never counted | Undeposited drafts sealed in a named archive; unidentified files | Unidentified or unattributed object |
| **Retired** (no token) | Leaves service by a validated act | Marked superseded, never silently deleted | Controlled deorbit or design-for-demise reentry |

The loop is REEPER's detect → route → distribute, closed by the SROC token disposition set.

### 2.2 Instrument map

| ERES instrument | Job in the loop | Orbit reading | Corpus reading |
| --- | --- | --- | --- |
| SHB band (Theorem 1) | Defines clean: both walls fail | Lower wall = untracked fragmentation; upper wall = Kessler cascade | Lower wall = scattered, unindexed files; upper wall = one bloated archive nobody can parse |
| ERES Recycling band 97/3–98/2 | Sets how much stays and how much leaves | 97–98% of resolved mass recovered (H3 target) | 97–98% of resolved unique items kept live |
| Sentry + margin law m* = v·τ | Alarm threshold and reserve | Shell occupancy alarm at 97% / 98%; last 2–3% held | Storage or attention budget alarm at 97% / 98% |
| CDFE n_eff | Counts what is genuinely distinct | Distinct hazard sources, not raw object count | Distinct instruments, not raw file count |
| SROC §1 Contact of Record | Every item has a reachable answerable party | Operator of record; none = orphan class | Owner record per instrument ID |
| Lean-SIM backward elimination | Retire only what carries no load | Remove highest cascade load per tonne first | Retire only if registry dependencies hold |
| "Mission Critical = return to base" | Every action recoverable | Funded end-of-life path per launch | Nothing DOI'd is deleted |
| CBGMODD 7-seat routing | No unilateral disposition | Coordination quorum; legal authority stays with states (§5.3) | Author + one named validator |
| ERES Recycling Machine | The "how" at any scale; closes the loop | In-orbit servicing and recycling | Manifest-driven mirror rebuild |

### 2.3 Disposition rules (tested: T02–T06)

1. Exact-hash copies collapse into one item. A copy is not a retirement.
2. A DOI'd version is never retired. It can only be marked superseded.
3. A retirement needs the author's listing **and** a named validator. A listing without a validator stays Held.
4. Held items are excluded from the recycling ratio until resolved. They are VEILED, not counted.
5. The last live copy of an instrument that another instrument depends on cannot be retired (F3 guard).

### 2.4 Three governing principles as a gate (tested: T11)

The ERES Constitution's three rules become a conjunctive gate on every intervention:

| Principle | Corpus gate | Orbit gate |
| --- | --- | --- |
| Don't hurt self | No loss of the author's working record | Mission and crew safety |
| Don't hurt others | No broken citation or dependency for readers | No added third-party collision or reentry casualty risk |
| Don't hurt the future | Every version recoverable | Net reduction of long-term orbital strain |

An action that improves one metric but fails any gate does not count as success.

---

### 2.5 Where — the LLPM binding (tested: T19–T22, T24)

Every made thing that occupies space sits at a coordinate. The Longitude–Latitude Property-Management instrument (ERES-LLPM-2026-001, POSTERITY Ledger) is that address book, and REEPER v0.2 §6 already names it as the EMCI tile ledger: the tiles that are watched are the tiles that are stewarded. Recycle Everything Made adopts LLPM's six invariants as **hard rules**: no disposition may break them, in any domain.

| LLPM invariant | Hard rule in this instrument | Test |
| --- | --- | --- |
| I1 Water-commons | No disposition may move a WATER-class item into a private (EARNED-private) trust state. Water infrastructure may be Recyclable, Held or Retired from service, never enclosed | T19 |
| I2 Floor-universal | A missing Healthy-Happy-SAFE attestation on an occupied dwelling triggers care-response. It is never grounds for retiring the dwelling or removing its occupant | T20 |
| I3 KEY-binding | Any allocation touching a coordinate passes the role-swap test (planned as if the planner were the recipient) | inherited (LLPM suite) |
| I4 Describable | The resource layer is public and auditable; the person layer is VEILED by default | T21 |
| I5 Reversion | Escrowed entitlements and future claims cannot be retired, sold or transferred out from under their holders | T24 |
| I6 No-surveillance | The ledger answers "what resource or obligation is at this coordinate", never "where is this person". No function from person to coordinate exists | T21 |

**Per-tile recovery ratio (resource layer only).** For tile τ, the recovery ratio $\rho_\tau$ is computed over the resource records on τ, never over people. Tile ratios aggregate exactly to the global ratio (Appendix C.12, T22), so a region can see which tiles sit outside the band without anyone being located.

**Stewardship records.** REEPER §6 binds a steward to a tile. Under I6 that binding is a VEILED entitlement reference: it proves the tile has an answerable steward without revealing who or where they are. The cryptography for proving this is LLPM's hardest open item and stays OPEN here (S5).

### 2.6 Routing gate before the quorum (tested: T23)

Routing has two steps, in this order (from REEPER v0.2 §3):

1. **Conjunctive gate.** Alignment × Resonance × Proportionality × Finality-risk clearance. If any factor is zero, the action is blocked, whatever the vote.
2. **Seated quorum, tiered by finality risk.** Reversible: at least 4 of 7 seats. Consequential: at least 5 of 7. Irreversible: at least 6 of 7 and no dissenting Dignitary seat.

A quorum can never override a zero factor, and no single seat authorises anything. In Application 1 the "quorum" is the author plus a named validator; in Application 2 it is a coordination body whose legal authority still comes from the state of registry (§5.3).

---

## 3. The ERES Recycling band 97/3–98/2

### 3.1 Definition (tested: T01, T03, T09)

For any period, take the items (corpus) or mass (orbit) that the loop **resolved**, meaning dispositioned Recyclable or Retired. Held items are left out.

**Recovery ratio** = Recyclable ÷ (Recyclable + Retired)

**Band:** 0.97 ≤ recovery ratio ≤ 0.98

| Reading | Recovery ratio | Retired share | Verdict |
| --- | --- | --- | --- |
| Lower wall | < 0.97 | > 3% | Over-retirement: risk of losing load-bearing content |
| **In band (97/3)** | 0.97 | 3% | Edge: maximum safe retirement |
| **In band (98/2)** | 0.98 | 2% | Edge: minimum real consolidation |
| Upper wall | > 0.98 | < 2% | Under-consolidation: waste kept, bloat persists |

Both walls fail, as in SHB. Keeping everything is not clean; it is condensation. Retiring freely is not clean; it is loss.

*Status: the band is an author-declared policy band (CONSTRUCTED). The validity of each edge for a given domain is derived from the margin law below, not asserted.*

### 3.2 The dovetail with the Sentry margin (tested: T07)

The same 2–3% is the Sentry reserve. The Sentry alarms amber when 97% of a capacity is committed and red at 98%; the last 2–3% is held for return to base. The GAIA Construct Grid margin law decides which edge a domain can use:

- 98/2 holds only if v·τ ≤ 0.02·ΔK
- 97/3 holds only if v·τ ≤ 0.03·ΔK
- If v·τ > 0.03·ΔK, neither edge holds and the domain needs a wider reserve (falsifier F2)

Here v is drift rate (new objects or edits per unit time), τ is response latency, and ΔK is the width of the working band. The numbers 2 and 3 stay policy; the test that tells you which one is safe is derived.

For a spacecraft, disposal propellant is held **outside** this budget. The 2–3% is a margin above the disposal requirement, not a substitute for it.

### 3.3 How the band reads in each application

| | Application 1 — corpus | Application 2 — orbit |
| --- | --- | --- |
| Unit | Unique items after exact copies collapse | Mass (tonnes) of dispositioned objects |
| Recyclable | Live and DOI'd versions | Serviced, refuelled, reused, material recycled |
| Retired (the 2–3%) | Dead stubs and superseded items with no load, validated | Controlled deorbit or demise of what cannot be recovered |
| Status today | Measurable now with the manifest tool | Recovery ratio near zero; band is the H3 target |
| Use of the band | **Gate**: Application 1 exit requires in-band | **Trajectory**: tracked per horizon, gate only from H3 |

In orbit today, controlled reentry and design-for-demise remain correct practice. The band does not call them failures now. It names the target state of a circular orbital economy, which ESA also states as a long-term aim.

---

## 4. Application 1 — the ERES corpus (the proof)

The goal is one canonical copy per instrument version, every file traceable to a registry root, and every mirror pointing back to Zenodo, which governs under CCAL §13.

### 4.1 Surfaces

| Surface | Role after consolidation |
| --- | --- |
| Zenodo (corpus DOIs 10.5281/zenodo.20709216, 10.5281/zenodo.21209870, and per-instrument records) | Source of truth; DOI'd versions immutable |
| GitHub Support-Documentation | Discovery front door; deposit ZIPs |
| eresinstitute.org download library | Public mirror, rebuilt from the manifest |
| ResearchGate, Figshare | Pointers to Zenodo, not separate masters |
| pCloud backup, private folders | Cold backup and working drafts only |

### 4.2 Phases

1. **Inventory.** Run `eres_cleanspace_manifest.py` on every surface. Each entry records path, SHA-256, size, instrument ID, version, disposition and reason.
2. **Collapse copies.** Exact-hash copies merge into one entry. Near-duplicates are scored by CDFE n_eff; only genuinely distinct versions keep separate entries.
3. **Dispose.** The tool marks latest and DOI'd versions Recyclable, superseded drafts and unidentified files Held, and empty stubs Retired. The author lists further retirements with a named validator.
4. **Check the band.** The tool reports the recovery ratio and band verdict. Adjust retirements until the ratio sits in 97/3–98/2 without triggering F3.
5. **Point the mirrors.** Site, ResearchGate, Figshare and GitHub link to the governing Zenodo record. The site library is rebuilt from the manifest.
6. **Seal.** The cleaned manifest ships as the next Zenodo supplement deposit.

**Manifest schema** (JSON and CSV): `path, sha256, size, instrument_id, version, disposition, reason, copies`, plus a report block with `unique_items, exact_copies_collapsed, dispositions, recovery_ratio, band, orphans_no_id`.

### 4.3 Known drift to clear first

- Trifecta Zenodo record: the Rights field still says CC-BY 4.0; change it to CCAL v2.1 and add the IsReferencedBy link to the CCAL record.
- VOTEPACK v1.2 on Zenodo carries Delta v1.6; the FULL is at v1.8.
- TERMS #46/#47 still print BERA as "Bio-Energetic"; the canonical form is Bio-Ecologic.
- EPIR-Q has three divergent canonical faces; pick one, Hold the others with supersede markers.
- Retire `eres-spanish-homepage.html` (superseded by `eres-homepage-spanish.html`); push `ERES-TERMS-48.pdf` to the server.
- Instruments declaring CC-BY 4.0 alone: cite the CCAL v2.1 DOI as governing license.
- Resolve the LLPM RG-SUBMISSION filename collision, restore the REEPER v0.1 README, and assign IDs to the 9 orphans found in §4.5.

### 4.4 Exit gate (tested: T12)

Application 1 exits, and Application 2 may be proposed publicly, only when all four hold:

1. Zero orphan files (every item has an instrument ID or is Held with a reason).
2. Zero license mismatches.
3. F3 not triggered.
4. Recovery ratio in the 97/3–98/2 band.

---

### 4.5 First real evidence — inventory of two ERES archives

On 19 October 2026 the v0.3 inventory tool ran read-only over two author archives (archivedwl-44: LLPM; archivedwl-45: EMCI and REEPER). The full manifest ships as `ERES-CLEANSPACE-2026-001_v0.4_EVIDENCE_App1-Inventory_archivedwl-44-45.csv`.

| Measure | Result |
| --- | --- |
| Unique items | 28 (1 exact copy collapsed) |
| Recyclable / Held / Retired | 16 / 12 / 0 |
| Orphans (no instrument ID) | 9 |
| Recovery ratio | 1.0 → upper wall (no retirements listed yet: expected) |
| Companion suites found and run | LLPM `test_posterity_ledger.py` 15/15 OK; REEPER `eres_reeper_testkit.py` 14 PASS / 0 FAIL / 3 SKIP |

**Drift found** (added to §4.3):

- Two *different* files share the name `ERES-LLPM-2026-001_POSTERITY-LEDGER_v0-1_RG-SUBMISSION.zip` inside archivedwl-44 (CRC 19e53104 and e9e2f1f8); a plain unzip silently keeps only one.
- `ERES-PELLIS-EMCI-REEPER_v0_1=README.md` is byte-identical to the v0.2 README: the v0.1 README was overwritten.
- `TRANSFORMATION_GATEWAY_EMCI_REEP_COMPREHENSIVE_THESIS` uses the superseded "Bio-Energetic" reading, declares CC BY-SA 4.0 rather than CCAL v2.1, and carries no instrument ID.
- The tool does not yet open nested ZIP archives (LLPM v0-1.zip contains an RG-SUBMISSION zip). Logged as a first developer issue.

**What this evidence shows.** The tool runs on real material, finds real drift, and reports the band honestly as *not yet reached*. It does not show that the band is reachable; that needs validated retirements and a full-corpus run (S3, F5).

---

## 5. Application 2 — Earth orbit (Clean Space)

Application 2 is a governance concept with options, not an operating plan. Its goal is to bring ESA's Health Index back toward 1 and to raise the orbital recovery ratio toward the 97/3–98/2 band by H3.

### 5.1 State as of October 2026

| Measure | Value | Source |
| --- | --- | --- |
| Health Index, one-year change (1 = sustainable benchmark) | about 4 → about 50 | ESA 2026 report (primary, verified) |
| Launched vs intact reentries | about 10 payloads/day vs more than 3/day | ESA 2026 report |
| Launches and new payloads in 2025 | more than 300 launches, more than 4,000 payloads | ESA 2026 report |
| Objects regularly tracked (31 Jul 2026) | about 47,070 | ESA statistics via New Space Economy (secondary) |
| Functioning satellites | about 15,900 | same (secondary) |
| Mass in orbit | more than 17,000 t | same (secondary) |

ESA's verdict: debris grows even with zero launches; active removal is required; a circular economy through in-orbit servicing is the long-term aim.

### 5.2 Phases

1. **Hold the line.** Every launch carries a Contact of Record, a funded end-of-life path, design-for-demise, and a Sentry reserve of 2–3% above its disposal requirement. No path back to base, no launch slot. Aligns with the 5-year disposal rule and the Zero Debris Charter.
2. **Detect and index.** Close the gap between detected and catalogued objects. An unidentified object is Held, not ignored. Hazard is scored by distinct sources (n_eff), not raw counts.
3. **Route.** Removal requests go through a seated coordination quorum tiered by finality risk (4/7, 5/7, 6/7). The quorum coordinates; it does not create legal authority (§5.3).
4. **Dispose by load.** Remove first what carries the most cascade load per tonne: large derelict rocket bodies in congested shells. Each object exits Recyclable, Held or Retired.
5. **Close the loop.** Scale servicing, refuelling and in-orbit recycling until the recovery ratio reaches 97/3–98/2: the ERES Recycling Machine at orbital scale.

### 5.3 Legal pathway (folded from MIEVM Round 1)

Under Article VIII of the 1967 Outer Space Treaty, the state of registry keeps jurisdiction and control over its objects. Removing another state's object needs that state's consent. The existing treaties do not mention debris removal, and the COPUOS Debris Mitigation Guidelines are not binding.

**Two-tier path.**

1. **Near term: voluntary layer.** Bilateral consent agreements, a charter-based removal register, and the offset ledger among willing operators. The Zero Debris Charter community is the natural on-ramp.
2. **Long term: binding instrument.** A convention on satellite sunsetting and orbital cleanup that the voluntary layer is designed to demonstrate the need for. A draft text exists as a separate lineage (GA-CLEANSPACE-CONVENTION-2026-001, produced in Round 1); it is referenced here, not merged.

**Mechanisms either tier needs.**

- **Advance consent declarations** filed at registration, pre-authorising removal by a certified remover once defined derelict conditions are met.
- **Liability for the act of removal** shifts to the remover; the original state keeps liability for the object itself.
- **Orphan class** for objects with no live operator, with a claims process and a default disposition.

**Responsibility matrix.**

| Action | Accountable party |
| --- | --- |
| Object identification | Tracking provider and operator |
| Ownership verification | State of registry and operator |
| Removal consent | State of registry (or its advance declaration) |
| Mission execution | Licensed servicing or removal operator |
| Financial obligation | Party under the ledger, by contract or treaty |
| Independent verification | Designated auditor |

**Host options (to assess, not endorsed):** UN COPUOS / UNOOSA (legitimacy, consensus, slow); ITU (existing registration and coordination machinery); a Zero Debris Charter working group or coalition of launching states (fast, narrower).

### 5.4 Financing (tested: T10)

Removal is paid by offset, not penalty (SROC §2 Offset; Paineology = non-punitive remediation).

- **Offset ledger.** Each operator's measured share of orbital strain is a deficit. It is discharged by funding removal, servicing or recycling, never by a fine paid to a holder.
- **Return-to-base reserve.** Each launch posts a reserve that guarantees its own disposal, plus the 2–3% Sentry margin. Spending below it is barred.
- **Recyclable credit.** Recycling clears the deficit **and** earns credit. Deorbit clears the deficit only. This asymmetry pulls the system toward the 97–98% recovery band.

The ledger needs a valuation method and an auditor before it can run. Both are open (§9).

---

### 5.5 Further applications (CANDIDATE, not specified)

The same loop and band apply wherever things are made. These are named so the general claim can be tested, not because they are designed yet.

| Domain | What is made | Recyclable routes | What retires (the 2–3%) | First ERES tie-in |
| --- | --- | --- | --- | --- |
| Electronics (e-waste) | Devices, batteries, boards | Repair, refurbishment, component harvest, material recovery | Hazardous fractions with no safe route | Offset ledger as producer responsibility |
| Built environment | Buildings, materials, THOWs | Reuse in place, relocation, salvage, remanufacture | Contaminated or unsalvageable material | THOW; LLPM lat/long tile ledger |
| Water and agriculture | Water, soil inputs, packaging | Treatment and reuse, composting, return loops | Residues that cannot re-enter safely | BEE WATER/AG floor |
| Data and compute | Datasets, models, hardware | Re-index, re-license, retrain, redeploy | Data that must be erased by law or consent | Application 1 manifest; SROC §1.6 erasure boundary |

Each further application inherits the rule set unchanged and supplies only an adapter (F6).

## 6. Falsifiers (pre-registered protocols)

| ID | Claim tested | Data | Method | Fails if | Status |
| --- | --- | --- | --- | --- | --- |
| F1 | Prioritising by cascade load per tonne beats random removal | Public catalogue (ESA DISCOS, Space-Track) + ESA environment model | Equal mass budget; targeted order vs 30 random orders; compare modeled Health Index | Targeted is not better than the best random run | Toy version passes (T08: 12.1% vs 5.1% of load); real data OPEN |
| F2 | The 2–3% reserve is enough | Measured drift v and response latency τ per shell or surface | m* = v·τ against 0.02·ΔK and 0.03·ΔK | v·τ > 0.03·ΔK in any operating domain | Rule tested (T07); measurements OPEN |
| F3 | Consolidation drops nothing load-bearing | Manifest + registry dependency list | Retire, then check every dependency still resolves | Any dependency breaks | Guard tested (T06); first real inventory run, no retirements yet (§4.5) |
| F4 | One decision rule serves every domain | Paired corpus and orbit cases | Same rule; only input adapters differ | The rule must change between domains | Passes on 4 paired cases (T13) |
| F5 | Application 1 lands in the recycling band | Live manifest | Recovery ratio after validated retirements | Ratio outside 0.97–0.98 at exit | Rule tested (T09); live run OPEN |
| F6 | The general rule needs no new rule for a new domain | A third domain (e.g. e-waste or building materials) with its own adapter | Map its items to the five inputs of the one disposition rule | Any domain item cannot be dispositioned without adding a rule | Passes for a synthetic third domain (T14); a real third domain OPEN |
| F7 | The ledger can locate no person | Any LLPM-bound ledger in any application | Attempt every query path from a person reference to a coordinate | Any path returns a location | Guard tested (T21); third-party audit OPEN |
| F8 | Tile ratios add up to the whole | Per-tile resource records | Weighted aggregate of ρ_τ vs global ρ | They differ | Passes (T22) |

---

## 7. The Future Map — horizons and gates

| Horizon | Action | Recovery band role | Tag |
| --- | --- | --- | --- |
| H0 · 2026–2027 | Application 1: inventory, clear drift, validated retirements, seal manifest | Exit gate: in-band | CONSTRUCTED method, measurable |
| H1 · 2027–2030 | Application 2 voluntary layer: Contact of Record, funded end-of-life, Sentry reserve, advance consent | Track recovery ratio; publish baseline | Sourced + CONSTRUCTED |
| H2 · 2030–2050 | Detect, route, dispose by load; servicing and refuelling scale up | Ratio rising toward 0.97 | Sourced + CONSTRUCTED |
| H3 · 2050–2126 | Close the loop: in-orbit recycling; Health Index ≤ 1 | Band becomes a gate | CONJECTURE |
| H4 · 2126–3026 | Orbit held as a commons in band; Spaceship Economics at generation scale | Band holds by design | VISION |

**Gates.** H0 → H1: Application 1 exit gate (§4.4). H1 → H2: a host body for the removal register and quorum. H2 → H3: F1 passes on real data. H3 onward: recovery ratio in 97/3–98/2 for three consecutive review cycles.

---

## 8. MIEVM Round 1 record

Round 1 reviewed v0.1. Claude is the drafting node and is excluded from the mean.

| Node | Score | What it rated |
| --- | --- | --- |
| DeepSeek | 4/10 overall (6/10 as internal vision; 3/10 as public proposal); 5/10 on a de-ERES'd variant | Actionable public plan |
| ChatGPT | 8.8/10 (Seven Anchors mean) | ERES instrument |
| Qwen 3.7-Plus | 8.5/10 | ERES instrument |
| Gemini | 8.25/10 | ERES instrument |
| **Mean (4 nodes)** | **7.39** | Median 8.38 |

**Verdict: SOUND not met.** Four nodes reviewed, but the mean is below 8.5. The spread comes from framing: three nodes rated the instrument, one rated it as a public plan ready to act on. Both readings are fair, and v0.2 answers the second by recasting Stage 2 as a governance concept with options.

**Adopted (structural):** glossary (Qwen, DeepSeek); definitions with units for n_eff, m* = v·τ and the band (ChatGPT, DeepSeek); falsifier protocols with data and decision rules (all four); manifest schema and script (ChatGPT, Qwen, Gemini); Stage 2 as concept with options, two-tier legal path, advance consent, liability for the act of removal, orphan class, quorum as coordination only (DeepSeek, ChatGPT); host options (Qwen); responsibility matrix, three-principle gate, F4 transferability test, governing proposition (ChatGPT).

**Held as candidate:** Clean Space Digital Twin (ChatGPT) for H2; an NBERS composite score R_clean = w₁D + w₂T + w₃S + w₄G, held because its weights have no anchor yet; EarnedPath work packages EP-CS-01 to 04.

**Declined:** Gemini's "meets threshold for SOUND" (node count and mean do not support it); ChatGPT's projected 9.5+ (a projection, not a review); a university affiliation for Dr. Pellis that his own title page does not state; UBIMIA/Meritcoin financing before a legal settlement mechanism exists.

---

## 9. Conclusions

1. The whole problem is what, why and how to recycle everything made. Everything made is in scope; 97–98% of what is resolved should return to use; 2–3% leaves by design.
2. One loop and one disposition rule fit every domain tested so far: the corpus, orbit and a synthetic third domain. The fit is CONSTRUCTED; F4 and F6 test it.
3. The ERES Recycling band 97/3–98/2 is where consolidation meets recycling: 97–98% of what is resolved stays in service, 2–3% leaves. Both walls fail.
4. The same 2–3% is the Sentry reserve. The margin law m* = v·τ tells each domain which edge it can safely use.
5. The corpus goes first because ERES controls it. Its sealed, in-band manifest is the proof Application 2 cites. It removes no debris.
6. In orbit the band is a horizon target, not a present rule. The offset ledger's asymmetry (recycling earns credit, deorbit only clears) is what moves the system toward it.
7. Application 2 needs consent the plan cannot supply. It proceeds on a voluntary layer and names a binding convention as the long-term goal.

8. Everything made has an address, but no person does. LLPM's invariants make the resource layer public and the person layer unlocatable, and routing must clear a conjunctive gate before any vote.

**Open items.** Person-layer VEIL cryptography (S5); nested-archive inventory; a real third application (F6); host body for the register and quorum; ledger valuation method and auditor; real-data runs of F1, F2, F3 and F5; MIEVM Round 2 (≥4 nodes, mean ≥8.5); author access to run the Application 1 inventory.

---

## 10. Historical Notes

| Date | Event |
| --- | --- |
| 19 Oct 2026 | v0.4: "Where" bound to LLPM; REEPER gate folded; first real inventory evidence |
| 19 Oct 2026 | v0.3: scope widened to "what, why and how to recycle everything made"; corpus and orbit become Applications 1 and 2 |
| 19 Oct 2026 | v0.2: Recycling band 97/3–98/2 bound to the loop; MIEVM Round 1 folded; package issued |
| 19 Oct 2026 | v0.1 drafted with companion WP "The Clean Space Future Map" (ERES-CLEANSPACE-FUTUREMAP-2026-001) |
| 14 Sep 2026 | ESA Space Environment Report 2026: Health Index about 4 → about 50; active removal declared required |
| Jul 2026 | GAIA Construct Grid derives the Sentry margin law m* = v·τ; 98/2 confirmed as Sentry load-to-failure policy |
| 2023 | Zero Debris Charter created with ESA's facilitation |
| 2022 | U.S. FCC adopts the 5-year post-mission disposal rule for low Earth orbit |
| 2017 | ESA publishes its first annual Space Environment Report |
| 4 Feb 2012 | ERES Institute established, Bella Vista, Arkansas |
| 2007–2012 | SaleBuilders, the commerce predecessor of ERES |
| 1 Jan 1997 | CyberRAVE founded: "Cybernetic Ratings Abolishing Veiled Exchanges" |
| 1978 | Kessler and Cour-Palais describe the collisional cascade later called Kessler syndrome |
| 1967 | Outer Space Treaty; Article VIII fixes jurisdiction and control with the state of registry |
| 1957 | Sputnik 1; its rocket body becomes the first orbital debris |

---

## 11. Story Image Description — "One Light, Two Spaces"

*The story image illustrates the first two applications; the instrument itself covers everything made.*

**Subtitle:** Detect · Route · Dispose — from the ERES desk to Earth orbit

**Image prompt (no embedded text; add labels afterward as a native overlay).** A wide landscape image split into two halves joined by one continuous band of soft light. On the left, a small, warmly lit study at night: a single desk, an open archive drawer, loose papers lifting off the desk and folding themselves into a neat stack of bound volumes; nearly all of them land on the stack, and only a thin few drift into a glowing recycling bin. On the right, Earth seen from low orbit at dawn: a thin haze of fragments above the limb, and a small servicing spacecraft gently capturing a large derelict rocket body, while most recovered pieces flow toward a small orbital workshop and only a sliver burns as a single bright reentry streak. The band of light runs from the desk lamp across the frame into the sunrise over Earth. Palette: deep navy, warm amber, soft green-blue at the horizon. Style: calm documentary realism; no logos, no flags, no faces.

**Alt text.** A desk where loose papers fold into an ordered archive, joined by a band of light to Earth orbit where a spacecraft captures debris; in both scenes nearly everything is kept and only a sliver is retired.

**Overlay labels.** Left: "Application 1 — the proof". Right: "Application 2 — Clean Space". Band: "Detect · Route · Dispose". Small corner tag: "97/3–98/2".

Figure files: `ERES-CLEANSPACE-2026-001_v0.4_Fig1_Loop-and-Band.svg` (the loop and the recycling band) and `ERES-CLEANSPACE-2026-001_v0.4_Fig2_One-Light-Two-Spaces.svg` (layout mockup of the story image).

---

## Appendix A — Glossary

| Term | Meaning here |
| --- | --- |
| BERA | Bio-Ecologic Resonance Architecture |
| CBGMODD | ERES seven-seat council; here a coordination quorum |
| CCAL v2.1 | CARE Commons Attribution License v2.1; CC-BY 4.0 compatible |
| CDFE n_eff | Effective number of genuinely independent items, from the correlation eigenspectrum |
| CONSTRUCTED / DERIVED / CONJECTURE / VISION | Doctrine of Verifiable Claims tags, from designed to proven to speculative |
| Contact of Record | A named, reachable, answerable party; a dead channel voids the contract (SROC §1) |
| Health Index | ESA Space Environment Health Index; 1 = sustainable benchmark |
| Held (VEILED) | Under investigation; never turned away, never counted until resolved |
| Lean-SIM | Greedy backward elimination: retire only what carries no load |
| LLPM | Longitude–Latitude Property-Management: the POSTERITY Ledger of resources and obligations at coordinates (ERES-LLPM-2026-001) |
| PoR conjunctive gate | Alignment × Resonance × Proportionality × Finality-risk; any zero blocks |
| MIEVM | Multi-Instrument Ensemble Validation Method; SOUND needs ≥4 nodes with mean ≥8.5 |
| Recovery ratio | Recyclable ÷ (Recyclable + Retired), over resolved items or mass |
| REEPER | Detect → route → distribute loop (ERES-PELLIS-EMCI-REEPER-2026-001) |
| Sentry | Alarm role; amber at 97%, red at 98%, last 2–3% held for return to base |
| SHB | "Sound Holds the Band" (ERES-PELLIS-SHB-001): both walls of the band are failure |
| SROC | Smart-Resonant Offset Contract |
| THOW / VLSA | Tiny House on Wheels; "works in a THOW = works on a generation ship" |

## Appendix C — Mathematical formalization ("show math")

Tags follow the Doctrine of Verifiable Claims. **DERIVED** here means derived *within the stated model*; it does not mean the model is true of the world. Every result marked [T##] is checked by the test suite.

### C.1 Objects, dispositions and the recovery ratio

Let $I$ be the set of items (corpus) or objects (orbit) touched by the loop in a period. Each item $i$ has a weight $w_i > 0$ (1 per unique item in Application 1; mass in tonnes in Application 2) and a disposition $d_i \in \{\mathrm{Rec}, \mathrm{Held}, \mathrm{Ret}\}$.

$$W_{\mathrm{Rec}} = \sum_{d_i=\mathrm{Rec}} w_i, \qquad W_{\mathrm{Ret}} = \sum_{d_i=\mathrm{Ret}} w_i, \qquad \rho = \frac{W_{\mathrm{Rec}}}{W_{\mathrm{Rec}} + W_{\mathrm{Ret}}}$$

Held items appear in neither sum: they are VEILED until resolved. $\rho$ is undefined when nothing is resolved. [T03] — CONSTRUCTED definition.

Exact copies are one item: if $\mathrm{sha256}(a) = \mathrm{sha256}(b)$ then $a$ and $b$ are the same $i$. Collapsing copies never changes $W_{\mathrm{Ret}}$. [T02]

### C.2 The ERES Recycling band

$$\mathcal{B} = [\rho_{\mathrm{lo}}, \rho_{\mathrm{hi}}] = [0.97,\ 0.98]$$

Equivalently, with $N = W_{\mathrm{Rec}} + W_{\mathrm{Ret}}$ the resolved weight, the retired share $r = 1 - \rho$ must satisfy

$$0.02\,N \;\le\; W_{\mathrm{Ret}} \;\le\; 0.03\,N .$$

Verdict function: $V(\rho) = \text{lower wall}$ if $\rho < 0.97$; $\text{in band}$ if $0.97 \le \rho \le 0.98$; $\text{upper wall}$ if $\rho > 0.98$. [T01, T09] — the numbers 0.97 and 0.98 are author-declared policy (CONSTRUCTED).

**Proposition 1 (batch size) — DERIVED.** For unit weights, an integer number of retirements $R$ lands in the band iff $\lceil 0.02N \rceil \le \lfloor 0.03N \rfloor$. This holds for $N \in [34, 50]$ and for every $N \ge 67$; it fails for $N \le 33$ and for $51 \le N \le 66$.

*Proof sketch.* For $N \ge 100$ the interval $[0.02N, 0.03N]$ has width $0.01N \ge 1$ and so contains an integer. The cases $N < 100$ are checked exhaustively. ∎ [T16]

*Consequence.* A small batch cannot be judged in band on its own. Application 1 must judge the band over the whole resolved manifest, or over batches of at least 67 resolved items.

### C.3 The Sentry margin law and which edge holds

Let the working band of a capacity have width $\Delta K$. Load drifts toward the upper wall at rate $v$, and the system needs time $\tau$ from alarm to effective response. During the response, load rises by $v\tau$. A reserve share $m$ (alarm at $1-m$ of capacity) prevents a breach iff

$$v\,\tau \;\le\; m\,\Delta K \qquad\Longrightarrow\qquad m^{*} = \frac{v\,\tau}{\Delta K}.$$

So the 98/2 edge ($m = 0.02$) holds iff $v\tau \le 0.02\,\Delta K$; the 97/3 edge ($m = 0.03$) iff $v\tau \le 0.03\,\Delta K$; if $v\tau > 0.03\,\Delta K$, neither holds and F2 fails for that domain. [T07] — DERIVED within the linear-drift model (GAIA-GRID Appendix B); the shares 2 and 3 stay policy.

### C.4 Two walls as one cost

The two-sided band is a dead-zone loss: no cost inside, linear cost outside.

$$\mathcal{L}(\rho) = \alpha\,\max(0,\ 0.97 - \rho) \;+\; \beta\,\max(0,\ \rho - 0.98), \qquad \alpha, \beta > 0$$

$\alpha$ prices lost load-bearing content; $\beta$ prices kept waste. Minimizers of $\mathcal{L}$ are exactly the band $\mathcal{B}$ for any positive $\alpha, \beta$. The weights are not needed to locate the band, so they stay OPEN without blocking anything. — DERIVED.

### C.5 Disposition as one rule for every domain

Every domain supplies an adapter $A_D$ that maps its item to five booleans $x = (s, u, k, q, c)$: in service value $s$, identified $u$, immutable $k$, retire requested $q$, validated $c$. The one rule is

$$\delta(x) = \begin{cases} \mathrm{Held} & \text{if } u = 0 \\ \mathrm{Rec} & \text{if } u = 1,\ k = 1 \\ \mathrm{Ret} & \text{if } u = 1,\ k = 0,\ q = 1,\ c = 1 \\ \mathrm{Held} & \text{if } u = 1,\ k = 0,\ q = 1,\ c = 0 \\ \mathrm{Rec} & \text{if } u = 1,\ k = 0,\ q = 0,\ s = 1 \\ \mathrm{Held} & \text{otherwise.} \end{cases}$$

The disposition of item $i$ in domain $D$ is $\delta(A_D(i))$. Only $A_D$ changes between domains. F4 and F6 claim $\delta$ never has to change. [T13, T14, T15]

Two properties follow directly from the cases:

- **What-completeness.** $u = 0 \Rightarrow \delta = \mathrm{Held}$. No unidentified item is ever dropped or retired. [T15]
- **No unilateral retirement.** $\delta = \mathrm{Ret} \Rightarrow q = 1 \wedge c = 1$. Retirement needs a request and a second, validating signature. [T05]

### C.6 Three-principle gate

$$G = g_{\mathrm{self}} \cdot g_{\mathrm{others}} \cdot g_{\mathrm{future}}, \qquad g \in \{0, 1\}$$

An intervention counts only if $G = 1$. The product is a minimum: improvement on one axis cannot buy a failure on another. [T11]

### C.7 Removal priority (Lean-SIM by load per tonne)

Each candidate object $j$ has mass $m_j$ and cascade-load contribution $\ell_j$. With a removal budget $B$ tonnes, choose $x_j \in [0, 1]$ to

$$\max \sum_j \ell_j x_j \quad \text{subject to} \quad \sum_j m_j x_j \le B .$$

This is the fractional knapsack. Sorting by $\ell_j / m_j$ and filling greedily is optimal (exchange argument: swapping mass from a lower-ratio to a higher-ratio object never lowers the objective). For whole objects ($x_j \in \{0,1\}$) greedy is an approximation. — DERIVED for the fractional case. [T08]

**F1 decision rule.** Compare the targeted order with $K = 30$ random orders at equal budget. If the targeted order removes more load than every random order, the chance of that under the null "order does not matter" is at most $1/(K+1) = 1/31 \approx 0.032$.

### C.8 Counting what is distinct (CDFE $n_{\mathrm{eff}}$)

For a correlation matrix with eigenvalues $\lambda_1, \dots, \lambda_n$ (Galwey 2009):

$$n_{\mathrm{eff}} = \frac{\left(\sum_k \sqrt{\lambda_k}\right)^2}{\sum_k \lambda_k}$$

For two items with correlation $r$, the eigenvalues are $1 \pm r$, so $n_{\mathrm{eff}} = \left(\sqrt{1+r} + \sqrt{1-r}\right)^2 / 2$: $r = 0 \Rightarrow 2$, $r = 1 \Rightarrow 1$, $r = 0.9 \Rightarrow 1.436$. Near-duplicates count as less than two. [T18]

*Correction found by T18:* the value at $r = 0.9$ is 1.436, which rounds to 1.44. The figure 1.43 carried in the ERES-CDFE-2026-001 record is a truncation, not a rounding; the substance (fewer than 1.5 effective items) is unchanged. — DERIVED identity; its use as a near-duplicate score is CONSTRUCTED.

### C.9 Offset ledger

For operator $o$ with deficit $D_o$ and credit $C_o$, a disposition of mass $m$ updates

$$D_o \leftarrow \max(0,\ D_o - m) \quad \text{(recycle or deorbit)}, \qquad C_o \leftarrow C_o + m \cdot \mathbb{1}[\text{recycle}] .$$

Both routes clear debt equally; only recycling earns credit. For an operator choosing between the two at equal cost, recycling weakly dominates, which pushes $\rho$ upward toward the band. [T10] — CONSTRUCTED mechanism; valuation of $m$ against Health Index share is OPEN.

### C.10 Why removal is required: a toy cascade model

A standard illustrative model for the number of objects $N(t)$ in one shell:

$$\frac{dN}{dt} = L - \left(\frac{1}{T} + \rho_{\mathrm{rem}}\right) N + k N^2$$

with launch rate $L$, natural decay time $T$, active removal rate $\rho_{\mathrm{rem}}$, and collision growth coefficient $k$. Write $a = 1/T + \rho_{\mathrm{rem}}$. Equilibria are

$$N_{\pm} = \frac{a \mp \sqrt{a^2 - 4kL}}{2k}.$$

A stable, bounded population exists iff $a^2 \ge 4kL$, that is

$$\rho_{\mathrm{rem}} \;\ge\; \rho^{*} = 2\sqrt{kL} - \frac{1}{T}.$$

Below $\rho^{*}$ the population grows without bound: the upper wall. Two readings follow, both DERIVED within the toy model:

1. When collisions dominate natural decay ($2\sqrt{kL} > 1/T$), some active removal is required. This matches ESA's 2026 statement in form, not in number.
2. The required removal rate grows with the square root of the launch rate. Doubling launches raises $\rho^{*}$'s collision term by about 41%.

The model has no fitted parameters and is not a forecast. [T17] — ILLUSTRATIVE.

### C.11 Stage gate

$$\text{Open}(\text{App. 2}) \iff O = 0 \;\wedge\; L_{\mathrm{mis}} = 0 \;\wedge\; \neg F_3 \;\wedge\; \rho \in \mathcal{B}$$

with $O$ the orphan count and $L_{\mathrm{mis}}$ the license-mismatch count. [T12]

### C.12 Where — tile ledger and the no-surveillance property

Let $\mathcal{T}$ be the set of tiles $\tau = (\varphi, \lambda)$ and $R_\tau$ the resource records on tile $\tau$. Records carry an asset class, a trust state $\sigma \in \{\mathrm{OPEN}, \mathrm{VEILED}, \mathrm{EARNED}\}$, a weight and a disposition. Persons appear only as opaque VEILED references $e$.

**Per-tile ratio.** $\rho_\tau = W^{\tau}_{\mathrm{Rec}} / (W^{\tau}_{\mathrm{Rec}} + W^{\tau}_{\mathrm{Ret}})$, computed over $R_\tau$ only.

**Proposition 2 (aggregation) — DERIVED.** With resolved weight $N_\tau = W^{\tau}_{\mathrm{Rec}} + W^{\tau}_{\mathrm{Ret}}$,

$$\rho = \frac{\sum_\tau N_\tau\, \rho_\tau}{\sum_\tau N_\tau}.$$

*Proof.* $\sum_\tau N_\tau \rho_\tau = \sum_\tau W^{\tau}_{\mathrm{Rec}} = W_{\mathrm{Rec}}$ and $\sum_\tau N_\tau = N$. ∎ [T22]

So the global band verdict is a weighted mean of tile verdicts, and a tile can be outside the band while the whole is inside it. Regions should read both.

**Query interface.** The ledger exposes exactly one query,

$$Q : \mathcal{T} \to 2^{\text{public records}}, \qquad Q(\tau) = \{\, \pi(r) : r \in R_\tau \,\}$$

where $\pi$ strips every person-layer field. There is no function $L : e \mapsto \tau$. **No-surveillance (I6)** is the statement that $L$ is not in the interface, and **describability (I4)** that $\pi(r)$ contains no person field. Both are structural; they are tested by attempting the forbidden call and inspecting $\pi$'s output (T21). Whether an outsider can *infer* a location from public records is a separate, statistical question (F7, third-party audit OPEN).

**Water-commons (I1).** For any disposition $\delta$ and record $r$ with class WATER: $\sigma(\delta(r)) \neq \mathrm{EARNED\text{-}private}$. [T19]

### C.13 Routing gate

$$\mathrm{Act} \iff \bigl(A \cdot R \cdot P \cdot F > 0\bigr) \;\wedge\; \bigl(q \ge q_{\min}(\text{finality})\bigr), \qquad q_{\min} \in \{4/7,\ 5/7,\ 6/7\}$$

The product form makes any zero factor decisive, so no quorum can override it. [T23]

### C.14 Summary of claim strength

| Result | Strength |
| --- | --- |
| Recovery ratio, band verdict, disposition rule, gates, ledger | CONSTRUCTED definitions |
| Batch-size proposition (C.2) | DERIVED |
| Margin law and edge validity (C.3) | DERIVED within the linear-drift model |
| Dead-zone loss minimizers (C.4) | DERIVED |
| Greedy optimality, fractional case (C.7); F1 bound 1/31 | DERIVED |
| $n_{\mathrm{eff}}$ two-item formula (C.8) | DERIVED identity |
| Removal threshold $\rho^{*}$ (C.10) | DERIVED within an illustrative toy model |
| Tile aggregation (C.12, Proposition 2) | DERIVED |
| No-surveillance and describability (C.12) | Structural property of the interface; inference resistance OPEN |
| The numbers 0.97 and 0.98 | Author-declared policy |
| Any claim that the band is achievable in orbit | CONJECTURE until F1, F2 run on real data |

## Appendix B — Change log

**v0.3 → v0.4**

- Added the fourth question, **Where**, bound to the LLPM POSTERITY Ledger (§0, §2.5). LLPM invariants I1–I6 adopted as hard rules.
- Per-tile recovery ratio over the resource layer only, with Proposition 2 (tile ratios aggregate exactly to the global ratio) (C.12).
- Folded REEPER v0.2's conjunctive gate ahead of the tiered quorum (§2.6, C.13).
- Added the first real evidence: a read-only inventory of two ERES archives, with drift found (§4.5) and the manifest shipped as an evidence file.
- Added falsifiers F7 (no person can be located) and F8 (tile aggregation); tests T19–T24; SKIP S5 (person-layer VEIL cryptography).
- Updated Figure titles and the package for the developer starter kit.

**v0.2 → v0.3**

- Widened the scope: the instrument now answers what, why and how to recycle everything made (§0). The corpus and orbit become Applications 1 and 2.
- Clarified that everything made is in scope but only 97–98% of what is resolved is expected to return to use; the 2–3% retired is part of the design (§0).
- Defined "Recyclable" broadly: any route back to use, with material recovery as one route (§0).
- Added candidate further applications: electronics, built environment, water and agriculture, data and compute (§5.5).
- Added falsifier F6 (a new domain needs only an adapter) and tests T14–T15.
- Retitled; Figure 1 and the story image labels updated.
- Added Appendix C, the mathematical formalization: recovery ratio, band and batch-size proposition, margin law, dead-zone loss, the one disposition rule, removal priority with the F1 bound, n_eff, ledger, a toy cascade model with removal threshold, and the stage gate. Tests T16–T18 added. T18 caught a truncation: n_eff at r = 0.9 is 1.436 (≈1.44), not 1.43.

**v0.1 → v0.2**

- Bound the loop to the ERES Recycling band 97/3–98/2 (§3), with two walls and a recovery ratio.
- Dovetailed the band with the Sentry reserve and the margin law m* = v·τ (§3.2).
- Added disposition rules (§2.3), three-principle gate (§2.4), manifest schema and tool (§4.2), band as Stage 1 exit condition (§4.4).
- Recast Stage 2 as a governance concept with a two-tier legal path, responsibility matrix and host options (§5.3).
- Made falsifiers into protocols and added F4 and F5 (§6).
- Merged the Future Map horizons into the instrument (§7) and recorded MIEVM Round 1 (§8).
- Issued as a full package with test suite, figures, citation and manifest.

---

## Credits

**Author:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. Sole accountable author.  
**Sentience (H2C2H):** drafting assistance by Claude (Anthropic), credited under the ERES Sentience convention, not co-authorship.  
**MIEVM Round 1 nodes:** DeepSeek, ChatGPT, Qwen 3.7-Plus, Gemini. Their findings are credited where adopted (§8); no node endorses this instrument.  
**Mathematical lineage:** the SHB band and spectral framing draw on the Track-B dialogue with Dr. Stergios Pellis; this instrument's governance and grading are ERES's, not his.

## References

1. ESA Space Debris Office. *ESA Space Environment Report 2026*, 14 Sep 2026. https://www.esa.int/Space_Safety/Space_Debris/ESA_Space_Environment_Report_2026 · full report: https://www.sdo.esoc.esa.int/environment_report/Space_Environment_Report_I10R1_20260908.pdf
2. New Space Economy. "What does NASA's September 2026 orbital debris report reveal about the future of crowded orbits," 29 Sep 2026. https://newspaceeconomy.ca/2026/09/29/what-does-nasas-september-2026-orbital-debris-report-reveal-about-the-future-of-crowded-orbits/
3. Kessler, D. J. & Cour-Palais, B. G. (1978). "Collision frequency of artificial satellites: the creation of a debris belt." *Journal of Geophysical Research* 83(A6), 2637–2646.
4. Treaty on Principles Governing the Activities of States in the Exploration and Use of Outer Space (Outer Space Treaty), 1967, Articles VI, VII, VIII.
5. Convention on International Liability for Damage Caused by Space Objects, 1972.
6. Convention on Registration of Objects Launched into Outer Space, 1975.
7. UN COPUOS. *Space Debris Mitigation Guidelines*, 2007 (non-binding).
8. ESA. *Zero Debris Charter*, 2023. https://www.esa.int/Space_Safety/Clean_Space/The_Zero_Debris_Charter
9. U.S. Federal Communications Commission. *Space Innovation; Mitigation of Orbital Debris in the New Space Age*, Second Report and Order (5-year rule), 2022.
10. Galwey, N. W. (2009). "A new measure of the effective number of tests, a practical tool for comparing families of non-independent significance tests." *Genetic Epidemiology* 33(7), 559–568.
11. ERES-LLPM-2026-001, *The Longitude–Latitude Property-Management Instrument (POSTERITY Ledger)*, v0.1, 25 July 2026. ERES-PELLIS-EMCI-REEPER-2026-001 v0.2, 6 August 2026. ERES-EMCI-SLA-2026-001 v0.1, 1 August 2026.
12. ERES companion and lineage instruments: ERES-CLEANSPACE-FUTUREMAP-2026-001 · ERES-PELLIS-SHB-001 · ERES-GAIA-GRID-2026-001 (margin law, Appendix B) · ERES-SROC-SCALULAR-2026-001 · ERES-CDFE-2026-001 · ERES-PELLIS-EMCI-REEPER-2026-001 · ERES-FLOOR-REGISTER-2026-001 · ERES-CLAUDE-REGISTRY-2026-001 · ERES-ECONOMIC-THEORY-LINEAGE-2026-001 (Spaceship Economics, DOI 10.6084/m9.figshare.32975624).
13. GA-CLEANSPACE-CONVENTION-2026-001, *Draft Convention on Satellite Sunsetting and Orbital Cleanup* (discussion draft, MIEVM Round 1 workup, separate lineage).

## License

CCAL v2.1 / CC-BY 4.0. The governing CCAL v2.1 text is Zenodo DOI 10.5281/zenodo.23451312, which controls over any mirror (CCAL §13). CCAL v2.1 matches CC-BY 4.0 in attribution and adds the Care Clause, Earth-First Constraint, Transparency, Share-Forward, Non-Enclosure and Patent Non-Assertion. Derivatives may be released under CC-BY 4.0 per CCAL §12.
