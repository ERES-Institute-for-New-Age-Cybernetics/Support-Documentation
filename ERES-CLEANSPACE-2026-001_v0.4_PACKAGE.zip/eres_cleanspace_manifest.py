#!/usr/bin/env python3
"""
eres_cleanspace_manifest.py  --  Application 1 (ERES corpus) inventory tool for ERES-CLEANSPACE-2026-001 v0.4

Walks one or more directories, hashes every file (SHA-256), infers ERES instrument ID
and version from the file name, collapses exact-hash copies, assigns a disposition
(Recyclable / Held / Retired), checks registry dependencies, and reports the
ERES Recycling band 97/3-98/2.

Standard library only. Read-only: this tool never moves, renames or deletes a file.
It writes a manifest (JSON and CSV) to the path you give it.

Usage:
    python3 eres_cleanspace_manifest.py DIR [DIR ...] --out manifest
    python3 eres_cleanspace_manifest.py DIR --out manifest --doi doi_list.txt --deps deps.json

License: CCAL v2.1 (governing text DOI 10.5281/zenodo.23451312); CC-BY 4.0 compatible per CCAL s.12.
Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass, field, asdict

# ---------------------------------------------------------------------------
# ERES Recycling band (author-declared policy, CONSTRUCTED)
# ---------------------------------------------------------------------------
BAND_LOW = 0.97    # 97/3 edge: at most 3% of unique content retired
BAND_HIGH = 0.98   # 98/2 edge: at least 2% retired (consolidation actually happened)

RECYCLABLE, HELD, RETIRED = "Recyclable", "Held", "Retired"

ID_RE = re.compile(r"(ERES-[A-Z0-9]+(?:-[A-Z0-9]+)*-\d{4}-\d{3}[A-Z]?)", re.I)
VER_RE = re.compile(r"[_\-\s]v(\d+(?:[._-]\d+){0,2})(?![\d])", re.I)


@dataclass
class Entry:
    path: str
    sha256: str
    size: int
    instrument_id: str | None
    version: str | None
    copies: list = field(default_factory=list)   # other paths with identical hash
    disposition: str = HELD
    reason: str = ""


def sha256_of(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def parse_name(name: str):
    m = ID_RE.search(name)
    iid = m.group(1).upper() if m else None
    v = VER_RE.search(name)
    ver = v.group(1).replace("_", ".").replace("-", ".") if v else None
    return iid, ver


def version_key(ver: str | None):
    if not ver:
        return (-1,)
    return tuple(int(p) for p in re.split(r"[.]", ver) if p.isdigit())


def walk(dirs):
    for d in dirs:
        for root, _, files in os.walk(d):
            for fn in sorted(files):
                p = os.path.join(root, fn)
                if os.path.isfile(p) and not os.path.islink(p):
                    yield p


def build(dirs, doi_ids=frozenset(), deps=None, retire=None):
    """Return (entries, report).
    deps   maps an item -> list of instrument IDs it needs (registry dependencies, F3 guard).
    retire maps a path -> validator name. A retirement needs the author's listing AND a named
           validator (no unilateral disposition); a listing without a validator stays Held."""
    retire = retire or {}
    by_hash: dict[str, Entry] = {}
    for p in walk(dirs):
        h = sha256_of(p)
        if h in by_hash:
            by_hash[h].copies.append(p)          # exact copy: collapsed, not a retirement
            continue
        iid, ver = parse_name(os.path.basename(p))
        by_hash[h] = Entry(p, h, os.path.getsize(p), iid, ver)
    entries = list(by_hash.values())

    # Latest version per instrument ID stays live
    latest: dict[str, tuple] = {}
    for e in entries:
        if e.instrument_id:
            k = version_key(e.version)
            if e.instrument_id not in latest or k > latest[e.instrument_id]:
                latest[e.instrument_id] = k

    needed = set()
    for v in (deps or {}).values():
        needed.update(x.upper() for x in v)

    for e in entries:
        tag = f"{e.instrument_id}@{e.version}" if e.instrument_id else None
        if e.size == 0:
            e.disposition, e.reason = RETIRED, "empty stub"
        elif e.instrument_id is None:
            e.disposition, e.reason = HELD, "no instrument ID: needs author routing"
        elif tag and tag.upper() in doi_ids:
            e.disposition, e.reason = RECYCLABLE, "DOI'd version: immutable, never retired"
        elif version_key(e.version) == latest[e.instrument_id]:
            e.disposition, e.reason = RECYCLABLE, "latest version"
        else:
            e.disposition, e.reason = HELD, "superseded undeposited draft: seal in archive"
        if e.path in retire:
            if tag and tag.upper() in doi_ids:
                pass  # DOI'd versions can never be retired
            elif retire[e.path]:
                e.disposition, e.reason = RETIRED, f"retired by author, validated by {retire[e.path]}"
            else:
                e.disposition, e.reason = HELD, "retirement listed without validator: second signature required"

    # F3 dependency guard: a needed instrument must keep at least one live (non-retired) copy
    for iid in needed:
        group = [e for e in entries if e.instrument_id == iid]
        if group and all(e.disposition == RETIRED for e in group):
            for e in group:
                e.disposition, e.reason = HELD, "dependency guard (F3): last copy of a needed instrument"

    return entries, report(entries)


def recovery_ratio(entries):
    """Share of RESOLVED unique content kept in service. Held items are excluded (VEILED)."""
    rec = sum(1 for e in entries if e.disposition == RECYCLABLE)
    ret = sum(1 for e in entries if e.disposition == RETIRED)
    resolved = rec + ret
    return (rec / resolved) if resolved else None


def band_verdict(r):
    if r is None:
        return "UNRESOLVED"
    if r < BAND_LOW:
        return "LOWER-WALL (over-retirement: >3% retired, load-bearing loss risk)"
    if r > BAND_HIGH:
        return "UPPER-WALL (under-consolidation: <2% retired, bloat persists)"
    return "IN-BAND (97/3-98/2)"


def report(entries):
    counts = {k: sum(1 for e in entries if e.disposition == k) for k in (RECYCLABLE, HELD, RETIRED)}
    copies = sum(len(e.copies) for e in entries)
    r = recovery_ratio(entries)
    return {
        "unique_items": len(entries),
        "exact_copies_collapsed": copies,
        "dispositions": counts,
        "recovery_ratio": None if r is None else round(r, 4),
        "band": band_verdict(r),
        "orphans_no_id": sum(1 for e in entries if e.instrument_id is None),
    }


def write(entries, rep, out):
    with open(out + ".json", "w", encoding="utf-8") as f:
        json.dump({"report": rep, "entries": [asdict(e) for e in entries]}, f, indent=2)
    with open(out + ".csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["path", "sha256", "size", "instrument_id", "version", "disposition", "reason", "copies"])
        for e in entries:
            w.writerow([e.path, e.sha256, e.size, e.instrument_id or "", e.version or "",
                        e.disposition, e.reason, ";".join(e.copies)])


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dirs", nargs="+")
    ap.add_argument("--out", default="cleanspace_manifest")
    ap.add_argument("--doi", help="text file: one INSTRUMENT-ID@version per line that carries a DOI")
    ap.add_argument("--deps", help="JSON file: {item: [instrument IDs it depends on]}")
    ap.add_argument("--retire", help="text file: 'path,validator' per line (author-listed retirements)")
    a = ap.parse_args(argv)
    doi = frozenset()
    if a.doi:
        with open(a.doi, encoding="utf-8") as f:
            doi = frozenset(l.strip().upper() for l in f if l.strip())
    deps = None
    if a.deps:
        with open(a.deps, encoding="utf-8") as f:
            deps = json.load(f)
    retire = {}
    if a.retire:
        with open(a.retire, encoding="utf-8") as f:
            for l in f:
                if l.strip():
                    path, _, val = l.strip().partition(",")
                    retire[path.strip()] = val.strip()
    entries, rep = build(a.dirs, doi, deps, retire)
    write(entries, rep, a.out)
    print(json.dumps(rep, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
