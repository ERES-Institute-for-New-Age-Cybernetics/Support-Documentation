#!/usr/bin/env python3
"""
eres_cleanspace_testkit.py  --  companion test suite for ERES-CLEANSPACE-2026-001 v0.4
"Recycle Everything Made: What, Why, How and Where" (Applications: ERES corpus; Earth orbit / Clean Space)

Standard library only. Deterministic (seed 20261019). Exit code = verdict:
0 = no FAIL (SKIPs allowed), 1 = at least one FAIL.

What this suite tests: the STRUCTURAL rules of the instrument (band edges, disposition
rules, no-unilateral-retirement, dependency guard, margin-law validity, stage gates,
offset-ledger asymmetry, three-principle gate, single decision rule across domains).
What it does NOT test: any real orbital outcome. T08 runs a synthetic toy population;
it shows the prioritization rule is coherent, not that it works in orbit. Load-bearing
SKIPs name the empirical work still owed.

License: CCAL v2.1 (DOI 10.5281/zenodo.23451312); CC-BY 4.0 compatible per CCAL s.12.
"""
from __future__ import annotations

import os
import random
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eres_cleanspace_manifest as M  # noqa: E402
import eres_cleanspace_where as W  # noqa: E402

SEED = 20261019
TESTS_SPEC_VERSION = (0, 4)
RESULTS = []

TRACEABILITY = {
    "T01": "Sec 3.1 Recycling band edges 97/3-98/2",
    "T02": "Sec 4.2 Exact copies collapse; not a retirement",
    "T03": "Sec 3.1 Held (VEILED) excluded from the ratio",
    "T04": "Sec 2.3 DOI'd versions never retired",
    "T05": "Sec 2.3 No unilateral disposition (author + validator)",
    "T06": "Sec 6 F3 dependency guard",
    "T07": "Sec 3.2 Margin law m* = v*tau sets which band edge holds",
    "T08": "Sec 6 F1 targeted vs random removal (toy population)",
    "T09": "Sec 6 F5 band verdict end-to-end on synthetic corpus",
    "T10": "Sec 5.4 Offset ledger: recycling earns credit, deorbit only clears",
    "T11": "Sec 2.4 Three governing principles = conjunctive gate",
    "T12": "Sec 4.4 Application 1 exit gate = Application 2 entry gate",
    "T13": "Sec 6 F4 one decision rule across corpus and orbit",
    "T14": "Sec 5.5 / F6 a third domain needs only an adapter (synthetic e-waste)",
    "T15": "Sec 0 'What': every domain's unidentified item is Held, never dropped",
    "T16": "App C.2 Proposition 1: batch sizes where the band is attainable",
    "T17": "App C.10 toy cascade: bounded iff removal rate >= 2*sqrt(kL) - 1/T",
    "T18": "App C.8 n_eff two-item identity (r=0 -> 2, r=1 -> 1, r=0.9 -> 1.436)",
    "T19": "Sec 2.5 LLPM I1 water-commons: no WATER record becomes EARNED-private",
    "T20": "Sec 2.5 LLPM I2 floor: missing attestation -> care-response; occupied dwelling never retired",
    "T21": "Sec 2.5 / F7 LLPM I4+I6: public view has no person field; no person-location query exists",
    "T22": "App C.12 Proposition 2 / F8: tile ratios aggregate exactly to the global ratio",
    "T23": "Sec 2.6 / C.13 conjunctive gate before tiered quorum",
    "T24": "Sec 2.5 LLPM I5: escrowed claims cannot be retired or transferred",
    "S1": "F1 on real catalogue data (ESA/USSPACECOM) -- OPEN",
    "S2": "F2 measured drift v and latency tau per orbital shell -- OPEN",
    "S3": "Application 1 full-corpus inventory with validated retirements -- OPEN (first partial run: Sec 4.5)",
    "S4": "MIEVM round 2: >=4 nodes, mean >=8.5 -- OPEN",
    "S5": "LLPM person-layer VEIL cryptography (prove entitlement without identity or location) -- OPEN",
}


def record(tid, status, msg):
    RESULTS.append((tid, status, msg))


def check(tid, cond, msg):
    record(tid, "PASS" if cond else "FAIL", msg)


# ---------------------------------------------------------------------------
# helpers shared by both domains (F4: one rule, two adapters)
# ---------------------------------------------------------------------------
def dispose(item):
    """The single disposition rule. item: dict with keys
    in_service_value(bool), identified(bool), immutable(bool), retire_request(bool), validated(bool)."""
    if not item["identified"]:
        return M.HELD
    if item["immutable"]:
        return M.RECYCLABLE
    if item["retire_request"]:
        return M.RETIRED if item["validated"] else M.HELD
    return M.RECYCLABLE if item["in_service_value"] else M.HELD


def corpus_adapter(f):
    return {"in_service_value": f["latest"], "identified": f["id"] is not None,
            "immutable": f["doi"], "retire_request": f["retire"], "validated": f["validator"] is not None}


def orbit_adapter(o):
    return {"in_service_value": o["serviceable"], "identified": o["catalogued"],
            "immutable": False, "retire_request": o["deorbit_request"],
            "validated": o["registry_consent"]}


def margin_valid(v, tau, dK, reserve_share):
    """Margin law (GAIA grid App. B): a reserve share m holds iff v*tau <= m*dK."""
    return v * tau <= reserve_share * dK


def ledger(disposition, mass_t, deficit_t):
    """Offset ledger: returns (deficit_after, credit). Deorbit clears, recycling clears and earns."""
    if disposition == "deorbit":
        return max(0.0, deficit_t - mass_t), 0.0
    if disposition == "recycle":
        return max(0.0, deficit_t - mass_t), mass_t
    return deficit_t, 0.0


def three_principles(no_self_harm, no_other_harm, no_future_harm):
    return all((no_self_harm, no_other_harm, no_future_harm))


def stage2_entry(report, license_mismatches, f3_triggered):
    return (report["orphans_no_id"] == 0 and license_mismatches == 0 and not f3_triggered
            and report["band"].startswith("IN-BAND"))


def mkfile(d, name, content):
    p = os.path.join(d, name)
    with open(p, "wb") as f:
        f.write(content)
    return p


# ---------------------------------------------------------------------------
def t01():
    ok = (M.band_verdict(0.97).startswith("IN-BAND") and M.band_verdict(0.98).startswith("IN-BAND")
          and M.band_verdict(0.9699).startswith("LOWER") and M.band_verdict(0.9801).startswith("UPPER"))
    check("T01", ok, "band edges: 0.97 and 0.98 in; 0.9699 lower wall; 0.9801 upper wall")


def t02():
    with tempfile.TemporaryDirectory() as d:
        mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"A")
        os.mkdir(os.path.join(d, "mirror"))
        mkfile(os.path.join(d, "mirror"), "ERES-TEST-2026-001_v1.0 (copy).md", b"A")
        entries, rep = M.build([d])
    check("T02", rep["unique_items"] == 1 and rep["exact_copies_collapsed"] == 1
          and rep["dispositions"][M.RETIRED] == 0,
          "two identical files -> 1 unique item, 1 copy collapsed, 0 retirements")


def t03():
    with tempfile.TemporaryDirectory() as d:
        mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"old")
        mkfile(d, "ERES-TEST-2026-001_v2.0.md", b"new")
        mkfile(d, "notes.txt", b"unidentified")
        entries, rep = M.build([d])
    check("T03", rep["dispositions"][M.HELD] == 2 and rep["recovery_ratio"] == 1.0,
          "old draft + unidentified file Held; ratio counts resolved items only (1/1)")


def t04():
    with tempfile.TemporaryDirectory() as d:
        p = mkfile(d, "ERES-TEST-2026-001_v1.0.md", b"deposited")
        mkfile(d, "ERES-TEST-2026-001_v2.0.md", b"newer")
        entries, _ = M.build([d], doi_ids=frozenset({"ERES-TEST-2026-001@1.0"}), retire={p: "Validator"})
    e = [x for x in entries if x.path == p][0]
    check("T04", e.disposition == M.RECYCLABLE, "DOI'd v1.0 listed for retirement stays Recyclable")


def t05():
    with tempfile.TemporaryDirectory() as d:
        a = mkfile(d, "ERES-AAA-2026-001_v1.0.md", b"a")
        b = mkfile(d, "ERES-BBB-2026-001_v1.0.md", b"b")
        entries, _ = M.build([d], retire={a: "", b: "Second Signer"})
    disp = {x.path: x.disposition for x in entries}
    check("T05", disp[a] == M.HELD and disp[b] == M.RETIRED,
          "retirement without validator -> Held; with validator -> Retired")


def t06():
    with tempfile.TemporaryDirectory() as d:
        old = mkfile(d, "ERES-ROOT-2026-001_v1.0.md", b"1")
        new = mkfile(d, "ERES-ROOT-2026-001_v2.0.md", b"2")
        deps = {"ERES-CHILD-2026-001": ["ERES-ROOT-2026-001"]}
        e1, _ = M.build([d], deps=deps, retire={old: "V"})
        e2, _ = M.build([d], deps=deps, retire={old: "V", new: "V"})
    d1 = {x.path: x.disposition for x in e1}
    d2 = {x.path: x.disposition for x in e2}
    check("T06", d1[old] == M.RETIRED and d1[new] == M.RECYCLABLE and d2[old] == M.HELD and d2[new] == M.HELD,
          "older copy of a needed root may retire; retiring its last live copy is blocked (Held)")


def t07():
    dK, tau = 1.0, 1.0
    a = margin_valid(0.02, tau, dK, 0.02) and not margin_valid(0.021, tau, dK, 0.02)
    b = margin_valid(0.03, tau, dK, 0.03) and not margin_valid(0.031, tau, dK, 0.03)
    c = margin_valid(0.025, tau, dK, 0.03) and not margin_valid(0.025, tau, dK, 0.02)
    check("T07", a and b and c,
          "98/2 holds iff v*tau <= 0.02*dK; 97/3 iff <= 0.03*dK; 0.025 needs the 97/3 edge; >0.03 fails both (F2)")


def t08():
    rng = random.Random(SEED)
    pop = []
    for _ in range(2000):
        mass = rng.lognormvariate(0, 1.2)
        density = rng.choice([0.2, 0.5, 1.0, 3.0])   # shell congestion factor
        pop.append((mass, mass * density))           # (mass, cascade-load proxy)
    total_load = sum(l for _, l in pop)
    budget = 0.05 * sum(m for m, _ in pop)

    def remove(order):
        spent = removed = 0.0
        for m, l in order:
            if spent + m > budget:
                continue
            spent += m
            removed += l
        return removed / total_load

    targeted = remove(sorted(pop, key=lambda x: -x[1] / x[0]))
    rand_runs = []
    for k in range(30):
        r = random.Random(SEED + k)
        o = pop[:]
        r.shuffle(o)
        rand_runs.append(remove(o))
    rmean = sum(rand_runs) / len(rand_runs)
    check("T08", targeted > max(rand_runs),
          f"toy: equal 5% mass budget removes {targeted:.1%} of load targeted vs {rmean:.1%} random "
          f"(max of 30 random runs {max(rand_runs):.1%}) -- synthetic only")


def t09():
    def corpus(n_retired):
        with tempfile.TemporaryDirectory() as d:
            paths = [mkfile(d, f"ERES-X{i:03d}-2026-001_v1.0.md", str(i).encode()) for i in range(100)]
            _, rep = M.build([d], retire={p: "V" for p in paths[:n_retired]})
        return rep
    r2, r4, r0 = corpus(2), corpus(4), corpus(0)
    check("T09", r2["band"].startswith("IN-BAND") and r4["band"].startswith("LOWER")
          and r0["band"].startswith("UPPER"),
          f"100 unique items: 2 retired -> {r2['recovery_ratio']} in-band; 4 -> {r4['recovery_ratio']} lower wall; "
          f"0 -> {r0['recovery_ratio']} upper wall")


def t10():
    d_after, c = ledger("deorbit", 3.0, 5.0)
    r_after, rc = ledger("recycle", 3.0, 5.0)
    check("T10", d_after == r_after == 2.0 and c == 0.0 and rc == 3.0,
          "same 3 t against a 5 t deficit: both clear to 2 t; only recycling earns 3 t credit")


def t11():
    ok = three_principles(True, True, True) and not three_principles(True, False, True) \
        and not three_principles(True, True, False)
    check("T11", ok, "an intervention that improves a metric but harms others or the future fails the gate")


def t12():
    good = {"orphans_no_id": 0, "band": "IN-BAND (97/3-98/2)"}
    ok = stage2_entry(good, 0, False) and not stage2_entry(good, 1, False) \
        and not stage2_entry(good, 0, True) \
        and not stage2_entry({"orphans_no_id": 0, "band": "UPPER-WALL"}, 0, False) \
        and not stage2_entry({"orphans_no_id": 3, "band": "IN-BAND"}, 0, False)
    check("T12", ok, "Application 2 opens only on zero orphans, zero license mismatches, F3 clear, band in-band")


def t13():
    f = {"latest": True, "id": "ERES-A-2026-001", "doi": False, "retire": False, "validator": None}
    o = {"serviceable": True, "catalogued": True, "deorbit_request": False, "registry_consent": False}
    cases = [
        (dict(f), dict(o)),
        (dict(f, retire=True), dict(o, deorbit_request=True)),
        (dict(f, retire=True, validator="V"), dict(o, deorbit_request=True, registry_consent=True)),
        (dict(f, id=None), dict(o, catalogued=False)),
    ]
    same = all(dispose(corpus_adapter(a)) == dispose(orbit_adapter(b)) for a, b in cases)
    check("T13", same, "four paired cases give identical dispositions under one rule; only adapters differ")


def ewaste_adapter(x):
    return {"in_service_value": x["repairable"], "identified": x["tagged"],
            "immutable": False, "retire_request": x["hazard_retire"], "validated": x["certified"]}


def t14():
    devices = [
        {"repairable": True, "tagged": True, "hazard_retire": False, "certified": False},
        {"repairable": False, "tagged": True, "hazard_retire": True, "certified": True},
        {"repairable": False, "tagged": True, "hazard_retire": True, "certified": False},
        {"repairable": True, "tagged": False, "hazard_retire": False, "certified": False},
    ]
    got = [dispose(ewaste_adapter(x)) for x in devices]
    want = [M.RECYCLABLE, M.RETIRED, M.HELD, M.HELD]
    check("T14", got == want,
          "synthetic e-waste: repairable -> Recyclable; certified hazard -> Retired; uncertified -> Held; "
          "untagged -> Held, with no new rule")


def t15():
    unknowns = [corpus_adapter({"latest": True, "id": None, "doi": False, "retire": True, "validator": "V"}),
                orbit_adapter({"serviceable": True, "catalogued": False, "deorbit_request": True,
                               "registry_consent": True}),
                ewaste_adapter({"repairable": True, "tagged": False, "hazard_retire": True, "certified": True})]
    check("T15", all(dispose(u) == M.HELD for u in unknowns),
          "an unidentified item in any domain is Held, even with a validated retire request")


def t16():
    import math
    feas = [N for N in range(1, 400) if math.ceil(0.02 * N - 1e-12) <= math.floor(0.03 * N + 1e-12)]
    infeas = sorted(set(range(1, 400)) - set(feas))
    expect = list(range(1, 34)) + list(range(51, 67))
    check("T16", infeas == expect,
          "band attainable for N in [34,50] and every N >= 67; not for N <= 33 or 51..66")


def t17():
    import math
    L, k, T = 1.0, 0.001, 50.0
    rstar = 2 * math.sqrt(k * L) - 1 / T

    def bounded(rho, years=3000, dt=0.05):
        n, a = 0.0, 1 / T + rho
        for _ in range(int(years / dt)):
            n += dt * (L - a * n + k * n * n)
            if n > 1e6:
                return False
        return True
    check("T17", bounded(rstar * 1.05) and not bounded(rstar * 0.95),
          f"toy model (L=1, k=0.001, T=50): rho* = {rstar:.4f}; bounded at +5%, unbounded at -5% (illustrative)")


def t18():
    import math
    ne = lambda r: (math.sqrt(1 + r) + math.sqrt(1 - r)) ** 2 / 2
    check("T18", abs(ne(0) - 2) < 1e-12 and abs(ne(1) - 1) < 1e-12 and abs(ne(0.9) - 1.436) < 0.0005,
          f"n_eff(0)=2, n_eff(1)=1, n_eff(0.9)={ne(0.9):.3f} (rounds to 1.44; the CDFE record's 1.43 is truncated)")


def t19():
    r = W.Record(tile=(36.48, -94.23), asset_class=W.WATER)
    blocked = False
    try:
        W.set_trust(r, W.EARNED_PRIVATE)
    except W.InvariantViolation:
        blocked = True
    W.set_trust(r, W.EARNED_COMMONS)
    a = W.Record(tile=(36.48, -94.23), asset_class=W.AG)
    W.set_trust(a, W.EARNED_PRIVATE)
    check("T19", blocked and r.trust_state == W.EARNED_COMMONS and a.trust_state == W.EARNED_PRIVATE,
          "WATER -> EARNED-private refused; WATER -> commons allowed; AG -> private allowed")


def t20():
    d = W.Record(tile=(1, 1), asset_class=W.THOW_SLOT, occupied=True, floor_attested=False)
    care = W.floor_check(d) == "care-response"
    refused = False
    try:
        W.retire(d, validated=True)
    except W.InvariantViolation:
        refused = True
    check("T20", care and refused and d.disposition != W.RETIRED,
          "missing attestation -> care-response; retiring an occupied dwelling is refused even when validated")


def t21():
    L = W.TileLedger()
    L.add(W.Record(tile=(2, 2), asset_class=W.THOW_SLOT, occupied=True, entitlement_ref="veiled:9f3a",
                   steward_ref="veiled:77c1"))
    view = L.query((2, 2))
    no_person = all(f not in v for v in view for f in W.PERSON_FIELDS)
    blocked = []
    for name in ("locate_person", "person_location", "where_is"):
        try:
            getattr(L, name)("veiled:9f3a")
            blocked.append(False)
        except W.InvariantViolation:
            blocked.append(True)
    check("T21", no_person and all(blocked) and len(view) == 1,
          "coordinate query returns the resource without person fields; every person-location call is refused")


def t22():
    rng = random.Random(SEED)
    L = W.TileLedger()
    for _ in range(500):
        tile = (rng.randint(0, 9), rng.randint(0, 9))
        disp = rng.choices([W.RECYCLABLE, W.RETIRED, W.HELD], [0.9, 0.03, 0.07])[0]
        L.add(W.Record(tile=tile, asset_class=W.MADE_THING, weight=rng.uniform(0.1, 5), disposition=disp))
    num = sum(L.resolved_weight(t) * L.tile_ratio(t) for t in L.tiles() if L.tile_ratio(t) is not None)
    den = sum(L.resolved_weight(t) for t in L.tiles())
    check("T22", abs(num / den - L.global_ratio()) < 1e-12,
          f"weighted tile ratios {num / den:.6f} = global ratio {L.global_ratio():.6f} over {len(L.tiles())} tiles")


def t23():
    ok = (W.route(1, 1, 1, 1, 4, "reversible") and not W.route(1, 1, 0, 1, 7, "reversible")
          and not W.route(1, 1, 1, 1, 4, "consequential") and W.route(1, 1, 1, 1, 5, "consequential")
          and not W.route(1, 1, 1, 1, 7, "irreversible", dignitary_dissents=True)
          and W.route(1, 1, 1, 1, 6, "irreversible"))
    check("T23", ok, "a zero factor blocks even 7/7; quorum tiers 4/5/6 of 7; irreversible needs no Dignitary dissent")


def t24():
    e = W.Record(tile=(3, 3), asset_class=W.THOW_SLOT, escrowed=True, entitlement_ref="veiled:future")
    hits = 0
    for op in (lambda: W.retire(e, validated=True), lambda: W.transfer(e, "veiled:buyer")):
        try:
            op()
        except W.InvariantViolation:
            hits += 1
    check("T24", hits == 2 and e.entitlement_ref == "veiled:future",
          "an escrowed claim can be neither retired nor transferred")


def skips():
    for s in ("S1", "S2", "S3", "S4", "S5"):
        record(s, "SKIP", TRACEABILITY[s])


def main():
    for t in (t01, t02, t03, t04, t05, t06, t07, t08, t09, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24):
        try:
            t()
        except Exception as ex:  # a crash is a FAIL, never a silent pass
            record(t.__name__.upper(), "FAIL", f"exception: {ex!r}")
    skips()
    print("ERES-CLEANSPACE-2026-001 v0.4 testkit  (spec %d.%d, seed %d)" % (*TESTS_SPEC_VERSION, SEED))
    print("-" * 78)
    for tid, st, msg in RESULTS:
        print(f"{tid:4} {st:5} {msg}")
    n = {k: sum(1 for _, s, _ in RESULTS if s == k) for k in ("PASS", "FAIL", "SKIP")}
    print("-" * 78)
    print(f"{n['PASS']} PASS / {n['FAIL']} FAIL / {n['SKIP']} SKIP  (SKIPs are load-bearing: empirical work owed)")
    print("Traceability:")
    for k, v in TRACEABILITY.items():
        print(f"  {k}: {v}")
    return 1 if n["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(main())
