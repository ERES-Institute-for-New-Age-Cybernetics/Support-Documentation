#!/usr/bin/env python3
"""
eres_cleanspace_where.py  --  the "Where" layer of ERES-CLEANSPACE-2026-001 v0.4

A minimal reference implementation of the LLPM binding (ERES-LLPM-2026-001 invariants I1, I2, I4,
I5, I6) and the REEPER routing gate (ERES-PELLIS-EMCI-REEPER-2026-001 v0.2 s.3), used by the test
suite and offered to developers as the starting point for real ledgers.

Design rules, enforced in code:
  * Resources live at coordinates; people never do. A person appears only as an opaque VEILED
    reference on a record. There is no person -> coordinate function, by construction (I6).
  * Public views strip every person-layer field (I4).
  * WATER records can never be moved into a private trust state (I1).
  * A missing floor attestation on an occupied dwelling returns a care-response, never a
    retirement or removal (I2).
  * Escrowed entitlements and future claims cannot be retired or transferred (I5).
  * Routing: conjunctive gate A*R*P*F first, then a quorum tiered by finality risk.

Standard library only. License: CCAL v2.1 (DOI 10.5281/zenodo.23451312); CC-BY 4.0 compatible.
"""
from __future__ import annotations

from dataclasses import dataclass, field

RECYCLABLE, HELD, RETIRED = "Recyclable", "Held", "Retired"
WATER, AG, THOW_SLOT, GSSG_NODE, COI_TERRITORY, MADE_THING = (
    "WATER", "AG", "THOW-slot", "GSSG-node", "CoI-territory", "made-thing")
OPEN, VEILED, EARNED_COMMONS, EARNED_PRIVATE = "OPEN", "VEILED", "EARNED-commons", "EARNED-private"

PERSON_FIELDS = ("entitlement_ref", "steward_ref")


class InvariantViolation(Exception):
    """Raised when an operation would break an LLPM invariant."""


@dataclass
class Record:
    tile: tuple                      # (lat, lon) -- a resource location, never a person location
    asset_class: str
    weight: float = 1.0
    trust_state: str = OPEN
    disposition: str = HELD
    occupied: bool = False
    floor_attested: bool = True
    escrowed: bool = False           # I5: entitlement held in trust / future claim
    entitlement_ref: str | None = None   # VEILED opaque reference, never an identity
    steward_ref: str | None = None       # VEILED opaque reference (REEPER s.6 stewardship)


@dataclass
class TileLedger:
    records: list = field(default_factory=list)

    def add(self, r: Record) -> None:
        self.records.append(r)

    # ---- the only query (I6): coordinate -> public resource records -----------------------
    def query(self, tile: tuple) -> list:
        return [public_view(r) for r in self.records if r.tile == tile]

    # There is deliberately no locate_person(). Any attempt is refused.
    def __getattr__(self, name):
        if "locate" in name or "person" in name or "where_is" in name:
            raise InvariantViolation("I6: the ledger cannot be queried to locate a person")
        raise AttributeError(name)

    # ---- recovery ratios over the resource layer -----------------------------------------
    def tile_ratio(self, tile: tuple):
        rec = sum(r.weight for r in self.records if r.tile == tile and r.disposition == RECYCLABLE)
        ret = sum(r.weight for r in self.records if r.tile == tile and r.disposition == RETIRED)
        return None if rec + ret == 0 else rec / (rec + ret)

    def resolved_weight(self, tile: tuple) -> float:
        return sum(r.weight for r in self.records if r.tile == tile and r.disposition in (RECYCLABLE, RETIRED))

    def global_ratio(self):
        rec = sum(r.weight for r in self.records if r.disposition == RECYCLABLE)
        ret = sum(r.weight for r in self.records if r.disposition == RETIRED)
        return None if rec + ret == 0 else rec / (rec + ret)

    def tiles(self):
        return sorted({r.tile for r in self.records})


def public_view(r: Record) -> dict:
    """I4: the resource layer is public; every person-layer field is stripped."""
    return {"tile": r.tile, "asset_class": r.asset_class, "weight": r.weight,
            "trust_state": r.trust_state, "disposition": r.disposition,
            "occupied": r.occupied, "floor_attested": r.floor_attested}


def set_trust(r: Record, new_state: str) -> Record:
    """I1: WATER can never be enclosed into a private trust state."""
    if r.asset_class == WATER and new_state == EARNED_PRIVATE:
        raise InvariantViolation("I1: WATER-class record cannot become EARNED-private")
    r.trust_state = new_state
    return r


def floor_check(r: Record) -> str:
    """I2: a missing attestation on an occupied dwelling is a call for care, never removal."""
    if r.asset_class == THOW_SLOT and r.occupied and not r.floor_attested:
        return "care-response"
    return "ok"


def retire(r: Record, validated: bool) -> Record:
    """Retire a record from service, subject to I2 and I5 and the second-signature rule."""
    if r.escrowed:
        raise InvariantViolation("I5: escrowed entitlement / future claim cannot be retired")
    if r.asset_class == THOW_SLOT and r.occupied:
        raise InvariantViolation("I2: an occupied dwelling is never retired; respond with care")
    if not validated:
        r.disposition = HELD
        return r
    r.disposition = RETIRED
    return r


def transfer(r: Record, new_ref: str) -> Record:
    """I5: an escrowed claim cannot be sold or transferred out from under its holder."""
    if r.escrowed:
        raise InvariantViolation("I5: escrowed entitlement / future claim cannot be transferred")
    r.entitlement_ref = new_ref
    return r


QUORUM = {"reversible": 4, "consequential": 5, "irreversible": 6}


def route(alignment: float, resonance: float, proportionality: float, finality_clear: float,
          seats_for: int, finality: str, dignitary_dissents: bool = False) -> bool:
    """REEPER s.3: conjunctive gate first (any zero blocks), then a quorum tiered by finality."""
    if alignment * resonance * proportionality * finality_clear <= 0:
        return False
    if seats_for < QUORUM[finality]:
        return False
    if finality == "irreversible" and dignitary_dissents:
        return False
    return True
