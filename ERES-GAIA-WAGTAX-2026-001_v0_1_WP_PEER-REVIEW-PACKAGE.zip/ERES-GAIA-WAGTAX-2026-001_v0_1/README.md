# ERES-GAIA-WAGTAX-2026-001 · v0.1 · Peer-Review Package

**Tax the Over-Draw, Not the Person**
*The GAIA Water–Ag Levy: a fair and equitable global tax system phased in through WATER/AG, with the key metrics for Future Mapping*

Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221 · CCAL v2.1 / CC BY 4.0
Status: DRAFT / PROPOSED, pre-MIEVM · ERES House Format v0.4 · Grade GOOD, SOUND-candidate · single-node 8.6 (capped < 9.0)

---

## In one line

**Only what is Worthy of Description may be taxed. That means resources, never persons.**

```
X = max(0, W − Q)                         over-draw: abstraction above sustainable allocation
L = max(0, r(t)·(1 + βS)·X + d·D − O)     levy: scaled by basin stress, reduced by ledgered offsets
floor F_d exempt · unused offset → qualifies support, never a balance
ℛ → dividend 0.55 · tuning 0.20 · RTB reserve 0.10 · GAIA commons 0.10 · admin ≤ 0.05
```

Entry runs through WATER/AG: agriculture draws 71% of global freshwater (FAO AQUASTAT, 2022 data) and receives about US$540 bn/yr in producer support, 87% of it classed as harmful (FAO–UNDP–UNEP 2021). Φ0 Measure and Φ1 Repurpose raise **no new tax**, which mirrors FLIP's no-new-tax Earth Bond path on the capital side.

## Contents

| Path | Role |
|---|---|
| `ERES-GAIA-WAGTAX-2026-001_v0_1_WP.md` | **Master** white paper (ERES House Format v0.4) |
| `ERES-GAIA-WAGTAX-2026-001_v0_1_WP.pdf` | Human-read rendering with figures |
| `eres_gaia_wagtax_validation.py` | **TEST 1, instrument suite:** 35 pass / 0 fail / 4 load-bearing SKIP, exit 0 |
| `eres_house_format_conformance.py` | **TEST 2, House Format §15 kit:** 21/21 items, exit 0 (conformance ≠ verdict) |
| `RUN.txt` | Captured output of both kits |
| `data/…_METRICS.json` | 57 Future-Mapping metrics, 7 families, with formula, unit, direction, source, tag, scale and layer |
| `data/…_ANCHORS.json` | Deficit anchors D1–D10 with source and tag; **no revenue magnitude** |
| `data/…_PREREGISTRATION.json` | SHA-256 of the §10 prediction table (P1–P7), fixed 2026-10-04 |
| `data/…_REGISTRAR.json` | House Format §3.1 REGISTRAR entry; `invariantsTouched: []` |
| `figures/…_FIG1_ARCHITECTURE.svg` | WoD gate → levy → recycling → GAIA / FLIP |
| `figures/…_FIG2_PHASE-IN.svg` | Coverage R(t) across Φ0–Φ5, gated by condition |
| `make_figures.py` | Regenerates both SVGs |
| `ERES-GAIA-WAGTAX-2026-001_v0_1_META.txt` | Copy-paste deposit metadata and NOTICE text |
| `ERES-GAIA-WAGTAX-2026-001_v0_1_SEO.md` | Titles, meta description, abstracts and keywords by channel |
| `metadata.json` | Machine-readable metadata (Zenodo-shaped block included) |
| `CITATION.cff` · `LICENSE.txt` | Citation, licence |
| `MANIFEST.json` · `MANIFEST.txt` | SHA-256 per file |

## Reproduce

```bash
python3 eres_gaia_wagtax_validation.py     # VERDICT: PASS (35 pass / 0 fail / 4 skip), exit 0
python3 eres_house_format_conformance.py   # CONFORMANCE: CONFORMS (21/21), exit 0
python3 make_figures.py
sha256sum -c <(grep -v '^#' MANIFEST.txt)
```

Requires Python ≥ 3.9 and the standard library only. Seed 20261004. The **4 SKIPs are load-bearing**: they are the §0.0 author-reserved readings (GAIA operative role, Worthy of Description, fair-and-equitable, WATER/AG entry). Set the matching `AUTHOR_RULINGS` entry to `True` after an author ruling.

## Claim → test traceability

| Claim (WP §) | Test |
|---|---|
| Over-draw base (5.1) | T1 |
| Scarcity multiplier (5.3) | T2 |
| Levy non-negative; offsets; non-accrual (5.4, Prop. 5, E7) | T3–T6 |
| Floor exemption (Prop. 1, E3) | T7 |
| Horizontal equity, role-invariance (E1, E5) | T8, T9 |
| Progressivity (Prop. 2, E2) | T10, T11 |
| Recycling vector; allocation review (5.6, I1) | T12, T13 |
| Net progressivity after dividend (Prop. 3, E4) | T14–T16 |
| Φ1 revenue neutrality; ledger closure (Prop. 4, 6) | T17, T18 |
| Ratchet; RTB; tax-shift (6.3–6.5) | T19–T21 |
| Federation; EDA leakage (E6, Prop. 7) | T22, T23 |
| Food-floor guard (5.5) | T24 |
| WoD gate (§3) | T25 |
| S5 OPEN (§6.1) | T26 |
| Metric registry (§9) | T27–T29 |
| Pre-registration integrity (§10) | T30 |
| Anchors (§2) | T31 |
| Vocabulary firewall (§2.2) | T32 |
| FLIP coupling (§6.7) | T33 |
| Layer Doctrine (§3.3) | T34 |
| Condition-gated phases (§6.1) | T35 |
| House Format v0.4 §15 checklist | C01–C20 |

## For MIEVM nodes

Return a composite rating out of 10, deductions keyed to §-numbers and Open Items O-1 to O-16, tag recalibrations, and your exit codes and SKIP counts for both kits. Answer the Reviewer Brief (WP §0.2, Q-R1 to Q-R7), **including the Q5 bias-check**. Do not simulate other nodes. Do not assert revenue or offset magnitudes.

## Prohibited inferences

- No revenue, dividend or fiscal-effect claim. All rates are ASSERTED.
- No adoption or endorsement by any government, the OECD, the UN or any other body.
- No trade-law claim for the Embedded-Draw Adjustment.
- No person-layer instrument: nothing taxes, tracks, scores or ranks a person.
- No world government. GAIA is an actuary and registrar. S5 is OPEN.
- Conformance to House Format is not a 10-10 verdict.

## Credits · References · License

These are in the WP (§19). The work was drafted under Sentience, with Claude (Anthropic) providing draft assistance; this is not co-authorship. Data stewards: FAO, UNDP, UNEP, OECD, UN DESA and OHCHR. Licensed **CCAL v2.1 / CC BY 4.0**.
