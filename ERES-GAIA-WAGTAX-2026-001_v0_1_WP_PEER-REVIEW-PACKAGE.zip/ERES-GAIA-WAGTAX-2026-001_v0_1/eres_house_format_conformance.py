#!/usr/bin/env python3
"""
eres_house_format_conformance.py: mechanised ERES House Format v0.4 §15 checklist
Target: ERES-GAIA-WAGTAX-2026-001 v0.1 (any HOUSE instrument via --wp/--registrar)

Author:  Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
         ORCID 0000-0001-9946-3221
Drafted: under Sentience (Claude draft assistance)
License: CCAL v2.1 / CC BY 4.0

Standard library only. Exit 0 = CONFORMS, 1 = DOES NOT CONFORM.
Conformance is a checklist verdict about STRUCTURE PRESENT. It is never a 10-10 verdict
about claims (House §11). A conforming instrument can still be wrong.
"""
import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ID = "ERES-GAIA-WAGTAX-2026-001_v0_1"
TAGS = ("EXACT", "STRUCTURAL", "CANDIDATE", "ANALOGICAL", "OPEN", "REFUTED")
REG_FIELDS = ("instrumentId", "version", "status", "epistemicTag", "gateStanding", "licenseTier",
              "checksum", "supersedes", "supersededBy", "invariantsTouched", "p3Boundary",
              "resourceImpact", "gaiaAnchorHash", "operatorInstructions")
FILENAME_RE = re.compile(r"^ERES-[A-Z0-9-]+-\d{4}-\d{3}_v\d+_\d+(_\d+)?_[A-Z0-9-]+\.[a-z]+$")

OUT = []


def c(code, label, ok, detail=""):
    OUT.append(ok)
    print(f"  [{'OK  ' if ok else 'MISS'}] {code} {label}" + (f" | {detail}" if detail else ""))


def has(text, *needles):
    return all(n in text for n in needles)


def section(text, start, end=None):
    i = text.find(start)
    if i < 0:
        return ""
    j = text.find(end, i + len(start)) if end else -1
    return text[i: j if j > 0 else None]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wp", default=os.path.join(HERE, f"{ID}_WP.md"))
    ap.add_argument("--registrar", default=os.path.join(HERE, "data", f"{ID}_REGISTRAR.json"))
    a = ap.parse_args()
    wp = open(a.wp, encoding="utf-8").read()
    reg = json.load(open(a.registrar, encoding="utf-8"))
    print(f"HOUSE Format v0.4 §15 conformance | {os.path.basename(a.wp)}")
    print("-" * 72)

    head = wp[: wp.find("## Abstract")]
    c("C01", "Masthead: ID, Version, Status+gate, Role, For/From/Date, Provenance, Changelog",
      has(head, "**Instrument ID**", "**Version**", "**Status**", "**Gate standing**", "**Role**",
          "**For**", "**From**", "**Date**", "ORCID", "**Provenance**", "**Changelog**"))
    c("C01b", "Filename follows ERES-<SLUG>-<YEAR>-<NNN>_vX_Y_<ROLE>.<ext>",
      bool(FILENAME_RE.match(os.path.basename(a.wp))), os.path.basename(a.wp))
    ab = section(wp, "## Abstract", "## §0 ")
    c("C02", "Abstract states register and gate status", has(ab, "Register", "GOOD") and "9.0" in ab)
    s0 = section(wp, "## §0 Scope", "### §0.0")
    c("C03", "§0 Scope / what-this-is-not with load-bearing-layer note",
      has(s0, "This is not", "Load-bearing layer"))
    s01 = section(wp, "### §0.1 Scoring Contract", "### §0.2")
    comp = re.search(r"\*\*Composite[^|]*\|\s*\*\*(\d+(?:\.\d+)?)\*\*", s01)
    cval = float(comp.group(1)) if comp else 99
    c("C04", "§0.1 Scoring Contract: subscores, composite single-node capped < 9.0, dual-axis, gate standing",
      comp is not None and cval < 9.0 and has(s01, "Single-node cap", "Dual-axis vector", "Gate standing"),
      f"composite={cval}")
    c("C05", "§0.2 Reviewer Brief", "### §0.2 Reviewer Brief" in wp)
    nl = section(wp, "## §7 Notation Lock", "## §8 ")
    c("C06", "Notation Lock with single-valued symbols, non-binding glosses, person rule, φ firewall",
      has(nl, "single-valued", "non-binding", "never used to gate, price, permit or rank a **person**", "φ"))
    reg8 = section(wp, "### §8.1", "## §9 ")
    rows = [r for r in reg8.splitlines() if re.match(r"^\| X\d+ \|", r)]
    tagged = all(any(t in r for t in TAGS) for r in rows)
    promo = "Promotion criterion" in reg8 and "Demotion criterion" in reg8
    c("C07", "Cross-instrument claims carry one §6 tag with promotion AND demotion criteria",
      len(rows) >= 5 and tagged and promo, f"{len(rows)} claims")
    ld = section(wp, "### §3.3 Layer Doctrine", "## §4 ")
    c("C08", "Layer separation L1-L4 with read-only one-directional interface",
      has(ld, "L1", "L2", "L3", "L4", "read-only", "May not write"))
    c("C09", "Foundational Attribution near top; Credit Protocol; AI drafting disclosed",
      "**Foundational Attribution.**" in head and has(wp, "Credit Protocol", "Claude (Anthropic)"))
    c("C10", "Pre-registered falsifier fixed before confirming data",
      has(wp, "## §10 Falsification and pre-registration", "Reject if", "Fixed before any confirming data"))
    c("C11", "§10 Reproducibility: env, seeds, testkit, RUN record, checksum, traceability",
      has(wp, "### §12.3 Reproducibility", "standard library", "Seeds", "RUN.txt", "SHA-256", "traceability"))
    ri = section(wp, "## §16 Record Integrity", "## §17")
    c("C12", "Record Integrity (H2C2H) block with external anchor (interim substrate)",
      has(ri, "H2C2H", "External anchor", "Interim substrate"))
    c("C13", "Explicit non-claims and 'what is deferred' section",
      has(wp, "## §13 Explicit non-claims", "## §14 What is deferred"))
    cr = section(wp, "## §19 Credits, References, License", "## §20")
    c("C14", "Credits / References / License (CCAL) preserving Attribution + Layer Doctrine",
      has(cr, "### Credits", "### References", "### License", "CCAL v2.1", "Foundational Attribution", "Layer Doctrine"))
    c("C15", "Version History & Amendment Log", "## §20 Version history and amendment log" in wp)
    c("C16", "IP-Isolation intact: invariantsTouched empty",
      reg.get("invariantsTouched") == [] and "`invariantsTouched = []`" in wp)
    c("C17", "P³ boundary declaration (resource-allocation instrument)",
      has(section(wp, "## §15 P³", "## §16"), "**Personal**", "**Public**", "**Private**"))
    c("C18", "Resource/Energy impact stated or deferred to GERP/SECUIR",
      "GERP/SECUIR" in str(reg.get("resourceImpact", "")))
    c("C19", "REGISTRAR entry with all §3.1 fields and ≥ 10 operator instructions",
      all(k in reg for k in REG_FIELDS) and len(reg.get("operatorInstructions", [])) >= 10)
    c("C20", "Conforms-vs-passes stated correctly (conformance not claimed as verdict)",
      has(wp, "**Conforms vs passes (House §11).**", "has **not** passed a 10-10 verdict"))

    print("-" * 72)
    ok = all(OUT)
    print(f"CONFORMANCE: {'CONFORMS' if ok else 'DOES NOT CONFORM'} "
          f"({sum(OUT)}/{len(OUT)} items) | NOTE: conformance is not a 10-10 verdict (House §11)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
