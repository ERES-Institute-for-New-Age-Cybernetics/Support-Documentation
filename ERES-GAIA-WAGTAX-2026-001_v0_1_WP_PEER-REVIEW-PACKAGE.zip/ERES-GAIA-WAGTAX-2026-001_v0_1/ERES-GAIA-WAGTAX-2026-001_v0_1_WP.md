---
instrumentId: ERES-GAIA-WAGTAX-2026-001
version: v0.1
status: DRAFT (PROPOSED; pre-MIEVM)
gateStanding: "8.5 Emanuel: not yet tested by ensemble · 9.0 Stergios: not met"
role: WP (White Paper, peer-review package)
format: ERES House Format (ERES-HOUSE-FORMAT-2026-001 v0.4)
author: Joseph Allen Sprute (ERES Maestro)
orcid: 0000-0001-9946-3221
institution: ERES Institute for New Age Cybernetics, Bella Vista, Arkansas (est. 4 Feb 2012)
date: 2026-10-04
license: CCAL v2.1 / CC BY 4.0 (licenseTier REL)
---

# Tax the Over-Draw, Not the Person
## The GAIA Water–Ag Levy: a fair and equitable global tax system phased in through WATER/AG, with the key metrics for Future Mapping

**Instrument ID** ERES-GAIA-WAGTAX-2026-001 · **Version** v0.1 · **Status** DRAFT / PROPOSED, pre-MIEVM · **Gate standing** 8.5 Emanuel: untested by ensemble; 9.0 Stergios: not met · **Role** White Paper (peer-review package)\
**For** peer reviewers, MIEVM nodes, tax and water-policy Communities of Interest · **From** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas · ORCID 0000-0001-9946-3221 · **Date** 4 October 2026\
**Provenance** Composed under ERES House Format v0.4 (author-supplied copy) with the HELP v0.1 deposit (ERES-HELP-2026-001) as structural and packaging exemplar. Corpus sources read in full for this draft: *ERES GAIA ECVS SOMT v2.0*; *ERES FLIP PREMISE LLM2* (FLIP Premise instrument v0.1–v0.2 and its MIEVM record); *ERES 1000-Year Plan DRAFT* (16 Feb 2025); *Bella Vista Declaration on GAIA GEAR v0.7*. Axioms are inherited from HELP §1, the POSTERITY Ledger, SROC, RROI and the CoG Economic-FOCUS ruling (24 Jul 2026). Drafted by Claude (Anthropic) under Sentience.\
**Changelog** v0.1 (2026-10-04): initial instrument. See §13.

**Foundational Attribution.** All ERES constructs used here (GAIA, SCALULAR, UBIMIA, SROC, KOL, PoR, RTB, Floor Supremacy, POSTERITY Ledger, Triune Math, 1000-Year Future Map) originate with Joseph Allen Sprute and the ERES corpus. External data are credited to their stewards (§12). No external party has reviewed or endorsed this instrument.

---

## Abstract

We specify a global tax system that can be entered through the one sector where the tax base is large, physically metered and hard to move: **water drawn for agriculture**, which accounts for 71% of global freshwater withdrawals (FAO AQUASTAT, 2022 data) and already receives about US$540 billion a year in public producer support, 87% of which a joint FAO–UNDP–UNEP report classes as price-distorting and environmentally or socially harmful. The design rests on one rule, derived from the ERES axiom that *resources are describable and persons are VEILED*: **only what is Worthy of Description may be taxed**, meaning a metered, attributable, resource-layer flow that bears on a shared deficit. People, their location and their survival draw are never in the base. The levy falls on **over-draw** (abstraction above a basin's sustainable allocation), is scaled by basin water stress, is reduced by ledgered restoration offsets, exempts a per-person floor, and is returned mostly as an equal per-capita dividend, so that anyone whose levy is below α_div (0.55) times the average levy receives more than they pay (Proposition 3, DERIVED). Whether that group includes the poor in practice is a pre-registered test (P2). Phase-in runs in six condition-gated phases (Φ0 Measure → Φ5 Generation): the first two raise no new tax, because they repurpose existing harmful support. GAIA (Global Actuary Investor Authority) acts as the **actuary and registrar** that certifies describability and mutual recognition between jurisdictions. It is not a taxing sovereign, and planetary (S5) closure stays OPEN. We couple the levy to the FLIP's Earth Bonds on the capital side, so that both enter with *no new tax* in their first phases. We set out 57 Future-Mapping metrics in seven families (Water, Agriculture, Tax, GAIA governance, Future-Map trajectory, Capital, Equity), each with formula, unit, source, direction and tag; seven pre-registered predictions with rejection rules; and a deterministic validation suite (35 tests plus 4 load-bearing author-reserved SKIPs) plus a mechanised House Format conformance kit. **Register:** GOOD (specified, suite PASS with load-bearing SKIPs), SOUND-candidate. Single-node self-rating 8.6, capped below 9.0. Rates and magnitudes are ASSERTED and stay open until pilot data exist.

**Keywords:** global tax, water pricing, agricultural subsidy reform, fee-and-dividend, resource taxation, Pillar Two, UN tax convention, ERES, GAIA, Future Mapping, pre-registration

---

## §0 Scope: what this is and what it is not

**This is** a specification for a resource-draw levy and its revenue recycling. It covers formulas, fairness properties proven inside the model, a gated phase-in, a metric registry for tracking progress along the 1000-Year Future Map, and test instruments any party can run.

**This is not**
- a claim that any government has adopted, or will adopt, the levy;
- a fiscal forecast. No revenue magnitude is claimed, and every rate is ASSERTED for testing only;
- a replacement for income, profit or consumption taxes at Φ0–Φ2. The instrument enters *beside* existing systems and widens only by gated tax-shift (Φ4);
- a world government. GAIA is specified as an actuary and registrar inside a federated system. Planetary cascade closure (S5) is inherited OPEN from the Bella Vista Declaration v0.7;
- a person-layer instrument. Nothing here tracks, prices, gates or ranks a person (A-Veil, Notation Lock §7.3).

**Load-bearing layer.** The standard terms (levy, over-draw, dividend, offset, basin stress, block tariff) are load-bearing. ERES vocabulary is the source register and is glossed on first use. A reviewer who never reads another ERES document can run or reject everything here.

### §0.0 Author-Definition Register (reserved readings)

Under the trifurcation rule, the author holds the canonical reading of four tokens. The readings below are what this instrument *uses*. They are flagged for author ruling, and suite tests S1–S4 SKIP until ruled.

| Token | Reading used here | Status |
|---|---|---|
| **GAIA** | **Global Actuary Investor Authority**: corpus-anchored in GAIA ECVS SOMT v2.0 §6.1 and House Format v0.4 §10. The *expansion* is settled. The *operative role* used here is reserved: GAIA is the actuary that prices scarcity (SAI, AFS), holds the return-to-base reserve and the GAIA Fund (FLIP Phase 1), and keeps the registry of describable draws. It is **not** a taxing sovereign | S1 · reserved (role) |
| **Worthy of Description (WoD)** | A four-part gate on what may enter a tax base (§3). Constructed from the A-Veil axiom ("resources describable, person location VEILED") and A0. The corpus's prior formal definition, *Proof-of-Work-Worthy-of-Description* (Sanctuary Floor article v0.3), was **not available** to this draft, so reconciliation is required | S2 · reserved |
| **Fair and equitable** | The seven criteria E1–E7 of §4, combining horizontal equity, vertical equity, benefit and ability-to-pay principles, A-KEY role-invariance, sovereignty and floor exemption | S3 · reserved |
| **Phased in through WATER/AG** | Entry by the CoG Economic-FOCUS ruling: AG is the economic centre of gravity, WATER bounds it as input and LAW bounds it as governance. Water-for-agriculture is therefore the first base and LAW is the federating layer (§6) | S4 · reserved |

### §0.1 Scoring Contract

| Subscore | Self-rating | Basis |
|---|---|---|
| Specification clarity | 8.8 | Every symbol is single-valued (§7). The levy, recycling and phase gates are executable |
| Internal consistency | 8.9 | Propositions 1–7 are machine-checked in the suite; the ledger identity closes |
| Groundedness in canonical corpus | 8.4 | Built on HELP, SROC, RROI, POSTERITY, Bella Vista v0.7, GAIA ECVS SOMT v2.0, FLIP Premise and the 1000-Year Plan DRAFT, all read. The Sanctuary Floor article was not supplied, so S2 stays reserved. Four corpus vocabulary conflicts are logged rather than resolved (§2.2) |
| Reproducibility of conformance test | 9.0 | Deterministic, standard-library-only kits with SHA-256 manifest |
| Honesty of register | 8.6 | Magnitudes ASSERTED; S5 OPEN; external analogies tagged ANALOGICAL |
| **Composite (single node, indicative)** | **8.6** | Single-node cap rule: no self-award of 9.0 |

**Dual-axis vector.** Epistemic axis: SPECIFIED-PROPOSED, with DERIVED propositions inside the model and every empirical effect CANDIDATE. Quality tier: **GOOD**, SOUND-candidate. SOUND requires MIEVM ≥ 4 independent nodes with mean ≥ 8.5, plus the Q5 bias-check.
**Gate standing.** 8.5 Emanuel: self-rating clears it, but ensemble confirmation is not run. 9.0 Stergios: not met. **Honest-register rule:** praise does not raise a subscore, added scope is not added strength, and a gate "not yet met" is an opportunity to test.

### §0.2 Reviewer Brief

Five things to check, in priority order:
1. **Is the base right?** Over-draw W − Q (§5.1) depends on a sustainable allocation Q. Is Q definable without politicising the base? (Q-R1)
2. **Is the fairness proof doing work?** Proposition 3 (net-progressive incidence) is the standard fee-and-dividend result. Does the floor exemption plus scarcity indexing keep it under realistic draw distributions? Run `T14–T17`. (Q-R2)
3. **Does the food floor survive?** A levy on ag water can raise staple prices. §5.5 says the dividend dominates that pass-through. Is the inequality (5.5) correct? (Q-R3)
4. **Is leakage closed?** The Embedded-Draw Adjustment (§6, Φ3) is tagged ANALOGICAL to the EU CBAM and Pillar Two top-up logic. Is that analogy load-bearing anywhere it shouldn't be? (Q-R4)
5. **Vocabulary firewall (§2.2).** Four corpus conflicts (BERA, UBIMIA, GCF, ERI polarity) are logged with the canonical choice this instrument uses. Is any choice wrong? (Q-R5)
6. **Q5 bias-check:** name any OPEN item you were tempted to close without data, and why you refrained. (Q-R6)

Then reproduce both kits on your own hardware and report exit codes and SKIP counts (Q-R7).

---

## §1 Axioms in force

| ID | Axiom (inherited) | Effect in this instrument |
|---|---|---|
| A-Floor | Floor Supremacy and Floor Invariance: the floor is additive, survives institutional collapse and, once granted, is never withdrawn | Floor draw is never taxed. Dividend coverage ratchets (§6.3) |
| A0 | No Unearned Resonance: measured value exists only as discharge against a shared deficit | The levy prices undischarged over-draw. Offsets reduce it; surplus never accrues to a holder |
| A-KOL | Kernel-of-Love: admission is non-refusable (Γ = 1) | Every person receives the dividend; none is excluded for non-payment |
| A-KEY | Whatever is suggested for another must be appropriate were the suggester the recipient | The floor and the rate schedule are role-invariant (E5, T9) |
| A-RTB | Mission critical = able to return to base | A phase advances only if the reserve covers h periods of floor obligations (§6.4) |
| A-DVC | Doctrine of Verifiable Claims: falsifiability, re-derivability, provenance, standing contestability, institutional competence | Tags, predictions, suites |
| A-Ensemble | No single node certifies. SOUND needs ≥ 4 independent nodes, mean ≥ 8.5 | §13 |
| A-Veil | POSTERITY Ledger I4/I6: resources describable, person location VEILED, no surveillance | Defines the WoD gate (§3) |
| I1 | POSTERITY Ledger: the water commons is un-enclosable | No levy confers ownership of water. Paying does not buy a right to over-draw (§5.6) |

---

## §2 The problem as deficit

Each anchor below is EMPIRICAL and cited to its steward. Nothing in this section is projected by ERES.

| # | Deficit anchor | Value | Tag | Source |
|---|---|---|---|---|
| D1 | Agriculture's share of global freshwater withdrawals | 71% (2022) | EMPIRICAL | FAO AQUASTAT 2025 release |
| D2 | Global water stress, SDG 6.4.2 | 18% (2022) | EMPIRICAL | FAO AQUASTAT 2025 |
| D3 | Water-use efficiency, SDG 6.4.1 | US$21.50/m³ (2022), up from 17.47 (2015) | EMPIRICAL | FAO AQUASTAT 2025 |
| D4 | Renewable freshwater per person | 5,326 m³, down 7% since 2015 | EMPIRICAL | FAO AQUASTAT 2025 |
| D5 | Cultivated land equipped for irrigation | 23% (2022), up from 21.5% (2015) | EMPIRICAL | FAO AQUASTAT 2025 |
| D6 | Global agricultural producer support | ≈ US$540 bn/yr (2013–2018 avg) | EMPIRICAL | FAO–UNDP–UNEP (2021) |
| D7 | Share of D6 that is price-distorting and harmful | 87% (≈ US$470 bn) | EMPIRICAL | FAO–UNDP–UNEP (2021) |
| D8 | Projected producer support by 2030, business as usual | ≈ US$1.759 tn | EMPIRICAL (steward projection) | FAO–UNDP–UNEP (2021) |
| D9 | Global minimum corporate tax (Pillar Two) | 15% on MNEs with revenue ≥ €750 m. In effect in 50+ jurisdictions (early 2025). Side-by-side package for US-parented groups released 5 Jan 2026 | EMPIRICAL | OECD / KPMG summary |
| D10 | UN Framework Convention on International Tax Cooperation | Negotiating since Feb 2025. Text plus two early protocols due to the UN General Assembly by autumn 2027. The United States has withdrawn | EMPIRICAL | UN FfD Office; Tax Notes (25 Sep 2026) |

**Reading.** D1, D6 and D7 together locate the entry point. The largest single block of freshwater use is already flowing through a public-money channel that its own stewards call mostly harmful. D9 and D10 show that the global tax architecture is being rebuilt *now*, around mobile corporate profit, and that consensus on it is fragile. A resource-draw base complements that work rather than competing with it. Water drawn from a basin cannot be booked in a low-tax jurisdiction (§4, E6). (Tag on that last sentence: STRUCTURAL. Physical immobility is established; whether it blocks avoidance in practice is CANDIDATE, see P6.)

### §2.1 Corpus inputs: what each source contributes

| Source (read) | What this instrument takes | What it leaves | Tag |
|---|---|---|---|
| **GAIA ECVS SOMT v2.0** | GAIA = Global Actuary Investor Authority, "Civilizational Actuarial Authority". Its actuarial outputs: **SAI** (Strategic Alignment Index) and **AFS** (Actuarial Foresight Score), computed over the 1000-year trajectory in five phases (Start-Up, Inception, Secure, Continuum, Resonant Harmony). **GERP** (Global Earth Resource Planner) as the planner that ingests NBERS data. The master formula NBERS Global Optimization = UBIMIA × GCF + (ARI / ERI / RHC / RCI) | BERA biometric enrolment, FAVORS, ARI (aura) and ECVS vote weighting. These are person-layer and fail WoD-V, so they never enter a tax base or a gate here | STRUCTURAL (actuarial role); ANALOGICAL (SAI/AFS as metrics, operational definitions OPEN) |
| **FLIP Premise (v0.1–v0.2)** | FLIP = Financial Leverage Inversion Protocol: sovereign debt converted voluntarily into **Earth Bonds**, whose yield is conditioned on measured ecological and social performance. Three phases with **no new taxes**: (1) legal foundation and **GAIA Fund**; (2) voluntary bondholder swap; (3) UBIMIA dividend launch. Falsifiers F1 (conversion < 15% at fair-certified pricing) and F2 (divergence < +8%). Its own example is a bond "whose yield depends on a water table *not* failing" | FLIP's national-scale macro claims, which the corpus files as "architecturally deduced, awaiting independent corroboration" | CANDIDATE |
| **1000-Year Plan DRAFT (16 Feb 2025)** | Three governance "securities": **BERC** (Bio-Ecological Ratings Codex), **FWV** (Functional Weighted Viability: real-time viability forecasting and adaptive recalibration) and **GRS** (Graphene-Rooted Sociocracy). Its scale ladder: Self → Family → Community → Nation → Planet → Universe | **All person-layer and reproductive content** (fertility regulation, biometric reproductive oversight, physiological monitoring). It is excluded under A-Veil and A-KEY and has no role in this instrument. The 2025 draft's "New World Order" phrasing is not adopted | ANALOGICAL (BERC, FWV as metric families); OPEN (codex contents) |
| **Bella Vista Declaration v0.7** | Scale bands S1–S6; **Resiliency = 0.2·F / S**; S5 cascade closure OPEN with candidate paths (a) a distributable Steward network, (b) scoping the distributability rule below S5, (c) a federated decentralised network; Threat 7 (scale misrepresentation) and Threat 9 (closure claimed by naming) | Path selection for S5, which is a v0.8+ task of that Declaration | STRUCTURAL |
| **HELP v0.1** | USE Energy Law; Ramp-UP operator; floor ratchet; RTB gate; axioms; deposit layout | Pillar-specific content | STRUCTURAL |

**Consequence for design.** FLIP and this levy are two halves of one move. FLIP re-instruments **capital**: existing debt service is redirected and no tax is added. The levy re-instruments **fiscal flows**: existing harmful subsidy is redirected, and in Φ0–Φ1 no tax is added. Both route their dividend through UBIMIA, and both keep their reserve at the GAIA Fund. Their performance signal is the same: water-table and basin metrics (W5, W6; K2). See §6.7.

### §2.2 Vocabulary firewall: corpus conflicts logged, not resolved

| # | Token | Conflict found | Reading used here | Why |
|---|---|---|---|---|
| V1 | BERA | GAIA ECVS SOMT v2.0 expands it as *Bio-Energetic* Resonance Architecture | **Bio-Ecologic** Resonance Architecture | Canon ruling of 17 Jun 2026 supersedes Bio-Energetic |
| V2 | UBIMIA | GAIA ECVS SOMT v2.0: "Universal Basic Income via Meritocratic Input Authentication" | **Universal Basic Income Merit Incentives Accounts** | ENDHOME v2.0 author ruling. The two halves map to Survival (Income) / Merit (Incentives Accounts) separation, which this instrument needs: dividend = survival term |
| V3 | GCF | GAIA ECVS SOMT v2.0: *Global Coherence Factor* (GERP-I). FLIP: *Graceful Contribution Formula* | Both left unused in equations here | Same acronym, two meanings. Awaiting author ruling (O-14) |
| V4 | ERI polarity | ERI is a denominator in NBERS, but the text says "improving ecology increases the ratio", and elsewhere speaks of "rising ERI strain" | ERI read as a **strain** measure (higher = worse) wherever it is cited (F9) | The only reading consistent with the denominator position. Flagged for author ruling (O-13) |

---

## §3 Worthy of Description: the base rule

### §3.1 Definition

**Definition 3.1 (WoD gate).** A candidate base element *x* is **Worthy of Description**, written WoD(*x*) = 1, iff all four hold:

1. **Measurable (M):** *x* is a physical resource-layer quantity with a declared unit and a metering or estimation method of stated error.
2. **Attributable (A):** *x* is ledgered to a draw unit *i* (an abstraction point, parcel or facility), not to a person.
3. **Veil-safe (V):** describing *x* requires no person-layer data, meaning no identity, location of a person, or behaviour of a person beyond the draw unit's operator of record.
4. **Material (D):** *x* bears on a named shared deficit (§2), so pricing it is a discharge signal under A0 and not a revenue grab.

WoD(*x*) = M · A · V · D, a conjunctive gate where any zero blocks. Tag: CONSTRUCTED. Reading reserved (S2).

**Base Rule.** *A tax base may contain x only if WoD(x) = 1.* Corollaries:
- **C3.1** A person is never a base element, because V fails. Head taxes, poll taxes and person-scored levies are excluded by construction.
- **C3.2** Survival draw is excluded by A-Floor *before* WoD is evaluated (§5.2).
- **C3.3** The base can grow (Φ4) only by admitting new elements that pass WoD. Land rent, mineral extraction, emissions and spectrum are candidates. Labour income is not a resource-layer quantity, so the instrument never *adds* tax to it. It may only *shift* tax away from it (Φ4, tax-shift identity 6.5).

### §3.2 Why WATER/AG passes first

| Gate | Agricultural water draw | Tag |
|---|---|---|
| M | Volumetric abstraction is meterable. Where unmetered, remote-sensing evapotranspiration estimates exist with stated error | STRUCTURAL |
| A | Abstraction permits and parcels are already ledgered in most jurisdictions | STRUCTURAL |
| V | Draw is a property of the well or intake, not of a person | EXACT (by definition 3.1) |
| D | Over-draw drives D2 and D4 (stress, per-capita decline) | STRUCTURAL |

The CoG Economic-FOCUS ruling (corpus, 24 Jul 2026) puts the economic centre of gravity in AG, bounded by WATER (input) and LAW (governance). This instrument applies that ruling directly: **tax the input boundary (WATER), protect the centre (AG's food floor), and federate through the governance boundary (LAW).** Tag: STRUCTURAL within the corpus.

### §3.3 Layer Doctrine declaration

This instrument covers both measurement and governance, so it declares its layers (House §8):

| Layer | Content here | Interface |
|---|---|---|
| L1 Signal / Math foundation | Metering of W, Q, Y, D; SDG 6.4.1 / 6.4.2; offset verification | Feeds L2, read-only |
| L2 Minimal testable core | Equations 5.1–5.5, 6.2, 6.6 and Propositions 1–7 | Feeds L3, read-only |
| L3 Governance / cybernetic extension | Phase gates, RTB, ratchet, QDRL qualification, allocation review | **May not write L1 or L2.** A gate decision never alters a meter reading or a basin's measured stress (T34) |
| L4 Application architecture | GAIA registry, GAIA Fund, dividend rails, FLIP coupling | Consumes L3 decisions |

**Theory ≠ Implementation ≠ Application.** The propositions (L2) do not certify any implementation (L4).

---

## §4 Fair and equitable: the seven criteria

A design is *fair and equitable* here iff it satisfies E1–E7. Each criterion is mechanised in the suite.

| ID | Criterion | Formal statement | Test |
|---|---|---|---|
| E1 | Horizontal equity | Equal draws under equal conditions (W, Q, S, D, O) incur equal levy | T8 |
| E2 | Vertical equity (progressivity in draw) | Marginal levy is non-decreasing in over-draw, so average levy rate is non-decreasing | T10, T11 |
| E3 | Floor exemption | Any person's floor draw incurs zero levy | T7 |
| E4 | Net progressivity after recycling | With equal per-capita dividend, net incidence is negative for every resident whose levy share is below α_div × the mean levy share | T14–T16 |
| E5 | Role-invariance (A-KEY) | The schedule is identical for every operator class: smallholder, corporation, state utility | T9 |
| E6 | Sovereignty and federation | Each jurisdiction levies and keeps its own revenue, except a declared commons share α_g. No jurisdiction is compelled. Non-participation triggers only the border adjustment on *imports into* participants | T22, T23 |
| E7 | Benefit and restoration | Offsets that restore the commons reduce levy one-for-one up to the levy owed. Surplus restoration qualifies for capped support and is never a tradable credit | T5, T6 |

**Why not "ability-to-pay" on income?** Income is not WoD (V fails at the person layer). Ability-to-pay enters instead through **E4**: the dividend is equal per person and the levy rises with draw, so net burden tracks resource command, which correlates with wealth. That correlation is CANDIDATE and is tested by P2.

---

## §5 The levy

### §5.1 Over-draw

For draw unit *i* in basin *b* over period *t*:

  X_i = max(0, W_i − Q_i)            (5.1)

where W_i is metered withdrawal (m³) and Q_i is the unit's **sustainable allocation**, its declared share of the basin's sustainable yield Y_b, with Σ_i Q_i ≤ Y_b. Draw within allocation is **not taxed**. Tag: CONSTRUCTED. How Q is set is OPEN (O-2), and it is the instrument's main governance risk (Q-R1).

### §5.2 Floor

Domestic floor F_d (litres per person per day) is exempt at every metered domestic connection serving *n* persons:

  W_i^dom,taxable = max(0, W_i^dom − n · F_d · days)     (5.2)

F_d is ASSERTED at 50 L/person/day for testing. This sits at the lower bound of the 50–100 L range cited by the UN for the human right to water (UN GA Res. 64/292; OHCHR Fact Sheet 35). Calibration is O-3.

### §5.3 Scarcity multiplier

  ψ(S_b) = 1 + β · S_b,  S_b = min(1, SDG 6.4.2_b / 100)   (5.3)

β is ASSERTED at 3, so the rate quadruples between an unstressed basin and a fully stressed one. ψ is monotone and bounded on [1, 1 + β]. Tag: CONSTRUCTED.

### §5.4 The levy equation

  L_i = max(0, r(t) · ψ(S_b) · X_i + d · D_i − O_i)          (5.4)
  U_i = max(0, O_i − r(t) · ψ(S_b) · X_i − d · D_i)        (5.4a)

- r(t) is the base rate per m³ of over-draw, phased (§6.2).
- D_i is describable damage in declared units (for example, a nitrogen surplus in kg N, or groundwater head decline in m), priced at d. D_i must itself pass WoD.
- O_i is **ledgered offsets** valued at schedule: verified recharge, efficiency savings below Q, soil-carbon or riparian restoration (SROC ledger).
- U_i is **unused offset**. Under A0 and the non-accrual corollary, U_i is *never* paid out as a credit and never traded. It *qualifies* the unit for capped tuning support from the repurposing pool (§5.6). This is the VEILED-C rule: credits qualify issuance and are never converted to magnitude.

**Block form (E2).** For a stronger progressive schedule, r may be replaced by a tiered tariff on X_i with non-decreasing marginal rates r_1 ≤ r_2 ≤ … (T11). The linear form (5.4) is the minimal testable core.

### §5.5 Food-floor guard

Let p_food be the cost of a floor diet per person per period, and let λ be the share of the levy passed through to that cost. The guard requires:

  λ · (ΣL / N) · s_food ≤ div_per_capita = α_div · ΣL / N       (5.5)

which holds whenever λ · s_food ≤ α_div, where s_food is the share of levy-bearing output that enters floor diets. With α_div ≥ 0.5 (ASSERTED) and λ · s_food ≤ 1 by definition, the guard holds with margin whenever λ · s_food ≤ 0.5. **Tag:** DERIVED as an inequality. The empirical values of λ and s_food are OPEN (O-5), and P4 tests the outcome directly.

### §5.6 Revenue recycling

Total levy revenue in jurisdiction *j*: ℛ_j = Σ_{i∈j} L_i. It is allocated by the declared vector α:

| Share | Use | Asserted value | Rule |
|---|---|---|---|
| α_div | Equal per-capita **GAIA dividend** to every resident, unconditional (Γ = 1, UBIMIA survival term) | 0.55 | ≥ 0.5 (food-floor guard) |
| α_rep | **Tuning support:** capped payments to units with U_i > 0 or verified transition (the "reward tuners" step) | 0.20 | Cap per unit; pays only against ledgered restoration |
| α_res | **RTB reserve** (A-RTB) | 0.10 | Until reserve ≥ h periods of floor obligations |
| α_g | **GAIA commons pool**, paid out equal per capita across *all* participating jurisdictions | 0.10 | Declared; the only cross-border transfer |
| α_adm | Administration | 0.05 | Hard cap ≤ 0.05 |

Σα = 1 (T12). **Non-ownership (I1):** paying L_i does not buy a right to keep over-drawing. Sustained over-draw beyond a basin trigger (X_b / Y_b > θ_X, ASSERTED 0.10 for three consecutive periods) escalates to LAW-layer allocation review, not to a higher price only (T13).

---

## §6 Phase-in through WATER/AG

### §6.1 Phases, gated by condition, not date

| Phase | Scale | What happens | New tax? | Advance gate |
|---|---|---|---|---|
| **Φ0 Measure** | S1–S2 | Meter and ledger draw units; publish W, Q, S, D by basin; run levy in **shadow** (computed, not collected) | No | Metered share of ag draw ≥ θ_M (ASSERTED 0.8) in pilot basin; shadow ledger balances for 4 periods |
| **Φ1 Repurpose** | S2 | Convert harmful producer support H into offset-linked tuning support, revenue-neutral: ΔH = −ρ(t)·H, P_rep = +ρ(t)·H | No | ρ ≥ 0.25 with no fall in floor-food affordability (A5); farmer net income not below baseline band (A6) |
| **Φ2 Levy** | S2–S3 | Collect L_i at r(t) in pilot basins; pay dividend; fund reserve | Yes, on over-draw only | Books balance (τ_B); net incidence progressive (P2); RTB reserve met |
| **Φ3 Federate** | S3–S4 | Mutual recognition of a **Qualified Domestic Resource Levy (QDRL)**: a jurisdiction meeting the minimum schedule is "qualified". Imports from non-qualified sources face an **Embedded-Draw Adjustment (EDA)** on the over-draw content only; α_g pooled | Yes | ≥ 2 jurisdictions qualified; leakage ratio below θ_leak (P6); cohesion cross-verified, not self-attested |
| **Φ4 Extend and shift** | S4 | Admit further WoD-passing bases (land rent, extraction, emissions); lower taxes on labour by the same amount (tax-shift identity 6.5) | Shift, not add | Each new base passes WoD; shift identity holds |
| **Φ5 Generation** | S5–S6 | Planetary federation over the 1000-year horizon | — | **OPEN:** S5 cascade closure unresolved (Bella Vista v0.7). Closure by naming is rejected (T26) |

EDA is ANALOGICAL to the EU Carbon Border Adjustment Mechanism and to Pillar Two's qualified-domestic-top-up logic. The *form* is shared (border adjustment against a qualified domestic charge). Legality under trade law is not claimed (O-7).

### §6.2 Ramp

  R(t) = 1 / (1 + e^(−k(t − t₀))),  r(t) = r_max · R(t)      (6.2)

R(t) is the **coverage share**: the fraction of basin over-draw under a collecting levy. This is the same logistic Ramp-UP operator as HELP §8.1 (Economy(t) = GDP + R(t)·(NBERS − GDP)), read here as levy coverage. Tag: CONSTRUCTED. k and t₀ are fitted from phase-gate passage, not set by date.

### §6.3 Floor ratchet

Dividend coverage (the share of residents receiving it) is non-decreasing. A phase may stall but may not withdraw a dividend once granted. A shortfall triggers reserve draw and RHC remediation, never rationing of the floor (T19).

### §6.4 Return-to-base gate

Advance Φ_k → Φ_{k+1} only if Reserve ≥ h · (dividend obligation per period), with h ASSERTED at 12 periods (T20).

### §6.5 Tax-shift identity (Φ4)

  ΔT_labour + ΔT_WoD = 0  over each fiscal period at Φ4        (6.5)

New resource bases replace labour taxation one-for-one. They are not stacked on top of it (T21). Tag: CONSTRUCTED design rule.

### §6.6 Ledger identity (books balance)

  Σ L + ΔH_repurposed = Σ dividends + Σ tuning + ΔReserve + Σ commons + Σ admin      (6.6)

  |residual| ≤ τ_B · Σ L,  τ_B ASSERTED 0.01                       (6.6a)

### §6.7 FLIP coupling: capital and fiscal sides together

| | FLIP (capital side) | This levy (fiscal side) |
|---|---|---|
| What is redirected | Existing sovereign debt service | Existing harmful producer support (H) |
| New tax at entry | None (FLIP Phases 1–2) | None (Φ0–Φ1) |
| Performance signal | Earth Bond yield conditioned on measured ecological/social performance | Levy conditioned on measured over-draw, stress and offsets |
| Shared signal (proposed) | **Basin metrics W5 (over-draw ratio) and W6 (groundwater trend)** as Earth Bond reference indices | The same metrics drive ψ and the P5 test |
| Reserve | GAIA Fund (FLIP Phase 1) | RTB reserve α_res and commons pool α_g, held at the GAIA Fund |
| Dividend | UBIMIA dividend (FLIP Phase 3) | GAIA dividend α_div through UBIMIA survival term |
| Falsifiers | F1: conversion < 15%; F2: divergence < +8% | P1–P7 (§10) |

**Coupling rule.** An Earth Bond may reference only metrics that pass WoD (resource-layer or aggregate). It may never reference ARI or any person-layer index (T33). **Tag:** CANDIDATE. Whether a water-table-linked yield prices tail risk the way the FLIP pension-fund case predicts is FLIP's F1 test, not this instrument's.

### §6.8 Correspondence with GAIA's actuarial phases

GAIA ECVS SOMT v2.0 segments the 1000-year trajectory into Start-Up, Inception, Secure, Continuum and Resonant Harmony. A *proposed* correspondence: Φ0 ↔ Start-Up; Φ1–Φ2 ↔ Inception; Φ3 ↔ Secure; Φ4 ↔ Continuum; Φ5 ↔ Resonant Harmony. **Tag:** ANALOGICAL (shared ordering only). The two sequences are gated differently. This instrument's phases advance by condition (T35), and the source does not state its own advance criteria.

---

## §7 Notation Lock

### §7.1 Symbols (single-valued in this instrument)

| Symbol | Operational definition | Unit |
|---|---|---|
| i, b, j, t | Draw unit; basin; jurisdiction; period | index |
| W_i | Metered (or declared-error estimated) withdrawal | m³/period |
| Q_i | Sustainable allocation, Σ_i Q_i ≤ Y_b | m³/period |
| Y_b | Basin sustainable yield | m³/period |
| X_i | Over-draw, max(0, W_i − Q_i) | m³/period |
| S_b | Basin stress, min(1, SDG 6.4.2_b/100) | [0, 1] |
| ψ(S) | Scarcity multiplier 1 + βS | dimensionless |
| β | Scarcity slope | dimensionless |
| r(t), r_max | Base rate per m³ over-draw; ceiling | currency/m³ |
| D_i, d | Describable damage; its price | declared unit; currency/unit |
| O_i | Ledgered offsets valued at schedule | currency |
| L_i | Levy owed | currency |
| U_i | Unused offset (non-accruing) | currency |
| F_d | Domestic floor | L/person/day |
| N_j | Resident population | persons |
| α | Allocation vector (α_div, α_rep, α_res, α_g, α_adm) | shares |
| H_j, ρ(t) | Harmful producer support; repurposed share | currency; [0, 1] |
| R(t) | Coverage share (logistic) | [0, 1] |
| τ_B | Ledger tolerance | share |
| h | RTB reserve horizon | periods |
| Γ | Admission certainty (= 1) | {0, 1} |
| WoD(x) | M·A·V·D gate | {0, 1} |

### §7.2 Interpretive glosses (non-binding)

Readings such as "GAIA as the planet's own actuary" or "tax the over-draw = tune, don't mine" are interpretive. They do not enter any equation.

### §7.3 Hard rule

Symbols and glosses are never used to gate, price, permit or rank a **person**. A measured state is a *state*, never a *standing*. The φ confirmation-bias firewall applies: no golden-ratio or numerological constant appears in the minimal testable core. ψ is a linear scarcity multiplier and is unrelated to φ.

---

## §8 Fairness results (inside the model)

Each result is DERIVED from the definitions in §5–§6 and machine-checked. None is an empirical claim.

**Proposition 1 (Floor exemption).** If W_i^dom ≤ n·F_d·days, then L_i = 0. *Proof:* (5.2) gives zero taxable draw, and with D_i = 0 for domestic connections, (5.4) gives L_i = max(0, −O_i) = 0. ∎ (T7)

**Proposition 2 (Monotone progressivity).** For fixed S_b, D_i, O_i, L_i is non-decreasing in W_i. Under the block form with non-decreasing marginal rates, the average rate L_i / X_i is non-decreasing in X_i. *Proof:* a convex piecewise-linear function through the origin has non-decreasing slope from the origin. ∎ (T10, T11)

**Proposition 3 (Net progressivity after recycling).** Let each of N residents receive dividend δ = α_div·ℛ/N, and assign each unit's levy to its N_i beneficial residents. Then any resident whose levy share ℓ satisfies ℓ < α_div · ℛ/N is a net beneficiary. With α_div ≥ 0.5, every resident whose levy share is below half the mean is a net beneficiary, whatever the distribution. *Proof:* net = ℓ − δ < 0 iff ℓ < α_div·ℛ/N, and ℛ/N is the mean levy share. ∎ (T14–T16) *Tag:* DERIVED. *Empirical relevance:* whether low-income households have below-mean resource command is CANDIDATE (P2).

**Proposition 4 (Revenue neutrality of Φ1).** In Φ1, total public outlay on agriculture is unchanged: (H − ρH) + ρH = H. ∎ (T17)

**Proposition 5 (Non-accrual).** No unit receives a transferable balance from offsets: U_i enters only as a qualification flag for capped α_rep support. ∎ (T6)

**Proposition 6 (Ledger closure).** Under (5.6) with Σα = 1, identity (6.6) holds exactly, so any audited residual is measurement or fraud, never design. ∎ (T18)

**Proposition 7 (Leakage bound under EDA).** If EDA charges imports at the qualified minimum on their over-draw content, the gain from relocating production to a non-qualified jurisdiction is bounded by the measurement error on embedded over-draw. *Tag:* CANDIDATE. It holds in the model (T23), but the empirical error on embedded over-draw is OPEN (O-6).

### §8.1 Cross-domain and cross-instrument claim register

Each claim carries one §6 tag with its promotion and demotion criteria (House §6). Synthetic or self-referential results (including this suite) can neither promote nor refute.

| # | Claim | Tag | Promote to | Promotion criterion | Demote to | Demotion criterion |
|---|---|---|---|---|---|---|
| X1 | Ag water draw passes WoD (M, A, D) | STRUCTURAL | EXACT | Independent audit of a pilot basin: ≥ θ_M metered with stated error | CANDIDATE | Audit finds metering error > declared bound |
| X2 | Resource-draw base resists profit-shifting | STRUCTURAL / CANDIDATE (P6) | STRUCTURAL (empirical) | P6 passes in ≥ 2 jurisdictions | REFUTED | P6 rejects (leakage > θ_leak) |
| X3 | EDA ≈ CBAM / Pillar Two qualified-top-up logic | ANALOGICAL | STRUCTURAL | Qualified legal opinion that EDA uses the same legal mechanism (O-7) | OPEN | Opinion finds the mechanism inapplicable |
| X4 | Levy + dividend is net-progressive in practice | CANDIDATE (P2) | STRUCTURAL | P2 passes on pilot microdata | REFUTED | P2 rejects |
| X5 | FLIP Earth Bond ↔ levy share a performance signal | CANDIDATE | STRUCTURAL | K2 and P5 move together in ≥ 1 coupled pilot | ANALOGICAL | No co-movement over 3 periods |
| X6 | Φ-phases ↔ GAIA AFS phases | ANALOGICAL | STRUCTURAL | Author ruling plus AFS advance criteria published | OPEN | AFS criteria conflict with Φ gates |
| X7 | SAI / AFS usable as governance metrics G9 / G10 | ANALOGICAL | STRUCTURAL | Operational definitions published with resource-layer inputs only (O-15) | OPEN | Definitions require person-layer inputs |
| X8 | BERC / FWV usable as F10 / F11 | ANALOGICAL / CANDIDATE | STRUCTURAL | Codex published; FWV forecast skill > 0 out-of-sample | REFUTED (F10) | FWV skill ≤ 0 vs persistence |
| X9 | AG = economic centre of gravity, bounded by WATER and LAW | STRUCTURAL (corpus ruling) | EXACT | Author ruling S4 | OPEN | Ruling withdrawn |
| X10 | WoD ≡ *Proof-of-Work-Worthy-of-Description* (Sanctuary Floor) | OPEN | STRUCTURAL / EXACT | Source supplied and definitions reconciled (O-4) | REFUTED | Definitions incompatible; one superseded |

---

## §9 Future Mapping: the key metrics

### §9.1 What "Future Mapping" means here

The 1000-Year Future Map is read as a **state trajectory**. The present state vector **X**(t₀) is moved toward a target band by condition-gated phases. Each metric below is a coordinate of **X**. Each carries a direction (↑ better, ↓ better, or = must hold) and a band. Following the SOUND Standard, the **operating target is the band centre (SOUND), not the BEST asymptote.** Every metric is WoD-compliant: it is resource-layer or aggregate, never person-layer.

The machine-readable registry is `ERES-GAIA-WAGTAX-2026-001_v0_1_METRICS.json`. Suite T27–T29 validates its schema, its uniqueness (including a match between these tables and the JSON) and its Veil-safety.

### §9.2 Registry (57 metrics, seven families)

Families: **W** Water (9) · **A** Agriculture (7) · **TX** Tax and fiscal (12) · **G** GAIA governance (10) · **F** Future-Map trajectory (11) · **K** Capital, FLIP coupling (3) · **E** Equity checks (5). Directions: *up* / *down* = better; *hold* = invariant that must stay met. Every metric also declares its scale band (S1 Person · S2 Community · S3 Institution · S4 Domain · S5 Planet, OPEN · S6 Beyond, candidate).

**W: Water — the input boundary**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| W1 | Ag share of freshwater withdrawals | ag W / total W | % | down (via efficiency, never via food loss) | FAO AQUASTAT | EMPIRICAL | S4-S5 |
| W2 | Basin water stress | SDG 6.4.2 per basin | % | down | FAO AQUASTAT | EMPIRICAL | S3-S4 |
| W3 | Water-use efficiency | SDG 6.4.1 | USD/m3 | up | FAO AQUASTAT | EMPIRICAL | S4-S5 |
| W4 | Renewable freshwater per capita | TRWR / N | m3/person | hold (stabilise decline) | FAO AQUASTAT | EMPIRICAL | S4-S5 |
| W5 | Over-draw ratio | sum X_i / Y_b | share | down to < theta_X | This WP (5.1) | CONSTRUCTED | S3 |
| W6 | Groundwater storage trend | delta storage per year (gravimetric or well network) | km3/yr | up (>= 0) | GRACE-class data; baseline OPEN | EMPIRICAL source / OPEN baseline | S3-S4 |
| W7 | Metered share (describability coverage) | metered ag W / ag W | share | up to >= theta_M | This WP (Phi0 gate) | CONSTRUCTED | S2-S3 |
| W8 | Floor-water coverage | share of residents with >= F_d at point of use | share | hold = 1 (ratchet) | WHO/UNICEF JMP-class data | EMPIRICAL source | S2-S4 |
| W9 | Return-flow quality | share of return flows meeting ambient standard | share | up | National monitoring; OPEN | OPEN | S3 |

**A: Agriculture — the centre of gravity**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| A1 | Harmful-support share | harmful H / total producer support | share | down | FAO-UNDP-UNEP (2021) method | EMPIRICAL | S4 |
| A2 | Crop water productivity | yield / consumptive water | kg/m3 | up | FAO | EMPIRICAL | S2-S3 |
| A3 | Soil organic carbon trend | delta SOC | t C/ha/yr | up | National inventories; baseline OPEN | OPEN | S2-S3 |
| A4 | Nitrogen surplus | N inputs - N outputs | kg N/ha | down | OECD/FAO nutrient balance | EMPIRICAL | S2-S4 |
| A5 | Floor-food affordability | share of population able to afford a healthy diet | share | up; never down because of the levy | FAO SOFI method | EMPIRICAL | S3-S4 |
| A6 | Farmer net-income band | median farm net income / pre-Phi1 baseline | ratio | hold >= band floor | National statistics; OPEN | OPEN | S3 |
| A7 | Offset-ledger coverage | units with >= 1 verified offset / units | share | up | This WP (SROC ledger) | CONSTRUCTED | S2-S3 |

**TX: Tax and fiscal**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| TX1 | Levy revenue | R_j = sum L_i | currency | descriptive only (not a target) | Ledger | CONSTRUCTED | S3 |
| TX2 | Ledger residual | |residual| / sum L | share | hold <= tau_B | WP (6.6a) | DERIVED | S3 |
| TX3 | Suits index of levy | Suits (1977) over resource-command deciles | [-1,1] | up (> 0) | Microsimulation | CANDIDATE | S3 |
| TX4 | Floor-exemption integrity | levy charged on floor draw | currency | hold = 0 | WP Prop. 1 | DERIVED | S2 |
| TX5 | Recycling share | (dividend + tuning + commons) / R | share | hold >= 0.85 | WP (5.6) | CONSTRUCTED | S3 |
| TX6 | Leakage ratio | relocated over-draw / pre-levy over-draw | share | down (< theta_leak) | WP P6 | CANDIDATE | S4 |
| TX7 | Administrative cost ratio | admin / R | share | hold <= 0.05 | WP (5.6) | CONSTRUCTED | S3 |
| TX8 | Dividend per capita | alpha_div R / N | currency/person | descriptive only | Ledger | CONSTRUCTED | S3 |
| TX9 | Net incidence, bottom 50% | mean(levy share - dividend) over bottom half of resource command | currency/person | down (< 0) | WP P2 | CANDIDATE | S3 |
| TX10 | Cross-jurisdiction equity | Gini(net contributions) - Gini(over-draw shares) | delta Gini | hold <= 0 | WP E6 | CONSTRUCTED | S4 |
| TX11 | Tax-shift balance (Phi4) | delta T_labour + delta T_WoD | currency | hold = 0 | WP (6.5) | CONSTRUCTED | S3-S4 |
| TX12 | Repurposed share | rho(t) | share | up | WP Phi1 | CONSTRUCTED | S3-S4 |

**G: GAIA governance**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| G1 | Admission certainty | Gamma | {0,1} | hold = 1 | A-KOL | DERIVED | S1-S6 |
| G2 | RTB reserve ratio | Reserve / (h * dividend obligation) | ratio | hold >= 1 to advance | A-RTB | CONSTRUCTED | S3 |
| G3 | Floor-ratchet violations | count of withdrawn floors | count | hold = 0 | WP 6.3 | DERIVED | S2-S4 |
| G4 | Veil violations | person-layer queries executed | count | hold = 0 | A-Veil | DERIVED | S1-S6 |
| G5 | Contestability latency | median days from challenge to ruling | days | down | A-DVC | CONSTRUCTED | S3 |
| G6 | MIEVM standing | (nodes, mean, Q5 retained) | tuple | up to SOUND | A-Ensemble | CONSTRUCTED | n/a |
| G7 | Qualified jurisdictions | count QDRL-qualified | count | up | WP Phi3 | CONSTRUCTED | S4 |
| G8 | S5 closure status | OPEN / CLOSED-by-test | enum | OPEN until tested | Bella Vista v0.7 | OPEN | S5 |
| G9 | Strategic Alignment Index (SAI) | GAIA-I SAI, restricted to resource-layer inputs | index | up | GAIA ECVS SOMT v2.0 s6.1 | ANALOGICAL (operational definition OPEN) | S3-S5 |
| G10 | Actuarial Foresight Score (AFS) | GAIA-I AFS over the 1000-year HR trajectory (Start-Up, Inception, Secure, Continuum, Resonant Harmony) | index | up | GAIA ECVS SOMT v2.0 s6.1 | ANALOGICAL (operational definition OPEN) | S4-S6 |

**F: Future-Map trajectory**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| F1 | Coverage | R(t) | [0,1] | up (non-decreasing) | WP (6.2) / HELP s8.1 | CONSTRUCTED | S2-S5 |
| F2 | Ramp-UP economy | GDP + R(t)(NBERS - GDP) | currency | up | HELP s8.1 | CONSTRUCTED | S3-S5 |
| F3 | Resiliency | 0.2*F / S (Floor share of S-score) | share | up | Bella Vista v0.7 value 5 | CONSTRUCTED | S1-S5 |
| F4 | Friction-absorption ratio | friction absorbed / friction passed to human layer over a stress event | ratio | up (> 1) | FRAME principle | CANDIDATE | S2-S4 |
| F5 | Healthy-Happy-SAFE attestation rate | resource-layer attestations / expected | share | up | HELP s5.4 | CONSTRUCTED | S2-S3 |
| F6 | Hazard density | h_phi (<1 / =1 / >1) | ratio | down (< 1) | SOUND Standard | CONSTRUCTED | S2-S4 |
| F7 | Phase reached | Phi0..Phi5 | ordinal | up | WP s6.1 | CONSTRUCTED | S2-S6 |
| F8 | Intergenerational water continuity | 10-year slope of W4 | m3/person/yr | hold >= 0 | AQUASTAT-derived | EMPIRICAL source | S4-S6 |
| F9 | NBERS optimisation (ecological term only) | ERI-family resource-layer component of NBERS; person-layer ARI not read | index | up | GAIA ECVS SOMT v2.0 s7 | ANALOGICAL (ERI polarity OPEN) | S3-S5 |
| F10 | FWV forecast skill | out-of-sample skill of Functional Weighted Viability forecasts vs persistence baseline | skill score | up (> 0) | 1000-Year Plan DRAFT s IV.B | CANDIDATE | S3-S5 |
| F11 | BERC ecological rating | Bio-Ecological Ratings Codex, ecological-impact components only | rating | up | 1000-Year Plan DRAFT s IV.A | ANALOGICAL (codex OPEN) | S3-S5 |

**K: Capital — FLIP / Earth Bond coupling**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| K1 | Earth Bond conversion share | converted face value / offered face value at fair-certified pricing | share | up (falsifier: < 0.15) | FLIP Premise F1 | CANDIDATE | S4 |
| K2 | Measured-performance divergence | performance of Earth-Bond-linked basins vs comparator at period close | % | up (falsifier: < +8%) | FLIP Premise F2 | CANDIDATE | S3-S4 |
| K3 | GAIA Fund reserve adequacy | (RTB reserve + commons pool held) / h-period obligations | ratio | hold >= 1 | WP 5.6 + FLIP Phase 1 | CONSTRUCTED | S4 |

**E: Equity checks — E1..E7 mechanised**

| ID | Metric | Formula / definition | Unit | Direction | Source | Tag | Scale |
|---|---|---|---|---|---|---|---|
| E1m | Horizontal-equity breaches | equal-input pairs with unequal levy | count | hold = 0 | WP E1 | DERIVED | S2-S4 |
| E2m | Marginal-rate monotonicity | min delta marginal rate | currency/m3 | hold >= 0 | WP E2 | DERIVED | S2-S4 |
| E3m | Floor levy | levy on floor draw | currency | hold = 0 | WP E3 | DERIVED | S2 |
| E4m | Net-progressivity share | share of below-threshold units that are net beneficiaries | share | hold = 1 | WP E4 | DERIVED | S3 |
| E5m | Role-variance | max levy difference across operator classes for identical inputs | currency | hold = 0 | WP E5 | DERIVED | S2-S4 |

### §9.3 Metric discipline

1. **WoD-compliant:** no metric reads person-layer data (T29). Where a corpus index mixes layers (NBERS, BERC), only its resource-layer component is admitted (F9, F11).
2. **Single-valued:** one ID, one formula (T28).
3. **Not targets by themselves:** TX1 and TX8 are descriptive. Optimising revenue is not a goal of the instrument.
4. **Goodhart guard:** any metric that becomes a payment trigger (A7, W7) is paired with an independent audit metric (G5 contestability; external re-measurement).

---

## §10 Falsification and pre-registration

Fixed before any confirming data exist (DVC element 1). Thresholds are ASSERTED. The suite stores this table's SHA-256 so later edits are detectable (T30).

| ID | Prediction | Threshold | Reject if |
|---|---|---|---|
| P1 | Φ1 repurposing raises crop water productivity (A2) in pilot vs matched basin | +10% over 3 seasons | Difference < 10%, or CI includes 0 (bootstrap, 95%) |
| P2 | Φ2 levy + dividend is net-progressive: bottom-50% mean net incidence < 0 | Suits index (TX3) > 0 and TX9 < 0 | Either fails in pilot microdata |
| P3 | Books balance every audited period | τ_B = 1% | Any unreconciled breach > 1 period |
| P4 | Floor-food affordability (A5) does not fall because of the levy | Δ A5 ≥ −0.5 pts vs comparator | Significant fall attributable to levy (DiD, α = 0.05) |
| P5 | Over-draw ratio (W5) falls in levied basins | −20% within 5 periods | Reduction < 20% vs comparator |
| P6 | Leakage stays bounded under EDA | θ_leak = 0.10 | Relocated over-draw > 10% of pre-levy over-draw |
| P7 | Metered share reaches θ_M in Φ0 pilot within 8 periods | 0.8 | Not reached; describability gate fails |

**Estimation discipline.** Comparators are matched basins. Estimates use maximum-likelihood with bootstrap CIs and likelihood-ratio tests against named alternatives (no-effect; secular trend; rainfall-driven). There is no least-squares on log-log axes. **A favourable result is evidence about the mechanism in that pilot, not proof of scale-up.** No step advances on the author's judgement. The load-bearing external check is independent reproduction.

---

## §11 Sequence and gates

1. Author ruling on §0.0 → S1–S4 green.
2. MIEVM Round 1 (≥ 4 independent nodes, Q5 retained) → SOUND standing if mean ≥ 8.5.
3. Φ0 pilot site named *with consent* (O-8) → shadow ledger.
4. P7 met → Φ1. P1, P4, A6 met → Φ2. P2, P3, P5 met and RTB reserve met → Φ3.
5. Φ3 requires ≥ 2 consenting jurisdictions and a legal opinion on EDA (O-7).
6. S5 is never closed by naming. Closure requires a tested mechanism (T26).

---

## §12 Validation instruments (test kits)

### §12.1 `eres_gaia_wagtax_validation.py` (instrument suite)

Deterministic, standard library only, seed 20261004. Exit 0 = PASS, 1 = FAIL. SKIPs are reported and load-bearing. 35 tests + 4 SKIP.

| Test | Checks | Claim |
|---|---|---|
| T1 | X = max(0, W − Q) ≥ 0; zero within allocation | 5.1 |
| T2 | ψ monotone, bounded [1, 1+β] | 5.3 |
| T3 | L ≥ 0 always | 5.4 |
| T4 | L non-increasing in O | 5.4 |
| T5 | Offsets reduce levy one-for-one up to levy owed | E7 |
| T6 | U never paid as transferable balance (non-accrual) | Prop. 5 |
| T7 | Floor draw → zero levy | Prop. 1, E3 |
| T8 | Horizontal equity | E1 |
| T9 | Role-invariance across operator classes | E5, A-KEY |
| T10 | L non-decreasing in W | Prop. 2 |
| T11 | Block tariff: average rate non-decreasing | Prop. 2, E2 |
| T12 | Σα = 1, α_div ≥ 0.5, α_adm ≤ 0.05 | 5.6 |
| T13 | Sustained over-draw escalates to allocation review (I1) | 5.6 |
| T14 | Net incidence < 0 for all below α_div × mean | Prop. 3 |
| T15 | Synthetic lognormal population: bottom-50% net beneficiaries | Prop. 3, E4 |
| T16 | Suits index > 0 on synthetic population | T3 metric |
| T17 | Φ1 revenue neutrality | Prop. 4 |
| T18 | Ledger identity closes to machine precision | Prop. 6 |
| T19 | Floor ratchet: withdrawal rejected | §6.3 |
| T20 | RTB gate blocks under-reserved advance | §6.4 |
| T21 | Tax-shift identity enforced at Φ4 | 6.5 |
| T22 | Federation: non-participant not compelled; revenue retained except α_g | E6 |
| T23 | EDA bounds relocation gain (model) | Prop. 7 |
| T24 | Food-floor guard inequality (5.5) | 5.5 |
| T25 | WoD gate: person-layer element rejected; any zero blocks | §3 |
| T26 | S5 remains OPEN; closure by naming rejected | §6.1 |
| T27 | Metrics registry: 57 entries, 7 families, required fields | §9 |
| T28 | Metrics: unique IDs, single formula each; WP tables match JSON | §9.3 |
| T29 | Metrics: none reads person-layer data | §9.3 |
| T30 | Pre-registration table hash matches the stored hash | §10 |
| T31 | Anchors: every §2 value is sourced and tagged; no revenue magnitude asserted | §2, §13 |
| T32 | Vocabulary firewall: canonical BERA / UBIMIA / GAIA readings; GCF unused in equations | §2.2 |
| T33 | FLIP coupling: no new tax in Φ0–Φ1; Earth Bond references only WoD metrics | §6.7 |
| T34 | Layer Doctrine: an L3 gate cannot write L1/L2 measurement | §3.3 |
| T35 | Phases advance on conditions only; a date alone never advances a phase | §6.1 |
| S1–S4 | SKIP (load-bearing): §0.0 reserved readings await author ruling | §0.0 |

### §12.2 `eres_house_format_conformance.py` (House Format §15 kit)

This kit mechanises the House Format v0.4 §15 checklist against the WP markdown and the REGISTRAR entry. Checks include: masthead fields, canonical section presence, scoring contract with a single-node cap below 9.0, notation lock, tagged claims, falsifier, reproducibility block, H2C2H block, non-claims, deferred section, credits/references/license, version log, `invariantsTouched` empty, P³ declaration, resourceImpact, REGISTRAR fields and operator instructions, and the conforms-vs-passes statement. **Conformance is not a verdict (House §11).**

### §12.3 Reproducibility

Environment: Python ≥ 3.9, standard library only. Seeds are fixed. The `RUN.txt` captures both kits' output. `MANIFEST.json` holds a SHA-256 for every file. Conformant deposit check: fresh-extract → both kits exit 0 → checksums match. Claim→test traceability is in the README.

---

## §13 Explicit non-claims (prohibited inferences)

1. **No revenue claim.** No levy revenue, dividend size or fiscal effect is claimed. Every rate (r_max, β, d, α, F_d, θ) is ASSERTED for testing.
2. **No adoption claim.** No government, multilateral body or negotiating process has reviewed or endorsed this design. References to Pillar Two, CBAM and the UN tax convention are context and ANALOGY, not alignment.
3. **No legal claim.** EDA's compatibility with trade law is not asserted (O-7).
4. **No efficacy claim.** That pricing over-draw reduces it, or that repurposing improves productivity, is CANDIDATE (P1, P5).
5. **No person-layer instrument.** Nothing taxes, tracks, scores or ranks a person (A-Veil, C3.1).
6. **No world government.** GAIA is an actuary and registrar inside a federation. S5 stays OPEN.
7. **No water ownership.** Paying the levy confers no right to over-draw (I1).
8. **Conformance is not passage.** Meeting House Format is not a 10-10 verdict.
9. **No person-layer import.** The 1000-Year Plan DRAFT's reproductive, biometric and physiological-monitoring content, and GAIA ECVS SOMT's BERA/ARI person-layer indices, have no role here. They cannot enter a base, a gate or a metric.
10. **No FLIP macro claim.** FLIP's national-scale effects remain as the corpus files them: architecturally deduced, awaiting independent corroboration.
11. **The mathematics guarantees floor, band and balance inside the model. It does not guarantee the people or the politics.**

---

## §14 What is deferred (open items)

| ID | Item | Closes when |
|---|---|---|
| O-1 | §0.0 reserved readings (GAIA, WoD, fair-and-equitable, WATER/AG entry) | Author ruling; S1–S4 green |
| O-2 | Method for setting sustainable allocation Q_i | Basin-level allocation rule specified and contested in LAW layer |
| O-3 | Calibration of F_d, β, r_max, d, θ_X, θ_M, θ_leak, τ_B, h | CBGMODD ratification; currently ASSERTED |
| O-4 | Reconciliation of WoD with *Proof-of-Work-Worthy-of-Description* (Sanctuary Floor v0.3; not supplied) | Author supplies source; definitions aligned or one superseded (claim X10) |
| O-5 | Empirical pass-through λ and floor-diet share s_food | Measured in Φ1–Φ2 pilot |
| O-6 | Measurement error on embedded over-draw (EDA basis) | Method published with stated error |
| O-7 | Trade-law opinion on EDA | Qualified legal opinion obtained |
| O-8 | Pilot basin and operating CoE named | With consent of operators and residents |
| O-9 | S5 cascade closure | Inherited OPEN (Bella Vista v0.7) |
| O-10 | Reconciliation with the *ERES 1000-Year Future Map* PDF (distinct from the 1000-Year Plan DRAFT, which was read) | Author supplies or confirms |
| O-13 | ERI polarity (V4) | Author ruling |
| O-14 | GCF disambiguation: Global Coherence Factor vs Graceful Contribution Formula (V3) | Author ruling; one token re-labelled |
| O-15 | Operational definitions of SAI and AFS with resource-layer inputs only (G9, G10) | Published in a GAIA instrument |
| O-16 | BERC codex contents and FWV method (F10, F11) | Published with out-of-sample protocol |
| O-11 | P³ lexicon registration (House §2.3 flag) | Registered in TERMS |
| O-12 | MIEVM Round 1, ≥ 4 independent nodes, mean ≥ 8.5, Q5 retained | SOUND standing |

---

## §15 P³ boundary declaration and resource impact

This instrument governs **resource allocation**, so the P³ declaration is REQUIRED (House §2.3).

| Boundary | Reads | Writes | May act upon | Out of scope |
|---|---|---|---|---|
| **Personal** | Nothing person-identifying. The dividend is paid against residence registration held by the jurisdiction, not by GAIA | Nothing | Nothing | Identity, location, behaviour, income of any person |
| **Public** | Basin W, Q, Y, S, D aggregates; levy and ledger totals; metric registry | Published ledgers; metric values; phase status | Phase advance and stall; escalation to allocation review | Any non-WoD element |
| **Private** | Draw-unit meter readings and offset evidence (operator of record) | Levy assessments to the operator of record | Assessment; qualification for tuning support | Operator's other business data |

**resourceImpact.** The test kits are standard-library Python and run in seconds on commodity hardware. Operational compute and metering energy are deferred to GERP/SECUIR at Φ0 sizing.

---

## §16 Record Integrity (H2C2H)

| Field | Value |
|---|---|
| Human author review and sign-off | **PENDING:** J. A. Sprute to sign on acceptance |
| Machine stage | Claude (Anthropic) drafting, kits, figures, package assembly |
| Human return | **PENDING** |
| External anchor (high-assurance) | **DESIGN-STAGE / CANDIDATE.** Interim substrate: Zenodo/ResearchGate deposit timestamp plus the package SHA-256 in MANIFEST.json. GAIA ledger is not live |

---

## §17 REGISTRAR entry

```json
{
  "instrumentId": "ERES-GAIA-WAGTAX-2026-001",
  "version": "v0.1",
  "status": "DRAFT",
  "epistemicTag": ["CONSTRUCTED", "DERIVED (in-model)", "CANDIDATE (empirical)", "OPEN (S5)"],
  "gateStanding": {"emanuel_8_5": false, "stergios_9_0": false},
  "licenseTier": "REL",
  "checksum": "see MANIFEST.json (SHA-256 per file)",
  "supersedes": null,
  "supersededBy": null,
  "invariantsTouched": [],
  "p3Boundary": "§15",
  "resourceImpact": "kits: stdlib, seconds; operations deferred to GERP/SECUIR",
  "gaiaAnchorHash": null,
  "operatorInstructions": [
    "1 Read this REGISTRAR entry",
    "2 Draft new DETAIL in HOUSE Format; assign next version",
    "3 Run both kits; capture RUN.txt; confirm pre-registered pass conditions",
    "4 SHA-256 every file into MANIFEST.json",
    "5 H2C2H: human reviews and signs §16",
    "6 Isolation guard: confirm invariantsTouched is empty, else REJECT",
    "7 Validate p3Boundary and resourceImpact",
    "8 Anchor MANIFEST hash to an interim external record",
    "9 If superseding, set supersedes / supersededBy pointers",
    "10 Write the updated entry to the REGISTRAR"
  ]
}
```

**Isolation check.** This instrument adds DETAIL only (Stratum B) and one REGISTRAR entry (Stratum C). It alters no LOCKED term, no Triune equation (C = R×P/M; M×E + C = R; REAL = (E·M·R)/(T·S)), no Governing Principle and not the 1000-Year telos. `invariantsTouched = []`.

**Conforms vs passes (House §11).** This instrument is written to *conform* to House Format v0.4, which the conformance kit checks. It has **not** passed a 10-10 verdict, which requires independent multi-node convergence, a bias-orthogonal human hinge and a ledger write.

---

## §18 Self-ratification and review packet

| Node | Rating | Note |
|---|---|---|
| Claude (author-side) | 8.6 / 10 | Levy, recycling and gates are executable and fairness is proven in-model. Magnitudes are OPEN by design; four reserved readings pending; two source PDFs unread |
| Ensemble | n/a | Not run. Single-node simulation of an ensemble is prohibited |

**Grade:** GOOD (specified, suite PASS with load-bearing SKIPs). SOUND-candidate.

**Review questions** Q-R1 to Q-R6 are in §0.2. **Request format for nodes:** a composite rating; itemised deductions keyed to §-numbers; tag recalibrations; reproduction report (exit codes, SKIP count, platform); Q5 answer.

---

## §19 Credits, References, License

### Credits
- **Author:** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics. ORCID 0000-0001-9946-3221.
- **Authorship convention:** "We" = Sentience, the human–AI collaboration.
- **Draft assistance:** Claude (Anthropic), under Sentience, for drafting, data assembly, kits and figures. This is not co-authorship.
- **Data stewards (not endorsers):** FAO (AQUASTAT); FAO, UNDP and UNEP (agricultural support report); OECD (GloBE/Pillar Two); UN Department of Economic and Social Affairs, Financing for Sustainable Development Office (INC on tax cooperation); UN OHCHR.
- **Structural exemplar:** ERES-HELP-2026-001 v0.1.
- **Credit Protocol:** no external party has reviewed this instrument. Any later expert input will be credited as *technical review and domain-specific commentary: expert consultation within a collaborative research dialogue*, never as peer review or endorsement.

### References

*External (EMPIRICAL)*
1. FAO (2025). *AQUASTAT 2025 water data / Water Data Snapshot 2025.* Rome: FAO. Summary: UN-Water, "FAO: 2025 AQUASTAT Water Data"; Smart Water Magazine, "Global water under pressure: what AQUASTAT 2025 reveals about agriculture, efficiency and stress."
2. FAO, UNDP, UNEP (2021). *A Multi-Billion-Dollar Opportunity: Repurposing agricultural support to transform food systems.* Rome: FAO. (Launched 14 Sep 2021.)
3. OECD (2026). *The Global Minimum Tax Implementation Toolkit* (Forum on Tax Administration, Apr 2026); OECD side-by-side package (5 Jan 2026), as summarised by KPMG, *BEPS 2.0: Pillar One and Pillar Two*.
4. UN DESA FfD Office. *Intergovernmental Negotiating Committee on the UN Framework Convention on International Tax Cooperation* (financing.desa.un.org/unfcitc).
5. Tax Notes / Forbes (25 Sep 2026). "U.N. Tax Talks: Keep Or Change The Status Quo."
6. UN General Assembly Resolution 64/292 (2010), *The human right to water and sanitation*; OHCHR / UN-Habitat / WHO, *Fact Sheet No. 35: The Right to Water*.
7. Suits, D. B. (1977). "Measurement of Tax Progressivity." *American Economic Review* 67(4): 747–752.
8. European Union, Regulation (EU) 2023/956 establishing a Carbon Border Adjustment Mechanism (context for EDA analogy).

*ERES corpus*
9. ERES-HOUSE-FORMAT-2026-001 v0.4, *ERES HOUSE Format Specification*.
10. ERES-HELP-2026-001 v0.1, *HELP: How to Deliver Relatively Free Healthcare, Education, Law and Protection*.
11. Bella Vista Declaration on GAIA GEAR v0.7 (21 Jul 2026).
12. ERES-GAIA-GRID-2026-001 v0.4, *The GAIA Construct Grid*.
13. ERES-SROC-COI-001; ERES-SROC-SCALULAR-2026-001, *Smart-Resonant Offset Contract*.
14. ERES-RROI-2026-001, *Reasoned ROI* (Offset axiom A0).
15. Sprute, J. A. (2026). *The POSTERITY Ledger* (ERES-LLPM-2026-001 v0.1).
16. ERES-FLIP-2026-001, *The Economic FLIP*.
17. ERES-FOUNDATIONS-CODE-2026-001, *Foundations of Sustainable Prosperity*.
18. ERES-SOUND-STANDARD-2026-001, *The SOUND Standard*.
19. ERES-DVC-2026-001, *Doctrine of Verifiable Claims*.
20. ERES-CCAL v2.1, *CARE Commons Attribution License*.
21. ERES Corpus (Zenodo). https://doi.org/10.5281/zenodo.21209870
22. *ERES GAIA ECVS SOMT v2.0*: Global Actuary Investor Authority, Empirical Realtime Voting System, Sociocratic Overlay Metadata Tapestry (interplanetary specification).
23. ERES-FLIP-PREMISE-2026-001 v0.1 PROPOSED / v0.2 PROVISIONAL, *The FLIP Premise Instrument: a falsifiable statement of the Earth Bond mechanism*, with MIEVM record (ERES FLIP PREMISE LLM2).
24. Sprute, J. A. (2025). *ERES 1000-Year Plan DRAFT: 1000-Year Future Map as Securities* (16 Feb 2025).
25. ERES-TERMS-48, *The Talonic NAC Lexicon* v1.0 (14 Aug 2026).
26. ERES-ENDHOME-2026-001 v2.0 (UBIMIA expansion ruling).

### License
© 2026 Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed CCAL v2.1 / Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/. Reuse requires attribution, propagates the license, preserves Foundational Attribution and the Layer Doctrine, and may not alter any LOCKED term. Third-party data remain under their stewards' terms.

---

## §20 Version history and amendment log

| Version | Date | Change | Against |
|---|---|---|---|
| v0.1 | 2026-10-04 | Initial instrument: WoD base rule; seven fairness criteria; over-draw levy with scarcity index, floor, offsets and non-accrual; recycling vector; six-phase WATER/AG phase-in with RTB and ratchet; §2.1 corpus inputs (GAIA ECVS SOMT v2.0, FLIP Premise, 1000-Year Plan DRAFT, Bella Vista v0.7) and §2.2 vocabulary firewall; §3.3 Layer Doctrine; §6.7 FLIP coupling; §6.8 AFS correspondence; §8.1 claim register; 57-metric Future-Mapping registry; P1–P7; instrument suite (35 tests + 4 SKIP); House Format conformance kit; Figures 1–2 | Author brief, 4 Oct 2026 |

---

## Appendix A: Glossary

**A0** No Unearned Resonance · **CBGMODD** seven-seat council (Citizen, Business, Government, Media, Organisation, Dignitary, Diplomat) · **CoE** Center of Excellence · **EDA** Embedded-Draw Adjustment · **GAIA** Global Actuary Investor Authority (operative role reserved) · **AFS** Actuarial Foresight Score · **BERC** Bio-Ecological Ratings Codex · **Earth Bond** FLIP debt instrument with performance-conditioned yield · **FLIP** Financial Leverage Inversion Protocol · **FWV** Functional Weighted Viability · **GERP** Global Earth Resource Planner · **SAI** Strategic Alignment Index · **Γ** admission certainty · **H2C2H** Human-to-Computer-to-Human integrity gate · **KOL** Kernel-of-Love · **MIEVM** Multi-Instrument Ensemble Validation Method · **Over-draw** abstraction above sustainable allocation · **QDRL** Qualified Domestic Resource Levy · **RTB** return to base · **SCALULAR** four-pillar service engine · **SROC** Smart-Resonant Offset Contract · **UBIMIA** Universal Basic Income Merit Incentives Accounts · **WoD** Worthy of Description (reserved)

## Appendix B: Figures

![Figure 1. Architecture: the WoD gate admits resource-layer draws only; over-draw is levied, scaled by stress and reduced by offsets; revenue is recycled by the declared vector; FLIP Earth Bonds share the basin signal and the GAIA Fund.](figures/ERES-GAIA-WAGTAX-2026-001_v0_1_FIG1_ARCHITECTURE.svg)

![Figure 2. Phase-in trajectory: coverage R(t) across Φ0–Φ5. Φ0–Φ1 raise no new tax. Each phase advances on its gate, never on a date. S5 is OPEN.](figures/ERES-GAIA-WAGTAX-2026-001_v0_1_FIG2_PHASE-IN.svg)
