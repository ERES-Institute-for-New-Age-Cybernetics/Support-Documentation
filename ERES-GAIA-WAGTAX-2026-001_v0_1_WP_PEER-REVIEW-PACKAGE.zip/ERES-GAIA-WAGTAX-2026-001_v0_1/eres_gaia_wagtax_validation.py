#!/usr/bin/env python3
"""
eres_gaia_wagtax_validation.py: companion TEST suite to ERES-GAIA-WAGTAX-2026-001 v0.1
"Tax the Over-Draw, Not the Person: The GAIA Water-Ag Levy"

Author:  Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
         ORCID 0000-0001-9946-3221
Drafted: under Sentience (human-AI collaboration; Claude draft assistance)
License: CCAL v2.1 / CC BY 4.0

Standard library only. Deterministic (seed 20261004). Exit code = verdict (0 PASS, 1 FAIL).
SKIPs are LOAD-BEARING: they are the WP §0.0 author-reserved readings. They turn green
only on author ruling (set AUTHOR_RULINGS below) and never count as failures.

Numbers inside tests are ILLUSTRATIVE FIXTURES, not claims. The instrument asserts no
revenue, dividend or offset magnitude (see data/*_ANCHORS.json).
Run:  python3 eres_gaia_wagtax_validation.py
"""
import hashlib
import json
import math
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ID = "ERES-GAIA-WAGTAX-2026-001_v0_1"
WP = os.path.join(HERE, f"{ID}_WP.md")
METRICS = os.path.join(HERE, "data", f"{ID}_METRICS.json")
ANCHORS = os.path.join(HERE, "data", f"{ID}_ANCHORS.json")
PREREG = os.path.join(HERE, "data", f"{ID}_PREREGISTRATION.json")
SEED = 20261004

# §0.0 Author-Definition Register: flip to True only on JAS ruling.
AUTHOR_RULINGS = {
    "S1 GAIA operative role = actuary/registrar, not taxing sovereign": False,
    "S2 Worthy of Description = M·A·V·D gate": False,
    "S3 Fair and equitable = criteria E1-E7": False,
    "S4 Phased in through WATER/AG = CoG Economic-FOCUS entry": False,
}

# Declared policy parameters (ASSERTED; CBGMODD-amendable). Mirror WP §5-§6.
BETA = 3.0
F_D = 50.0               # L/person/day
ALPHA = {"div": 0.55, "rep": 0.20, "res": 0.10, "g": 0.10, "adm": 0.05}
THETA_X = 0.10
TAU_B = 0.01
H_RTB = 12
RHO_GATE = 0.25
OPERATOR_CLASSES = ("smallholder", "corporation", "state_utility", "cooperative")

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append(("PASS" if cond else "FAIL", name))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))


def skip(name, why):
    RESULTS.append(("SKIP", name))
    print(f"  [SKIP] {name} | {why}")


# --------------------------------------------------------------------------- #
# Model (mirrors WP §3, §5, §6)
# --------------------------------------------------------------------------- #
def overdraw(W, Q):
    """(5.1) X = max(0, W - Q)."""
    if W < 0 or Q < 0:
        raise ValueError("W, Q >= 0")
    return max(0.0, W - Q)


def psi(S, beta=BETA):
    """(5.3) scarcity multiplier, S clipped to [0, 1]."""
    S = min(1.0, max(0.0, S))
    return 1.0 + beta * S


def taxable_domestic(W_dom_L, n_persons, days):
    """(5.2) domestic draw above the per-person floor (litres)."""
    return max(0.0, W_dom_L - n_persons * F_D * days)


def gross_charge(r, S, X, d=0.0, D=0.0):
    return r * psi(S) * X + d * D


def levy(r, S, W, Q, d=0.0, D=0.0, O=0.0, operator_class=None):
    """(5.4) L = max(0, r·psi(S)·X + d·D - O). operator_class deliberately unused (A-KEY)."""
    if O < 0 or r < 0 or d < 0 or D < 0:
        raise ValueError("non-negative inputs")
    return max(0.0, gross_charge(r, S, overdraw(W, Q), d, D) - O)


def unused_offset(r, S, W, Q, d=0.0, D=0.0, O=0.0):
    """(5.4a) U = max(0, O - gross). Qualification flag only; never a balance."""
    return max(0.0, O - gross_charge(r, S, overdraw(W, Q), d, D))


def tuning_qualification(U):
    """Prop. 5 / VEILED-C: U qualifies support; it is never converted to a payable balance."""
    return {"qualifies": U > 0, "payable_balance": 0.0, "tradable": False}


def block_levy(X, tiers):
    """Block tariff. tiers = [(upper_bound, marginal_rate), ...], last bound = inf."""
    total, lower = 0.0, 0.0
    for upper, rate in tiers:
        if X <= lower:
            break
        total += rate * (min(X, upper) - lower)
        lower = upper
    return total


def allocate(R, alpha=ALPHA):
    return {k: R * v for k, v in alpha.items()}


def escalation(overdraw_ratio_series, theta=THETA_X, periods=3):
    """§5.6 / I1: sustained over-draw escalates to LAW-layer allocation review."""
    run = 0
    for x in overdraw_ratio_series:
        run = run + 1 if x > theta else 0
        if run >= periods:
            return "ALLOCATION_REVIEW"
    return "PRICE_ONLY"


def logistic(t, k=0.6, t0=10.0):
    return 1.0 / (1.0 + math.exp(-k * (t - t0)))


def suits_index(burden_by_unit, base_by_unit):
    """Suits (1977): 1 - L/K over units sorted by base (ascending). >0 progressive."""
    pairs = sorted(zip(base_by_unit, burden_by_unit))
    tb = sum(b for b, _ in pairs)
    tt = sum(t for _, t in pairs)
    if tb <= 0 or tt <= 0:
        return 0.0
    area, cb, ct = 0.0, 0.0, 0.0
    for b, t in pairs:
        nb, nt = cb + b / tb, ct + t / tt
        area += (nb - cb) * (ct + nt) / 2.0
        cb, ct = nb, nt
    return 1.0 - area / 0.5


class Phase:
    ORDER = ["PHI0", "PHI1", "PHI2", "PHI3", "PHI4", "PHI5"]

    def __init__(self):
        self.idx = 0
        self.floors_granted = 0
        self.dividend_coverage = 0.0

    def advance(self, gates, reserve, obligation, date_reached=False):
        """Condition-gated only. date_reached is ignored (T35). RTB gate (§6.4)."""
        if self.ORDER[self.idx + 1] == "PHI5":
            return False  # S5 OPEN: cannot be entered by gate-naming (T26)
        if not all(gates.values()):
            return False
        if reserve < H_RTB * obligation:
            return False
        self.idx += 1
        return True

    def set_coverage(self, c):
        """Floor ratchet (§6.3): coverage non-decreasing."""
        if c < self.dividend_coverage:
            raise PermissionError("floor withdrawal rejected (A-Floor ratchet)")
        self.dividend_coverage = c


def wod(element):
    """§3 WoD gate: conjunctive M·A·V·D."""
    keys = ("measurable", "attributable", "veil_safe", "material")
    return int(all(bool(element.get(k)) for k in keys))


class Ledger:
    """L1/L2 measurement store with a read-only view for L3 (Layer Doctrine, §3.3)."""

    def __init__(self, readings):
        self._readings = dict(readings)

    def view(self):
        return _ReadOnly(self._readings)


class _ReadOnly:
    def __init__(self, d):
        object.__setattr__(self, "_d", dict(d))

    def __getitem__(self, k):
        return self._d[k]

    def __setitem__(self, k, v):
        raise PermissionError("L3 may not write L1/L2 measurement")

    def __setattr__(self, k, v):
        raise PermissionError("read-only")


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def main():
    rng = random.Random(SEED)
    print(f"{ID} validation suite | seed {SEED}")
    print("-" * 72)

    # T1 over-draw
    ok = all(overdraw(w, q) >= 0 for w, q in [(0, 5), (5, 5), (3, 9), (12, 4)])
    ok &= overdraw(80, 100) == 0 and overdraw(130, 100) == 30
    check("T1 over-draw X = max(0, W-Q) >= 0; zero within allocation", ok)

    # T2 psi monotone, bounded
    grid = [i / 100 for i in range(101)]
    vals = [psi(s) for s in grid]
    ok = all(b >= a for a, b in zip(vals, vals[1:])) and min(vals) == 1.0 and max(vals) == 1 + BETA
    ok &= psi(-1) == 1.0 and psi(7) == 1 + BETA
    check("T2 psi(S) monotone, bounded on [1, 1+beta]", ok)

    # T3 L >= 0 always
    ok = True
    for _ in range(2000):
        L = levy(rng.uniform(0, 2), rng.random(), rng.uniform(0, 500), rng.uniform(0, 500),
                 rng.uniform(0, 1), rng.uniform(0, 50), rng.uniform(0, 2000))
        ok &= L >= 0
    check("T3 levy L >= 0 for 2000 random draws", ok)

    # T4 L non-increasing in O
    Ls = [levy(1.0, 0.5, 300, 100, 0.2, 10, o) for o in range(0, 800, 10)]
    check("T4 levy non-increasing in offsets O", all(b <= a for a, b in zip(Ls, Ls[1:])))

    # T5 offsets one-for-one up to levy owed
    g = gross_charge(1.0, 0.5, overdraw(300, 100), 0.2, 10)
    ok = abs(levy(1.0, 0.5, 300, 100, 0.2, 10, 50) - (g - 50)) < 1e-9
    ok &= levy(1.0, 0.5, 300, 100, 0.2, 10, g + 99) == 0.0
    check("T5 offsets reduce levy one-for-one, floored at zero", ok, f"gross={g:.1f}")

    # T6 non-accrual
    U = unused_offset(1.0, 0.5, 300, 100, 0.2, 10, g + 99)
    q = tuning_qualification(U)
    check("T6 unused offset qualifies support, never a payable/tradable balance",
          U > 0 and q["qualifies"] and q["payable_balance"] == 0.0 and not q["tradable"])

    # T7 floor
    days = 30
    for n in (1, 4, 9):
        W_floor = n * F_D * days
        if taxable_domestic(W_floor, n, days) != 0 or taxable_domestic(W_floor * 0.6, n, days) != 0:
            ok = False
            break
    else:
        ok = taxable_domestic(4 * F_D * days + 300, 4, days) == 300
    check("T7 floor draw (<= n·F_d·days) bears zero levy (Prop. 1, E3)", ok)

    # T8 horizontal equity
    args = (0.8, 0.4, 260, 120, 0.1, 5, 20)
    check("T8 equal inputs -> equal levy (E1)", levy(*args) == levy(*args))

    # T9 role invariance
    vals = {c: levy(0.8, 0.4, 260, 120, 0.1, 5, 20, operator_class=c) for c in OPERATOR_CLASSES}
    check("T9 identical levy across operator classes (E5, A-KEY)", len(set(vals.values())) == 1)

    # T10 L non-decreasing in W
    Ls = [levy(1.0, 0.3, w, 100, 0, 0, 25) for w in range(0, 1000, 7)]
    check("T10 levy non-decreasing in withdrawal W (Prop. 2)", all(b >= a for a, b in zip(Ls, Ls[1:])))

    # T11 block tariff average rate non-decreasing
    tiers = [(100, 0.5), (300, 1.0), (800, 2.0), (float("inf"), 4.0)]
    avg = [block_levy(x, tiers) / x for x in range(1, 2000, 3)]
    rates = [r for _, r in tiers]
    check("T11 block tariff: marginal and average rates non-decreasing (E2)",
          all(b >= a - 1e-12 for a, b in zip(avg, avg[1:])) and rates == sorted(rates))

    # T12 alpha constraints
    check("T12 sum(alpha)=1, alpha_div >= 0.5, alpha_adm <= 0.05",
          abs(sum(ALPHA.values()) - 1) < 1e-12 and ALPHA["div"] >= 0.5 and ALPHA["adm"] <= 0.05)

    # T13 escalation
    check("T13 sustained over-draw escalates to allocation review (I1)",
          escalation([0.12, 0.15, 0.11]) == "ALLOCATION_REVIEW"
          and escalation([0.12, 0.05, 0.11, 0.2]) == "PRICE_ONLY")

    # Synthetic population for T14-T16 (lognormal resource command)
    N = 5000
    command = [rng.lognormvariate(0.0, 1.0) for _ in range(N)]   # resource command per resident
    Q_pc = 1.0                                                      # per-capita sustainable share
    levies = [levy(1.0, 0.5, c, Q_pc) for c in command]
    R = sum(levies)
    div = ALPHA["div"] * R / N
    mean_l = R / N
    net = [l - div for l in levies]

    # T14 Prop. 3
    below = [n_ for l, n_ in zip(levies, net) if l < ALPHA["div"] * mean_l]
    check("T14 every resident with levy share < alpha_div·mean is a net beneficiary (Prop. 3)",
          len(below) > 0 and all(x < 0 for x in below), f"{len(below)} residents")

    # T15 bottom 50% by command are net beneficiaries on average
    order = sorted(range(N), key=lambda i: command[i])
    bottom = order[: N // 2]
    mean_net_bottom = sum(net[i] for i in bottom) / len(bottom)
    check("T15 synthetic population: bottom-50% mean net incidence < 0 (E4)",
          mean_net_bottom < 0, f"mean net = {mean_net_bottom:.4f}")

    # T16 Suits > 0
    si = suits_index(levies, command)
    check("T16 Suits index of levy over resource command > 0", si > 0, f"Suits = {si:.3f}")

    # T17 Phi1 revenue neutrality
    H = 470.0
    ok = all(abs((H - rho * H) + rho * H - H) < 1e-9 for rho in (0, 0.25, 0.5, 1.0))
    check("T17 Phi1 repurposing is revenue-neutral (Prop. 4)", ok)

    # T18 ledger identity
    alloc = allocate(R)
    dH = 37.5
    lhs = R + dH
    rhs = alloc["div"] + (alloc["rep"] + dH) + alloc["res"] + alloc["g"] + alloc["adm"]
    resid = abs(lhs - rhs) / R
    check("T18 ledger identity closes (Prop. 6, 6.6a)", resid <= 1e-12 <= TAU_B, f"residual={resid:.2e}")

    # T19 floor ratchet
    ph = Phase()
    ph.set_coverage(0.4)
    try:
        ph.set_coverage(0.3)
        ok = False
    except PermissionError:
        ok = True
    check("T19 floor ratchet: coverage withdrawal rejected", ok)

    # T20 RTB gate
    ph = Phase()
    blocked = not ph.advance({"g": True}, reserve=11 * 10, obligation=10)
    allowed = ph.advance({"g": True}, reserve=12 * 10, obligation=10)
    check("T20 RTB gate blocks under-reserved advance", blocked and allowed)

    # T21 tax shift identity
    def phi4_ok(dT_labour, dT_wod):
        return abs(dT_labour + dT_wod) < 1e-9
    check("T21 Phi4 tax-shift identity: add rejected, shift accepted",
          phi4_ok(-50, 50) and not phi4_ok(0, 50))

    # T22 federation
    juris = {"A": {"participates": True, "R": 100.0}, "B": {"participates": False, "R": 0.0},
             "C": {"participates": True, "R": 300.0}}
    pool = sum(j["R"] * ALPHA["g"] for j in juris.values() if j["participates"])
    retained = {k: (v["R"] * (1 - ALPHA["g"]) if v["participates"] else 0.0) for k, v in juris.items()}
    ok = juris["B"]["R"] == 0.0 and retained["B"] == 0.0
    ok &= abs(sum(retained.values()) + pool - sum(j["R"] for j in juris.values())) < 1e-9
    check("T22 federation: non-participant not levied; only alpha_g crosses borders (E6)", ok)

    # T23 EDA leakage bound (model)
    r_min, S, X_embedded, err = 1.0, 0.5, 100.0, 0.05
    charge_home = r_min * psi(S) * X_embedded
    charge_import = r_min * psi(S) * X_embedded * (1 - err)   # EDA under-measures by err
    gain = charge_home - charge_import
    check("T23 EDA bounds relocation gain by measurement error (Prop. 7, model only)",
          gain <= err * charge_home + 1e-9, f"gain={gain:.2f}")

    # T24 food-floor guard (5.5)
    def guard(lam, s_food, a_div=ALPHA["div"]):
        return lam * s_food <= a_div
    check("T24 food-floor guard holds iff lambda·s_food <= alpha_div",
          guard(1.0, 0.5) and guard(0.3, 0.9) and not guard(1.0, 0.8))

    # T25 WoD gate
    water = {"measurable": 1, "attributable": 1, "veil_safe": 1, "material": 1}
    person = {"measurable": 1, "attributable": 1, "veil_safe": 0, "material": 1}
    ok = wod(water) == 1 and wod(person) == 0
    for k in water:
        e = dict(water)
        e[k] = 0
        ok &= wod(e) == 0
    check("T25 WoD gate: person-layer rejected; any zero blocks", ok)

    # T26 S5 OPEN
    ph = Phase()
    ph.idx = 4
    check("T26 S5 remains OPEN: entry into Phi5 by gate-naming rejected",
          not ph.advance({"named_steward": True}, reserve=1e9, obligation=1))

    # T27-T29 metrics
    with open(METRICS, encoding="utf-8") as f:
        M = json.load(f)
    allm = [m for fam in M["families"] for m in fam["metrics"]]
    req = {"id", "name", "formula", "unit", "direction", "source", "tag", "scale", "layer"}
    check("T27 metric registry: 57 metrics, 7 families, all required fields",
          len(allm) == 57 == M["count"] and len(M["families"]) == 7 and all(req <= set(m) for m in allm))
    ids = [m["id"] for m in allm]
    with open(WP, encoding="utf-8") as f:
        wp = f.read()
    sec = wp[wp.index("### §9.2"): wp.index("### §9.3")]
    wp_ids = re.findall(r"^\| ([A-Z]{1,2}\d+m?) \|", sec, flags=re.M)
    check("T28 metric IDs unique; WP §9.2 tables match JSON exactly",
          len(ids) == len(set(ids)) and wp_ids == ids, f"{len(wp_ids)} rows in WP")
    check("T29 no metric reads person-layer data",
          all(m["layer"] in ("resource", "aggregate") for m in allm))

    # T30 pre-registration hash
    with open(PREREG, encoding="utf-8") as f:
        pre = json.load(f)
    s10 = wp[wp.index("## §10 Falsification"): wp.index("**Estimation discipline.**")]
    h = hashlib.sha256(s10.encode("utf-8")).hexdigest()
    check("T30 pre-registration table matches stored SHA-256", h == pre["sha256_section10_table"], h[:16])

    # T31 anchors
    with open(ANCHORS, encoding="utf-8") as f:
        A = json.load(f)
    ok = A["asserts_revenue_magnitude"] is False
    ok &= all(a.get("source") and a.get("tag") for a in A["anchors"])
    ok &= {f"D{i}" for i in range(1, 11)} <= {a["id"] for a in A["anchors"]}
    check("T31 anchors D1-D10 sourced and tagged; no revenue magnitude asserted", ok)

    # T32 vocabulary firewall
    vf = wp[wp.index("### §2.2"): wp.index("## §3 ")]
    eqs = wp[wp.index("## §5 The levy"): wp.index("## §7 Notation Lock")]
    ok = "**Bio-Ecologic** Resonance Architecture" in vf
    ok &= "**Universal Basic Income Merit Incentives Accounts**" in vf
    ok &= "Global Actuary Investor Authority" in wp and "InvestorAuthority" not in wp
    ok &= "GCF" not in eqs
    check("T32 vocabulary firewall: canonical BERA/UBIMIA/GAIA; GCF absent from equations", ok)

    # T33 FLIP coupling
    new_tax = {"PHI0": False, "PHI1": False, "PHI2": True, "PHI3": True, "PHI4": "shift"}
    earth_bond_refs = ["W5", "W6"]
    layer = {m["id"]: m["layer"] for m in allm}
    ok = new_tax["PHI0"] is False and new_tax["PHI1"] is False
    ok &= all(layer[r] in ("resource", "aggregate") for r in earth_bond_refs)
    ok &= "ARI" not in earth_bond_refs
    check("T33 FLIP coupling: no new tax Phi0-Phi1; Earth Bond refs are WoD metrics only", ok)

    # T34 Layer Doctrine
    view = Ledger({"W_basin": 1.2e6, "S_b": 0.42}).view()
    try:
        view["S_b"] = 0.1
        ok = False
    except PermissionError:
        ok = view["S_b"] == 0.42
    check("T34 Layer Doctrine: L3 gate cannot write L1/L2 measurement", ok)

    # T35 condition-gated only
    ph = Phase()
    ok = not ph.advance({"metered_share": False}, reserve=1e9, obligation=1, date_reached=True)
    ok &= ph.advance({"metered_share": True}, reserve=1e9, obligation=1, date_reached=False)
    check("T35 phases advance on conditions only; a date alone never advances", ok)

    # Ramp sanity (supports F1/F2 in WP §6.2)
    Rt = [logistic(t) for t in range(0, 41)]
    if not (all(0 < x < 1 for x in Rt) and all(b > a for a, b in zip(Rt, Rt[1:]))):
        check("T35b ramp logistic bounded and monotone", False)

    # S1-S4 author-reserved
    for k, v in AUTHOR_RULINGS.items():
        if v:
            check(k + " (author ruled)", True)
        else:
            skip(k, "load-bearing: awaits author ruling (WP §0.0)")

    print("-" * 72)
    p = sum(1 for s, _ in RESULTS if s == "PASS")
    fl = sum(1 for s, _ in RESULTS if s == "FAIL")
    sk = sum(1 for s, _ in RESULTS if s == "SKIP")
    verdict = "PASS" if fl == 0 else "FAIL"
    print(f"VERDICT: {verdict} ({p} pass / {fl} fail / {sk} skip)")
    return 0 if fl == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
