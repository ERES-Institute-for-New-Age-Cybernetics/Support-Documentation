#!/usr/bin/env python3
"""make_figures.py: regenerates Figures 1-2 for ERES-GAIA-WAGTAX-2026-001 v0.1.
Standard library only. CCAL v2.1 / CC BY 4.0. Joseph Allen Sprute (ERES Maestro)."""
import math
import os
from xml.sax.saxutils import escape as esc

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "figures")
ID = "ERES-GAIA-WAGTAX-2026-001_v0_1"
INK, MUTED, LINE, BG = "#1f2933", "#52606d", "#9aa5b1", "#ffffff"
WATER, AG, LAW, GAIA, OPEN = "#1d6fa5", "#3b7d3a", "#7a4b9c", "#a86b12", "#b0413e"
FONT = "font-family='Helvetica, Arial, sans-serif'"


def box(x, y, w, h, title, sub, color, fill="#ffffff"):
    lines = sub if isinstance(sub, list) else [sub]
    t = [f"<rect x='{x}' y='{y}' width='{w}' height='{h}' rx='8' fill='{fill}' stroke='{color}' stroke-width='2'/>",
         f"<text x='{x + w / 2}' y='{y + 22}' text-anchor='middle' {FONT} font-size='14' font-weight='700' fill='{color}'>{esc(title)}</text>"]
    for i, s in enumerate(lines):
        t.append(f"<text x='{x + w / 2}' y='{y + 42 + 16 * i}' text-anchor='middle' {FONT} font-size='11.5' fill='{INK}'>{esc(s)}</text>")
    return "\n".join(t)


def arrow(x1, y1, x2, y2, label=""):
    s = f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='{MUTED}' stroke-width='1.6' marker-end='url(#a)'/>"
    if label:
        s += f"<text x='{(x1 + x2) / 2 + 6}' y='{(y1 + y2) / 2 - 4}' {FONT} font-size='10.5' fill='{MUTED}'>{label}</text>"
    return s


DEFS = (f"<defs><marker id='a' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto'>"
        f"<path d='M0,0 L10,5 L0,10 z' fill='{MUTED}'/></marker></defs>")


def fig1():
    W, H = 980, 640
    p = [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' width='{W}' height='{H}'>", DEFS,
         f"<rect width='{W}' height='{H}' fill='{BG}'/>",
         f"<text x='24' y='34' {FONT} font-size='18' font-weight='700' fill='{INK}'>Figure 1 · Tax the over-draw, not the person</text>",
         f"<text x='24' y='54' {FONT} font-size='12' fill='{MUTED}'>ERES-GAIA-WAGTAX-2026-001 v0.1 · base rule → levy → recycling · FLIP coupling on the capital side</text>"]
    # inputs
    p.append(box(24, 80, 290, 92, "Candidate base element x", ["water draw · land rent · extraction", "emissions · labour income · a person"], MUTED))
    p.append(box(344, 80, 290, 92, "WoD gate = M · A · V · D", ["Measurable · Attributable", "Veil-safe · Material (any 0 blocks)"], LAW))
    p.append(box(664, 80, 292, 92, "Excluded", ["persons, location, biometrics (V = 0)", "survival floor F_d (A-Floor)"], OPEN, "#fff7f6"))
    p.append(arrow(314, 126, 342, 126))
    p.append(arrow(634, 126, 662, 126))
    p.append(f"<text x='636' y='150' {FONT} font-size='10.5' fill='{MUTED}'>fails</text>")
    # levy
    p.append(box(250, 210, 480, 110, "Over-draw levy (WATER / AG entry)",
                 ["X = max(0, W − Q)    ψ(S) = 1 + βS",
                  "L = max(0, r(t)·ψ(S)·X + d·D − O)",
                  "unused offset U → qualifies support, never a balance"], WATER))
    p.append(arrow(489, 172, 489, 208, "passes"))
    # recycling
    p.append(arrow(489, 320, 489, 352))
    p.append(f"<text x='500' y='343' {FONT} font-size='11' fill='{MUTED}'>revenue ℛ allocated by α (Σα = 1)</text>")
    cols = [("Dividend α_div 0.55", ["equal per capita", "UBIMIA survival term"], AG),
            ("Tuning α_rep 0.20", ["capped, vs ledgered", "restoration"], AG),
            ("RTB reserve α_res 0.10", ["≥ h periods of", "floor obligations"], GAIA),
            ("Commons α_g 0.10", ["pooled across jurisdictions,", "equal per capita"], GAIA),
            ("Admin α_adm ≤ 0.05", ["hard cap"], MUTED)]
    x = 24
    for t, s, col in cols:
        p.append(box(x, 356, 178, 80, t, s, col))
        x += 188
    # GAIA + FLIP
    p.append(box(24, 480, 452, 118, "GAIA: Global Actuary Investor Authority",
                 ["actuary + registrar, not a taxing sovereign", "prices scarcity (SAI, AFS) · holds GAIA Fund",
                  "certifies WoD + QDRL mutual recognition · S5 OPEN"], GAIA, "#fffaf2"))
    p.append(box(504, 480, 452, 118, "FLIP (capital side): Earth Bonds",
                 ["debt service redirected · no new tax", "yield referenced to basin metrics W5, W6",
                  "falsifiers F1 < 15% · F2 < +8%"], WATER, "#f3f8fc"))
    p.append(arrow(560, 436, 400, 478))
    p.append(arrow(740, 436, 420, 478))
    p.append(arrow(476, 540, 502, 540))
    p.append(f"<text x='24' y='626' {FONT} font-size='10.5' fill='{MUTED}'>Rates and shares are ASSERTED test values, not claims. CCAL v2.1 / CC BY 4.0 · J. A. Sprute (ERES Maestro) · drafted under Sentience</text>")
    p.append("</svg>")
    return "\n".join(p)


def fig2():
    W, H = 980, 548
    x0, x1, y0, y1 = 80, 940, 420, 90
    p = [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' width='{W}' height='{H}'>", DEFS,
         f"<rect width='{W}' height='{H}' fill='{BG}'/>",
         f"<text x='24' y='34' {FONT} font-size='18' font-weight='700' fill='{INK}'>Figure 2 · Phase-in through WATER/AG: coverage R(t), gated by condition</text>",
         f"<text x='24' y='54' {FONT} font-size='12' fill='{MUTED}'>R(t) = 1/(1+e^(−k(t−t₀))) · r(t) = r_max·R(t) · advance only when the gate passes and Reserve ≥ h·obligation</text>",
         f"<line x1='{x0}' y1='{y0}' x2='{x1}' y2='{y0}' stroke='{LINE}'/>",
         f"<line x1='{x0}' y1='{y0}' x2='{x0}' y2='{y1 - 10}' stroke='{LINE}'/>",
         f"<text x='{x0 - 10}' y='{y0 + 4}' text-anchor='end' {FONT} font-size='11' fill='{MUTED}'>0</text>",
         f"<text x='{x0 - 10}' y='{y1 + 4}' text-anchor='end' {FONT} font-size='11' fill='{MUTED}'>1</text>",
         f"<text x='30' y='{(y0 + y1) / 2}' {FONT} font-size='11' fill='{MUTED}' transform='rotate(-90 30 {(y0 + y1) / 2})'>coverage R(t)</text>"]
    pts = []
    for i in range(0, 201):
        t = i / 200 * 40
        R = 1 / (1 + math.exp(-0.32 * (t - 20)))
        pts.append(f"{x0 + (x1 - x0) * i / 200:.1f},{y0 - (y0 - y1) * R:.1f}")
    p.append(f"<polyline points='{' '.join(pts)}' fill='none' stroke='{WATER}' stroke-width='2.6'/>")
    phases = [("Φ0 Measure", "meter + shadow ledger", "no new tax", AG),
              ("Φ1 Repurpose", "harmful support → tuning", "no new tax", AG),
              ("Φ2 Levy", "over-draw levy + dividend", "levy on X only", WATER),
              ("Φ3 Federate", "QDRL + EDA + commons", "≥ 2 jurisdictions", LAW),
              ("Φ4 Extend/shift", "new WoD bases", "shift, never add", GAIA),
              ("Φ5 Generation", "S5–S6 · 1000 yr", "S5 OPEN", OPEN)]
    seg = (x1 - x0) / 6
    for k, (n, a, b, col) in enumerate(phases):
        xa = x0 + seg * k
        if k:
            p.append(f"<line x1='{xa:.1f}' y1='{y1 - 10}' x2='{xa:.1f}' y2='{y0}' stroke='{LINE}' stroke-dasharray='4 4'/>")
            p.append(f"<text x='{xa:.1f}' y='{y1 - 16}' text-anchor='middle' {FONT} font-size='10' fill='{MUTED}'>gate {k}</text>")
        cx = xa + seg / 2
        dash = " stroke-dasharray='5 4'" if k == 5 else ""
        p.append(f"<rect x='{xa + 6:.1f}' y='{y0 + 14}' width='{seg - 12:.1f}' height='66' rx='6' fill='#ffffff' stroke='{col}' stroke-width='1.8'{dash}/>")
        p.append(f"<text x='{cx:.1f}' y='{y0 + 32}' text-anchor='middle' {FONT} font-size='12' font-weight='700' fill='{col}'>{n}</text>")
        p.append(f"<text x='{cx:.1f}' y='{y0 + 49}' text-anchor='middle' {FONT} font-size='10.5' fill='{INK}'>{a}</text>")
        p.append(f"<text x='{cx:.1f}' y='{y0 + 66}' text-anchor='middle' {FONT} font-size='10.5' fill='{MUTED}'>{b}</text>")
    p.append(f"<text x='{x0 + 8}' y='{y1 + 18}' {FONT} font-size='11' fill='{MUTED}'>Floor ratchet: coverage never withdrawn · RTB: h = 12 periods (ASSERTED) · a date alone never advances a phase</text>")
    p.append(f"<text x='24' y='{H - 8}' {FONT} font-size='10.5' fill='{MUTED}'>Illustrative curve; k and t₀ are fitted from gate passage, not set by date. CCAL v2.1 / CC BY 4.0 · J. A. Sprute (ERES Maestro)</text>")
    p.append("</svg>")
    return "\n".join(p)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for name, fn in (("FIG1_ARCHITECTURE", fig1), ("FIG2_PHASE-IN", fig2)):
        path = os.path.join(OUT, f"{ID}_{name}.svg")
        with open(path, "w", encoding="utf-8") as f:
            f.write(fn())
        print("wrote", os.path.relpath(path, HERE))
