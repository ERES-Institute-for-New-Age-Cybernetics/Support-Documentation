#!/usr/bin/env python3
"""
eres_howway_test_instrument.py
ERES-HOWWAY-2026-001  |  HowWay WP v2 (v0.2 PROPOSED)  |  CCAL v2.1 / CC-BY 4.0
Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics

WHAT THIS IS
    A stdlib-only reference model of the six runtime-assurance questions and a
    test suite that exercises it. Run:   python3 eres_howway_test_instrument.py

WHAT THIS IS NOT
    Not a runtime. Not a proof against a live or novel attacker. Green means the
    SPECIFICATION behaves as written against a MODELED adversary. The model
    exposes no is_safe / is_secure / is_compliant verdict, and no test asserts one.

OPEN ITEMS (H1-H7) are skipped tests. The suite is meant to stay green-with-skips
until those items are closed by evidence, not by model agreement.
"""
import hashlib
import json
import math
import os
import sys
import unittest

# --------------------------------------------------------------------------
# Reference model
# --------------------------------------------------------------------------

GENESIS = "0" * 64


class Somt:
    """Append-only, hash-chained provenance log (GEAR's recording substrate)."""

    def __init__(self):
        self.entries = []

    def append(self, record):
        prev = self.entries[-1]["hash"] if self.entries else GENESIS
        body = json.dumps(record, sort_keys=True)
        h = hashlib.sha256((prev + body).encode()).hexdigest()
        self.entries.append({"i": len(self.entries), "prev": prev, "record": record, "hash": h})
        return h

    def verify(self):
        """Return (ok, first_bad_index). Detects edit, deletion or reordering."""
        prev = GENESIS
        for n, e in enumerate(self.entries):
            body = json.dumps(e["record"], sort_keys=True)
            if e["prev"] != prev or e["hash"] != hashlib.sha256((prev + body).encode()).hexdigest():
                return False, n
            prev = e["hash"]
        return True, None


def por_admit(a, r, p, f):
    """PoR = A x R x P x F. Conjunctive: any zero factor blocks.
    Model convention: each factor is an admissibility score in [0,1]; 0 = inadmissible.
    (F is scored as admissibility with respect to finality-risk.) No threshold is asserted:
    only an exact zero blocks, which is the corpus rule. A threshold would be an ASSERTED
    parameter (see H2)."""
    factors = (a, r, p, f)
    if any(x < 0 or x > 1 for x in factors):
        raise ValueError("factors must lie in [0,1]")
    score = a * r * p * f
    return score > 0.0, score


def rcr_authorised(live_state, now, ttl=30.0):
    """Runtime Containment Requirement: no execution without live-state authorisation.
    Authorisation must exist AND be fresh (age <= ttl seconds)."""
    if not live_state or not live_state.get("token"):
        return False
    return (now - live_state["issued_at"]) <= ttl


def raec_route(required_tier, agent_tier):
    """Risk-adaptive execution across four autonomy tiers (0..3).
    Escalate when the action needs more autonomy than the agent holds."""
    if required_tier not in (0, 1, 2, 3) or agent_tier not in (0, 1, 2, 3):
        raise ValueError("tiers are 0..3")
    return "execute" if required_tier <= agent_tier else "escalate"


def rhc_drift(history, x, k=1.0):
    """Resonant Harmony Cycle drift check: flag x if it lies more than k sigma from
    the baseline mean. k=1.0 is ASSERTED (corpus states 'within 1 sigma'); see H2."""
    n = len(history)
    if n < 2:
        return False
    mu = sum(history) / n
    var = sum((h - mu) ** 2 for h in history) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return x != mu
    return abs(x - mu) > k * sd


def _jacobi_eigenvalues(m, tol=1e-12, max_sweeps=100):
    """Eigenvalues of a real symmetric matrix by the cyclic Jacobi method (pure Python)."""
    n = len(m)
    a = [row[:] for row in m]
    for _ in range(max_sweeps):
        off = sum(a[i][j] ** 2 for i in range(n) for j in range(n) if i != j)
        if off < tol:
            break
        for p in range(n - 1):
            for q in range(p + 1, n):
                if abs(a[p][q]) < 1e-15:
                    continue
                theta = (a[q][q] - a[p][p]) / (2.0 * a[p][q])
                t = (1.0 if theta >= 0 else -1.0) / (abs(theta) + math.sqrt(theta * theta + 1.0))
                c = 1.0 / math.sqrt(t * t + 1.0)
                s = t * c
                for k in range(n):
                    akp, akq = a[k][p], a[k][q]
                    a[k][p] = c * akp - s * akq
                    a[k][q] = s * akp + c * akq
                for k in range(n):
                    apk, aqk = a[p][k], a[q][k]
                    a[p][k] = c * apk - s * aqk
                    a[q][k] = s * apk + c * aqk
    return [a[i][i] for i in range(n)]


def n_eff(corr):
    """Effective independence of nodes: (sum sqrt(l_i))^2 / sum l_i over the eigenspectrum
    of the node-correlation matrix. Identity(n) -> n ; all-ones(n) -> 1 ;
    for k=2 it reduces to 1 + sqrt(1 - r^2)."""
    lam = [max(v, 0.0) for v in _jacobi_eigenvalues(corr)]
    total = sum(lam)
    if total <= 0:
        return 0.0
    return (sum(math.sqrt(v) for v in lam) ** 2) / total


def independence_gate(corr, miev_scores, tau=3.0, miev_min=8.5):
    """Ratify iff n_eff >= tau AND mean(MIEVM) >= miev_min. Conjunctive.
    tau=3.0 is ASSERTED (see H2)."""
    ne = n_eff(corr)
    mean = sum(miev_scores) / len(miev_scores)
    return (ne >= tau and mean >= miev_min), ne, mean


class Workflow:
    """A gated workflow. Every governed action is decided AND logged inside run()."""

    def __init__(self, clock=lambda: 0.0):
        self.log = Somt()
        self.clock = clock
        self.effects = []          # what actually happened (the effect ledger)
        self.agent_level = {}      # agent -> level 1..3
        self.quarantined = set()

    def run(self, agent, action, por, live_state, required_tier=0, agent_tier=3):
        now = self.clock()
        if agent in self.quarantined:
            decision, why = "block", "agent isolated"
        elif not rcr_authorised(live_state, now):
            decision, why = "block", "no live-state authorisation (RCR)"
        else:
            ok, score = por_admit(*por)
            if not ok:
                decision, why = "block", "PoR zero factor"
            elif raec_route(required_tier, agent_tier) == "escalate":
                decision, why = "escalate", "action tier exceeds agent tier (RAEC)"
            else:
                decision, why = "execute", "admitted"
        h = self.log.append({"t": now, "agent": agent, "action": action,
                             "por": list(por), "decision": decision, "why": why})
        if decision == "execute":
            self.effects.append({"agent": agent, "action": action, "log_hash": h})
        return decision, h

    def challenge(self, ref_hash, by, reason):
        return self.log.append({"type": "challenge", "ref": ref_hash, "by": by, "reason": reason})

    def respond(self, ref_hash, by, text):
        return self.log.append({"type": "response", "ref": ref_hash, "by": by, "text": text})

    def remediate(self, agent, breach):
        """Non-punitive remediation: isolate, downgrade L3->L1, audit (logged)."""
        self.quarantined.add(agent)
        self.agent_level[agent] = 1
        return self.log.append({"type": "remediation", "agent": agent, "breach": breach,
                                "steps": ["isolate", "downgrade L3->L1", "audit"]})

    def telemetry(self):
        """Telemetry is a pure function of the log (no side channel)."""
        return telemetry_from_log(self.log.entries)


def telemetry_from_log(entries):
    d = {"execute": 0, "block": 0, "escalate": 0, "challenges": 0, "remediations": 0}
    for e in entries:
        r = e["record"]
        if r.get("type") == "challenge":
            d["challenges"] += 1
        elif r.get("type") == "remediation":
            d["remediations"] += 1
        elif "decision" in r:
            d[r["decision"]] += 1
    total = d["execute"] + d["block"] + d["escalate"]
    d["gated"] = total
    d["intervention_rate"] = (d["block"] + d["escalate"]) / total if total else 0.0
    return d


def reconcile(effects, log_entries):
    """Independent effect-ledger reconciliation: every effect must trace to a logged
    'execute' decision. Returns the list of effects with no matching log entry."""
    logged = {e["hash"] for e in log_entries if e["record"].get("decision") == "execute"}
    return [x for x in effects if x.get("log_hash") not in logged]


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------

LIVE = {"token": "t1", "issued_at": 0.0}
GOOD = (0.9, 0.9, 0.9, 0.9)


class Q1_ProveOperating(unittest.TestCase):
    def test_log_verifies_when_untouched(self):
        w = Workflow()
        for i in range(5):
            w.run("a1", f"act{i}", GOOD, LIVE)
        self.assertEqual(w.log.verify(), (True, None))

    def test_edit_is_detected(self):
        w = Workflow()
        for i in range(5):
            w.run("a1", f"act{i}", GOOD, LIVE)
        w.log.entries[2]["record"]["decision"] = "block"
        ok, idx = w.log.verify()
        self.assertFalse(ok)
        self.assertEqual(idx, 2)

    def test_deletion_is_detected(self):
        w = Workflow()
        for i in range(5):
            w.run("a1", f"act{i}", GOOD, LIVE)
        del w.log.entries[1]
        self.assertFalse(w.log.verify()[0])

    def test_reorder_is_detected(self):
        w = Workflow()
        for i in range(4):
            w.run("a1", f"act{i}", GOOD, LIVE)
        w.log.entries[1], w.log.entries[2] = w.log.entries[2], w.log.entries[1]
        self.assertFalse(w.log.verify()[0])


class Q2_Telemetry(unittest.TestCase):
    def test_telemetry_is_pure_function_of_log(self):
        w = Workflow()
        w.run("a1", "x", GOOD, LIVE)
        w.run("a1", "y", (0.0, 1, 1, 1), LIVE)
        w.run("a1", "z", GOOD, LIVE, required_tier=3, agent_tier=1)
        self.assertEqual(w.telemetry(), telemetry_from_log(w.log.entries))

    def test_telemetry_counts(self):
        w = Workflow()
        w.run("a1", "x", GOOD, LIVE)
        w.run("a1", "y", (0.0, 1, 1, 1), LIVE)
        w.run("a1", "z", GOOD, LIVE, required_tier=3, agent_tier=1)
        t = w.telemetry()
        self.assertEqual((t["execute"], t["block"], t["escalate"]), (1, 1, 1))
        self.assertAlmostEqual(t["intervention_rate"], 2 / 3)


class Q3_AutomaticEvidence(unittest.TestCase):
    def test_evidence_exists_when_action_completes(self):
        w = Workflow()
        before = len(w.log.entries)
        w.run("a1", "x", GOOD, LIVE)
        self.assertEqual(len(w.log.entries), before + 1)  # no separate collection step

    def test_every_gated_effect_traces_to_log(self):
        w = Workflow()
        for i in range(6):
            w.run("a1", f"a{i}", GOOD, LIVE)
        self.assertEqual(reconcile(w.effects, w.log.entries), [])


class Q4_DetectChange(unittest.TestCase):
    BASE = [10.0, 10.2, 9.8, 10.1, 9.9, 10.0, 10.1, 9.9]

    def test_shift_beyond_baseline_is_flagged(self):
        self.assertTrue(rhc_drift(self.BASE, 12.0))

    def test_value_near_baseline_not_flagged(self):
        self.assertFalse(rhc_drift(self.BASE, 10.05))

    def test_n_eff_identity_is_n(self):
        eye = [[1.0 if i == j else 0.0 for j in range(4)] for i in range(4)]
        self.assertAlmostEqual(n_eff(eye), 4.0, places=6)

    def test_n_eff_collapses_under_full_correlation(self):
        ones = [[1.0] * 4 for _ in range(4)]
        self.assertAlmostEqual(n_eff(ones), 1.0, places=6)

    def test_n_eff_k2_identity(self):
        for r in (0.0, 0.3, 0.7, 0.95):
            got = n_eff([[1.0, r], [r, 1.0]])
            self.assertAlmostEqual(got, 1.0 + math.sqrt(1.0 - r * r), places=6)

    def test_sybil_cluster_blocks_ratification(self):
        # 5 nodes: 4 near-duplicates of one voter + 1 independent, all scoring high
        n = 5
        corr = [[1.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    corr[i][j] = 1.0
                elif i == 4 or j == 4:
                    corr[i][j] = 0.05
                else:
                    corr[i][j] = 0.98
        ok, ne, mean = independence_gate(corr, [9.5] * n)
        self.assertGreaterEqual(mean, 8.5)   # agreement is high...
        self.assertLess(ne, 3.0)             # ...independence is not
        self.assertFalse(ok)                 # so ratification is refused

    def test_independent_high_agreement_ratifies(self):
        eye = [[1.0 if i == j else 0.0 for j in range(5)] for i in range(5)]
        ok, ne, mean = independence_gate(eye, [9.0] * 5)
        self.assertTrue(ok)

    def test_independent_low_agreement_refused(self):
        eye = [[1.0 if i == j else 0.0 for j in range(5)] for i in range(5)]
        self.assertFalse(independence_gate(eye, [7.0] * 5)[0])


class Q5_StopOrEscalate(unittest.TestCase):
    def test_any_zero_factor_blocks(self):
        for z in range(4):
            f = [0.9, 0.9, 0.9, 0.9]
            f[z] = 0.0
            self.assertFalse(por_admit(*f)[0])

    def test_all_positive_admits(self):
        self.assertTrue(por_admit(0.1, 0.1, 0.1, 0.1)[0])

    def test_factors_out_of_range_rejected(self):
        with self.assertRaises(ValueError):
            por_admit(1.2, 1, 1, 1)

    def test_no_live_authorisation_blocks(self):
        w = Workflow()
        self.assertEqual(w.run("a1", "x", GOOD, None)[0], "block")

    def test_stale_authorisation_blocks(self):
        t = [0.0]
        w = Workflow(clock=lambda: t[0])
        t[0] = 100.0
        self.assertEqual(w.run("a1", "x", GOOD, {"token": "t", "issued_at": 0.0})[0], "block")

    def test_tier_exceeding_agent_escalates(self):
        w = Workflow()
        self.assertEqual(w.run("a1", "x", GOOD, LIVE, required_tier=3, agent_tier=1)[0], "escalate")

    def test_blocked_action_has_no_effect(self):
        w = Workflow()
        w.run("a1", "x", (0.0, 1, 1, 1), LIVE)
        self.assertEqual(w.effects, [])

    def test_remediation_isolates_and_downgrades(self):
        w = Workflow()
        w.remediate("a1", "breach-1")
        self.assertEqual(w.agent_level["a1"], 1)
        self.assertEqual(w.run("a1", "x", GOOD, LIVE)[0], "block")
        self.assertEqual(w.telemetry()["remediations"], 1)


class Q6_InWorkflow(unittest.TestCase):
    def test_decision_and_log_are_one_step(self):
        w = Workflow()
        d, h = w.run("a1", "x", GOOD, LIVE)
        self.assertEqual(w.log.entries[-1]["hash"], h)   # logged by the same call that decided

    def test_challenge_response_are_chained_to_decision(self):
        w = Workflow()
        d, h = w.run("a1", "x", GOOD, LIVE)
        c = w.challenge(h, "user-group-2", "scope exceeded")
        w.respond(c, "owner", "scope confirmed")
        self.assertEqual(w.log.verify(), (True, None))
        self.assertEqual(w.log.entries[-2]["record"]["ref"], h)
        self.assertEqual(w.log.entries[-1]["record"]["ref"], c)

    def test_no_deferred_queue(self):
        # Nothing in the model batches decisions for later assessment: the log length
        # equals the number of run() calls at every step.
        w = Workflow()
        for i in range(5):
            w.run("a1", f"a{i}", GOOD, LIVE)
            self.assertEqual(len(w.log.entries), i + 1)


class Limits_DocumentedNotClosed(unittest.TestCase):
    """These PASS by demonstrating a limit. They are not closures of H1-H7."""

    def test_H1_bypass_is_invisible_to_the_log_alone(self):
        w = Workflow()
        w.run("a1", "gated", GOOD, LIVE)
        w.effects.append({"agent": "rogue", "action": "ungated", "log_hash": None})  # gate evaded
        self.assertEqual(w.log.verify(), (True, None))   # the log is intact and says nothing
        self.assertEqual(len(w.log.entries), 1)

    def test_H1_reconciliation_against_effect_ledger_detects_bypass(self):
        w = Workflow()
        w.run("a1", "gated", GOOD, LIVE)
        w.effects.append({"agent": "rogue", "action": "ungated", "log_hash": None})
        missing = reconcile(w.effects, w.log.entries)
        self.assertEqual([m["action"] for m in missing], ["ungated"])
        # Caveat kept in the test: this only works if the effect ledger is itself
        # independent of the gate. In this model it is not; see H1 / H3.

    def test_H2_rhc_1sigma_false_alarm_rate_is_about_32_percent(self):
        # For stationary Gaussian noise, P(|z| > 1) = erfc(1/sqrt(2)) ~ 0.3173.
        p = math.erfc(1.0 / math.sqrt(2.0))
        self.assertAlmostEqual(p, 0.3173, places=3)
        # => k=1 is a corpus-stated return target, not a usable alarm threshold as-is.


class Package_Integrity(unittest.TestCase):
    def test_manifest_matches_files(self):
        here = os.path.dirname(os.path.abspath(__file__))
        mp = os.path.join(here, "MANIFEST.json")
        if not os.path.exists(mp):
            self.skipTest("no MANIFEST.json next to the harness")
        man = json.load(open(mp))
        for name, digest in man["files"].items():
            path = os.path.join(here, name)
            self.assertTrue(os.path.exists(path), f"missing {name}")
            self.assertEqual(hashlib.sha256(open(path, "rb").read()).hexdigest(), digest, name)


class OPEN_Items(unittest.TestCase):
    @unittest.skip("H1 OPEN: no proof that PoR + RCR + RAEC block ALL malicious actions; gate bypass is the central risk")
    def test_H1(self): pass

    @unittest.skip("H2 OPEN: BERA/RHC thresholds and tau are asserted, not derived; signal not shown to track real failures")
    def test_H2(self): pass

    @unittest.skip("H3 OPEN: SOMT tamper-evidence and external anchoring not realised outside the model")
    def test_H3(self): pass

    @unittest.skip("H4 OPEN: latency/throughput cost of gating every action is unmeasured")
    def test_H4(self): pass

    @unittest.skip("H5 OPEN: external red-team of a running system; NOT simulable")
    def test_H5(self): pass

    @unittest.skip("H6 OPEN: regulatory fit (EU AI Act / GDPR / eIDAS) not established; see RRH")
    def test_H6(self): pass

    @unittest.skip("H7 OPEN: bio-electric inputs (Kirlianography / Schumann coupling) unvalidated; excluded from every claim here")
    def test_H7(self): pass


if __name__ == "__main__":
    result = unittest.main(exit=False, verbosity=1)
    ok = result.result.wasSuccessful()
    print("\nBOUNDARY: green = SPECIFICATION vs a MODELED adversary. Not a runtime; "
          "not proof against a live attacker. OPEN items H1-H7 are skipped by design.")
    sys.exit(0 if ok else 1)
