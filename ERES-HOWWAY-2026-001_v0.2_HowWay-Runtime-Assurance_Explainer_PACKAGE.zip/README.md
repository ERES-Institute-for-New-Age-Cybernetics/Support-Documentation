# ERES-HOWWAY-2026-001_v0.2_HowWay-Runtime-Assurance_Explainer

**HowWay = ERES @: Runtime Assurance for AI Governance**
Six questions a governance control must answer while it runs, not six weeks later. A technical-to-plain-language account of the ERES finding, as it stands at v0.2.

Author: Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221
License: CCAL v2.1 / CC BY 4.0 | Date: 2026-10-09 | As-is account of v0.2 PROPOSED: pre-canonical, not MIEVM-rated, canonical ID pending JAS confirmation

## What this is
An as-is, technical-to-plain-language account of the ERES finding that six runtime-assurance questions can be answered by construction within one architecture (HowWay = ERES @; mechanism GEAR x DERR + ERES). Sections: Title, Subtitle, Keywords, Abstract, Introduction, Body of Evidence, Conclusions, Historical Notes, Credits, References, License.

## Contents
| File | Role |
|---|---|
| ERES-HOWWAY-2026-001_v0.2_HowWay-Runtime-Assurance_Explainer.pdf | Paper (PDF, figure embedded) |
| ERES-HOWWAY-2026-001_v0.2_HowWay-Runtime-Assurance_Explainer.md | Paper (Markdown, same text) |
| ERES-HOWWAY-2026-001_v0.2_Figure-1_Assessment-vs-Runtime.svg | Figure 1 (SVG) |
| ERES-HOWWAY-2026-001_v0.2_DATA.json | Structured data: six-question mapping, gate, tests, open items, share text |
| eres_howway_test_instrument.py | Test instrument (Python standard library only) |
| LICENSE.md | Full CCAL v2.1 text |
| META.txt | SEO title, abstract, keywords, LinkedIn and ResearchGate share messages, citation |
| README.md | This file |
| MANIFEST.json | sha256 for every file above |
| RUN.txt | Test run log from a fresh extract (written after the manifest, so not hashed in it) |

## Run the tests
    python3 eres_howway_test_instrument.py
Expected: 38 tests, 31 pass, 7 skipped by design (open items H1-H7), exit code 0. One test verifies every hash in MANIFEST.json.

## Boundary
Specification against a modeled adversary. Not a runtime; not proof against a live attacker; no compliance claim. See section 4a of the paper for what this record does and does not include.

Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1.
