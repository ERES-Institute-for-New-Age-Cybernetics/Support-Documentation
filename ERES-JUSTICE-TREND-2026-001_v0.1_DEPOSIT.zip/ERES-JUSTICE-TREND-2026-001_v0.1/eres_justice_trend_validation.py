#!/usr/bin/env python3
"""
eres_justice_trend_validation.py
Companion TEST suite to ERES-JUSTICE-TREND-2026-001 v0.1
"The TREND: Queue-State Adjudication of the U.S. Justice Backlog
 via PlayNAC · VACATIONOMICS · LLPM"

Author:  Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
         ORCID 0000-0001-9946-3221
Drafted: under Sentience (human–AI collaboration; Claude draft assistance)
License: CC BY 4.0  (CCAL v2.1 compatible)

Pure standard library. Deterministic. Exit code = verdict (0 = PASS, 1 = FAIL),
for MIEVM nodes and CI.

What this suite does and does not prove
---------------------------------------
* It verifies the instrument's ARITHMETIC (readouts recomputed from data/trend_data.json),
  its STRUCTURAL RULES (PoR conjunctive gate, VEILED hold, min-composition),
  and its CONSTRUCTED models behave as the text claims (margin law, Pain-load, LLPM).
* It does NOT validate any causal claim about WHY the FY2026 immigration outflow rose,
  and it never adjudicates an individual case. PASS = evidence of internal consistency, not proof.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "trend_data.json")

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    mark = "PASS" if cond else "FAIL"
    print(f"  [{mark}] {name}" + (f" — {detail}" if detail else ""))
    return bool(cond)


# --------------------------------------------------------------------------- #
# Core model (mirrors Workup §2–§6)
# --------------------------------------------------------------------------- #
def queue_step(B, I, O):
    """Population Law (from ERES-ENDHOME): B(t+1) = B(t) + I(t) - O(t)."""
    return B + I - O


def readouts(B, I, O, months):
    net = I - O                                  # velocity over the window
    annual_net = net * 12.0 / months
    clearance = O / I if I else math.inf         # O/I > 1 => draining
    horizon = (B / -annual_net) if annual_net < 0 else math.inf
    return {"net": net, "annual_net": annual_net, "clearance": clearance, "horizon_yrs": horizon}


def growth(a, b):
    return b / a


def per_capita_growth(a, b, pop_a, pop_b):
    return (b / pop_b) / (a / pop_a)


def band(g20, lo=0.5, hi=2.0):
    """Band classification on 20-year per-capita growth factor (CONSTRUCTED thresholds).
    below lo -> 'contracting'; in [lo, hi] -> 'in-band'; above hi -> 'condensation'."""
    if g20 > hi:
        return "condensation"
    if g20 < lo:
        return "contracting"
    return "in-band"


def por(A, R, P, F):
    """Proof-of-Resonance admissibility gate: conjunctive product; any zero blocks."""
    for x in (A, R, P, F):
        if not (0.0 <= x <= 1.0):
            raise ValueError("PoR factors live in [0,1]")
    return A * R * P * F


def admissible(A, R, P, F):
    return por(A, R, P, F) > 0.0


def margin_valid(v, tau, dK, reserve=0.02):
    """Sentry margin law m* = v·tau. The 98/2 policy is valid iff m* <= reserve·ΔK."""
    return v * tau <= reserve * dK


def pain_load(cases):
    """Paineology debit: Σ age_years × stakes_weight."""
    return sum(age * w for age, w in cases)


def vacation_score(necessity, pain, merit):
    """VACATION (NECESSITY in cases) × Paineology + Meritcology.
    Merit enters additively (+), the necessity-weighted pain multiplicatively (×)."""
    return necessity * pain + merit


def trend_state(mechanism_decomposition, F_scored):
    """Fiduciary state of the TREND claim: OPEN -> VEILED -> EARNED."""
    if mechanism_decomposition and F_scored:
        return "EARNED"
    if mechanism_decomposition or F_scored:
        return "VEILED"
    return "VEILED"  # volume improvement alone never earns the trend


def min_compose(*grades):
    order = {"NONE": 0, "GOOD": 1, "SOUND": 2, "BEST": 3}
    return min(grades, key=lambda g: order[g])


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #
def main():
    with open(DATA) as fh:
        d = json.load(fh)

    imm = d["immigration"]
    ytd = imm["fy2026_ytd"]
    B_now = imm["series"][-1]["value"]
    I, O, months = ytd["receipts_I"], ytd["completions_O"], ytd["months"]

    print("ERES-JUSTICE-TREND-2026-001 v0.1 — validation suite")
    print("=" * 66)

    # T1 Queue law conservation & back-cast
    print("T1  Queue law (Population Law) conservation")
    B_start = B_now - I + O
    check("T1a back-cast FY2026 start reproduces end state",
          queue_step(B_start, I, O) == B_now, f"B_start={B_start:,}")
    check("T1b implied FY2026-start backlog is in the publicly reported ~3.4–3.5M range",
          3_300_000 <= B_start <= 3_500_000, f"{B_start:,}")

    # T2 Readouts
    print("T2  TREND readouts (Level, Velocity, Clearance, Horizon)")
    r = readouts(B_now, I, O, months)
    check("T2a velocity is negative (draining)", r["net"] < 0, f"net={r['net']:,}")
    check("T2b clearance ratio ≈ 1.75", abs(r["clearance"] - 1.75) < 0.01, f"{r['clearance']:.3f}")
    check("T2c annualized net outflow ≈ 420.7k", abs(r["annual_net"] + 420_742) < 50,
          f"{r['annual_net']:,.0f}")
    check("T2d clearing horizon ≈ 7.35 yrs (CONSTRUCTED: constant-rate)",
          abs(r["horizon_yrs"] - 7.35) < 0.02, f"{r['horizon_yrs']:.2f} yrs")

    # T3 Normalization
    print("T3  Per-capita normalization")
    fed = d["federal"]["series"]
    p = d["population"]
    pc_crim = per_capita_growth(fed["district_crim"]["2007"], fed["district_crim"]["2025"],
                                p["us_2007_millions"], p["us_2025_millions"])
    check("T3a federal criminal flat-or-declining per capita (≤ 1.0)", pc_crim <= 1.0, f"{pc_crim:.3f}")
    pc_civ = per_capita_growth(fed["district_civil"]["2007"], fed["district_civil"]["2025"],
                               p["us_2007_millions"], p["us_2025_millions"])
    check("T3b federal civil grew per capita but < 2× (moderate)", 1.0 < pc_civ < 2.0, f"{pc_civ:.3f}")

    # T4 Band classification
    print("T4  Band classification (20-yr per-capita growth; thresholds CONSTRUCTED)")
    g_imm = per_capita_growth(imm["series"][0]["value"], B_now, p["us_2007_millions"], p["us_2025_millions"])
    check("T4a immigration courts = condensation", band(g_imm) == "condensation", f"g={g_imm:.1f}×")
    for k in ("district_civil", "district_crim"):
        g = per_capita_growth(fed[k]["2007"], fed[k]["2025"], p["us_2007_millions"], p["us_2025_millions"])
        check(f"T4b {k} in-band", band(g) == "in-band", f"g={g:.2f}×")
    g_bk = per_capita_growth(fed["bankruptcy"]["2007"], fed["bankruptcy"]["2025"],
                             p["us_2007_millions"], p["us_2025_millions"])
    check("T4c bankruptcy contracting", band(g_bk) == "contracting", f"g={g_bk:.2f}×")

    # T5 PoR gate
    print("T5  PoR = A×R×P×F conjunctive gate (Admissibility before Speed)")
    check("T5a capacity add (judges, triage) admissible", admissible(0.9, 0.8, 0.9, 0.9))
    check("T5b throughput via due-process loss blocked (F=0)", not admissible(1.0, 1.0, 1.0, 0.0))
    check("T5c any single zero blocks regardless of others",
          all(not admissible(*[0.0 if i == j else 1.0 for i in range(4)]) for j in range(4)))
    check("T5d gate is not compensatory (high A cannot buy back low F)",
          por(1.0, 1.0, 1.0, 0.1) < por(0.5, 0.5, 0.5, 0.9),
          f"{por(1.0, 1.0, 1.0, 0.1):.4f} < {por(0.5, 0.5, 0.5, 0.9):.4f}")

    # T6 Sentry margin law
    print("T6  Sentry margin law m* = v·τ (98/2 validity)")
    check("T6a slow drift: 98/2 valid", margin_valid(v=0.01, tau=1.0, dK=1.0))
    check("T6b fast drift: 98/2 invalid -> margin must widen", not margin_valid(v=0.05, tau=1.0, dK=1.0))

    # T7 VACATIONOMICS / Paineology
    print("T7  VACATIONOMICS: Pain-load ≠ backlog size")
    small_old = [(4.0, 2.0)] * 100          # 100 cases, 4 yrs old, detained/child weight 2
    large_young = [(0.5, 1.0)] * 500        # 500 cases, 6 months, standard weight
    check("T7a smaller-but-older backlog carries more pain",
          pain_load(small_old) > pain_load(large_young),
          f"{pain_load(small_old):.0f} vs {pain_load(large_young):.0f}")
    check("T7b Meritcology additive: zero merit leaves pain term intact",
          vacation_score(1.0, 10.0, 0.0) == 10.0)
    check("T7c Necessity zero nulls the pain product, merit survives (+ floor)",
          vacation_score(0.0, 10.0, 3.0) == 3.0)

    # T8 VEILED hold
    print("T8  Fiduciary state of the TREND claim")
    check("T8a volume-only improvement stays VEILED", trend_state(False, False) == "VEILED")
    check("T8b decomposition without F-score stays VEILED", trend_state(True, False) == "VEILED")
    check("T8c decomposition + F-scored -> EARNED", trend_state(True, True) == "EARNED")

    # T9 LLPM geography
    print("T9  LLPM: national mean hides hotspots")
    w = fed_w = d["federal"]["weighted_filings_per_judgeship"]
    hot = [w["N.D. Florida"], w["E.D. California"], w["N.D. Illinois (after)"]]
    mean_hot = sum(hot) / len(hot)
    check("T9a hotspot spread > 1.75× (max/min)", max(hot) / min(hot) > 1.75, f"{max(hot)/min(hot):.2f}×")
    check("T9b N.D. Illinois load growth > 1.8×",
          w["N.D. Illinois (after)"] / w["N.D. Illinois (before)"] > 1.8,
          f"{w['N.D. Illinois (after)']/w['N.D. Illinois (before)']:.2f}×")
    check("T9c aged civil cases (>3 yrs) rose 2020→2025",
          d["federal"]["civil_over_3yrs"]["2025"] > d["federal"]["civil_over_3yrs"]["2020"])

    # T10 Provenance discipline
    print("T10 Provenance / Data-Integrity")
    tagged = all("source" in s and "tag" in s for s in imm["series"])
    check("T10a every immigration datum carries source + tag", tagged)
    srcs = set(d["sources"])
    used = {s["source"] for s in imm["series"]} | {ytd["source"], d["federal"]["source_2007_2016"],
                                                    d["federal"]["source_2025"], p["source"]}
    check("T10b every cited source key resolves", used <= srcs, f"{sorted(used - srcs)}")
    check("T10c APPROX data flagged, never silently EMPIRICAL",
          imm["series"][1]["tag"] == "APPROX" and p["tag"] == "APPROX")

    # T11 Grade composition
    print("T11 Instrument grade (min-composition, SOUND Standard)")
    grade = min_compose("SOUND", "GOOD")   # epistemic (spec, pre-MIEVM) vs health (CONSTRUCTED models)
    check("T11a pre-MIEVM instrument cannot self-grade above GOOD", grade == "GOOD", grade)

    n = len(RESULTS)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print("=" * 66)
    verdict = "PASS" if passed == n else "FAIL"
    print(f"VERDICT: {verdict}  ({passed}/{n} checks)")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
