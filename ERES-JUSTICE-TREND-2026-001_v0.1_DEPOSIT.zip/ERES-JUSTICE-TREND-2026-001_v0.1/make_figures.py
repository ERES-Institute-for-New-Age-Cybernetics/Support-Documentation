#!/usr/bin/env python3
"""Regenerates Figure 1 and Figure 2 SVGs for ERES-JUSTICE-TREND-2026-001 v0.1 from data/trend_data.json.
License: CC BY 4.0. Standard library only."""
import json, math, os

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "data", "trend_data.json")))
FONT = "font-family='Helvetica, Arial, sans-serif'"

# ---------------- Figure 1: 20-year indexed growth (log scale) ---------------- #
imm = [s["value"] for s in d["immigration"]["series"]]
fed = d["federal"]["series"]
series = [
    ("Immigration courts", imm, "#b3261e"),
    ("Federal civil", [fed["district_civil"][y] for y in ("2007", "2016", "2025")], "#1f5fa8"),
    ("Federal criminal", [fed["district_crim"][y] for y in ("2007", "2016", "2025")], "#2e7d32"),
    ("Federal appeals", [fed["appeals"][y] for y in ("2007", "2016", "2025")], "#6a4c93"),
    ("Federal bankruptcy", [fed["bankruptcy"][y] for y in ("2007", "2016", "2025")], "#8d6e63"),
]
W, H = 900, 560
L, R, T, B = 90, 250, 80, 90
pw, ph = W - L - R, H - T - B
ymin, ymax = math.log10(0.4), math.log10(25)
def yp(v): return T + ph * (1 - (math.log10(v) - ymin) / (ymax - ymin))
xs = [L + pw * i / 2 for i in range(3)]
out = [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' width='{W}' height='{H}' {FONT}>",
       f"<rect width='{W}' height='{H}' fill='#ffffff'/>",
       f"<text x='{L}' y='34' font-size='20' font-weight='700' fill='#111'>Figure 1 — The TREND: 20-year pending-caseload growth (indexed, log scale)</text>",
       f"<text x='{L}' y='56' font-size='12.5' fill='#444'>Raw index (not per-capita) = pending ÷ pending at ~20 yrs ago (immigration FY2006; federal Mar-31-2007). ERES-JUSTICE-TREND-2026-001 v0.1</text>"]
# band shading: in-band [0.5, 2.0]
out.append(f"<rect x='{L}' y='{yp(2.0):.1f}' width='{pw}' height='{yp(0.5)-yp(2.0):.1f}' fill='#e8f3e8'/>")
out.append(f"<rect x='{L}' y='{T}' width='{pw}' height='{yp(2.0)-T:.1f}' fill='#fbe9e7'/>")
out.append(f"<text x='{L+8}' y='{T+18}' font-size='12' fill='#b3261e' font-weight='700'>CONDENSATION (above upper wall, &gt; 2×)</text>")
out.append(f"<text x='{L+pw-8}' y='{yp(2.0)+16:.1f}' text-anchor='end' font-size='12' fill='#2e7d32' font-weight='700'>RESONANCE BAND (0.5×–2×, CONSTRUCTED)</text>")
out.append(f"<text x='{L+8}' y='{yp(0.5)+16:.1f}' font-size='12' fill='#6d6d6d' font-weight='700'>CONTRACTING (&lt; 0.5×)</text>")
for v in (0.5, 1, 2, 5, 10, 20):
    y = yp(v)
    out.append(f"<line x1='{L}' x2='{L+pw}' y1='{y:.1f}' y2='{y:.1f}' stroke='#cfcfcf' stroke-dasharray='3,3'/>")
    out.append(f"<text x='{L-10}' y='{y+4:.1f}' font-size='12' text-anchor='end' fill='#333'>{v}×</text>")
out.append(f"<line x1='{L}' x2='{L}' y1='{T}' y2='{T+ph}' stroke='#333'/>")
out.append(f"<line x1='{L}' x2='{L+pw}' y1='{T+ph}' y2='{T+ph}' stroke='#333'/>")
for x, lab in zip(xs, ("~20 yrs ago\n(2006/07)", "~10 yrs ago\n(2016)", "Now\n(2025/26)")):
    a, b = lab.split("\n")
    out.append(f"<text x='{x:.1f}' y='{T+ph+22}' font-size='12.5' text-anchor='middle' fill='#222'>{a}</text>")
    out.append(f"<text x='{x:.1f}' y='{T+ph+38}' font-size='11.5' text-anchor='middle' fill='#555'>{b}</text>")
for i, (name, vals, col) in enumerate(series):
    idx = [v / vals[0] for v in vals]
    pts = " ".join(f"{x:.1f},{yp(v):.1f}" for x, v in zip(xs, idx))
    out.append(f"<polyline points='{pts}' fill='none' stroke='{col}' stroke-width='3'/>")
    for x, v in zip(xs, idx):
        out.append(f"<circle cx='{x:.1f}' cy='{yp(v):.1f}' r='4.5' fill='{col}'/>")
    ly = T + 30 + i * 46
    out.append(f"<line x1='{L+pw+22}' x2='{L+pw+44}' y1='{ly}' y2='{ly}' stroke='{col}' stroke-width='3'/>")
    out.append(f"<text x='{L+pw+52}' y='{ly+4}' font-size='13' fill='#111' font-weight='600'>{name}</text>")
    out.append(f"<text x='{L+pw+52}' y='{ly+21}' font-size='11.5' fill='#444'>{vals[0]:,} → {vals[-1]:,} ({idx[-1]:.2f}×)</text>")
out.append(f"<text x='{L}' y='{H-14}' font-size='10.5' fill='#666'>Sources: TRAC, CRS R47077, U.S. Courts Judicial Caseload Indicators (2016, 2025). FY2016 immigration value APPROX. Band thresholds CONSTRUCTED. CC BY 4.0</text>")
out.append("</svg>")
open(os.path.join(HERE, "figures", "Figure1_TREND_20yr.svg"), "w").write("\n".join(out))

# ---------------- Figure 2: adjudication pipeline ---------------- #
W, H = 960, 620
o = [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' width='{W}' height='{H}' {FONT}>",
     f"<rect width='{W}' height='{H}' fill='#ffffff'/>",
     "<defs><marker id='a' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0,0 L10,5 L0,10 z' fill='#333'/></marker></defs>",
     "<text x='30' y='36' font-size='20' font-weight='700' fill='#111'>Figure 2 — Adjudicating the TREND: PlayNAC · VACATIONOMICS · LLPM</text>",
     "<text x='30' y='58' font-size='12.5' fill='#444'>The queue and every intervention on it are adjudicated — never the merits of an individual case.</text>"]
def box(x, y, w, h, title, lines, fill, stroke):
    o.append(f"<rect x='{x}' y='{y}' width='{w}' height='{h}' rx='10' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    o.append(f"<text x='{x+w/2}' y='{y+24}' font-size='14.5' font-weight='700' text-anchor='middle' fill='#111'>{title}</text>")
    for i, ln in enumerate(lines):
        o.append(f"<text x='{x+w/2}' y='{y+45+i*17}' font-size='12' text-anchor='middle' fill='#333'>{ln}</text>")
def arrow(x1, y1, x2, y2):
    o.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='#333' stroke-width='2' marker-end='url(#a)'/>")
# main spine
bw, bh, y0 = 165, 120, 250
X = [30, 215, 400, 585, 770]
box(X[0], y0, bw, bh, "1 · TREND", ["B(t+1)=B+I−O", "Level · Velocity", "Clearance O/I", "Age · Horizon"], "#eef3fb", "#1f5fa8")
box(X[1], y0, bw, bh, "2 · TABLE", ["Question: “improving?”", "Col 4 CHALLENGE:", "HOW did O rise?", "Col 5 RESPONSE"], "#f3eefb", "#6a4c93")
box(X[2], y0, bw, bh, "3 · PoR GATE", ["A × R × P × F", "any zero → BLOCK", "F = Finality-Risk", "(removal ≈ irreversible)"], "#fbe9e7", "#b3261e")
box(X[3], y0, bw, bh, "4 · CBGMODD", ["7 seats score", "MIEVM mean ≥ 8.5", "RHC: restore to 1σ", "non-punitive"], "#eef7ee", "#2e7d32")
box(X[4], y0, bw, bh, "5 · SOMT", ["append-only log", "state: OPEN →", "VEILED → EARNED", "(now: VEILED)"], "#f6f1ea", "#8d6e63")
for i in range(4):
    arrow(X[i] + bw, y0 + bh / 2, X[i + 1] - 4, y0 + bh / 2)
# side inputs
box(150, 92, 300, 112, "VACATIONOMICS (Paineology)", ["VACATION(NECESSITY) × Paineology + Meritcology", "Pain-load = Σ age × stakes weight", "Judge recovery = hard throughput input"], "#fff8e1", "#c79100")
box(510, 92, 300, 112, "LLPM (Long-Lat Prop Mgmt)", ["Each pending case at (φ, λ)", "per-court band test · hotspot map", "capacity routed spatially"], "#e0f2f1", "#00796b")
arrow(300, 204, X[1] + bw / 2, y0 - 4)
arrow(300, 204, X[2] + bw / 2 - 20, y0 - 4)
arrow(660, 204, X[0] + bw / 2 + 40, y0 - 4)
arrow(660, 204, X[3] + bw / 2, y0 - 4)
# sentry band
o.append(f"<rect x='30' y='410' width='905' height='70' rx='10' fill='#fafafa' stroke='#999' stroke-dasharray='5,4'/>")
o.append("<text x='482' y='436' font-size='14' font-weight='700' text-anchor='middle' fill='#111'>SENTRY per court — 98/2 load alarm, valid iff m* = v·τ ≤ 0.02·ΔK</text>")
o.append("<text x='482' y='458' font-size='12' text-anchor='middle' fill='#333'>Immigration courts: CONDENSATION (≈16× per-capita in 20 yrs) · Federal civil/criminal: IN-BAND, regional hotspots · Bankruptcy/appeals: contracting</text>")
# prohibited inferences
o.append("<rect x='30' y='500' width='905' height='86' rx='10' fill='#fff' stroke='#b3261e'/>")
o.append("<text x='482' y='524' font-size='13.5' font-weight='700' text-anchor='middle' fill='#b3261e'>Prohibited Inferences</text>")
for i, t in enumerate(["No individual-case adjudication · No merits claim on immigration policy",
                       "No causal claim about WHY FY2026 outflow rose (held VEILED until mechanism decomposition + F-score)",
                       "Volume decline ≠ earned improvement"]):
    o.append(f"<text x='482' y='{545+i*16}' font-size='12' text-anchor='middle' fill='#333'>{t}</text>")
o.append(f"<text x='30' y='{H-12}' font-size='10.5' fill='#666'>ERES-JUSTICE-TREND-2026-001 v0.1 · ERES Institute for New Age Cybernetics · CC BY 4.0</text>")
o.append("</svg>")
open(os.path.join(HERE, "figures", "Figure2_Adjudication_Pipeline.svg"), "w").write("\n".join(o))
print("figures written")
