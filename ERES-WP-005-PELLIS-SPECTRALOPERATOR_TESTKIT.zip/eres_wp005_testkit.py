#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_wp005_testkit.py
=====================
Pre-registered falsifiable test kit for ERES-WP-005-2026 v0.1 (DRAFT).

WHAT THIS CERTIFIES (and what it does NOT):
  CERTIFIES  : the STRUCTURE of the WP-005 primitive mapping -- that a genuinely
               non-Hermitian Pellis-class error operator, whose eigenvalues are
               COMPUTED (not stipulated), reproduces the five Bentley primitives
               (P1-P5) and, crucially, that the spectral protection gap gives a
               PREDICTIVE LEAD over logical-survival collapse (the paper's core
               claim).
  DOES NOT    : establish empirical universality. Everything here is synthetic.
               Per standing ERES rule, SYNTHETIC RESULTS CANNOT CONFIRM OR REFUTE
               the physical claim. This kit keeps WP-005 at its honest sub-9.0
               grade. The 9.0 (Stergios) gate needs the real-hardware correlation
               rho_S = Corr(S_phi, P_logical) from the Pellis paper's own roadmap.

WHY IT AVOIDS THE CLIMATE-BRIDGE BLOCKER:
  The prior climate sim stipulated its spectrum directly (np.linspace) and drifted
  it by a uniform constant, so no operator existed and Delta-lambda was constant by
  construction. Here the spectrum is obtained by numpy.linalg.eig on an actual
  matrix-valued operator L(phi); eigenvalue migration is therefore a computed
  consequence, not an input.

Foundational operator mathematics: Dr. Stergios Pellis (Greece),
Pellis Spectral Operator Theory. ERES supplies the diagnostic-architecture casting.

Deterministic. Dependency: numpy. Seed: 20260804.
Run:  python3 eres_wp005_testkit.py
Exit code 0 iff all pre-registered tests pass.
"""

import hashlib
import sys

import numpy as np

SEED = 20260804

# ---------------------------------------------------------------------------
# Operator construction
# ---------------------------------------------------------------------------
# L(phi) = S  -  i * phi * D
#   S : Hermitian stabilizing part  -> coherent energies E_n = Re(lambda_n)
#   D : positive-semidefinite leakage part, engineered so that as phi grows,
#       two modes migrate toward coalescence (an exceptional point) and the
#       dominant leakage rate Gamma_n = -Im(lambda_n) rises toward a critical
#       threshold Gamma_c.  lambda_n = E_n - i*Gamma_n.
#
# The "machine" here is a small logical-qubit surrogate: eigenvalues are the
# spectral modes of the error operator, exactly as in the Pellis QEC paper.

N = 6                      # spectral modes: 1 EP pair (modes 0,1) + 4 background
GAMMA_C = 1.00             # critical leakage threshold (collapse boundary)
WARN_MARGIN = 0.20         # predictive warning fires when Delta_phi < 0.20*GAMMA_C
FAIL_LEVEL = 0.10          # logical failure := survival probability P_L < 0.10

# Deterministic, physically faithful non-Hermitian construction.
#   Modes 0,1 form a PT-symmetry pair: degenerate coherent energy (0.0), a
#   Hermitian coupling g=0.15, and asymmetric leakage (1.0 vs 0.4). This yields
#   an EXACT exceptional point at phi_EP = 0.5, beyond which the dominant mode's
#   leakage runs away -- i.e. the EP is the onset of logical instability, exactly
#   the "critical spectral migration" of the Pellis QEC paper.
#   Modes 2..5 are well-separated benign background modes.

_G = 0.15                                  # Hermitian coupling in the EP block
_BG_E = np.array([-1.2, -0.9, 0.9, 1.2])   # background coherent energies
_BG_D = np.array([0.10, 0.15, 0.15, 0.20]) # background leakage (all < block)

def build_S():
    S = np.zeros((N, N))
    S[0, 0] = 0.0; S[1, 1] = 0.0           # degenerate energies -> EP pair
    S[0, 1] = S[1, 0] = _G                 # Hermitian coupling
    for k in range(2, N):
        S[k, k] = _BG_E[k - 2]
    return S

def build_D():
    D = np.zeros((N, N))
    D[0, 0] = 1.00; D[1, 1] = 0.40         # asymmetric leakage -> runaway after EP
    for k in range(2, N):
        D[k, k] = _BG_D[k - 2]
    return D                                # diagonal PSD by construction

S = build_S()
D = build_D()


def L(phi):
    return S - 1j * phi * D


def spectrum(phi):
    """COMPUTED eigenvalues of the actual operator (not stipulated)."""
    lam = np.linalg.eigvals(L(phi))
    E = lam.real
    Gamma = -lam.imag                              # leakage rate >= 0 for decay
    return E, Gamma, lam


def protection_gap(phi):
    """Delta_phi = distance of the worst (max-leakage) mode to the collapse boundary."""
    _, Gamma, _ = spectrum(phi)
    return GAMMA_C - float(np.max(Gamma))


def survival_probability(phi, t=1.0):
    """P_L(t) = exp(-Lambda_phi * t), Lambda_phi = sum_n w_n Gamma_n (uniform w)."""
    _, Gamma, _ = spectrum(phi)
    # Logical loss is governed by the DOMINANT (worst) error mode, not the mean:
    # the encoded qubit fails when its fastest-leaking mode runs away.
    Lam = float(np.max(np.clip(Gamma, 0.0, None)))
    return float(np.exp(-Lam * t))


def min_eigenvalue_separation(phi):
    """Smallest pairwise separation in the complex plane -> exceptional-point probe."""
    _, _, lam = spectrum(phi)
    seps = [abs(lam[i] - lam[j]) for i in range(N) for j in range(i + 1, N)]
    return float(min(seps))


# ---------------------------------------------------------------------------
# Noise sweep
# ---------------------------------------------------------------------------
PHIS = np.linspace(0.0, 2.6, 521)
GAP = np.array([protection_gap(p) for p in PHIS])
SURV = np.array([survival_probability(p) for p in PHIS])
SEP = np.array([min_eigenvalue_separation(p) for p in PHIS])


def first_index(mask):
    idx = np.argmax(mask)
    return int(idx) if mask.any() else None


# ---------------------------------------------------------------------------
# Pre-registered tests  (promotion/demotion criteria fixed BEFORE running)
# ---------------------------------------------------------------------------
results = []


def check(name, passed, detail):
    results.append((name, bool(passed), detail))


# T1 (P2 -- baseline). At zero noise the configuration is stable:
#     protection gap positive, survival high.
check("T1 baseline stable (P2)",
      GAP[0] > 0.5 and SURV[0] > 0.7,
      f"gap0={GAP[0]:.3f}, surv0={SURV[0]:.3f}")

# T2 (P1/P3 -- computed migration). Increasing noise monotonically closes the gap.
#     The spectrum is COMPUTED, so a closing gap is a real operator consequence.
diffs = np.diff(GAP)
check("T2 gap closes monotonically under noise (P1/P3)",
      np.all(diffs <= 1e-9) and GAP[-1] < GAP[0],
      f"gap {GAP[0]:.3f} -> {GAP[-1]:.3f}, max step {float(diffs.max()):+.2e}")

# T4 (P3 -- exceptional point). Two modes coalesce: min separation dips sharply,
#     identifying the fault mode (Bentley's 'shape of deviation identifies cause').
check("T4 exceptional-point coalescence (P3)",
      SEP.min() < 0.15 and SEP.min() < 0.5 * SEP[0],
      f"min separation {SEP.min():.4f} at phi={PHIS[int(np.argmin(SEP))]:.3f} (sep0={SEP[0]:.3f})")

# T3 (P4/P5 -- THE LOAD-BEARING CLAIM). The spectral warning must PRECEDE logical
#     failure. If warning has no lead over just watching survival, the framework
#     adds nothing. This test can come out null.
i_warn = first_index(GAP < WARN_MARGIN * GAMMA_C)
i_fail = first_index(SURV < FAIL_LEVEL)
lead = None
if i_warn is not None and i_fail is not None:
    lead = PHIS[i_fail] - PHIS[i_warn]
check("T3 spectral warning leads logical failure (P4/P5) [LOAD-BEARING]",
      (i_warn is not None and i_fail is not None and lead is not None and lead > 0),
      (f"warn@phi={PHIS[i_warn]:.3f}, fail@phi={PHIS[i_fail]:.3f}, lead={lead:+.3f}"
       if lead is not None else "warning or failure never reached -- NULL"))

# T5 (NEGATIVE CONTROL -- guards against a warning that always fires).
#     A benign operator whose leakage saturates below the boundary: gap stays
#     open, warning must NOT fire, survival must NOT collapse.
def benign_gap_and_surv():
    # Benign operator: leakage scaled so the dominant mode stays well below the
    # boundary across the whole sweep -> no true instability, warning must stay silent.
    Db = 0.25 * D / max(float(np.max(np.diag(D))), 1e-9)   # dominant diagonal -> 0.25
    gaps, survs = [], []
    for p in PHIS:
        lam = np.linalg.eigvals(S - 1j * p * Db)
        Gamma = -lam.imag
        gaps.append(GAMMA_C - float(np.max(Gamma)))
        survs.append(float(np.exp(-float(np.max(np.clip(Gamma, 0, None))))))
    return np.array(gaps), np.array(survs)

bgap, bsurv = benign_gap_and_surv()
check("T5 negative control does NOT false-alarm",
      np.all(bgap > WARN_MARGIN * GAMMA_C) and np.all(bsurv > FAIL_LEVEL),
      f"benign min gap {bgap.min():.3f} (>{WARN_MARGIN*GAMMA_C:.2f}), min surv {bsurv.min():.3f}")

# T6 (R-1 invariant -- machine/human consent split). Declared, not computed:
#     this operator is MACHINE-class (qubit), so R-1 is not triggered. A human-
#     signal flag would require the legal-enablement gate before any run.
SIGNAL_CLASS = "machine"          # 'machine' (qubit/shaft) | 'human' (BERA)
R1_SATISFIED = False              # enabling legal layer does not yet exist
check("T6 R-1 machine/human gate honored",
      (SIGNAL_CLASS == "machine") or R1_SATISFIED,
      f"signal_class={SIGNAL_CLASS}, R1_satisfied={R1_SATISFIED} "
      f"(human-signal run would be blocked)")

# T7 (determinism -- reproducibility). Recomputing the sweep is byte-stable.
GAP2 = np.array([protection_gap(p) for p in PHIS])
SURV2 = np.array([survival_probability(p) for p in PHIS])
check("T7 deterministic sweep (reproducible)",
      np.array_equal(GAP2, GAP) and np.array_equal(SURV2, SURV),
      "gap/survival sweep byte-identical on recompute (seed 20260804)")


# ---------------------------------------------------------------------------
# Source self-checksum (integrity)
# ---------------------------------------------------------------------------
def self_sha256():
    try:
        with open(__file__, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except Exception:
        return "unavailable"


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
def main():
    print("=" * 72)
    print("ERES-WP-005-2026 v0.1  --  Pre-registered falsifiable test kit")
    print("Pellis Spectral Operator (QEC) cast into the SCALULAR stack")
    print("Seed:", SEED, "| modes N =", N, "| Gamma_c =", GAMMA_C)
    print("=" * 72)
    n_pass = 0
    for name, passed, detail in results:
        tag = "PASS" if passed else "FAIL"
        if passed:
            n_pass += 1
        print(f"[{tag}] {name}")
        print(f"       {detail}")
    print("-" * 72)
    print(f"{n_pass}/{len(results)} pre-registered tests passed")
    print(f"source SHA-256: {self_sha256()}")
    print("-" * 72)
    print("EPISTEMIC STATUS: synthetic structure certified; empirical universality"
          " NOT established.")
    print("This kit does not move the 9.0 (Stergios) gate. The physical test is"
          " rho_S = Corr(S_phi, P_logical)")
    print("on real hardware (Pellis paper, sec.15/sec.17). Synthetic results"
          " cannot confirm or refute.")
    print("=" * 72)
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
