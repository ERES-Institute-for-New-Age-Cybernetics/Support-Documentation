#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_ennea_rt_testkit_v0_3.py
Pre-registered falsifiable test kit accompanying:

    ERES-S3C-ENNEAGRAM-RT-2026-001 v0.5 DRAFT
    "How the Enneagram Is RECORDED and REFLECTED in RT:
     Run-Time, Real-Time, and Risk-Time"
    Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics
    ORCID: 0000-0001-9946-3221
    Drafting node: Claude (Anthropic), 30 Jul 2026 — single-node provisional; MIEVM pass PENDING.
    License: CCAL v2.1 (CC-BY 4.0 compatible base).

--------------------------------------------------------------------------------
WHAT THIS KIT SHOWS  /  WHAT IT DOES NOT SHOW  (read before scoring)
--------------------------------------------------------------------------------
SHOWS  : internal COHERENCE of the paper's structural claims — that the RT
         three-rung ladder, the RECORDED/REFLECTED/RECONCILE mapping, the
         conjunctive gate (Thm 1 schema), the Lyapunov reconciliation (Thm 3
         schema), and the REAL time-decay behave as the text asserts. A PASS
         means the instrument does not contradict itself.

DOES NOT SHOW : that any claim is TRUE OF THE WORLD. Every test runs on
         constructed inputs. Per the corpus rule "synthetic results cannot
         refute" (mapping instrument §1.1), the corollary holds symmetrically:
         synthetic results cannot CONFIRM. In particular test T10 (the §5
         Pellis bridge) is ILLUSTRATIVE ONLY — a PASS validates the internal
         SHAPE of the analogy on synthetic data and CANNOT promote the §5
         bridge above ANALOGICAL, nor imply Dr. Pellis's endorsement.

A FAIL is a real finding: it means the instrument's own logic is inconsistent
and the paper must be corrected before it can rise above DRAFT.

DESIGN NOTES
  * Standard library only (no numpy) so any MIEVM node can run it unchanged.
  * Eigenvalue-bearing tests use TRIANGULAR operators, whose eigenvalues are
    exactly the diagonal — mathematically exact, no solver needed.
  * All randomness is seeded; every node should get byte-identical results.
  * Sign convention (flagged for Pellis, see T10): this kit reads stability
    through the spectral ABSCISSA a = sup Re(lambda) rising to 0 at collapse,
    consistent with the semiconductor sibling's "lambda_1 up-arrow 0^-". The
    cardiac sibling's V(psi)=inf Re(lambda) is the same object under a sign/
    labeling convention; reconciling the two is logged as an OPEN item, not
    silently chosen.
--------------------------------------------------------------------------------
"""

import math
import random
import json
import datetime

random.seed(20260730)  # deterministic across nodes

# ------------------------------------------------------------------ result type
class R:
    def __init__(self, tid, section, label, passed, detail):
        self.tid, self.section, self.label = tid, section, label
        self.passed, self.detail = passed, detail

def ok(cond):  # tiny helper
    return bool(cond)

# ============================================================ canonical fixtures
# The nine S3C positions as (SG, SM, SC) with Weak/Absent=0, Developing/Nascent=0.5,
# Active=1  (per ERES_S3C_ENNEAGRAMMATICS v0.1 Section II table).
POSITIONS = {
    1: (0.0, 0.0, 0.0),   # Latent
    2: (0.0, 0.5, 0.0),   # Monitoring (surveillance trap sits here)
    3: (0.0, 1.0, 0.5),   # Aware
    4: (0.5, 0.0, 0.0),   # Sovereign
    5: (0.5, 0.5, 0.5),   # Architect
    6: (0.5, 1.0, 0.5),   # Governed
    7: (1.0, 0.0, 0.5),   # Assertive (authority trap sits here)
    8: (1.0, 1.0, 0.5),   # Integrated
    9: (1.0, 1.0, 1.0),   # Solid-State  (the attractor)
}
DOCUMENTED_FAILURE_TRANSITIONS = {(1, 2), (4, 7), (8, 5)}  # Surveillance / Authority / Regression

def ssi(state):
    """Solid-State Index = conjunctive product (Theorem 1 schema)."""
    sg, sm, sc = state
    return sg * sm * sc

def additive(state):
    """The checklist scorer the paper says is WRONG for a conjunctive condition."""
    return sum(state) / 3.0

def vc(state):
    """Conflict-energy V_c >= 0, = 0 iff Solid-State (Theorem 3 schema)."""
    return 1.0 - ssi(state)


# ================================================================= the tests ===

def T1_conjunctive_gate():
    """Thm 1 (PROVED schema): any zeroed dimension closes the gate; additive does not."""
    zeroed = [(0.0, 1.0, 1.0), (1.0, 0.0, 0.3), (1.0, 1.0, 0.0), (0.9, 0.0, 0.9)]
    conj_gates_all = all(ssi(s) == 0.0 for s in zeroed)
    # Position 7 = (1,0,0.5): conjunctive gates it (0); additive scores it "partial" (>0)
    p7 = POSITIONS[7]
    diverge = (ssi(p7) == 0.0) and (additive(p7) > 0.3)
    passed = ok(conj_gates_all and diverge)
    return R("T1", "Section 7.1", "PROVED(schema)", passed,
             "conjunctive gates every zeroed-dim case (%s); Pos7 additive=%.2f vs conj=%.2f"
             % (conj_gates_all, additive(p7), ssi(p7)))

def T2_nine_position_integrity():
    """Position map: 9 is the unique all-Active attractor; 2 and 7 are distinct."""
    all_active = [p for p, s in POSITIONS.items() if s == (1.0, 1.0, 1.0)]
    unique_ss = (all_active == [9])
    ss_is_max = (ssi(POSITIONS[9]) == 1.0 and
                 all(ssi(s) < 1.0 for p, s in POSITIONS.items() if p != 9))
    distinct = len(set(POSITIONS.values())) == 9
    p2_ne_p7 = POSITIONS[2] != POSITIONS[7]
    passed = ok(unique_ss and ss_is_max and distinct and p2_ne_p7)
    return R("T2", "Section 1 / Enn.II", "DESIGN-PRINCIPLE", passed,
             "unique all-Active=Pos%s; SSI-maximal=%s; 9 distinct=%s; 2!=7=%s"
             % (all_active, ss_is_max, distinct, p2_ne_p7))

def T3_recorded_runtime_exactness():
    """RECORDED/Run-Time: a FIXED stored standard classifies with zero drift;
       a RE-DERIVED-each-call standard drifts. (fixed-standard -> exact-classification)"""
    def classify(state, thresholds):
        # band by SSI against ordered thresholds -> stable label
        val = ssi(state)
        for name, lo in thresholds:
            if val >= lo:
                return name
        return "GATED"
    probe = POSITIONS[8]  # SSI = 0.5
    fixed = [("BEST", 0.8), ("SOUND", 0.4), ("GOOD", 0.05)]
    fixed_runs = {classify(probe, fixed) for _ in range(200)}
    fixed_stable = (len(fixed_runs) == 1)
    # re-derived: thresholds jittered live each call (origination under pressure)
    rederived_runs = set()
    for _ in range(200):
        j = [(n, lo + random.uniform(-0.12, 0.12)) for n, lo in fixed]
        j.sort(key=lambda x: -x[1])
        rederived_runs.add(classify(probe, j))
    rederived_drifts = (len(rederived_runs) > 1)
    passed = ok(fixed_stable and rederived_drifts)
    return R("T3", "Section 2", "DESIGN-PRINCIPLE", passed,
             "fixed ruler -> %d label (stable=%s); re-derived ruler -> %d labels (drift=%s)"
             % (len(fixed_runs), fixed_stable, len(rederived_runs), rederived_drifts))

def T4_recorded_honesty_caveat():
    """RECORDED caveat: exactness is invariant to validation-state; ACCURACY is not.
       Lookup vs a wrong PROVISIONAL record is stable-but-wrong; vs CANON stable-and-right."""
    truth = 9  # ground-truth position
    def lookup(record_position, repeats=100):
        outs = {record_position for _ in range(repeats)}  # execution is deterministic
        return outs
    canon_rec, prov_rec = 9, 7  # CANON matches truth; PROVISIONAL is wrong
    canon_exact = (len(lookup(canon_rec)) == 1)
    prov_exact = (len(lookup(prov_rec)) == 1)            # still exact (stable)
    canon_accurate = (canon_rec == truth)
    prov_accurate = (prov_rec == truth)                 # NOT accurate
    # claim: exactness same for both; accuracy tracks validation-state only
    passed = ok(canon_exact and prov_exact and canon_accurate and (not prov_accurate))
    return R("T4", "Section 2", "DESIGN-PRINCIPLE", passed,
             "both records execute exactly (canon=%s prov=%s); accuracy canon=%s prov=%s"
             % (canon_exact, prov_exact, canon_accurate, prov_accurate))

def T5_reflected_realtime_artifact():
    """REFLECTED/Real-Time is artifact-prone: a shallow observable collides Pos2 & Pos7
       ('both look busy/governed'); the full (SG,SM,SC) read separates them."""
    def shallow(state):  # 'busy/governed' = high on EITHER a dashboard or authority axis
        sg, sm, sc = state
        return 1 if (sm >= 0.5 or sg >= 1.0) else 0
    naive_collides = (shallow(POSITIONS[2]) == shallow(POSITIONS[7]) == 1)
    disciplined_separates = (POSITIONS[2] != POSITIONS[7])
    passed = ok(naive_collides and disciplined_separates)
    return R("T5", "Section 3", "DESIGN-PRINCIPLE", passed,
             "shallow read: Pos2=%d Pos7=%d (collide=%s); full read separates=%s"
             % (shallow(POSITIONS[2]), shallow(POSITIONS[7]), naive_collides, disciplined_separates))

def T6_risktime_symptom_patching():
    """RISK-TIME + Corollary 3.1: on a trap trajectory an OBSERVABLE improves while the
       true (conjunctive) conflict-energy V_c does NOT decrease (symptom-patching).
       AMENDED during authoring: an earlier draft measured an L1 distance-to-target, which
       FELL on this drift because SG/SC rose -- the exact additive artifact T1 warns of.
       The faithful measure is the conjunctive V_c=1-SSI the paper names in Section 7.2:
       with SM pinned at 0 through the drift, SSI stays 0 and V_c stays 1.0 while the
       authority observable climbs. The falling L1 gap is retained as the demonstrated
       artifact; the flat V_c is the true signal."""
    # Authority-trap drift 4->7: SG (authority) rises, SM stays 0 throughout
    traj = [(0.5, 0.0, 0.0), (0.7, 0.0, 0.2), (0.9, 0.0, 0.3), (1.0, 0.0, 0.5)]
    observable = [s[0] for s in traj]                 # authority axis (flattering metric)
    vc_series = [vc(s) for s in traj]                 # conjunctive conflict-energy (true state)
    recorded = POSITIONS[9]
    l1_series = [sum(abs(a - b) for a, b in zip(recorded, s)) for s in traj]  # additive artifact
    obs_rises = all(x <= y for x, y in zip(observable, observable[1:])) and observable[-1] > observable[0]
    vc_not_falling = vc_series[-1] >= vc_series[0] - 1e-9          # true state does not improve
    l1_artifact_falls = l1_series[-1] < l1_series[0] - 1e-9        # additive read misleads
    passed = ok(obs_rises and vc_not_falling and l1_artifact_falls)
    return R("T6", "Section 4", "DESIGN-PRINCIPLE", passed,
             "observable %.2f->%.2f rises=%s; V_c %.2f->%.2f not-improved=%s; L1 artifact falls %.2f->%.2f=%s"
             % (observable[0], observable[-1], obs_rises, vc_series[0], vc_series[-1], vc_not_falling,
                l1_series[0], l1_series[-1], l1_artifact_falls))

def T7_lyapunov_reconciliation():
    """Thm 3 schema: V_c>=0 and =0 iff Solid-State; a valid control law makes dV_c/dt<0
       monotonically to 0; the 8->5 regression LOSES the dissipation condition (V_c rises)."""
    vc_nonneg = all(vc(s) >= 0.0 for s in POSITIONS.values())
    vc_zero_iff_ss = (vc(POSITIONS[9]) == 0.0 and all(vc(s) > 0.0 for p, s in POSITIONS.items() if p != 9))
    # control law: step every deficient dimension toward Active
    def control_step(state):
        return tuple(min(1.0, x + 0.25) for x in state)
    s = POSITIONS[5]
    series = [vc(s)]
    for _ in range(6):
        s = control_step(s); series.append(vc(s))
    monotone_down = all(a >= b - 1e-12 for a, b in zip(series, series[1:])) and series[-1] <= 1e-9
    # regression 8 -> 5 : V_c must INCREASE (dissipation lost)
    regression_rises = vc(POSITIONS[5]) > vc(POSITIONS[8])
    passed = ok(vc_nonneg and vc_zero_iff_ss and monotone_down and regression_rises)
    return R("T7", "Section 7.2", "PROVED(schema)", passed,
             "V_c>=0=%s; zero-iff-SS=%s; control V_c %.2f->%.2f monotone=%s; regr rises=%s"
             % (vc_nonneg, vc_zero_iff_ss, series[0], series[-1], monotone_down, regression_rises))

def T8_real_time_decay_cadence():
    """Section 7.3: REAL=(E*M*R)/(T*S). Certification decays monotonically as T (time since
       re-validation) grows; re-validation (T->T0) restores it. Risk-Time cadence."""
    E = M = Rr = 1.0; S = 1.0; T0 = 1.0
    def REAL(T): return (E * M * Rr) / (T * S)
    Ts = [T0 * k for k in (1, 2, 4, 8, 16)]
    vals = [REAL(T) for T in Ts]
    monotone_decay = all(a > b for a, b in zip(vals, vals[1:]))
    restored = abs(REAL(T0) - vals[0]) < 1e-12       # re-validation resets to the peak
    passed = ok(monotone_decay and restored)
    return R("T8", "Section 7.3", "DESIGN-PRINCIPLE", passed,
             "REAL over T=%s -> %s (decay=%s); re-validation restores=%s"
             % (Ts, [round(v, 3) for v in vals], monotone_decay, restored))

def T9_rt_nondegeneracy_and_CAn():
    """Section 1: RTM = RealTime*RiskTime + RunTime is non-compensating (no rung redundant);
       CA_n is a half-life on capacity-to-act (halves each CA_n; missing k half-lives -> 0.5^k)."""
    def RTM(rt, risk, run): return rt * risk + run
    base = RTM(0.7, 0.6, 0.5)
    # dropping any single rung to its identity must change the output for these inputs
    drop_realtime = RTM(1.0, 0.6, 0.5)     # rt -> 1 (no scaling by world-clock)
    drop_risktime = RTM(0.7, 1.0, 0.5)     # risk -> 1
    drop_runtime = RTM(0.7, 0.6, 0.0)      # run -> 0 (offset removed)
    non_degenerate = (drop_realtime != base) and (drop_risktime != base) and (drop_runtime != base)
    # CA_n half-life semantics
    CA_n = 3.0
    def capacity(t, C0=1.0): return C0 * 0.5 ** (t / CA_n)
    halves = abs(capacity(CA_n) - 0.5) < 1e-12
    two_halflives = abs(capacity(2 * CA_n) - 0.25) < 1e-12
    reconcile_in_window = capacity(CA_n * 0.9) > 0.5   # act before one half-life -> keep >50%
    passed = ok(non_degenerate and halves and two_halflives and reconcile_in_window)
    return R("T9", "Section 1", "DESIGN-PRINCIPLE", passed,
             "non-degenerate=%s; CA_n halves=%s; 2*CA_n->0.25=%s; in-window keeps>50%%=%s"
             % (non_degenerate, halves, two_halflives, reconcile_in_window))

def T10_pellis_bridge_ILLUSTRATIVE():
    """Section 5 — ANALOGICAL, SYNTHETIC, NON-CONFIRMING.
       On a constructed non-normal operator L(t) whose spectral abscissa a(t)=sup Re(lambda)
       rises toward 0 at t_c: (a) penumbra = a<0 pre-collapse, a(t_c)=0 on M_c;
       (b) critical scaling |a(t)| ~ (t_c - t)^nu recovers t_c from PRE-critical points only;
       (c) non-normal part K != 0 => sigma_EP proxy > 0.
       PASS validates only the internal shape; it CANNOT move Section 5 off ANALOGICAL."""
    A, nu_true, t_c = 0.1, 0.5, 10.0
    k_off = 0.4  # off-diagonal -> non-normality (the K part)

    def L(t):
        # upper-triangular 2x2 -> eigenvalues are the diagonal (exact, no solver)
        lam_top = -A * (t_c - t) ** nu_true   # rises toward 0 as t -> t_c
        lam_stable = -1.0
        return [[lam_top, k_off], [0.0, lam_stable]]

    def abscissa(t):
        M = L(t)
        return max(M[0][0], M[1][1])           # sup Re(lambda) for triangular = max diagonal

    def sigma_EP_proxy(t):
        M = L(t)                                # ||antisymmetric part||, K = (M - M^T)/2
        k01 = 0.5 * (M[0][1] - M[1][0])
        return abs(k01) * 2                     # Frobenius of the 2x2 antisymmetric block

    ts = [float(t) for t in range(0, 9)]        # PRE-critical only (t < t_c)
    a_vals = [abscissa(t) for t in ts]
    penumbra = all(a < 0 for a in a_vals) and all(x <= y + 1e-12 for x, y in zip(a_vals, a_vals[1:]))
    on_Mc = abs(abscissa(t_c)) < 1e-9           # a(t_c) = 0  -> critical manifold reached
    Knonzero = sigma_EP_proxy(0.0) > 0.0

    # recover (nu, t_c) by scanning t_c_guess, linear-regressing ln|a| on ln(t_c_guess - t)
    def linreg(xs, ys):
        n = len(xs); mx = sum(xs) / n; my = sum(ys) / n
        sxx = sum((x - mx) ** 2 for x in xs); sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
        b = sxy / sxx; a0 = my - b * mx
        ss_res = sum((y - (a0 + b * x)) ** 2 for x, y in zip(xs, ys))
        ss_tot = sum((y - my) ** 2 for y in ys)
        r2 = 1.0 - (ss_res / ss_tot if ss_tot > 0 else 0.0)
        return b, r2
    best = (None, -1.0, None)  # (t_c_guess, r2, slope)
    g = 9.05
    while g <= 11.0:
        xs = [math.log(g - t) for t in ts]
        ys = [math.log(abs(a)) for a in a_vals]
        slope, r2 = linreg(xs, ys)
        if r2 > best[1]:
            best = (g, r2, slope)
        g += 0.05
    tc_recovered, r2, nu_recovered = best
    tc_close = abs(tc_recovered - t_c) <= 0.2
    nu_close = abs(nu_recovered - nu_true) <= 0.05

    passed = ok(penumbra and on_Mc and Knonzero and tc_close and nu_close)
    return R("T10", "Section 5", "ANALOGICAL(synthetic; non-confirming)", passed,
             "penumbra a<0 rising=%s; M_c a(t_c)=0=%s; K!=0=%s; recovered t_c=%.2f (nu=%.3f, R2=%.4f)"
             % (penumbra, on_Mc, Knonzero, tc_recovered, nu_recovered, r2))

def T11_label_gate_hygiene():
    """Discipline guard: Section 5 stays ANALOGICAL; no DERIVED claim rides a synthetic test;
       the 9.0 Stergios gate is recorded NOT MET; PENDING items are declared."""
    claim_labels = {
        "S5_pellis_bridge": "ANALOGICAL",
        "Vc_as_gap_identification": "PENDING",   # Section 7.2, awaits MIEVM
        "rt_ladder": "DESIGN-PRINCIPLE",
        "conjunctive_gate": "PROVED(schema)",
    }
    s5_analogical = (claim_labels["S5_pellis_bridge"] == "ANALOGICAL")
    no_derived_on_synthetic = ("DERIVED" not in claim_labels.values())
    stergios_gate_met = False                    # instrument self-declares below 9.0
    pending_declared = ("PENDING" in claim_labels.values())
    passed = ok(s5_analogical and no_derived_on_synthetic and (not stergios_gate_met) and pending_declared)
    return R("T11", "Legend / Section 8", "DISCIPLINE", passed,
             "S5=ANALOGICAL=%s; no DERIVED-on-synthetic=%s; 9.0 gate met=%s; PENDING declared=%s"
             % (s5_analogical, no_derived_on_synthetic, stergios_gate_met, pending_declared))


def T12_user_group_application():
    """Section 6 (User-Group Application): a COI is a DISTRIBUTION of typed members across
       CBGMODD roles, not a scalar. Checks: (a) the group's REFLECTED posture is composed
       from member contributions and can diverge from the RECORDED group position (group-scale
       gap); (b) conjunctive distribution-gate -- if the WHOLE membership is missing a
       dimension, the aggregate is gated regardless of the other two; (c) reconciliation is
       type-indexed (the move register is non-constant across types); (d) membership 369-circuit
       orthogonality -- a diverse membership spans all three circuits, a collapsed one spans one."""
    # member = (enneagram_type, cbgmodd_role, contribution (sg,sm,sc))
    members = [
        (1, "Citizen",    (0.6, 0.3, 0.2)),
        (5, "Business",   (0.4, 0.5, 0.3)),
        (8, "Government", (0.9, 0.4, 0.5)),
        (2, "Ombudsmen",  (0.5, 0.6, 0.4)),
        (9, "Dignitary",  (0.5, 0.5, 0.5)),
    ]
    def compose(ms):  # group REFLECTED posture = element-wise mean of member contributions
        n = len(ms)
        return tuple(sum(m[2][k] for m in ms) / n for k in range(3))
    reflected = compose(members)
    recorded = POSITIONS[9]  # the group CLAIMS Solid-State
    group_gap = sum(abs(a - b) for a, b in zip(recorded, reflected))
    gap_nonzero = group_gap > 1e-9                                   # (a)

    # (b) whole membership missing SM -> aggregate sm=0 -> conjunctive gate closes
    missing_sm = [(t, r, (sg, 0.0, sc)) for (t, r, (sg, _, sc)) in members]
    gated = (ssi(compose(missing_sm)) == 0.0)

    # (c) type-indexed reconciliation register (PlayNAC per-type move, ENNEAGRAMMATICS Sec.III)
    register = {5: "depth/data", 7: "breadth/possibility", 2: "relational", 8: "challenge",
                1: "principle", 9: "mediation"}
    used = {register.get(m[0], "other") for m in members}
    type_indexed = (len(used) > 1)                                  # non-uniform across membership

    # (d) 369-circuit coverage
    circuits = {"Manifestation": {3, 6, 9}, "Liberation": {1, 4, 7}, "Power": {2, 5, 8}}
    def coverage(ms):
        types = {m[0] for m in ms}
        return sum(1 for c in circuits.values() if types & c)
    diverse_cov = coverage(members)                                 # spans all 3 here
    collapsed = [(2, "x", (0.9, 0.1, 0.1)), (5, "x", (0.9, 0.1, 0.1)), (8, "x", (0.9, 0.1, 0.1))]
    collapsed_cov = coverage(collapsed)                             # Power-only -> 1
    orthogonality_detects = (diverse_cov >= 3 and collapsed_cov == 1)

    passed = ok(gap_nonzero and gated and type_indexed and orthogonality_detects)
    return R("T12", "Section 6", "DESIGN-PRINCIPLE", passed,
             "group gap=%.2f (nonzero=%s); all-missing-SM gated=%s; type-indexed registers=%d (>1=%s); "
             "circuit coverage diverse=%d collapsed=%d (detects=%s)"
             % (group_gap, gap_nonzero, gated, len(used), type_indexed,
                diverse_cov, collapsed_cov, orthogonality_detects))


# ==================================================================== runner ===
TESTS = [T1_conjunctive_gate, T2_nine_position_integrity, T3_recorded_runtime_exactness,
         T4_recorded_honesty_caveat, T5_reflected_realtime_artifact, T6_risktime_symptom_patching,
         T7_lyapunov_reconciliation, T8_real_time_decay_cadence, T9_rt_nondegeneracy_and_CAn,
         T10_pellis_bridge_ILLUSTRATIVE, T11_label_gate_hygiene, T12_user_group_application]

def run():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines = []
    def out(s):
        print(s); lines.append(s)

    out("=" * 78)
    out("ERES-S3C-ENNEAGRAM-RT-2026-001 v0.2  —  Accompanying Test Kit")
    out("Run (UTC): %s   |   seed: 20260730   |   stdlib-only" % stamp)
    out("Coherence checks on constructed inputs. PASS = self-consistent, NOT world-true.")
    out("T10 (Section 5) is synthetic & NON-CONFIRMING: a PASS cannot move the")
    out("Pellis bridge off ANALOGICAL. A FAIL anywhere = an instrument defect to fix.")
    out("=" * 78)
    out("%-5s %-20s %-34s %-4s" % ("ID", "SECTION", "CLAIM LABEL", "RES"))
    out("-" * 78)

    results = [t() for t in TESTS]
    for r in results:
        out("%-5s %-20s %-34s %-4s" % (r.tid, r.section, r.label, "PASS" if r.passed else "FAIL"))
        out("        %s" % r.detail)
    out("-" * 78)

    npass = sum(1 for r in results if r.passed)
    n = len(results)
    out("RESULT: %d/%d PASS" % (npass, n))
    out("Structural tests (T1-T9, T11-T12): %d/%d PASS  |  Illustrative (T10): %s"
        % (sum(1 for r in results if r.tid != "T10" and r.passed),
           n - 1, "PASS" if results[9].passed else "FAIL"))
    out("")
    out("MIEVM NODE INSTRUCTIONS:")
    out("  1. Confirm the kit runs unmodified and reproduces this table.")
    out("  2. Score whether each test faithfully operationalizes its paper section")
    out("     (a passing test that tests the WRONG thing is a defect — flag it).")
    out("  3. T10: verify it is treated as non-confirming; challenge any place the")
    out("     paper leans on it as evidence rather than illustration.")
    out("  4. Report: does anything here justify a status above DRAFT / below 9.0?")
    out("=" * 78)

    record = {
        "instrument": "ERES-S3C-ENNEAGRAM-RT-2026-001",
        "version": "v0.5-kit-v0.3",
        "run_utc": stamp, "seed": 20260730,
        "pass": npass, "total": n,
        "results": [{"id": r.tid, "section": r.section, "label": r.label,
                     "passed": r.passed, "detail": r.detail} for r in results],
        "note": "Coherence kit. Synthetic inputs. T10 non-confirming (ANALOGICAL). "
                "9.0 Stergios gate NOT claimed met."
    }
    with open("eres_ennea_rt_testkit_RUN.txt", "w") as f:
        f.write("\n".join(lines) + "\n\n--- MACHINE RECORD ---\n" + json.dumps(record, indent=2) + "\n")
    return npass, n

if __name__ == "__main__":
    run()
