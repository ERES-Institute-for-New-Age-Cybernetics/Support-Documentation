"""Testkit for ERES-HYP-IDLOSS-TEST-2026-001. Run: python test_eres_idloss.py
Checks that estimators recover known values and that decision rules,
Holm correction and controls behave as pre-registered."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import eres_idloss_test as E

rng = np.random.default_rng(7)
PASS = []


def check(name, cond):
    PASS.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name)


# estimators
t, hr = E.hr_trace(40.0, rng, noise=0.5)
check("tau_single recovers 40 s within 10%", abs(E.tau_single(t, hr) - 40) < 4)
x = np.zeros(4000)
for i in range(1, 4000):
    x[i] = 0.9 * x[i - 1] + rng.normal()
check("tau0_autocorr near AR(1) value 9.5 within 30%", abs(E.tau0_autocorr(x) - 9.5) < 2.9)
pat = np.vstack([rng.normal(m, 0.1, (20, 30)) for m in (np.zeros(30), np.ones(30) * np.linspace(-1, 1, 30))])
lab = np.repeat([0, 1], 20)
check("distinctiveness high for distinct categories", E.distinctiveness(pat, lab) > 0.5)
check("tot_rate", E.tot_rate(3, 7) == 0.3)
check("pct_hear", E.pct_hear([1, 0, 1, 1]) == 0.75)
check("srt_from_track", E.srt_from_track(np.r_[np.zeros(5), -8 * np.ones(10)]) == -8)
dt = 0.1; T = np.arange(0, 60, dt)
sig = np.exp(-T / 6) * np.cos(2 * np.pi * 0.12 * T)
check("tau_multimode recovers 6 s within 10% (clean)", abs(E.tau_multimode(sig, dt, oscillatory_only=True) - 6) < 0.6)

# rules
check("classify confirm +", E.classify(0.1, 0.3, "+") == "confirmed")
check("classify refute +", E.classify(-0.3, -0.1, "+") == "refuted")
check("classify inconclusive", E.classify(-0.1, 0.1, "+") == "inconclusive")
check("classify confirm -", E.classify(-0.3, -0.1, "-") == "confirmed")
h = E.holm({"a": 0.01, "b": 0.02, "c": 0.04})
check("holm step-down: 0.01, 0.02, 0.04 all pass", h == {"a": True, "b": True, "c": True})
h2 = E.holm({"a": 0.01, "b": 0.03, "c": 0.04})
check("holm stops at first failure", h2 == {"a": True, "b": False, "c": False})
r, lo, hi, p, n = E.partial_r(np.arange(100.0), np.arange(100.0) + rng.normal(0, 1, 100))
check("partial_r near 1", r > 0.99 and lo < r < hi)

# controls
check("positive control passes", E.positive_control(np.random.default_rng(1)))
check("negative control confirm rate <= 0.1", E.negative_control(np.random.default_rng(2), reps=40) <= 0.1)

# noise-control tests (v0.2)
d15 = E.world_P15(np.random.default_rng(3), True, n=20000)
check("P15 confirms night > day in effect world", E.test_P15(**d15, n_boot=200).outcome == "confirmed")
d16 = E.world_P16(np.random.default_rng(4), True)
check("P16 confirms noise-change effect", E.test_P16(**d16).outcome == "confirmed")
d16n = E.world_P16(np.random.default_rng(5), False)
check("P16 not confirmed in null world", E.test_P16(**d16n).outcome != "confirmed")

# frozen rules
check("rules hash is 64 hex chars", len(E.rules_hash()) == 64)

print(f"\n{sum(PASS)}/{len(PASS)} checks passed")
raise SystemExit(0 if all(PASS) else 1)
