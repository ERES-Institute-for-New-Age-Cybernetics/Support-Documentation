# SEO Note for Package Submission

**Package:** ERES-HYP-IDLOSS-TEST-2026-001_v0.2_Complete-Package.zip
**For:** Zenodo deposit, ResearchGate project and LinkedIn announcement
**Status:** ready to post once the deposit is approved

## Before posting

- **Attribution check.** The package cites Stergios Pellis's spectral methods and implements his multiscale construction in ERES code. Under your standing Track-B practice, confirm his attribution wording before public deposit.
- **Placeholders to fill after deposit:** `[ZENODO DOI — PENDING]` and `[RESEARCHGATE LINK — PENDING]` in the Synopsis.
- **Privacy.** The package contains no personal data: all results are synthetic.

## Title (primary, 96 characters)

What Noise Tells Us About Our Environment: Tinnitus as an Environmental Sentinel and the Case for Noise Control

## Short title (for social and RG project name)

Tinnitus as an Environmental Sentinel: A Pre-Registered Test Package

## Subtitle

A falsifiable ERES hypothesis, a SEPLTA H&E analysis of noise control, and a calibrated test harness ready for UK Biobank data

## Abstract (Zenodo / ResearchGate, 214 words)

Noise is a measurement of the environment that is already taken everywhere, and the human ear keeps its own record of it. Tinnitus, which affects about 14% of adults worldwide, stores the cumulative noise dose a body has lived through. This package presents a pre-registered hypothesis that reads the tinnitus ring in two directions: as a marker of the body's loss of resilience with age, and as a sentinel of environmental conditions. It defines the data-reach of noise across human activity, wildlife, ecosystems, population health and personal exposure history, and analyses the need for noise control across six domains (Social, Economic, Political, Legal, Technical, Administrative) with their history and present environment, including the July 2026 US court ruling on the Noise Control Act and Europe's off-track 2030 noise target. Sixteen predictions are specified with confirm, refute and inconclusive rules, including two new noise-control tests: night-time noise should predict tinnitus more strongly than daytime noise, and falling noise should be followed by falling tinnitus. A Python test harness implements every rule and is calibrated on synthetic data, where primary tests confirm built-in effects reliably and rarely confirm on null data. No result is yet evidence about people. The first real tests need only UK Biobank's tinnitus and residential-noise records.

## Keywords (comma-delimited)

environmental noise, noise pollution, tinnitus, environmental sentinel, noise control, night-time noise, public health, UK Biobank, WHO noise guidelines, Noise Control Act, Environmental Noise Directive, hearing in noise, heart rate recovery, aging, resilience, pre-registration, falsifiable hypothesis, test harness, SEPLTA, ERES Institute

## Zenodo metadata

| Field | Value |
| --- | --- |
| Resource type | Publication / Working paper (primary); Software (harness, as a related item) |
| Version | v0.8 hypothesis; v0.2 test instrument |
| License | Creative Commons Attribution 4.0 International |
| Creators | Sprute, Joseph Allen (ERES Institute for New Age Cybernetics; ORCID 0000-0001-9946-3221) |
| Contributors | Pellis, Stergios (methods source; ORCID 0000-0002-7363-8254), pending his confirmation |
| Subjects | Environmental health; Acoustics; Audiology; Epidemiology; Public policy |
| Related identifiers | Earlier ERES-PELLIS deposits (add DOIs); WHO 2018 guidelines; EEA Report 05/2025 |
| Language | English |

## ResearchGate

- **Publication type:** Preprint (main), with the harness as supplementary data.
- **Topics to tag:** Environmental Health, Noise Pollution, Tinnitus, Epidemiology, Public Health Policy, Acoustics.
- **Project description (one line):** Testing whether the tinnitus ring can report on, and justify control of, the noise environment people live in.

## LinkedIn post (about 120 words)

Noise is data. The ring in our ears may be the most personal noise map there is.

New from the ERES Institute: a pre-registered hypothesis and test package asking what tinnitus can tell medicine about the environment we live in, and why noise control is overdue.

What's inside:
- What noise reports about human activity, wildlife, ecosystems and health
- A SEPLTA H&E analysis of noise control, including the July 2026 US court ruling on the Noise Control Act
- 16 predictions with confirm/refute rules, including "night noise matters more than day noise"
- A calibrated Python harness, ready for UK Biobank data

No results about people yet; the test comes first.

[ZENODO DOI — PENDING]

#NoisePollution #Tinnitus #EnvironmentalHealth #PublicHealth #OpenScience #ERESInstitute

## Figure alt text

**Figure 1 (fig1_noise_data_reach_loop.svg):** Six-step loop. Environmental noise from roads, rail, aircraft, rockets and conflict reaches the body; the tinnitus ring records the dose; noise maps and health data are joined; predictions P12 to P16 test the link; SEPLTA noise control lowers noise; a guard ensures control reduces total exposure rather than moving it.

**Figure 2 (fig2_calibration.svg):** Bar chart of each prediction's power (confirm rate when the effect is real) beside its false-confirm rate on null data, from the synthetic calibration.
