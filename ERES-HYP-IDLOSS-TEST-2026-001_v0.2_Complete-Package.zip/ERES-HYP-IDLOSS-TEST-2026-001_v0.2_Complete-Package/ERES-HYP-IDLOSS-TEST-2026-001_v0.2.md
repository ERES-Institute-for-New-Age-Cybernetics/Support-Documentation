# ERES-HYP-IDLOSS-TEST-2026-001 v0.2

## Test Instrument for the Identifiability Loss and Recovery Hypothesis

**Version:** v0.2 · **Date:** 1 November 2026 · **Target:** ERES-HYP-IDLOSS-2026-001 v0.8  
**Author:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, ORCID 0000-0001-9946-3221  
**Spectral methods:** Stergios Pellis, ORCID 0000-0002-7363-8254 (the multiscale estimator is an ERES implementation of his construction, not his code)  
**Drafting assistance:** Claude (Anthropic) · **License:** CC-BY 4.0

---

## 1. Purpose

This instrument turns every prediction in v0.8 into a test that runs. v0.2 adds the two noise-control tests of H4: P15 (night-time noise predicts tinnitus more strongly than daytime noise) and P16 (change in residential noise predicts change in tinnitus). It applies each pre-registered decision rule exactly as written, then proves on synthetic data that each test confirms when the effect is real and stays quiet when it is not. It certifies the test, not the hypothesis: no result in this document is evidence about people.

**Status:** harness built and calibrated; 20 unit checks pass; ready for Stage A data.

<figure><img src="fig2_calibration.svg" alt="Calibration: power and false-confirm rate per prediction"><figcaption>Figure 2. Calibration on synthetic data: power (confirmed when the effect is real) and false-confirm rate (confirmed on null data) for every prediction with a true/null pair.</figcaption></figure>

## 2. What the instrument contains

| Component | What it does |
| --- | --- |
| Estimators | Turn raw measurements into the hypothesis quantities: τ from heart-rate recovery (single smooth decay for UK Biobank's 60 s window), τ from longer traces (Pellis-style multiscale operator, golden or baseline weights), τ₀ from resting signal (integrated autocorrelation time), %Hear and SRT from digits-in-noise, distinctiveness, tip-of-the-tongue rate |
| Decision rules | One function per prediction (P1–P16), returning confirmed, refuted or inconclusive by the v0.8 rule, with estimate, 95% interval, p-value and N |
| Holm correction | Applied across the H1 family (P1, P2, P3, P7, P10) and the H3/H4 family (P12, P13, P14, P15, P16); a result that fails Holm is downgraded to inconclusive |
| Synthetic worlds | For each prediction, a "hypothesis-true" world with the effect built in at a realistic size, and a "null" world without it |
| Controls | Positive control: tip-of-the-tongue rate must rise with age. Negative control: shuffled subject labels must return null |
| Frozen rules | The rule set is hashed (SHA-256) and printed in every report, so any later change to a rule is visible |
| CSV adapters | Run a prediction from a data export with documented columns; UK Biobank field map included |

## 3. Decision rules as implemented

| # | Role | Test statistic | Confirmed | Refuted | Otherwise |
| --- | --- | --- | --- | --- | --- |
| P1 | Primary | Slope of τ on age | CI > 0 | CI < 0 | Inconclusive |
| P2 | Primary | Partial r(τ₀, distinctiveness \| age) | CI < 0 | CI > 0 | Inconclusive |
| P3 | Primary | Partial r(τ₀, TOT rate \| age) | CI > 0 | CI < 0 | Inconclusive |
| P7 | Primary | Partial r(τ, %Hear \| age, self-reported hearing) and slope of Δ%Hear on Δτ | Both confirm | Either refutes | Inconclusive; longitudinal part exploratory if n < 1,000 |
| P10 | Primary | Arm effect on Δτ, then outcome change per unit −Δτ | Both confirm | τ falls but outcomes do not follow | Inconclusive |
| P4 | Exploratory | Golden minus each baseline, median relative τ error (paired bootstrap) | Golden better than every baseline | Golden worse than one | Inconclusive |
| P5 | Secondary | Synchrony excess and attention-load effect | Both CIs > 0 | Either absent at N ≥ 100 | Inconclusive |
| P6 | Exploratory | Listener agreement on replayed facsimiles vs shuffled-item null | p < 0.05 | Not significant | n/a |
| P8 | Exploratory | (a) prevalence difference; (b) own account beats decoys, permutation test | Both confirm | Neither confirms | Inconclusive |
| P9 | Secondary | Silence loudness, pitch-tuned masking, residual inhibition | All three CIs > 0 | Any absent at N ≥ 100 | Inconclusive |
| P11 | Secondary | Held-out R² of τ from voice features vs shuffled labels | p < 0.05 | Not significant | n/a |
| P12 | Secondary | Change in tinnitus probability per dB of residential noise, controlled | CI > 0 | No trend | n/a (sample is large) |
| P13 | Secondary | Held-out accuracy of exposure category from facsimile pitch and type vs shuffled labels | p < 0.05 | Not significant | n/a |
| P14 | Secondary | Held-out R² gain from adding area tinnitus burden to a baseline noise model | CI > 0 | No added value | n/a |
| P15 | Secondary | Night minus day standardised coefficient on tinnitus, one model, P12 controls, bootstrap CI | CI > 0 | CI < 0 | Inconclusive |
| P16 | Secondary | Slope of tinnitus change on residential-noise change between visits | CI > 0 | CI < 0 | Inconclusive |

## 4. Calibration results

Seed 20261101, α = 0.05, 370.8 s. Rules hash `74439f62144f96ce92794022303878d6816d948a7aa0583fd1ae1551455d2643`.

Positive control: **passed**. Negative control (shuffled labels): confirm rate **0.06**, which should be near 0.025.

| # | Role | Runs | Power: confirmed when true | False confirm on null | Refuted when true | Null classed refuted |
| --- | --- | --- | --- | --- | --- | --- |
| P1 | Primary | 20 | 1.00 | 0.00 | 0.00 | 0.00 |
| P2 | Primary | 100 | 0.84 | 0.02 | 0.00 | 0.03 |
| P3 | Primary | 100 | 0.87 | 0.01 | 0.00 | 0.03 |
| P7 | Primary | 100 | 1.00 | 0.00 | 0.00 | 0.05 |
| P10 | Primary | 100 | 1.00 | 0.02 | 0.00 | 0.98 |
| P5 | Secondary | 100 | 0.71 | 0.00 | 0.02 | 0.93 |
| P9 | Secondary | 100 | 1.00 | 0.00 | 0.00 | 1.00 |
| P6 | Exploratory | 40 | 1.00 | 0.00 | 0.00 | 1.00 |
| P8 | Exploratory | 40 | 0.88 | 0.00 | 0.00 | 0.95 |
| P11 | Secondary | 20 | 1.00 | 0.10 | 0.00 | 0.90 |
| P12 | Secondary | 100 | 1.00 | 0.02 | 0.00 | 0.98 |
| P13 | Secondary | 20 | 0.95 | 0.00 | 0.05 | 1.00 |
| P14 | Secondary | 40 | 1.00 | 0.00 | 0.00 | 1.00 |
| P15 | Secondary | 40 | 0.28 | 0.00 | 0.00 | 0.00 |
| P16 | Secondary | 100 | 1.00 | 0.05 | 0.00 | 0.01 |

**Reading the table.** "Power" is how often the test finds an effect that is really there. "False confirm on null" is how often it claims an effect that is not there, and should sit near 0.025 for two-sided tests. "Null classed refuted" is high by design where v0.8 says absence refutes (P5, P9, P10, P12, P14 and the permutation tests), and low where v0.8 says absence is only inconclusive (P1, P2, P3, P7, P15, P16).

**P4 benchmark (golden weighting).** P4 has no true/null pair: it asks whether golden weighting beats uniform, 2⁻ᵏ and single-scale weighting on realistic two-mode traces at 5 dB. Across 10 runs golden was confirmed better in 0%, worse than at least one baseline in 10%, and indistinguishable in 90%. Mean margin -0.0013 (positive = golden better). This repeats the hypothesis's earlier synthetic dry run: no golden advantage.

## 5. What calibration showed

- **Primary tests are sound.** Power across P1, P2, P3, P7 and P10 ranges from 0.84 to 1.00; false confirmations on null data range from 0.00 to 0.02.
- **P15 needs UK Biobank's full sample.** Night and day noise at one address are highly correlated, so telling them apart takes many people. At 20,000 simulated people P15 confirmed the built-in night effect in only 28% of runs (false-confirm 0.00). A follow-up power check (p15_power_by_n.json, 12 runs per size, so rough) gave 20,000 people: 0.42, 60,000 people: 0.75, 120,000 people: 0.83, 200,000 people: 1.00. UK Biobank asked the tinnitus question of 172,385 people at baseline (field 4803), which is above the roughly 120,000 needed.
- **P16 works at 1,500 movers:** power 1.00, false-confirm 0.05.
- **Cam-CAN is adequate but not generous.** P2 and P3 confirm a built-in r = 0.11 in 84% and 87% of runs at N = 656.
- **Under-powered at planned size:** P5 (0.71), P15 (0.28).
- **False-confirm above 0.05:** P11 (0.10). These used few permutations in calibration; on real data pass n_perm=2000 or more.
- **Golden weighting (P4) shows no advantage.**
- **Controls:** positive control passed; negative-control confirm rate 0.06 over 50 runs (expected about 0.025). Before Stage A, rerun with negative_control(rng, reps=1000).

## 6. Running it on real data

1. Freeze: record the rules hash and harness hash in the OSF pre-registration before data access.
2. Export each dataset to CSV with the columns below, or call the `test_Pn()` functions from Python with arrays.
3. Run `python eres_idloss_test.py run P12 ukb_p12.csv` (and likewise for each prediction).
4. Apply Holm across each family with `apply_holm()`, then publish every verdict, including refuted and inconclusive ones.

| # | CSV columns |
| --- | --- |
| P1 | age, tau |
| P2 | tau0, distinct, age |
| P3 | tau0, tot, age |
| P7 | tau, hear, age, hearing_self, tau_v1?, hear_v1?, age_v1? |
| P10 | arm, dtau, dhear, dword |
| P5 | group(tin or ctl), sync, load_effect |
| P9 | loud_silence_minus_noise, mask_offpitch_minus_onpitch, residual_inhibition_s |
| P12 | tinnitus, noise_db, age, sex, srt, occ_noise, deprivation |
| P14 | area_noise, base_1..base_k, area_tinnitus |
| P15 | tinnitus, night_db, day_db, age, sex, srt, occ_noise, deprivation |
| P16 | d_noise_db, d_tinnitus |

UK Biobank field map: tinnitus = f.4803 (recode: any 'yes' = 1); tinnitus_severity = f.4814; noise_db = f.24023 (LAeq,16hr) or f.24022 (night); night_db = f.24022; day_db = f.24023; srt = mean of f.20019, f.20021; hear = per-triplet correct share, f.4232/f.4243; tau = tau_single() on recovery-phase HR from exercise ECG XML; age = f.21003; sex = f.31

## 7. Limits

- Synthetic worlds use effect sizes chosen to be realistic, not measured; real power depends on the true effect.
- P1's τ comes from a 60-second recovery window. The estimator was validated on simulated traces at 1.5 bpm noise; real ECG-derived heart rate needs the same check on a held-out sample before Stage A.
- P6, P11 and P13 used small permutation counts in calibration for speed. On real data pass n_perm=2000 or more (defaults: P6 2,000; P11 and P13 200).
- The P4 benchmark covers one kind of trace (two close modes, 5 dB). Golden weighting may behave differently on other signals.

## 8. Files

| File | Contents |
| --- | --- |
| eres_idloss_test.py | The harness: estimators, rules, worlds, calibration, adapters |
| test_eres_idloss.py | Unit testkit (20 checks) |
| calibration_results.json | Full calibration output |
| calibration_report.md | Calibration table |
| p15_power_by_n.json | P15 power at 20,000 to 200,000 people |
| ERES-HYP-IDLOSS-TEST-2026-001_v0.2.md / .pdf | This instrument |
| ERES-HYP-IDLOSS-2026-001_v0.8.pdf | The hypothesis under test (24 pp.) |
| ERES-HYP-IDLOSS-SYN-2026-001_v0.8_Synopsis.pdf | Synopsis in ERES Story Format |
| fig1_noise_data_reach_loop.svg, fig2_calibration.svg | Figures |
| _SUBMISSION_SEO.md | SEO note for Zenodo, ResearchGate and LinkedIn |
| README.md | Quick start |
| MANIFEST.json | SHA-256 of every file |

## References

1. ERES-HYP-IDLOSS-2026-001 v0.8, Identifiability Loss and Recovery Hypothesis. ERES Institute, 1 Nov 2026.
2. Pellis, S. *Decoding the Hidden Spectrum of Black-Hole Ringdown.* 317 pp., 4 Sep 2026.
3. Pellis, S. *The Spectral Foundations of Quantum Many-Body Dynamics.* 157 pp., 25 Oct 2026.
4. Pellis, S. *The Spectral Origin of Physical Instability.* 205 pp., 28 Oct 2026.
5. Holm, S. A simple sequentially rejective multiple test procedure. *Scandinavian Journal of Statistics* 6, 65–70 (1979).

## License

CC-BY 4.0. Reuse with attribution to the ERES Institute, and to Stergios Pellis for the spectral methods.
