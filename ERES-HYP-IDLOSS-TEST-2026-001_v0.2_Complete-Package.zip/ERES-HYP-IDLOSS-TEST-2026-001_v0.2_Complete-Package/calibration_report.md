# ERES-HYP-IDLOSS-TEST-2026-001 v0.2 calibration report

Target: ERES-HYP-IDLOSS-2026-001 v0.8  
Rules SHA-256: `74439f62144f96ce92794022303878d6816d948a7aa0583fd1ae1551455d2643`  
Harness SHA-256: `564e8c4dde84a7fb8c7eb3b0681ee923048699b511bda3460d36588d9a4a9242`  
Seed: 20261101; alpha = 0.05; runtime 370.8 s

Positive control (TOT rises with age): PASSED  
Negative control (shuffled labels, confirm rate): 0.06 (should be near 0.025)

| Prediction | Role | Reps | Power (confirm when true) | False confirm (null) | Refuted when true | Null classed refuted |
| --- | --- | --- | --- | --- | --- | --- |
| P1 | primary | 20 | 1.00 | 0.00 | 0.00 | 0.00 |
| P2 | primary | 100 | 0.84 | 0.02 | 0.00 | 0.03 |
| P3 | primary | 100 | 0.87 | 0.01 | 0.00 | 0.03 |
| P7 | primary | 100 | 1.00 | 0.00 | 0.00 | 0.05 |
| P10 | primary | 100 | 1.00 | 0.02 | 0.00 | 0.98 |
| P5 | secondary | 100 | 0.71 | 0.00 | 0.02 | 0.93 |
| P9 | secondary | 100 | 1.00 | 0.00 | 0.00 | 1.00 |
| P6 | exploratory | 40 | 1.00 | 0.00 | 0.00 | 1.00 |
| P8 | exploratory | 40 | 0.88 | 0.00 | 0.00 | 0.95 |
| P11 | secondary | 20 | 1.00 | 0.10 | 0.00 | 0.90 |
| P12 | secondary | 100 | 1.00 | 0.02 | 0.00 | 0.98 |
| P13 | secondary | 20 | 0.95 | 0.00 | 0.05 | 1.00 |
| P14 | secondary | 40 | 1.00 | 0.00 | 0.00 | 1.00 |
| P15 | secondary | 40 | 0.28 | 0.00 | 0.00 | 0.00 |
| P16 | secondary | 100 | 1.00 | 0.05 | 0.00 | 0.01 |

P4 is a benchmark, not a true/null pair: it asks whether golden weighting beats the baselines on realistic two-mode traces (5 dB SNR). Observed: golden confirmed better in 0% of runs, worse in 10%, no difference in 90%; mean margin -0.0013 (positive = golden better).

Synthetic worlds certify the test, not the hypothesis.
