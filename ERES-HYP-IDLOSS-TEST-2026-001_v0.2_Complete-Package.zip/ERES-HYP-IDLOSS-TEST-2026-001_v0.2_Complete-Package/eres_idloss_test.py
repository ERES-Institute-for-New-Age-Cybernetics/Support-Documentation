#!/usr/bin/env python3
"""
ERES-HYP-IDLOSS-TEST-2026-001  v0.2
Test instrument for ERES-HYP-IDLOSS-2026-001 v0.8
("Identifiability Loss and Recovery Hypothesis").

What this file does
  1. ESTIMATORS  - turn raw measurements into the hypothesis quantities
                   (tau, tau0, %Hear, SRT, distinctiveness, TOT rate).
  2. RULES       - apply each prediction's pre-registered decision rule
                   (confirmed / refuted / inconclusive) exactly as v0.7 states it.
  3. WORLDS      - synthetic "hypothesis-true" and "null" data for every
                   prediction, so the harness can be calibrated before real data.
  4. CALIBRATE   - power (confirm rate when true) and false-call rates
                   (confirm or refute when null) for every prediction.
  5. ADAPTERS    - run any prediction from a CSV with documented columns
                   (UK Biobank, Cam-CAN or new-study exports).

Synthetic results are NOT evidence about people. They certify the test,
not the hypothesis.

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics.
Spectral methods: Stergios Pellis (ORCID 0000-0002-7363-8254); the multiscale
weighted estimator here is an ERES implementation of his construction, not his code.
Drafting assistance: Claude (Anthropic).
License: CC-BY 4.0.

Usage
  python eres_idloss_test.py calibrate [--reps N] [--seed S] [--out DIR]
  python eres_idloss_test.py run P12 data.csv
  python eres_idloss_test.py rules
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from dataclasses import dataclass, asdict

import numpy as np
from scipy import stats, optimize

INSTRUMENT_ID = "ERES-HYP-IDLOSS-TEST-2026-001"
VERSION = "0.2"
TARGET = "ERES-HYP-IDLOSS-2026-001 v0.8"
ALPHA = 0.05
PHI = (1 + 5 ** 0.5) / 2

# --------------------------------------------------------------------------
# 0. PRE-REGISTERED RULES (frozen: their hash is printed in every report)
# --------------------------------------------------------------------------
RULES = {
    "P1":  dict(role="primary", family="H1", expected="+",
                claim="tau rises with age",
                data="UK Biobank exercise ECG, age"),
    "P2":  dict(role="primary", family="H1", expected="-",
                claim="longer tau0 predicts lower distinctiveness, controlling age",
                data="Cam-CAN resting + task MEG"),
    "P3":  dict(role="primary", family="H1", expected="+",
                claim="longer tau0 predicts more TOT failures, controlling age",
                data="Cam-CAN resting MEG + TOT task"),
    "P7":  dict(role="primary", family="H1", expected="-",
                claim="longer tau predicts lower %Hear (cross-section) and a rise in tau predicts a fall in %Hear (longitudinal)",
                data="UK Biobank ECG + digits-in-noise, visits 0 and 1"),
    "P10": dict(role="primary", family="H1", expected="+",
                claim="training shortens tau and outcome gains scale with tau change",
                data="new randomised trial"),
    "P4":  dict(role="exploratory", family="method", expected="+",
                claim="golden weighting beats uniform, 2^-k and single-scale on held-out tau error",
                data="any recovery traces"),
    "P5":  dict(role="secondary", family="H2", expected="+",
                claim="tinnitus shows excess auditory synchrony that scales with attention load",
                data="new EEG recording"),
    "P6":  dict(role="exploratory", family="H2x", expected="+",
                claim="facsimile content shared by blind unrelated listeners above shuffled nulls",
                data="facsimile replay"),
    "P8":  dict(role="exploratory", family="H2x-c", expected="+",
                claim="(a) excess tinnitus in past-life-report children; (b) blind content match above decoys",
                data="new child study"),
    "P9":  dict(role="secondary", family="H2", expected="+",
                claim="percept louder in silence, masked most near own pitch, residual inhibition present",
                data="Facsimile test"),
    "P11": dict(role="secondary", family="H1", expected="+",
                claim="voice/language features predict tau on held-out people",
                data="trial speech recordings"),
    "P12": dict(role="secondary", family="H3", expected="+",
                claim="tinnitus rises with residential noise, dose-response, after controls",
                data="UK Biobank 4803/4814, 24022/24023"),
    "P13": dict(role="secondary", family="H3", expected="+",
                claim="facsimile pitch/type predicts exposure category above chance",
                data="Facsimile test + exposure history"),
    "P14": dict(role="secondary", family="H3", expected="+",
                claim="area tinnitus burden adds held-out prediction of measured noise",
                data="UK Biobank aggregated by area"),
    "P15": dict(role="secondary", family="H4", expected="+",
                claim="night-time noise predicts tinnitus more strongly than daytime noise, same model and controls",
                data="UK Biobank 24022 (night), 24023 (16-hour), 4803"),
    "P16": dict(role="secondary", family="H4", expected="+",
                claim="change in residential noise predicts change in tinnitus between visits",
                data="movers with noise at both addresses, or repeated noise mapping"),
}
HOLM_FAMILIES = {"H1": ["P1", "P2", "P3", "P7", "P10"], "H3": ["P12", "P13", "P14", "P15", "P16"]}


def rules_hash() -> str:
    return hashlib.sha256(json.dumps(RULES, sort_keys=True).encode()).hexdigest()


def file_hash() -> str:
    with open(os.path.abspath(__file__), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


# --------------------------------------------------------------------------
# 1. ESTIMATORS
# --------------------------------------------------------------------------
def tau_single(t, hr):
    """Recovery time constant from a heart-rate recovery trace (seconds).
    Fits hr(t) = rest + drop * exp(-t / tau). UK Biobank has only 60 s of
    recovery, so a single smooth decay is the honest model."""
    t = np.asarray(t, float)
    hr = np.asarray(hr, float)
    ok = np.isfinite(hr)
    t, hr = t[ok], hr[ok]
    if t.size < 8:
        return np.nan
    p0 = (hr[-1] - 5, hr[0] - hr[-1] + 5, 40.0)
    try:
        popt, _ = optimize.curve_fit(
            lambda tt, r, d, ta: r + d * np.exp(-tt / ta),
            t, hr, p0=p0,
            bounds=([0, 0, 2], [250, 200, 600]), maxfev=4000)
        return float(popt[2])
    except Exception:
        return np.nan


def tau_multimode(x, dt, weights=None, p=60, r=4, oscillatory_only=False):
    """Slowest-decaying mode time constant from a longer trace, via a
    rank-truncated operator built from nested windows L_k = L / PHI^k with
    weights w_k (the Pellis-style multiscale construction). weights=None
    means golden weights over K=6 scales."""
    x = np.asarray(x, float)
    if weights is None:
        weights = weights_for("golden")
    H = np.array([x[i:i + p] for i in range(x.size - p)])
    Xs, Ys = [], []
    for k, w in enumerate(weights):
        Lk = min(max(int(H.shape[0] / PHI ** k), 3 * p), H.shape[0])
        Xs.append(np.sqrt(w) * H[:Lk - 1])
        Ys.append(np.sqrt(w) * H[1:Lk])
    X, Y = np.vstack(Xs).T, np.vstack(Ys).T
    U, S, Vh = np.linalg.svd(X, full_matrices=False)
    U, S, Vh = U[:, :r], S[:r], Vh[:r]
    At = U.T @ Y @ Vh.T / S
    lam = np.log(np.linalg.eigvals(At).astype(complex)) / dt
    lam = lam[lam.real < 0]
    if oscillatory_only:
        lam = lam[lam.imag > 1e-6]
    if lam.size == 0:
        return np.nan
    return float(-1 / lam[np.argmax(lam.real)].real)


def weights_for(name, K=6):
    k = np.arange(K + 1)
    w = {"golden": PHI ** -k, "uniform": np.ones(K + 1),
         "exp2": 2.0 ** -k, "single": np.array([1.0])}[name]
    return w / w.sum()


def tau0_autocorr(x, dt=1.0, max_lag=None):
    """Integrated autocorrelation time of a resting signal (early-warning
    proxy for tau when no perturbation exists). Sums the ACF to its first
    non-positive value."""
    x = np.asarray(x, float) - np.mean(x)
    n = x.size
    max_lag = max_lag or n // 4
    f = np.fft.rfft(x, 2 * n)
    acf = np.fft.irfft(f * np.conj(f))[:max_lag] / (x.var() * n)
    cut = np.argmax(acf[1:] <= 0) + 1 if np.any(acf[1:] <= 0) else max_lag
    return float(dt * (0.5 + acf[1:cut].sum()))


def distinctiveness(patterns, labels):
    """1 - mean correlation between category-mean response patterns."""
    patterns, labels = np.asarray(patterns, float), np.asarray(labels)
    cats = np.unique(labels)
    means = np.array([patterns[labels == c].mean(0) for c in cats])
    C = np.corrcoef(means)
    off = C[~np.eye(len(cats), dtype=bool)]
    return float(1 - off.mean())


def tot_rate(n_tot, n_known):
    """Tip-of-the-tongue responses / (known + TOT)."""
    return float(n_tot / max(n_tot + n_known, 1))


def pct_hear(correct):
    """Share of digit triplets heard correctly."""
    c = np.asarray(correct, float)
    return float(np.nanmean(c))


def srt_from_track(snr_per_trial, n_last=10):
    """Speech-reception threshold from an adaptive SNR track: mean SNR over
    the last n trials (dB). Lower is better hearing."""
    s = np.asarray(snr_per_trial, float)
    return float(np.mean(s[-n_last:]))


# --------------------------------------------------------------------------
# 2. STATISTICS AND DECISION RULES
# --------------------------------------------------------------------------
@dataclass
class Verdict:
    pid: str
    estimate: float
    lo: float
    hi: float
    p: float
    n: int
    outcome: str
    note: str = ""


def _residualize(y, covars):
    if covars is None:
        return y - y.mean()
    Z = np.column_stack([np.ones(len(y)), covars])
    beta, *_ = np.linalg.lstsq(Z, y, rcond=None)
    return y - Z @ beta


def partial_r(x, y, covars=None, alpha=ALPHA):
    x, y = np.asarray(x, float), np.asarray(y, float)
    cv = None if covars is None else np.asarray(covars, float).reshape(len(x), -1)
    ok = np.isfinite(x) & np.isfinite(y)
    if cv is not None:
        ok &= np.all(np.isfinite(cv), 1)
        cv = cv[ok]
    x, y = x[ok], y[ok]
    rx, ry = _residualize(x, cv), _residualize(y, cv)
    r = float(np.corrcoef(rx, ry)[0, 1])
    k = 0 if cv is None else cv.shape[1]
    n = len(x)
    se = 1 / math.sqrt(max(n - 3 - k, 1))
    z = np.arctanh(np.clip(r, -0.999999, 0.999999))
    zc = stats.norm.ppf(1 - alpha / 2)
    p = 2 * (1 - stats.norm.cdf(abs(z) / se))
    return r, float(np.tanh(z - zc * se)), float(np.tanh(z + zc * se)), float(p), n


def ols_coef(x, y, covars=None, alpha=ALPHA):
    """Coefficient of x in y ~ x + covars, with t-based CI."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    cols = [np.ones(len(x)), x]
    if covars is not None:
        cols.append(np.asarray(covars, float).reshape(len(x), -1))
    Z = np.column_stack(cols)
    ok = np.all(np.isfinite(Z), 1) & np.isfinite(y)
    Z, y = Z[ok], y[ok]
    beta, *_ = np.linalg.lstsq(Z, y, rcond=None)
    res = y - Z @ beta
    dof = max(len(y) - Z.shape[1], 1)
    s2 = res @ res / dof
    cov = s2 * np.linalg.pinv(Z.T @ Z)
    se = math.sqrt(cov[1, 1])
    tc = stats.t.ppf(1 - alpha / 2, dof)
    p = 2 * (1 - stats.t.cdf(abs(beta[1] / se), dof)) if se > 0 else 1.0
    return float(beta[1]), float(beta[1] - tc * se), float(beta[1] + tc * se), float(p), len(y)


def classify(lo, hi, expected):
    """v0.7 rule: confirmed if CI excludes 0 in the expected direction,
    refuted if CI excludes 0 in the opposite direction, else inconclusive."""
    if lo > 0:
        return "confirmed" if expected == "+" else "refuted"
    if hi < 0:
        return "confirmed" if expected == "-" else "refuted"
    return "inconclusive"


def classify_one_sided(p, effect_ok):
    """For tests against a null distribution (held-out gain, decoys):
    confirmed if p < ALPHA and effect in expected direction, refuted if the
    pre-registered sample is complete and p >= ALPHA."""
    return "confirmed" if (p < ALPHA and effect_ok) else "refuted"


def holm(pvals: dict, alpha=ALPHA):
    """Holm step-down. Returns {pid: adjusted_significant(bool)}."""
    items = sorted(pvals.items(), key=lambda kv: kv[1])
    m = len(items)
    out, still = {}, True
    for i, (k, p) in enumerate(items):
        thr = alpha / (m - i)
        still = still and (p <= thr)
        out[k] = still
    return out


def apply_holm(verdicts: dict):
    """Downgrade confirmed/refuted to inconclusive where Holm fails."""
    for fam, pids in HOLM_FAMILIES.items():
        ps = {k: verdicts[k].p for k in pids if k in verdicts}
        if len(ps) < 2:
            continue
        sig = holm(ps)
        for k, ok in sig.items():
            v = verdicts[k]
            if not ok and v.outcome in ("confirmed", "refuted") and RULES[k]["role"] != "exploratory":
                v.outcome = "inconclusive"
                v.note = (v.note + " Holm-adjusted.").strip()
    return verdicts


def perm_p(stat_obs, stat_null):
    stat_null = np.asarray(stat_null)
    return float((1 + np.sum(stat_null >= stat_obs)) / (1 + stat_null.size))


# --------------------------------------------------------------------------
# 3. PREDICTION TESTS (each takes plain arrays; adapters map CSVs onto these)
# --------------------------------------------------------------------------
def test_P1(age, tau, sex=None):
    b, lo, hi, p, n = ols_coef(age, tau, sex)
    return Verdict("P1", b, lo, hi, p, n, classify(lo, hi, "+"), "slope of tau on age (s per year)")


def test_P2(tau0, distinct, age):
    r, lo, hi, p, n = partial_r(tau0, distinct, age)
    return Verdict("P2", r, lo, hi, p, n, classify(lo, hi, "-"), "partial r, age-controlled")


def test_P3(tau0, tot, age):
    r, lo, hi, p, n = partial_r(tau0, tot, age)
    return Verdict("P3", r, lo, hi, p, n, classify(lo, hi, "+"), "partial r, age-controlled")


def test_P7(tau, hear, age, hearing_self, tau_v1=None, hear_v1=None, age_v1=None, min_long=1000):
    """Cross-section: partial r(tau, %Hear | age, self-reported hearing).
    Longitudinal: slope of d%Hear on dtau. Both must agree for 'confirmed'."""
    r, lo, hi, p, n = partial_r(tau, hear, np.column_stack([age, hearing_self]))
    cross = classify(lo, hi, "-")
    note = f"cross-section partial r={r:.3f} [{lo:.3f},{hi:.3f}]"
    if tau_v1 is None:
        return Verdict("P7", r, lo, hi, p, n, cross, note + "; no longitudinal data")
    dt, dh = np.asarray(tau_v1) - np.asarray(tau), np.asarray(hear_v1) - np.asarray(hear)
    ok = np.isfinite(dt) & np.isfinite(dh)
    b, blo, bhi, bp, bn = ols_coef(dt[ok], dh[ok], None if age_v1 is None else np.asarray(age_v1)[ok])
    longi = classify(blo, bhi, "-")
    note += f"; longitudinal slope={b:.4f} [{blo:.4f},{bhi:.4f}], n={bn}"
    if bn < min_long:
        note += " (longitudinal subset < 1000: exploratory)"
        outcome = cross
    elif cross == longi:
        outcome = cross
    elif "refuted" in (cross, longi):
        outcome = "refuted"
    else:
        outcome = "inconclusive"
    return Verdict("P7", r, lo, hi, max(p, bp if bn >= min_long else p), n, outcome, note)


def test_P10(arm, dtau, dhear, dword):
    """arm: 1 = training, 0 = control. Requires (i) tau falls more with
    training and (ii) within the trial, outcome change scales with -dtau."""
    arm = np.asarray(arm)
    b1, lo1, hi1, p1, n = ols_coef(arm, dtau)          # expected negative
    first = classify(lo1, hi1, "-")
    outcome_z = (stats.zscore(dhear) + stats.zscore(dword)) / 2
    b2, lo2, hi2, p2, _ = ols_coef(-np.asarray(dtau), outcome_z, arm)  # expected positive
    second = classify(lo2, hi2, "+")
    if first == "confirmed" and second == "confirmed":
        outcome = "confirmed"
    elif first == "confirmed" and second != "confirmed":
        outcome = "refuted" if second == "refuted" or hi2 < 0.05 else "inconclusive"
    else:
        outcome = "inconclusive"
    return Verdict("P10", b2, lo2, hi2, max(p1, p2), n, outcome,
                   f"arm effect on dtau={b1:.2f} [{lo1:.2f},{hi1:.2f}]; outcome per unit -dtau={b2:.3f}")


def test_P4(true_tau, est_by_method: dict, n_boot=500, seed=0):
    """Golden must have lower median relative error than every baseline,
    with paired bootstrap CI of the difference excluding 0."""
    rng = np.random.default_rng(seed)
    t = np.asarray(true_tau)
    err = {m: np.abs(np.asarray(e) - t) / t for m, e in est_by_method.items()}
    g = err["golden"]
    worst = None
    for m, e in err.items():
        if m == "golden":
            continue
        ok = np.isfinite(g) & np.isfinite(e)
        d = e[ok] - g[ok]  # positive = golden better
        boots = [np.median(d[rng.integers(0, d.size, d.size)]) for _ in range(n_boot)]
        lo, hi = np.percentile(boots, [2.5, 97.5])
        if worst is None or lo < worst[1]:
            worst = (float(np.median(d)), float(lo), float(hi), m)
    est, lo, hi, m = worst
    return Verdict("P4", est, lo, hi, float("nan"), len(t), classify(lo, hi, "+"),
                   f"golden minus weakest-margin baseline ({m}); positive = golden better")


def test_P5(sync_tin, sync_ctl, load_effect_tin):
    """Excess synchrony (tinnitus vs control) and attention-load effect
    within tinnitus; both CIs must exclude 0 positively."""
    t1 = stats.ttest_ind(sync_tin, sync_ctl, equal_var=False)
    d = np.mean(sync_tin) - np.mean(sync_ctl)
    se = math.sqrt(np.var(sync_tin, ddof=1) / len(sync_tin) + np.var(sync_ctl, ddof=1) / len(sync_ctl))
    lo1, hi1 = d - 1.96 * se, d + 1.96 * se
    m = np.mean(load_effect_tin)
    se2 = np.std(load_effect_tin, ddof=1) / math.sqrt(len(load_effect_tin))
    lo2, hi2 = m - 1.96 * se2, m + 1.96 * se2
    a, b = classify(lo1, hi1, "+"), classify(lo2, hi2, "+")
    outcome = "confirmed" if a == b == "confirmed" else ("refuted" if "confirmed" not in (a, b) and len(sync_tin) >= 100 else "inconclusive")
    return Verdict("P5", d, lo1, hi1, float(t1.pvalue), len(sync_tin) + len(sync_ctl), outcome,
                   f"load effect={m:.3f} [{lo2:.3f},{hi2:.3f}]")


def test_P9(loud_silence_minus_noise, mask_offpitch_minus_onpitch, residual_inhibition_s):
    """Three within-person effects, all must be > 0 with CI excluding 0."""
    parts, res = [], []
    for name, v in (("silence", loud_silence_minus_noise),
                    ("tuning", mask_offpitch_minus_onpitch),
                    ("RI", residual_inhibition_s)):
        v = np.asarray(v, float)
        m, se = v.mean(), v.std(ddof=1) / math.sqrt(v.size)
        lo, hi = m - 1.96 * se, m + 1.96 * se
        res.append(classify(lo, hi, "+"))
        parts.append(f"{name}={m:.2f} [{lo:.2f},{hi:.2f}]")
    if all(r == "confirmed" for r in res):
        outcome = "confirmed"
    elif any(r != "confirmed" for r in res) and len(loud_silence_minus_noise) >= 100:
        outcome = "refuted"
    else:
        outcome = "inconclusive"
    return Verdict("P9", float(np.mean(loud_silence_minus_noise)), float("nan"), float("nan"),
                   float("nan"), len(loud_silence_minus_noise), outcome, "; ".join(parts))


def test_P6(listener_reports, source_ids, n_perm=2000, seed=0):
    """listener_reports: (n_items, n_listeners) category codes describing each
    replayed facsimile. Statistic = mean pairwise agreement between listeners
    on the same item. Null = shuffle items within each listener
    (shuffled-subject null)."""
    rng = np.random.default_rng(seed)
    R = np.asarray(listener_reports)

    def agree(M):
        n_l = M.shape[1]
        s, c = 0.0, 0
        for i in range(n_l):
            for j in range(i + 1, n_l):
                s += np.mean(M[:, i] == M[:, j]); c += 1
        return s / c
    obs = agree(R)
    null = []
    for _ in range(n_perm):
        M = R.copy()
        for j in range(M.shape[1]):
            M[:, j] = M[rng.permutation(M.shape[0]), j]
        null.append(agree(M))
    p = perm_p(obs, null)
    return Verdict("P6", obs, float(np.percentile(null, 2.5)), float(np.percentile(null, 97.5)), p,
                   R.shape[0], classify_one_sided(p, obs > np.mean(null)),
                   "listener agreement vs shuffled-item null (CI shown is the null band)")


def test_P8(tin_plr, n_plr, tin_ctl, n_ctl, sim_matrix, n_perm=5000, seed=0):
    """(a) excess tinnitus prevalence, past-life-report vs matched controls.
    (b) blind match: sim_matrix[i, j] = similarity of child i's tinnitus
    description to account j; diagonal = own account, off-diagonal = decoys.
    Statistic = mean rank of own account; null = permuted accounts."""
    p1, p2 = tin_plr / n_plr, tin_ctl / n_ctl
    d = p1 - p2
    se = math.sqrt(p1 * (1 - p1) / n_plr + p2 * (1 - p2) / n_ctl)
    lo, hi = d - 1.96 * se, d + 1.96 * se
    a = classify(lo, hi, "+")
    S = np.asarray(sim_matrix, float)
    rng = np.random.default_rng(seed)

    def hit(Sm):
        return np.mean([np.mean(Sm[i, i] > np.delete(Sm[i], i)) for i in range(Sm.shape[0])])
    obs = hit(S)
    null = [hit(S[:, rng.permutation(S.shape[1])]) for _ in range(n_perm)]
    pb = perm_p(obs, null)
    b = classify_one_sided(pb, obs > 0.5)
    outcome = "confirmed" if (a == "confirmed" and b == "confirmed") else (
        "refuted" if a != "confirmed" and b != "confirmed" else "inconclusive")
    return Verdict("P8", d, lo, hi, pb, n_plr + n_ctl, outcome,
                   f"(a) prevalence diff {d:.3f} [{lo:.3f},{hi:.3f}] -> {a}; "
                   f"(b) own-account beats decoys {obs:.3f} vs 0.5, perm p={pb:.4f} -> {b}")


def _cv_r2(X, y, groups=None, k=5, seed=0):
    from sklearn.linear_model import RidgeCV
    from sklearn.model_selection import KFold, GroupKFold
    X, y = np.asarray(X, float), np.asarray(y, float)
    if groups is None:
        splits = KFold(k, shuffle=True, random_state=seed).split(X)
    else:
        splits = GroupKFold(k).split(X, y, groups)
    pred = np.zeros_like(y)
    for tr, te in splits:
        m = RidgeCV(alphas=np.logspace(-3, 3, 13)).fit(X[tr], y[tr])
        pred[te] = m.predict(X[te])
    return 1 - np.sum((y - pred) ** 2) / np.sum((y - y.mean()) ** 2), pred


def test_P11(voice_features, tau, n_perm=200, seed=0):
    """Held-out (k-fold, by person) prediction of tau from voice features,
    against a shuffled-label null."""
    rng = np.random.default_rng(seed)
    r2, _ = _cv_r2(voice_features, tau, seed=seed)
    null = [_cv_r2(voice_features, rng.permutation(tau), seed=seed)[0] for _ in range(n_perm)]
    p = perm_p(r2, null)
    return Verdict("P11", r2, float(np.percentile(null, 2.5)), float(np.percentile(null, 97.5)), p,
                   len(tau), classify_one_sided(p, r2 > 0), "held-out R^2 vs shuffled-label null band")


def test_P12(tinnitus, noise_db, controls):
    """Linear-probability dose-response: tinnitus (0/1) on noise (dB) plus
    controls (age, sex, SRT, occupational noise, deprivation)."""
    b, lo, hi, p, n = ols_coef(noise_db, tinnitus, controls)
    out = classify(lo, hi, "+")
    out = "confirmed" if out == "confirmed" else "refuted"   # v0.7: no trend = refuted
    return Verdict("P12", b, lo, hi, p, n, out,
                   "change in tinnitus probability per dB, controlled")


def test_P13(features, exposure_cat, n_perm=200, seed=0):
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import cross_val_score, StratifiedKFold
    rng = np.random.default_rng(seed)
    cv = StratifiedKFold(5, shuffle=True, random_state=seed)
    clf = LogisticRegression(max_iter=2000)
    acc = cross_val_score(clf, features, exposure_cat, cv=cv).mean()
    null = [cross_val_score(clf, features, rng.permutation(exposure_cat), cv=cv).mean() for _ in range(n_perm)]
    p = perm_p(acc, null)
    return Verdict("P13", acc, float(np.percentile(null, 2.5)), float(np.percentile(null, 97.5)), p,
                   len(exposure_cat), classify_one_sided(p, acc > np.mean(null)),
                   "held-out accuracy vs shuffled-label null band")


def test_P14(area_noise, area_base, area_tinnitus, n_boot=500, seed=0):
    """Held-out (area-level k-fold) R^2 of measured noise from baseline area
    covariates vs baseline + tinnitus burden; bootstrap CI of the gain."""
    rng = np.random.default_rng(seed)
    Xb = np.asarray(area_base, float).reshape(len(area_noise), -1)
    Xf = np.column_stack([Xb, area_tinnitus])
    y = np.asarray(area_noise, float)
    _, pb = _cv_r2(Xb, y, seed=seed)
    _, pf = _cv_r2(Xf, y, seed=seed)
    eb, ef = (y - pb) ** 2, (y - pf) ** 2
    gain = (eb.sum() - ef.sum()) / np.sum((y - y.mean()) ** 2)
    boots = []
    for _ in range(n_boot):
        i = rng.integers(0, y.size, y.size)
        boots.append((eb[i].sum() - ef[i].sum()) / np.sum((y[i] - y[i].mean()) ** 2))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    p = float(np.mean(np.asarray(boots) <= 0))
    out = "confirmed" if classify(lo, hi, "+") == "confirmed" else "refuted"  # v0.7: no added value = refuted
    return Verdict("P14", float(gain), float(lo), float(hi), p, y.size, out,
                   "held-out R^2 gain from adding tinnitus burden")


def test_P15(tinnitus, night_db, day_db, controls, n_boot=500, seed=0):
    """Night minus day coefficient, both standardised, in one linear-probability
    model with the P12 controls; percentile bootstrap CI of the difference."""
    rng = np.random.default_rng(seed)
    y = np.asarray(tinnitus, float)
    zn, zd = stats.zscore(night_db), stats.zscore(day_db)
    C = np.asarray(controls, float).reshape(len(y), -1)

    def diff(i):
        Z = np.column_stack([np.ones(i.size), zn[i], zd[i], C[i]])
        b, *_ = np.linalg.lstsq(Z, y[i], rcond=None)
        return b[1] - b[2]
    allidx = np.arange(y.size)
    d = diff(allidx)
    boots = np.array([diff(rng.integers(0, y.size, y.size)) for _ in range(n_boot)])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    p = float(2 * min(np.mean(boots <= 0), np.mean(boots >= 0)))
    return Verdict("P15", float(d), float(lo), float(hi), p, y.size, classify(lo, hi, "+"),
                   "night minus day standardised coefficient on tinnitus")


def test_P16(d_noise_db, d_tinnitus, controls=None):
    """Slope of change in tinnitus (score or 0/1 difference) on change in
    residential noise (dB) between visits."""
    b, lo, hi, p, n = ols_coef(d_noise_db, d_tinnitus, controls)
    return Verdict("P16", b, lo, hi, p, n, classify(lo, hi, "+"),
                   "change in tinnitus per dB change in residential noise")


# --------------------------------------------------------------------------
# 4. SYNTHETIC WORLDS  (effect=True -> hypothesis world, False -> null world)
# --------------------------------------------------------------------------
def hr_trace(tau, rng, rest=75, drop=40, secs=60, noise=1.5):
    t = np.arange(0, secs + 1, 1.0)
    return t, rest + drop * np.exp(-t / tau) + rng.normal(0, noise, t.size)


def world_P1(rng, effect, n=2000):
    age = rng.uniform(40, 70, n)
    tau = 35 + (0.6 * (age - 55) if effect else 0) + rng.normal(0, 8, n)
    tau = np.clip(tau, 8, None)
    est = np.array([tau_single(*hr_trace(t, rng)) for t in tau])
    return dict(age=age, tau=est)


def world_P23(rng, effect, n=656, r_true=0.11):
    age = rng.uniform(18, 88, n)
    e = rng.normal(0, 1, n)
    tau0 = 0.03 * (age - 50) + e
    rr = r_true if effect else 0.0
    distinct = -0.02 * (age - 50) - rr * e + math.sqrt(1 - rr ** 2) * rng.normal(0, 1, n)
    tot = 0.02 * (age - 50) + rr * e + math.sqrt(1 - rr ** 2) * rng.normal(0, 1, n)
    return dict(age=age, tau0=tau0, distinct=distinct, tot=tot)


def world_P7(rng, effect, n=5000, n_long=1500, r_true=0.10):
    age = rng.uniform(40, 70, n)
    self_hear = rng.integers(0, 2, n)
    e = rng.normal(0, 1, n)
    tau = 35 + 0.5 * (age - 55) + 8 * e
    rr = r_true if effect else 0.0
    hear = 0.85 - 0.003 * (age - 55) - 0.03 * self_hear + 0.05 * (-rr * e + math.sqrt(1 - rr ** 2) * rng.normal(0, 1, n))
    i = rng.choice(n, n_long, replace=False)
    dtau = rng.normal(2, 4, n_long)
    dh = (-0.004 * dtau if effect else 0) + rng.normal(0, 0.03, n_long)
    tau_v1 = np.full(n, np.nan); hear_v1 = np.full(n, np.nan)
    tau_v1[i] = tau[i] + dtau
    hear_v1[i] = hear[i] + dh
    return dict(tau=tau, hear=hear, age=age, hearing_self=self_hear,
                tau_v1=tau_v1, hear_v1=hear_v1, age_v1=age)


def world_P10(rng, effect, n=300):
    arm = rng.integers(0, 2, n)
    dtau = -6 * arm + rng.normal(0, 6, n)
    k = 0.04 if effect else 0.0
    dhear = -k * dtau + rng.normal(0, 0.5, n)
    dword = -k * dtau + rng.normal(0, 0.5, n)
    return dict(arm=arm, dtau=dtau, dhear=dhear, dword=dword)


def world_P4(rng, effect, n=150, snr_db=5):
    """effect=True: traces carry a slow mode buried among closely spaced
    modes, where multiscale weighting could help. Either way the test only
    says whether golden wins."""
    dt = 0.1
    T = np.arange(0, 60, dt)
    taus = rng.uniform(3, 9, n)
    est = {m: [] for m in ("golden", "uniform", "exp2", "single")}
    for tau in taus:
        s = np.exp(-T / tau) * np.cos(2 * np.pi * 0.12 * T) + 0.4 * np.exp(-T / (0.35 * tau)) * np.cos(2 * np.pi * 0.31 * T + 1)
        x = s + rng.normal(0, np.std(s) / 10 ** (snr_db / 20), T.size)
        for m in est:
            est[m].append(tau_multimode(x, dt, weights_for(m), oscillatory_only=True))
    return dict(true_tau=taus, est_by_method={m: np.array(v) for m, v in est.items()})


def world_P5(rng, effect, n=100):
    d = 0.4 if effect else 0.0
    return dict(sync_tin=rng.normal(d, 1, n), sync_ctl=rng.normal(0, 1, n),
                load_effect_tin=rng.normal(0.3 if effect else 0.0, 1, n))


def world_P9(rng, effect, n=100):
    s = 1.0 if effect else 0.0
    return dict(loud_silence_minus_noise=rng.normal(3 * s, 5, n),
                mask_offpitch_minus_onpitch=rng.normal(4 * s, 6, n),
                residual_inhibition_s=rng.normal(20 * s, 30, n))


def world_P6(rng, effect, n_items=60, n_listeners=8, n_cats=6):
    truth = rng.integers(0, n_cats, n_items)
    R = np.empty((n_items, n_listeners), int)
    for j in range(n_listeners):
        hit = rng.random(n_items) < (0.35 if effect else 0.0)
        R[:, j] = np.where(hit, truth, rng.integers(0, n_cats, n_items))
    return dict(listener_reports=R, source_ids=np.arange(n_items))


def world_P8(rng, effect, n=60):
    p_ctl = 0.15
    p_plr = 0.30 if effect else p_ctl
    S = rng.normal(0, 1, (n, n))
    if effect:
        S[np.arange(n), np.arange(n)] += 0.8
    return dict(tin_plr=rng.binomial(n * 2, p_plr), n_plr=n * 2,
                tin_ctl=rng.binomial(n * 2, p_ctl), n_ctl=n * 2, sim_matrix=S)


def world_P11(rng, effect, n=300, n_feat=12):
    tau = rng.normal(35, 8, n)
    F = rng.normal(0, 1, (n, n_feat))
    if effect:
        F[:, :3] += 0.06 * (tau - 35)[:, None]
    return dict(voice_features=F, tau=tau)


def world_P12(rng, effect, n=20000):
    age = rng.uniform(40, 70, n)
    sex = rng.integers(0, 2, n)
    srt = rng.normal(-7, 2, n) + 0.05 * (age - 55)
    occ = rng.integers(0, 2, n)
    dep = rng.normal(0, 1, n)
    noise = 54 + 2 * dep + rng.normal(0, 4, n)
    lin = -2.2 + 0.03 * (age - 55) + 0.2 * sex + 0.15 * (srt + 7) + 0.6 * occ + (0.03 * (noise - 54) if effect else 0)
    tin = (rng.random(n) < 1 / (1 + np.exp(-lin))).astype(float)
    return dict(tinnitus=tin, noise_db=noise, controls=np.column_stack([age, sex, srt, occ, dep]))


def world_P13(rng, effect, n=200):
    cat = rng.integers(0, 3, n)
    pitch_khz = rng.uniform(1, 8, n)
    if effect:
        pitch_khz = np.where(cat == 0, rng.normal(4.5, 0.8, n), pitch_khz)
    sound_type = rng.integers(0, 4, n)
    return dict(features=p13_features(pitch_khz, sound_type), exposure_cat=cat)


def p13_features(pitch_khz, sound_type, notch_khz=4.5):
    """Pre-specified P13 features: matched pitch, distance from the 3-6 kHz
    noise-damage region (centre 4.5 kHz), and sound type (one-hot, 4 types)."""
    pitch_khz = np.asarray(pitch_khz, float)
    return np.column_stack([pitch_khz, np.abs(pitch_khz - notch_khz),
                            np.eye(4)[np.asarray(sound_type, int)]])


def world_P14(rng, effect, n_areas=400):
    base = rng.normal(0, 1, (n_areas, 3))
    noise = 54 + base @ np.array([1.0, 0.5, 0.0]) + rng.normal(0, 2, n_areas)
    tin = 0.15 + 0.01 * base[:, 0] + (0.004 * (noise - 54) if effect else 0) + rng.normal(0, 0.01, n_areas)
    return dict(area_noise=noise, area_base=base, area_tinnitus=tin)


def world_P15(rng, effect, n=20000):
    age = rng.uniform(40, 70, n); sex = rng.integers(0, 2, n)
    srt = rng.normal(-7, 2, n) + 0.05 * (age - 55)
    occ = rng.integers(0, 2, n); dep = rng.normal(0, 1, n)
    day = 54 + 2 * dep + rng.normal(0, 4, n)
    night = day - 8 + rng.normal(0, 2.5, n)          # night tracks day, correlated
    zn, zd = stats.zscore(night), stats.zscore(day)
    lin = -2.2 + 0.03 * (age - 55) + 0.2 * sex + 0.15 * (srt + 7) + 0.6 * occ + \
        (0.18 * zn + 0.06 * zd if effect else 0.12 * zn + 0.12 * zd)
    tin = (rng.random(n) < 1 / (1 + np.exp(-lin))).astype(float)
    return dict(tinnitus=tin, night_db=night, day_db=day, controls=np.column_stack([age, sex, srt, occ, dep]))


def world_P16(rng, effect, n=1500):
    d_noise = rng.normal(0, 4, n)                    # movers: change in dB
    k = 0.012 if effect else 0.0
    d_tin = k * d_noise + rng.normal(0, 0.25, n)     # change in 0-1 tinnitus score
    return dict(d_noise_db=d_noise, d_tinnitus=d_tin)


WORLDS = {
    "P1": (world_P1, lambda d: test_P1(d["age"], d["tau"])),
    "P2": (world_P23, lambda d: test_P2(d["tau0"], d["distinct"], d["age"])),
    "P3": (world_P23, lambda d: test_P3(d["tau0"], d["tot"], d["age"])),
    "P7": (world_P7, lambda d: test_P7(**d)),
    "P10": (world_P10, lambda d: test_P10(**d)),
    "P4": (world_P4, lambda d: test_P4(**d, n_boot=200)),
    "P5": (world_P5, lambda d: test_P5(**d)),
    "P9": (world_P9, lambda d: test_P9(**d)),
    "P6": (world_P6, lambda d: test_P6(d["listener_reports"], d["source_ids"], n_perm=300)),
    "P8": (world_P8, lambda d: test_P8(**d, n_perm=500)),
    "P11": (world_P11, lambda d: test_P11(**d, n_perm=40)),
    "P12": (world_P12, lambda d: test_P12(**d)),
    "P13": (world_P13, lambda d: test_P13(**d, n_perm=40)),
    "P14": (world_P14, lambda d: test_P14(**d, n_boot=300)),
    "P15": (world_P15, lambda d: test_P15(**d, n_boot=200)),
    "P16": (world_P16, lambda d: test_P16(**d)),
}
# reps scale: expensive tests run fewer repetitions
REP_SCALE = {"P15": 0.4, "P1": 0.2, "P4": 0.1, "P11": 0.2, "P13": 0.2, "P14": 0.4, "P6": 0.4, "P8": 0.4}


# --------------------------------------------------------------------------
# 5. CONTROLS
# --------------------------------------------------------------------------
def positive_control(rng, n=656):
    """TOT rate must rise with age (a known Cam-CAN result). If the pipeline
    cannot find it in a world where it is built in, nothing else is trusted."""
    age = rng.uniform(18, 88, n)
    tot = 0.05 + 0.002 * (age - 18) + rng.normal(0, 0.05, n)
    b, lo, hi, p, _ = ols_coef(age, tot)
    return classify(lo, hi, "+") == "confirmed"


def negative_control(rng, reps=50):
    """Shuffled subject labels in a hypothesis-true world must return null:
    the confirm rate must stay near alpha."""
    hits = 0
    for _ in range(reps):
        d = world_P23(rng, True)
        v = test_P2(rng.permutation(d["tau0"]), d["distinct"], d["age"])
        hits += v.outcome == "confirmed"
    return hits / reps


# --------------------------------------------------------------------------
# 6. CALIBRATION
# --------------------------------------------------------------------------
def calibrate(reps=100, seed=20261101, verbose=True):
    rng = np.random.default_rng(seed)
    t0 = time.time()
    out = {"instrument": INSTRUMENT_ID, "version": VERSION, "target": TARGET,
           "rules_sha256": rules_hash(), "harness_sha256": file_hash(),
           "seed": seed, "alpha": ALPHA, "predictions": {}}
    pc = positive_control(rng)
    nc = negative_control(rng)
    out["positive_control_passed"] = bool(pc)
    out["negative_control_confirm_rate"] = nc
    for pid, (wfun, tfun) in WORLDS.items():
        R = max(5, int(reps * REP_SCALE.get(pid, 1.0)))
        row = {}
        for label, eff in (("true", True), ("null", False)):
            counts = {"confirmed": 0, "refuted": 0, "inconclusive": 0}
            ests = []
            for _ in range(R):
                v = tfun(wfun(rng, eff))
                counts[v.outcome] += 1
                ests.append(v.estimate)
            row[label] = {k: c / R for k, c in counts.items()}
            row[label]["mean_estimate"] = float(np.nanmean(ests))
        row["reps"] = R
        row["power"] = row["true"]["confirmed"]
        row["false_confirm"] = row["null"]["confirmed"]
        row["false_refute_when_true"] = row["true"]["refuted"]
        out["predictions"][pid] = row
        if verbose:
            print(f"{pid:4s} reps={R:3d}  power={row['power']:.2f}  "
                  f"false-confirm(null)={row['false_confirm']:.2f}  "
                  f"refuted-when-true={row['false_refute_when_true']:.2f}  "
                  f"null->refuted={row['null']['refuted']:.2f}", flush=True)
    out["runtime_s"] = round(time.time() - t0, 1)
    return out


def report_md(res):
    L = [f"# {INSTRUMENT_ID} v{VERSION} calibration report", "",
         f"Target: {TARGET}  ", f"Rules SHA-256: `{res['rules_sha256']}`  ",
         f"Harness SHA-256: `{res['harness_sha256']}`  ",
         f"Seed: {res['seed']}; alpha = {res['alpha']}; runtime {res['runtime_s']} s", "",
         f"Positive control (TOT rises with age): {'PASSED' if res['positive_control_passed'] else 'FAILED'}  ",
         f"Negative control (shuffled labels, confirm rate): {res['negative_control_confirm_rate']:.2f} (should be near {ALPHA/2:.3f})", "",
         "| Prediction | Role | Reps | Power (confirm when true) | False confirm (null) | Refuted when true | Null classed refuted |",
         "| --- | --- | --- | --- | --- | --- | --- |"]
    for pid, r in res["predictions"].items():
        if pid == "P4":
            continue
        L.append(f"| {pid} | {RULES[pid]['role']} | {r['reps']} | {r['power']:.2f} | {r['false_confirm']:.2f} | "
                 f"{r['false_refute_when_true']:.2f} | {r['null']['refuted']:.2f} |")
    if "P4" in res["predictions"]:
        r = res["predictions"]["P4"]["true"]
        L += ["", "P4 is a benchmark, not a true/null pair: it asks whether golden weighting beats the baselines "
              f"on realistic two-mode traces (5 dB SNR). Observed: golden confirmed better in {r['confirmed']:.0%} of runs, "
              f"worse in {r['refuted']:.0%}, no difference in {r['inconclusive']:.0%}; "
              f"mean margin {r['mean_estimate']:+.4f} (positive = golden better)."]
    L += ["", "Synthetic worlds certify the test, not the hypothesis."]
    return "\n".join(L)


# --------------------------------------------------------------------------
# 7. CSV ADAPTERS
# --------------------------------------------------------------------------
CSV_SCHEMA = {
    "P1": ["age", "tau"],
    "P2": ["tau0", "distinct", "age"],
    "P3": ["tau0", "tot", "age"],
    "P7": ["tau", "hear", "age", "hearing_self", "tau_v1?", "hear_v1?", "age_v1?"],
    "P10": ["arm", "dtau", "dhear", "dword"],
    "P5": ["group(tin|ctl)", "sync", "load_effect"],
    "P9": ["loud_silence_minus_noise", "mask_offpitch_minus_onpitch", "residual_inhibition_s"],
    "P12": ["tinnitus", "noise_db", "age", "sex", "srt", "occ_noise", "deprivation"],
    "P14": ["area_noise", "base_1..base_k", "area_tinnitus"],
    "P15": ["tinnitus", "night_db", "day_db", "age", "sex", "srt", "occ_noise", "deprivation"],
    "P16": ["d_noise_db", "d_tinnitus"],
}
UKB_FIELD_MAP = {
    "tinnitus": "f.4803 (recode: any 'yes' = 1)",
    "tinnitus_severity": "f.4814",
    "noise_db": "f.24023 (LAeq,16hr) or f.24022 (night)",
    "night_db": "f.24022", "day_db": "f.24023",
    "srt": "mean of f.20019, f.20021",
    "hear": "per-triplet correct share, f.4232/f.4243",
    "tau": "tau_single() on recovery-phase HR from exercise ECG XML",
    "age": "f.21003",
    "sex": "f.31",
}


def run_csv(pid, path):
    import csv
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    col = lambda k: np.array([float(r[k]) if r.get(k, "") not in ("", "NA") else np.nan for r in rows])
    has = lambda k: k in rows[0]
    if pid == "P1":
        return test_P1(col("age"), col("tau"))
    if pid == "P2":
        return test_P2(col("tau0"), col("distinct"), col("age"))
    if pid == "P3":
        return test_P3(col("tau0"), col("tot"), col("age"))
    if pid == "P7":
        kw = dict(tau=col("tau"), hear=col("hear"), age=col("age"), hearing_self=col("hearing_self"))
        if has("tau_v1"):
            kw.update(tau_v1=col("tau_v1"), hear_v1=col("hear_v1"), age_v1=col("age"))
        return test_P7(**kw)
    if pid == "P10":
        return test_P10(col("arm"), col("dtau"), col("dhear"), col("dword"))
    if pid == "P5":
        g = np.array([r["group"] for r in rows])
        s = col("sync")
        return test_P5(s[g == "tin"], s[g == "ctl"], col("load_effect")[g == "tin"])
    if pid == "P9":
        return test_P9(col("loud_silence_minus_noise"), col("mask_offpitch_minus_onpitch"), col("residual_inhibition_s"))
    if pid == "P12":
        C = np.column_stack([col(k) for k in ("age", "sex", "srt", "occ_noise", "deprivation")])
        return test_P12(col("tinnitus"), col("noise_db"), C)
    if pid == "P14":
        bases = [k for k in rows[0] if k.startswith("base_")]
        return test_P14(col("area_noise"), np.column_stack([col(k) for k in bases]), col("area_tinnitus"))
    if pid == "P15":
        C = np.column_stack([col(k) for k in ("age", "sex", "srt", "occ_noise", "deprivation")])
        return test_P15(col("tinnitus"), col("night_db"), col("day_db"), C, n_boot=2000)
    if pid == "P16":
        return test_P16(col("d_noise_db"), col("d_tinnitus"))
    raise SystemExit(f"No CSV adapter for {pid}; call test_{pid}() from Python with arrays.")


# --------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=f"{INSTRUMENT_ID} v{VERSION}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("calibrate")
    c.add_argument("--reps", type=int, default=100)
    c.add_argument("--seed", type=int, default=20261101)
    c.add_argument("--out", default=".")
    r = sub.add_parser("run")
    r.add_argument("pid")
    r.add_argument("csv")
    sub.add_parser("rules")
    a = ap.parse_args(argv)
    if a.cmd == "rules":
        print(json.dumps({"rules": RULES, "holm_families": HOLM_FAMILIES,
                          "csv_schema": CSV_SCHEMA, "ukb_field_map": UKB_FIELD_MAP,
                          "rules_sha256": rules_hash()}, indent=2))
    elif a.cmd == "run":
        print(json.dumps(asdict(run_csv(a.pid, a.csv)), indent=2))
    else:
        res = calibrate(a.reps, a.seed)
        os.makedirs(a.out, exist_ok=True)
        with open(os.path.join(a.out, "calibration_results.json"), "w") as f:
            json.dump(res, f, indent=2)
        with open(os.path.join(a.out, "calibration_report.md"), "w") as f:
            f.write(report_md(res) + "\n")
        print(f"\nWrote calibration_results.json and calibration_report.md to {a.out}")


if __name__ == "__main__":
    main()
