# ERES-HYP-IDLOSS-TEST-2026-001 v0.2 · Complete Package

Test instrument for **ERES-HYP-IDLOSS-2026-001 v0.8**, the Identifiability Loss and Recovery Hypothesis.

It runs every prediction (P1–P16), including the noise-control tests P15 and P16, under its pre-registered decision rule and proves, on synthetic data, that each test confirms real effects and stays quiet on null data. Synthetic results certify the test, not the hypothesis.

## Quick start

Requires Python 3.9+, numpy, scipy, scikit-learn.

```
python test_eres_idloss.py                      # unit checks
python eres_idloss_test.py rules                # frozen rules, CSV schema, UK Biobank field map, rules hash
python eres_idloss_test.py calibrate --reps 100 # power and false-call rates (about 7 minutes)
python eres_idloss_test.py run P12 data.csv     # one prediction on real data
```

## Files

- `eres_idloss_test.py`: harness (estimators, decision rules, synthetic worlds, calibration, CSV adapters)
- `test_eres_idloss.py`: unit testkit
- `calibration_results.json`, `calibration_report.md`: calibration output for seed 20261101
- `ERES-HYP-IDLOSS-SYN-2026-001_v0.8_Synopsis.pdf`: synopsis in ERES Story Format (start here)
- `ERES-HYP-IDLOSS-2026-001_v0.8.pdf`: the hypothesis under test, with the noise data-reach and SEPLTA H&E noise-control analysis
- `ERES-HYP-IDLOSS-TEST-2026-001_v0.2.md` / `.pdf`: the test instrument
- `fig1_noise_data_reach_loop.svg`, `fig2_calibration.svg`: figures
- `_SUBMISSION_SEO.md`: title, abstract, keywords and post text for Zenodo, ResearchGate and LinkedIn
- `MANIFEST.json`: SHA-256 of every file

## Credits and license

Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics. Spectral methods: Stergios Pellis. Drafting assistance: Claude (Anthropic). CC-BY 4.0.
