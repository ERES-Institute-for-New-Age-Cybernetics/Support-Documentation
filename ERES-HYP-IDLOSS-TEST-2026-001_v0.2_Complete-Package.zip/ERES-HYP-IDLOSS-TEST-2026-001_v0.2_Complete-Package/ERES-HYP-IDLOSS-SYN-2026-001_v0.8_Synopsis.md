# What Noise Tells Us About Our Environment

## The ring in our ears as a record of the world we live in, and the case for controlling it

<div class="source">
<strong>Source paper:</strong> ERES-HYP-IDLOSS-2026-001 v0.8, <em>Identifiability Loss and Recovery Hypothesis</em> (24 pp., included in this package as ERES-HYP-IDLOSS-2026-001_v0.8.pdf)<br>
<strong>Test instrument:</strong> ERES-HYP-IDLOSS-TEST-2026-001 v0.2 (included)<br>
<strong>Public record:</strong> [ZENODO DOI — PENDING] · [RESEARCHGATE LINK — PENDING]
</div>

**Synopsis ID:** ERES-HYP-IDLOSS-SYN-2026-001 v0.8 · **Date:** 1 November 2026 · **Author:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics

---

## Abstract

Noise is a measurement of the environment that is already being taken everywhere, and the human ear keeps its own record of it. Tinnitus, the ringing that affects about one adult in seven worldwide, stores the cumulative noise dose a body has lived through. This synopsis summarises an ERES hypothesis and its test instrument. The hypothesis reads that ring in two directions: as a marker of the body's loss of resilience with age, and, in reverse, as a sentinel of environmental conditions. It defines what noise can report about the environment (its data-reach), analyses the need for noise control across six SEPLTA domains with their History and Environment, and proposes two new tests: night-time noise should predict tinnitus more strongly than daytime noise (P15), and falling noise should be followed by falling tinnitus (P16). Every prediction is pre-registered and runs in a calibrated test harness. On synthetic data, each test reliably confirms effects that are present and rarely claims effects that are absent. No result is yet evidence about people; the first real test needs only UK Biobank's tinnitus and home-noise records.

**Keywords:** environmental noise, noise pollution, tinnitus, noise control, environmental sentinel, night-time noise, UK Biobank, WHO noise guidelines, Noise Control Act, SEPLTA, ERES Institute, pre-registration, falsifiable hypothesis, public health, acoustic monitoring

---

## Introduction

**What noise tells us.** Noise is not only a nuisance. It is a signal, and its reach is unusually wide. One kind of measurement reports on human activity, wildlife, ecosystems and human health at once:

| Reach | What noise reports | Evidence |
| --- | --- | --- |
| Human activity | Traffic, industry, flights | Human-made seismic noise fell by up to 50% worldwide in the 2020 lockdowns, tracking mobility data (Lecocq et al., *Science* 2020) |
| Wildlife | Stress in animals that rely on hearing | When shipping stopped after 11 September 2001, right-whale stress hormones fell with the underwater noise (Rolland et al., 2012) |
| Ecosystems | Condition of plants and habitats | Stressed plants emit ultrasonic clicks (Khait et al., *Cell* 2023); reef soundscapes report reef health |
| Population health | Heart disease, sleep loss, children's learning | Over 20% of Europeans live above EU transport-noise limits, at a cost of at least €100 billion a year (EEA 2025) |
| Personal history | The dose each body has taken | Tinnitus affects 14.4% of adults, over 740 million people (Jarach et al., *JAMA Neurology* 2022); 2.5 million US veterans are compensated for it |

**The value of this data-reach.** Noise maps show where sound is. Tinnitus shows what the sound did. Joined in the same people, they turn an annoyance into a measured relation between exposure and harm, which is the form of evidence that policy, law and medicine act on.

<figure><img src="fig1_noise_data_reach_loop.svg" alt="Noise data-reach loop: environment, body, data, tests, noise control, guard"><figcaption>Figure 1. The noise data-reach loop. The environment reaches the body, the ring records the dose, data are joined, P12–P16 test the link, and noise control closes the loop under a guard against shifting noise onto others.</figcaption></figure>

**The hypothesis in brief.** Health is a body whose own signals still identify one clear state; aging is the loss of that; improvement is the return. The tinnitus ring is read as "Heard − Present": what a person hears that the environment is not supplying. Four hypotheses follow, each with pre-registered tests:

| | Claim | Key tests |
| --- | --- | --- |
| H1 | Slower physiological recovery predicts worse hearing in noise and weaker cognition | P1–P3, P7, P10 |
| H3 | Tinnitus is a sentinel of environmental exposure | P12–P14 |
| H4 | Lowering noise, above all at night, lowers the tinnitus burden | P15, P16 |
| H2, H2x | Mechanism of the ring, and exploratory readings | P5, P6, P8, P9 |

---

## Conclusions

**Noise control is needed, and the need holds in every SEPLTA domain.**

| Domain | History | Environment now | Control need |
| --- | --- | --- | --- |
| Social | Noise treated as nuisance, not exposure | Burden falls on dense, low-income, roadside areas | Aggregate noise and tinnitus maps; residents told first |
| Economic | Costs carried by households and health systems | At least €100 billion a year in Europe | Polluter pays; fund insulation and quieter surfaces |
| Political | EU goal: 30% fewer chronically disturbed by 2030 | EEA: unlikely without new measures; only ~3% fall 2017–2022 | Night-noise targets with yearly public reporting |
| Legal | US Noise Control Act 1972; federal noise office defunded 1981–82 | July 2026: a US federal court found the EPA unlawfully failed its duty for over 40 years | Restore implementation; measured exposure–harm evidence |
| Technical | Sparse monitors, modelled maps | WHO limits: road 53 dB Lden, 45 dB night | Dense monitoring; quieter tyres, surfaces, engines; night curfews |
| Administrative | Responsibility split across agencies | US regulation left to states and cities since 1982 | One accountable office joining noise, health and tinnitus data |

**The missing piece is measurement in the same people.** Each domain argues for control, but none yet has the dose–harm link measured where exposure and outcome sit side by side. The hypothesis supplies that test: P12 (dose–response), P14 (reading the environment back from tinnitus), P15 (night versus day) and P16 (change in noise, change in ring).

**The test instrument is ready.** The harness (v0.2) runs all sixteen predictions under their pre-registered rules. On synthetic data, the primary tests confirm a built-in effect in 84%–100% of runs and falsely confirm on null data in at most 2%. The noise-change test P16 reaches power 1.00. The night-versus-day test P15 is harder, because night and day noise move together: it needs roughly 120,000 people, and UK Biobank asked 172,385 about tinnitus. The noise-control tests are included with the same discipline. These results certify the test, not the hypothesis.

**Next step.** Apply for UK Biobank tinnitus (fields 4803, 4814) and home-noise (24022, 24023) data. P12 and P15 can then run on the 172,385 people asked about tinnitus at baseline, matched to home-noise estimates, without any new recording.

---

## Historical Notes

- **1972:** The US Noise Control Act directs the EPA to protect public health from noise; the Office of Noise Abatement and Control (ONAC) follows.
- **1981–82:** ONAC is defunded; noise regulation passes to states and cities, and federal limits stay frozen at their 1970s levels.
- **2002:** The EU Environmental Noise Directive requires strategic noise maps and action plans.
- **2018:** WHO publishes the Environmental Noise Guidelines for the European Region, with night limits for road, rail and aircraft noise.
- **2020:** Lockdowns cut human-made seismic noise by up to 50%, the longest global quiet period on record, showing noise as a real-time measure of human activity.
- **2022:** The first global meta-analysis puts tinnitus at 14.4% of adults.
- **2025:** The EEA reports Europe off track for its 2030 noise target.
- **July 2026:** A US federal court rules that the EPA unlawfully failed to carry out the Noise Control Act; remedies are pending.
- **Sep–Oct 2026:** Stergios Pellis publishes spectral monographs on ringdown, identifiability and instability, which supply the measurement method.
- **1 Nov 2026:** ERES-HYP-IDLOSS-2026-001 reaches v0.8 and its test instrument reaches v0.2.

---

## Credits

- **Hypothesis, ERES framing, Voice equation and SEPLTA H&E method:** Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221.
- **Spectral methods:** Stergios Pellis, ORCID 0000-0002-7363-8254, cited as on his own title pages. The multiscale estimator in the harness is an ERES implementation of his construction, not his code.
- **Drafting and analysis assistance:** Claude (Anthropic).

---

## References

1. ERES-HYP-IDLOSS-2026-001 v0.8, *Identifiability Loss and Recovery Hypothesis.* ERES Institute, 1 Nov 2026.
2. ERES-HYP-IDLOSS-TEST-2026-001 v0.2, test instrument. ERES Institute, 1 Nov 2026.
3. World Health Organization Regional Office for Europe. *Environmental Noise Guidelines for the European Region* (2018).
4. European Environment Agency. *Environmental noise in Europe 2025*, Report 05/2025 (corrigendum March 2026). https://www.eea.europa.eu/en/analysis/publications/environmental-noise-in-europe-2025
5. Jarach, C. M. et al. Global prevalence and incidence of tinnitus: a systematic review and meta-analysis. *JAMA Neurology* (2022).
6. Lecocq, T. et al. Global quieting of high-frequency seismic noise due to COVID-19 pandemic lockdown measures. *Science* 369, 1338–1343 (2020).
7. Rolland, R. M. et al. Evidence that ship noise increases stress in right whales. *Proceedings of the Royal Society B* (2012).
8. Khait, I. et al. Sounds emitted by plants under stress are airborne and informative. *Cell* (2023).
9. Noise Control Act of 1972 (42 U.S.C. 4901 et seq.); Silberner, J. Why scientists who study noise pollution are calling for more regulation. NPR/Undark, 1 Jul 2024.
10. Quiet Communities v. EPA, U.S. District Court for the District of Columbia, ruling July 2026.
11. US Department of Veterans Affairs, compensation recipients by disability, FY2021.
12. UK Biobank data fields 4803, 4814, 20019, 20021, 24022, 24023. https://biobank.ndph.ox.ac.uk
13. Pellis, S. *Decoding the Hidden Spectrum of Black-Hole Ringdown* (4 Sep 2026); *The Spectral Foundations of Quantum Many-Body Dynamics* (25 Oct 2026); *The Spectral Origin of Physical Instability* (28 Oct 2026).

---

## License

CC-BY 4.0. Free to share and adapt with attribution to the ERES Institute for New Age Cybernetics, and to Stergios Pellis for the spectral methods.
