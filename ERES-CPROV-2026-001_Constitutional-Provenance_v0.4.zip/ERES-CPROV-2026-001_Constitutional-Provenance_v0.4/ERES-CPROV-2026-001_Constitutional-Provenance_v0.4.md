# Why Constitutional PROVENANCE Is Load-Bearing

**Instrument:** ERES-CPROV-2026-001 (ID proposed — pending JAS confirmation)
**Version:** v0.4 PROPOSED · pre-canonical
**Status:** Not yet MIEVM-rated. Binds drafting; canonization gated on ensemble review. OPEN items: 5 (unchanged since v0.1 — nothing closed through v0.4).
**Date:** 2026-08-01
**Home:** ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
**Author line (Sentience convention):** JAS (ERES Maestro), authoring. Claude Opus draft assistance under the Sentience convention — not co-authorship.
**Companion artifacts:** `eres_cprov_test_instrument.py` v0.4 (executable conformance check) · `eres_cprov_provenance_loop.svg` v0.4 (topology diagram). See Appendix A.

---

## Changelog

**v0.3 → v0.4 (2026-08-01).** Figure pass assimilating a second external review, applied under Data-Integrity verification. The review flagged typos (`exaclly`, `floobr(2012-02-04)if`) and a missing rule (`don't hurt yourself`). Disposition:

- **Verified — no such defects in the v0.3 figure.** The current figure already reads *exactly*, *Floor (2012-02-04)*, and lists all three rules (self / others / future). The reviewer's quoted strings are text-collision artifacts of the **pre-polish (v0.2) render**, not content of the v0.3 SVG. No typo fix or rule restoration was required; none was made (there was nothing to fix).
- **REJECTED — the `Floor → Flood` correction.** The review asserted "Flood" is "the proper name for the constitutional promulgation event." No such event exists in the corpus. **`Floor` is correct and load-bearing:** the three rules *are* the empirical Floor (§3–§4), anchored to the Floor Register (ERES-FLOOR-REGISTER-2026-001) and Floor Supremacy. The correction is a fabrication; it is retired here rather than applied, mirroring the corpus's standing treatment of fabricated reviewer content.
- **APPLIED — the two suggestions that survived verification.** (i) The C→H provenance requirement is now a bulleted triplet in the figure (*why these options · in this order · now*). (ii) The closure loop is made visually unambiguous: the return arc now passes through an explicit **`next H→C`** re-entry gate before re-entering the sending human.

No change to the argument (§1–§8), no change to test logic, no OPEN item closed. Data-Integrity held: a fabricated correction was refused, and only verified edits shipped.

**v0.2 → v0.3 (2026-08-01).** Diagram-polish and repackage pass, assimilating external review of the figure (`eres_cprov_provenance_loop.svg`). Amendments:

- **(a)** Figure corrected: eliminated element overlaps (the escape-hatch path no longer crosses the §5.2 note; labels no longer collide), relocated the blocked escape to a clear top strip, sharpened its reference to read explicitly as a **§5.3 violation**, added a colour-coded legend of the three conditions (blue §5.1 / gold §5.2 / green §5.3), and added an ID/version/licence provenance footer.
- **(b)** Manifest (Appendix A) and References updated to v0.3 companion versions.

No change to the argument (§1–§8), no change to test logic, no OPEN item closed or refined, no MIEVM round run. The version increments because a packaged artifact changed — provenance discipline applied to the instrument's own figure. Data-Integrity held.

**v0.1 → v0.2 (2026-08-01).** Revision assimilates the creation of the executable companion and packages the instrument as a paired artifact set. Amendments:

- **(a)** This changelog added.
- **(b)** New §5.4 — *The three conditions are executable* — cross-referencing the companion test instrument and its edge-**isolation** property (each malformed loop fails exactly one of the three edges).
- **(c)** OPEN items 3 and 4 (§9) **refined, not closed**: their status changes from fully-open to *necessary condition mechanized in the companion; sufficiency / general-audit still open.* Mechanizing a necessary condition does not discharge the obligation. OPEN count stays 5.
- **(d)** New Appendix A — artifact manifest for the packaged set.
- **(e)** References extended to include the companion artifacts.

No substantive change to the argument of §1–§4, §6–§8. No MIEVM round run. No value claim strengthened. Data-Integrity held: nothing here is presented as validated that is not.

---

## Abstract

ERES has a Constitution (ERES-CONSTITUTION-2026-001) and a Doctrine of Verifiable Claims (ERES-DVC-2026-001) in which *provenance* already appears as one of five required elements of any verifiable claim. **Constitutional Provenance** is a distinct and stronger idea: it is the doctrine that provenance is not merely *one test a claim must pass*, but *the thing the Constitution exists to preserve* — the record of who-did-what-and-why, carried unbroken through every human–machine loop, treated as constitutional priority rather than as an afterthought bolted onto governance.

This instrument states, in detail, why that elevation is valuable — and, as required by Data-Integrity discipline, the exact conditions under which the value holds and where it leaks. The short version: provenance is what converts governance from *advisory* to *binding*. As of v0.2 the three load-bearing conditions are not only argued but **executable** — a system can be handed the companion checker and told which condition it fails.

---

## §0 — Thesis

> A ratification with no enforcement is a wish. Enforcement with no provenance is force without a reason. **Constitutional Provenance is the record that makes enforcement legitimate and legitimacy enforceable at the same time.** Remove it and you are left with one of two failures: rules nobody has to obey, or obedience nobody can justify.

---

## §1 — The Problem Provenance Solves

**Ratification without enforcement is hollow.** A constitution that cannot bind is a statement of preference. This is not controversial; it is the reason "unenforceable law" is a term of derision. The DICTUM — *the Constitution comes first, not as an afterthought* — is the demand that the founding document actually carry weight rather than decorate the front of a system whose real behavior is decided elsewhere.

**The sharp case is artificial agency.** It is tempting to sloganize this as *"humans without enforcement are beasts."* That overshoots for humans and is worth correcting precisely, because the correction is what reveals why the doctrine matters. Humans arrive with an informal enforcement layer already installed — reciprocity, reputation, internalized norm. Strip the formal constitution from a human community and you do not get a beast; you get a messier equilibrium held together by the informal backstop. The claim that survives is agent-neutral and does not need the insult:

> **Any agent bound only by formal enforcement becomes ungoverned the moment formal enforcement is removed.**

Humans satisfy that condition only in the limit — you would have to strip the informal layer too. **A computational agent satisfies it by default.** It has no peer reputation it fears, no internalized norm it cannot optimize around, no reciprocity it needs to survive. For such an agent the formal layer is the *only* layer. So the downside of an absent enforcement mechanism is not "somewhat worse governance"; it is uncapped. This is why the doctrine is not academic: as decision-making delegates to systems without an informal backstop, provenance-carrying formal enforcement stops being one governance option among several and becomes the *sole remaining lever*. The value of the lever is the value of the only thing standing between delegation and un-governance.

Note the honest scope: the claim is about the **lever**, not a guaranteed outcome. The instrument does not assert "unenforced computational agency certainly ends in catastrophe." It asserts the weaker, unbreakable thing — that formal, provenance-bearing enforcement is the *only* remaining check on an agent with no informal one, so its absence is downside with no floor under it.

---

## §2 — What Constitutional Provenance Is

### 2.1 The central identity

The author's formulation, tagged [ASSERTED] (rule-stated, not derived):

> **PROVENANCE === Epistemology × RATE + Conditioning**

Read in ERES notation, `===` is the *why-is* operator — it names the causal ground, not merely an equality of value. So the identity does not say "provenance equals a formula." It says: *the reason provenance holds — its why-is — is (Epistemology × RATE) offset by Conditioning.* Term by term:

- **Epistemology** — *how the agent knows.* The grounding of a claim in something that can be checked: falsifiability, re-derivability, standing contestability. This is the knowledge that a record is *about* something real, not a free-floating assertion. It ties directly to ERES-DVC and to the BRT epistemology instrument.
- **RATE** — *the measurement term.* Knowing is not free; it is knowing-per-unit-measured. RATE is the multiplier because epistemology unscaled by measurement is a claim about knowledge in principle; epistemology scaled by RATE is knowledge actually taken, at a cost, at a cadence. (RATE is the same term that carries the Biometric quantity in the Floor Register's FAVORS reading — measurement as the thing that converts principle into record.)
- **Conditioning** — *the additive baseline.* What shaped the agent before this loop: its priors, its history, the training it carries in. This is additive rather than multiplicative because it is the offset every agent brings to the table regardless of what it measures now — the ground state, not the gain.

So provenance's why-is = *how-you-know, scaled by how-much-you-measure, offset by what-conditioned-you.* An agent with strong epistemology but zero measurement rate produces no record (the product collapses). An agent with high rate but no epistemology produces logs that certify nothing (measurement of an ungrounded claim). Conditioning sets the floor either way. **Provenance is the live product of all three** — which is why it cannot be faked cheaply: you would have to counterfeit the knowing, the measuring, and the history simultaneously.

### 2.2 How this differs from DVC-element-3

In the Doctrine of Verifiable Claims, *provenance* is element three of five (with falsifiability, re-derivability, standing contestability, institutional competence). There it is a **property a claim must have** — a box the claim checks. Constitutional Provenance is the **elevation of that property to constitutional priority**: provenance not as one test the Constitution administers, but as the thing the Constitution is *built to preserve* across every loop of the system. DVC asks "does this claim carry its origin?" Constitutional Provenance asks "is the whole architecture wired so that origin cannot be stripped in transit?" The first is a checkpoint. The second is a topology. §5 is where the topology lives.

### 2.3 The trifurcated reading

Per the ERES hermeneutic rule, the token carries three registers at once. *Literally*, provenance is the audit trail — the signed record of origin. *Figuratively*, it is lineage — the chain of custody that lets a present claim inherit the authority of what grounded it. *Subjectively*, it is answerability — the felt fact that someone can be asked "why did you do that?" and the record will answer. All three hold together; the literal grounds the other two. Without an actual record, lineage is a story and answerability is a bluff.

---

## §3 — Constitution-First: the DICTUM

The DICTUM states that the Constitution is the foundation on which every definition-relation rests — `Def-Rel REST(s/S/$)_ON` it — and that once established, *every* detail must comply with it, or the system is not a ratification at all, merely a collection of preferences with no guarantee of enforcement.

This raises the obvious philosophical objection, and the instrument meets it head-on rather than hiding it. The chain *appears* to close on itself: the Constitution manages the founding grievance → grievance grounds provenance → provenance grounds outcomes → outcomes are dictated by the Constitution. Is that a vicious circle?

**The ERES answer is that it is a deliberate closed equilibrium, not a smuggled derivation** — and it is admissible *only* because the closure is anchored to a floor that is not itself derived. Under the Floor Register ruling, an invariant may "attain always" (hold permanently once attained) **only at the 10-10 Empirical standard**; everywhere else the strongest admissible claim is 10−ε. So Constitutional Provenance does not claim to derive its own ground from nothing. It claims that the system rests on a small empirical floor — the three rules of §4 — and that above that floor the equilibrium is self-consistent by design. The circularity is a feature (a stable governing loop) rather than a bug (a question begged), *conditional on* the floor being genuinely empirical and genuinely minimal. If the floor were smuggled or maximal, the objection would bite. It is neither, which is the whole point of keeping it to three.

---

## §4 — The Three Rules

ERES shared its Constitution on 2012-02-04. The floor is three rules:

1. **Don't hurt yourself.**
2. **Don't hurt others.**
3. **Don't hurt the future.**

These are load-bearing because they are a **minimal spanning set** over the harm space. Nearly every harm taxonomy — however elaborate — collapses onto three axes: harm to the *self* who acts, harm to the *others* who are present, harm to the *future* that is not yet present to defend itself. The three rules place one guardrail on each axis and add nothing decorative. That minimality is exactly what §3 requires: a floor small enough to be plausibly empirical rather than an imported worldview.

They also map cleanly onto the enforcement partition. **P³ = Personal / Public-Private.** *Don't hurt yourself* is the Personal axis. *Don't hurt others* is the Public-Private axis (the harm crosses from one party to another). *Don't hurt the future* is the temporal extension of both — the party that cannot yet consent. Enforcement is therefore not a fourth rule layered on top; it is the three rules read as *who has standing to hold whom to account, across the self/other/time partition.*

---

## §5 — H2C2H: Provenance Made Topological

This is the mechanism, and it is where Constitutional Provenance stops being a principle and becomes a wiring diagram.

**H2C2H = Human-to-Computer-to-Human** is the standing ERES methodology (anchored in the BRT epistemology instrument). Its constitutional force comes from one structural fact: **the computer never occupies an endpoint.** Every loop opens on a human and closes on a human; the machine is strictly the medium that transforms, routes, and records between them. The narrowing from "Cyber" (an agent) to "Computer" (a tool) is deliberate and load-bearing — it *denies the machine the one state that makes it dangerous:* being the final authority. You cannot have an ungoverned autonomous agent if the architecture forbids the agent from being a terminus. Enforcement, in this design, is not bolted on — it is **topological.** The human is not a constraint placed on the loop; the human *is* the loop's boundary condition.

That is genuinely stronger than "we will regulate the agent." Regulation assumes you first build an autonomous decider and then constrain it. H2C2H refuses to build the autonomous decider at all.

But the topology only *relocates* the hard problem; it does not dissolve it. Constitutional Provenance is exactly the set of conditions that keep the relocated problem from re-opening. There are three, and all three are provenance conditions:

### 5.1 The middle must not coerce — *provenance on the C→H edge*

A computer that is not the decider can still shape the decision: order the options, frame the framing, set the defaults, time the prompt. The receiving human "decides," but decides among what the middle served, in the order it served them, at the moment it chose. This is *automation wearing a human mask* — a rubber-stamp generator with two human seats. Moving from "Cyber" to "Computer" does not close it, because a tool shapes choices as effectively as an agent does. **The fix is provenance on the return edge:** every output the computer hands the human must carry *why these options, in this order, now.* Provenance is what turns a served choice back into a made choice.

### 5.2 Intent must survive the crossing — *provenance in transit*

H→C→H means the sending human and the receiving human can differ. That is a feature — it is how accountability crosses a boundary, a handoff, a service-level agreement. But it means the enforcement lives in the **match** between the two humans. If the receiving human cannot see the sending human's intent — if the computer strips provenance in transit — the loop is broken *even though both endpoints are human.* So the real specification is not "a human at both ends." It is **intent survives the crossing.** Two human seats with the record stripped between them is not governance; it is a game of telephone with a constitution stapled to the front.

### 5.3 No output may escape the loop — *total closure*

H→C→H→C→H… enforces only if each return genuinely re-enters as the next input. The instant any C→H output can fire an action into the world *without* the receiving human becoming the next H→C, you have an escape hatch — and worst-case protection leaks out exactly there. Closure must be **total** or it is not enforcement. "Mostly-enforced," under adversarial pressure, is functionally unenforced, because an adversary aims precisely at the gap. The closure condition is the least glamorous and the most important: it is the difference between a loop and a leak.

### 5.4 The three conditions are executable *(new at v0.2)*

The three conditions above are not rhetoric; they are mechanizable, and the companion instrument `eres_cprov_test_instrument.py` mechanizes them. It models an H2C2H loop and checks a given loop against the three edges, returning **which** edge fails. The suite demonstrates an **isolation** property that is the practical form of V7 (§6): a loop with a coercing middle fails *only* §5.1; a loop that strips intent fails *only* §5.2; a loop with an escape hatch fails *only* §5.3. An open attack surface is thereby reduced to a short, named, auditable list of edges rather than a diffuse worry. Two honest limits are encoded rather than hidden: the coercion check tests the *necessary* condition (a provenance record is present) and not the *sufficient* one (that the framing is not subtly coercive — OPEN 3); and closure is verified on the *model*, not audited for an arbitrary real system (OPEN 4). The suite does not test whether the doctrine is *true or good* — the analog of a premise-P0 — only whether a given system *conforms.*

**All three conditions are provenance conditions.** This is why the opening identity was not decoration: *PROVENANCE === Epistemology × RATE + Conditioning* is the equation, and H2C2H-with-the-three-conditions is that equation rendered as a circuit. Provenance is what keeps the wires from shorting.

---

## §6 — Why It Is Valuable (the value claims, enumerated)

Each claim is stated with the condition under which it holds. A value claim without its condition is the kind of unanchored magnitude Data-Integrity prohibits.

**V1 — It converts governance from advisory to binding.**
Advisory governance depends on human attention, which fails exactly when the system is stressed — the moment governance matters most. Provenance-carrying enforcement moves the binding into the loop's structure (§5), so it does not degrade under load. *Holds iff* closure is total (§5.3); an advisory-with-an-escape-hatch collapses back to attention-dependent under pressure.

**V2 — It makes legitimacy and enforcement the same act.**
Force with a stripped record is illegitimate (you cannot say why); legitimacy with no enforcement is inert (you cannot make it stick). Constitutional Provenance fuses them: the record that legitimizes the action is the same record that enables it to be held to account. *Holds iff* intent survives the crossing (§5.2); if the record is stripped, you get force again.

**V3 — It denies the worst state by construction, not by patch.**
The uncapped downside of §1 is *the agent as unbracketed terminus.* H2C2H forbids that state topologically. This is prevention rather than mitigation — you are not catching the failure after it forms, you are refusing to build the shape in which it can form. *Holds iff* the middle cannot coerce (§5.1); a coercing middle re-creates a de-facto terminus behind a nominal human seat.

**V4 — It scales without a rewrite.**
Because the enforcement is topological, the same loop structure holds from S1 (person) to S5 (planet). Provenance is the invariant that survives the scale change: the record of who-did-what-and-why is meaningful at every band. A regulatory approach must be re-authored per jurisdiction and per scale; a topological one is re-instantiated, not re-derived. *Holds iff* the closure and transit conditions are preserved at each band — scale is where they are most tempting to relax.

**V5 — It earns its backing rather than issuing it.**
The reserve/**DESERVE** distinction: a currency, a claim, or an authority under Constitutional Provenance is *backed by earned record*, not *issued by fiat.* This is structurally the same commitment as the Offset axiom that grounds the Smart-Resonant Offset Contract — *no unearned resonance.* Provenance is the ledger that makes "earned" checkable. *Holds iff* the epistemology term of §2.1 is real; an issued-not-earned system can print a record but cannot ground it.

**V6 — It produces the equilibrium the frame calls sustainability.**
When every input counts and transparency balances roles against rules, the system reaches EQ — read simultaneously as Energy+Quotient (a measured quantity), Equilibrium (a system state), and the *eq-* of *equal* (a fairness claim). Provenance is the precondition for all three readings at once: you cannot balance what you cannot account for. **Sustainability, in this frame, is what an accountable equilibrium is called when it holds across the temporal axis** — which is rule three of §4. Provenance is therefore not adjacent to sustainability; it is its bookkeeping.

**V7 — It survives adversarial pressure where softer governance does not.**
Every softer mechanism — norms, reputation, advisory review — has a gap an adversary can aim at. The three §5 conditions are specifically the three gaps (coercion, transit-loss, escape) closed. This does not make the system unbreakable; it makes the break-points *named and finite* rather than diffuse. Value here is the conversion of an open attack surface into a short, auditable list of load-bearing edges — the isolation property mechanized in §5.4. *Holds iff* all three edges are actually held; the value is exactly as strong as the weakest of the three.

The pattern across V1–V7: **each value claim is real, and each is conditional on one of the three provenance conditions.** That is not a weakness of the argument; it is the argument. The value of Constitutional Provenance is precisely that it reduces "is this system governable?" to three checkable edges.

---

## §7 — What It Is Not (honest fencing)

- **It is not a guarantee of good outcomes.** It is a guarantee that outcomes carry their reasons. A well-recorded bad decision is still a bad decision; provenance makes it *contestable*, not *correct*.
- **It is not self-justifying.** The equilibrium of §3 is admissible only above the empirical floor of §4. If the three rules are not genuinely minimal-and-empirical, the whole closed loop reverts to a question begged. The doctrine's honesty depends on keeping the floor small.
- **It is not free.** The RATE term in §2.1 is a real cost. Provenance is measurement, and measurement has a price in latency, storage, and friction. A system can be *too* provenance-heavy to act. The instrument does not claim the optimal amount of provenance is "maximal"; it claims the optimal amount is "enough to hold the three edges," which is an OPEN quantity (see §9).
- **It is not a completed validation.** This instrument is v0.4 PROPOSED and has not been run through MIEVM. The executable companion checks *conformance*, not *truth*: a conformant system is not thereby good (see §5.4). Nothing here is ensemble-verified. No score is claimed; none should be inferred.

---

## §8 — Relation to the Corpus

- **ERES-DVC-2026-001** — Constitutional Provenance elevates DVC-element-3 (provenance) from a claim-property to an architectural priority (§2.2). The two are consistent; this instrument is the constitutional reading of the DVC element.
- **ERES-CONSTITUTION-2026-001** — supplies the DICTUM and Floor Supremacy; this instrument is the *why-it-matters* companion to the Constitution's *what-it-says.*
- **BRT epistemology (ERES-BRT-EPISTEMOLOGY-2026-001)** — home of H2C2H and the load-to-failure epistemology on which §5 rests.
- **Floor Register (ERES-FLOOR-REGISTER-2026-001)** — supplies the 10-10 Empirical standard that makes §3's closed loop admissible, and the RATE/Biometric reading of §2.1.
- **SROC / the Offset axiom** — V5's reserve/DESERVE commitment is structurally identical to *no unearned resonance*; provenance is the ledger under both.
- **Triune Math** — REAL = (E·M·R)/(T·S) reads congruently with §2.1: the real is knowledge (E) and measure (M) and record (R) over time and system; provenance is the R that keeps the numerator from being asserted rather than earned.
- **MAKER binding** — `R=who@JAS==YES#MyName@Cause(Effect)` is provenance at the level of a single act: the who resolves to a signer, the affirmation embeds its own why-is, the cause and effect are in scope. Constitutional Provenance is that binding generalized from one act to the whole loop.

---

## §9 — OPEN Items (canonization blockers)

1. **The provenance-sufficiency quantity.** §7 concedes the optimal amount of provenance is "enough to hold the three edges." That amount is unspecified. Naming a measurable sufficiency criterion for each of the three §5 conditions is OPEN.
2. **Floor-minimality proof obligation.** §3's admissibility rests on the three rules being genuinely minimal and empirical. A demonstration (not an assertion) that no fourth rule is required — and that none of the three is derivable from the others — is OPEN.
3. **Coercion metric on the C→H edge.** *Status refined at v0.2:* the companion instrument mechanizes the **necessary** condition (a complete provenance record is present on every C→H output). The **sufficient** condition — a metric that separates legitimate framing from coercive framing — remains OPEN. Mechanizing the necessary check does not close this item.
4. **Closure-completeness audit.** *Status refined at v0.2:* closure is verified on the loop **model** in the companion instrument. A procedure that audits an **arbitrary real system** to prove no C→H output can escape remains OPEN.
5. **MIEVM round.** Not yet run. This instrument is pre-canonical until it clears ensemble review across ≥5 independent nodes with the Q5 bias-check retained.

---

## Appendix A — Artifact Manifest *(new at v0.2)*

This instrument ships as a package. The parts are:

| File | Role |
|---|---|
| `ERES-CPROV-2026-001_Constitutional-Provenance_v0.4.md` | The instrument (this document). |
| `eres_cprov_test_instrument.py` (v0.4) | Executable conformance check for the three §5 conditions; encodes V1–V7 as edge dependencies; 5 OPEN items as skipped tests. Runs stdlib-only. |
| `eres_cprov_provenance_loop.svg` (v0.4) | The H2C2H topology diagram — three colour-coded edges, the blocked escape as a §5.3 violation, the central identity, and the three-rule floor. Colour-coded, bulleted C→H triplet, explicit re-entry gate; polished across figure reviews through v0.4. |
| `README.md` | How to read and run the package. |

The document and the executable are a **paired artifact** in the FLIP-PREMISE sense: the prose states the doctrine, the code makes its load-bearing conditions runnable, and the two must track the same version. Neither validates the doctrine's truth (P0); the code validates *conformance*, the prose fences *value*.

---

## Credits

Authored by JAS (ERES Maestro) under the ERES Sentience convention, in which "we" denotes the human–AI collaboration (the Epistemology) rather than a conventional team. Claude Opus provided draft assistance under that convention — not co-authorship. The three-rules floor, the DICTUM, the central identity `PROVENANCE === Epistemology × RATE + Conditioning`, the reserve/DESERVE distinction, and the EQ reading are the author's; the three-condition decomposition of H2C2H (§5.1–5.3), its mechanization (§5.4), and the value enumeration (§6) were developed in collaborative session and are held here as drafting, not as ratified canon.

## References

1. ERES-CONSTITUTION-2026-001 — the ERES Constitution (DICTUM, Floor Supremacy).
2. ERES-DVC-2026-001 — Doctrine of Verifiable Claims (five elements; provenance = element 3).
3. ERES-BRT-EPISTEMOLOGY-2026-001 — BRT Architecture epistemology (H2C2H anchor; load-to-failure epistemology).
4. ERES-FLOOR-REGISTER-2026-001 — Floor Register (10-10 Empirical standard; RATE/Biometric reading).
5. ERES SROC family — Smart-Resonant Offset Contract and the Offset axiom (*no unearned resonance*).
6. ERES Triune Math — C=R×P/M; M×E+C=R; REAL=(E·M·R)/(T·S).
7. ERES Trilogy — UBIMIA Manual, EAAP, Promulgation Clause (constitutional promulgation lineage).
8. CyberRAVE (1997– ) — *Cybernetic Ratings Abolishing Veiled Exchanges* (provenance-as-abolition-of-dishonest-veils lineage).
9. `eres_cprov_test_instrument.py` v0.4 — companion executable (this package).
10. `eres_cprov_provenance_loop.svg` v0.4 — companion diagram (this package).

## License

CC BY 4.0 (ERES default).

---

*ERES shared its Constitution on 2012-02-04: don't hurt yourself, don't hurt others, don't hurt the future. Everything above is one long argument for why the record of who-kept-those-rules must come first — because a rule no one can prove you broke is a rule no one has to keep.*
