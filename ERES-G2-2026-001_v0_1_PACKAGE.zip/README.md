# ERES-G2-2026-001 v0.1 — ERES G-2: Flying & Diving Cities

Gate-constructed Smart-City design in which BEST / SOUND / GOOD emerges as end-outcome.
Status: CONSTRUCTED DRAFT, author-side, not MIEVM-rated. Self-rate ~8.2 (below 8.5 / 9.0 gates).

## Contents
| File | Role |
|---|---|
| ERES-G2-2026-001_v0_1.md | Instrument (master) |
| eres_g2_testkit.py | Zero-dependency testkit, confirm + refuse per rule |
| RUN.txt | Captured run: 14 PASS / 0 FAIL / 4 SKIP, exit 0 |
| MANIFEST.json | SHA-256 of every file |

## Claim → test
| Claim (§) | Test |
|---|---|
| Mass/person binds air modules (§1.1) | T01 |
| No single fly+dive hull (§1.3) | T02 |
| GOOD floor gate (§4) | T03 |
| SOUND two-sided band (§4) | T04 |
| Return-to-base (§4) | T05 |
| Margin law m* = v·τ (§4) | T06 |
| BEST = bounded optimum (§4) | T07 |
| Min-composition (§4) | T08 |
| M/N line: floor on anchor (§3.3) | T09 |
| Staged promotion on measured data (§4) | T10 |
| Fused HINGE hulls, releasable docks (§3.1) | T11 |
| Anchor-tile binding (§3.3) | T12 |
| SROC Contact of Record (§3.3) | T13 |
| Nothing derived ⇒ none BEST (§4) | T14 |

## Run
`python3 eres_g2_testkit.py`

## Non-claims
No measured data. No physical component built. Footprint figures are declared ranges.

License: CCAL v2.1 / CC-BY 4.0
