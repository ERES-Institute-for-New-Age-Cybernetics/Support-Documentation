#!/usr/bin/env python3
"""
ERES-G2-2026-001 v0.1 -- companion testkit (zero-dependency, stdlib only)
"ERES G-2: Flying & Diving Cities" -- gate-constructed Smart-City design.

Tests STRUCTURE and the CONSTRUCTED physics envelope only. Every test is
confirm + refuse: a compliant case must pass and a violating case must fail.
Nothing here is measured; SKIPs mark load-bearing items that need real data.
Exit code 0 = all non-skipped tests pass.
License: CCAL v2.1 / CC-BY 4.0
"""
import math, sys

SEED = 20261025
RESULTS = []

def rec(tid, name, status, note=""):
    RESULTS.append((tid, name, status, note))

# ---------- declared constants (CONSTRUCTED; see instrument Sec. 5) ----------
LIFT_HE = 1.03          # kg lift per m3 helium, sea level
LIFT_H2 = 1.11          # kg lift per m3 hydrogen, sea level
RHO_AIR = 1.2           # kg/m3
RHO_SEA = 1025.0        # kg/m3
HE_WORLD_M3_YR = 1.6e8  # order-of-magnitude global helium output
MASS_PP_T = {"ground-city": 140.0, "submarine": 120.0, "THOW": 6.0, "airliner": 1.0}

# ---------- grade model (BEST/SOUND/GOOD as declared in Sec. 4) ----------
GRADES = ["BELOW", "GOOD", "SOUND", "BEST"]
def gmin(*gs):
    return min(gs, key=GRADES.index)

FLOORS = {"water_makeup_L": 30.0, "crop_m2": 20.0, "o2_closure": 1.0, "shelter_m3": 25.0}

def good_gate(m):
    """GOOD = every per-person floor met. Floors are additive minima, never averaged."""
    return (m["water_supply_L"] >= FLOORS["water_makeup_L"] and m["crop_m2"] >= FLOORS["crop_m2"]
            and m["o2_closure"] >= FLOORS["o2_closure"] and m["shelter_m3"] >= FLOORS["shelter_m3"])

def in_band(x, lo, hi):
    """Two-sided band: BOTH walls are failure (incoherence below, condensation above)."""
    return lo < x < hi

def margin(v, tau):
    """Sentry margin law m* = v * tau (drift rate x response latency)."""
    return v * tau

def rtb_ok(m):
    """Mission critical = able to return to base: reserve covers the path to the anchor tile plus margin."""
    return m["reserve"] >= m["rtb_cost"] + margin(m["drift"], m["tau"])

def sound_gate(m):
    return (good_gate(m) and in_band(m["water_recovery"], 0.85, 0.995)
            and in_band(m["load_frac"], 0.0, 0.95) and rtb_ok(m)
            and m["anchor_tile"] is not None and m["contact_of_record"])

def module_grade(m):
    if not good_gate(m):
        return "BELOW"
    if not sound_gate(m):
        return "GOOD"
    return "SOUND"   # BEST is only awarded at fleet level, by bounded optimum + DERIVED evidence

def city_grade(modules, derived_evidence=False):
    g = gmin(*[module_grade(m) for m in modules])
    if g == "SOUND" and derived_evidence:
        return "BEST"
    return g

def base_module(**kw):
    m = dict(medium="ground", water_supply_L=100, crop_m2=40, o2_closure=1.0, shelter_m3=40,
             water_recovery=0.95, load_frac=0.70, reserve=10.0, rtb_cost=4.0, drift=1.0, tau=2.0,
             anchor_tile=(36.48, -94.23), contact_of_record=True, mass_pp_t=6.0,
             seam="HINGE-fused", dock="releasable", survival_requires_module=False)
    m.update(kw)
    return m

# ---------- tests ----------
def T01():
    V = MASS_PP_T["ground-city"] * 1000 * 10_000 / LIFT_HE
    yrs = V / HE_WORLD_M3_YR
    Vt = MASS_PP_T["THOW"] * 1000 * 10_000 / LIFT_HE
    ok = 8.0 < yrs < 9.0 and Vt / HE_WORLD_M3_YR < 0.5
    rec("T01", "Air lift budget: ground-city mass needs ~8.5 yr world He at 10k people; THOW-class < 0.5 yr", "PASS" if ok else "FAIL",
        f"ground={yrs:.2f} yr, THOW={Vt/HE_WORLD_M3_YR:.2f} yr")

def T02():
    ratio = RHO_SEA / RHO_AIR
    single_hull_feasible = ratio < 10      # declared: a single hull cannot ballast across >10x mean-density change
    ok = ratio > 800 and not single_hull_feasible
    rec("T02", "Dual-medium: density ratio ~854:1 refuses a single fly+dive hull -> modular fleet", "PASS" if ok else "FAIL",
        f"ratio={ratio:.0f}")

def T03():
    ok = good_gate(base_module()) and not good_gate(base_module(crop_m2=10)) and not good_gate(base_module(o2_closure=0.9))
    rec("T03", "GOOD floor: compliant module admitted; any single missing floor refused", "PASS" if ok else "FAIL")

def T04():
    ok = (in_band(0.95, 0.85, 0.995) and not in_band(0.80, 0.85, 0.995)
          and not in_band(0.999, 0.85, 0.995))
    rec("T04", "SOUND band is two-sided: both walls fail (incoherence and condensation)", "PASS" if ok else "FAIL")

def T05():
    ok = rtb_ok(base_module()) and not rtb_ok(base_module(reserve=5.0))
    rec("T05", "Return-to-base: reserve >= path cost + m* passes; short reserve refused", "PASS" if ok else "FAIL")

def T06():
    ok = margin(0.02, 1.0) == 0.02 and margin(2.0, 3.0) == 6.0
    rec("T06", "Margin law m* = v*tau", "PASS" if ok else "FAIL")

def T07():
    # BEST = bounded optimum: argmin mass/person subject to SOUND, NOT argmax size/altitude
    cands = [base_module(mass_pp_t=t, load_frac=lf) for t, lf in [(1.0, 0.99), (6.0, 0.70), (20.0, 0.60), (140.0, 0.50)]]
    feasible = [c for c in cands if sound_gate(c)]
    best = min(feasible, key=lambda c: c["mass_pp_t"])
    maxer = min(cands, key=lambda c: c["mass_pp_t"])      # unconstrained minimizer ignores the band
    ok = best["mass_pp_t"] == 6.0 and not sound_gate(maxer)
    rec("T07", "BEST is bounded: unconstrained optimum breaches band; chosen = lightest SOUND design", "PASS" if ok else "FAIL",
        f"chosen={best['mass_pp_t']} t/p")

def T08():
    fleet = [base_module(), base_module(medium="sea"), base_module(medium="air", reserve=3.0)]
    ok = city_grade(fleet) == "GOOD" and city_grade(fleet[:2]) == "SOUND"
    rec("T08", "Min-composition: one non-SOUND module grades the whole city down (no averaging)", "PASS" if ok else "FAIL")

def T09():
    good = [base_module(), base_module(medium="air")]
    bad = [base_module(), base_module(medium="air", survival_requires_module=True)]
    def humane(fleet):
        return all(not m["survival_requires_module"] for m in fleet if m["medium"] != "ground")
    ok = humane(good) and not humane(bad)
    rec("T09", "M/N line: survival floor lives on the ground anchor; survival contingent on flying/diving refused", "PASS" if ok else "FAIL")

def T10():
    def promote(stage, prior_sound, measured):
        return stage == 0 or (prior_sound and measured)
    ok = promote(0, False, False) and promote(2, True, True) and not promote(2, True, False) and not promote(2, False, True)
    rec("T10", "Staged promotion: stage k needs stage k-1 SOUND on MEASURED data; synthetic cannot promote", "PASS" if ok else "FAIL")

def T11():
    def joint_ok(m):
        return m["seam"] == "HINGE-fused" and m["dock"] == "releasable"
    ok = joint_ok(base_module()) and not joint_ok(base_module(dock="HINGE-fused"))
    rec("T11", "HINGE register: fused HINGE builds hulls; module docks must stay releasable", "PASS" if ok else "FAIL")

def T12():
    ok = sound_gate(base_module()) and not sound_gate(base_module(anchor_tile=None))
    rec("T12", "LLPM: every mobile module bound to an anchor tile (base for RTB); unbound refused", "PASS" if ok else "FAIL")

def T13():
    ok = sound_gate(base_module()) and not sound_gate(base_module(contact_of_record=False))
    rec("T13", "SROC Contact of Record: no callable number -> module contract void, not SOUND", "PASS" if ok else "FAIL")

def T14():
    ok = city_grade([base_module()], derived_evidence=False) == "SOUND" and city_grade([base_module()], True) == "BEST"
    rec("T14", "Nothing DERIVED => none BEST: BEST requires derived + empirical evidence on top of SOUND", "PASS" if ok else "FAIL")

def SKIPS():
    rec("S1", "Real closed-loop life-support data (water/crop/O2) for any module", "SKIP", "needs measurement")
    rec("S2", "HINGE Phase-0 coupon (phononic + thermal spectrum)", "SKIP", "inherited from ERES-HINGE-WP-2026-001")
    rec("S3", "Lifting-gas choice He vs H2 vs hybrid (supply vs safety)", "SKIP", "OPEN design decision")
    rec("S4", "Independent >=5-node MIEVM round", "SKIP", "not run")

if __name__ == "__main__":
    for t in (T01, T02, T03, T04, T05, T06, T07, T08, T09, T10, T11, T12, T13, T14, SKIPS):
        t()
    w = max(len(r[1]) for r in RESULTS)
    print(f"ERES-G2-2026-001 v0.1 testkit  seed={SEED}  python={sys.version.split()[0]}")
    for tid, name, st, note in RESULTS:
        print(f"[{st:4s}] {tid:4s} {name}" + (f"  ({note})" if note else ""))
    P = sum(r[2] == "PASS" for r in RESULTS); F = sum(r[2] == "FAIL" for r in RESULTS); S = sum(r[2] == "SKIP" for r in RESULTS)
    print(f"\n{P} PASS / {F} FAIL / {S} SKIP")
    sys.exit(1 if F else 0)
