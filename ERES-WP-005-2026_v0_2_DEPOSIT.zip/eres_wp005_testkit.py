#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_wp005_testkit.py  (STDLIB EDITION -- zero dependencies)
============================================================
Pre-registered falsifiable test kit for ERES-WP-005-2026 v0.1 (DRAFT).

Reimplemented with NO third-party dependencies: the non-Hermitian complex
spectrum is computed by an internal shifted-QR eigenvalue solver (below),
not by numpy. This makes the kit byte-portable across MIEVM nodes and removes
any version-pinning question. Standard library only: cmath, math, hashlib, sys.

WHAT THIS CERTIFIES (and what it does NOT):
  CERTIFIES : the STRUCTURE of the WP-005 primitive mapping -- that a genuinely
              non-Hermitian Pellis-class error operator, whose eigenvalues are
              COMPUTED (not stipulated), reproduces the five Bentley primitives
              (P1-P5), that the exceptional point is the onset of instability,
              and that the spectral protection gap gives a PREDICTIVE LEAD over
              logical-survival collapse (the Pellis paper's central claim).
  DOES NOT  : establish empirical universality. Everything is synthetic. Per
              standing ERES rule, SYNTHETIC RESULTS CANNOT CONFIRM OR REFUTE the
              physical claim. This kit keeps WP-005 at its honest sub-9.0 grade.
              The 9.0 (Stergios) gate needs the real-hardware correlation
              rho_S = Corr(S_phi, P_logical) from the Pellis paper's own roadmap.

WHY IT AVOIDS THE CLIMATE-BRIDGE BLOCKER:
  The prior climate sim stipulated its spectrum directly and drifted it by a
  uniform constant, so no operator existed and the spectral difference was
  constant by construction. Here the spectrum is obtained by a GENERAL QR solver
  applied to an actual matrix-valued operator L(phi); eigenvalue migration is a
  computed consequence. Test T8 cross-checks the general solver against the
  closed-form exceptional-point eigenvalues -- proving computed, not stipulated.

Foundational operator mathematics: Dr. Stergios Pellis (Greece),
Pellis Spectral Operator Theory. ERES supplies the diagnostic-architecture casting.

Deterministic. Run:  python3 eres_wp005_testkit.py
Exit code 0 iff all pre-registered tests pass.
"""

import cmath
import hashlib
import math
import sys

SEED_TAG = "20260804"   # provenance tag (construction is fully deterministic)

# ===========================================================================
# Internal complex eigenvalue solver  (shifted QR with deflation, stdlib only)
# ===========================================================================
def _qr_decompose(A):
    """Modified Gram-Schmidt QR for a complex square matrix (list of lists)."""
    n = len(A)
    cols = [[A[i][j] for i in range(n)] for j in range(n)]
    qcols = []
    R = [[0j] * n for _ in range(n)]
    for j in range(n):
        v = cols[j][:]
        for i in range(j):
            r = sum(qcols[i][k].conjugate() * v[k] for k in range(n))
            R[i][j] = r
            v = [v[k] - r * qcols[i][k] for k in range(n)]
        nrm = math.sqrt(sum(abs(x) ** 2 for x in v))
        R[j][j] = nrm
        qcols.append([0j] * n if nrm < 1e-300 else [x / nrm for x in v])
    Q = [[qcols[j][i] for j in range(n)] for i in range(n)]
    return Q, R


def _matmul(A, B):
    n, p, m = len(A), len(B), len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(p)) for j in range(m)]
            for i in range(n)]


def _wilkinson_shift(A, m):
    """Complex shift from the trailing 2x2 of the leading m x m submatrix."""
    a, b = A[m - 2][m - 2], A[m - 2][m - 1]
    c, d = A[m - 1][m - 2], A[m - 1][m - 1]
    tr, det = a + d, a * d - b * c
    disc = cmath.sqrt(tr * tr - 4 * det)
    l1, l2 = (tr + disc) / 2, (tr - disc) / 2
    return l1 if abs(l1 - d) < abs(l2 - d) else l2


def eigvals(A, tol=1e-13, maxit=2000):
    """Eigenvalues of a complex square matrix via shifted QR + deflation.
    Eigenvalues only (correct even for defective matrices, e.g. at an EP)."""
    A = [row[:] for row in A]
    m = len(A)
    eig = []
    while m > 1:
        it = 0
        while it < maxit:
            it += 1
            if abs(A[m - 1][m - 2]) < tol * (abs(A[m - 2][m - 2])
                                             + abs(A[m - 1][m - 1]) + 1e-300):
                break
            mu = _wilkinson_shift(A, m)
            B = [[A[i][j] - (mu if i == j else 0) for j in range(m)]
                 for i in range(m)]
            Q, R = _qr_decompose(B)
            RQ = _matmul(R, Q)
            for i in range(m):
                for j in range(m):
                    A[i][j] = RQ[i][j] + (mu if i == j else 0)
        eig.append(A[m - 1][m - 1])
        m -= 1
    eig.append(A[0][0])
    return eig


# ===========================================================================
# Operator construction  (deterministic, physically faithful)
# ===========================================================================
# L(phi) = S - i*phi*D
#   Modes 0,1 form a PT-symmetry pair: degenerate coherent energy (0.0),
#   Hermitian coupling g=0.15, asymmetric leakage (1.0 vs 0.4). This yields an
#   EXACT exceptional point at phi_EP = 0.5, beyond which the dominant mode's
#   leakage runs away -- the EP IS the onset of logical instability, matching
#   the "critical spectral migration" of the Pellis QEC paper.
#   Modes 2..5 are well-separated benign background modes.

N = 6
GAMMA_C = 1.00          # critical leakage threshold (collapse boundary)
WARN_MARGIN = 0.20      # warning fires when Delta_phi < 0.20 * GAMMA_C
FAIL_LEVEL = 0.10       # logical failure := survival probability P_L < 0.10
_G = 0.15               # Hermitian coupling in the EP block
_BG_E = [-1.2, -0.9, 0.9, 1.2]      # background coherent energies
_BG_D = [0.10, 0.15, 0.15, 0.20]    # background leakage (all < block dominant)


def build_S():
    S = [[0j] * N for _ in range(N)]
    S[0][1] = S[1][0] = _G                      # degenerate energies + coupling
    for k in range(2, N):
        S[k][k] = _BG_E[k - 2]
    return S


def build_D():
    D = [[0j] * N for _ in range(N)]
    D[0][0] = 1.00
    D[1][1] = 0.40
    for k in range(2, N):
        D[k][k] = _BG_D[k - 2]
    return D                                     # diagonal PSD by construction


S = build_S()
D = build_D()


def L(phi):
    return [[S[i][j] - 1j * phi * D[i][j] for j in range(N)] for i in range(N)]


def spectrum(phi):
    lam = eigvals(L(phi))                         # COMPUTED, not stipulated
    E = [z.real for z in lam]
    Gamma = [-z.imag for z in lam]                # leakage rate >= 0 for decay
    return E, Gamma, lam


def protection_gap(phi):
    _, Gamma, _ = spectrum(phi)
    return GAMMA_C - max(Gamma)


def survival_probability(phi, t=1.0):
    # Logical loss is governed by the DOMINANT (worst) mode: the encoded qubit
    # fails when its fastest-leaking mode runs away.
    _, Gamma, _ = spectrum(phi)
    Lam = max(max(Gamma), 0.0)
    return math.exp(-Lam * t)


def min_eigenvalue_separation(phi):
    _, _, lam = spectrum(phi)
    return min(abs(lam[i] - lam[j])
               for i in range(N) for j in range(i + 1, N))


# ---------------------------------------------------------------------------
# Noise sweep
# ---------------------------------------------------------------------------
STEPS = 521
PHIS = [2.6 * k / (STEPS - 1) for k in range(STEPS)]
GAP = [protection_gap(p) for p in PHIS]
SURV = [survival_probability(p) for p in PHIS]
SEP = [min_eigenvalue_separation(p) for p in PHIS]


def first_index(pred_list):
    for i, ok in enumerate(pred_list):
        if ok:
            return i
    return None


# ===========================================================================
# Pre-registered tests
# ===========================================================================
results = []


def check(name, passed, detail):
    results.append((name, bool(passed), detail))


# T1 (P2 -- baseline stable)
check("T1 baseline stable (P2)",
      GAP[0] > 0.5 and SURV[0] > 0.7,
      "gap0=%.3f, surv0=%.3f" % (GAP[0], SURV[0]))

# T2 (P1/P3 -- computed migration; gap closes monotonically)
diffs = [GAP[i + 1] - GAP[i] for i in range(len(GAP) - 1)]
check("T2 gap closes monotonically under noise (P1/P3)",
      all(d <= 1e-9 for d in diffs) and GAP[-1] < GAP[0],
      "gap %.3f -> %.3f, max step %+.2e" % (GAP[0], GAP[-1], max(diffs)))

# T4 (P3 -- exceptional-point coalescence)
sep_min = min(SEP)
sep_at = PHIS[SEP.index(sep_min)]
check("T4 exceptional-point coalescence (P3)",
      sep_min < 0.15 and sep_min < 0.5 * SEP[0],
      "min separation %.4f at phi=%.3f (sep0=%.3f)" % (sep_min, sep_at, SEP[0]))

# T3 (P4/P5 -- LOAD-BEARING: spectral warning must lead logical failure)
i_warn = first_index([g < WARN_MARGIN * GAMMA_C for g in GAP])
i_fail = first_index([s < FAIL_LEVEL for s in SURV])
lead = (PHIS[i_fail] - PHIS[i_warn]) if (i_warn is not None and i_fail is not None) else None
check("T3 spectral warning leads logical failure (P4/P5) [LOAD-BEARING]",
      lead is not None and lead > 0,
      ("warn@phi=%.3f, fail@phi=%.3f, lead=%+.3f" % (PHIS[i_warn], PHIS[i_fail], lead)
       if lead is not None else "warning or failure never reached -- NULL"))

# T5 (negative control -- must NOT false-alarm)
def _benign_curves():
    dmax = max(D[k][k].real for k in range(N))
    scale = 0.25 / (dmax if dmax else 1.0)
    Db = [[D[i][j] * scale for j in range(N)] for i in range(N)]
    gaps, survs = [], []
    for p in PHIS:
        Lb = [[S[i][j] - 1j * p * Db[i][j] for j in range(N)] for i in range(N)]
        G = [-z.imag for z in eigvals(Lb)]
        gaps.append(GAMMA_C - max(G))
        survs.append(math.exp(-max(max(G), 0.0)))
    return gaps, survs

bgap, bsurv = _benign_curves()
check("T5 negative control does NOT false-alarm",
      all(g > WARN_MARGIN * GAMMA_C for g in bgap) and all(s > FAIL_LEVEL for s in bsurv),
      "benign min gap %.3f (>%.2f), min surv %.3f"
      % (min(bgap), WARN_MARGIN * GAMMA_C, min(bsurv)))

# T6 (R-1 invariant -- machine/human consent split; declared, not computed)
SIGNAL_CLASS = "machine"     # 'machine' (qubit/shaft) | 'human' (BERA)
R1_SATISFIED = False         # enabling legal layer does not yet exist
check("T6 R-1 machine/human gate honored",
      SIGNAL_CLASS == "machine" or R1_SATISFIED,
      "signal_class=%s, R1_satisfied=%s (human-signal run would be blocked)"
      % (SIGNAL_CLASS, R1_SATISFIED))

# T7 (determinism -- reproducible sweep)
GAP2 = [protection_gap(p) for p in PHIS]
check("T7 deterministic sweep (reproducible)",
      GAP2 == GAP,
      "gap sweep byte-identical on recompute (tag %s)" % SEED_TAG)

# T8 (SOLVER VALIDATION -- computed, not stipulated).
# The internal QR solver must reproduce the closed-form eigenvalues of the 2x2
# EP block, lam = -0.7*phi*i +/- sqrt(0.0225 - 0.09*phi^2), at several phi.
def _t8():
    worst = 0.0
    for phi in (0.0, 0.25, 0.5, 0.75, 1.2, 2.0):
        root = cmath.sqrt(0.0225 - 0.09 * phi * phi)
        analytic = [-0.7 * phi * 1j + root, -0.7 * phi * 1j - root]
        lam = eigvals(L(phi))
        for a in analytic:
            worst = max(worst, min(abs(a - z) for z in lam))
    return worst

t8_err = _t8()
check("T8 solver reproduces closed-form EP eigenvalues (computed, not stipulated)",
      t8_err < 1e-6,
      "max |QR - analytic| over phi grid = %.2e" % t8_err)


# ---------------------------------------------------------------------------
# Integrity + report
# ---------------------------------------------------------------------------
def self_sha256():
    try:
        with open(__file__, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except Exception:
        return "unavailable"


def main():
    print("=" * 72)
    print("ERES-WP-005-2026 v0.1  --  Pre-registered falsifiable test kit (STDLIB)")
    print("Pellis Spectral Operator (QEC) cast into the SCALULAR stack")
    print("Zero dependencies | modes N=%d | Gamma_c=%.2f | tag %s"
          % (N, GAMMA_C, SEED_TAG))
    print("=" * 72)
    n_pass = 0
    for name, passed, detail in results:
        if passed:
            n_pass += 1
        print("[%s] %s" % ("PASS" if passed else "FAIL", name))
        print("       %s" % detail)
    print("-" * 72)
    print("%d/%d pre-registered tests passed" % (n_pass, len(results)))
    print("source SHA-256: %s" % self_sha256())
    print("-" * 72)
    print("EPISTEMIC STATUS: synthetic structure certified; empirical universality"
          " NOT established.")
    print("Does not move the 9.0 (Stergios) gate. Physical test = rho_S ="
          " Corr(S_phi, P_logical) on")
    print("real hardware (Pellis paper sec.15/sec.17). Synthetic results cannot"
          " confirm or refute.")
    print("=" * 72)
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
