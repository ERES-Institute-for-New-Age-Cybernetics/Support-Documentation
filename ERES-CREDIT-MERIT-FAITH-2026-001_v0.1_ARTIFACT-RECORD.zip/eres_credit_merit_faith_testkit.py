#!/usr/bin/env python3
"""ERES-CREDIT-MERIT-FAITH-2026-001 v0.1 — companion test instrument.

Credit -> Merit as Instrument-of-Faith (BEST / SOUND / GOOD).

Stdlib-only, deterministic, import-guarded. Each structural rule is both
confirmed and falsified. SKIPs mark the open items in WP §8; the suite goes
fully green only when they close.

Expected v0.1 result: 11 PASS / 0 FAIL / 4 SKIP, exit 0.

Author of record: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age
Cybernetics. ORCID 0000-0001-9946-3221. Drafted with Claude (Anthropic).
License: CCAL v2.1 / CC BY 4.0.

This suite tests the instrument's rules, not any empirical claim about the
world. Illustrative numbers are not measurements.
"""
from __future__ import annotations

import hashlib
import math
import sys
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

INSTRUMENT_ID = "ERES-CREDIT-MERIT-FAITH-2026-001"
VERSION = "v0.1"

BANDS = ("BEST", "SOUND", "GOOD", "BELOW_GOOD")
GRADES = ("DERIVED", "STRUCTURAL", "ANALOGICAL", "CLAIMED")


class SkipTest(Exception):
    """Raised by a test whose rule depends on an open item."""


# ---------------------------------------------------------------- rules ----

def proof_of_resonance(a: float, r: float, p: float, f: float) -> float:
    """Conjunctive PoR = A x R x P x F (EAAP v1.3-FINAL). Factors in [0, 1]."""
    for name, v in (("A", a), ("R", r), ("P", p), ("F", f)):
        if not 0.0 <= v <= 1.0:
            raise ValueError(f"PoR factor {name} out of [0,1]: {v}")
    return a * r * p * f


@dataclass
class Exchange:
    bera_ok: bool
    favors_custody: bool
    factors: Tuple[float, float, float, float]
    auth: bool = True  # SROC SPRT gate: AUTH=yes/no

    def ratable(self) -> bool:
        return self.bera_ok and self.favors_custody


@dataclass
class Account:
    n: float  # UBIMIA survival provision (GraceChain) — never merit-contingent
    m: float = 0.0  # Merit (Meritcoin)
    history: List[str] = field(default_factory=list)


def settle(acct: Account, ex: Exchange, credit: float) -> str:
    """Convert extended Credit to Merit, or hold it. Never refuses, never touches N."""
    if not ex.auth or not ex.ratable():
        acct.history.append("HELD")
        return "HELD"
    por = proof_of_resonance(*ex.factors)
    if por == 0.0:
        acct.history.append("HELD")
        return "HELD"
    acct.m += credit * por
    acct.history.append("MINTED")
    return "MINTED"


def reliability(cumulative_hazard: float) -> float:
    """R = exp(-H): actuarial survival identity (Pellis correspondence)."""
    if cumulative_hazard < 0:
        raise ValueError("cumulative hazard must be >= 0")
    return math.exp(-cumulative_hazard)


def apply_hazard(acct: Account, h_phi: float, cumulative_h: float) -> str:
    """Illustrative decrement (WP §6): hphi > 1 -> below GOOD -> M x R. N untouched."""
    if h_phi > 1.0:
        acct.m *= reliability(cumulative_h)
        return "BELOW_GOOD"
    return "HELD_STANDING"


def assign_band(grade: str, node_scores: List[float]) -> str:
    """Band by evidence grade and ensemble gate (GAIA Benchmarks / MIEVM)."""
    if grade not in GRADES:
        raise ValueError(f"unknown grade {grade}")
    n = len(node_scores)
    if grade == "DERIVED" and n >= 5 and all(s >= 9.0 for s in node_scores):
        return "BEST"
    if grade in ("DERIVED", "STRUCTURAL") and n >= 4 and sum(node_scores) / n >= 8.5:
        return "SOUND"
    return "GOOD"


def record_audit(owner: str) -> Dict[str, str]:
    """Band-ownership guardrail (RROI): holder-owned audit is surveillance."""
    if owner != "BAND":
        raise PermissionError("audit must be band-owned, not holder-owned")
    return {"owner": "BAND", "mode": "tuning"}


# ---------------------------------------------------------------- tests ----

def t01_por_zero_blocks() -> None:
    assert proof_of_resonance(0.9, 0.0, 0.95, 0.9) == 0.0
    for i in range(4):
        f = [0.9, 0.8, 0.95, 0.9]
        f[i] = 0.0
        assert proof_of_resonance(*f) == 0.0
    # falsify: out-of-range factor rejected
    try:
        proof_of_resonance(1.2, 0.5, 0.5, 0.5)
    except ValueError:
        pass
    else:
        raise AssertionError("out-of-range factor accepted")


def t02_positive_and_not_additive() -> None:
    por = proof_of_resonance(0.9, 0.8, 0.95, 0.9)
    assert abs(por - 0.6156) < 1e-9
    blocked = (0.9, 0.0, 0.95, 0.9)
    additive_mean = sum(blocked) / 4
    assert additive_mean > 0.6  # an averaging rule would let it pass...
    assert proof_of_resonance(*blocked) == 0.0  # ...the conjunctive rule does not


def t03_veiled_not_creditable() -> None:
    acct = Account(n=100.0)
    veiled = Exchange(bera_ok=False, favors_custody=False, factors=(1, 1, 1, 1))
    assert settle(acct, veiled, credit=50) == "HELD" and acct.m == 0.0
    no_custody = Exchange(bera_ok=True, favors_custody=False, factors=(1, 1, 1, 1))
    assert settle(acct, no_custody, credit=50) == "HELD" and acct.m == 0.0
    # confirm: ratable exchange is credited
    ok = Exchange(bera_ok=True, favors_custody=True, factors=(0.9, 0.8, 0.95, 0.9))
    assert settle(acct, ok, credit=100) == "MINTED"
    assert abs(acct.m - 61.56) < 1e-9


def t04_n_invariant() -> None:
    acct = Account(n=100.0, m=100.0)
    n0 = acct.n
    settle(acct, Exchange(False, False, (0, 0, 0, 0)), 10)
    settle(acct, Exchange(True, True, (0.5, 0.5, 0.5, 0.5)), 10)
    apply_hazard(acct, h_phi=1.2, cumulative_h=1.6)
    apply_hazard(acct, h_phi=5.0, cumulative_h=50.0)
    assert acct.n == n0, "N moved"
    assert acct.m < 100.0, "M should have decremented"


def t05_best_requires_derived_and_five_nodes() -> None:
    assert assign_band("DERIVED", [9.1, 9.2, 9.0, 9.5, 9.3]) == "BEST"
    # falsify: structural claim with perfect scores is still not BEST
    assert assign_band("STRUCTURAL", [10.0] * 6) != "BEST"
    # falsify: four nodes, or one node below 9.0, is not BEST
    assert assign_band("DERIVED", [9.5] * 4) != "BEST"
    assert assign_band("DERIVED", [9.5, 9.5, 9.5, 9.5, 8.9]) != "BEST"


def t06_sound_gate() -> None:
    assert assign_band("STRUCTURAL", [9.5, 9.1, 8.3, 8.2]) == "SOUND"  # mean 8.775
    assert assign_band("STRUCTURAL", [8.5, 8.4, 8.4]) == "GOOD"  # three nodes
    assert assign_band("STRUCTURAL", [8.0, 8.0, 8.0, 8.0]) == "GOOD"  # mean < 8.5
    assert assign_band("ANALOGICAL", [9.9] * 5) == "GOOD"  # analogical capped


def t07_hazard_default() -> None:
    acct = Account(n=100.0, m=100.0)
    assert apply_hazard(acct, h_phi=0.4, cumulative_h=0.4) == "HELD_STANDING"
    assert acct.m == 100.0
    assert apply_hazard(acct, h_phi=1.2, cumulative_h=1.6) == "BELOW_GOOD"
    assert abs(acct.m - 100.0 * math.exp(-1.6)) < 1e-9


def t08_reliability_identity() -> None:
    assert reliability(0.0) == 1.0
    prev = 1.0
    for k in range(1, 50):
        r = reliability(k * 0.1)
        assert 0.0 < r <= prev
        prev = r
    try:
        reliability(-0.1)
    except ValueError:
        pass
    else:
        raise AssertionError("negative hazard accepted")


def t09_held_never_refused() -> None:
    acct = Account(n=100.0)
    out = settle(acct, Exchange(True, True, (1, 1, 1, 1), auth=False), 10)
    assert out == "HELD" and out != "REJECTED"
    assert "REJECTED" not in acct.history


def t10_band_owned_audit() -> None:
    assert record_audit("BAND")["mode"] == "tuning"
    try:
        record_audit("HOLDER")
    except PermissionError:
        pass
    else:
        raise AssertionError("holder-owned audit accepted")


def t11_self_application() -> None:
    # v0.1 has no MIEVM ensemble data: it holds the grade its evidence earns.
    assert assign_band("STRUCTURAL", []) == "GOOD"


def s1_hphi_cutpoints() -> None:
    raise SkipTest("OPEN 2: hphi cut-points separating SOUND from GOOD not fixed")


def s2_bera_metrics() -> None:
    raise SkipTest("OPEN 3: BERA metric set not traced to a corpus instrument")


def s3_empirical_ensemble() -> None:
    raise SkipTest("No >=5-node MIEVM ensemble with empirical data yet")


def s4_credit_voucher() -> None:
    raise SkipTest("OPEN 4: CREDIT-VOUCHER User-GROUP data not linked")


TESTS: List[Tuple[str, Callable[[], None]]] = [
    ("T01 PoR zero-factor block", t01_por_zero_blocks),
    ("T02 PoR positive; additive rejected", t02_positive_and_not_additive),
    ("T03 veiled exchange not creditable", t03_veiled_not_creditable),
    ("T04 N invariant", t04_n_invariant),
    ("T05 BEST gate", t05_best_requires_derived_and_five_nodes),
    ("T06 SOUND gate", t06_sound_gate),
    ("T07 hazard default decrements M", t07_hazard_default),
    ("T08 R = exp(-H) identity", t08_reliability_identity),
    ("T09 held, never refused", t09_held_never_refused),
    ("T10 band-owned audit", t10_band_owned_audit),
    ("T11 self-application grade", t11_self_application),
    ("S1 hphi cut-points", s1_hphi_cutpoints),
    ("S2 BERA metrics", s2_bera_metrics),
    ("S3 empirical ensemble", s3_empirical_ensemble),
    ("S4 CREDIT-VOUCHER data", s4_credit_voucher),
]


def self_sha256() -> Optional[str]:
    try:
        with open(__file__, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except OSError:
        return None


def run() -> int:
    print(f"{INSTRUMENT_ID} {VERSION} — companion test instrument")
    print(f"self SHA-256: {self_sha256()}")
    counts = {"PASS": 0, "FAIL": 0, "SKIP": 0}
    for name, fn in TESTS:
        try:
            fn()
            status, note = "PASS", ""
        except SkipTest as e:
            status, note = "SKIP", f" — {e}"
        except Exception as e:  # noqa: BLE001
            status, note = "FAIL", f" — {type(e).__name__}: {e}"
        counts[status] += 1
        print(f"  [{status}] {name}{note}")
    print(f"RESULT: {counts['PASS']} PASS / {counts['FAIL']} FAIL / {counts['SKIP']} SKIP")
    return 1 if counts["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(run())
