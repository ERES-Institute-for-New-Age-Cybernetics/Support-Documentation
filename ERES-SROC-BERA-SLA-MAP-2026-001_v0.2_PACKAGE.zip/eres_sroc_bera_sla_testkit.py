#!/usr/bin/env python3
"""
eres_sroc_bera_sla_testkit.py  --  ERES-SROC-BERA-SLA-MAP-2026-001 v0.2 DRAFT

Enumerates the universe of SROC options against BERA (measurement) and the
S3C User-GROUP SLA (who is bound, where), then prunes it with the Reverse X
N/M rule and the corpus person-lock. Python 3.8+, standard library only,
deterministic, no network.

Structural rules only. Nothing here is a measurement of any real system.
Skips are deliberate and load-bearing: the suite goes fully green only when
the items they name are closed by the author or by outside evidence.

Run:  python3 eres_sroc_bera_sla_testkit.py          (tests)
      python3 eres_sroc_bera_sla_testkit.py --cells  (print the cell table)

Operator slot (v0.2): bring your own operator.
      python3 eres_sroc_bera_sla_testkit.py --operator mymodule:abscissa \
              --range 0 4 --warn 0.125
          mymodule.abscissa(mu) -> spectral abscissa (max Re lambda) at mu
      python3 eres_sroc_bera_sla_testkit.py --series readings.csv --warn 0.125
          readings.csv has header t,abscissa, rows in time order
      In code: set_operator(fn); lead_time(); lead_time_series(rows)
"""
import csv
import importlib
import itertools
import math
import sys
import unittest

INSTRUMENT = "ERES-SROC-BERA-SLA-MAP-2026-001"
VERSION = "v0.2"
TESTS_SPEC_VERSION = (0, 2)

PHI = (1 + 5 ** 0.5) / 2

# ---------------------------------------------------------------- parameters
# Band labels: S5 = Planet is corpus-stated (GAIA GEAR). S1-S4 labels are a
# CANDIDATE assignment awaiting author ratification (see SKIP s3).
BANDS = {
    "S1": "Body (person)",            # CANDIDATE label
    "S2": "Device / asset",           # CANDIDATE label
    "S3": "Infrastructure tile (EMCI)",  # CANDIDATE label
    "S4": "Community (S3C User-GROUP)",  # CANDIDATE label
    "S5": "Planet (GAIA)",            # STATED; closure OPEN
}
P3 = ("Personal", "Public", "Private")          # STATED (HOW-ILO stewardship classes)
TARGETS = ("N", "M")                             # STATED (ENDHOME Survival/Merit)
DISPOSITIONS = ("token", "held", "retired")      # STATED (SROC token mechanic)

ADMISSIBLE = "ADMISSIBLE"
CONDITIONAL = "CONDITIONAL"   # admissible only with floor provision continuing
REFUSED = "REFUSED"
OPEN = "OPEN"


def classify(band, p3, target, disp):
    """Return (status, reason) for one cell of the SROC option universe."""
    if band not in BANDS or p3 not in P3 or target not in TARGETS or disp not in DISPOSITIONS:
        raise ValueError("unknown parameter")
    if band == "S5":
        return OPEN, "S5 cascade closure is OPEN; no path selected"
    if target == "N" and disp == "retired":
        return REFUSED, "retiring an N element abandons the floor (N never decremented)"
    if band == "S1" and target == "M":
        return REFUSED, "an S1 SROC is indexed to a person's resonance; resonance may never gate or price a person"
    if target == "N" and disp == "held":
        return CONDITIONAL, "element may be HELD; floor provision must continue meanwhile"
    return ADMISSIBLE, "within N/M rule and person-lock"


def universe():
    return list(itertools.product(BANDS, P3, TARGETS, DISPOSITIONS))


def tally():
    t = {ADMISSIBLE: 0, CONDITIONAL: 0, REFUSED: 0, OPEN: 0}
    for cell in universe():
        t[classify(*cell)[0]] += 1
    return t


# -------------------------------------------------------- structural refusals
class Refused(Exception):
    pass


class Field:
    """One SROC field: x^2 = g*x + b with g guards and b bindings."""

    def __init__(self):
        self.guards = 1
        self.bindings = 1
        self.floor = {"shelter": 1, "water": 1, "food": 1,
                      "sanitation": 1, "warmth": 1, "call": 1}
        self.m_layer = {}

    def add_guard(self):
        raise Refused("second guard: floor would be settled by conflict")

    def add_binding(self):
        raise Refused("second binding: market context would reach the floor")

    def market_write(self, layer, key, value):
        if layer == "N":
            raise Refused("market context may not define the N-floor")
        self.m_layer[key] = value

    def bera_adjust(self, key, delta):
        """A BERA reading may raise floor provision, never lower it."""
        if key in self.floor:
            if delta < 0:
                raise Refused("a BERA reading may never decrement the N-floor")
            self.floor[key] += delta
        else:
            self.m_layer[key] = self.m_layer.get(key, 0) + delta


def contract_valid(contact_of_record):
    """SROC §1: a contract begins with a number anyone can call."""
    return bool(contact_of_record) and contact_of_record.get("channel_live") is True \
        and bool(contact_of_record.get("answerable_party"))


# ------------------------------------------- BERA admissibility (four tests)
ADMISSIBILITY_TESTS = ("persistent", "distinguishable", "stable", "accessible")


def reading_admissible(reading):
    """A BERA reading may trigger an SROC only if it passes all four tests
    (structure borrowed from the physicality criteria in Pellis, Spectral
    Principle of Physical Reality, 2026; ANALOGICAL transfer)."""
    return all(reading.get(k) is True for k in ADMISSIBILITY_TESTS)


# ------------------------------------------------ three-regime band and HELD
def regime(abscissa, warn_margin):
    """stable / metastable / unstable by spectral abscissa (max Re lambda).
    Structure after the stable/metastable/unstable regimes of the Pellis
    Stability Operator (smart grids, 2026); ANALOGICAL transfer."""
    if abscissa >= 0:
        return "unstable"
    if abscissa >= -warn_margin:
        return "metastable"
    return "stable"


REGIME_BAND = {"stable": "GREEN", "metastable": "YELLOW", "unstable": "RED"}


def eig2(a, b, c, d):
    """Eigenvalues of [[a, b], [c, d]] (complex-safe, stdlib only)."""
    tr, det = a + d, a * d - b * c
    disc = tr * tr - 4 * det
    if disc >= 0:
        r = math.sqrt(disc)
        return complex((tr + r) / 2), complex((tr - r) / 2)
    r = math.sqrt(-disc)
    return complex(tr / 2, r / 2), complex(tr / 2, -r / 2)


def abscissa_of(mu, k=4.0, c=1.0):
    """Toy damped resonator x'' + (c - mu) x' + k x = 0 as a 2x2 operator.
    The abscissa is COMPUTED from the matrix, not stipulated."""
    lam = eig2(0.0, 1.0, -k, mu - c)
    return max(z.real for z in lam)


# ------------------------------------------------------------ operator slot
_OPERATOR = None   # None means the built-in toy resonator


def set_operator(fn):
    """Install an external operator. fn(mu) must return the spectral
    abscissa (max Re lambda, a finite float) of the operator at control
    parameter mu. Pass None to restore the built-in toy."""
    global _OPERATOR
    if fn is not None and not callable(fn):
        raise TypeError("operator must be callable: fn(mu) -> abscissa")
    _OPERATOR = fn


def current_abscissa(mu):
    fn = _OPERATOR or abscissa_of
    a = fn(mu)
    if isinstance(a, bool) or not isinstance(a, (int, float)) or not math.isfinite(a):
        raise ValueError("operator returned a non-finite or non-numeric abscissa")
    return float(a)


def from_matrix_2x2(A):
    """Adapter: A(mu) -> ((a, b), (c, d)). Returns fn(mu) -> abscissa.
    For larger operators, compute the abscissa yourself (for example with
    numpy: lambda mu: float(max(numpy.linalg.eigvals(M(mu)).real)))."""
    def fn(mu):
        (a, b), (c, d) = A(mu)
        return max(z.real for z in eig2(a, b, c, d))
    return fn


def lead_time_series(rows, warn_margin=0.125):
    """rows: iterable of (t, abscissa) in strictly increasing t, e.g.
    abscissa values computed from real telemetry. Returns
    (t_warn, t_fail, lead); entries are None if a regime is never reached."""
    t_prev, t_warn, t_fail = None, None, None
    for t, a in rows:
        t, a = float(t), float(a)
        if not (math.isfinite(t) and math.isfinite(a)):
            raise ValueError("non-finite value in series")
        if t_prev is not None and t <= t_prev:
            raise ValueError("series must be in strictly increasing time order")
        t_prev = t
        r = regime(a, warn_margin)
        if t_warn is None and r != "stable":
            t_warn = t
        if t_fail is None and r == "unstable":
            t_fail = t
            break
    lead = (t_fail - t_warn) if (t_warn is not None and t_fail is not None) else None
    return t_warn, t_fail, lead


def load_series_csv(path):
    with open(path, newline="") as fh:
        return [(row["t"], row["abscissa"]) for row in csv.DictReader(fh)]


def load_operator(spec):
    mod, _, fn = spec.partition(":")
    if not fn:
        raise ValueError("--operator expects module:function")
    return getattr(importlib.import_module(mod), fn)


def first_crossing(pred, lo=0.0, hi=4.0, steps=40000):
    for i in range(steps + 1):
        mu = lo + (hi - lo) * i / steps
        if pred(mu):
            return mu
    return None


def lead_time(warn_margin=0.125, lo=0.0, hi=4.0, steps=40000):
    """Sweep mu over [lo, hi] using the installed operator (toy by default)."""
    mu_warn = first_crossing(lambda m: regime(current_abscissa(m), warn_margin) != "stable", lo, hi, steps)
    mu_fail = first_crossing(lambda m: regime(current_abscissa(m), warn_margin) == "unstable", lo, hi, steps)
    return mu_warn, mu_fail


# ------------------------------------------------------ phi weighting guard
def weight(value, golden_advantage_registered=False):
    """Reverse X F5 and Pellis' own golden-scale falsification rule: phi may
    not enter any weight unless a registered test shows a predictive
    advantage over non-golden alternatives. No such test exists, so the
    flag is never set inside ERES."""
    if abs(value - PHI) < 1e-9 and not golden_advantage_registered:
        raise Refused("phi weighting without a registered golden-advantage test")
    return value


# ------------------------------------------------------------------- tests
TRACEABILITY = {
    "t01": "§3 universe has 90 cells",
    "t02": "§3 tally: admissible / conditional / refused / open",
    "t03": "§4.1 N + retired refused at every band S1-S4",
    "t04": "§4.2 S1 + M refused (person-lock)",
    "t05": "§4.3 N + held conditional; provision continues",
    "t06": "§4.4 every S5 cell OPEN, none admissible",
    "t07": "§5 second guard refused",
    "t08": "§5 second binding refused",
    "t09": "§5 market write at N refused; at M allowed",
    "t10": "§5 BERA reading may raise, never lower, the floor",
    "t11": "§5 dead channel voids the contract",
    "t12": "§6.1 BERA admissibility: all four tests required",
    "t13": "§6.2 regime map stable/metastable/unstable -> GREEN/YELLOW/RED",
    "t14": "§6.2 computed lead time > 0 on toy operator (could be null)",
    "t15": "§6.3 phi weighting refused without registered test",
    "t16": "§3 every cell has exactly one status and a reason",
    "t17": "§6.6 slot rejects a non-callable operator",
    "t18": "§6.6 external operator drives lead_time; None restores toy",
    "t19": "§6.6 non-finite abscissa rejected",
    "t20": "§6.6 series mode computes lead from (t, abscissa) rows",
    "t21": "§6.6 series must be strictly time-ordered",
    "t22": "§6.6 2x2 matrix adapter reproduces the toy",
    "s1": "F1 real multi-scale telemetry for any band (OPEN)",
    "s2": "S5 closure (OPEN)",
    "s3": "Author ratification of S1-S4 labels and the S1+M rule",
    "s4": "Disposition of cited author on use of references",
    "s5": "Independent >=5-node MIEVM round",
    "s6": "EMCI green-band metric set and SROC offset thresholds",
}


class T(unittest.TestCase):
    def test_t01_universe_size(self):
        self.assertEqual(len(universe()), 5 * 3 * 2 * 3)

    def test_t02_tally(self):
        self.assertEqual(tally(), {ADMISSIBLE: 39, CONDITIONAL: 12, REFUSED: 21, OPEN: 18})

    def test_t03_n_retired_refused(self):
        for b in ("S1", "S2", "S3", "S4"):
            for p in P3:
                self.assertEqual(classify(b, p, "N", "retired")[0], REFUSED)

    def test_t04_person_lock(self):
        for p in P3:
            for d in DISPOSITIONS:
                self.assertEqual(classify("S1", p, "M", d)[0], REFUSED)
        self.assertEqual(classify("S2", "Private", "M", "token")[0], ADMISSIBLE)

    def test_t05_n_held_conditional(self):
        for b in ("S1", "S2", "S3", "S4"):
            st, why = classify(b, "Public", "N", "held")
            self.assertEqual(st, CONDITIONAL)
            self.assertIn("provision must continue", why)

    def test_t06_s5_open(self):
        for p, t, d in itertools.product(P3, TARGETS, DISPOSITIONS):
            self.assertEqual(classify("S5", p, t, d)[0], OPEN)

    def test_t07_second_guard(self):
        with self.assertRaises(Refused):
            Field().add_guard()

    def test_t08_second_binding(self):
        with self.assertRaises(Refused):
            Field().add_binding()

    def test_t09_market_write(self):
        f = Field()
        with self.assertRaises(Refused):
            f.market_write("N", "water", 0)
        f.market_write("M", "credential_price", 3)
        self.assertEqual(f.m_layer["credential_price"], 3)

    def test_t10_bera_floor_monotone(self):
        f = Field()
        f.bera_adjust("water", 1)
        self.assertEqual(f.floor["water"], 2)
        with self.assertRaises(Refused):
            f.bera_adjust("water", -1)

    def test_t11_contact_of_record(self):
        self.assertTrue(contract_valid({"channel_live": True, "answerable_party": "steward"}))
        self.assertFalse(contract_valid({"channel_live": False, "answerable_party": "steward"}))
        self.assertFalse(contract_valid({"channel_live": True, "answerable_party": ""}))

    def test_t12_admissibility(self):
        ok = dict.fromkeys(ADMISSIBILITY_TESTS, True)
        self.assertTrue(reading_admissible(ok))
        for k in ADMISSIBILITY_TESTS:
            bad = dict(ok)
            bad[k] = False
            self.assertFalse(reading_admissible(bad))

    def test_t13_regimes(self):
        self.assertEqual(REGIME_BAND[regime(-1.0, 0.1)], "GREEN")
        self.assertEqual(REGIME_BAND[regime(-0.05, 0.1)], "YELLOW")
        self.assertEqual(REGIME_BAND[regime(0.0, 0.1)], "RED")

    def test_t14_lead_time(self):
        mu_warn, mu_fail = lead_time()
        self.assertIsNotNone(mu_warn)
        self.assertIsNotNone(mu_fail)
        self.assertGreater(mu_fail - mu_warn, 0.0)

    def test_t15_phi_guard(self):
        with self.assertRaises(Refused):
            weight(PHI)
        self.assertEqual(weight(1.5), 1.5)

    def test_t16_one_status_each(self):
        statuses = {ADMISSIBLE, CONDITIONAL, REFUSED, OPEN}
        for cell in universe():
            st, why = classify(*cell)
            self.assertIn(st, statuses)
            self.assertTrue(why)

    def tearDown(self):
        set_operator(None)

    def test_t17_slot_type(self):
        with self.assertRaises(TypeError):
            set_operator(3.0)

    def test_t18_external_operator(self):
        set_operator(lambda mu: mu - 2.0)
        mw, mf = lead_time()
        self.assertAlmostEqual(mw, 1.875, places=3)
        self.assertAlmostEqual(mf, 2.0, places=3)
        set_operator(None)
        self.assertAlmostEqual(lead_time()[0], 0.75, places=3)

    def test_t19_nonfinite(self):
        set_operator(lambda mu: float("nan"))
        with self.assertRaises(ValueError):
            lead_time()

    def test_t20_series(self):
        rows = [(0, -0.5), (1, -0.3), (2, -0.1), (3, -0.05), (4, 0.02)]
        self.assertEqual(lead_time_series(rows, 0.125), (2.0, 4.0, 2.0))
        self.assertEqual(lead_time_series([(0, -1.0), (1, -0.9)]), (None, None, None))

    def test_t21_series_order(self):
        with self.assertRaises(ValueError):
            lead_time_series([(1, -0.5), (1, -0.4)])

    def test_t22_matrix_adapter(self):
        set_operator(from_matrix_2x2(lambda mu: ((0.0, 1.0), (-4.0, mu - 1.0))))
        mw, mf = lead_time()
        self.assertAlmostEqual(mf - mw, 0.25, places=3)

    @unittest.skip("s1 F1: no real multi-scale telemetry yet (lifts ANALOGICAL)")
    def test_s1(self):
        pass

    @unittest.skip("s2 S5 closure OPEN: 18 cells stay OPEN until a path is selected")
    def test_s2(self):
        pass

    @unittest.skip("s3 author ratification of S1-S4 labels and the S1+M rule")
    def test_s3(self):
        pass

    @unittest.skip("s4 cited author's disposition on use of references; HOLD")
    def test_s4(self):
        pass

    @unittest.skip("s5 independent >=5-node MIEVM round not run")
    def test_s5(self):
        pass

    @unittest.skip("s6 EMCI green-band metric set and offset thresholds OPEN")
    def test_s6(self):
        pass


def print_cells():
    print(f"{'band':4} {'P3':9} {'tgt':3} {'disp':8} status")
    for cell in universe():
        st, why = classify(*cell)
        print(f"{cell[0]:4} {cell[1]:9} {cell[2]:3} {cell[3]:8} {st:11} {why}")


def _arg(name, n=1):
    if name in sys.argv:
        i = sys.argv.index(name)
        vals = sys.argv[i + 1:i + 1 + n]
        if len(vals) != n:
            raise SystemExit(f"{name} needs {n} value(s)")
        return vals
    return None


if __name__ == "__main__":
    if "--cells" in sys.argv:
        print_cells()
        sys.exit(0)
    warn = float((_arg("--warn") or ["0.125"])[0])
    if _arg("--series"):
        tw, tf, ld = lead_time_series(load_series_csv(_arg("--series")[0]), warn)
        print(f"series: t_warn={tw} t_fail={tf} lead={ld} (warn_margin={warn})")
        sys.exit(0)
    if _arg("--operator"):
        set_operator(load_operator(_arg("--operator")[0]))
        lo, hi = map(float, _arg("--range", 2) or ["0", "4"])
        mw, mf = lead_time(warn, lo, hi)
        ld = (mf - mw) if (mw is not None and mf is not None) else None
        print(f"operator {_arg('--operator')[0]}: mu_warn={mw} mu_fail={mf} lead={ld} (warn_margin={warn}, range=[{lo}, {hi}])")
        sys.exit(0)
    mw, mf = lead_time()
    print(f"{INSTRUMENT} {VERSION}  tally={tally()}  toy lead: mu_warn={mw:.4f} mu_fail={mf:.4f} lead={mf-mw:.4f}")
    res = unittest.main(exit=False, verbosity=2).result
    print("\nTRACEABILITY")
    for k, v in TRACEABILITY.items():
        print(f"  {k}: {v}")
    sys.exit(0 if res.wasSuccessful() else 1)
