# ERES-SROC-BERA-SLA-MAP-2026-001 v0.2 (DRAFT)

Maps the universe of SROC (Smart-Resonant Offset Contract) options to BERA and S³C User-GROUP SLAs, prunes it with the Reverse X N/M rule, and provides a slot where an outside spectral operator, or real telemetry, can drive the early-warning lead-time test.

Status: DRAFT, single-node, pre-MIEVM. CC BY 4.0: free to use and extend. Not to be posted with a cited author's name attached without that author's agreement.

## Files
- `ERES-SROC-BERA-SLA-MAP-2026-001_v0.2.md`: the instrument
- `eres_sroc_bera_sla_testkit.py`: stdlib-only testkit (Python 3.8+)
- `example_operator.py`, `example_series.csv`: worked examples for the slot
- `RUN.txt`: captured test run, slot examples, full cell table
- `MANIFEST.json`: SHA-256 of each file

## Run the tests
    python3 eres_sroc_bera_sla_testkit.py          # 28 tests: 22 pass, 6 skip, exit 0
    python3 eres_sroc_bera_sla_testkit.py --cells  # all 90 cells with status and reason

## Plug in your operator (§6.6)
Write a function that returns the spectral abscissa (max Re λ, a finite float) of your operator at control parameter mu:

    # my_operator.py
    def abscissa(mu):
        ...                       # build your operator at mu
        return max_real_part      # e.g. float(max(numpy.linalg.eigvals(M).real))

Then:

    python3 eres_sroc_bera_sla_testkit.py --operator my_operator:abscissa --range 0 4 --warn 0.125
    # -> mu_warn (band leaves GREEN), mu_fail (band reaches RED), lead

Worked example (bundled toy): `--operator example_operator:abscissa` gives mu_warn=0.75, mu_fail=1.0, lead=0.25.

## Or bring readings from real data
CSV with header `t,abscissa`, strictly increasing t:

    python3 eres_sroc_bera_sla_testkit.py --series my_readings.csv --warn 0.125
    # -> t_warn, t_fail, lead

Worked example: `--series example_series.csv` gives t_warn=2.0, t_fail=4.0, lead=2.0.

In code: `set_operator(fn)`, `lead_time(margin, lo, hi)`, `lead_time_series(rows, margin)`, `from_matrix_2x2(A)`.

A positive lead on real data is the first evidence toward open item F1. A null result is registered the same way. The slot changes no pruning rule.

## Result
90 cells: 39 admissible, 12 conditional, 21 refused, 18 open (S5).

## Claim → test
| Claim | Test |
|---|---|
| 90-cell universe; tally | t01, t02, t16 |
| N + retired refused | t03 |
| S1 + M refused (person-lock) | t04 |
| N + held conditional | t05 |
| S5 open | t06 |
| One guard, one binding; market and BERA limits; Contact of Record | t07-t11 |
| Four-test admissibility | t12 |
| Three regimes; computed toy lead time | t13, t14 |
| No φ weighting | t15 |
| Operator slot, series mode, guards, adapter | t17-t22 |
| Load-bearing skips | s1-s6 |

License: CCAL v2.1 / CC BY 4.0. Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. ORCID 0000-0001-9946-3221.
