"""Worked example for the operator slot. Replace this with your own operator.

Contract: abscissa(mu) returns the spectral abscissa (max Re lambda, a finite
float) of the operator at control parameter mu. Here: a 2x2 damped resonator,
the same toy the testkit uses, written out so the shape is visible.
"""
from eres_sroc_bera_sla_testkit import eig2


def abscissa(mu):
    a, b, c, d = 0.0, 1.0, -4.0, mu - 1.0   # [[0, 1], [-k, mu - c]] with k=4, c=1
    return max(z.real for z in eig2(a, b, c, d))
