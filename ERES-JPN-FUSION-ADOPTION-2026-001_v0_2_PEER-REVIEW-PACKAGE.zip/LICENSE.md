# License ／ ライセンス — ERES-JPN-FUSION-ADOPTION-2026-001 v0.2

Copyright © 2026 Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221).

## English

1. **Text** (EN and JA papers, Synopsis, README, Figure): CCAL v2.1 (CARE Commons Attribution License) and Creative Commons Attribution 4.0 International (CC BY 4.0) — https://creativecommons.org/licenses/by/4.0/legalcode . CCAL v2.1 adds no restriction beyond CC BY 4.0.
2. **Code** (`eres_jpn_fusion_testkit.py`): CC BY 4.0. A conventional software license may be requested from the author.
3. **Patents and trademarks are not licensed** (CC BY 4.0 §2(b)(2)). The author holds and files no patents on this content; it is openly published and may serve as prior art. No right is claimed in or granted to any third party's name or mark.
4. **Moral rights:** waived or not asserted only to the extent necessary and possible under applicable law. Where not waivable (e.g., author's personal rights under Japanese copyright law), the author's attribution and integrity rights are retained.
5. **Attribution form:** use the Suggested Citation in the paper (§12), with a link to the license and an indication of any changes.
6. **Governing text:** the official Creative Commons legal code governs the license. The English paper governs meaning; the Japanese paper is a faithful translation.
7. **No warranty.** Not legal, investment or medical advice.
8. **Non-endorsement:** licensing this work implies no endorsement by any person or institution named or cited in it.

## 日本語（参考訳）

1. **本文**（英語版・日本語版論文、概要、README、図）：CCAL v2.1 および クリエイティブ・コモンズ 表示 4.0 国際（CC BY 4.0）。CCAL v2.1 は CC BY 4.0 を超える制限を加えません。
2. **コード**（`eres_jpn_fusion_testkit.py`）：CC BY 4.0。従来型のソフトウェア・ライセンスは著者に申請できます。
3. **特許権および商標権は許諾対象外です**（CC BY 4.0 第2条(b)(2)）。著者は本内容について特許を保有・出願しません。本内容は公開されており、先行技術となり得ます。第三者の名称・標章についていかなる権利も主張・付与しません。
4. **著作者人格権：** 適用法上必要かつ可能な範囲でのみ放棄または不行使とします。放棄できない場合（日本の著作権法上の著作者人格権など）、氏名表示権および同一性保持権は保持されます。
5. **帰属表示：** 論文第12節の推奨引用形式を用い、ライセンスへのリンクと変更の有無を示してください。
6. **準拠テキスト：** ライセンスはクリエイティブ・コモンズ公式リーガルコードに準拠します。意味については英語版が優先し、日本語版は忠実な翻訳です。
7. **無保証。** 法律・投資・医療上の助言ではありません。
8. **非承認：** 本ライセンスは、本書で言及・引用されたいかなる個人・機関による承認も意味しません。
