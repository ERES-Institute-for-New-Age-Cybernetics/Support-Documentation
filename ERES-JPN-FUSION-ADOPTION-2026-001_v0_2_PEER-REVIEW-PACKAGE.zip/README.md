# ERES-JPN-FUSION-ADOPTION-2026-001 v0.2 — Peer-Review Package ／ 査読用パッケージ

**Semiconduction to Fusion: A Nations-Role Adoption Proposal for Japan**
**半導体からフュージョンへ：日本のための国家ロール採択提案**

Joseph Allen Sprute (ERES Maestro) · ORCID 0000-0001-9946-3221 · ERES Institute for New Age Cybernetics · 30 Oct 2026
License: CCAL v2.1 / CC BY 4.0 (see LICENSE.md — patents and trademarks not licensed)

## Contents ／ 内容

| File | Role ／ 役割 |
|---|---|
| `…_EN.md` / `…_EN.pdf` | Adoption paper, English master ／ 採択論文（英語原本） |
| `…_JA.md` / `…_JA.pdf` | Adoption paper, Japanese ／ 採択論文（日本語） |
| `…_SYNOPSIS.md` / `…_SYNOPSIS.pdf` | Bilingual synopsis: title, subtitle, keywords, abstract, citation ／ 二言語概要 |
| `…_FIGURE.svg` | Figure 1, Fusion Model + Adoption Ladder ／ 図1 |
| `eres_jpn_fusion_testkit.py` | Test Kit ／ テストキット |
| `LICENSE.md` | License and IP terms (EN/JA) ／ ライセンス・知的財産条件 |
| `CITATION.cff`, `META.json` | Citation + deposit metadata ／ 引用・登録メタデータ |
| `MANIFEST.json` | SHA-256 of every file ／ 全ファイルの SHA-256 |

## Run the Test Kit ／ テストキットの実行

```
python3 eres_jpn_fusion_testkit.py            # from the unzipped folder
python3 eres_jpn_fusion_testkit.py --json     # + machine-readable record
```

Python 3.8+, standard library only, deterministic. Keep the papers and MANIFEST.json in the same folder. Expected: structural **9 PASS / 0 FAIL**; guards **3 PASS / 1 SKIP**; empirical **0 of 4 tested (4 SKIP)**; exit 0.
T9 (no-names guard) is run by the author with an out-of-band list (`--withheld FILE`) that is not shipped, so reviewers see SKIP.
**A structural PASS validates algebra and bookkeeping, not empirical truth. 2 of 72 domains are declared; 0 are empirically calibrated.**

Python 3.8 以上、標準ライブラリのみ、決定論的。論文と MANIFEST.json を同じフォルダに置いてください。期待結果：構造 **9 PASS / 0 FAIL**、ガード **3 PASS / 1 SKIP**、経験的予測 **4件中0件検証**、終了コード 0。

## Claim → test traceability ／ 主張とテストの対応

| Paper § | Claim | Test |
|---|---|---|
| §2 | Prop. 1 survival identity, additive hazard | T1 |
| §3.1 | Poisson yield ↔ hazard | T2 |
| §3.2 | Phase product ↔ hazard, LOA ≈ 7.9% | T3 |
| §4.2 | Grade bands | T4 |
| §4.3 F2 | Non-collapse (min, not ordinal or hazard mean) | T5 |
| §4.7 | 72-domain scope; global-min collapse; scoped fusion | T12 |
| §4.3 F3 | Floor rule (definitional); host-declared floor; N never decremented | T6 |
| §4.4 | Epistemic cap (no BEST from illustrative inputs) | T7 |
| §7 | Adoption Ladder gating; current stage A0 | T8 |
| Status 4 | Sponsor/company names withheld (author-run, out-of-band list) | T9 |
| — | Package integrity vs MANIFEST | T13 |
| §10.5 | EN/JA term lock | T10 |
| Status | Non-endorsement in both languages | T11 |
| §8 P1–P4 | Empirical predictions | S1–S4 (SKIP) |

## Reviewer requests ／ 査読者へのお願い

1. Reproduce the Test Kit on your own hardware and report the verdict + self-SHA-256 (Stage A2). ／ ご自身の環境でテストキットを実行し、判定と SHA-256 をご報告ください（段階 A2）。
2. Assess whether F1–F3 are the right conditions for a Fusion. ／ F1–F3 がフュージョンの条件として適切かご評価ください。
3. Advise on Japanese terminology and register. ／ 日本語の用語・文体についてご助言ください。
4. Suggest real data sources for P1–P4, and a third domain from the 72 with a citable reference hazard. ／ P1–P4 の実データ源と、参照ハザードを引用可能な第3の領域をご提案ください。
5. Assess whether scoped fusion (§4.7) resolves the 72-domain collapse. ／ スコープ付き融合が崩壊問題を解決するかご評価ください。 ／ P1–P3 の実データ源をご提案ください。

## Status ／ 状況

Proposal at Stage **A0**; dedication pending the Fellow's consent (A1). No endorsement or adoption by any person or institution. ／ 段階 **A0** の提案。いかなる個人・機関による承認・採択もありません。
