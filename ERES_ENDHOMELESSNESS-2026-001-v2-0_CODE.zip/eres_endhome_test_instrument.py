#!/usr/bin/env python3
"""
ERES-ENDHOME-2026-001 v2.0 — Test Instrument
=============================================

An executable companion to the End-Homelessness_HOW canonical instrument.

This is NOT a policy simulator and NOT a claim that the framework "works."
It is a falsifier harness: it encodes the instrument's own structural claims
as runnable assertions, so that anyone can check whether a candidate
implementation (real jurisdiction data, or a hypothetical config) is
CONSISTENT with the instrument — or violates it.

Design rules, inherited from the instrument:
  - Data-Integrity value 3: no weight, threshold, or magnitude is hard-coded
    as "true." Every numeric parameter enters as an OPEN input the caller
    supplies. The harness tests STRUCTURE, not values.
  - The four pre-registered falsifiers (§10) are each a test that can FAIL.
  - The Coupling Law hard/soft partition (§3.3) is testable and is tested.
  - The Survival/Merit Separation (§6.4) is an audit, not a formula: it checks
    that merit never entered an admission decision.

Run:  python3 eres_endhome_test_instrument.py
Exit code 0 = all structural checks passed. Non-zero = a violation was found.

No third-party dependencies. Standard library only.
Author: Joseph A. Sprute (ERES Maestro), ERES Institute for New Age Cybernetics.
License: CC BY 4.0.
"""

from __future__ import annotations

import sys
import math
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Section A — The provisioning identity and the gated product (§3.3, §5.1)
# ---------------------------------------------------------------------------

# The eight SEPLTA + H&E axes, partitioned per §3.3.
HARD_GATE_AXES = ("Legal", "Administrative")           # G_hard ∈ {0,1}
SOFT_AXES = ("Social", "Economic", "Political",
             "Technical", "History", "Environment")     # degrade gracefully


@dataclass
class CareConfig:
    """
    A candidate care-system configuration.

    Every field is supplied by the caller. Nothing here carries a default
    'correct' value — that is the Data-Integrity rule made literal. Axis
    scores are on [0,1]; gamma is the admission-certainty gate.
    """
    gamma: float                       # Γ — admission-certainty gate, [0,1]
    hard: dict = field(default_factory=dict)   # {"Legal": 0/1, "Administrative": 0/1}
    soft: dict = field(default_factory=dict)   # {"Social": s, ...} each in [0,1]
    # provisioning-identity operands (all caller-supplied, all [0,1] or >=0):
    C: float = 1.0   # care access
    A: float = 1.0   # attention access
    H: float = 1.0   # housing stability
    P: float = 1.0   # EarnedPath opportunity
    B: float = 1.0   # belonging / continuity
    X: float = 0.0   # extraction pressure   (denominator)
    F: float = 0.0   # friction              (denominator)
    D: float = 0.0   # delay                 (denominator)

    def validate(self) -> None:
        if not (0.0 <= self.gamma <= 1.0):
            raise ValueError(f"gamma out of [0,1]: {self.gamma}")
        for k in HARD_GATE_AXES:
            v = self.hard.get(k, 1)
            if v not in (0, 1):
                raise ValueError(f"hard-gate axis {k} must be 0 or 1, got {v}")
        for k in SOFT_AXES:
            v = self.soft.get(k, 1.0)
            if not (0.0 <= v <= 1.0):
                raise ValueError(f"soft axis {k} out of [0,1]: {v}")


def g_hard(cfg: CareConfig) -> int:
    """G_hard — product over the genuinely gating axes. 0 if any hard gate fails."""
    out = 1
    for k in HARD_GATE_AXES:
        out *= cfg.hard.get(k, 1)
    return out


def p_soft(cfg: CareConfig) -> float:
    """P_soft — mean of soft-axis performance. Degrades, never gates."""
    vals = [cfg.soft.get(k, 1.0) for k in SOFT_AXES]
    return sum(vals) / len(vals) if vals else 1.0


def tuning_aggregate(cfg: CareConfig) -> float:
    """
    T_care = Γ · G_hard · P_soft   (§3.3, v2.0 hard/soft refinement)

    A gate at zero (Γ=0 or any hard axis=0) collapses the whole aggregate,
    regardless of soft-axis excellence. That is the Coupling Law.
    """
    return cfg.gamma * g_hard(cfg) * p_soft(cfg)


def provisioning_identity(cfg: CareConfig) -> float:
    """
    End-Homelessness_HOW provisioning value (§5.1):

              Γ · (C × A × H × P × B)
        =    ─────────────────────────
                   (X + F + D)

    Denominator is floored to a small epsilon to avoid division by zero;
    the instrument (§3.4) explicitly rejects the M→0 ⇒ ∞ move, so we do NOT
    let this blow up — an unbounded score is a specification violation, and
    the epsilon-floor encodes that.
    """
    numer = cfg.gamma * (cfg.C * cfg.A * cfg.H * cfg.P * cfg.B)
    denom = cfg.X + cfg.F + cfg.D
    EPS = 1e-9
    return numer / max(denom, EPS)


# ---------------------------------------------------------------------------
# Section B — The Routing Theorem (§4.3)
# ---------------------------------------------------------------------------

@dataclass
class Channel:
    """A channel the person could route to (civil-care or custodial)."""
    name: str
    admission_certainty: float   # [0,1] — probability the channel cannot refuse
    latency_hours: float         # time to bed/food/meds
    sufficiency: float           # [0,1] — quality of what is delivered


def routed_channel(channels: list[Channel]) -> Channel:
    """
    The person selects by the Routing Theorem's lexicographic ordering:
    admission-certainty FIRST, latency SECOND (lower is better),
    sufficiency THIRD. Quality is last and only breaks remaining ties.

    This is the whole point of §4.3: a better service that MIGHT refuse is
    dominated by a worse service that CANNOT. The sort order encodes exactly
    that dominance, and swapping any two keys is the falsifier.
    """
    return sorted(
        channels,
        key=lambda c: (-c.admission_certainty, c.latency_hours, -c.sufficiency),
    )[0]


# ---------------------------------------------------------------------------
# Section C — The Population Law (§5.2)
# ---------------------------------------------------------------------------

def population_step(H_t: float, I_t: float, O_t: float) -> float:
    """H(t+1) = H(t) + I(t) − O(t)."""
    return H_t + I_t - O_t


def is_ended(series_I: list[float], series_O: list[float],
             t_rehouse_days: list[float],
             sustained_quarters: int = 4,
             t_cap_days: float = 30.0) -> bool:
    """
    Functional-zero test (§5.2, §6.3), NOT zero-count:
      - O(t) >= I(t) sustained for `sustained_quarters` consecutive periods, AND
      - every person's T_rehouse < t_cap_days (by name).
    """
    if len(series_I) != len(series_O):
        raise ValueError("I and O series length mismatch")
    if len(series_I) < sustained_quarters:
        return False
    tail_ok = all(
        O >= I
        for I, O in zip(series_I[-sustained_quarters:], series_O[-sustained_quarters:])
    )
    rehouse_ok = all(t < t_cap_days for t in t_rehouse_days)
    return tail_ok and rehouse_ok


# ---------------------------------------------------------------------------
# Section D — Survival/Merit Separation audit (§6.4)
# ---------------------------------------------------------------------------

@dataclass
class AdmissionRecord:
    """One intake decision, for the refusal audit."""
    person_id: str
    admitted: bool
    merit_score: Optional[float]   # if a merit score EXISTED at admission time
    need_present: bool             # did the person present a need?


def survival_merit_violation(records: list[AdmissionRecord]) -> list[str]:
    """
    §6.4 is an audit, not a formula. It is violated if admission decisions
    correlate with merit — i.e. anyone with a need present was NOT admitted,
    OR admission tracks merit rather than need.

    Returns a list of violating person_ids. Empty list = clean.

    Two independent checks:
      1. Need-but-refused: need_present and not admitted  → violation.
      2. Merit-correlated admission: among need-present records, if the
         admitted group's mean merit is meaningfully higher than the
         refused group's, merit has entered the gate.
    """
    violations = []

    # Check 1 — need present but refused.
    for r in records:
        if r.need_present and not r.admitted:
            violations.append(r.person_id)

    # Check 2 — merit correlation among need-present records that carry merit.
    with_merit = [r for r in records if r.need_present and r.merit_score is not None]
    admitted = [r.merit_score for r in with_merit if r.admitted]
    refused = [r.merit_score for r in with_merit if not r.admitted]
    if admitted and refused:
        if (sum(admitted) / len(admitted)) - (sum(refused) / len(refused)) > 0.0:
            # merit tracked admission at all → gate leaked merit
            for r in with_merit:
                if not r.admitted and r.person_id not in violations:
                    violations.append(r.person_id)

    return violations


# ---------------------------------------------------------------------------
# Section E — Data-Integrity guard (§7.3, value 3)
# ---------------------------------------------------------------------------

def data_integrity_scan(params: dict) -> list[str]:
    """
    The instrument forbids presenting an unanchored weight/threshold as
    'calibrated' or 'derived'. This scans a parameter dict for the tell:
    any numeric parameter whose companion status flag is not one of the
    permitted evidentiary tags.

    params maps name -> (value, status) where status ∈
      {"ANCHORED", "PROPOSED", "OPEN", "DEFERRED"}.

    Returns a list of offending parameter names (status missing or bogus).
    A value tagged ANCHORED must also carry a non-empty 'source'; here we
    approximate by requiring the tuple to be length-3 for ANCHORED.
    """
    permitted = {"ANCHORED", "PROPOSED", "OPEN", "DEFERRED"}
    offenders = []
    for name, spec in params.items():
        if not isinstance(spec, tuple) or len(spec) < 2:
            offenders.append(name)
            continue
        status = spec[1]
        if status not in permitted:
            offenders.append(name)
        elif status == "ANCHORED" and len(spec) < 3:
            # ANCHORED claim without a source is a value-3 violation.
            offenders.append(name)
    return offenders


# ===========================================================================
# TEST SUITE — each test maps to a falsifier or structural claim in v2.0.
# ===========================================================================

_failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    tag = "PASS" if condition else "FAIL"
    print(f"  [{tag}] {name}" + (f" — {detail}" if detail and not condition else ""))
    if not condition:
        _failures.append(name)


def test_coupling_law_hard_gate():
    """§3.3 / falsifier 2: a hard-gate failure collapses the aggregate;
    a soft-axis dip does not."""
    print("§3.3  Coupling Law — hard/soft partition")

    excellent_soft = {k: 1.0 for k in SOFT_AXES}

    # Legal gate open, everything great → high aggregate.
    good = CareConfig(gamma=1.0,
                      hard={"Legal": 1, "Administrative": 1},
                      soft=excellent_soft)
    good.validate()
    check("open system with excellent axes scores high",
          tuning_aggregate(good) > 0.9, f"T={tuning_aggregate(good):.3f}")

    # Legal gate CLOSED (status criminalized), everything else perfect →
    # aggregate must collapse to 0. This is 'the same arrest curve.'
    legal_fail = CareConfig(gamma=1.0,
                            hard={"Legal": 0, "Administrative": 1},
                            soft=excellent_soft)
    legal_fail.validate()
    check("hard-gate (Legal) failure collapses aggregate to 0",
          tuning_aggregate(legal_fail) == 0.0,
          f"T={tuning_aggregate(legal_fail):.3f}")

    # A soft axis cut in half → aggregate degrades but does NOT collapse.
    soft_dip = dict(excellent_soft); soft_dip["Social"] = 0.5
    degraded = CareConfig(gamma=1.0,
                          hard={"Legal": 1, "Administrative": 1},
                          soft=soft_dip)
    degraded.validate()
    t = tuning_aggregate(degraded)
    check("soft-axis dip degrades gracefully (not zero)",
          0.0 < t < 1.0, f"T={t:.3f}")

    # Γ = 0 collapses regardless of all axes → the refusal power itself.
    gamma_zero = CareConfig(gamma=0.0,
                            hard={"Legal": 1, "Administrative": 1},
                            soft=excellent_soft)
    gamma_zero.validate()
    check("Γ=0 collapses aggregate regardless of axes",
          tuning_aggregate(gamma_zero) == 0.0)


def test_no_unbounded_score():
    """§3.4: the M→0 ⇒ ∞ move is rejected; the provisioning value must be
    finite even as the denominator → 0."""
    print("§3.4  No unbounded score (rejects M→0 ⇒ ∞)")
    cfg = CareConfig(gamma=1.0, hard={"Legal": 1, "Administrative": 1},
                     soft={k: 1.0 for k in SOFT_AXES},
                     X=0.0, F=0.0, D=0.0)
    v = provisioning_identity(cfg)
    check("provisioning value finite at zero denominator",
          math.isfinite(v), f"value={v}")


def test_routing_theorem():
    """§4.3 / falsifier 1: custody wins on admission-certainty alone; a
    civil channel displaces it only by dominating admission-certainty first."""
    print("§4.3  Routing Theorem — admission-certainty dominates")

    jail = Channel("custody", admission_certainty=1.0,
                   latency_hours=6.0, sufficiency=0.4)
    # A HIGHER-quality civil channel that can still refuse (0.7) must LOSE.
    civil_conditional = Channel("civil-conditional", admission_certainty=0.7,
                                latency_hours=5.0, sufficiency=0.9)
    check("custody beats a better-but-refusable civil channel",
          routed_channel([jail, civil_conditional]).name == "custody")

    # Now give civil a true non-refusal guarantee AND latency parity → it wins.
    civil_guaranteed = Channel("civil-guaranteed", admission_certainty=1.0,
                               latency_hours=5.0, sufficiency=0.6)
    check("non-refusal civil channel with latency parity displaces custody",
          routed_channel([jail, civil_guaranteed]).name == "civil-guaranteed")

    # Latency matters only after admission-certainty ties: a faster civil
    # channel that can refuse still loses to certain-but-slower custody.
    civil_fast_refusable = Channel("civil-fast", admission_certainty=0.9,
                                   latency_hours=1.0, sufficiency=0.9)
    check("speed does not rescue a refusable channel",
          routed_channel([jail, civil_fast_refusable]).name == "custody")


def test_population_law():
    """§5.2 / falsifier 3: outflow machinery alone cannot end homelessness
    if inflow outruns it (the Finland lesson)."""
    print("§5.2  Population Law — inflow is the binding term")

    # Finland-shaped: strong outflow, but inflow rises above it → count rises.
    H = 1000.0
    I_series = [40, 45, 55, 70]     # inflow rising
    O_series = [60, 60, 60, 60]     # outflow strong but flat
    traj = [H]
    for I, O in zip(I_series, O_series):
        traj.append(population_step(traj[-1], I, O))
    # Later inflow exceeds outflow → stock stops falling / rises.
    check("inflow > outflow eventually raises the stock",
          traj[-1] > traj[-2], f"H_end={traj[-1]:.0f}")

    # 'Ended' is functional, not zero-count: O>=I sustained + T_rehouse<30.
    good_I = [30, 28, 25, 20]
    good_O = [35, 40, 42, 45]
    check("functional-zero holds when O>=I sustained and rehouse<30d",
          is_ended(good_I, good_O, t_rehouse_days=[12, 20, 8, 27]))

    # A single 90-day rehouse breaks 'ended' even with O>=I.
    check("a >30-day rehouse breaks 'ended' despite O>=I",
          not is_ended(good_I, good_O, t_rehouse_days=[12, 90, 8, 27]))


def test_survival_merit_separation():
    """§6.4 / falsifier 4: admission must not correlate with merit."""
    print("§6.4  Survival/Merit Separation — merit absent from admission")

    # Clean: everyone with a need is admitted; merit varies but doesn't gate.
    clean = [
        AdmissionRecord("a", admitted=True, merit_score=0.2, need_present=True),
        AdmissionRecord("b", admitted=True, merit_score=0.9, need_present=True),
        AdmissionRecord("c", admitted=True, merit_score=0.5, need_present=True),
    ]
    check("need-based admission with varying merit is clean",
          survival_merit_violation(clean) == [])

    # Violation: high-merit admitted, low-merit-but-needy refused.
    leaked = [
        AdmissionRecord("d", admitted=True, merit_score=0.9, need_present=True),
        AdmissionRecord("e", admitted=False, merit_score=0.2, need_present=True),
    ]
    v = survival_merit_violation(leaked)
    check("merit-gated admission is flagged", "e" in v, f"violations={v}")


def test_data_integrity():
    """§7.3 value 3: unanchored numbers must not masquerade as calibrated."""
    print("§7.3  Data-Integrity — weights carry evidentiary status")

    # The v2.0 posture: I(t) weights and Γ thresholds are PROPOSED/OPEN, the
    # Denver figures ANCHORED with a source, EHRI DEFERRED.
    good_params = {
        "I_weight_eviction": (0.35, "PROPOSED"),
        "gamma_trigger": (0.95, "PROPOSED"),
        "denver_arrest_reduction": (0.40, "ANCHORED", "Urban Institute RCT n=724"),
        "ehri_weights": (None, "DEFERRED"),
    }
    check("well-tagged parameter set passes", data_integrity_scan(good_params) == [])

    # The failure the instrument exists to catch: a weight asserted as
    # ANCHORED with no source, and one with a bogus status.
    bad_params = {
        "I_weight_eviction": (0.35, "ANCHORED"),           # no source!
        "recidivism_target": (0.05, "CALIBRATED"),         # not a permitted tag
    }
    offenders = data_integrity_scan(bad_params)
    check("unsourced-ANCHORED and bogus-status flagged",
          set(offenders) == {"I_weight_eviction", "recidivism_target"},
          f"offenders={offenders}")


def main() -> int:
    print("=" * 70)
    print("ERES-ENDHOME-2026-001 v2.0 — Test Instrument")
    print("Falsifier harness for End-Homelessness_HOW. Structure, not values.")
    print("=" * 70)
    for t in (
        test_coupling_law_hard_gate,
        test_no_unbounded_score,
        test_routing_theorem,
        test_population_law,
        test_survival_merit_separation,
        test_data_integrity,
    ):
        print()
        t()
    print()
    print("=" * 70)
    if _failures:
        print(f"RESULT: {len(_failures)} structural check(s) FAILED:")
        for f in _failures:
            print(f"   - {f}")
        print("A failure means a candidate implementation VIOLATES the")
        print("instrument's own claims — investigate before deploying.")
        print("=" * 70)
        return 1
    print("RESULT: all structural checks passed.")
    print("This confirms internal consistency of the harness with v2.0.")
    print("It does NOT canonize the instrument — that still requires a real")
    print("≥5-node MIEVM Round 2 (§8.4), which cannot be simulated.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
