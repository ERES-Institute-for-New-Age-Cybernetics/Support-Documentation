# ERES-ENDHOME-2026-001 — End-Homelessness_HOW (v2.0)

**A falsifier harness for a care-vs-custody model of ending homelessness.**

Author: Joseph A. Sprute (ERES Maestro) · ORCID [0000-0001-9946-3221](https://orcid.org/0000-0001-9946-3221)
Institution: ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
Version: 2.0 (24 July 2026) · Status: pre-canonical · License: CC BY 4.0

---

## What this is

`eres_endhome_test_instrument.py` is the executable companion to the
**End-Homelessness_HOW** canonical instrument. It encodes the instrument's own
structural claims as runnable assertions, so anyone can check whether a
candidate implementation — real jurisdiction data or a hypothetical
configuration — is **consistent with** the model or **violates** it.

**It is a test harness, not a policy simulator.** It does not claim the
framework "works," does not predict outcomes, and does not fit or assert any
empirical value. Per the instrument's Data-Integrity rule (value 3), **no
weight, threshold, or magnitude is hard-coded as true** — every numeric
parameter enters as a caller-supplied input. The harness tests *structure*,
not *values*.

## Contents

| File | Purpose |
|---|---|
| `eres_endhome_test_instrument.py` | The falsifier harness (standard library only) |
| `ERES-ENDHOME-2026-001_End-Homelessness_HOW_v2-0.md` | The canonical instrument (source) |
| `ERES-ENDHOME-2026-001_End-Homelessness_HOW_v2-0.md.pdf` | The same instrument, PDF render |
| `README.md` | This file |

## Requirements

- **Python 3.8 or newer** (tested on 3.12).
- **No third-party dependencies** — standard library only. No `pip install` step.

## Quick start

```bash
python3 eres_endhome_test_instrument.py
```

**Exit code 0** = every structural check passed (the harness is internally
consistent with v2.0). **Non-zero exit** = a violation was found; the offending
check is named in the output.

## What the harness checks

Each test maps to a pre-registered falsifier (§10) or a canonized structure in
the instrument. Every one of these *can fail* — that is the point.

| Section | Claim under test | Falsifier form |
|---|---|---|
| **§3.3 Coupling Law** | Hard-gate axes (Legal, Administrative) are non-separable; soft axes degrade gracefully. `T_care = Γ · G_hard · P_soft`. | A single hard-gate failure must collapse the aggregate to 0; a soft-axis dip must not. |
| **§3.4 No unbounded score** | The provisioning value stays finite as the denominator → 0 (rejects the `M→0 ⇒ ∞` move). | An unbounded score is a specification violation. |
| **§4.3 Routing Theorem** | A care channel displaces custody only if it dominates on admission-certainty first, latency second. | Custody must beat a better-but-refusable civil channel; speed alone must not rescue a refusable one. |
| **§5.2 Population Law** | Inflow `I(t)`, not outflow `O(t)`, is binding; "ended" = functional zero (O ≥ I sustained, rehouse < 30 days, by name). | A >30-day rehousing must break "ended" even when O ≥ I. |
| **§6.4 Survival/Merit Separation** | Merit is additive to opportunity and **absent from admission**. | Any admission decision correlated with merit must be flagged. |
| **§7.3 Data-Integrity** | Every parameter carries an evidentiary status (ANCHORED / PROPOSED / RETIRED). | An unsourced "ANCHORED" value or a bogus status must be flagged. |

## Using it with your own data

The harness is built from small, caller-supplied dataclasses. To test a real or
hypothetical configuration, construct these and call the corresponding function:

- `CareConfig(gamma=…, hard={…}, soft={…}, C=…, A=…, …)` → `tuning_aggregate()`
  / `provisioning_identity()` — score a candidate care-system configuration.
- `Channel(name, admission_certainty, latency, sufficiency, quality)` list →
  `routed_channel()` — which channel a rational actor selects.
- `series_I`, `series_O` lists + rehousing time → `is_ended()` — does a
  jurisdiction meet the functional-zero definition?
- `AdmissionRecord(...)` list → `survival_merit_violation()` — audit whether
  merit ever entered an admission decision.
- `params` dict → `data_integrity_scan()` — check evidentiary tagging.

All axis scores are on `[0, 1]`; `gamma` is the admission-certainty gate;
hard-gate axes are `0` or `1`. Nothing carries a default "correct" value.

## Sample output

```
======================================================================
ERES-ENDHOME-2026-001 v2.0 — Test Instrument
Falsifier harness for End-Homelessness_HOW. Structure, not values.
======================================================================

§3.3  Coupling Law — hard/soft partition
  [PASS] open system with excellent axes scores high
  [PASS] hard-gate (Legal) failure collapses aggregate to 0
  [PASS] soft-axis dip degrades gracefully (not zero)
  [PASS] Γ=0 collapses aggregate regardless of axes
...
RESULT: all structural checks passed.
It does NOT canonize the instrument — that still requires a real
≥5-node MIEVM Round 2 (§8.4), which cannot be simulated.
======================================================================
```

A passing run confirms the harness is internally consistent with v2.0. It does
**not** canonize the instrument: full canonization is gated on a real ≥5-node
MIEVM Round 2 (mean ≥ 9.0, Q5 bias-check administered), which cannot be
simulated.

## Companion document

The `.md` / `.pdf` instrument is the authority; the harness follows it, not the
reverse. Read the instrument for the derivations (Coupling Law §3.3,
Attention-Routing Theorem §4, Population Law §5, Survival/Merit Separation §6.4)
and for the empirical anchors (Denver Supportive Housing SIB RCT, n = 724;
Finland national Housing First, 2008–2025).

## Citation

> Sprute, J. A. (2026). *ERES-ENDHOME-2026-001 — End-Homelessness_HOW (v2.0):
> a falsifier harness for a care-vs-custody model of ending homelessness.*
> ERES Institute for New Age Cybernetics. ORCID 0000-0001-9946-3221.
> DOI: [assigned on deposit].

## License

CC BY 4.0 — ERES Institute default. You may share and adapt with attribution.
