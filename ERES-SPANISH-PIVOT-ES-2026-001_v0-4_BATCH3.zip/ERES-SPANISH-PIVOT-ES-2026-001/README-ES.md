# ERES-SPANISH-PIVOT-ES-2026-001

Fichas de documento en español (Tema Nacional ES v1) para los 95 documentos sembrados en la página española.

- `ERES-ES-00-INDICE-FICHAS-v0-1.pdf` — índice por dominio PiVOT.
- `ERES-ES-NN-<Dominio>-<CLAVE>-FICHA-v0-1.pdf` — una ficha por documento: título ES/EN, dominio, Punto de Lagrange, resumen, palabras clave PiVOT, fuentes.
- `eres-homepage-spanish.html` — página española; PiVOT y enlaces apuntan a la traducción, al gemelo o a la ficha.
- `ERES-ES-CROSSWALK-PIVOT-v0-1.csv` — mapa clave → ficha → URL sugerida (columna `ficha_url`) para actualizar ERES PIVOT — SPANISH.

Destino sugerido: `https://eresinstitute.org/eresmaestro/download/ERES_SPANISH/ERES-SPANISH-PIVOT-ES-2026-001/`

Estado (v0.4 · Lotes 1–3): 19 documentos traducidos íntegramente (`-ES-v1-0.pdf`); 11 con gemelo español existente (enlazado); 65 con ficha, traducción íntegra pendiente.

## Tema Nacional ES v1
| Elemento | Valor |
|---|---|
| Rojo (banda superior, títulos H2, enlaces) | #AA151B |
| Gualda (franja, reglas, Punto de Lagrange) | #F1BF00 |
| Papel | #FBF7EE · paneles #F4ECD8 · líneas #D9CBA3 |
| Texto / secundario | #1A1A1A / #6B5E4A |
| Títulos | Lora 22 pt (H1), 12.5 pt (H2) |
| Cuerpo / IDs | Liberation Sans 10.3 pt / Liberation Mono 7.5–8.6 pt |
| Bordes | banda roja 5 mm + franja gualda 1.6 mm; resumen con filete rojo 3 pt |
| Página | A4, márgenes 22/18/20/18 mm |
| Dominios | F #8a6bff · A #2f8dff · V #18bccf · O #37c66d · R #e3ab3c · S #f05fb4 |

CCAL v2.1 / CC-BY 4.0 — Instituto ERES para la Cibernética de la Nueva Era.
