#!/usr/bin/env python3
"""
ERES-G2-2026-001 v0.2 -- companion testkit (zero-dependency, stdlib only)
"ERES G-2: Flying & Diving Cities" -- gate-constructed Smart-City design.

DESIGN tests (T..) are confirm + refuse and can fail on the design.
UNIT checks (U..) verify helper arithmetic only and carry NO design evidence.
SKIPs mark load-bearing items that need real data.
Exit code 0 = no FAIL.
License: CCAL v2.1 / CC-BY 4.0
"""
import sys

SEED = 20261025
RESULTS = []
def rec(tid, name, status, note=""):
    RESULTS.append((tid, name, status, note))

# ---------------- sourced / declared inputs (instrument Sec. 1, 5) ----------------
LIFT_HE = 1.03            # kg lift per m3 helium at sea level (physics)
RHO_SEA = 1025.0          # kg/m3 seawater
HE_WORLD_M3_YR = 1.9e8    # USGS MCS 2026: world helium production 2025 ~190 million m3
ANTHRO_T = 1.1e12         # Elhacham et al. 2020: anthropogenic mass ~1.1 Tt (tonnes)
POP_2020 = 7.8e9
CROP_M2 = (35, 45, 50)    # NASA review (Frontiers 2021): 40-50 m2/person, 35-40 with insects
WATER_RECOVERY_ISS = 0.98 # NASA 2023
# CONSTRUCTED (unsourced, declared) air-module per-person components, tonnes (low, central, high)
COMP = {"habitat_THOW": (4.5, 6.0, 7.0), "life_support": (0.5, 1.0, 2.0),
        "water_inventory": (0.3, 0.5, 1.0), "energy_storage": (0.3, 0.5, 1.0)}
AREAL_T_PER_M2 = (0.03, 0.06, 0.10)   # growing-system areal mass incl. water/racks
F_STRUCT = (0.15, 0.25, 0.35)          # envelope+structure share of lifted mass

def air_mass_pp(i, food=True):
    pay = sum(v[i] for v in COMP.values())
    f = CROP_M2[i] * AREAL_T_PER_M2[i] if food else 0.0
    return (pay + f) / (1 - F_STRUCT[i]), f, pay + f

# ---------------- grade model ----------------
GRADES = ["BELOW", "GOOD", "SOUND", "BEST"]
def gmin(*gs): return min(gs, key=GRADES.index)
FLOORS = {"water_supply_L": 30.0, "crop_m2": 35.0, "o2_closure": 1.0, "shelter_m3": 25.0}
PILLARS = ("SSST", "SSHP", "SSLA", "SSPS")   # Skills/Trades, Health, Law, Protection
CERT_FLOOR = 0.8                              # declared policy: certified coverage per pillar

def in_band(x, lo, hi): return lo < x < hi
def margin(v, tau): return v * tau
def good_gate(m): return all(m[k] >= FLOORS[k] for k in FLOORS)
def rtb_ok(m): return m["reserve"] >= m["rtb_cost"] + margin(m["drift"], m["tau"])
def cert_ok(m): return all(m["cert"][p] >= CERT_FLOOR for p in PILLARS)
def sound_gate(m):
    return (good_gate(m) and in_band(m["water_recovery"], 0.85, 0.995) and in_band(m["load_frac"], 0.0, 0.95)
            and rtb_ok(m) and m["anchor_tile"] is not None and m["contact_of_record"] and cert_ok(m))
def module_grade(m):
    if not good_gate(m): return "BELOW"
    if not sound_gate(m): return "GOOD"
    return "SOUND"
def city_grade(mods, derived=False):
    g = gmin(*[module_grade(m) for m in mods])
    return "BEST" if (g == "SOUND" and derived) else g

def base(**kw):
    m = dict(medium="ground", water_supply_L=100, crop_m2=45, o2_closure=1.0, shelter_m3=40, water_recovery=0.95,
             load_frac=0.70, reserve=10.0, rtb_cost=4.0, drift=1.0, tau=2.0, anchor_tile=(36.48, -94.23),
             contact_of_record=True, mass_pp_t=6.0, seam="HINGE-fused", dock="releasable",
             survival_requires_module=False, cert={p: 0.9 for p in PILLARS})
    m.update(kw); return m

# ---------------- economy / governance model ----------------
def rate(cbgmodd, bera, favors): return cbgmodd * bera + favors          # RATE = CBGMODD x BERA + FAVORS
def ubimia(income_floor, merit):  return income_floor + max(0.0, merit)  # N floor + additive M
def meritcoin(load_frac):        return 1.0 if in_band(load_frac, 0.0, 0.95) else 0.0   # PoR: tuning in-band only
QUORUM = {"routine": 4, "launch": 5, "dive": 5, "abandon": 6}           # of 7 CBGMODD seats, by finality risk
DOORS = range(1, 10)                                                     # nine Enneagram doors

def nbers_call(door, person):
    """A call to the number anyone can call. Never refused; always ends in provisioning."""
    return {"answered_by_person": True, "outcome": "THOW@anchor", "first_rung": "N-floor",
            "pillar_open": set(PILLARS)}   # door routes the first conversation only; every pillar stays open

# ---------------- DESIGN TESTS ----------------
def T01():
    tpp = ANTHRO_T / POP_2020
    yrs = tpp * 1000 * 1e4 / LIFT_HE / HE_WORLD_M3_YR
    ok = 120 < tpp < 160 and yrs > 5
    rec("T01", "Built-world mass (~141 t/p, sourced) cannot fly: 10k people need >5 yr world He", "PASS" if ok else "FAIL",
        f"{tpp:.0f} t/p, {yrs:.1f} yr")

def T02():
    tot, _, _ = air_mass_pp(1)
    gas_m3 = tot * 1000 / LIFT_HE
    ballast_ratio = (RHO_SEA * gas_m3 - tot * 1000) / (tot * 1000)
    ok = ballast_ratio > 100
    rec("T02", "Single fly+dive hull: to submerge, an air module must take on ~1000x its own mass -> fleet",
        "PASS" if ok else "FAIL", f"ballast/mass={ballast_ratio:.0f}x (refusal holds for any threshold < this)")

def T03():
    ok = good_gate(base()) and not good_gate(base(crop_m2=20)) and not good_gate(base(o2_closure=0.9))
    rec("T03", "GOOD floor: compliant admitted; any single missing floor refused", "PASS" if ok else "FAIL")

def T05():
    ok = rtb_ok(base()) and not rtb_ok(base(reserve=5.0))
    rec("T05", "Return-to-base: reserve >= path + m* passes; short reserve refused", "PASS" if ok else "FAIL")

def T07():
    cands = [base(mass_pp_t=t, load_frac=lf) for t, lf in [(1.0, 0.99), (6.0, 0.70), (20.0, 0.60), (140.0, 0.50)]]
    best = min([c for c in cands if sound_gate(c)], key=lambda c: c["mass_pp_t"])
    ok = best["mass_pp_t"] == 6.0 and not sound_gate(min(cands, key=lambda c: c["mass_pp_t"]))
    rec("T07", "BEST bounded: unconstrained lightest breaches band; chosen = lightest SOUND", "PASS" if ok else "FAIL")

def T08():
    fleet = [base(), base(medium="sea"), base(medium="air", reserve=3.0)]
    ok = city_grade(fleet) == "GOOD" and city_grade(fleet[:2]) == "SOUND"
    rec("T08", "Min-composition: one non-SOUND module grades city down", "PASS" if ok else "FAIL")

def T09():
    hum = lambda f: all(not m["survival_requires_module"] for m in f if m["medium"] != "ground")
    ok = hum([base(), base(medium="air")]) and not hum([base(medium="air", survival_requires_module=True)])
    rec("T09", "M/N line: survival never depends on sea/air residency", "PASS" if ok else "FAIL")

def T10():
    promote = lambda k, prior, measured: k == 0 or (prior and measured)
    ok = promote(0, False, False) and promote(2, True, True) and not promote(2, True, False)
    rec("T10", "Staged promotion requires prior stage SOUND on MEASURED data", "PASS" if ok else "FAIL")

def T11():
    j = lambda m: m["seam"] == "HINGE-fused" and m["dock"] == "releasable"
    ok = j(base()) and not j(base(dock="HINGE-fused"))
    rec("T11", "HINGE: fused seams build hulls; docks stay releasable", "PASS" if ok else "FAIL")

def T12():
    ok = sound_gate(base()) and not sound_gate(base(anchor_tile=None))
    rec("T12", "LLPM: mobile module bound to anchor tile; unbound refused", "PASS" if ok else "FAIL")

def T13():
    ok = sound_gate(base()) and not sound_gate(base(contact_of_record=False))
    rec("T13", "SROC Contact of Record: no callable number -> not SOUND", "PASS" if ok else "FAIL")

def T14():
    ok = city_grade([base()]) == "SOUND" and city_grade([base()], True) == "BEST"
    rec("T14", "Nothing DERIVED => none BEST", "PASS" if ok else "FAIL")

def T15():
    tot, food, pay = air_mass_pp(1)
    share = food / pay
    cap = HE_WORLD_M3_YR * LIFT_HE / (tot * 1000)
    ok = share < 0.5 and 5_000 < cap < 50_000
    rec("T15", "Air mass budget (computed): food is minority of payload; binding limit = lifting gas supply",
        "PASS" if ok else "FAIL", f"{tot:.1f} t/p, food share {share:.2f}, 1 yr world He lifts ~{cap:,.0f} people")

def T16():
    ok = sound_gate(base()) and not sound_gate(base(cert={"SSST": 0.9, "SSHP": 0.9, "SSLA": 0.9, "SSPS": 0.5}))
    rec("T16", "People gate: all four SCALULAR pillars certified >= floor; weakest pillar blocks", "PASS" if ok else "FAIL")

def T17():
    calls = [nbers_call(d, p) for d in DOORS for p in range(5)]
    ok = all(c["answered_by_person"] and c["outcome"] == "THOW@anchor" for c in calls)
    rec("T17", "NBERS: every call answered by a person and ends in provisioning; none refused", "PASS" if ok else "FAIL")

def T18():
    reach = all(nbers_call(d, 0)["pillar_open"] == set(PILLARS) for d in DOORS)
    same_floor = len({nbers_call(d, 0)["first_rung"] for d in DOORS}) == 1
    ok = reach and same_floor
    rec("T18", "Enneagram doors not ranks: all 9 doors reach all 4 pillars, same floor", "PASS" if ok else "FAIL")

def T19():
    ok = rate(0.0, 0.0, 0.3) >= 0.3 and rate(0.8, 0.9, 0.3) > rate(0.0, 0.9, 0.3)
    rec("T19", "RATE = CBGMODD x BERA + FAVORS: floor survives multiplier collapse", "PASS" if ok else "FAIL")

def T20():
    ok = ubimia(1.0, -5.0) == 1.0 and ubimia(1.0, 2.0) == 3.0
    rec("T20", "UBIMIA: Income floor (N) unconditional; Merit (M) additive, never subtracts", "PASS" if ok else "FAIL")

def T21():
    ok = meritcoin(0.70) == 1.0 and meritcoin(0.99) == 0.0
    rec("T21", "Meritcoin PoR: tuning in-band earns; over-drive past wall earns nothing", "PASS" if ok else "FAIL")

def T22():
    ok = QUORUM["abandon"] > QUORUM["launch"] > QUORUM["routine"] and all(q <= 7 for q in QUORUM.values())
    rec("T22", "CBGMODD quorum rises with finality risk (routine < launch/dive < abandon)", "PASS" if ok else "FAIL")

def T23():
    # Bottom-up grade x top-down band: a module SOUND locally but outside the fleet band is held at GOOD
    fleet_band = (0.0, 0.85)
    def bu_td(m): return module_grade(m) if in_band(m["load_frac"], *fleet_band) else gmin(module_grade(m), "GOOD")
    ok = bu_td(base(load_frac=0.70)) == "SOUND" and bu_td(base(load_frac=0.90)) == "GOOD"
    rec("T23", "Bottom-up/top-down: local SOUND overridden by fleet band (both act at once)", "PASS" if ok else "FAIL")

def T24():
    gcf = {"Credits": ["CERT:SSST", "CERT:SSHP"], "Liabilities": ["SLA:duty-to-steward"], "Aims": ["Stage-1 sea"]}
    ok = set(gcf) == {"Credits", "Liabilities", "Aims"} and any("SLA" in x for x in gcf["Liabilities"])
    rec("T24", "GCF account (GraceChain): CERTs=Credits, SLA duty=Liabilities, stage goal=Aims", "PASS" if ok else "FAIL")

# ---------------- UNIT CHECKS (no design evidence) ----------------
def U1():
    ok = in_band(0.9, 0.85, 0.995) and not in_band(0.80, 0.85, 0.995) and not in_band(0.999, 0.85, 0.995)
    rec("U1", "unit: two-sided band helper", "PASS" if ok else "FAIL")
def U2():
    ok = margin(2.0, 3.0) == 6.0
    rec("U2", "unit: m* = v*tau helper", "PASS" if ok else "FAIL")

def SKIPS():
    rec("S1", "Measured closed-loop life-support data (anchor stage first)", "SKIP", "needs measurement")
    rec("S2", "HINGE Phase-0 coupon", "SKIP", "inherited from ERES-HINGE-WP-2026-001")
    rec("S3", "Lifting gas: He vs H2 vs hybrid", "SKIP", "OPEN design decision")
    rec("S4", "Pillar curricula mapped from existing licensing bodies", "SKIP", "OPEN")
    rec("S5", "Independent >=5-node MIEVM round", "SKIP", "not run")

if __name__ == "__main__":
    for t in (T01, T02, T03, T05, T07, T08, T09, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19,
              T20, T21, T22, T23, T24, U1, U2, SKIPS):
        t()
    print(f"ERES-G2-2026-001 v0.2 testkit  seed={SEED}  python={sys.version.split()[0]}")
    for tid, name, st, note in RESULTS:
        print(f"[{st:4s}] {tid:4s} {name}" + (f"  ({note})" if note else ""))
    T = [r for r in RESULTS if r[0].startswith("T")]; U = [r for r in RESULTS if r[0].startswith("U")]
    F = sum(r[2] == "FAIL" for r in RESULTS); S = sum(r[2] == "SKIP" for r in RESULTS)
    print(f"\nDESIGN {sum(r[2]=='PASS' for r in T)}/{len(T)} PASS · UNIT {sum(r[2]=='PASS' for r in U)}/{len(U)} PASS · {F} FAIL · {S} SKIP")
    sys.exit(1 if F else 0)
