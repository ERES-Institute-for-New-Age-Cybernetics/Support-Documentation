# Submission Meta Text — ERES-G2-2026-001 v0.2

## SEO title
ERES G-2 Flying & Diving Cities: A Gate-Constructed Smart-City Design Where BEST/SOUND/GOOD Emerges From Physics, Certified People and an Unconditional Floor

## Abstract (≈200 words)
How should a smart city be built so that its quality emerges from tests it must pass rather than from claims? ERES G-2 answers for the hardest case: cities that fly and dive. Sourced inputs show that the built world (~141 t of human-made mass per person) cannot fly; that a food-closed air module of ~14 t per person can, but one year of world helium output lifts only ~14,000 people; and that the ~1000× ballast an air hull would need to dive forces a modular fleet of ground anchor, sea and air modules. Each stage is promoted only when the previous stage holds a two-sided operating band on measured data, every module can return to base, and certified people cover all four pillars — Skills/Trades, Health, Law, Protection. Entry is one public number, never refused, routed by nine doors that are not ranks. An unconditional income floor (UBIMIA) sits beneath merit earned by holding systems in band; RATE = CBGMODD × BERA + FAVORS keeps the floor alive if the multiplier collapses. A zero-dependency testkit checks 22 design rules in confirm-and-refuse form. Status: CONSTRUCTED design, no measured data; the anchor stage is buildable now.

## Keywords
smart city; floating city; underwater habitat; airship; closed-loop life support; bioregenerative life support; helium supply; modular architecture; return to base; certification; workforce development; universal basic income; proof of resonance; governance design; falsifiable design; ERES; GSSG; HINGE; SCALULAR; NBERS; Enneagram; UBIMIA; GraceChain; CBGMODD; RATE

## ResearchGate share message
New ERES instrument: G-2 Flying & Diving Cities (v0.2). Not a vision piece — a gate-constructed design. The physics says the built world can't fly, a ~14 t/person air module can, and lifting gas (not food) is the limit. Every stage waits on measured data and certified people in four pillars; entry is one number anyone can call. Testkit included (22/22 design rules, 5 named open items). CCAL v2.1 / CC-BY 4.0.

## LinkedIn share message
Flying and diving cities sound like fiction until you make them pass gates. ERES G-2 v0.2 starts on the ground, today: water and food closure, certified trades, health, law and protection, and a number anyone can call that never refuses. Sea and air only follow when measured data says the stage before holds. Full package with testkit and timeline.
