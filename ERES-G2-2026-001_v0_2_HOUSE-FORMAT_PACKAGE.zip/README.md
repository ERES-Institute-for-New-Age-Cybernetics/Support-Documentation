# ERES-G2-2026-001 v0.2 — ERES G-2: Flying & Diving Cities
**How to Construct a Smart City So That BEST / SOUND / GOOD Emerges as End-Outcome**

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics · ORCID 0000-0001-9946-3221
Status: CONSTRUCTED DRAFT · author-side self-rate ≈ 8.5 (meets 8.5 Emanuel threshold as design; below 9.0 Stergios) · nothing DERIVED ⇒ none BEST · not MIEVM-rated
License: CCAL v2.1 / CC-BY 4.0

## Package contents (ERES House Format)
| File | Role |
|---|---|
| `ERES-G2-2026-001_v0_2.md` | Instrument — master text |
| `ERES-G2-2026-001_v0_2.pdf` | Instrument — reading copy (figure embedded) |
| `ERES-G2-2026-001_v0_2_timeline.svg` | Progressive timeline (gate-ordered, dates unspecified) |
| `eres_g2_testkit.py` | Zero-dependency testkit (stdlib only) |
| `RUN.txt` | Captured run: DESIGN 22/22 · UNIT 2/2 · 0 FAIL · 5 SKIP · exit 0 |
| `META_TEXT.md` | SEO title, abstract, keywords, ResearchGate and LinkedIn share messages |
| `CITATION.cff` | Citation metadata |
| `COVER_Dr-Pellis.md` | Cover note to Dr. Stergios Pellis (HOLD until author sends) |
| `MANIFEST.json` | SHA-256 of every file |
| `README.md` | This file |

## Reviewer reading order
1. PDF §1 (physics) and the timeline figure
2. §4 gates → §5 people → §6 entry → §7 economy
3. Run `python3 eres_g2_testkit.py` and compare with `RUN.txt`
4. Check checksums against `MANIFEST.json`

## Verification hierarchy
1. Files present and checksums match MANIFEST
2. Testkit runs with stdlib only, exit 0
3. Output matches RUN.txt line for line (except the Python version)
4. Each claim in §10 traces to a named test
5. DESIGN tests can fail on the design; UNIT checks carry no design evidence
6. SKIPs are named and remain open — they are the path to 9.0, not hidden gaps

## Non-claims
No physical component is built. No measured data. CONSTRUCTED mass components are declared, not sourced. Pellis-source use is ANALOGICAL and implies no endorsement of the governance application.
