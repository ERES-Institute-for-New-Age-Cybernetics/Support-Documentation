#!/usr/bin/env python3
"""
adapter_template.py -- copy this file to add a new domain to Recycle Everything Made.

THE ONE RULE: you never change the disposition rule. You only write an adapter that maps an item
from your domain to five yes/no inputs. If your domain needs a sixth input or a new rule, that is
a finding (falsifier F6) -- open an issue, do not patch the core.

The five inputs:
  in_service_value  -- is the item still useful as it is (or after repair/service/reuse)?
  identified        -- do we know what it is and who answers for it? (No -> it is Held.)
  immutable         -- is it a record that must never leave service (e.g. a DOI'd version)?
  retire_request    -- has someone asked to retire it?
  validated         -- has a SECOND person (not the requester) signed that retirement?

Privacy (LLPM I6): an item may carry a coordinate for a RESOURCE, never a person's location.
Do not put names, addresses of people, or person-tracking fields into your items.

Example domain below: household electronics. Replace it with yours.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "core"))
from eres_cleanspace_testkit import dispose  # noqa: E402  (the one rule; do not reimplement)

DOMAIN = "household-electronics"          # <- rename
FIVE_INPUTS = ("in_service_value", "identified", "immutable", "retire_request", "validated")


def adapt(item: dict) -> dict:
    """Map one item from your domain to the five inputs. Keep this pure: no I/O, no side effects."""
    return {
        "in_service_value": item.get("works", False) or item.get("repairable", False),
        "identified": item.get("serial") is not None,
        "immutable": False,
        "retire_request": item.get("hazardous_end_of_life", False),
        "validated": item.get("certified_recycler") is not None,
    }


def disposition(item: dict) -> str:
    return dispose(adapt(item))


if __name__ == "__main__":
    demo = [
        {"serial": "TV-001", "works": True},
        {"serial": "PH-002", "repairable": True},
        {"serial": "BAT-003", "hazardous_end_of_life": True, "certified_recycler": "R2-site-17"},
        {"serial": "BAT-004", "hazardous_end_of_life": True},
        {"works": True},
    ]
    for d in demo:
        print(f"{str(d):90} -> {disposition(d)}")
