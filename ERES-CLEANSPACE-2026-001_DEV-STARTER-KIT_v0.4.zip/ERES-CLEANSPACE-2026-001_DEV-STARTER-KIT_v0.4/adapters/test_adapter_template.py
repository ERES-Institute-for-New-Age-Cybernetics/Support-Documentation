#!/usr/bin/env python3
"""Starter tests for an adapter. Copy alongside your adapter and keep all five checks."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import adapter_template as A  # noqa: E402  <- change to your adapter module

PERSON_WORDS = ("name", "person", "owner_address", "home_address", "location_of", "gps_of")


class TestAdapter(unittest.TestCase):
    def test_returns_exactly_five_boolean_inputs(self):
        out = A.adapt({"serial": "X"})
        self.assertEqual(set(out), set(A.FIVE_INPUTS))
        self.assertTrue(all(isinstance(v, bool) for v in out.values()))

    def test_unidentified_item_is_held(self):
        self.assertEqual(A.disposition({"works": True}), "Held")

    def test_retirement_needs_second_signature(self):
        self.assertEqual(A.disposition({"serial": "B", "hazardous_end_of_life": True}), "Held")
        self.assertEqual(A.disposition({"serial": "B", "hazardous_end_of_life": True,
                                        "certified_recycler": "R2"}), "Retired")

    def test_useful_item_is_recyclable(self):
        self.assertEqual(A.disposition({"serial": "T", "works": True}), "Recyclable")

    def test_no_person_fields_are_read(self):
        src = open(A.__file__, encoding="utf-8").read().split("def adapt", 1)[1].split("def disposition", 1)[0]
        for w in PERSON_WORDS:
            self.assertNotIn(f'"{w}', src, f"adapter reads a person field: {w}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
