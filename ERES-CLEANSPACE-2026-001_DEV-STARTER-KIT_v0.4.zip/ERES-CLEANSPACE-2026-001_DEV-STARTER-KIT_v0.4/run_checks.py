#!/usr/bin/env python3
"""Run every check a pull request must pass. Same as CI. Standard library only. Exit 0 = ready."""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
steps = [
    ("core test suite", [sys.executable, "-I", os.path.join(ROOT, "core", "eres_cleanspace_testkit.py")]),
    ("adapter tests", [sys.executable, "-I", "-m", "unittest", "discover", "-s", os.path.join(ROOT, "adapters"),
                       "-p", "test_*.py"]),
]
failed = 0
for name, cmd in steps:
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    ok = r.returncode == 0
    failed += not ok
    last = (r.stdout.strip().splitlines() or r.stderr.strip().splitlines() or [""])
    summary = next((l for l in reversed(last) if "PASS /" in l or l.startswith(("OK", "FAILED", "Ran"))), last[-1])
    print(f"{'PASS' if ok else 'FAIL'}  {name:18} {summary}")
    if not ok:
        print(r.stdout[-2000:], r.stderr[-2000:])
print("ready" if not failed else f"{failed} step(s) failed")
sys.exit(1 if failed else 0)
