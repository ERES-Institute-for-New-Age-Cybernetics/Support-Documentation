# Recycle Everything Made — Developer Starter Kit (v0.4)

**Start here if you're new to ERES.** This kit is the smallest working piece of the ERES framework you can run, test and extend. It asks four questions about everything people make: what to recycle, why, how, and where. It answers them with code you can check.

## Run it (one command, no installs)

```
python3 run_checks.py
```

You should see `ready`. That runs the core test suite (24 checks) and the adapter tests. Python 3.9 or newer, standard library only.

## The idea in five lines

1. **Everything made is in scope.** Anything we can't identify is *Held*, never thrown away.
2. **Every item gets one of three outcomes:** *Recyclable* (back into use), *Held* (waiting, under investigation), or *Retired* (leaves service).
3. **Retiring needs two people:** someone asks, someone else signs.
4. **The recovery band is 97/3–98/2.** Of everything resolved, 97–98% should return to use and 2–3% leave. Retiring more loses things that matter; retiring less means nothing was cleaned.
5. **Things have addresses, people don't.** The ledger answers "what is at this coordinate", never "where is this person".

## Words you'll meet (plain meanings)

| Term | Plain meaning |
| --- | --- |
| ERES | The ERES Institute for New Age Cybernetics, which maintains this framework |
| Disposition | The outcome for an item: Recyclable, Held or Retired |
| Recovery ratio | Recyclable ÷ (Recyclable + Retired), ignoring Held items |
| Adapter | Your code that translates one domain's items into the five inputs the rule needs |
| LLPM | The coordinate ledger (Longitude–Latitude Property-Management) |
| VEILED | Hidden by design: a person's link to a resource can be proved but not exposed |
| Conjunctive gate | Four checks multiplied together; if any is zero, nothing happens |
| CONSTRUCTED / DERIVED | A designed rule vs a result proven from data or math. Label every claim |
| SKIP | A test for work that's not done yet. It names the gap instead of hiding it |

## Layout

| Folder | What's inside |
| --- | --- |
| `core/` | The rule, the inventory tool, the "Where" layer and the test suite. Change only by version cut |
| `adapters/` | Where you add a new domain. Start from `adapter_template.py` |
| `docs/` | The full specification (v0.4), PDF and figures |
| `evidence/` | Real runs. The first one inventoried two ERES archives |
| `.github/workflows/` | CI that runs `run_checks.py` on every pull request |

## Your first contribution

Pick an item from `ISSUES.md` marked **good first issue**, or write an adapter for a domain you know. Read `CONTRIBUTING.md` first.

License: CCAL v2.1 / CC-BY 4.0 (governing text DOI 10.5281/zenodo.23451312). Spec: ERES-CLEANSPACE-2026-001 v0.4, by Joseph Allen Sprute (ERES Maestro).
