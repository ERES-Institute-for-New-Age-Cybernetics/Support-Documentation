# Contributing

Thank you for helping. These rules keep the framework honest as it grows.

## Hard rules (a pull request that breaks one is not merged)

1. **Never change the disposition rule in an adapter.** Write an adapter that maps your domain to the five inputs. If you can't, that's a research finding (falsifier F6): open an issue.
2. **No person-location, ever.** Nothing you add may answer "where is this person". Resources have coordinates; people have only VEILED references (LLPM invariant I6).
3. **Water stays commons.** No code may move a WATER-class record into private ownership (I1).
4. **Care, not eviction.** A missing safety attestation on an occupied dwelling triggers care. It is never grounds to retire the dwelling or remove anyone (I2).
5. **Two signatures to retire.** The person who requests a retirement cannot also validate it.
6. **No fabricated data.** Synthetic data must be labeled synthetic. Never present a toy result as a real-world result.
7. **Label every claim.** CONSTRUCTED (designed), DERIVED (proven within a stated model), CONJECTURE or VISION. When unsure, use the weaker tag.
8. **The band and the core rule change only by a version cut.** 0.97 and 0.98, the five inputs and the three dispositions are fixed within a version. Propose changes as an issue; the maintainer cuts the next version.

## How to submit

1. Fork, branch, make your change.
2. Run `python3 run_checks.py` until it says `ready`.
3. Add tests for what you added. An adapter needs at least the five checks in `adapters/test_adapter_template.py`.
4. Open a pull request saying which issue, falsifier or SKIP it addresses.

## Turning a SKIP into a PASS

A SKIP becomes a PASS only with real evidence: the data source named, the method fixed **before** the run, and the result published whether it passes or fails. A pre-registered failure is a good contribution.

## Credit

Contributors are credited by name in the next version's Credits section. The specification's accountable author remains Joseph Allen Sprute (ERES Maestro).
