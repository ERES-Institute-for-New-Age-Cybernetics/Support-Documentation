# License

CCAL v2.1 (CARE Commons Attribution License v2.1). The governing text is the Zenodo deposit DOI 10.5281/zenodo.23451312, which controls over any copy.

CCAL v2.1 matches CC-BY 4.0 in attribution and adds the Care Clause, Earth-First Constraint, Transparency, Share-Forward, Non-Enclosure and Patent Non-Assertion. Derivatives may be released under CC-BY 4.0, CC-BY-SA 4.0, MIT, Apache 2.0, ODC-BY, GFDL or CERN-OHL-S v2 (CCAL §12).

Attribution: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics. ERES-CLEANSPACE-2026-001.
