# First issues

Seeded from the v0.4 SKIPs and the first real inventory (19 October 2026). Core-safe issues don't touch the rule or the band.

| # | Issue | Label | Touches core? |
| --- | --- | --- | --- |
| 1 | **Nested ZIP inventory.** `eres_cleanspace_manifest.py` doesn't look inside ZIPs inside ZIPs. Add read-only recursion (in memory, never extracting to disk), with a depth limit and tests | good first issue | tool only |
| 2 | **Same-name collision detection.** An archive held two different files with one name; unzip silently kept one. Detect duplicate names with different CRCs and report them | good first issue | tool only |
| 3 | **A real third domain (F6).** Write an adapter for a real domain (household electronics, a website's files, a farm co-op's equipment) and run it on real items | good first issue | no |
| 4 | **Orphan routing helper.** Suggest likely instrument IDs for files with none, for the author to confirm; never assign automatically | help wanted | tool only |
| 5 | **Full-corpus run (S3).** Pre-register retirement criteria, name a validator who isn't the author, run on the whole corpus, publish the manifest whatever the result | research | no |
| 6 | **Orbital catalogue data (S1 / F1).** Run targeted-vs-random removal on a public catalogue with a published environment model | research | no |
| 7 | **Measured drift and latency (S2 / F2).** Measure v and τ for one real domain and test which band edge holds | research | no |
| 8 | **VEIL cryptography (S5).** Prove "this tile has an answerable steward" without revealing who or where. LLPM's hardest open item | research, hard | design review first |
| 9 | **Inference audit (F7).** Can a person's location be inferred from public resource records alone? Attack it and report | research | no |
| 10 | **Independent review (S4).** Review v0.4 and score it; four or more independent reviewers needed for SOUND | review | no |
