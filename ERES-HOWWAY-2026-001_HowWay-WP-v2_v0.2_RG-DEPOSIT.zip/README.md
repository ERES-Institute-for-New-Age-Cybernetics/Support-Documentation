# ERES-HOWWAY-2026-001 - HowWay WP v2 (v0.2 PROPOSED)

**HowWay = ERES @: Runtime Assurance for AI Governance**
Answering six control-assurance questions inside the workflow (HowWay WP v2)

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics - ORCID 0000-0001-9946-3221
Drafting and validation node: Claude (Anthropic); not an author. Date: 2026-09-28. License: CCAL v2.1 / CC-BY 4.0.

## What this is
A whitepaper defining HowWay (the Method term of C = R x P / M) as the ERES layer that answers six runtime-assurance questions: prove the control operates, see the telemetry, collect evidence automatically, detect change, stop or escalate at runtime, and govern inside the workflow. Mechanism: GEAR x DERR + ERES. Spine: the PlayNAC HowWay sequence.

## Contents
| File | Role |
|---|---|
| ERES-HOWWAY-2026-001_HowWay-WP-v2_v0.2.pdf | Whitepaper (PDF) |
| ERES-HOWWAY-2026-001_HowWay-WP-v2_v0.2.md | Whitepaper (Markdown; same text) |
| ERES-HOWWAY-2026-001_Figure-1_GEAR-DERR-ERES-Loop.svg | Figure 1 (SVG) |
| eres_howway_test_instrument.py | Test instrument (Python standard library only) |
| CREDITS.md | Credits |
| REFERENCES.md | Internal and external references |
| LICENSE.md | Full CCAL v2.1 text |
| META.txt | ResearchGate / Zenodo submission metadata |
| MANIFEST.json | sha256 for every file above |
| README.md | This file |

## Run the tests
    python3 eres_howway_test_instrument.py
Expected from a fresh extract: 38 tests, 31 pass, 7 skipped by design (open items H1-H7), exit code 0.

## Boundary
Green means SPECIFICATION against a MODELED adversary. Not a runtime; not proof against a live or novel attacker; no is_safe / is_compliant verdict. Seven items are open (H1-H7); H5, an external red-team of a running system, cannot be simulated. Bio-electric, Kirlianographic and Schumann-resonance inputs are [CONJECTURE] and excluded from every claim.

## Status
v0.2 PROPOSED, pre-canonical, NOT MIEVM-rated, ID pending JAS confirmation. Supersedes v0.1 (2026-09-28).

## License
CCAL v2.1 / CC-BY 4.0. Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1. See LICENSE.md.

Don't hurt yourself. Don't hurt others. Build for generations to come.
