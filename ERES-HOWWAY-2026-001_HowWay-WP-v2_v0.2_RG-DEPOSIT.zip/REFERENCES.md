# References - ERES-HOWWAY-2026-001 v0.2

## Internal (ERES)

[I1] Sprute, J. A. ERES PlayNAC "HowWay": Organizer for User/GROUP Pedagogy and Emergency Management Critical Infrastructure (EMCI) Game Theory. Published 2018-07-25; revised 2018-07-26 and 2025-07-06. ERES Institute. Open Source Common Core.
[I2] Sprute, J. A. (2026, March). What / With / Why and HowWay: AnswerQuestion.IT.MyWay, GEAR x DERR + ERES (with Schumann Resonance detail). ERES Institute. CCAL v2.1.
[I3] Sprute, J. A. (2026, July 17). ERES-VOTING-2026-001 v0.2, Addendum 13: Divine HowWay (the Delivery Cross-Walk). ERES Institute. CCAL v2.1 / CC-BY 4.0.
[I4] Sprute, J. A. (2026, September). ERES-ARH-2026-001 v0.1: Adversarial Root Hardening. ERES Institute.
[I5] ERES-CDFE-2026-001 v1.1: Covariance-Discounted Floor Engine. ERES Institute. (See that instrument for its own credits.)
[I6] ERES-CPROV-2026-001: Constitutional Provenance. ERES Institute.
[I7] ERES-PLAYNAC-GOVERNANCE-2026-001: PlayNAC resonance-governance stack (BERA, RHC, SOMT, MIEVM, PoR, CBGMODD, RCR, RAEC). ERES Institute.
[I8] Sprute, J. A. (2026, September 28). ERES-HOWWAY-2026-001 v0.1: HowWay = ERES @, Runtime Assurance for AI Governance. Superseded by this version.
[I9] ERES-RRH-2026-001: Regulatory Root Hardening (EU AI Act, GDPR, eIDAS). Drafting approved 2026-09-24; not part of this package.
[I10] ERES-LEGAL-2026-001: Doctrine of Verifiable Claims (tag discipline: DERIVED, CONSTRUCTED, CONJECTURE, VALIDATED, STATED). ERES Institute.
[I11] CARE Commons Attribution License v2.1 (CCAL v2.1). ERES Institute for New Age Cybernetics. Effective 2026-04-26.

## External

[E1] European Union. Regulation (EU) 2024/1689 (Artificial Intelligence Act), in particular Articles 12 (record-keeping), 14 (human oversight) and 72 (post-market monitoring). Official Journal of the European Union, 12 July 2024.
[E2] National Institute of Standards and Technology. Artificial Intelligence Risk Management Framework (AI RMF 1.0). NIST AI 100-1, January 2023.
[E3] National Institute of Standards and Technology. Information Security Continuous Monitoring (ISCM) for Federal Information Systems and Organizations. NIST SP 800-137, September 2011.
[E4] ISO/IEC 42001:2023. Information technology - Artificial intelligence - Management system.
[E5] Schneider, F. B. (2000). Enforceable security policies. ACM Transactions on Information and System Security, 3(1), 30-50.
[E6] Leucker, M., and Schallhart, C. (2009). A brief account of runtime verification. Journal of Logic and Algebraic Programming, 78(5), 293-303.
[E7] Crosby, S. A., and Wallach, D. S. (2009). Efficient data structures for tamper-evident logging. Proceedings of the 18th USENIX Security Symposium, 317-334.
[E8] Laurie, B., Langley, A., and Kasper, E. (2013). Certificate Transparency. RFC 6962, IETF.
[E9] Douceur, J. R. (2002). The Sybil attack. Peer-to-Peer Systems (IPTPS 2002), Lecture Notes in Computer Science 2429, 251-260.

*External references (E1-E9) were supplied from the drafting node's training knowledge and were not re-checked against the sources during this session. Verify volume, page and clause details before deposit.*
