# Credits - ERES-HOWWAY-2026-001 v0.2

**Author of record.** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221. Sole author.

**Corpus lineage acknowledged.** The ERES PlayNAC HowWay page (published 2018, revised 2018 and 2025) [I1]; What / With / Why and HowWay (March 2026) [I2]; ERES-VOTING-2026-001 v0.2 Addendum 13 [I3]; ERES-ARH-2026-001 v0.1 [I4]; ERES-CDFE-2026-001 v1.1 [I5]; ERES-CPROV-2026-001 [I6]; the PlayNAC governance stack [I7]; and HowWay v0.1 [I8]. CDFE carries its own credits; this paper uses it only as a general effective-independence scorer over a node-correlation matrix, and invokes no application of it.

**Drafting and validation node.** Claude (Anthropic), working under the H2C2H method. Claude is a drafting and validation node, not an author. No MIEVM rating has been applied to this version.

**External literature.** Authors of works E1-E9 are credited through the References; none has reviewed or endorsed this paper.

**Prompting context.** Item H6 exists because of a public regulatory critique of the ERES corpus (September 2026); see [I9]. The critic is not named here.

**No endorsement.** No third party has reviewed, approved or endorsed this paper. Individuals and organisations named elsewhere in the ERES corpus are not endorsers of it.

License: CCAL v2.1 / CC-BY 4.0.
