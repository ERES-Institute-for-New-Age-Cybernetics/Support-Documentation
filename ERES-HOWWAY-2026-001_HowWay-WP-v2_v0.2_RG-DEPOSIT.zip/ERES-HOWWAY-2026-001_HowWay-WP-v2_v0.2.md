# HowWay = ERES @: Runtime Assurance for AI Governance
*Answering six control-assurance questions inside the workflow (HowWay WP v2)*

**ERES-HOWWAY-2026-001** | v0.2 PROPOSED (HowWay WP v2) - pre-canonical, NOT MIEVM-rated, ID pending JAS confirmation | 2026-09-28 | Supersedes v0.1 | CCAL v2.1 / CC-BY 4.0

Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics - ORCID 0000-0001-9946-3221. Drafting and validation node: Claude (Anthropic); not an author.

## Abstract

Assessment-time governance asks whether a control existed on the day someone looked. Runtime governance asks whether the control is operating now, can be seen operating, produces its own evidence, notices change, can stop or escalate an action, and does so inside the workflow. This paper defines HowWay, the Method term (M) of C = R x P / M and the Method column of PlayNAC, as the ERES layer that answers six such questions, and reads the operator '@' as the corpus defines it: methodology or process inquiry, so 'ERES @' is ERES as method. Version 2 recasts the mechanism as GEAR x DERR + ERES (record, diagnose, remediate), adds the PlayNAC HowWay sequence as the in-workflow spine, tags every claim under the Doctrine of Verifiable Claims, and ships a stdlib-only test instrument. The claim is bounded: the six answers are design properties checked at specification level against a modeled adversary; they are not evidence of operation in a live deployment, and none depends on bio-electric, Kirlianographic or Schumann-resonance inputs, which remain [CONJECTURE] and are excluded. Seven items (H1-H7) remain open; H5, an external red-team of a running system, cannot be simulated.

## Changes from v0.1

- **'@' corrected.** v0.1 read '@' as 'ERES at the point of action'. The corpus defines '@' as the methodology or process operator [STATED: I2]. That is now the definition; 'at the point of action' survives only as a design consequence [DERIVED].
- **Mechanism recast** as GEAR x DERR + ERES [STATED: I2] and mapped onto the six questions (Figure 1, section 4).
- **PlayNAC HowWay sequence** (12 steps) added as the in-workflow spine for Q6 (section 5).
- **Doctrine tags** on claims; boundary section rewritten; bio-electric layer scoped out (H7 added).
- **Effect-ledger requirement** added for H1: a log cannot show what bypassed it (section 6).
- **Package** now carries the figure, test instrument, README, credits, references, full license and meta text.

## 1. The gap: assessment-time versus runtime assurance

A conventional control is evidenced by a sample: policies, screenshots, tickets, an interview. Evidence is gathered after the fact, so a change made the week after sampling stays invisible until the next assessment. The delay between a control failing and anyone knowing is the exposure. The six questions in section 4 ask for properties of the control itself rather than documents about it.

## 2. HowWay defined

Three corpus sources fix the term. (a) In the identity C = R x P / M, M is Method, and HowWay is the Method term [STATED: I1, I2]. (b) In the PlayNAC TABLE the right-hand project columns sit under IT, MyWay (Purpose) and HowWay (Method) [STATED: I1]. (c) The ERES nomenclature operators assign '@' to methodology or process inquiry, '#' to core frameworks or protocols, '^' to resolution or elevation to harmony, and '*' to emphasis or core study areas [STATED: I2]; the 2025 HowWay page uses the same convention in '#C=R*P/M @E=MC^2' [STATED: I1].

Reading: 'HowWay = ERES @' says that the method by which the ERES stack is applied is itself an inquiry that can be posed, recorded and answered. The six questions are that inquiry, put to a control rather than to a person [CONSTRUCTED]. Because the inquiry sits in the Method column of a workflow, the mechanism that answers it sits in the path of the action rather than beside it [DERIVED].

## 3. The mechanism: GEAR x DERR + ERES

At the systemic level HowWay is a three-step cycle: GEAR records, DERR diagnoses, ERES remediates, with remediation tracked back into GEAR [STATED: I2]. The formula multiplies before it adds: recording and diagnosis are coupled as one product before remediation can occur, since a state cannot be remediated unless it has been both recorded and diagnosed [STATED: I2].

Assurance reading [CONSTRUCTED]: a control that cannot be evidenced (GEAR) or noticed when it changes (DERR) cannot be remediated at runtime (ERES). The six questions distribute across the three terms, with Q6 carried by the enclosing PlayNAC sequence (Figure 1).

**Scope limit.** In its source paper DERR is defined through Kirlianography and COI semantic interpretation [I2]. This paper uses only DERR's role, diagnosis and semantic mediation across Communities of Interest, and specifies ordinary inputs: logs, control states, metrics. Kirlianography, Schumann-resonance coupling and bio-electric readings are [CONJECTURE] here, are not required by any answer below, and are excluded from all claims (H7). Human biometric or emotion-inference inputs would in addition raise regulatory exposure (H6).

![Figure 1: GEAR x DERR + ERES loop mapped to the six questions](ERES-HOWWAY-2026-001_Figure-1_GEAR-DERR-ERES-Loop.svg)

*Figure 1. Record, diagnose, remediate inside the PlayNAC HowWay sequence.*

## 4. The six questions mapped to ERES mechanisms

| Question | Term | Mechanism | Evidence produced | Status |
|---|---|---|---|---|
| 1. Can you prove the control is actually operating? | GEAR | SOMT append-only hash-chained log; CPROV provenance chain [STATED: I2, I6] | Each governed action is a logged entry; the log is the proof of operation for gated actions | MODELED; tamper-evidence tested; bypass limit H1 |
| 2. Can I see the telemetry? | DERR | BERA health signal computed from the log; drift and independence readouts [STATED: I7] | Telemetry that is a pure function of the log (tested), visible to the affected User-GROUP | MODELED; thresholds ASSERTED (H2) |
| 3. Can I automatically collect the evidence? | GEAR | SOMT entry written by the act of governing; sha256 manifests per artifact | No separate collection step (tested: one entry per run) | MODELED; live pipeline not built (H3) |
| 4. Can the control detect when something changes? | DERR | RHC drift against baseline; Independence Gate (CDFE n_eff) [STATED: I4, I5, I7] | A logged drift event and an independence score | MODELED; k and tau ASSERTED (H2) |
| 5. Can it stop or escalate an action at runtime? | ERES | PoR = A x R x P x F (any zero blocks); RCR live-state authorisation; RAEC tiers; Paineology remediation [STATED: I7] | Block, escalate and remediation entries tied to the triggering action | MODELED; completeness OPEN (H1); red-team OPEN (H5) |
| 6. Can governance happen inside the workflow instead of six weeks later? | PlayNAC | 12-step HowWay sequence; CHALLENGE/RESPONSE columns; ratification gate (mean MIEVM >= 8.5 AND n_eff >= tau) [STATED: I1, I4, I7] | Decision, log, challenge and ratification are steps of the run, not a later queue (tested) | ARCHITECTURAL; latency unmeasured (H4) |

## 5. The in-workflow spine: the PlayNAC HowWay sequence

The 2025 HowWay page lists twelve steps from an SLA being initiated to the SLA being updated [STATED: I1]. Read as an assurance workflow, each step carries a control function [CONSTRUCTED]. The sequence predates this reading; the mapping is made here.

| # | Step in the PlayNAC HowWay sequence [STATED: I1] | Assurance function [CONSTRUCTED] |
|---|---|---|
| 1 | User-GROUP SLA initiated: a number anyone can call for real help | An accountable owner and contact path exist before work starts (Q6) |
| 2 | AnswerQuestion posed by Questioner: EMCI initiation | The claim or action enters the workflow as a recorded question (Q1) |
| 3 | System relevancy defined: SLA query | The scope of the control is declared |
| 4 | P^3 interpretation garnered: Questioner DEF-REL inquiry | Frame and definitions are fixed before scoring (criteria, not canon) |
| 5 | Permission defined: security level (s/S/$) | Authorisation level set; input to RCR (Q5) |
| 6 | User-GROUP notified: detail rendered | Visibility to the affected group (Q2) |
| 7 | User-GROUP assigned: reaction notice generated | Escalation path (Q5) |
| 8 | Questioner QuestionAnswer rendered (SIM-GEN $EL(L)) | The decision and its basis are produced |
| 9 | QuestionAnswer reviewed: actuary data population keys made-read-fed | Review and evidence keys (Q3) |
| 10 | Questioner awarded credit: NAC UBIMIA x SOMT update + GAIA DEF-REL | SOMT updated; provenance closes (Q1, Q3) |
| 11 | GAIA General Ledger (GGL) updated | Ledger of record (Q1) |
| 12 | NAC User-GROUP SLA updated; NBERS pays Questioner(s) UBIMIA | The SLA reflects the outcome. Economic settlement is outside the assurance claim |

## 6. Evidence by construction, and its limit

What an assessor receives is a queryable log and a live signal rather than a sample. Because the log is written by the act of governing, its population is complete by construction for every action that passed through the gate. Hash-chained logs give tamper evidence against edit, deletion and reordering [VALIDATED: E7, E8]; the harness reproduces that property in miniature.

**The limit.** A log cannot show what bypassed it. The harness demonstrates this: with one ungated effect, the log verifies intact and says nothing. **Requirement R-EL [CONSTRUCTED]:** keep an effect ledger that is independent of the gate and reconcile it against the log, so that every effect traces to a logged execute decision. In the harness the ledger is not independent, so the reconciliation test demonstrates the mechanism, not the guarantee (H1, H3). Runtime enforcement has known limits in what it can enforce [VALIDATED: E5, E6].

## 7. The Independence Gate at ratification

A change to the control set ratifies if and only if n_eff >= tau AND the mean MIEVM score >= 8.5 [STATED: I4]. n_eff = (sum of sqrt(l_i))^2 / sum of l_i over the eigenspectrum of the node-correlation matrix [STATED: I4, I5]. It equals n for independent nodes, 1 for fully correlated nodes, and 1 + sqrt(1 - r^2) for two nodes [DERIVED; tested]. tau = 3.0 is asserted (H2). In the harness, five nodes of which four are near-duplicates score a mean of 9.5 yet fall below tau and are refused, which closes the sybil route in the model [E9]. Carried caveat from [I4]: n_eff is computed on verdict correlation, not error correlation.

## 8. Boundary

- Green means SPECIFICATION against a MODELED adversary. It does not mean a runtime, and it is not proof against a live or novel attacker.
- The model exposes no is_safe, is_secure or is_compliant verdict, and no test asserts one. 'Prevents malicious activity' is, at v0.2, a design property with a named modeled adversary, not an operational guarantee.
- No answer depends on Kirlianography, Schumann-resonance coupling or bio-electric readings. Those remain [CONJECTURE] and are excluded (H7).
- The six questions resemble properties sought by continuous-monitoring and record-keeping regimes (E1-E4). Resemblance is not conformity: no clause-level mapping to any regime has been reviewed, and no compliance or certification outcome is claimed.
- The PlayNAC sequence mapping (section 5) is constructed here. It is not a claim about the original intent of the 2018 page.
- The Divine HowWay string in [I3] is a separate delivery specification for the vote. It is cited for its carrier role and its boundary discipline, not for the operator reading in section 2.

## 9. Test instrument results

The instrument **eres_howway_test_instrument.py** (Python standard library only) runs 38 tests from a fresh extract with MANIFEST.json present: 31 pass and 7 are skipped by design, one for each open item H1-H7. Coverage by question: Q1 four tests (edit, deletion and reorder detection), Q2 two, Q3 two, Q4 eight (drift, n_eff identities, sybil refusal), Q5 eight (zero-factor block, stale authorisation, escalation, remediation), Q6 three, three documented-limit tests (bypass invisible to the log; reconciliation detects it; 1-sigma false-alarm rate about 32 percent), and one package-integrity check. Exit code 0.

## 10. OPEN items

- **H1.** PoR completeness. No proof that PoR, RCR and RAEC block all malicious actions (ARH O1). A gate that can be bypassed leaves a silent log. Direction, not a claim: an effect ledger independent of the gate, reconciled against the log (R-EL, section 6).
- **H2.** Asserted parameters. The RHC threshold (k = 1 sigma), tau = 3.0 and any BERA alert level are asserted, not derived. At k = 1 the expected false-alarm rate on stationary Gaussian noise is about 32 percent (tested), so it is a return target, not an alarm threshold as it stands.
- **H3.** Log integrity in deployment. SOMT tamper-evidence and external anchoring are specified and modeled, not realised outside the harness.
- **H4.** Inline cost. Latency and throughput overhead of gating every action is unmeasured, so 'inside the workflow' is not yet shown viable at load.
- **H5.** External red-team of a running system (ARH O5). Not simulable; the one gate Claude cannot stand in for.
- **H6.** Regulatory fit. Telemetry design must clear the collisions raised for RRH (EU AI Act, GDPR, eIDAS). The 'not surveillance' framing of BERA is a claim to be tested there, not assumed.
- **H7.** Bio-electric inputs. Kirlianography, Schumann-resonance coupling and bio-electric readings are [CONJECTURE] in this paper. No answer above needs them. They are excluded from every claim and should stay out of any assurance-bearing path until independently validated.

## 11. Suggested next step

- Two-round Delphi MIEVM on v0.2 as an adversarial-completeness probe of the mapping (did the six questions miss an assurance property), run blind-first with the Independence Gate applied to the round itself. MIEVM is not the promoting gate for H1-H7.
- Close H2 and H4 with a measured prototype; build R-EL; hold H5 as the empirical gate.

## Credits

- **Author of record.** Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221. Sole author.
- **Corpus lineage acknowledged.** The ERES PlayNAC HowWay page (published 2018, revised 2018 and 2025) [I1]; What / With / Why and HowWay (March 2026) [I2]; ERES-VOTING-2026-001 v0.2 Addendum 13 [I3]; ERES-ARH-2026-001 v0.1 [I4]; ERES-CDFE-2026-001 v1.1 [I5]; ERES-CPROV-2026-001 [I6]; the PlayNAC governance stack [I7]; and HowWay v0.1 [I8]. CDFE carries its own credits; this paper uses it only as a general effective-independence scorer over a node-correlation matrix, and invokes no application of it.
- **Drafting and validation node.** Claude (Anthropic), working under the H2C2H method. Claude is a drafting and validation node, not an author. No MIEVM rating has been applied to this version.
- **External literature.** Authors of works E1-E9 are credited through the References; none has reviewed or endorsed this paper.
- **Prompting context.** Item H6 exists because of a public regulatory critique of the ERES corpus (September 2026); see [I9]. The critic is not named here.
- **No endorsement.** No third party has reviewed, approved or endorsed this paper. Individuals and organisations named elsewhere in the ERES corpus are not endorsers of it.

## References

**Internal (ERES)**

- [I1] Sprute, J. A. ERES PlayNAC "HowWay": Organizer for User/GROUP Pedagogy and Emergency Management Critical Infrastructure (EMCI) Game Theory. Published 2018-07-25; revised 2018-07-26 and 2025-07-06. ERES Institute. Open Source Common Core.
- [I2] Sprute, J. A. (2026, March). What / With / Why and HowWay: AnswerQuestion.IT.MyWay, GEAR x DERR + ERES (with Schumann Resonance detail). ERES Institute. CCAL v2.1.
- [I3] Sprute, J. A. (2026, July 17). ERES-VOTING-2026-001 v0.2, Addendum 13: Divine HowWay (the Delivery Cross-Walk). ERES Institute. CCAL v2.1 / CC-BY 4.0.
- [I4] Sprute, J. A. (2026, September). ERES-ARH-2026-001 v0.1: Adversarial Root Hardening. ERES Institute.
- [I5] ERES-CDFE-2026-001 v1.1: Covariance-Discounted Floor Engine. ERES Institute. (See that instrument for its own credits.)
- [I6] ERES-CPROV-2026-001: Constitutional Provenance. ERES Institute.
- [I7] ERES-PLAYNAC-GOVERNANCE-2026-001: PlayNAC resonance-governance stack (BERA, RHC, SOMT, MIEVM, PoR, CBGMODD, RCR, RAEC). ERES Institute.
- [I8] Sprute, J. A. (2026, September 28). ERES-HOWWAY-2026-001 v0.1: HowWay = ERES @, Runtime Assurance for AI Governance. Superseded by this version.
- [I9] ERES-RRH-2026-001: Regulatory Root Hardening (EU AI Act, GDPR, eIDAS). Drafting approved 2026-09-24; not part of this package.
- [I10] ERES-LEGAL-2026-001: Doctrine of Verifiable Claims (tag discipline: DERIVED, CONSTRUCTED, CONJECTURE, VALIDATED, STATED). ERES Institute.
- [I11] CARE Commons Attribution License v2.1 (CCAL v2.1). ERES Institute for New Age Cybernetics. Effective 2026-04-26.

**External**

- [E1] European Union. Regulation (EU) 2024/1689 (Artificial Intelligence Act), in particular Articles 12 (record-keeping), 14 (human oversight) and 72 (post-market monitoring). Official Journal of the European Union, 12 July 2024.
- [E2] National Institute of Standards and Technology. Artificial Intelligence Risk Management Framework (AI RMF 1.0). NIST AI 100-1, January 2023.
- [E3] National Institute of Standards and Technology. Information Security Continuous Monitoring (ISCM) for Federal Information Systems and Organizations. NIST SP 800-137, September 2011.
- [E4] ISO/IEC 42001:2023. Information technology - Artificial intelligence - Management system.
- [E5] Schneider, F. B. (2000). Enforceable security policies. ACM Transactions on Information and System Security, 3(1), 30-50.
- [E6] Leucker, M., and Schallhart, C. (2009). A brief account of runtime verification. Journal of Logic and Algebraic Programming, 78(5), 293-303.
- [E7] Crosby, S. A., and Wallach, D. S. (2009). Efficient data structures for tamper-evident logging. Proceedings of the 18th USENIX Security Symposium, 317-334.
- [E8] Laurie, B., Langley, A., and Kasper, E. (2013). Certificate Transparency. RFC 6962, IETF.
- [E9] Douceur, J. R. (2002). The Sybil attack. Peer-to-Peer Systems (IPTPS 2002), Lecture Notes in Computer Science 2429, 251-260.

*External references (E1-E9) were supplied from the drafting node's training knowledge and were not re-checked against the sources during this session. Verify volume, page and clause details before deposit.*

## License

Released under CCAL v2.1 / CC-BY 4.0. Full CCAL v2.1 text: LICENSE.md in this package. Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1. ORCID 0000-0001-9946-3221. Steward contact: eresmaestro@gmail.com. Don't hurt yourself. Don't hurt others. Build for generations to come.
