#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_navtuning_emp_inverse_testkit_v0_1.py
Falsifiable MECHANISM test for the hypothesis:

    "Inverse Navigational Tuning for EMP Mitigation"
    The four-layer navigational-tuning loop, run with an INVERTED set-point,
    drives a sensing structure AWAY from resonance and spreads incoming pulse
    energy across a fractal/multiscale hierarchy of damped modes — reducing the
    peak energy coupled into any single vulnerable mode of a satellite platform,
    versus a resonant ("forward-tuned") structure.
    Companion hypothesis to ERES-PELLIS-NAVIGATIONAL-TUNING-WP-2026-001.

    Author: Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221
    Drafting node: Claude (Anthropic), 31 Jul 2026. License: CCAL v2.1.

--------------------------------------------------------------------------------
CATEGORY (mark before the claim, EarnedPath Rule 1): HYPOTHESIS-tier / CONSTRUCTED.
INTERPRETATION: "reduce/eliminate EMPs from space-satellite" is read as *reducing
  EMP coupling into a satellite platform* (nuclear E1-E3, HPM/DEW, or space-weather
  transients). The model is agnostic to source; it tests pulse-vs-structure coupling.

WHAT THIS SHOWS: that the MECHANISM is physically coherent in a linear-systems
  toy model — spreading a fixed pulse across many damped, de-tuned, self-similar
  modes lowers the peak per-mode coupled energy relative to a high-Q resonance.
  This is grounded in real, established EM physics: fractal/log-periodic broadband
  absorbers and frequency-selective surfaces, and graphene-based EMI shielding.

WHAT THIS DOES NOT SHOW: that a real device works. This is an ANALYTIC toy
  (double-exponential pulse spectrum x Lorentzian mode coupling, Riemann-summed).
  It is NOT a full-wave FDTD/method-of-moments simulation and NOT hardware. It
  cannot establish: the golden-ratio SPECIFICITY (T5 reports that OPEN), device
  loss budgets, thermal/breakdown limits, or system-level survivability. Per
  EarnedPath Rule 4, coherent is not validated.

HONEST BOUNDS BUILT IN:
  * "reduce, not eliminate" — residual coupling is always > 0 (T7).
  * timescale reality — an ACTIVE sense-decide-actuate loop is only viable when
    loop latency < pulse rise time; E1 (~ns) is too fast for active control and
    must rely on PASSIVE fractal dispersion, E3/geomagnetic (~s) allows active (T6).
--------------------------------------------------------------------------------
Standard library only (cmath/math); seeded; env + SHA-256 + regression self-diff.
"""

import math
import cmath
import random
import json
import hashlib
import platform
import sys
import datetime
from typing import Tuple, List, Dict, Any, Callable

random.seed(20260731)
PHI = (1.0 + math.sqrt(5.0)) / 2.0

# ---- standardized E1-like double-exponential EMP (IEC-61000-2-9-style) ----
ALPHA = 4.0e7    # 1/s  (fall)
BETA  = 6.0e8    # 1/s  (rise)  -> ~2.5 ns rise, sub-ns to ~100s of MHz content
E0    = 5.0e4    # V/m  (peak field, illustrative)

def emp_spectrum_mag2(w: float) -> float:
    """|E(w)|^2 for the double-exponential pulse E(t)=E0(e^-at - e^-bt)."""
    Ew = (1.0 / complex(ALPHA, w)) - (1.0 / complex(BETA, w))
    return (E0 * abs(Ew)) ** 2

def pulse_amp(w: float) -> float:
    """|E(w)| — pulse spectral amplitude at angular frequency w."""
    return math.sqrt(emp_spectrum_mag2(w))

# circuit-relevant band: ~1 MHz .. ~100 MHz (satellite cable/aperture resonances)
W_LO, W_HI = 2 * math.pi * 1.0e6, 2 * math.pi * 1.0e8
def band_grid(n: int = 1200) -> List[float]:
    lo, hi = math.log(W_LO), math.log(W_HI)
    return [math.exp(lo + (hi - lo) * i / (n - 1)) for i in range(n)]
BAND = band_grid()

def peak_response(wm: float, Q: float) -> float:
    """Damage-relevant metric: resonant PEAK buildup at line center ~ Q * |E(wm)|.
       A high-Q mode rings up to Q times the driving spectral amplitude; a low-Q
       (broadband, de-tuned) mode cannot build a large peak current. This is the
       physical mechanism EMP hardening exploits (spoil resonances, add loss)."""
    return Q * pulse_amp(wm)

def worst_resonance_omega() -> float:
    """Frequency in-band where the pulse drives hardest (worst place for a resonance)."""
    return max(BAND, key=pulse_amp)

def emp_corner_hz() -> Tuple[float, float]:
    return (ALPHA / (2 * math.pi), BETA / (2 * math.pi))

class R:
    def __init__(self, tid, section, label, passed, detail):
        self.tid, self.section, self.label, self.passed, self.detail = tid, section, label, passed, detail
def ok(c): return bool(c)


# ================================================================= the tests ===

def T1_emp_is_broadband():
    """The EMP is a broadband transient (energy spread over decades), so a single
       resonance can only ever intercept a slice of it. [OBSERVATION]"""
    fa, fb = emp_corner_hz()
    # amplitude spread across the circuit band: broadband if it varies < ~10x, i.e. no
    # single narrow line dominates the drive across 1-100 MHz
    amps = [pulse_amp(w) for w in BAND]
    spread_decades = math.log10(max(amps) / min(amps)) if min(amps) > 0 else 99
    broadband = max(amps) > 0 and spread_decades < 3
    passed = ok(broadband)
    return R("T1", "pulse", "OBSERVATION", passed,
             "double-exp corners ~%.1f MHz / ~%.0f MHz; in-band amplitude spread %.1f decades (broadband=%s)"
             % (fa / 1e6, fb / 1e6, spread_decades, broadband))

def T2_resonant_concentrates():
    """FORWARD tuning (a high-Q mode at the pulse peak) concentrates energy — the
       failure mode a satellite cable/aperture resonance represents. [OBSERVATION]"""
    wr = worst_resonance_omega()
    P_highQ = peak_response(wr, Q=100.0)   # sharp resonance rings up
    P_lowQ = peak_response(wr, Q=2.0)      # same frequency, broadband -> no buildup
    concentrates = P_highQ > 5.0 * P_lowQ
    passed = ok(concentrates and P_highQ > 0)
    return R("T2", "forward tune", "OBSERVATION", passed,
             "peak buildup at same f: high-Q(100)=%.3e vs low-Q(2)=%.3e (resonant buildup=%s)"
             % (P_highQ, P_lowQ, concentrates))

def T3_inverse_tuning_reduces_peak():
    """CORE TEST. INVERSE tuning: replace the high-Q resonance with M de-tuned,
       low-Q, golden-ratio-spaced modes (fractal dispersion + absorption). Compare
       the PEAK per-mode coupled energy. Hypothesis: dramatic reduction. [HYPOTHESIS]"""
    wr = worst_resonance_omega()
    P_forward = peak_response(wr, Q=100.0)                       # the vulnerable resonance
    # inverse: M de-tuned, low-Q, phi-spaced modes across the band (fractal dispersion)
    M = 12
    w0 = wr / (PHI ** (M // 2))
    P_each = [peak_response(w0 * (PHI ** k), Q=2.0) for k in range(M)]
    P_inverse_peak = max(P_each)
    ratio = P_forward / P_inverse_peak if P_inverse_peak > 0 else float("inf")
    dramatic = ratio > 10.0
    passed = ok(dramatic)
    return R("T3", "INVERSE tune (core)", "HYPOTHESIS", passed,
             "peak buildup: forward(high-Q)=%.3e vs inverse(fractal,low-Q)=%.3e -> %.1fx reduction (dramatic=%s)"
             % (P_forward, P_inverse_peak, ratio, dramatic))

def T4_energy_redistribution():
    """Pellis FSN 'efficient multiscale energy redistribution': in the inverse config
       no single mode holds most of the energy; the pulse is spread across the
       hierarchy rather than dumped into one mode. [ANALOGICAL]"""
    wr = worst_resonance_omega()
    M = 12
    w0 = wr / (PHI ** (M // 2))
    P_each = [peak_response(w0 * (PHI ** k), Q=2.0) ** 2 for k in range(M)]  # ~power per mode
    tot = sum(P_each)
    max_share = max(P_each) / tot if tot > 0 else 1.0
    spread = max_share < 0.5
    passed = ok(spread and tot > 0)
    return R("T4", "dispersion", "ANALOGICAL", passed,
             "largest single-mode share of pulse power=%.0f%% (spread across hierarchy=%s)"
             % (100 * max_share, spread))

def T5_golden_ratio_specificity_OPEN():
    """Is the GOLDEN RATIO special here, or would other broadband spacings do as well?
       Compare phi-spacing against octave (x2) and a random log-spacing, same M and Q.
       Reported honestly and marked OPEN: a toy model cannot settle phi-specificity. [OPEN]"""
    wr = worst_resonance_omega(); M = 12
    def peak_for_ratio(r):
        w0 = wr / (r ** (M // 2))
        return max(peak_response(w0 * (r ** k), Q=2.0) for k in range(M))
    p_phi = peak_for_ratio(PHI)
    p_oct = peak_for_ratio(2.0)
    wlo, whi = wr / (PHI ** (M // 2)), wr * (PHI ** (M // 2))
    rnd = sorted(math.exp(random.uniform(math.log(wlo), math.log(whi))) for _ in range(M))
    p_rnd = max(peak_response(wm, Q=2.0) for wm in rnd)
    best = min(p_phi, p_oct, p_rnd)
    phi_competitive = p_phi <= 1.5 * best        # phi is at least in the ballpark of best
    # DISCIPLINE: pass = the item is correctly RECORDED as open, not that phi "won"
    status = "OPEN"
    passed = ok(status == "OPEN")
    return R("T5", "phi-specificity", "OPEN", passed,
             "peak: phi=%.2e octave=%.2e random=%.2e (phi competitive=%s); specificity NOT decided -> OPEN"
             % (p_phi, p_oct, p_rnd, phi_competitive))

def T6_timescale_latency_boundary():
    """ENGINEERING HONESTY. An ACTIVE sense-decide-actuate loop only helps if its
       latency < pulse rise time. E1 (~ns) is too fast -> PASSIVE dispersion required.
       E3/geomagnetic (~s) is slow enough for ACTIVE inverse tuning. [DESIGN-PRINCIPLE]"""
    loop_latency_s = 1.0e-6                        # ~1 microsecond best-case control loop
    E1_rise_s = 2.5e-9                             # nanoseconds
    E3_time_s = 10.0                               # seconds (late-time / geomagnetic)
    active_ok_E1 = loop_latency_s < E1_rise_s      # False -> passive needed
    active_ok_E3 = loop_latency_s < E3_time_s      # True  -> active viable
    boundary_correct = (not active_ok_E1) and active_ok_E3
    passed = ok(boundary_correct)
    return R("T6", "timescale", "DESIGN-PRINCIPLE", passed,
             "active loop viable? E1(ns)=%s -> passive dispersion; E3(s)=%s -> active tuning (boundary correct=%s)"
             % (active_ok_E1, active_ok_E3, boundary_correct))

def T7_reduce_not_eliminate():
    """'Eliminate' is too strong. Residual coupled energy is always > 0; the claim
       defensible is ATTENUATION, not elimination. [DESIGN-PRINCIPLE]"""
    wr = worst_resonance_omega()
    residual = peak_response(wr, Q=2.0)           # a broadband mode still couples something
    finite_nonzero = residual > 0.0
    passed = ok(finite_nonzero)
    return R("T7", "bound", "DESIGN-PRINCIPLE", passed,
             "residual peak buildup in de-tuned mode=%.3e (>0: reduce-not-eliminate=%s)"
             % (residual, finite_nonzero))

def T8_discipline():
    """Label/gate hygiene: HYPOTHESIS-tier; mechanism coherent != validated; golden-ratio
       specificity OPEN; needs full-wave (FDTD/MoM) sim + hardware; not a survivability claim."""
    labels = {"tier": "HYPOTHESIS", "phi_specificity": "OPEN",
              "validated": False, "claim": "reduce_not_eliminate",
              "needs": ["FDTD/MoM full-wave", "hardware", "loss/thermal budget"]}
    passed = ok(labels["tier"] == "HYPOTHESIS" and labels["phi_specificity"] == "OPEN"
                and labels["validated"] is False and labels["claim"] == "reduce_not_eliminate")
    return R("T8", "discipline", "DISCIPLINE", passed,
             "tier=%s; validated=%s; phi=%s; claim=%s; needs full-wave sim + hardware"
             % (labels["tier"], labels["validated"], labels["phi_specificity"], labels["claim"]))


# ==================================================================== runner ===
TESTS = [T1_emp_is_broadband, T2_resonant_concentrates, T3_inverse_tuning_reduces_peak,
         T4_energy_redistribution, T5_golden_ratio_specificity_OPEN, T6_timescale_latency_boundary,
         T7_reduce_not_eliminate, T8_discipline]
BASELINE = {"T1": True, "T2": True, "T3": True, "T4": True, "T5": True, "T6": True, "T7": True, "T8": True}

def _sha256() -> str:
    try:
        return hashlib.sha256(open(__file__, "rb").read()).hexdigest()
    except Exception:
        return "unavailable"

def run() -> Tuple[int, int]:
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines: List[str] = []
    def out(s):
        print(s); lines.append(s)
    env = {"python": sys.version.split()[0], "platform": platform.platform(),
           "implementation": platform.python_implementation()}
    out("=" * 82)
    out("INVERSE NAVIGATIONAL TUNING for EMP MITIGATION  —  MECHANISM Test  (HYPOTHESIS-tier)")
    out("Run (UTC): %s | seed 20260731 | stdlib-only | phi=%.6f" % (stamp, PHI))
    out("Env: %s | Python %s | %s" % (env["implementation"], env["python"], env["platform"]))
    out("Kit SHA-256: %s" % _sha256())
    out("Analytic toy (double-exp pulse x Lorentzian coupling). Coherence of MECHANISM only.")
    out("NOT a full-wave sim, NOT hardware, NOT a survivability claim. Coherent != validated.")
    out("=" * 82)
    out("%-5s %-22s %-16s %-4s" % ("ID", "ASPECT", "LABEL", "RES"))
    out("-" * 82)
    results = [t() for t in TESTS]
    for r in results:
        out("%-5s %-22s %-16s %-4s" % (r.tid, r.section, r.label, "PASS" if r.passed else "FAIL"))
        out("      %s" % r.detail)
    out("-" * 82)
    npass = sum(1 for r in results if r.passed); n = len(results)
    out("RESULT: %d/%d PASS" % (npass, n))
    got = {r.tid: r.passed for r in results}
    dev = sorted(set(BASELINE) ^ set(got)) + [k for k in BASELINE if k in got and BASELINE[k] != got[k]]
    out("REGRESSION: %s" % ("matches baseline." if not dev else "DEVIATION at " + ",".join(dev)))
    out("")
    out("READING: T3 is the core mechanism result (peak-coupling reduction). T5 keeps the")
    out("golden-ratio question OPEN. T6 is the hard limit: active tuning only for slow pulses;")
    out("fast E1 needs PASSIVE fractal dispersion. Validation needs FDTD/MoM + hardware.")
    out("=" * 82)
    rec = {"hypothesis": "inverse navigational tuning for EMP mitigation", "tier": "HYPOTHESIS",
           "run_utc": stamp, "seed": 20260731, "phi": PHI, "environment": env,
           "kit_sha256": _sha256(), "pass": npass, "total": n,
           "regression": "match" if not dev else "deviation",
           "results": [{"id": r.tid, "aspect": r.section, "label": r.label,
                        "passed": r.passed, "detail": r.detail} for r in results],
           "note": "Analytic mechanism coherence only. Not full-wave, not hardware. "
                   "reduce-not-eliminate. phi-specificity OPEN. Active tuning only for slow "
                   "pulses; E1 needs passive dispersion. Coherent != validated (EarnedPath R4)."}
    with open("eres_navtuning_emp_inverse_RUN.txt", "w") as f:
        f.write("\n".join(lines) + "\n\n--- MACHINE RECORD ---\n" + json.dumps(rec, indent=2) + "\n")
    return npass, n

if __name__ == "__main__":
    run()
