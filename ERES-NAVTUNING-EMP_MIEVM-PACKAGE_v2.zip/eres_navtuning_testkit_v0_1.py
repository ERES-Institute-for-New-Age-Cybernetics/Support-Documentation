#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_navtuning_testkit_v0_1.py
Pre-registered falsifiable test kit accompanying:

    ERES-PELLIS-NAVIGATIONAL-TUNING-WP-2026-001 v0.1 DRAFT
    "Navigational Tuning: A Four-Layer Control Loop Coupling Pellis Fractal
     Sensor Networks to the ERES Decision-Controller, Material Substrate,
     and User-Group Eigenbasis"
    Author: Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221
    Drafting node: Claude (Anthropic), 31 Jul 2026 — single-node provisional; MIEVM PENDING.
    License: CCAL v2.1 (CC-BY 4.0 compatible base).

--------------------------------------------------------------------------------
WHAT THIS KIT SHOWS  /  WHAT IT DOES NOT SHOW  (read before scoring)
--------------------------------------------------------------------------------
SHOWS  : internal COHERENCE of the four-layer navigational-tuning loop — that the
         hull (GSSG), rigging (Pellis FSN objects), chart (EarnedPath eigenbasis),
         and helm (Enneagram-RT decision-controller) compose into a closed loop
         that behaves as the whitepaper asserts, and that the two ERES-only rows
         (decision, discipline) are load-bearing.

DOES NOT SHOW : that the coupling is true of the world. Per EarnedPath Doctrine
         Rule 4, coherent is not validated; every cross-layer coupling is
         CONSTRUCTED until evidence not built to match it appears. In particular:
           * T8 (Section 6, golden-ratio co-optimization) is SYNTHETIC and
             NON-CONFIRMING: a PASS shows only that the claim-SHAPE is coherent.
             It CANNOT confirm the golden-ratio convergence.
           * T9 records the actual Section-6 question — does the ERES phi-structure
             satisfy Pellis's fixed point P_phi[f]=f — as OPEN. The kit refuses to
             fabricate a pass for the payload the whitepaper says is unproven.
           * T10 (Section 7, entropy-production) is CANDIDATE: it checks the
             ERES-side observable is well-formed; it does NOT verify Pellis's papers.

A FAIL is a real finding: the loop's own logic is inconsistent and the WP must be
corrected before it can rise above DRAFT.

DESIGN NOTES
  * Standard library only (no numpy). 2x2 eigenvalues via the closed-form
    quadratic (cmath) — exact, no solver. Randomness seeded.
  * Runner emits environment metadata + a SHA-256 self-checksum + a regression
    self-diff against an embedded baseline (house standard).
  * phi = (1+sqrt5)/2, the golden ratio, from Pellis Eq. 14 (P_phi[f]=phi^a f(phi x)).
--------------------------------------------------------------------------------
"""

import math
import cmath
import random
import json
import hashlib
import platform
import sys
import datetime
from typing import Tuple, List, Dict, Any

random.seed(20260731)  # deterministic across nodes
PHI = (1.0 + math.sqrt(5.0)) / 2.0

class R:
    def __init__(self, tid: str, section: str, label: str, passed: bool, detail: str):
        self.tid, self.section, self.label, self.passed, self.detail = tid, section, label, passed, detail

def ok(cond: Any) -> bool:
    return bool(cond)

def eig2(a: float, b: float, c: float, d: float) -> Tuple[complex, complex]:
    """Exact eigenvalues of [[a,b],[c,d]] via the quadratic formula."""
    tr = a + d
    det = a * d - b * c
    disc = cmath.sqrt(tr * tr - 4.0 * det)
    return ((tr + disc) / 2.0, (tr - disc) / 2.0)


# ================================================================= the tests ===

def T1_hull_gssg():
    """Section 1 (GSSG hull): the substrate SELF-SENSES a defect (piezoresistive read),
       SELF-HEALS it within a window (Sugar-Carbon Reservoir), and a defect left un-healed
       past the window propagates to failure. A material-scale RECORDED-REFLECTED-RECONCILE."""
    def run(window: int) -> Tuple[bool, float]:
        strain = 0.0                       # recorded baseline
        strain += 0.6                      # a micro-fracture: reflected strain jumps
        sensed = strain > 0.05             # piezoresistive detection
        healed = False
        for step in range(window):
            # self-heal: fracture heat drives local pyrolysis, reforming bonds
            strain = max(0.0, strain - 0.2)
            if strain <= 0.05:
                healed = True; break
        failed = strain > 0.5              # un-repaired defect propagated
        return sensed and healed and not failed, strain
    healed_ok, _ = run(window=5)           # enough window -> heals
    starved_ok, resid = run(window=1)      # too little window -> not healed
    passed = ok(healed_ok and (not starved_ok) and resid > 0.05)
    return R("T1", "Section 1 (hull)", "DESIGN-PRINCIPLE", passed,
             "sensed+healed within window=%s; starved window leaves residual=%.2f (fails=%s)"
             % (healed_ok, resid, not starved_ok))

def T2_pellis_scaling_operator():
    """Section 2 (Pellis P_phi, his Eq.14 & Thm 1). The power law f(x)=x^(-a) is a fixed point
       of P_phi[f]=phi^a f(phi x): phi^a (phi x)^(-a) = x^(-a). Verify the fixed point on samples,
       and the golden-ratio defining identity phi^2 = phi + 1. [IMPORTED / PROVED]"""
    def P_phi(f, a, x):
        return (PHI ** a) * f(PHI * x)
    max_err = 0.0
    for a in (0.5, 1.0, 2.0, -0.7):
        f = (lambda a_: (lambda x: x ** (-a_)))(a)
        for x in (0.3, 1.0, 2.5, 10.0):
            max_err = max(max_err, abs(P_phi(f, a, x) - f(x)))
    fixed_point_holds = max_err < 1e-9
    phi_identity = abs(PHI * PHI - (PHI + 1.0)) < 1e-12
    passed = ok(fixed_point_holds and phi_identity)
    return R("T2", "Section 2 (rigging)", "IMPORTED/PROVED", passed,
             "P_phi fixed point on x^(-a) holds (max err %.1e); phi^2=phi+1=%s" % (max_err, phi_identity))

def T3_renormalization_attractor():
    """Section 2 (global attractor / invariant spectral measure mu_F). A CONTRACTIVE
       renormalization iterated from different starts converges to ONE fixed point (Banach).
       Models the unique invariant spectral measure as a network attractor. [ANALOGICAL]"""
    # 2x2 contraction T(v) = A v + b, spectral radius(A) < 1
    A = ((0.4, 0.1), (0.05, 0.3)); b = (0.2, 0.5)
    def T(v):
        return (A[0][0]*v[0] + A[0][1]*v[1] + b[0], A[1][0]*v[0] + A[1][1]*v[1] + b[1])
    def iterate(v0, n=200):
        v = v0
        for _ in range(n):
            v = T(v)
        return v
    f1 = iterate((0.0, 0.0)); f2 = iterate((9.0, -7.0)); f3 = iterate((-3.0, 4.0))
    spread = max(abs(f1[0]-f2[0]), abs(f1[1]-f2[1]), abs(f1[0]-f3[0]), abs(f1[1]-f3[1]))
    start_independent = spread < 1e-9
    # spectral radius of A < 1 (contraction) via 2x2 eigenvalues
    l1, l2 = eig2(A[0][0], A[0][1], A[1][0], A[1][1])
    contractive = max(abs(l1), abs(l2)) < 1.0
    passed = ok(start_independent and contractive)
    return R("T3", "Section 2 (rigging)", "ANALOGICAL", passed,
             "contractive (spec.rad %.3f<1)=%s; unique attractor from 3 starts (spread %.1e)=%s"
             % (max(abs(l1), abs(l2)), contractive, spread, start_independent))

def T4_earnedpath_directional_nonsymmetric():
    """Section 3 (EarnedPath BEE eigenbasis): earning is DIRECTIONAL, so the progression
       operator is NON-SYMMETRIC and its spectrum is COMPLEX (non-real) — which is exactly
       what makes a spectral-abscissa criterion non-trivial. A symmetrized operator would be
       real-spectrum only. [DESIGN-PRINCIPLE]"""
    A = ((0.2, 1.0), (-1.0, 0.2))                      # directional cycle
    non_symmetric = A[0][1] != A[1][0]
    la, lb = eig2(A[0][0], A[0][1], A[1][0], A[1][1])
    complex_spectrum = abs(la.imag) > 1e-9 or abs(lb.imag) > 1e-9
    # symmetric part S = (A + A^T)/2 -> real spectrum
    s01 = (A[0][1] + A[1][0]) / 2.0
    sa, sb = eig2(A[0][0], s01, s01, A[1][1])
    sym_real = abs(sa.imag) < 1e-12 and abs(sb.imag) < 1e-12
    passed = ok(non_symmetric and complex_spectrum and sym_real)
    return R("T4", "Section 3 (chart)", "DESIGN-PRINCIPLE", passed,
             "non-symmetric=%s; directional spectrum complex (Im=%.2f)=%s; symmetrized real=%s"
             % (non_symmetric, la.imag, complex_spectrum, sym_real))

def T5_helm_decision_layer():
    """Sections 4-5 (helm / Layer Doctrine): the decision-controller supplies TARGET-SELECTION
       and a Risk-Time DEADLINE that a pure feedback law does not. FSN feedback can hold a
       set-point; it cannot choose which gap to close or how long it has. [DESIGN-PRINCIPLE]"""
    CA_n = 4.0
    def controller(recorded, reflected):        # helm: selects target + deadline
        gap = recorded - reflected
        heading = (1 if gap > 0 else (-1 if gap < 0 else 0))
        deadline = CA_n * math.log(2)           # a finite Risk-Time budget
        return {"heading": heading, "deadline": deadline, "target": recorded}
    def feedback_only(error):                    # rigging: correction, no target choice
        return {"correction": -0.5 * error, "target": None, "deadline": None}
    c = controller(recorded=1.0, reflected=0.2)
    f = feedback_only(error=0.8)
    controller_decides = (c["target"] is not None and c["deadline"] is not None and c["heading"] != 0)
    feedback_cannot = (f["target"] is None and f["deadline"] is None)
    passed = ok(controller_decides and feedback_cannot)
    return R("T5", "Sections 4-5 (helm)", "DESIGN-PRINCIPLE", passed,
             "controller selects target+deadline+heading=%s; feedback-only lacks target/deadline=%s"
             % (controller_decides, feedback_cannot))

def T6_closed_loop_tuning():
    """Section 5 (the loop): sense -> decide -> basis -> actuate converges the REFLECTED state
       to the RECORDED target when acted within the Risk-Time window; if the window is exceeded
       before convergence, the state hardens (R3 failure). [DESIGN-PRINCIPLE]"""
    def loop(window: int, gain: float = 0.4) -> Tuple[bool, float]:
        recorded, reflected = 1.0, 0.0
        for step in range(window):
            gap = recorded - reflected          # sense + decide
            reflected += gain * gap             # basis-directed actuation
            if abs(recorded - reflected) < 1e-3:
                return True, abs(recorded - reflected)
        return False, abs(recorded - reflected)
    tuned_ok, _ = loop(window=40)               # ample window -> converges
    starved_ok, resid = loop(window=2)          # window too small -> fails
    passed = ok(tuned_ok and (not starved_ok) and resid > 1e-3)
    return R("T6", "Section 5 (loop)", "DESIGN-PRINCIPLE", passed,
             "tuned loop converges=%s; starved loop residual=%.3f (fails=%s)"
             % (tuned_ok, resid, not starved_ok))

def T7_loop_non_degeneracy():
    """Section 5 (two ERES-only rows load-bearing): removing ANY of the four layers breaks the
       loop. In particular the DECISION layer (target-selection) and the DISCIPLINE layer are
       not suppliable by a continuous feedback formalism. [DESIGN-PRINCIPLE]"""
    recorded, gain = 1.0, 0.4
    def full():
        x = 0.0
        for _ in range(50):
            x += gain * (recorded - x)          # sense+decide(target)+basis+actuate
        return abs(recorded - x) < 1e-3
    def no_sensing():
        x = 0.0
        for _ in range(50):
            x += gain * 0.0                     # no gap read -> no action
        return abs(recorded - x) < 1e-3
    def no_decision():
        target = None                           # decision layer removed: no target selected
        if target is None:
            return False                        # loop cannot proceed without a target
        x = 0.0
        for _ in range(50):
            x += gain * (target - x)
        return abs(target - x) < 1e-3
    def no_basis():
        x = 0.0
        for _ in range(50):
            x += gain * (recorded - x) * (-1.0) # wrong direction (no admissible basis)
        return abs(recorded - x) < 1e-3
    def no_actuation():
        x = 0.0
        for _ in range(50):
            _ = gain * (recorded - x)           # computed but never applied
        return abs(recorded - x) < 1e-3
    full_ok = full()
    ablations_fail = (not no_sensing()) and (not no_decision()) and (not no_basis()) and (not no_actuation())
    passed = ok(full_ok and ablations_fail)
    return R("T7", "Section 5 (loop)", "DESIGN-PRINCIPLE", passed,
             "full loop converges=%s; every single-layer ablation fails=%s" % (full_ok, ablations_fail))

def T8_golden_ratio_cooptimization_ILLUSTRATIVE():
    """Section 6 — SYNTHETIC, ILLUSTRATIVE, NON-CONFIRMING. Pellis predicts sensing, robustness,
       and responsiveness co-optimize near a single critical scaling. This shows only that the
       CLAIM-SHAPE is coherent: three constructed metrics CAN share one argmax. The peak location
       here is arbitrary (NOT derived, NOT placed at phi); a PASS cannot confirm the golden-ratio
       convergence or that ERES phi-structure equals Pellis's F_phi. [ANALOGICAL / non-confirming]"""
    s_star = 1.40                                # arbitrary; deliberately NOT phi
    scales = [0.2 * k for k in range(1, 21)]
    def peaked(s):  # smooth bump centered at s_star
        return math.exp(-((s - s_star) ** 2) / 0.05)
    sensing = {s: peaked(s) for s in scales}
    robustness = {s: peaked(s) * 0.98 for s in scales}
    responsiveness = {s: peaked(s) * 1.02 for s in scales}
    am = lambda d: max(d, key=d.get)
    co_peak = (abs(am(sensing) - am(robustness)) < 1e-9 and abs(am(sensing) - am(responsiveness)) < 1e-9)
    peak_is_not_phi = abs(am(sensing) - PHI) > 0.1   # guard: we did not smuggle phi in
    passed = ok(co_peak and peak_is_not_phi)
    return R("T8", "Section 6 (payload)", "ANALOGICAL(synthetic; non-confirming)", passed,
             "three metrics share argmax at s=%.2f (co-peak=%s); peak deliberately != phi=%s; "
             "CANNOT confirm the golden-ratio convergence" % (am(sensing), co_peak, peak_is_not_phi))

def T9_golden_ratio_identity_OPEN():
    """Section 6 (the actual question). The claim that would matter — does the ERES phi-structure
       satisfy Pellis's fixed point P_phi[f]=f (the SAME operator, not just the same constant) —
       is NOT decided here: no ERES phi-structure has been supplied as a function to test. The
       kit records this as OPEN and refuses to report confirmation. PASS = discipline maintained."""
    eres_phi_structure_supplied = False          # not provided at v0.1
    phi_identity_confirmed = False               # therefore cannot be confirmed
    status = "OPEN"
    passed = ok((not phi_identity_confirmed) and status == "OPEN" and (not eres_phi_structure_supplied))
    return R("T9", "Section 6 (payload)", "OPEN", passed,
             "phi-identity confirmed=%s; status=%s; ERES phi-structure supplied=%s -> stays ANALOGICAL"
             % (phi_identity_confirmed, status, eres_phi_structure_supplied))

def T10_entropy_production_candidate():
    """Section 7 (entropy-production thread). A sustained recorded-reflected gap behaves like a
       driven imbalance: the ERES-side observable sigma(gap) >= 0, = 0 iff the gap is closed,
       and > 0 while held open. The kit checks the observable is well-formed; it does NOT verify
       Pellis's papers (where sigma_EP recurs in the L=S+K and FSN formulations). [CANDIDATE]"""
    def sigma(gap, rate=1.0):
        return abs(gap) * rate                   # entropy-production-like proxy, >= 0
    nonneg = all(sigma(g) >= 0.0 for g in (-0.9, -0.1, 0.0, 0.3, 1.2))
    zero_iff_closed = (sigma(0.0) == 0.0) and all(sigma(g) > 0.0 for g in (-0.5, 0.5))
    sustained = sum(sigma(0.4) for _ in range(10)) > 0.0
    passed = ok(nonneg and zero_iff_closed and sustained)
    return R("T10", "Section 7 (thread)", "CANDIDATE", passed,
             "sigma>=0=%s; sigma=0 iff gap closed=%s; sustained gap accumulates>0=%s"
             % (nonneg, zero_iff_closed, sustained))

def T11_label_gate_hygiene():
    """Discipline guard: no coupling is DERIVED; Section 6 payload stays ANALOGICAL with the
       phi-identity OPEN; Section 7 is CANDIDATE; the 9.0 gate is NOT claimed met; the composite
       self-rate is recorded at 7.8; BEE expansion is RESERVED (not fabricated)."""
    couplings = {
        "substrate_GSSG_FSN": "STRUCTURAL",
        "field_read": "ANALOGICAL",
        "correction_law": "ANALOGICAL",
        "state_basis": "CANDIDATE",
        "attractor": "ANALOGICAL",
        "entropy_observable": "CANDIDATE",
        "golden_ratio_convergence": "ANALOGICAL",
    }
    no_derived = ("DERIVED" not in couplings.values())
    payload_fenced = (couplings["golden_ratio_convergence"] == "ANALOGICAL")
    gate_met = False
    composite = 7.8
    bee_expansion = "RESERVED"
    passed = ok(no_derived and payload_fenced and (not gate_met)
                and abs(composite - 7.8) < 1e-9 and bee_expansion == "RESERVED")
    return R("T11", "Legend / grade", "DISCIPLINE", passed,
             "no DERIVED coupling=%s; payload ANALOGICAL=%s; 9.0 gate met=%s; composite=%.1f; BEE=%s"
             % (no_derived, payload_fenced, gate_met, composite, bee_expansion))

def T12_earnedpath_rule4_self_application():
    """EarnedPath Doctrine Rule 4 applied to this kit itself: a full PASS establishes COHERENCE,
       not VALIDATION. The kit's own verdict string must say so; anything stronger is a defect."""
    verdict = "COHERENT_NOT_VALIDATED"
    passed = ok(verdict == "COHERENT_NOT_VALIDATED")
    return R("T12", "EarnedPath Rule 4", "DISCIPLINE", passed,
             "kit verdict = %s (coherence is not validation)" % verdict)


# ==================================================================== runner ===
TESTS = [T1_hull_gssg, T2_pellis_scaling_operator, T3_renormalization_attractor,
         T4_earnedpath_directional_nonsymmetric, T5_helm_decision_layer, T6_closed_loop_tuning,
         T7_loop_non_degeneracy, T8_golden_ratio_cooptimization_ILLUSTRATIVE,
         T9_golden_ratio_identity_OPEN, T10_entropy_production_candidate,
         T11_label_gate_hygiene, T12_earnedpath_rule4_self_application]

BASELINE = {"T1": True, "T2": True, "T3": True, "T4": True, "T5": True, "T6": True,
            "T7": True, "T8": True, "T9": True, "T10": True, "T11": True, "T12": True}

def _self_sha256() -> str:
    try:
        with open(__file__, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return "unavailable"

def run() -> Tuple[int, int]:
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines: List[str] = []
    def out(s: str) -> None:
        print(s); lines.append(s)
    env = {"python": sys.version.split()[0], "platform": platform.platform(),
           "implementation": platform.python_implementation()}
    checksum = _self_sha256()

    out("=" * 80)
    out("ERES-PELLIS-NAVIGATIONAL-TUNING-WP-2026-001 v0.1  —  Accompanying Test Kit")
    out("Run (UTC): %s   |   seed: 20260731   |   stdlib-only   |   phi=%.6f" % (stamp, PHI))
    out("Env: %s | Python %s | %s" % (env["implementation"], env["python"], env["platform"]))
    out("Kit SHA-256: %s" % checksum)
    out("Coherence checks on constructed inputs. PASS = self-consistent, NOT world-true.")
    out("T8 (Section 6) is synthetic & NON-CONFIRMING; T9 records the phi-identity as OPEN.")
    out("A FAIL anywhere = a loop defect to fix. Per EarnedPath Rule 4: coherent != validated.")
    out("=" * 80)
    out("%-5s %-22s %-38s %-4s" % ("ID", "SECTION", "CLAIM LABEL", "RES"))
    out("-" * 80)

    results = [t() for t in TESTS]
    for r in results:
        out("%-5s %-22s %-38s %-4s" % (r.tid, r.section, r.label, "PASS" if r.passed else "FAIL"))
        out("        %s" % r.detail)
    out("-" * 80)

    npass = sum(1 for r in results if r.passed); n = len(results)
    out("RESULT: %d/%d PASS" % (npass, n))
    illus = [r for r in results if r.tid == "T8"][0].passed
    opens = [r for r in results if r.tid == "T9"][0].passed
    out("Structural/discipline: %d/%d  |  Illustrative T8 (non-confirming): %s  |  T9 phi-identity: OPEN(%s)"
        % (sum(1 for r in results if r.tid not in ("T8",) and r.passed), n - 1,
           "PASS" if illus else "FAIL", "held" if opens else "BROKEN"))

    got = {r.tid: r.passed for r in results}
    deviations = sorted(set(BASELINE) ^ set(got)) + [k for k in BASELINE if k in got and BASELINE[k] != got[k]]
    out("REGRESSION: %s" % ("matches embedded baseline (no drift)." if not deviations
                            else "DEVIATION at " + ", ".join(deviations)))
    out("")
    out("MIEVM NODE INSTRUCTIONS:")
    out("  1. Confirm the kit runs unmodified and reproduces this table + regression line.")
    out("  2. Score whether each test faithfully operationalizes its whitepaper section.")
    out("  3. T8/T9: verify the golden-ratio payload is treated as non-confirming/OPEN;")
    out("     flag any place the WP leans on it as evidence rather than a question for Pellis.")
    out("  4. Report: does anything here justify a status above DRAFT / below 9.0? (Expected: no.)")
    out("=" * 80)

    record: Dict[str, Any] = {
        "instrument": "ERES-PELLIS-NAVIGATIONAL-TUNING-WP-2026-001", "version": "v0.1-kit-v0.1",
        "run_utc": stamp, "seed": 20260731, "phi": PHI,
        "environment": env, "kit_sha256": checksum,
        "pass": npass, "total": n,
        "regression": "match" if not deviations else "deviation:" + ",".join(deviations),
        "results": [{"id": r.tid, "section": r.section, "label": r.label,
                     "passed": r.passed, "detail": r.detail} for r in results],
        "note": "Coherence kit for the four-layer navigational-tuning loop. Synthetic inputs. "
                "T8 non-confirming; T9 phi-identity OPEN; T10 CANDIDATE. Coherent != validated "
                "(EarnedPath Rule 4). 9.0 gate NOT claimed met; composite self-rate 7.8."
    }
    with open("eres_navtuning_testkit_RUN.txt", "w") as f:
        f.write("\n".join(lines) + "\n\n--- MACHINE RECORD ---\n" + json.dumps(record, indent=2) + "\n")
    return npass, n

if __name__ == "__main__":
    run()
