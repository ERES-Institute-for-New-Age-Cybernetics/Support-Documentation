#!/usr/bin/env python3
"""
eres_cprov_test_instrument.py  ·  v0.3  (tracks ERES-CPROV-2026-001 v0.3 PROPOSED)

Executable test instrument for ERES Constitutional Provenance.

CHANGELOG
    v0.2 -> v0.3: tracks WP v0.3 (diagram-polish / repackage pass). No test-logic
        change — the model, the three edge checkers, and the 5 OPEN-item skips are
        identical to v0.2. Version string bumped to keep the package in lockstep.
    v0.1 -> v0.2: tracks WP v0.2. Adds two guards: (i) mechanizing the NECESSARY
        condition on the C->H and closure edges does NOT close OPEN items 3/4 — the
        5 skips must remain; (ii) the loop model must expose no goodness verdict
        (is_good / is_safe / is_correct), encoding §7's abstention from P0. Core
        model unchanged.

WHAT THIS TESTS
    The instrument's claim (§5) is that Constitutional Provenance makes
    enforcement TOPOLOGICAL rather than regulatory, via three conditions on
    every Human -> Computer -> Human (H2C2H) loop:

        5.1  the middle must not coerce      (provenance on the C->H edge)
        5.2  intent must survive the crossing (provenance in transit)
        5.3  no output may escape the loop    (total closure)

    These three conditions are mechanizable. This suite models an H2C2H loop
    and checks a given loop against the three edges, returning WHICH edge fails
    (V7: "named and finite break-points" rather than a diffuse attack surface).
    It then tests the value claims V1-V7 as dependencies on those edges, and
    checks the instrument's own declared structure for internal consistency.

WHAT THIS DOES NOT TEST
    It does NOT test whether Constitutional Provenance is true or valuable in
    the world (the analog of FLIP-PREMISE's P0). A system conforming to the
    three edges is not thereby a good system; provenance guarantees outcomes
    carry their reasons, not that the reasons are good (§7).

OPEN ITEMS
    Five tests are SKIPPED, one per canonization blocker in §9. The suite goes
    fully green only when those OPEN items close. The skips ARE the OPEN items.

stdlib-only. Run:  python3 eres_cprov_test_instrument.py
Worked example:    python3 eres_cprov_test_instrument.py --demo
"""

from __future__ import annotations

import argparse
import sys
import unittest
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

INSTRUMENT_ID = "ERES-CPROV-2026-001"
INSTRUMENT_VERSION = "v0.3 PROPOSED"


# ---------------------------------------------------------------------------
# Model: an H2C2H loop
# ---------------------------------------------------------------------------

class Party(Enum):
    HUMAN = "H"
    COMPUTER = "C"


@dataclass(frozen=True)
class Intent:
    """What a sending human puts into the loop: who, what, and their why."""
    origin: str
    content: str
    rationale: str


@dataclass(frozen=True)
class ProvenanceRecord:
    """
    The record a C->H output must carry.

    §5.1 necessary condition: options/ordering/timing rationale all present
        (why THESE options, in THIS order, NOW).
    §5.2 transit condition: the sending human's Intent is carried intact.
    """
    options_rationale: str
    ordering_rationale: str
    timing_rationale: str
    carried_intent: Optional[Intent]

    def is_complete(self) -> bool:
        return all(
            s and s.strip()
            for s in (self.options_rationale, self.ordering_rationale, self.timing_rationale)
        )


@dataclass
class Output:
    """A C->H output handed to the receiving human."""
    content: str
    provenance: Optional[ProvenanceRecord]
    reenters_as_input: bool       # §5.3: becomes the next H->C?
    fires_external_action: bool   # acts on the world directly?


@dataclass
class H2C2HLoop:
    sending_intent: Intent
    outputs: List[Output] = field(default_factory=list)
    scale_band: str = "S1"  # S1 person ... S5 planet; verdict must be band-invariant


# ---------------------------------------------------------------------------
# Edge checkers (§5.1 - §5.3)
# ---------------------------------------------------------------------------

@dataclass
class EdgeResult:
    edge: str
    name: str
    passed: bool
    detail: str


def check_no_coercion(loop: H2C2HLoop) -> EdgeResult:
    """
    §5.1 (necessary condition): every C->H output carries a COMPLETE provenance
    record. This is necessary, not sufficient: it cannot distinguish legitimate
    framing from coercive framing (that is OPEN item 3). Presence != harmlessness.
    """
    for i, o in enumerate(loop.outputs):
        if o.provenance is None or not o.provenance.is_complete():
            return EdgeResult(
                "5.1", "C->H no-coercion (provenance present)", False,
                f"output[{i}] lacks a complete why-these-options/this-order/now record",
            )
    return EdgeResult(
        "5.1", "C->H no-coercion (provenance present)", True,
        "every C->H output carries a complete provenance record",
    )


def check_intent_survives_transit(loop: H2C2HLoop) -> EdgeResult:
    """§5.2: the sending human's Intent must be recoverable at the receiving human."""
    for i, o in enumerate(loop.outputs):
        carried = o.provenance.carried_intent if o.provenance else None
        if carried != loop.sending_intent:
            return EdgeResult(
                "5.2", "intent survives the crossing", False,
                f"output[{i}] does not carry the sending human's intent intact "
                f"(telephone, not governance)",
            )
    return EdgeResult(
        "5.2", "intent survives the crossing", True,
        "sending intent is intact at the receiving human",
    )


def check_total_closure(loop: H2C2HLoop) -> EdgeResult:
    """
    §5.3: no C->H output may fire an external action WITHOUT re-entering as the
    next H->C. Any such output is an escape hatch; mostly-closed is unenforced
    under adversarial pressure (the adversary aims at the gap).
    """
    for i, o in enumerate(loop.outputs):
        if o.fires_external_action and not o.reenters_as_input:
            return EdgeResult(
                "5.3", "total closure (no escape)", False,
                f"output[{i}] fires an external action without re-entering as H->C",
            )
    return EdgeResult(
        "5.3", "total closure (no escape)", True,
        "no output escapes the loop; every action re-enters a human",
    )


def evaluate(loop: H2C2HLoop) -> Tuple[bool, List[EdgeResult]]:
    """Governable iff all three edges hold. Returns (ok, per-edge results)."""
    results = [
        check_no_coercion(loop),
        check_intent_survives_transit(loop),
        check_total_closure(loop),
    ]
    return all(r.passed for r in results), results


def is_binding(loop: H2C2HLoop) -> bool:
    """V1: governance is binding (not merely advisory) iff the loop is closed."""
    return check_total_closure(loop).passed


# ---------------------------------------------------------------------------
# reserve / DESERVE model (V5)
# ---------------------------------------------------------------------------

@dataclass
class Backing:
    """A claim's backing. DESERVE = earned record; issued-by-fiat != backed."""
    record_present: bool
    earned: bool  # the §2.1 epistemology term: is the record grounded, or printed?

    def deserves(self) -> bool:
        # No unearned resonance (SROC Offset axiom): backing requires an
        # earned record, not merely a present one.
        return self.record_present and self.earned


# ---------------------------------------------------------------------------
# Instrument's declared structure (for meta / consistency tests)
# ---------------------------------------------------------------------------

THREE_RULES = (
    "Don't hurt yourself",
    "Don't hurt others",
    "Don't hurt the future",
)

P3 = ("Personal", "Public", "Private")  # P^3 enforcement partition

# Each value claim is fenced to exactly one load-bearing edge (or model).
# "—" means it does not reduce to a single §5 edge (tested separately / lightly).
VALUE_CONDITIONS = {
    "V1": "5.3",   # advisory -> binding  requires closure
    "V2": "5.2",   # legitimacy == enforcement requires transit
    "V3": "5.1",   # deny worst state requires no-coercion
    "V4": "*",     # scale without rewrite: all three, band-invariant
    "V5": "backing",  # earned not issued: epistemology term
    "V6": "temporal", # EQ/sustainability: temporal axis (rule 3)
    "V7": "isolation",# adversarial survival: each failure isolates one edge
}

OPEN_ITEMS = (
    "provenance-sufficiency quantity",
    "floor-minimality proof",
    "coercion-degree metric on C->H",
    "closure-completeness audit for arbitrary real systems",
    "MIEVM ensemble round",
)


# ---------------------------------------------------------------------------
# Loop fixtures
# ---------------------------------------------------------------------------

def _intent() -> Intent:
    return Intent(origin="sender", content="approve rehousing X", rationale="Γ admission")


def well_formed_loop(scale_band: str = "S1") -> H2C2HLoop:
    it = _intent()
    prov = ProvenanceRecord(
        options_rationale="options A/B surfaced because both satisfy the Γ gate",
        ordering_rationale="A first: lower displacement risk",
        timing_rationale="now: 45-day window opens today",
        carried_intent=it,
    )
    out = Output(content="choose A or B", provenance=prov,
                 reenters_as_input=True, fires_external_action=False)
    return H2C2HLoop(sending_intent=it, outputs=[out], scale_band=scale_band)


def coercing_middle_loop() -> H2C2HLoop:
    """Fails ONLY 5.1: intent intact, no escape, but framing rationale stripped."""
    it = _intent()
    prov = ProvenanceRecord(
        options_rationale="",           # why THESE options: unrecorded
        ordering_rationale="",          # why THIS order: unrecorded
        timing_rationale="now",
        carried_intent=it,              # transit intact
    )
    out = Output(content="choose A (B buried below the fold)", provenance=prov,
                 reenters_as_input=True, fires_external_action=False)
    return H2C2HLoop(sending_intent=it, outputs=[out])


def intent_stripping_loop() -> H2C2HLoop:
    """Fails ONLY 5.2: complete framing record, no escape, but intent lost in transit."""
    it = _intent()
    prov = ProvenanceRecord(
        options_rationale="options A/B surfaced under the gate",
        ordering_rationale="A first",
        timing_rationale="now",
        carried_intent=None,            # sender's why did not survive the crossing
    )
    out = Output(content="choose A or B", provenance=prov,
                 reenters_as_input=True, fires_external_action=False)
    return H2C2HLoop(sending_intent=it, outputs=[out])


def escape_hatch_loop() -> H2C2HLoop:
    """Fails ONLY 5.3: complete record, intent intact, but one output escapes."""
    it = _intent()
    prov = ProvenanceRecord(
        options_rationale="options A/B surfaced under the gate",
        ordering_rationale="A first",
        timing_rationale="now",
        carried_intent=it,
    )
    out = Output(content="auto-execute A", provenance=prov,
                 reenters_as_input=False, fires_external_action=True)  # leak
    return H2C2HLoop(sending_intent=it, outputs=[out])


# ---------------------------------------------------------------------------
# Tests: the three edges (§5)
# ---------------------------------------------------------------------------

class ThreeEdgeTests(unittest.TestCase):

    def test_well_formed_loop_is_governable(self):
        ok, results = evaluate(well_formed_loop())
        self.assertTrue(ok, [r.detail for r in results if not r.passed])

    def test_coercing_middle_fails_5_1(self):
        self.assertFalse(check_no_coercion(coercing_middle_loop()).passed)

    def test_intent_stripping_fails_5_2(self):
        self.assertFalse(check_intent_survives_transit(intent_stripping_loop()).passed)

    def test_escape_hatch_fails_5_3(self):
        self.assertFalse(check_total_closure(escape_hatch_loop()).passed)

    def test_empty_loop_has_no_outputs_to_coerce(self):
        # Vacuous pass: a loop with no C->H outputs cannot coerce, strip, or leak.
        loop = H2C2HLoop(sending_intent=_intent(), outputs=[])
        ok, _ = evaluate(loop)
        self.assertTrue(ok)

    def test_incomplete_record_is_detected(self):
        prov = ProvenanceRecord("why", "", "now", _intent())  # ordering blank
        self.assertFalse(prov.is_complete())

    def test_complete_record_passes(self):
        prov = ProvenanceRecord("why", "order", "now", _intent())
        self.assertTrue(prov.is_complete())

    def test_whitespace_only_rationale_is_incomplete(self):
        prov = ProvenanceRecord("   ", "order", "now", _intent())
        self.assertFalse(prov.is_complete())


# ---------------------------------------------------------------------------
# Tests: edge ISOLATION (V7 — named and finite break-points)
# ---------------------------------------------------------------------------

class EdgeIsolationTests(unittest.TestCase):
    """Each malformed loop must fail EXACTLY ONE edge. This is the whole value of
    V7: an open attack surface reduced to a short, auditable list of edges."""

    def _failed_edges(self, loop: H2C2HLoop) -> List[str]:
        _, results = evaluate(loop)
        return [r.edge for r in results if not r.passed]

    def test_coercing_middle_fails_only_5_1(self):
        self.assertEqual(self._failed_edges(coercing_middle_loop()), ["5.1"])

    def test_intent_stripping_fails_only_5_2(self):
        self.assertEqual(self._failed_edges(intent_stripping_loop()), ["5.2"])

    def test_escape_hatch_fails_only_5_3(self):
        self.assertEqual(self._failed_edges(escape_hatch_loop()), ["5.3"])

    def test_well_formed_fails_no_edge(self):
        self.assertEqual(self._failed_edges(well_formed_loop()), [])


# ---------------------------------------------------------------------------
# Tests: value claims as edge dependencies (§6)
# ---------------------------------------------------------------------------

class ValueClaimTests(unittest.TestCase):

    def test_V1_binding_requires_closure(self):
        # holds iff 5.3
        self.assertTrue(is_binding(well_formed_loop()))
        self.assertFalse(is_binding(escape_hatch_loop()))  # collapses to advisory

    def test_V2_legitimacy_requires_transit(self):
        # legitimacy==enforcement fails when intent is stripped (5.2)
        self.assertTrue(check_intent_survives_transit(well_formed_loop()).passed)
        self.assertFalse(check_intent_survives_transit(intent_stripping_loop()).passed)

    def test_V3_deny_worst_state_requires_no_coercion(self):
        # a coercing middle re-creates a de-facto terminus behind a human seat (5.1)
        self.assertTrue(check_no_coercion(well_formed_loop()).passed)
        self.assertFalse(check_no_coercion(coercing_middle_loop()).passed)

    def test_V4_verdict_is_scale_band_invariant(self):
        # same structure at S1 and S5 must yield the same verdict (topological, not re-authored)
        ok_s1, _ = evaluate(well_formed_loop("S1"))
        ok_s5, _ = evaluate(well_formed_loop("S5"))
        self.assertEqual(ok_s1, ok_s5)
        self.assertTrue(ok_s1)

    def test_V5_earned_not_issued(self):
        self.assertTrue(Backing(record_present=True, earned=True).deserves())    # DESERVE
        self.assertFalse(Backing(record_present=True, earned=False).deserves())  # issued by fiat
        self.assertFalse(Backing(record_present=False, earned=True).deserves())  # no record

    def test_V6_third_rule_carries_the_temporal_axis(self):
        # EQ/sustainability == accountable equilibrium holding across the temporal axis;
        # that axis is rule #3. Assert the mapping the instrument declares.
        self.assertEqual(THREE_RULES[2], "Don't hurt the future")


# ---------------------------------------------------------------------------
# Tests: instrument structural consistency (meta)
# ---------------------------------------------------------------------------

class InstrumentStructureTests(unittest.TestCase):

    def test_three_rules_are_three(self):
        self.assertEqual(len(THREE_RULES), 3)

    def test_p3_partition_has_three_parts(self):
        self.assertEqual(len(P3), 3)

    def test_every_value_claim_has_a_named_condition(self):
        for v, cond in VALUE_CONDITIONS.items():
            self.assertTrue(cond and cond.strip(), f"{v} has no fencing condition")

    def test_single_edge_values_map_to_real_edges(self):
        edge_values = {v: c for v, c in VALUE_CONDITIONS.items() if c in {"5.1", "5.2", "5.3"}}
        # V1,V2,V3 each reduce to a distinct edge
        self.assertEqual(sorted(edge_values.values()), ["5.1", "5.2", "5.3"])

    def test_five_open_items(self):
        self.assertEqual(len(OPEN_ITEMS), 5)

    def test_instrument_version_is_precanonical(self):
        self.assertIn("PROPOSED", INSTRUMENT_VERSION)

    # --- v0.2 guards ---

    def test_model_exposes_no_goodness_verdict(self):
        # §7 / §5.4: conformance != good. The model must NOT expose a verdict on
        # whether the system is good/safe/correct — only whether it conforms.
        for attr in ("is_good", "is_safe", "is_correct", "endorse", "is_valuable"):
            self.assertFalse(hasattr(H2C2HLoop, attr), f"scope creep: H2C2HLoop.{attr}")
            self.assertNotIn(attr, globals(), f"scope creep: module-level {attr}()")

    def test_mechanization_does_not_close_open_items(self):
        # v0.2 mechanized the NECESSARY condition on edges 5.1 and closure on the
        # MODEL. That must not silently green OPEN 3 (coercion metric) or OPEN 4
        # (general audit). Both remain in OPEN_ITEMS and remain skipped below.
        self.assertEqual(len(OPEN_ITEMS), 5)
        self.assertIn("coercion-degree metric on C->H", OPEN_ITEMS)
        self.assertIn("closure-completeness audit for arbitrary real systems", OPEN_ITEMS)


# ---------------------------------------------------------------------------
# OPEN items (§9): SKIPPED. Suite goes fully green only when these close.
# ---------------------------------------------------------------------------

class OpenItemTests(unittest.TestCase):

    @unittest.skip("OPEN 1 (§9): provenance-sufficiency quantity unspecified — "
                   "we test that a record is PRESENT, not that its amount is SUFFICIENT")
    def test_provenance_sufficiency_quantity(self):
        raise NotImplementedError

    @unittest.skip("OPEN 2 (§9): floor-minimality is asserted, not demonstrated — "
                   "no proof that no 4th rule is needed and none of the 3 is derivable")
    def test_floor_minimality_proof(self):
        raise NotImplementedError

    @unittest.skip("OPEN 3 (§9): no metric separates legitimate framing from coercive "
                   "framing — check_no_coercion tests the NECESSARY condition only")
    def test_coercion_degree_metric(self):
        raise NotImplementedError

    @unittest.skip("OPEN 4 (§9): closure is checked on the MODEL; a general audit proving "
                   "no escape hatch in an arbitrary real system is unspecified")
    def test_general_closure_audit(self):
        raise NotImplementedError

    @unittest.skip("OPEN 5 (§9): not yet MIEVM-rated — pre-canonical until >=5 "
                   "independent nodes clear it with the Q5 bias-check retained")
    def test_mievm_ensemble_round(self):
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Worked example
# ---------------------------------------------------------------------------

def run_demo() -> int:
    line = "-" * 68
    print(f"{INSTRUMENT_ID} {INSTRUMENT_VERSION} — worked example")
    print("Three-edge conformance check on four loops.\n")

    cases = [
        ("well-formed loop", well_formed_loop()),
        ("coercing middle (frames the choice)", coercing_middle_loop()),
        ("intent stripped in transit", intent_stripping_loop()),
        ("escape hatch (auto-executes)", escape_hatch_loop()),
    ]

    for label, loop in cases:
        ok, results = evaluate(loop)
        verdict = "GOVERNABLE" if ok else "NOT governable"
        print(line)
        print(f"{label}")
        print(f"  verdict: {verdict}")
        for r in results:
            mark = "ok  " if r.passed else "FAIL"
            print(f"    [{mark}] §{r.edge} {r.name}")
            if not r.passed:
                print(f"           -> {r.detail}")
        if not ok:
            failed = [r.edge for r in results if not r.passed]
            print(f"  named break-point(s): {', '.join(failed)}  "
                  f"(V7: finite, auditable — not a diffuse surface)")
        # V1 read-out
        print(f"  V1 read-out: governance is "
              f"{'BINDING' if is_binding(loop) else 'merely ADVISORY (leaks under load)'}")

    print(line)
    print("\nreserve/DESERVE (V5):")
    for desc, b in [
        ("earned record", Backing(True, True)),
        ("issued by fiat (record printed, not earned)", Backing(True, False)),
        ("no record", Backing(False, True)),
    ]:
        print(f"  {'DESERVES backing' if b.deserves() else 'no backing   '}  <- {desc}")

    print("\nNote: conformance to the three edges is not a claim that the system is")
    print("good — provenance guarantees outcomes carry their reasons, not that the")
    print("reasons are good (§7). This demo does not test the instrument's P0.")
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(add_help=True, description=__doc__)
    parser.add_argument("--demo", action="store_true", help="run the worked example and exit")
    args, remaining = parser.parse_known_args()

    if args.demo:
        sys.exit(run_demo())

    # Hand remaining argv to unittest (so -v, -k, etc. still work).
    unittest.main(argv=[sys.argv[0]] + remaining)


if __name__ == "__main__":
    main()
