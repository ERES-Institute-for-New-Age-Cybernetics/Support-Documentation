# ERES Transmission Validation Suite — Deposit Manifest

**Instrument:** ERES-PELLIS-SHB-VAL-001
**Companion to:** ERES-PELLIS-SHB-001, *Sound Holds the Band* (white paper)
**Author:** Joseph Allen Sprute (ERES Maestro), ORCID 0000-0001-9946-3221
**Institute:** ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
**License:** CC-BY 4.0
**Date:** 10 July 2026

## Contents

| File | What it is |
|---|---|
| `eres_transmission_validation.py` | The validation & principle suite (runnable). |
| `README.md` | Method, findings, usage, and revision-loop status. |
| `eres_validation_report.json` | Machine-readable report from a 30-seed run. |
| `sample_real_data.csv` | Synthetic 4-channel CSV exercising the real-data adapter. |

## Run

```bash
python3 eres_transmission_validation.py                 # full suite
python3 eres_transmission_validation.py --seeds 40      # more Monte-Carlo
python3 eres_transmission_validation.py --json out.json # machine report
python3 eres_transmission_validation.py --csv data.csv  # real biology/graphene data (250 Hz)
```

Exit code is the verdict: `0` = all staked claims behaved as the paper
asserts; `1` = at least one unsupported. Requires `numpy` and `scipy`.

## What it certifies

Coherence as a two-sided band (the paper's Corollary 1): a successful
ERES Transmission sits strictly between an incoherence wall and a
condensation wall. The decisive result is that the over-locked
(condensed) case is *rejected* — a naive "more synchronization is
better" metric would accept it. Confirmation and falsification are kept
rigorously separate. A PASS is evidence, not proof; the paper's
CONSTRUCTED and CONJECTURE tags stand until an independent instrument or
real data reproduces the result.
