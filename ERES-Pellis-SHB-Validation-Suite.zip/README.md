# ERES Transmission — Validation & Principle Suite

**Companion to** ERES-PELLIS-SHB-001 v2.2, *Sound Holds the Band*.
**File:** `eres_transmission_validation.py` · **License:** CC-BY 4.0 · **Date:** 10 July 2026

---

## What it is

A self-contained Python suite that tests the one claim the white paper actually
stakes everything on: that **coherence is a two-sided band**. A Transmission —
an entrained Question/Answer coupling — succeeds only *between* two walls:

- **lower wall — incoherence:** no phase-lock, nothing transmitted;
- **upper wall — condensation:** over-lock, the Answer becomes an echo, frequency
  diversity dies. This is collapse in Pellis's sense and "mining" in ERES's.

"Tune, not mine" is true **only if the upper wall exists.** A coherence metric
with no upper wall would call full condensation "perfect resonance," which is
the failure mode the paper is built to reject. So the suite's central job is to
prove the upper wall is real and that the battery detects it.

## How it tests (confirm / falsify, kept separate)

- **CONFIRM** — clean in-band signals *should* read coherent (`in_band`,
  `qa_coupled`).
- **FALSIFY** — null and wall signals *should* read incoherent
  (`incoherent`, `condensed`, `white noise`, `qa_decoupled`).

The falsification half is the point. If a null passes, the corresponding paper
claim is **unsupported** and the suite says so and exits non-zero. Each regime is
run across many random seeds; a test "passes for a regime" only on a majority of
seeds (Monte-Carlo robustness, not one lucky RNG).

## Tests instrumented

From the paper's nine-test battery (Appendix A), the suite instruments the five
that both certify coherence and can be *broken* by the nulls:

| Test | Paper # | Tag | Role |
|---|---|---|---|
| Kuramoto order-parameter **band** | 7 | DERIVED | core gate (two-sided) |
| Spectral **gap** (Fiedler, two-sided) | 1 | DERIVED + CONSTRUCTED | core gate |
| Spectral **entropy** (RHC) | 6 | DERIVED + CONSTRUCTED | corroborating |
| Inverse participation ratio | 5 | DERIVED | corroborating |
| Q/A cross-block transmission | §6 | CONSTRUCTED | coupling-fidelity gate |

The verdict gates on the **DERIVED pair** (order-parameter band + spectral gap),
with entropy/IPR reported as corroboration rather than gates — deliberately, so
the verdict can't be tuned to pass by moving a threshold we chose.

## Two findings the suite caught about the paper's own construction

The suite did its job as an independent oscillator — it broke two of the author's
own choices before any external reviewer saw them:

1. **The first Q/A generator over-coupled into condensation.** Built with
   cross-coupling 0.9, the "successful transmission" case collapsed both blocks
   into one phase — it drove the system *through* the upper wall. The suite
   flagged it as incoherent, correctly. Fix: cross-coupling lowered to 0.35 to
   sit in-band. *The paper's own principle caught the paper's own code.*

2. **The global order parameter is the wrong instrument for a two-block system.**
   Global Kuramoto `r` reads low for Q/A precisely because Q and A lock to
   *different* mean phases — which is the "distinct voices" the paper wants, not
   a defect. The correct gate for a Q/A system is the **cross-block** transmission
   (cross-PLV in band), which certifies entrainment without demanding the voices
   merge. This is now encoded in the aggregate and is itself a substantive
   clarification for the white paper: *coupling fidelity must be measured
   cross-block, not globally.*

Both findings should flow back into the WP revision (see below).

## Running it

```bash
python3 eres_transmission_validation.py                 # full suite (20 seeds)
python3 eres_transmission_validation.py --seeds 40      # more Monte-Carlo
python3 eres_transmission_validation.py --json out.json # machine-readable report
python3 eres_transmission_validation.py --csv data.csv  # real biology/graphene data
python3 eres_transmission_validation.py --csv d.csv --phase   # if CSV is already phases
```

Exit code is the verdict: **0 = all staked claims behaved as asserted, 1 = at
least one unsupported.** This lets MIEVM/CI tooling consume the result directly.

## Real-data adapter

`--csv` accepts a table of simultaneously-sampled channels (one column per
channel: e.g. ECG, respiration, EEG band, graphene piezoresistive trace; one row
per timestep). Raw amplitudes are converted to instantaneous phase via the
analytic (Hilbert) signal, then run through the **identical** battery as the
synthetic core — no test knows whether its input was simulated or measured. That
identity is the point: it is what lets the §6 benchtop experiment be scored by
exactly the instrument that scored the principle. Note the statistics need a
reasonable channel count; a handful of channels is legitimately too few and the
adapter will (correctly) not pretend otherwise.

## What a PASS means, and does not

A PASS is **evidence, not proof.** It shows the operationalized tests behave as
the paper asserts *on these signals*. The CONSTRUCTED and CONJECTURE tags in the
white paper stay exactly where they are until an **independent instrument
(MIEVM)** or **real data** reproduces the result. The suite is designed to be the
first independent oscillator; it is not a substitute for the ensemble.

## Revision loop status (as of v2.2)

**Done:** The article was MIEVM'd across four instruments (Claude, DeepSeek,
Gemini, ChatGPT; convergent ~9.6-9.7/10). Their convergent 10/10 blockers were
folded into the paper, which is now at **v2.2** ("Sound Holds the Band"): the
Kuramoto correspondence was softened from equivalence to a mapping; **Theorem 1**
(two-sided band) with proof sketch and **Corollary 1** (full sync is not
resonance-preserving) were added; conjectures became numbered, falsifiable
**Predictions 1-3**; this suite's results were embedded as Section 6; and the
two validation findings (cross-block coupling fidelity, condensation-tuning
caution) were promoted into Appendix A. This script's header is synced to name
the theorem and predictions it bears on.

**Next:** run real graphene/biology traces through the adapter at 250 Hz to test
**Prediction 2**, then return the paired article + validated script to Dr. Pellis
for Track-B. Until real data or the independent MIEVM ensemble reproduces the
Section 6 results, the paper's CONSTRUCTED/CONJECTURE tags stay exactly where
they are.
