#!/usr/bin/env python3
"""Structural test suite for ERES-NAC-SYMBOLS-2026-001 v2.1 (NAC Symbol Register).

Standard library only. Run:  python3 test_nac_symbols.py
Exit code 0 = every structural invariant holds.

These tests check that the register is internally consistent: counts, homes,
chain order, Trinity ownership and collision rules. They do NOT validate any
symbol's physical or empirical claim; those stay Proposed / On file as tagged.
License: CCAL v2.1 / CC-BY 4.0.
"""
import glob, json, math, os, re, sys, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
REG_PATH = glob.glob(os.path.join(HERE, "*_register.json"))[0]
MD_PATH = [p for p in glob.glob(os.path.join(HERE, "*.md")) if not p.endswith("README.md")][0]
with open(REG_PATH, encoding="utf-8") as f:
    R = json.load(f)
with open(MD_PATH, encoding="utf-8") as f:
    MD = f.read()

RING = ["L1", "L2", "L3", "L4", "L5", "L6"]
CHAIN = ["Emotion", "Utterance", "Sound", "Word (spoken)", "Symbol", "Glyph",
         "Letter", "Word (written)", "Character", "Semantic"]
DOM = {d["id"]: d for d in R["domains"]}
STAGES = R["stages"]
SYMS = R["symbols"]
BY_SYMBOL = {s["symbol"]: s for s in SYMS}


class TestChain(unittest.TestCase):
    def test_ten_stages_in_order(self):
        self.assertEqual([s["n"] for s in STAGES], list(range(1, 11)))

    def test_stage_names_match_author_chain(self):
        self.assertEqual([s["name"] for s in STAGES], CHAIN)

    def test_word_appears_twice_spoken_then_written(self):
        words = [s["n"] for s in STAGES if s["name"].startswith("Word")]
        self.assertEqual(words, [4, 8])

    def test_chain_runs_once_round_the_ring_from_L2_to_L1(self):
        order = ["L2", "L3", "L4", "L5", "L6", "L1"]
        idx = [order.index(s["domain"]) for s in STAGES]
        self.assertEqual(idx, sorted(idx), "chain must not step backwards round the ring")
        self.assertEqual(STAGES[0]["domain"], "L2")
        self.assertEqual(STAGES[-1]["domain"], "L1")
        self.assertEqual(set(s["domain"] for s in STAGES), set(RING), "every Domain is visited")

    def test_stage_counts_per_domain(self):
        counts = {d: sum(1 for s in STAGES if s["domain"] == d) for d in RING}
        self.assertEqual(counts, {"L1": 1, "L2": 2, "L3": 2, "L4": 2, "L5": 2, "L6": 1})

    def test_loop_closes_through_aura_after(self):
        self.assertEqual(R["loop"], {"from": 10, "to": 1, "via": "Aura After"})

    def test_privacy_line_is_K_c_between_emotion_and_utterance(self):
        pl = R["privacy_line"]
        self.assertEqual(pl["symbol"], "K_c")
        self.assertEqual(pl["between_stages"], [1, 2])
        self.assertIn("K_c", STAGES[1]["symbols"])
        self.assertNotIn("K_c", STAGES[0]["symbols"])


class TestTrinity(unittest.TestCase):
    def test_ownership(self):
        own = {d: DOM[d]["owner"] for d in RING}
        self.assertEqual(own, {"L1": "GOOD", "L6": "GOOD", "L2": "SOUND", "L3": "SOUND",
                               "L4": "BEST", "L5": "BEST"})

    def test_movements_are_contiguous_voice_inscription_meaning(self):
        owners = [DOM[s["domain"]]["owner"] for s in STAGES]
        self.assertEqual(owners, ["SOUND"] * 4 + ["BEST"] * 4 + ["GOOD"] * 2)
        self.assertEqual([m["name"] for m in R["movements"]], ["Voice", "Inscription", "Meaning"])


class TestRegister(unittest.TestCase):
    def test_counts(self):
        on_file = [s for s in SYMS if s["status"].startswith("On file")]
        proposed = [s for s in SYMS if s["status"].startswith("Proposed")]
        self.assertEqual(len(SYMS), 27)
        self.assertEqual(len(on_file), 23)
        self.assertEqual(len(proposed), 4)
        self.assertEqual({s["symbol"] for s in proposed}, {"☉", "𓋹", "⇄", "≈"})

    def test_every_symbol_has_a_valid_home_and_a_source(self):
        for s in SYMS:
            self.assertIn(s["home"], DOM, s["symbol"])
            self.assertTrue(s["source"].strip(), f"{s['symbol']} has no source")
            self.assertTrue(s["binding"].strip(), f"{s['symbol']} has no binding")

    def test_symbols_are_unique(self):
        self.assertEqual(len(BY_SYMBOL), len(SYMS))

    def test_hub_symbols_bind_all_six(self):
        for s in SYMS:
            if s["home"] == "HUB":
                self.assertIn(s["stage"], {"Loop", "Movements", "All"}, s["symbol"])

    def test_every_stage_symbol_is_registered_at_that_stage_domain(self):
        for st in STAGES:
            for sym in st["symbols"]:
                self.assertIn(sym, BY_SYMBOL, f"stage {st['n']} symbol {sym} not registered")
                self.assertEqual(BY_SYMBOL[sym]["home"], st["domain"], sym)

    def test_numeric_stage_tags_agree_with_home(self):
        stage_dom = {s["n"]: s["domain"] for s in STAGES}
        for s in SYMS:
            nums = [int(x) for x in re.findall(r"\d+", s["stage"])]
            for n in nums:
                self.assertEqual(stage_dom[n], s["home"], f"{s['symbol']} stage {n}")

    def test_five_named_keys_present_and_consistent(self):
        keys = {k["symbol"]: k for k in R["named_keys"]}
        self.assertEqual(set(keys), {"☉", "𓋹", "Δ", "∞", "Φ"})
        for sym, k in keys.items():
            self.assertEqual(k["home"], BY_SYMBOL[sym]["home"], sym)


class TestCollisionRules(unittest.TestCase):
    def test_lowercase_phi_only_as_latitude(self):
        for s in SYMS:
            if "φ" in s["symbol"]:
                self.assertEqual(s["symbol"], "G(φ, λ)")

    def test_capital_phi_only_as_golden_ratio_and_held_as_conjecture(self):
        phi = BY_SYMBOL["Φ"]
        self.assertEqual(phi["name"], "Golden ratio")
        self.assertIn("conjecture", phi["status"].lower())

    def test_spectral_lambda_carries_its_operator(self):
        for s in SYMS:
            if "λ" in s["symbol"] and s["symbol"] != "G(φ, λ)":
                self.assertTrue(s["symbol"].startswith("Δλ"), s["symbol"])

    def test_sigma_cases_are_distinct_quantities(self):
        self.assertNotEqual(BY_SYMBOL["σ"]["binding"], BY_SYMBOL["Σ"]["binding"])
        self.assertIn("1σ", BY_SYMBOL["σ"]["binding"])
        self.assertIn("HARMONY", BY_SYMBOL["Σ"]["binding"])

    def test_four_collisions_each_with_a_rule(self):
        self.assertEqual(len(R["collisions"]), 4)
        for c in R["collisions"]:
            self.assertTrue(c["rule"].strip())

    def test_golden_ratio_identity(self):
        phi = (1 + math.sqrt(5)) / 2
        self.assertAlmostEqual(phi, 1.6180339887, places=9)
        self.assertAlmostEqual(phi * phi, phi + 1, places=12)


class TestTextAgreesWithRegister(unittest.TestCase):
    def test_master_text_states_the_same_counts(self):
        m = re.search(r"\*\*(\d+) symbols: (\d+) on file in corpus instruments, (\d+) proposed\.\*\*", MD)
        self.assertIsNotNone(m)
        self.assertEqual(tuple(int(x) for x in m.groups()), (27, 23, 4))

    def test_master_text_carries_version_and_license(self):
        self.assertIn(f"v{R['version']} Proposed", MD)
        self.assertIn(R["license"], MD)
        self.assertIn("## Credits", MD)
        self.assertIn("## References", MD)


if __name__ == "__main__":
    result = unittest.main(exit=False, verbosity=2).result
    sys.exit(0 if result.wasSuccessful() else 1)
