#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_flip_testkit.py  —  companion to ERES-FLIP-2026-001 v0.2 PROVISIONAL

FLIP-PREMISE (CPROV): the prose states the doctrine; this code makes its
load-bearing STRUCTURAL conditions runnable; the two track one version.
A green run is evidence of INTERNAL COHERENCE, not empirical or political
truth. Every empirical/political claim in the WP stays CONJECTURE by
construction and is out of scope here.

Standard library only. Expected: PASS on structural invariants, deliberate
SKIP on the two author-reserved definitions, exit 0.

    python3 eres_flip_testkit.py
"""

import sys

TESTS_SPEC_VERSION = (0, 2)
INSTRUMENT_ID = "ERES-FLIP-2026-001"

results = []  # (name, status, detail)   status in {PASS, FAIL, SKIP}


def check(name, ok, detail=""):
    results.append((name, "PASS" if ok else "FAIL", detail))


def skip(name, detail=""):
    results.append((name, "SKIP", detail))


# ----------------------------------------------------------------------
# Structural model of the FLIP's load-bearing rules and the ERES axioms.
# ----------------------------------------------------------------------

class Reserve:
    """Denominated in priced MAGNITUDE or coherence-DURATION. The FLIP
    forbids magnitude denomination and forbids converting qualified
    (VEILED) credits into magnitude (F3)."""
    def __init__(self, unit):
        assert unit in ("magnitude", "duration")
        self.unit = unit

    def convert_credits_to_magnitude(self):
        raise ValueError("F3 violation: credits qualify issuance, never convert")


def proven_duration_years(system):
    return system.get("proven_years", 0)


def reserve_satisfies(planned_years, system):
    return proven_duration_years(system) >= planned_years


def reuse_allowed(site):
    """Dignity rule: ordnance clearance AND remains recovery precede reuse."""
    return bool(site.get("ordnance_cleared")) and bool(site.get("remains_recovered"))


# A0 — No Unearned Resonance: value minted only against a real deficit.
def mint(offset):
    return offset if offset > 0 else 0


# A-Floor — the empirical Floor (2012-02-04): exactly three rules.
FLOOR = ("dont_hurt_yourself", "dont_hurt_others", "dont_hurt_the_future")

# non-imposability: the floor is offered, never administered from outside.
FLOOR_DELIVERY = {"offered": True, "imposed": False}

REGION_ROLE = {
    "obligated": False, "invitation": True, "portable": True, "exclusive": False,
}


class Instrument:
    """A-DVC: the model exposes NO truth/goodness verdict (P0 abstention)."""
    def has_truth_verdict(self):
        return False


# ----------------------------------------------------------------------
# t1-t3 — FLIP inversion (§2), F3 non-conversion
# ----------------------------------------------------------------------
r_dur = Reserve("duration")
check("t1_duration_unit_is_legal", r_dur.unit == "duration",
      "FLIP reserve denominated in coherence-duration")
try:
    r_dur.convert_credits_to_magnitude()
    check("t2_F3_blocks_conversion", False)
except ValueError:
    check("t2_F3_blocks_conversion", True, "F3 non-conversion enforced")
check("t3_magnitude_and_duration_distinct",
      Reserve("magnitude").unit != Reserve("duration").unit,
      "magnitude and duration not conflated")

# ----------------------------------------------------------------------
# t4-t6 — accrual gap #U2 (§9): unsatisfiable at t=0
# ----------------------------------------------------------------------
check("t4_greenfield_zero_proven", proven_duration_years({"proven_years": 0}) == 0,
      "a not-yet-rebuilt system has zero proven duration")
check("t5_U2_unsatisfiable_at_inception",
      reserve_satisfies(1000, {"proven_years": 0}) is False,
      "1000 proven >= 1000 planned is FALSE at t=0 (#U2)")
check("t6_U2_not_falsely_closed_by_eres_age",
      reserve_satisfies(1000, {"proven_years": 14}) is False,
      "~14 proven years do not satisfy a 1000-year map")

# ----------------------------------------------------------------------
# t7-t9 — dignity rule precedence (§0, §7): absolute
# ----------------------------------------------------------------------
check("t7_no_reuse_before_clearance",
      reuse_allowed({"ordnance_cleared": False, "remains_recovered": False}) is False,
      "reuse blocked until dignity gate passes")
check("t8_partial_clearance_still_blocks",
      reuse_allowed({"ordnance_cleared": True, "remains_recovered": False}) is False,
      "ordnance AND remains recovery both required")
check("t9_reuse_only_after_full_dignity_gate",
      reuse_allowed({"ordnance_cleared": True, "remains_recovered": True}) is True,
      "reuse only after full dignity gate")

# ----------------------------------------------------------------------
# t10-t12 — proposal-not-obligation (§7 / C10)
# ----------------------------------------------------------------------
check("t10_region_not_obligated", REGION_ROLE["obligated"] is False,
      "no region is claimed to be obligated")
check("t11_method_portable_nonexclusive",
      REGION_ROLE["portable"] and not REGION_ROLE["exclusive"],
      "offered to any electing region, exclusive to none")
check("t12_role_is_invitation", REGION_ROLE["invitation"] is True,
      "the regional role is an invitation, not an assignment")

# ----------------------------------------------------------------------
# t15-t18 — ERES AXIOMS (§1), newly demonstrated in v0.2
# ----------------------------------------------------------------------
check("t15_A0_no_unearned_resonance",
      mint(0) == 0 and mint(-3) == 0 and mint(5) == 5,
      "A0: zero/negative offset mints nothing; positive offset mints value")
check("t16_floor_is_exactly_three_rules",
      len(FLOOR) == 3 and FLOOR[2] == "dont_hurt_the_future",
      "A-Floor: exactly three rules incl. don't-hurt-the-future (rule #3)")
check("t17_floor_non_imposable",
      FLOOR_DELIVERY["offered"] and not FLOOR_DELIVERY["imposed"],
      "non-imposability: floor offered, never administered from outside")
check("t18_DVC_abstains_from_truth_verdict",
      Instrument().has_truth_verdict() is False,
      "A-DVC: the instrument exposes no truth/goodness (P0) verdict")

# ----------------------------------------------------------------------
# t13-t14 — author-reserved definitions (§0): deliberate load-bearing SKIP
# ----------------------------------------------------------------------
RT_MEDIA_CONFIRMED = False
FLIP_SENSE_CONFIRMED = False
(skip if not RT_MEDIA_CONFIRMED else check)(
    "t13_rt_media_reading_confirmed",
    "RT-Media = RECORDED/REFLECTED/RECONCILE — awaiting author confirmation (§0)"
    if not RT_MEDIA_CONFIRMED else True)
(skip if not FLIP_SENSE_CONFIRMED else check)(
    "t14_flip_sense_confirmed",
    "FLIP = economic inversion + CPROV FLIP-PREMISE — awaiting author confirmation (§0)"
    if not FLIP_SENSE_CONFIRMED else True)


# ----------------------------------------------------------------------
# Runner
# ----------------------------------------------------------------------
def main():
    n_pass = sum(1 for _, s, _ in results if s == "PASS")
    n_fail = sum(1 for _, s, _ in results if s == "FAIL")
    n_skip = sum(1 for _, s, _ in results if s == "SKIP")
    width = max(len(n) for n, _, _ in results)
    print(f"{INSTRUMENT_ID}  structural testkit  (spec {TESTS_SPEC_VERSION})")
    print("-" * (width + 22))
    for name, status, detail in results:
        line = f"{name.ljust(width)}  {status}"
        if detail:
            line += f"  · {detail}"
        print(line)
    print("-" * (width + 22))
    print(f"{n_pass} pass · {n_fail} fail · {n_skip} skip (of {len(results)})")
    print("SKIPs are the two author-reserved readings (§0); green on author confirmation.")
    print("Green == structural COHERENCE only; empirical/political claims remain CONJECTURE.")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
