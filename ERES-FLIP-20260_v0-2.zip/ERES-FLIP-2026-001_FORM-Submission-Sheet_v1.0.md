# FORM Symposium — Submission Sheet
### *Resilience in Research: The Role of Open Science in the Arab World* (19–20 Oct 2026, online)

**Companion to:** ERES-FLIP-2026-001 v0.2 PROVISIONAL
**Prepared:** 2026-08-04 · **License:** CCAL v2.1 / CC BY 4.0

---

## Key dates & submission facts (from the FORM Call for Papers)

- **Submission deadline:** **31 August 2026** — submitted via the online form on the FORM Call-for-Papers page.
- Responses in early September; event 19–20 October 2026, online, free to attend, bilingual (Arabic/English).
- **Presentation:** 20-minute online presentation. **Preferred language:** English.
- **Form fields required:** presenter name, institutional affiliation, email, presentation title, a **300-word paper abstract**, and a **100-word professional biography**. (Keywords are not a form field but are supplied below for the deposited whitepaper.)
- Organiser contact: contact@forumforopenresearch.com (Knowledge E Foundation).

---

## Presentation title

**Primary:**
The Economic FLIP: ERES Axioms for Non-Extractive, Provenance-First Open Science under Human-Made Crisis

**Short alternate:**
The FLIP — Provenance-First Open Science for Resilience and Reconstruction

---

## Paper abstract (300-word field)

Open science is hardest, and most necessary, where research infrastructure is under human-made stress. This presentation offers a method built for that setting: a compact set of ERES (Empirical Realtime Education System) axioms that make a knowledge system resilient because it is provenance-first, non-extractive, and openly verifiable — and a worked composition of that method into long-horizon reconstruction.

The organizing move is the FLIP: denominating value and reserve in the *duration of proven coherence* rather than priced magnitude. Under it, worth is tuned, not mined; obligations are offset, not externalized — the axiom "No Unearned Resonance," where value exists only as discharge against a shared deficit; and outputs are reflected back to the community that produced them. Two further axioms carry the open-science load directly. Provenance-backs-not-fiat: a claim, currency, or authority is backed by earned, checkable record, never issued by decree. The Doctrine of Verifiable Claims: every statement is tagged DERIVED, CONSTRUCTED, or CONJECTURE, and the work abstains from asserting its own truth. All instruments ship as paired prose-and-runnable-code under an open CCAL/CC-BY license, removing the cost-of-knowledge barrier by construction.

I map each symposium theme — decoloniality and agency, resilience in higher-education infrastructure, autonomy, infrastructure reliability, preservation and access, cost of knowledge, and transparency in crisis — to a specific axiom and its demonstration, then offer, non-partisanly and as a proposal only, how the method could serve recovery and reconstruction under an absolute dignity rule.

I also present the framework's sharpest unsolved problem openly: a not-yet-rebuilt system has zero proven duration, so a duration-backed reserve is unsatisfiable at inception. Publishing that gap, rather than hiding it, is the open-science discipline the symposium asks for. The work is pre-canonical, self-assessed, and not peer-reviewed.

*(~300 words.)*

---

## Short description (~90 words, for the deposited whitepaper / RG share)

A methods contribution proposing a compact set of ERES axioms — No Unearned Resonance, provenance-backs-not-fiat, and the Doctrine of Verifiable Claims — for open science under human-made crisis. It introduces the FLIP (value denominated in proven coherence-duration, not extracted magnitude), maps each symposium theme to an axiom and its demonstration, and offers a non-partisan, dignity-governed reconstruction proposal. All outputs are openly licensed (CCAL/CC-BY) and ship as paired prose-and-code. The framework's sharpest open problem — the inception accrual gap — is published, not hidden. Pre-canonical, self-assessed, not peer-reviewed.

---

## Keywords (comma-delimited)

open science, research resilience, provenance, verifiable claims, non-extractive knowledge economy, open access, cost of knowledge, reproducibility, CARE Commons Attribution License, CC BY, decoloniality, autonomy, recovery and reconstruction, MENA, Arab world, ERES, Empirical Realtime Education System, No Unearned Resonance, Doctrine of Verifiable Claims, coherence-duration reserve, open licensing, human-made crisis, transparency, higher-education infrastructure, paired prose-and-code

---

## Professional biography (100-word field)

Joseph A. Sprute (ERES Maestro) is founder and director of the ERES Institute for New Age Cybernetics (established 2012, Bella Vista, Arkansas, USA), where he works as an independent researcher developing open, verifiable governance and knowledge instruments under a New Age Cybernetics framework. His current work formalizes each construct as paired prose-and-code released under open CARE Commons / CC-BY licenses, with every claim tagged by an explicit Doctrine of Verifiable Claims and stress-tested through multi-model ensemble review before any canonization. He is a U.S. Army veteran and a published author. ORCID: 0000-0001-9946-3221.

*(~95 words.)*

---

## Honest-status note (do NOT omit at submission)

This is a conceptual/methodological proposal. It reports **no empirical results**, is **not peer-reviewed**, and is **pre-canonical** (self-assessed at author-maximal "10-10 relativity," awaiting a ≥5-node ensemble validation pass). Present it as a framework and an open problem, not as validated findings. Re-verify any quantitative reconstruction figures against current independent assessments before use, and keep the dignity rule (ordnance clearance and human-remains recovery precede any material reuse) explicit.
