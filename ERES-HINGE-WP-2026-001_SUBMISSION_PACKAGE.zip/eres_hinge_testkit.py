#!/usr/bin/env python3
"""
eres_hinge_testkit.py  —  Structural test suite for ERES-HINGE-WP-2026-001
("The HINGE / The Missing Link").

Stdlib-only. This suite encodes the whitepaper's STRUCTURAL invariants as
executable checks. It tests internal logical consistency and Doctrine-of-
Verifiable-Claims (DVC) discipline ONLY. It does NOT test physics: nothing
here is an empirical result. Each structural rule is checked twice — the
canonical spec must PASS and a deliberately broken variant must be REJECTED
(confirm + falsify).

The four load-bearing SKIPs correspond to the paper's open experimental
items (Section 9). They are not failures; they stay SKIP until real
measurements close them, so the suite only turns fully green when the
physics has actually been demonstrated.

Usage:
    python3 eres_hinge_testkit.py         # run the suite
    python3 eres_hinge_testkit.py --demo  # worked example of the spec model
    python3 eres_hinge_testkit.py -v      # verbose per-test detail

Exit code 0 iff there are no FAILs (SKIPs are allowed and expected).
"""

import copy
import sys

TESTS_SPEC_VERSION = (0, 1, 0)  # tracks ERES-HINGE-WP-2026-001 v0.1

# --------------------------------------------------------------------------
# The spec model: the whitepaper's canonical structural claims, in data.
# --------------------------------------------------------------------------

SPEC = {
    "artifact_name": "HINGE",
    "aka": "The Missing Link",
    "retired_label": "SUGAR-SEAM",          # retired to avoid the collision below
    "sugar_acronym": "SUGAR",               # Sovereign Universal Glycan Architecture for Resilience (bio, NOT structural)
    "carbon_feedstock": "sugar-carbon",     # literal sucrose C6H12O6, the structural feedstock
    "material": "GSSG",                     # Green Solar-Sand Glass with Infused Graphene
    # Frequency bands (order-of-magnitude Hz); ordering is load-bearing.
    "bands": {
        "sound":   {"role": "block",    "f_hz": 1.0e3},
        "bonding": {"role": "localize", "f_hz": 1.0e6},
        "heat":    {"role": "pass",     "f_hz": 1.0e12},
    },
    # Three coupled loops, each required to be bi-directional (non-degenerative).
    "loops": {
        "carbon":   {"forward": "heal_y_to_x", "reverse": "replenish_x_to_y"},
        "thermal":  {"forward": "peltier_out",  "reverse": "seebeck_in"},
        "acoustic": {"forward": "block",         "reverse": "localize"},
    },
    "energy_path": ["seebeck_harvest", "batteries", "peltier_climate"],
    "seam": {"disposition": "permanent_solid_state", "repair": "re_fusion"},
    "peltier_role": "climate_and_assist",   # explicitly NOT the pyrolysis-activation igniter
    "scalular": {"status": "asserted", "falsifier": "replenishment_x_to_y@high_z"},
    "reflection": {
        "established_vs_conjecture": True,
        "falsifiers": ["band_separation", "acoustic_lattice_fusion", "replenishment_at_high_z"],
        "make_or_break": "coupon_phonon_transmission_and_thermal_spectrum",
        "conjectures": [
            "tri_band_in_real_gssg",
            "acoustic_graphene_lattice_fusion",
            "activation_temp_reached",
            "scalular_invariance",
        ],
    },
    "does_not_claim": [
        "built_hinge",
        "measured_healing",
        "demonstrated_fusion",
        "validated_invariance",
        "sugar_glycan_involved",
    ],
    # Empirical evidence the paper does NOT have (all False -> the SKIPs stay SKIP).
    "empirical": {
        "coupon_band_separation_measured": False,
        "acoustic_lattice_fusion_demonstrated": False,
        "activation_temp_reached_in_panel": False,
        "scalular_invariance_validated": False,
    },
}

# --------------------------------------------------------------------------
# Checkers (each returns True if the invariant holds for a given spec).
# --------------------------------------------------------------------------

def chk_naming_firewall(s):
    # The glycan acronym and the structural feedstock must be distinct tokens,
    # and the retired label must not be reused as the active artifact name.
    return (s["sugar_acronym"] != s["carbon_feedstock"]
            and s["artifact_name"] != s["retired_label"])

def chk_band_order(s):
    b = s["bands"]
    return b["sound"]["f_hz"] < b["bonding"]["f_hz"] < b["heat"]["f_hz"]

def chk_band_roles_distinct(s):
    roles = [b["role"] for b in s["bands"].values()]
    return sorted(roles) == ["block", "localize", "pass"]

def chk_loops_bidirectional(s):
    for lp in s["loops"].values():
        if not lp.get("forward") or not lp.get("reverse"):
            return False
    return True

def chk_energy_path(s):
    p = s["energy_path"]
    return (len(p) >= 3 and p[0] == "seebeck_harvest"
            and "batteries" in p and p[-1] == "peltier_climate")

def chk_seam_permanent(s):
    return (s["seam"]["disposition"] == "permanent_solid_state"
            and s["seam"]["repair"] == "re_fusion")

def chk_peltier_not_igniter(s):
    return s["peltier_role"] != "pyrolysis_igniter"

def chk_scalular_is_claim(s):
    # DVC: SCALULAR invariance may be asserted, never marked "proven"
    # unless the coupon result exists.
    if s["scalular"]["status"] == "proven":
        return s["empirical"]["scalular_invariance_validated"] is True
    return s["scalular"]["status"] == "asserted"

def chk_scalular_falsifier_located(s):
    f = s["scalular"]["falsifier"]
    return "replenishment" in f and "high_z" in f

def chk_reflection_complete(s):
    r = s["reflection"]
    return (r["established_vs_conjecture"] is True
            and len(r["falsifiers"]) >= 1
            and bool(r["make_or_break"])
            and len(r["conjectures"]) >= 4)

def chk_anti_fabrication(s):
    required = {"built_hinge", "measured_healing", "demonstrated_fusion",
                "validated_invariance", "sugar_glycan_involved"}
    return required.issubset(set(s["does_not_claim"]))

# --------------------------------------------------------------------------
# Test registry.  Structural tests: (id, section, checker, breaker).
# The breaker mutates a copy so the SAME checker must reject it.
# --------------------------------------------------------------------------

def _break(mut):
    s = copy.deepcopy(SPEC)
    mut(s)
    return s

def b_naming(s):        s["carbon_feedstock"] = s["sugar_acronym"]
def b_band_order(s):    s["bands"]["bonding"]["f_hz"] = s["bands"]["heat"]["f_hz"]
def b_roles(s):         s["bands"]["heat"]["role"] = "block"
def b_loops(s):         s["loops"]["carbon"]["reverse"] = ""
def b_energy(s):        s["energy_path"] = ["seebeck_harvest", "peltier_climate"]
def b_seam(s):          s["seam"]["disposition"] = "reopenable_mechanical"
def b_peltier(s):       s["peltier_role"] = "pyrolysis_igniter"
def b_scalular(s):      s["scalular"]["status"] = "proven"
def b_falsifier(s):     s["scalular"]["falsifier"] = "healing_leg@low_z"
def b_reflection(s):    s["reflection"]["falsifiers"] = []
def b_antifab(s):       s["does_not_claim"].remove("demonstrated_fusion")

STRUCTURAL = [
    ("t01_naming_firewall",        "§2",  chk_naming_firewall,          b_naming,
     "HINGE supersedes SUGAR-SEAM; glycan SUGAR != structural sugar-carbon"),
    ("t02_band_order",             "§4.4/§6", chk_band_order,           b_band_order,
     "frequency order sound < bonding < heat (why tri-band is non-contradictory)"),
    ("t03_band_roles_distinct",    "§4.4", chk_band_roles_distinct,     b_roles,
     "one band each: block / localize / pass"),
    ("t04_loops_bidirectional",    "§3/§4.6", chk_loops_bidirectional,  b_loops,
     "carbon/thermal/acoustic loops each bi-directional (non-degenerative)"),
    ("t05_energy_path_closed",     "§4.5", chk_energy_path,             b_energy,
     "Seebeck -> batteries -> Peltier climate (closed thermal loop)"),
    ("t06_seam_permanent",         "§4.1", chk_seam_permanent,          b_seam,
     "fold-seam -> permanent solid-state; repair = re-fusion, not re-entry"),
    ("t07_peltier_not_igniter",    "§4.5/§9", chk_peltier_not_igniter,  b_peltier,
     "Peltier is climate/assist, NOT the pyrolysis-activation igniter"),
    ("t08_scalular_is_claim",      "§3/§9", chk_scalular_is_claim,      b_scalular,
     "SCALULAR invariance asserted, never 'proven' without the coupon result"),
    ("t09_scalular_falsifier",     "§7/§9", chk_scalular_falsifier_located, b_falsifier,
     "predicted break = replenishment (x->y) leg at high z"),
    ("t10_reflection_complete",    "§9",  chk_reflection_complete,      b_reflection,
     "established-vs-conjecture split + falsifiers + make-or-break present"),
    ("t11_anti_fabrication",       "§9.5", chk_anti_fabrication,        b_antifab,
     "does not claim built/measured/demonstrated/validated/glycan"),
]

# Load-bearing SKIPs: open empirical items. Each returns SKIP until its
# empirical flag is True (i.e., until a real experiment closes it).
SKIPS = [
    ("s12_tri_band_in_real_gssg",     "§9.2(1)/§10 Phase 0",
     "coupon_band_separation_measured",
     "measure a quasiperiodic GSSG coupon's phonon transmission + thermal spectrum"),
    ("s13_acoustic_lattice_fusion",   "§9.2(2)/§10 Phase 1",
     "acoustic_lattice_fusion_demonstrated",
     "show localized mid-band acoustic energy bonds a graphene lattice"),
    ("s14_activation_temp_reached",   "§9.2(3)/§10 Phase 2",
     "activation_temp_reached_in_panel",
     "show crack-tip / Peltier / resonance reaches transition-zone activation temp"),
    ("s15_scalular_invariance",       "§9.2(4)/§10 Phase 4+",
     "scalular_invariance_validated",
     "show x-y coupling holds across z, incl. high-z replenishment closure"),
]

# --------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------

def run(verbose=False):
    results = []  # (id, status, section, note)

    for tid, sec, checker, breaker, note in STRUCTURAL:
        try:
            confirm = checker(SPEC) is True
            falsify = checker(_break(breaker)) is False
            status = "PASS" if (confirm and falsify) else "FAIL"
            detail = note if status == "PASS" else (
                f"{note}  [confirm={confirm} falsify={falsify}]")
        except Exception as exc:  # a checker error is a FAIL, not a crash
            status, detail = "FAIL", f"{note}  [exception: {exc!r}]"
        results.append((tid, status, sec, detail))

    for tid, sec, flag, note in SKIPS:
        closed = SPEC["empirical"].get(flag, False) is True
        status = "PASS" if closed else "SKIP"
        results.append((tid, status, sec, note))

    width = max(len(r[0]) for r in results)
    print("=" * 72)
    print("ERES-HINGE-WP-2026-001  structural test suite  "
          f"(spec v{'.'.join(map(str, TESTS_SPEC_VERSION))})")
    print("STRUCTURAL / DVC checks only — NOT an empirical validation.")
    print("=" * 72)
    for tid, status, sec, detail in results:
        line = f"[{status:4}] {tid:<{width}}  {sec}"
        if verbose or status != "PASS":
            line += f"\n         {detail}"
        print(line)

    p = sum(1 for r in results if r[1] == "PASS")
    f = sum(1 for r in results if r[1] == "FAIL")
    k = sum(1 for r in results if r[1] == "SKIP")
    print("-" * 72)
    print(f"{p} PASS / {f} FAIL / {k} SKIP   (of {len(results)})")
    print("SKIPs are load-bearing: they map to the paper's open experiments")
    print("and go green only when the physics is actually demonstrated.")
    print("=" * 72)
    return 0 if f == 0 else 1


def demo():
    print("ERES-HINGE spec model — worked example\n")
    print("Naming firewall:")
    print(f"  artifact     = {SPEC['artifact_name']} (aka {SPEC['aka']})")
    print(f"  retired      = {SPEC['retired_label']}")
    print(f"  SUGAR (bio)  = glycan architecture, NOT structural")
    print(f"  feedstock    = {SPEC['carbon_feedstock']} (literal sucrose)")
    print(f"  material     = {SPEC['material']}\n")
    print("Tri-band phonon model (low blocks, mid localizes, high passes):")
    for name in ("sound", "bonding", "heat"):
        band = SPEC["bands"][name]
        print(f"  {name:8} ~{band['f_hz']:.0e} Hz  ->  {band['role']}")
    print("\nThree bi-directional loops:")
    for name, lp in SPEC["loops"].items():
        print(f"  {name:9} {lp['forward']:16} <->  {lp['reverse']}")
    print(f"\nEnergy path: {'  ->  '.join(SPEC['energy_path'])}")
    print(f"Seam: {SPEC['seam']['disposition']} (repair = {SPEC['seam']['repair']})")
    print(f"SCALULAR: {SPEC['scalular']['status']}; "
          f"falsifier = {SPEC['scalular']['falsifier']}")
    print(f"Make-or-break: {SPEC['reflection']['make_or_break']}")
    return 0


if __name__ == "__main__":
    args = set(sys.argv[1:])
    if "--demo" in args:
        sys.exit(demo())
    sys.exit(run(verbose=("-v" in args or "--verbose" in args)))
