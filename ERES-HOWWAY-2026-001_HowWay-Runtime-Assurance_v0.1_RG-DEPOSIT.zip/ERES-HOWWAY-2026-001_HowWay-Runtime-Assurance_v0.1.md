# HowWay = ERES @: Runtime Assurance for AI Governance
*Answering the six control-assurance questions inside the workflow, not six weeks after it*

**ERES-HOWWAY-2026-001** | v0.1 PROPOSED - pre-canonical, NOT MIEVM-rated, ID pending JAS confirmation

## Abstract

Assessment-time governance asks whether a control existed on the day the assessor looked. Runtime governance asks whether the control is operating now, can be seen operating, produces its own evidence, notices when something changes, can stop or escalate an action, and does all of this inside the workflow. This paper defines HowWay, the Method column of the PlayNAC TABLE (beside IT and MyWay/Purpose), as the ERES layer that answers those six questions, and reads '@' as 'ERES at the point of action'. For each question it names the ERES mechanism (SOMT, CPROV, BERA, RHC, PoR, RCR, RAEC, the Independence Gate, and the CHALLENGE/RESPONSE columns), states what is specified, what is demonstrated, and what is open. The claim is deliberately bounded: at v0.1 the six answers are design properties with a specification-level harness (ERES-ARH-2026-001) and are not evidence of operation in a live deployment. The unresolved items are listed as H1-H6; H5, an external red-team of a running system, is the one gate that cannot be simulated.

## 1. The gap: assessment-time versus runtime assurance

A conventional control is evidenced by a sample: policies, screenshots, tickets, an interview. Evidence is collected after the fact, so a change made the week after sampling is invisible until the next assessment. The delay between a control failing and anyone knowing is the exposure.

The six questions below are the tests that close that gap. Each one asks for a property of the control itself rather than a document about it.

## 2. HowWay defined

In PlayNAC the right-hand project columns are organised under three headings: IT, MyWay (Purpose) and HowWay (Method). HowWay is where a stated purpose becomes an executable, observable, contestable procedure.

'ERES @' is read here as ERES at the point of action: the governance mechanism sits in the path of the action rather than beside it. This is an interpretation of the notation and is flagged for author confirmation.

## 3. The six questions mapped to ERES mechanisms

| Question | ERES mechanism | Evidence produced | Status |
|---|---|---|---|
| 1. Can you prove the control is actually operating? | SOMT append-only provenance log; CPROV provenance chain. | Every governance act is a logged, immutable entry; the log is the proof of operation. | Specified; spec-level harness. |
| 2. Can I see the telemetry? | BERA health signal (the organisational ECG); TALONICS Row 18 / RAW measurement layer. | A continuous readout of governance health per user-group, visible to the group. | Specified; thresholds asserted. |
| 3. Can I automatically collect the evidence? | SOMT writes evidence as a byproduct of acting; package manifests carry sha256 per artifact. | No separate collection step: the evidence exists when the action completes. | Demonstrated at package level; live pipeline not built. |
| 4. Can the control detect when something changes? | RHC detects drift beyond 1 sigma of baseline purpose; Independence Gate (CDFE n_eff) detects correlated or sybil nodes. | A drift event and an independence score, both logged. | Gate computes in the ARH harness; RHC thresholds asserted. |
| 5. Can it stop or escalate an action at runtime? | PoR = A x R x P x F (any zero blocks); RCR (no execution without live-state authorisation); RAEC (four autonomy tiers); Paineology remediation (isolate, downgrade L3 to L1, audit). | A block, escalation or downgrade record tied to the action that triggered it. | Spec-level; completeness OPEN (H1). |
| 6. Can governance happen inside the workflow instead of six weeks later? | PlayNAC TABLE CHALLENGE/RESPONSE columns; ratification gate: mean MIEVM >== 8.5 AND n_eff >== tau. | Contestation and ratification occur as steps of the workflow, so there is no post-hoc assessment queue. | Architectural; latency unmeasured (H4). |

## 4. The in-workflow loop

1. Act: an agent or user-group proposes an action inside the workflow.
2. Gate: PoR scores Alignment, Resonance, Proportionality and Finality-Risk; RCR requires live-state authorisation. Any zero blocks.
3. Log: SOMT records the proposal, the score and the decision before execution.
4. Observe: BERA updates the health signal; RHC compares against baseline purpose.
5. Challenge: the CHALLENGE/RESPONSE columns let a user-group contest the decision in-line.
6. Escalate or remediate: on breach, isolate and downgrade (L3 to L1), audit, update empirically. Humans remain the final constitutional layer; execution can be delegated, responsibility cannot.

## 5. What the assessor receives

What an assessor receives under HowWay is a queryable log plus a live signal, rather than a sample. Because the log is written by the act of governing, the evidence population is complete by construction for every action that passed through the gate. That completeness claim is bounded: it covers gated actions only, and an action that bypasses the gate is invisible to the log. Bypass resistance is the content of ARH threat T4 (PoR gate-evasion) and remains open (H1).

## 6. Boundary

- Green means SPECIFICATION against a MODELED adversary. It does not mean a runtime, and it is not proof against a live or novel attacker.
- This paper exposes no is_safe, is_secure or is_compliant verdict, and it does not claim any framework-specific certification or compliance outcome. 'Prevents malicious activity' is, at v0.1, a design property with a named threat model, not an operational guarantee.
- The six-question mapping is an internal specification of where each answer lives. It has not been reviewed by an external assessor.

## 7. OPEN items

- **H1.** PoR completeness: no proof that A x R x P x F blocks all malicious actions (ARH O1). Bypass of the gate is the central risk.
- **H2.** Telemetry validity: BERA and RHC thresholds are asserted, not derived; the signal has not been shown to track real governance failures.
- **H3.** Log integrity in deployment: SOMT tamper-evidence and external anchoring are specified but not realised outside the harness.
- **H4.** Inline cost: latency and throughput overhead of gating every action is unmeasured, so 'inside the workflow' is not yet shown to be viable at load.
- **H5.** External red-team of a running system (ARH O5): not simulable; the sole gate Claude cannot stand in for.
- **H6.** Regulatory fit: telemetry design must clear the collisions identified for RRH (EU AI Act, GDPR, eIDAS). The 'not surveillance' framing of BERA is a claim to be tested there, not assumed.

## 8. Suggested next step

- Two-round Delphi MIEVM on v0.1 as an adversarial-completeness probe of the mapping (did the six questions miss an assurance property), run blind-first with the Independence Gate applied to the round itself; MIEVM is not the promoting gate for H1-H6.
- Close H2 and H4 with a measured prototype; hold H5 as the empirical gate.

Author: Joseph Allen Sprute, ERES Institute for New Age Cybernetics (ORCID 0000-0001-9946-3221). License: CC BY 4.0 / CCAL v2.1.
