#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eres_gaia_benchmarks_testkit.py  (v0.2)
=======================================
Structural validation suite for:

    ERES-PELLIS-GAIA-BENCHMARKS-2026-001 v0.2
    "GAIA Benchmarks - A Spectral-Actuarial Standard for Investor-Worker
     Standing under UBIMIA-Meritcoin (GraceChain Version)"

WHAT THIS TESTS (and what it does NOT)
--------------------------------------
This kit tests the *structural rules* of the whitepaper: the reference
implementations of its definitions behave as the document says, and each
rule has a matching FALSIFIER that would fail if the rule were violated.

It tests logic and internal consistency ONLY. It proves NOTHING empirical.
The four load-bearing empirical claims of the WP (WP section 7) are encoded
as SKIP tests: they go green only when a real operator L(t) is instantiated
and its hazard is read off computed eigenvalues, not asserted. Until then,
a passing run means "the specification is coherent," never "the governance
model is validated."

Grade discipline carried from the WP:
  * Pellis-math  <-> actuarial-math  correspondence : STRUCTURAL (tested here)
  * NAC-governance application                       : ANALOGICAL (NOT tested here;
                                                        it is a design hypothesis)

CHANGES IN v0.2 (per MIEVM Round 1 review):
  * Full return type hints on every reference function (mypy-strict clean).
  * New L(t) operator INTERFACE: build_L_operator() (honestly stubbed,
    raises NotImplementedError with the exact contract) and
    hazard_from_spectrum() (the eigenvalue -> hazard readout formula).
  * New structural test T14: the eigenvalue->hazard readout is correct on a
    synthetic spectrum (confirm+falsify).
  * New structural test T15: build_L_operator is honestly stubbed - it must
    RAISE, never silently return fabricated data (an empirical-leak guard).
  * S01-S04 now reference the real build_L_operator contract; still SKIP.

Stdlib only. No third-party imports. Python 3.8+.
Run:  python3 eres_gaia_benchmarks_testkit.py
Exit: 0 if no FAIL and no REGRESSION (SKIPs are allowed); 1 otherwise.
"""

from __future__ import annotations

import hashlib
import math
import platform
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional, Sequence, Tuple

SEED: int = 20260801
VERSION: str = "0.2"
INSTRUMENT: str = "ERES-PELLIS-GAIA-BENCHMARKS-2026-001"
EPS: float = 1e-12
PHI_DEFAULT: float = (1.0 + math.sqrt(5.0)) / 2.0  # golden ratio; configurable weighting base


# ---------------------------------------------------------------------------
# Reference implementation of the WP's definitions (Layer: actuarial spine)
# All equation numbers refer to Pellis (2026), the cited source manuscript.
# ---------------------------------------------------------------------------

def weighted_instability(gammas: Sequence[float], weights: Sequence[float], phi: float) -> float:
    """Pellis weighted spectral instability functional (eq. 1907):
       Lambda_phi = sum_n  w_n * phi^(-n) * |gamma_n|.
    Governance reading: instantaneous rate of drift off baseline purpose."""
    if phi <= 0:
        raise ValueError("phi must be > 0")
    if len(gammas) != len(weights):
        raise ValueError("gammas and weights must align")
    total: float = 0.0
    for n, (g, w) in enumerate(zip(gammas, weights), start=1):
        total += w * (phi ** (-n)) * abs(g)
    return total


def cumulative_hazard(lam_series: Sequence[float], dt: float) -> float:
    """Pellis cumulative spectral hazard functional (eqs. 1975, 1998):
       H_phi(t) = integral_0^t Lambda_phi(tau) dtau.  Trapezoidal quadrature.
    Actuarial reading: cumulative hazard H(t).
    NOTE: dt is an explicit parameter; structural tests use dt=1.0 for clarity,
    but the quadrature is general in dt."""
    if dt <= 0:
        raise ValueError("dt must be > 0")
    if not lam_series:
        return 0.0
    if any(x < 0 for x in lam_series):
        # Lambda_phi = sum of non-negative terms; a negative value is ill-formed.
        raise ValueError("instability functional must be non-negative")
    acc: float = 0.0
    for a, b in zip(lam_series[:-1], lam_series[1:]):
        acc += 0.5 * (a + b) * dt
    return acc


def survival(H: float) -> float:
    """Pellis reliability functional (eqs. 1999-2000):  R_phi = exp(-H_phi).
    Actuarial reading: survival function S(t) = exp(-cumulative hazard)."""
    return math.exp(-H)


def hazard_density(lam: float, gamma_c: float) -> float:
    """Pellis normalized spectral hazard density (eq. 1979): h_phi = Lambda_phi / Gamma_c.
    Three-band structure (eqs. 1980-1982):  <1 sub-critical, =1 critical, >1 super-critical."""
    if gamma_c <= 0:
        raise ValueError("gamma_c (critical threshold) must be > 0")
    return lam / gamma_c


def reserve_margin(lam: float, gamma_c: float) -> Tuple[float, float]:
    """Pellis reliability margin (eq. 1906): Delta_phi = Gamma_c - Lambda_phi,
       normalized e_phi = 1 - Lambda_phi/Gamma_c, with e_phi = 0 at collapse (eq. 1911).
    Governance reading: remaining earned reserve (Merit buffer)."""
    delta: float = gamma_c - lam
    e_norm: float = 1.0 - lam / gamma_c
    return delta, e_norm


def is_catastrophic(gamma_max: float, gamma_c: float, C_phi: float, C_c: float) -> bool:
    """Pellis irreversible collapse criterion (eq. 943):
       (gamma_max >= gamma_c) AND (C_phi >= C_c).  Strictly conjunctive."""
    return (gamma_max >= gamma_c) and (C_phi >= C_c)


# ---------------------------------------------------------------------------
# L(t) operator INTERFACE (the empirical companion contract)
# ---------------------------------------------------------------------------
# hazard_from_spectrum() is the READOUT: given a computed complex spectrum it
# returns h_phi by Pellis's own definitions -- this is STRUCTURAL and tested.
# build_L_operator() is the CONSTRUCTOR: it must be fed real PlayNAC couplings.
# It is honestly stubbed so no fabricated spectrum can leak into the tests.

def hazard_from_spectrum(eigenvalues: Sequence[complex],
                         gamma_c: float,
                         weights: Optional[Sequence[float]] = None,
                         phi: float = PHI_DEFAULT) -> float:
    """Read h_phi off a complex spectrum. Pellis eq. 1977: lambda_n = E_n - i*gamma_n,
    so the instability driver is gamma_n = |Im(lambda_n)|. Then Lambda_phi (eq. 1907)
    and h_phi = Lambda_phi / Gamma_c (eq. 1979). This is the exact bridge the empirical
    L(t) will use; here it is exercised only on synthetic spectra (no empirical claim)."""
    gammas: List[float] = [abs(z.imag) for z in eigenvalues]
    if weights is None:
        weights = [1.0] * len(gammas)
    lam: float = weighted_instability(gammas, weights, phi)
    return hazard_density(lam, gamma_c)


def build_L_operator(layers: int = 18,
                     earnedpath_coupling: Optional[object] = None,
                     gerp_weights: Optional[object] = None) -> object:
    """CONTRACT for the L(t) operator that would move the application off ANALOGICAL:

      * a  layers x layers  non-Hermitian matrix (default 18 PlayNAC layers as nodes),
      * EarnedPath as the DIRECTIONAL (non-symmetric) coupling between nodes,
        [MIEVM-workup CANDIDATE decomposition, not yet ratified: EP = CPM x WBS + PERT],
      * edge weights = GERP  C = R x P / M,
      * whose complex eigenvalues feed hazard_from_spectrum() to yield h_phi.

    Deliberately NOT implemented: instantiating it requires real PlayNAC telemetry.
    Raising here is a feature -- it guarantees S01-S04 cannot be satisfied by
    fabricated data (see T15)."""
    raise NotImplementedError(
        "L(t) requires real PlayNAC couplings and GERP weights; "
        "see WP section 7 and the L(t) interface section. Do not stub with synthetic data."
    )


# ---------------------------------------------------------------------------
# Reference implementation of the WP's governance / economic rules
# (Layer: NAC application -- ANALOGICAL; tested here only for internal coherence)
# ---------------------------------------------------------------------------

def mint_meritcoin(offset: float) -> float:
    """RROI axiom A0 'No Unearned Resonance': measured value exists only as
    discharge against a shared deficit. Zero offset mints zero (non-accrual guardrail)."""
    if offset < 0:
        raise ValueError("offset (discharged deficit) cannot be negative")
    return offset  # resonance-built, not pocketed: mint == discharge, 1:1


@dataclass
class Account:
    """UBIMIA investor-worker account.
       N = Universal Basic Income floor (unconditional; NEVER scored by the timeline).
       M = Merit-Incentives Account (Meritcoin reserve; scored by the hazard timeline)."""
    N: float          # survival floor
    M: float          # merit reserve
    _N0: float = field(init=False)

    def __post_init__(self) -> None:
        if self.N < 0 or self.M < 0:
            raise ValueError("N and M must be non-negative")
        self._N0 = self.N  # frozen witness of the floor

    def apply_decrement(self, amount: float) -> None:
        """A decrement event (a 'claim') writes down EARNED merit only.
        The floor N is not in the collapse spectrum and is never touched."""
        if amount < 0:
            raise ValueError("decrement must be non-negative")
        self.M = max(0.0, self.M - amount)
        # N deliberately untouched -- the humane invariant.

    def floor_intact(self) -> bool:
        return abs(self.N - self._N0) < EPS


class _Veiled:
    """VEILED-C credit sentinel. Under crypto-stack rule F3 a credit-bearing
    magnitude returns VEILED: ratable, but never coerced to a public number."""
    __slots__ = ()

    def __repr__(self) -> str:
        return "VEILED"

    def __float__(self) -> float:
        # Arithmetic substitution of an earned magnitude is a spec violation.
        raise TypeError("VEILED-C magnitude may not be coerced to a number")

    __int__ = __float__


VEILED: _Veiled = _Veiled()


def credit_under_F3(_earned_magnitude: float) -> _Veiled:
    """Return the VEILED sentinel regardless of the internal earned magnitude."""
    return VEILED


def mievm_tier(nodes: int, mean: float, epistemic: str, state: str) -> str:
    """Tier gate combining the epistemic axis with the MIEVM ensemble gate and
    fiduciary state. Rules from WP section 4:
      BEST  : epistemic == DERIVED  AND nodes >= 5 AND mean >= 9.0 AND state == EARNED
      SOUND : epistemic in {DERIVED, DESIGN-PRINCIPLE} AND nodes >= 4 AND mean >= 8.5
      GOOD  : otherwise, if provisioned (a positive reserve)
      BELOW : not certifiable
    Cap rule: 'no claim is DERIVED so none is BEST' -- an ANALOGICAL/CANDIDATE
    claim can never reach BEST no matter how high the MIEVM mean."""
    epistemic = epistemic.upper()
    state = state.upper()
    if epistemic == "DERIVED" and nodes >= 5 and mean >= 9.0 and state == "EARNED":
        return "BEST"
    if epistemic in ("DERIVED", "DESIGN-PRINCIPLE") and nodes >= 4 and mean >= 8.5:
        return "SOUND"
    if epistemic in ("DERIVED", "DESIGN-PRINCIPLE", "ANALOGICAL", "CANDIDATE"):
        return "GOOD"
    return "BELOW"


def por_admissible(A: float, R: float, P: float, F: float) -> bool:
    """PoR admissibility (EAAP): A x R x P x F conjunctive gate; any zero factor
    blocks. F = Finality-Risk factor -- as risk-margin D_f -> 0, F -> 0 and blocks
    irreversible actions near a boundary that cannot be uncrossed."""
    return (A > 0) and (R > 0) and (P > 0) and (F > 0)


def finality_factor(risk_margin: float, floor: float = 0.05) -> float:
    """F collapses toward 0 as the risk margin to the irreversible boundary shrinks.
    Simplified reference form: demonstrates the principle (F->0 near boundary), not a
    production risk model."""
    if risk_margin <= 0:
        return 0.0
    return min(1.0, max(0.0, risk_margin) / max(floor, EPS)) * (1.0 if risk_margin > floor else 0.0)


# ---------------------------------------------------------------------------
# Test harness
# ---------------------------------------------------------------------------

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
Result = Tuple[str, str]  # (status, detail)


def _ok(detail: str = "") -> Result:
    return (PASS, detail)


def _no(detail: str) -> Result:
    return (FAIL, detail)


def _skip(detail: str) -> Result:
    return (SKIP, detail)


# ---- STRUCTURAL TESTS (confirm + falsify each rule) ------------------------

def t01_survival_identity() -> Result:
    """R_phi = exp(-H_phi) is the actuarial survival identity (STRUCTURAL)."""
    lam = [0.2, 0.3, 0.25, 0.4]
    H = cumulative_hazard(lam, dt=1.0)
    R = survival(H)
    if abs(R - math.exp(-H)) > 1e-9:                       # confirm
        return _no("survival != exp(-H)")
    if abs((1.0 - H) - R) < 1e-9 and H > 0.1:              # falsify: linear model must differ
        return _no("survival collapsed to a linear 1-H model")
    return _ok(f"R=exp(-H) held; H={H:.4f}, R={R:.4f}")


def t02_survival_monotone() -> Result:
    """With Lambda_phi >= 0, cumulative hazard is non-decreasing and survival non-increasing."""
    lam = [0.1, 0.15, 0.2, 0.35, 0.5]
    Rs = [survival(cumulative_hazard(lam[:k], dt=1.0)) for k in range(1, len(lam) + 1)]
    if any(b - a > 1e-12 for a, b in zip(Rs[:-1], Rs[1:])):     # confirm non-increasing
        return _no(f"survival increased: {Rs}")
    try:                                                        # falsify: negative hazard rejected
        cumulative_hazard([0.1, -0.2, 0.1], dt=1.0)
        return _no("negative instability functional was accepted")
    except ValueError:
        pass
    return _ok("survival monotone non-increasing; ill-formed negative hazard rejected")


def t03_hazard_three_band() -> Result:
    """h_phi = Lambda/Gamma_c gives the exact three-band structure at h=1."""
    gc = 1.0
    below = hazard_density(0.5, gc)
    crit = hazard_density(1.0, gc)
    above = hazard_density(1.7, gc)
    if not (below < 1.0 and abs(crit - 1.0) < EPS and above > 1.0):   # confirm bands
        return _no(f"bands wrong: {below},{crit},{above}")
    if not (below < crit < above):                                   # falsify: ordering must hold
        return _no("band ordering violated")
    return _ok("h<1 / h=1 / h>1 bands exact and ordered")


def t04_reserve_zero_at_collapse() -> Result:
    """Normalized reserve e_phi = 0 exactly at Lambda = Gamma_c; negative beyond (uncertifiable)."""
    gc = 2.0
    _, e_boundary = reserve_margin(2.0, gc)
    _, e_below = reserve_margin(1.0, gc)
    _, e_beyond = reserve_margin(2.5, gc)
    if abs(e_boundary) > EPS:                                  # confirm zero at boundary
        return _no(f"e_phi != 0 at collapse: {e_boundary}")
    if not (e_below > 0 > e_beyond):                           # falsify: sign structure
        return _no("reserve sign structure wrong")
    return _ok("reserve zero at collapse; positive below, negative beyond")


def t05_collapse_conjunctive() -> Result:
    """Catastrophic transition requires BOTH gamma_max>=gamma_c AND C_phi>=C_c."""
    gc, cc = 1.0, 1.0
    both = is_catastrophic(1.2, gc, 1.3, cc)
    only_g = is_catastrophic(1.2, gc, 0.5, cc)
    only_c = is_catastrophic(0.5, gc, 1.3, cc)
    neither = is_catastrophic(0.4, gc, 0.4, cc)
    if not both:                                              # confirm conjunction fires
        return _no("conjunction failed to trigger on both")
    if only_g or only_c or neither:                           # falsify: OR-logic would leak here
        return _no("collapse triggered on a single condition (OR-logic leak)")
    return _ok("collapse strictly conjunctive")


def t06_humane_invariant_floor() -> Result:
    """The load-bearing invariant: a full collapse trajectory decrements M to 0
    but NEVER touches the UBIMIA floor N."""
    acc = Account(N=1000.0, M=300.0)
    for _ in range(50):                                       # drive merit to the floor
        acc.apply_decrement(25.0)
    if not acc.floor_intact():                                # confirm N untouched
        return _no("floor N was altered by the timeline")
    if acc.M > EPS:                                           # confirm merit consumed
        return _no("merit reserve did not decrement to zero")
    # falsify: there must exist NO public method that reduces N
    if any(callable(getattr(acc, m, None)) and "floor" in m.lower() and "decrement" in m.lower()
           for m in dir(acc)):
        return _no("a floor-decrement path exists")
    return _ok("N floor intact through full collapse; only M scored")


def t07_a0_mint_rule() -> Result:
    """A0 'No Unearned Resonance': zero offset mints zero; positive offset mints positive."""
    if mint_meritcoin(0.0) != 0.0:                            # confirm zero-offset -> zero
        return _no("minted on zero offset")
    if mint_meritcoin(3.0) <= 0.0:                            # confirm positive offset mints
        return _no("failed to mint on positive offset")
    try:                                                      # falsify: negative offset rejected
        mint_meritcoin(-1.0)
        return _no("negative offset accepted")
    except ValueError:
        pass
    return _ok("mint proportional to discharged offset; zero-offset mints zero")


def t08_non_accrual() -> Result:
    """Non-accrual guardrail: total minted equals total offset discharged (resonance-built)."""
    offsets = [1.0, 2.5, 0.0, 4.0, 0.0]
    minted = sum(mint_meritcoin(o) for o in offsets)
    if abs(minted - sum(offsets)) > EPS:                      # confirm 1:1, no free accrual
        return _no("accrual diverged from discharged offset")
    # falsify: minting the count of actions (not their discharge) would over-credit
    if abs(minted - len(offsets)) < EPS and len(offsets) != sum(offsets):
        return _no("credited per-action rather than per-discharge")
    return _ok("credit == discharged offset; no free accrual")


def t09_best_cap_rule() -> Result:
    """'No claim is DERIVED so none is BEST' -- an ANALOGICAL claim cannot reach BEST."""
    tier = mievm_tier(nodes=8, mean=9.9, epistemic="ANALOGICAL", state="EARNED")
    if tier == "BEST":                                        # falsify: high MIEVM must not lift ANALOGICAL
        return _no("ANALOGICAL claim reached BEST")
    derived = mievm_tier(nodes=5, mean=9.0, epistemic="DERIVED", state="EARNED")
    if derived != "BEST":                                     # confirm the gate is reachable when earned
        return _no("DERIVED+gate did not reach BEST")
    return _ok(f"ANALOGICAL capped at {tier}; DERIVED reaches BEST")


def t10_mievm_gate() -> Result:
    """MIEVM node-count / mean / fiduciary-state gates for SOUND and BEST."""
    sound = mievm_tier(nodes=4, mean=8.6, epistemic="DESIGN-PRINCIPLE", state="VEILED")
    if sound != "SOUND":                                      # confirm SOUND gate
        return _no(f"expected SOUND, got {sound}")
    leak_nodes = mievm_tier(nodes=4, mean=8.6, epistemic="DERIVED", state="EARNED")
    if leak_nodes == "BEST":                                  # falsify: 4 nodes must not reach BEST
        return _no("BEST reached with only 4 nodes")
    leak_mean = mievm_tier(nodes=5, mean=8.9, epistemic="DERIVED", state="EARNED")
    if leak_mean == "BEST":                                   # falsify: mean<9.0 must not reach BEST
        return _no("BEST reached with mean < 9.0")
    return _ok("SOUND@(>=4,>=8.5); BEST blocked at 4 nodes and at mean<9.0")


def t11_veiled_c() -> Result:
    """VEILED-C: credit returns a VEILED sentinel that refuses numeric coercion."""
    c = credit_under_F3(123.45)
    if repr(c) != "VEILED":                                   # confirm sentinel
        return _no("credit was not VEILED")
    try:                                                      # falsify: coercion must fail
        float(c)
        return _no("VEILED credit was coerced to a number")
    except TypeError:
        pass
    return _ok("credit VEILED; numeric coercion blocked")


def t12_por_finality_gate() -> Result:
    """PoR A x R x P x F conjunctive; F -> 0 near the irreversible boundary blocks action."""
    far = por_admissible(1, 1, 1, finality_factor(risk_margin=0.5))
    near = por_admissible(1, 1, 1, finality_factor(risk_margin=0.0))
    zero_factor = por_admissible(1, 0, 1, 1)                  # any zero blocks
    if not far:                                               # confirm admissible away from boundary
        return _no("blocked action far from boundary")
    if near:                                                  # falsify: must block at the boundary
        return _no("irreversible action admitted at the boundary")
    if zero_factor:                                           # falsify: zero factor must block
        return _no("zero PoR factor did not block")
    return _ok("admissible far, blocked at boundary, any-zero blocks")


def t13_structural_not_empirical() -> Result:
    """Distinguishability rule: the certifiable boundary is the STRUCTURAL h=1
    (Pellis), scale-free in Gamma_c -- not a hardcoded ratified governance magnitude."""
    for gc in (0.3, 1.0, 42.0, 1e4):
        if abs(hazard_density(gc, gc) - 1.0) > EPS:
            return _no(f"boundary not scale-free at Gamma_c={gc}")
    if abs(hazard_density(0.5, 1.0) - hazard_density(0.5 * 42.0, 42.0)) > EPS:  # falsify
        return _no("classifier depends on absolute magnitude (empirical leak)")
    return _ok("boundary is structural (h=1), scale-free in Gamma_c")


def t14_spectrum_hazard_readout() -> Result:
    """NEW (v0.2): the eigenvalue -> hazard readout is correct on a synthetic spectrum.
    STRUCTURAL: exercises the exact bridge the empirical L(t) will use, on made-up
    eigenvalues (no empirical claim). gamma_n = |Im(lambda_n)|; h = Lambda/Gamma_c."""
    # lambda_n = E_n - i*gamma_n ; choose Im parts 0.3, 0.6, 0.9
    spectrum = [complex(1.0, -0.3), complex(0.5, -0.6), complex(-0.2, -0.9)]
    gc = 2.0
    w = [1.0, 1.0, 1.0]
    got = hazard_from_spectrum(spectrum, gc, weights=w, phi=PHI_DEFAULT)
    expected = weighted_instability([0.3, 0.6, 0.9], w, PHI_DEFAULT) / gc   # hand path
    if abs(got - expected) > 1e-12:                          # confirm readout matches definition
        return _no(f"readout {got} != definition {expected}")
    # falsify: reading the REAL parts instead of the imaginary parts must differ
    wrong = weighted_instability([1.0, 0.5, 0.2], w, PHI_DEFAULT) / gc
    if abs(got - wrong) < 1e-9:
        return _no("readout indistinguishable from a Re-part (wrong-axis) reading")
    return _ok(f"h read off Im(spectrum) correctly; h={got:.4f}")


def t15_lt_honestly_stubbed() -> Result:
    """NEW (v0.2): empirical-leak guard. build_L_operator must RAISE, never silently
    return fabricated data -- this is what keeps S01-S04 honestly SKIP."""
    try:
        build_L_operator(layers=18)
        return _no("build_L_operator returned data instead of raising (fabrication risk)")
    except NotImplementedError:
        pass
    except Exception as exc:                                  # any other error is still a fail
        return _no(f"build_L_operator raised the wrong error: {exc!r}")
    return _ok("L(t) constructor honestly stubbed; no synthetic spectrum can leak in")


# ---- LOAD-BEARING EMPIRICAL CLAIMS (SKIP until real operator instantiated) --

def _needs_real_lt(detail: str) -> Result:
    """All four empirical tests depend on a real L(t); confirm it is not yet available."""
    try:
        build_L_operator(layers=18)
        # If this ever returns, an operator exists -- the test author must wire real data.
        return _skip(detail + " [L(t) constructor present but data-wiring not implemented]")
    except NotImplementedError:
        return _skip(detail)


def s01_real_hazard_boundary() -> Result:
    return _needs_real_lt("needs real L(t): does governance reserve show a true h=1 boundary "
                          "(not a soft cost gradient)? WP section 7, claim 1.")


def s02_exceptional_point_cliff() -> Result:
    return _needs_real_lt("needs real L(t): is there a genuine kappa->inf governance cliff at "
                          "RECONCILE (irreversibility), not just rising salvage cost? WP 7, claim 2.")


def s03_mievm_maps_collapse() -> Result:
    return _needs_real_lt("needs correspondence data: does MIEVM ratification map onto the "
                          "collapse conjunction rather than merely resemble it? WP 7, claim 3.")


def s04_absorption_ratio() -> Result:
    return _needs_real_lt("needs real stress data: does Proof-of-Resonance tuning replenish fast "
                          "enough to hold h<1 under stress (absorption-ratio gate)? WP 7, claim 4.")


TESTS: List[Tuple[str, Callable[[], Result]]] = [
    ("T01 survival_identity (STRUCTURAL)", t01_survival_identity),
    ("T02 survival_monotone", t02_survival_monotone),
    ("T03 hazard_three_band", t03_hazard_three_band),
    ("T04 reserve_zero_at_collapse", t04_reserve_zero_at_collapse),
    ("T05 collapse_conjunctive", t05_collapse_conjunctive),
    ("T06 humane_invariant_floor", t06_humane_invariant_floor),
    ("T07 a0_mint_rule", t07_a0_mint_rule),
    ("T08 non_accrual", t08_non_accrual),
    ("T09 best_cap_rule", t09_best_cap_rule),
    ("T10 mievm_gate", t10_mievm_gate),
    ("T11 veiled_c", t11_veiled_c),
    ("T12 por_finality_gate", t12_por_finality_gate),
    ("T13 structural_not_empirical", t13_structural_not_empirical),
    ("T14 spectrum_hazard_readout (STRUCTURAL, new)", t14_spectrum_hazard_readout),
    ("T15 lt_honestly_stubbed (leak-guard, new)", t15_lt_honestly_stubbed),
    ("S01 real_hazard_boundary (empirical)", s01_real_hazard_boundary),
    ("S02 exceptional_point_cliff (empirical)", s02_exceptional_point_cliff),
    ("S03 mievm_maps_collapse (empirical)", s03_mievm_maps_collapse),
    ("S04 absorption_ratio (empirical)", s04_absorption_ratio),
]

# Regression baseline: expected status of every test (self-diff guard).
EXPECTED: Dict[str, str] = {
    "T01 survival_identity (STRUCTURAL)": PASS,
    "T02 survival_monotone": PASS,
    "T03 hazard_three_band": PASS,
    "T04 reserve_zero_at_collapse": PASS,
    "T05 collapse_conjunctive": PASS,
    "T06 humane_invariant_floor": PASS,
    "T07 a0_mint_rule": PASS,
    "T08 non_accrual": PASS,
    "T09 best_cap_rule": PASS,
    "T10 mievm_gate": PASS,
    "T11 veiled_c": PASS,
    "T12 por_finality_gate": PASS,
    "T13 structural_not_empirical": PASS,
    "T14 spectrum_hazard_readout (STRUCTURAL, new)": PASS,
    "T15 lt_honestly_stubbed (leak-guard, new)": PASS,
    "S01 real_hazard_boundary (empirical)": SKIP,
    "S02 exceptional_point_cliff (empirical)": SKIP,
    "S03 mievm_maps_collapse (empirical)": SKIP,
    "S04 absorption_ratio (empirical)": SKIP,
}


def self_sha256() -> Optional[str]:
    try:
        with open(__file__, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except (NameError, OSError):
        return None


def run() -> int:
    print("=" * 74)
    print(f" {INSTRUMENT}  v{VERSION}  -- structural validation suite")
    print("=" * 74)
    print(f" python   : {platform.python_version()} ({platform.system()} {platform.machine()})")
    print(f" utc      : {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
    print(f" seed     : {SEED}")
    sha = self_sha256()
    print(f" sha256   : {sha if sha else '(unavailable)'}")
    print("-" * 74)

    n_pass = n_fail = n_skip = n_regress = 0
    for name, fn in TESTS:
        try:
            status, detail = fn()
        except Exception as exc:  # a test raising is itself a failure
            status, detail = FAIL, f"exception: {exc!r}"
        expected = EXPECTED.get(name)
        tag = ""
        if expected is not None and status != expected:
            tag = f"  <<< REGRESSION (expected {expected})"
            n_regress += 1
        print(f" [{status}] {name}")
        if detail:
            print(f"        {detail}{tag}")
        elif tag:
            print(f"       {tag}")
        n_pass += status == PASS
        n_fail += status == FAIL
        n_skip += status == SKIP

    print("-" * 74)
    print(f" totals   : {n_pass} PASS / {n_fail} FAIL / {n_skip} SKIP "
          f"({len(TESTS)} tests){' / ' + str(n_regress) + ' REGRESSION' if n_regress else ''}")
    print("-" * 74)
    print(" NOTE: SKIPs are the four load-bearing empirical claims (WP section 7).")
    print(" They stay SKIP until a real operator L(t) is instantiated (build_L_operator)")
    print(" and its hazard read off computed eigenvalues. A clean run proves coherence,")
    print(" not truth.")
    print("=" * 74)

    return 0 if (n_fail == 0 and n_regress == 0) else 1


if __name__ == "__main__":
    sys.exit(run())
