"""main_ship_ai.py -- VERTECA "Ship's Computer" main loop.
Transcribed from PlayNAC Grok KERNEL Codebase (V.3)."""
from voice_nav_module import listen_and_process
import time


def main_loop():
    print("KERNEL Ship's Computer Active (VERTECA AI Ready)")
    while True:
        response = listen_and_process()
        print(f"KERNEL Response: {response}")
        time.sleep(1)


if __name__ == "__main__":
    main_loop()
