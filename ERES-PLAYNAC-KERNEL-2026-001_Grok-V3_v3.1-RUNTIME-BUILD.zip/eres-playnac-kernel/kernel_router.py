"""kernel_router.py -- routes voice intents to appropriate modules (GERP, EarnedPath, SOMT...).
Transcribed from PlayNAC Grok KERNEL Codebase (V.3)."""
from somt_recorder import GEAR_record
from care_module import CARE
from geo_perspective import GeoPerspective


def route_intent_to_module(command):
    cmd = command.lower()
    if "show" in cmd and "water" in cmd:
        return call_gerp_resource("water")
    elif "learn path" in cmd:
        return launch_earnedpath_training()
    elif "start game" in cmd:
        return start_playnac_sim()
    elif "record state" in cmd:
        return activate_somt_recording()
    elif "what is" in cmd:
        return question_answer(cmd)
    else:
        return "Command not recognized in current module space."


def call_gerp_resource(resource):
    return f"Accessing GERP data: {resource} status across global zones."


def launch_earnedpath_training():
    return "Launching EarnedPath training dashboard..."


def start_playnac_sim():
    return "Booting PlayNAC simulation -- prepare for civic mission."


def activate_somt_recording():
    care = CARE(water=0.85, immigration=0.65, security=0.75)
    geo = GeoPerspective(latitude=33.68, longitude=-111.87)
    somt = GEAR_record(care, geo, notes="Recording system state", npr_phase="stabilization")
    return f"SOMT recorded: {somt.to_json()}"


def question_answer(command):
    from question_answer import CAREGaiasystem
    care_system = CAREGaiasystem()
    return care_system.process_question(command)
