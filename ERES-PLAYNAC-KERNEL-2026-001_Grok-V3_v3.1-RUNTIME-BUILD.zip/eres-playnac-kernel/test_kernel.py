"""Smoke tests for the non-hardware paths (no mic / no EEG required)."""
import numpy as np
from playnac_kernel import PlayNACKernel, BioPoW, MediaProcessor
from care_module import CARE
from geo_perspective import GeoPerspective
from somt_recorder import GEAR_record
from question_answer import CAREGaiasystem
from kernel_router import route_intent_to_module


def test_media_processor():
    mp = MediaProcessor()
    frame = np.random.randint(0, 255, (64, 64, 3), dtype=np.uint8)
    assert mp.validate_md_complexity(frame)          # random frame is high-entropy
    out = mp.gerp_transform(frame, 0.5)
    assert out.shape == frame.shape


def test_bio_pow_ep_is_finite():
    ep = BioPoW().generate_ep()
    assert np.isfinite(ep)


def test_care_score():
    c = CARE(0.85, 0.65, 0.75)
    assert c.protect_enrich_score() == round(0.85*0.4 + 0.65*0.3 + 0.75*0.3, 3)


def test_somt_record_roundtrip():
    somt = GEAR_record(CARE(0.85, 0.65, 0.75),
                       GeoPerspective(33.68, -111.87),
                       npr_phase="stabilization")
    assert len(somt.state_hash) == 64
    assert "GO<33.68:-111.87>D" == GeoPerspective(33.68, -111.87).god_view()


def test_router_intents():
    assert "GERP" in route_intent_to_module("show water usage")
    assert "EarnedPath" in route_intent_to_module("learn path")
    assert "simulation" in route_intent_to_module("start game")
    assert "SOMT recorded" in route_intent_to_module("record state")
    assert "Choice" in route_intent_to_module("what is care")
    assert "not recognized" in route_intent_to_module("fly to mars")


def test_qa_gaia_gating():
    qa = CAREGaiasystem()
    # ep 0.5 < gaia_threshold 0.7 -> simple even for complex "how"
    assert qa.process_question("how does care work") == qa.simple_response("how does care work")
    qa.ep_value = 0.75
    assert "Aura-Tech" in qa.process_question("explain care")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = 0
    for fn in fns:
        fn(); print(f"PASS  {fn.__name__}"); passed += 1
    print(f"\n{passed}/{len(fns)} tests passed")
