"""jas_graph.py -- compatibility shim. JASConsensus / JASLink live in playnac_kernel.py."""
from playnac_kernel import JASConsensus, JASLink  # noqa: F401
