"""care_module.py -- CARE (Choice, Action, Response, Evaluation) for human-centric decisions.
Transcribed from PlayNAC Grok KERNEL Codebase (V.3)."""
from dataclasses import dataclass
from typing import Dict

ASPECTS = ["water", "immigration", "security"]


@dataclass
class CARE:
    water: float
    immigration: float
    security: float

    def protect_enrich_score(self) -> float:
        weights = {"water": 0.4, "immigration": 0.3, "security": 0.3}
        total = sum(getattr(self, k) * weights[k] for k in ASPECTS)
        return round(total, 3)

    def to_dict(self) -> Dict:
        return {
            "water": self.water,
            "immigration": self.immigration,
            "security": self.security
        }
