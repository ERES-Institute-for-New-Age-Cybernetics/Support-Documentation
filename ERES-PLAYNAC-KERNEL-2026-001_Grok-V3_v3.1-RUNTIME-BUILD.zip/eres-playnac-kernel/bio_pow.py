"""bio_pow.py -- compatibility shim. In the Grok V.3 listing BioPoW lives in playnac_kernel.py.
Re-exported here to satisfy the public stub's file taxonomy."""
from playnac_kernel import BioPoW, AuraScanner  # noqa: F401
