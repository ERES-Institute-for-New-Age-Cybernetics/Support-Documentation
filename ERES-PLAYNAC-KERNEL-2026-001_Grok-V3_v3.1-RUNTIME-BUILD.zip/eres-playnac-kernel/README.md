# ERES PlayNAC KERNEL — Grok V.3 Runtime (buildable)

A runnable reconstruction of the **PlayNAC Grok "KERNEL" Codebase (V.3)** (ERES Institute
for New Age Cybernetics, 5/2025), assembled from the documented module listings. The public
`PlayNAC_KERNEL_GitHub_v3.1.zip` shipped these modules as empty `# Module code placeholder.`
stubs; this build fills them in with the actual code from the V.3 document and wires it into
an importable, testable package.

## What this is
A **biocybernetic media proof-of-work runtime**: a mock-EEG "BioPoW" validator, an OpenCV
media processor, a JAS-graph task-chaining consensus, a voice-navigation router (VERTECA),
and small CARE / SOMT / GeoPerspective / QuestionAnswer helpers, plus a Three.js 4D view.

## What this is NOT
This is **not** the PlayNAC governance engine. There is no BERA, RHC, MIEVM, PoR admissibility
gate, CBGMODD council, or 17×7 TABLE here. "GAIA" is a single harm-threshold float in
`question_answer.py`; "SOMT" is a SHA-256 state recorder; "NPR" is a metadata phase string.
These are lightweight namesakes of the governance concepts, not implementations of them.

## Layout
```
playnac_kernel.py     Core orchestrator: MediaTask/JASLink/Block, AuraScanner, BioPoW,
                      MediaProcessor, JASConsensus, PlayNACKernel, demo entrypoint.
care_module.py        CARE (Choice/Action/Response/Evaluation) + protect_enrich_score.
somt_recorder.py      SOMT dataclass + GEAR_record() -> hashed sustainability state.
geo_perspective.py    GeoPerspective(lat, lon).god_view().
question_answer.py    CAREGaiasystem: EP/GAIA-gated simple-vs-detailed answers.
kernel_router.py      route_intent_to_module(): maps voice intents to handlers.
voice_nav_module.py   VERTECA mic capture -> Google STT -> router  (needs mic + PyAudio).
main_ship_ai.py       "Ship's Computer" main loop.
4d_visual_env.html    Three.js r128 THOW/RV visualization (open in a browser).
bio_pow.py / media_kernel.py / jas_graph.py
                      Compatibility shims re-exporting the classes from playnac_kernel.py
                      (the V3.1 stub listed these as separate files).
test_kernel.py        Smoke tests for the non-hardware paths.
```

## Quick start
```bash
pip install -r requirements.txt          # numpy, opencv-python, SpeechRecognition, PyAudio
python playnac_kernel.py                  # runs the media-PoW demo
python test_kernel.py                     # runs the smoke tests (no mic/EEG required)
python main_ship_ai.py                    # voice loop — requires a working microphone
# open 4d_visual_env.html in a browser for the 4D view
```

## Status (verified in this build)
- Imports clean; `test_kernel.py` → 6/6 pass (Python 3.12, numpy 2.4, opencv 4.13).
- The media pipeline (MD-complexity, GERP stylization), CARE, SOMT, Geo, QA, and the
  router all run correctly.
- **Block mining fails by design of the V.3 listing** — `generate_ep()` returns ~O(70)
  while `network_target` is 0.5 (tolerance 0.01), so `validate_bio_work` can never be true.
  See `BUILD_NOTES.md` for the exact cause and a one-line fix (not applied — it changes
  the documented algorithm).

License: Creative Commons BY-NC 4.0 (as stated in the V.3 document).
