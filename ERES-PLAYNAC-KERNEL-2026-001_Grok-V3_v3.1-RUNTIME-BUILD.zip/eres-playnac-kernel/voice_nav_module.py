"""voice_nav_module.py -- VERTECA hands-free voice recognition.
Transcribed from PlayNAC Grok KERNEL Codebase (V.3).
Requires: SpeechRecognition + PyAudio + a working microphone (not exercisable headless)."""
import speech_recognition as sr
from kernel_router import route_intent_to_module


def listen_and_process():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio)
        print(f"Command received: {command}")
        response = route_intent_to_module(command)
        return response
    except sr.UnknownValueError:
        return "Sorry, I didn't understand that."
    except sr.RequestError as e:
        return f"Could not request results; {e}"
