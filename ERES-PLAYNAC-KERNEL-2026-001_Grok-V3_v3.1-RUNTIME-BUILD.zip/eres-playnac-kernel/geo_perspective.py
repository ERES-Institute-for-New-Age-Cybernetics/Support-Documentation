"""geo_perspective.py -- longitude/latitude + GOD perspective for geo-aware insights.
Transcribed from PlayNAC Grok KERNEL Codebase (V.3).
FIX: added the missing `from dataclasses import dataclass` import (absent in the PDF listing)."""
from dataclasses import dataclass


@dataclass
class GeoPerspective:
    latitude: float
    longitude: float

    def god_view(self) -> str:
        return f"GO<{self.latitude:.2f}:{self.longitude:.2f}>D"
