# BUILD_NOTES — faithfulness, fixes, and the one real bug

Source: `ERES PlayNAC Grok KERNEL Codebase V.3.pdf` (ERES Institute, 5/2025).
Goal: turn the documented listings into a repo that installs, imports, and runs, while
staying faithful to the code as written. Every deviation is listed below.

## Transcribed verbatim (logic unchanged)
`care_module.py`, `somt_recorder.py`, `question_answer.py`, `kernel_router.py`,
`voice_nav_module.py`, `main_ship_ai.py`, `4d_visual_env.html`, and all class logic in
`playnac_kernel.py` (MediaTask, JASLink, Block, AuraScanner, BioPoW, MediaProcessor,
JASConsensus, PlayNACKernel).

## Deviations made to let it run (all minimal, all here)
1. **geo_perspective.py** — added the missing `from dataclasses import dataclass`. The PDF
   listing uses `@dataclass` but omits the import, so the module could not load as printed.
2. **playnac_kernel.py, entropy lines** — `np.log2(raw_eeg + 1e-10)` → `np.log2(np.abs(raw_eeg)
   + 1e-10)` in `generate_ep()` and `get_aura_entropy()`. The mock EEG is `normal(0.5, 0.1)`,
   which can be negative; `log2` of a negative is NaN. `abs()` keeps EP finite. This changes
   numerical robustness, not the intended formula.
3. **4d_visual_env** — shipped as `.html` (the content is an HTML/Three.js document). The stub
   named it `4d_visual_env.py`, which would not run as Python.
4. **bio_pow.py / media_kernel.py / jas_graph.py** — added as one-line re-export shims. The V.3
   text puts BioPoW/MediaProcessor/JASConsensus inside `playnac_kernel.py`, but the public stub
   listed them as separate files; the shims satisfy both.
5. **demo entrypoint** — `demo_playnac_kernel()` now uses a 240×320 frame and
   `mine_block(max_iterations=25)` so `python playnac_kernel.py` terminates in ~1s instead of
   grinding 1000 expensive stylizations. The kernel/mining logic itself is untouched.
6. Replaced a few emoji in `print()` strings with ASCII for portable terminals. Cosmetic.

## The one real bug (left as-is, documented, not patched)
`generate_ep()` returns spectral entropy over 256 samples × `gerp_factor` 0.618 ≈ **70–80**.
`mine_block()` compares it to `network_target` (0.5 for the genesis block) with
`tolerance = 0.01` via `validate_bio_work`. |77 − 0.5| ≫ 0.01, so **the check never passes and
no block is ever mined** — the loop runs to `max_iterations` and returns `None`.

This is a scale mismatch in the documented design, not a transcription error. It is left
unpatched because any fix is a semantic choice about how BioPoW should work. The minimal
option, if you want the demo to close a block, is to normalize EP into the target's range,
e.g. in `generate_ep()`:

    ep_value = (spectral_entropy * self.gerp_factor) % 1.0   # map into [0, 1)

and/or widen `tolerance`. Decide the intended semantics before adopting either.

## Not exercisable headless
`voice_nav_module.py` and `main_ship_ai.py` need SpeechRecognition + PyAudio + a live
microphone; `4d_visual_env.html` needs a browser/WebGL. These were import-checked and
transcribed but not run in the build sandbox.
