"""media_kernel.py -- compatibility shim. MediaProcessor lives in playnac_kernel.py."""
from playnac_kernel import MediaProcessor  # noqa: F401
