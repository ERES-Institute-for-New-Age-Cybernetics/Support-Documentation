"""question_answer.py -- lightweight QuestionAnswer system, regulated by Aura-Tech EP and GAIA.
Transcribed from PlayNAC Grok KERNEL Codebase (V.3)."""


class CAREGaiasystem:
    def __init__(self):
        self.ep_value = 0.5       # Mock EEG from Aura-Tech
        self.gaia_threshold = 0.7  # GAIA harm prevention threshold

    def process_question(self, question):
        is_complex = any(word in question.lower()
                         for word in ["how", "why", "explain", "detail"])
        return (self.detailed_response(question)
                if is_complex and self.ep_value >= self.gaia_threshold
                else self.simple_response(question))

    def simple_response(self, question):
        if "care" in question.lower():
            return "CARE is Choice, Action, Response, Evaluation, optimizing decisions."
        elif "gcf" in question.lower():
            return "GCF calculates rewards as UBI + Merits * Investments +/- Awards."
        return "Please clarify your question."

    def detailed_response(self, question):
        if "care" in question.lower():
            return ("CARE (Choice, Action, Response, Evaluation) optimizes decisions in "
                    "PlayNAC by using Aura-Tech (EEG) to personalize choices, Gracechain to "
                    "validate actions, and Non-Punitive Remediation to adjust tasks.")
        elif "gcf" in question.lower():
            return ("GCF (Graceful Contribution Formula) is UBI + (Merits * Investments) "
                    "+/- Awards, integrating BERC (bio-ecologic metrics) and NBERS "
                    "(resource scores) to reward contributions equitably.")
        return "Please clarify your question."

    def update_ep(self, new_ep):
        self.ep_value = min(max(new_ep, 0.2), 0.8)
        check = 'Simplified' if self.ep_value < self.gaia_threshold else 'Detailed'
        print(f"EP updated: {self.ep_value}, GAIA check: {check} response")
