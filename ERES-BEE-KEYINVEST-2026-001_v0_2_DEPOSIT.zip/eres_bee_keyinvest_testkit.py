#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-BEE-KEYINVEST-2026-001  --  Companion Falsifiable Testkit  (v0.1)
Key Investments for a Spectrally-Stable Bio-Ecologic Economy (BEE)

Zero third-party dependencies (Python 3 standard library only).

WHAT THIS KIT IS / IS NOT
  - IS: a check that the *mathematics* in the whitepaper is implemented
        correctly and behaves as claimed, on operators whose eigenvalues are
        COMPUTED from the matrix (Faddeev-LeVerrier + Durand-Kerner), never
        stipulated.  Each investment lever is exercised with a confirming test
        and, where possible, a falsifying / negative-control test.
  - IS NOT: evidence that the climate/physiology -> provisioning transfer is
        physically valid.  That transfer is ANALOGICAL (Layer Doctrine:
        Pellis L1-2 math foundational; ERES L3-4 governance application).
        The empirical claims are pre-registered falsifiers and reported as
        SKIP until real >=2-scale BEE telemetry exists.

Foundational attribution: the spectral-stability grammar used here
(spectral bound s(A)=sup Re lambda, critical slowing down, spectral gap,
pseudospectral transient growth) is the foundational mathematics of
Dr. Stergios Pellis (Spectral-Fractal Operator Theory of Climate Criticality,
24 June 2026, unpublished manuscript; ORCID 0000-0002-7363-8254; Greece) and
its operator family.  Cited, not endorsed.

Run:  python3 eres_bee_keyinvest_testkit.py
Exit code 0 iff 0 FAIL.
"""

import cmath
import hashlib
import math
import os
import sys

TOL = 1e-9

# ----------------------------------------------------------------------------
# Minimal real/complex linear algebra (small dense matrices, lists of lists)
# ----------------------------------------------------------------------------

def eye(n):
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]

def matmul(A, B):
    n, m, p = len(A), len(B[0]), len(B)
    return [[sum(A[i][k] * B[k][j] for k in range(p)) for j in range(m)] for i in range(n)]

def matsub(A, B):
    return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def scal(A, s):
    return [[A[i][j] * s for j in range(len(A[0]))] for i in range(len(A))]

def trace(A):
    return sum(A[i][i] for i in range(len(A)))

def transpose(A):
    return [[A[j][i] for j in range(len(A))] for i in range(len(A[0]))]

def inf_norm(A):
    return max(sum(abs(v) for v in row) for row in A)

def inv(A):
    """Gauss-Jordan inverse for a small nonsingular matrix."""
    n = len(A)
    M = [list(map(float, A[i])) + [1.0 if j == i else 0.0 for j in range(n)] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-15:
            raise ZeroDivisionError("singular matrix")
        M[c], M[piv] = M[piv], M[c]
        pv = M[c][c]
        M[c] = [v / pv for v in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0.0:
                f = M[r][c]
                M[r] = [a - f * b for a, b in zip(M[r], M[c])]
    return [row[n:] for row in M]

def block_diag(*blocks):
    n = sum(len(b) for b in blocks)
    out = [[0.0] * n for _ in range(n)]
    off = 0
    for b in blocks:
        k = len(b)
        for i in range(k):
            for j in range(k):
                out[off + i][off + j] = b[i][j]
        off += k
    return out

# ----------------------------------------------------------------------------
# Eigenvalues by CHARACTERISTIC POLYNOMIAL, computed from the matrix.
#   Faddeev-LeVerrier -> monic char-poly coefficients (uses only mat-mul/trace)
#   Durand-Kerner     -> all complex roots of that polynomial
# This is the "computed, not stipulated" spectrum: the eigenvalues are derived
# from L itself, so an operator with a genuine structure is required.
# ----------------------------------------------------------------------------

def char_poly(A):
    """Return monic char-poly coeffs [1, c1, c2, ..., cn] with
       p(x) = x^n + c1 x^(n-1) + ... + cn."""
    n = len(A)
    M = eye(n)
    coeffs = [1.0]
    for k in range(1, n + 1):
        AM = matmul(A, M)
        a_k = trace(AM) / k
        coeffs.append(-a_k)
        M = matsub(AM, scal(eye(n), a_k))
    return coeffs

def _poly_eval(coeffs, x):
    r = 0 + 0j
    for c in coeffs:
        r = r * x + c
    return r

def poly_roots(coeffs, iters=2000):
    """All complex roots of a monic polynomial via Durand-Kerner."""
    n = len(coeffs) - 1
    if n == 0:
        return []
    # spread initial guesses off the real axis so conjugate pairs separate
    seed = complex(0.4, 0.9)
    roots = [seed ** k for k in range(n)]
    for _ in range(iters):
        maxd = 0.0
        new = list(roots)
        for i in range(n):
            num = _poly_eval(coeffs, roots[i])
            den = 1 + 0j
            for j in range(n):
                if j != i:
                    den *= (roots[i] - roots[j])
            if den == 0:
                den = 1e-30
            step = num / den
            new[i] = roots[i] - step
            maxd = max(maxd, abs(step))
        roots = new
        if maxd < 1e-15:
            break
    return roots

def eigenvalues(A):
    return poly_roots(char_poly(A))

def spectral_abscissa(A):
    """Pellis s(A) = sup_k Re(lambda_k)."""
    return max(z.real for z in eigenvalues(A))

def stability_margin(A):
    """m(A) = -s(A).  BEE stable iff m > 0."""
    return -spectral_abscissa(A)

def spectral_gap(A):
    """Delta_s = Re(lambda_1) - Re(lambda_2), dominant two modes of the
       STABILITY operator (not of any correlation matrix)."""
    re = sorted((z.real for z in eigenvalues(A)), reverse=True)
    if len(re) < 2:
        return float("inf")
    return re[0] - re[1]

# ----------------------------------------------------------------------------
# Matrix exponential (scaling & squaring + Taylor) and spectral norm.
# Used for the pseudospectral / transient-amplification demonstration.
# ----------------------------------------------------------------------------

def matexp(A, t, terms=18):
    n = len(A)
    s = 0
    scale = inf_norm(A) * abs(t)
    while scale > 0.5:
        scale /= 2.0
        s += 1
    At = scal(A, t / (2 ** s))
    E = eye(n)
    term = eye(n)
    for k in range(1, terms + 1):
        term = scal(matmul(term, At), 1.0 / k)
        E = [[E[i][j] + term[i][j] for j in range(n)] for i in range(n)]
    for _ in range(s):
        E = matmul(E, E)
    return E

def spectral_norm(A, iters=200, seed=20260904):
    """Largest singular value of real A via power iteration on A^T A."""
    n = len(A[0])
    AtA = matmul(transpose(A), A)
    x = 20260904
    v = []
    for _ in range(n):
        x = (1103515245 * x + 12345) & 0x7FFFFFFF   # deterministic LCG
        v.append((x / 0x7FFFFFFF) - 0.5)
    nrm = math.sqrt(sum(c * c for c in v)) or 1.0
    v = [c / nrm for c in v]
    lam = 0.0
    for _ in range(iters):
        w = [sum(AtA[i][j] * v[j] for j in range(n)) for i in range(n)]
        nw = math.sqrt(sum(c * c for c in w))
        if nw < 1e-300:
            return 0.0
        v = [c / nw for c in w]
        lam = nw
    return math.sqrt(lam)

def max_transient_gain(A, t_max=40.0, steps=400):
    """G_max = sup_{t>=0} ||exp(A t)||_2  (spectral norm)."""
    best = 0.0
    for i in range(steps + 1):
        t = t_max * i / steps
        g = spectral_norm(matexp(A, t))
        best = max(best, g)
    return best

# ----------------------------------------------------------------------------
# Investment-lever primitives
# ----------------------------------------------------------------------------

def n_eff_two_channel(r):
    """Galwey (2009) effective-independence count for a 2-channel
       redundancy with correlation r.  Correlation-matrix eigenvalues are
       (1+r, 1-r); n_eff = (sqrt(1+r)+sqrt(1-r))^2 / 2."""
    r = max(-0.999999, min(0.999999, r))
    return (math.sqrt(1 + r) + math.sqrt(1 - r)) ** 2 / 2.0

def common_mode_load(n, n_eff):
    """Fraction of nominal redundancy that is co-moving (wasted).
       0 when n_eff==n (fully independent), 1 when n_eff==1 (all common)."""
    if n <= 1:
        return 0.0
    return (n - n_eff) / (n - 1)

def recovery_shift(A, rho):
    """Investment #4 / #6: uniform diagonal recovery (or forcing buy-down)
       shifts the whole spectrum left by rho:  spec(A - rho I) = spec(A) - rho."""
    n = len(A)
    return matsub(A, scal(eye(n), rho))

def ou_variance(lmbda, sigma=1.0):
    """Stationary variance of a 1-D return process dx = lambda x dt + sigma dW,
       lambda < 0:  Var = sigma^2 / (2|lambda|)  -> inf as lambda -> 0-."""
    return sigma ** 2 / (2.0 * abs(lmbda))

def ou_ac1(lmbda, dt=1.0):
    """Lag-1 autocorrelation = exp(lambda dt) -> 1 as lambda -> 0-."""
    return math.exp(lmbda * dt)

def read_margin_from_telemetry(*_a, **_k):
    """Investment #3 empirical readout on REAL >=2-scale BEE telemetry.
       Deliberately unimplemented: no such dataset is bound.  This guard makes
       the ANALOGICAL->SOUND lift impossible to fake in code."""
    raise NotImplementedError(
        "No real >=2-scale BEE telemetry is bound. Margin cannot be read from "
        "data yet; see pre-registered falsifier F1."
    )

# ----------------------------------------------------------------------------
# Harness
# ----------------------------------------------------------------------------

class Results:
    def __init__(self):
        self.p = self.f = self.s = 0
    def ok(self, name, cond, detail=""):
        if cond:
            self.p += 1
            print("  PASS  " + name + (("  -- " + detail) if detail else ""))
        else:
            self.f += 1
            print("  FAIL  " + name + (("  -- " + detail) if detail else ""))
    def skip(self, name, why):
        self.s += 1
        print("  SKIP  " + name + "  -- " + why)

def close(a, b, tol=1e-6):
    return abs(a - b) <= tol

def main():
    R = Results()
    print("=" * 74)
    print("ERES-BEE-KEYINVEST-2026-001 v0.1  --  falsifiable testkit")
    print("=" * 74)

    # --- T1  Eigensolver correctness: COMPUTED, not stipulated -------------
    # Build a genuinely non-triangular, non-normal L with KNOWN eigenvalues
    # via a non-orthogonal similarity, then recover them from L alone.
    T = [[-0.5, 3.0, 1.0],
         [ 0.0, -0.9, 2.0],
         [ 0.0,  0.0, -1.4]]           # eigenvalues = diag = -0.5,-0.9,-1.4
    S = [[1.0, 0.0, 0.0],
         [0.7, 1.0, 0.0],
         [0.3, 0.5, 1.0]]             # unit lower-triangular shear (non-orth)
    L1 = matmul(matmul(S, T), inv(S))
    known = sorted([-0.5, -0.9, -1.4])
    got = sorted(z.real for z in eigenvalues(L1))
    imag_ok = all(abs(z.imag) < 1e-6 for z in eigenvalues(L1))
    rec_ok = all(close(a, b, 1e-6) for a, b in zip(known, got)) and imag_ok
    R.ok("T1  eigenvalues recovered from a full non-normal L (computed)",
         rec_ok, "s(L)=%.6f expected %.6f" % (spectral_abscissa(L1), -0.5))

    # --- T2  Floor-block guarantee (Investment #1) ------------------------
    # Decoupled floor block always contributes eigenvalue -d_floor,
    # regardless of an UNSTABLE merit block.  Coupling breaks the guarantee.
    d_floor = 0.8
    L_floor = [[-d_floor]]
    L_merit_unstable = [[ 0.4, 1.0],
                        [-0.2, 0.3]]   # s > 0 (unstable merit layer)
    L_dec = block_diag(L_floor, L_merit_unstable)
    ev = eigenvalues(L_dec)
    floor_present = any(abs(z.real + d_floor) < 1e-6 and abs(z.imag) < 1e-6 for z in ev)
    merit_unstable = spectral_abscissa(L_merit_unstable) > 0
    R.ok("T2a floor eigenvalue -d_floor survives an unstable merit layer",
         floor_present and merit_unstable,
         "floor=-%.2f present; s(merit)=%.3f>0" % (d_floor, spectral_abscissa(L_merit_unstable)))
    # Falsify: couple the floor to the unstable merit layer -> guarantee lost
    L_cpl = [row[:] for row in L_dec]
    L_cpl[0][1] = 0.9
    L_cpl[1][0] = 0.9
    ev_c = eigenvalues(L_cpl)
    floor_lost = not any(abs(z.real + d_floor) < 1e-6 and abs(z.imag) < 1e-6 for z in ev_c)
    R.ok("T2b coupling the floor DESTROYS the guarantee (decoupling is load-bearing)",
         floor_lost, "no eigenvalue at -%.2f once coupled" % d_floor)

    # --- T3  Recovery / forcing-buydown shift (Investments #4, #6) --------
    rho = 0.35
    s0 = spectral_abscissa(L1)
    s1 = spectral_abscissa(recovery_shift(L1, rho))
    R.ok("T3  funded recovery shifts s(L) left by exactly rho",
         close(s1, s0 - rho, 1e-6), "s: %.4f -> %.4f (drho=%.2f)" % (s0, s1, rho))

    # --- T4  Effective independence (Investment #2, CDFE / n_eff) ---------
    r09 = n_eff_two_channel(0.90)
    ok_143 = close(r09, 1.4359, 1e-3)   # exact: (sqrt(1.9)+sqrt(0.1))^2/2
    mono = n_eff_two_channel(0.0) > n_eff_two_channel(0.5) > n_eff_two_channel(0.95)
    limits = close(n_eff_two_channel(0.0), 2.0, 1e-6) and n_eff_two_channel(0.999999) < 1.02
    R.ok("T4a n_eff(r=0.90) ~ 1.43 (two 'independent' channels are < 1.5)",
         ok_143, "n_eff=%.4f" % r09)
    R.ok("T4b n_eff monotone in r and hits limits (r=0 ->2, r->1 ->1)",
         mono and limits,
         "n_eff(0)=%.3f n_eff(0.5)=%.3f n_eff(0.95)=%.3f"
         % (n_eff_two_channel(0), n_eff_two_channel(0.5), n_eff_two_channel(0.95)))
    # Falsify the naive 'count = n' claim: common-mode load > 0 whenever r>0
    cml = common_mode_load(2, r09)
    R.ok("T4c naive redundancy count overstates independence (common-mode load>0)",
         cml > 0.5, "common_mode_load=%.3f at r=0.90" % cml)

    # --- T5  Pseudospectral transient growth (Investment #5, reserves) ----
    # Non-normal L, ALL eigenvalues stable, still amplifies transiently.
    L_nn = [[-0.5, 6.0, 0.0],
            [ 0.0, -0.6, 6.0],
            [ 0.0,  0.0, -0.7]]        # eigenvalues -0.5,-0.6,-0.7 (all < 0)
    L_norm = [[-0.5, 0.0, 0.0],
              [ 0.0, -0.6, 0.0],
              [ 0.0,  0.0, -0.7]]      # same spectrum, normal (diagonal)
    assert spectral_abscissa(L_nn) < 0
    G_nn = max_transient_gain(L_nn)
    G_no = max_transient_gain(L_norm)
    R.ok("T5a stable-but-non-normal L amplifies transiently (G_max>1)",
         G_nn > 1.5, "G_max(non-normal)=%.3f while s(L)=%.3f<0"
         % (G_nn, spectral_abscissa(L_nn)))
    R.ok("T5b normal L with same spectrum does NOT (negative control G_max~1)",
         close(G_no, 1.0, 1e-2), "G_max(normal)=%.3f" % G_no)

    # --- T6  Critical slowing down -> observability (Investment #3 math) --
    lams = [-1.0, -0.5, -0.25, -0.1, -0.05, -0.02]
    var = [ou_variance(l) for l in lams]
    ac1 = [ou_ac1(l) for l in lams]
    var_mono = all(var[i] < var[i + 1] for i in range(len(var) - 1))
    ac1_mono = all(ac1[i] < ac1[i + 1] for i in range(len(ac1) - 1))
    R.ok("T6a variance inflates and AC1 -> 1 as margin -> 0 (readable precursor)",
         var_mono and ac1_mono,
         "Var: %.2f..%.2f  AC1: %.3f..%.3f" % (var[0], var[-1], ac1[0], ac1[-1]))
    # margin m=|lambda|; 1/Var = 2|lambda| = 2m -> exact ANALYTIC IDENTITY.
    ident = all(close(1.0 / ou_variance(l), 2.0 * abs(l), 1e-9) for l in lams)
    R.ok("T6b margin<->1/Var is an ANALYTIC IDENTITY (not empirical evidence)",
         ident, "1/Var == 2*margin exactly; flagged non-evidential")

    # --- T7  Forcing raises s(L) toward criticality (Investment #6) -------
    base = [[-1.0, 0.2], [0.1, -1.0]]
    pattern = [[1.0, 0.0], [0.0, 1.0]]
    svals = [spectral_abscissa([[base[i][j] + f * pattern[i][j]
                                 for j in range(2)] for i in range(2)])
             for f in (0.0, 0.3, 0.6, 0.9)]
    R.ok("T7  rising destabilizing forcing f monotonically raises s(L)",
         all(svals[i] < svals[i + 1] for i in range(len(svals) - 1)),
         "s(L): " + " -> ".join("%.3f" % v for v in svals))

    # --- T8  Empirical-leak guard (honest ANALOGICAL->SOUND gate) ---------
    raised = False
    try:
        read_margin_from_telemetry([1, 2, 3])
    except NotImplementedError:
        raised = True
    R.ok("T8  reading margin from real telemetry is blocked by design",
         raised, "the SOUND/BEST lift cannot be faked in code")

    # --- T9  Determinism / integrity --------------------------------------
    try:
        with open(os.path.abspath(__file__), "rb") as fh:
            digest = hashlib.sha256(fh.read()).hexdigest()
        det = spectral_abscissa(L1) == spectral_abscissa(L1)
        R.ok("T9  deterministic recompute + self-hash available",
             det, "sha256[:16]=" + digest[:16])
    except Exception as e:                      # pragma: no cover
        R.ok("T9  deterministic recompute + self-hash available", False, str(e))

    # --- Pre-registered EMPIRICAL falsifiers: not yet testable -------------
    R.skip("F1  rho(margin, early-warning) on real >=2-scale BEE telemetry",
           "no real dataset bound (only ANALOGICAL lift possible without it)")
    R.skip("F2  independent >=5-node MIEVM >= 9.0 on the governance application",
           "author-side single node only; not an independent panel")
    R.skip("F3  field instantiation of the six investments on a live S3C tile",
           "requires deployed EMCI/LLPM ledger + NBERS call-line")

    print("-" * 74)
    print("SUMMARY: %d PASS / %d FAIL / %d SKIP" % (R.p, R.f, R.s))
    print("Grade unaffected by PASS count: nothing here is DERIVED, so nothing")
    print("is BEST; the governance transfer stays ANALOGICAL below the 9.0 gate.")
    print("-" * 74)
    return 0 if R.f == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
