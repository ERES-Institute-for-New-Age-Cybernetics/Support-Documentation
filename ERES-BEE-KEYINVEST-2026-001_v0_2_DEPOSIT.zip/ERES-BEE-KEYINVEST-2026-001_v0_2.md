# Implementation Requirements for a Spectrally-Stable Bio-Ecologic Economy (BEE)
### A Spectral-Margin Conformance Specification — "Key Investments" read as build requirements, not investment advice

**Instrument ID:** ERES-BEE-KEYINVEST-2026-001
**Version:** v0.2 (DRAFT — below the 9.0 Stergios gate; not for external citation as endorsement)
**Supersedes:** v0.1 — framing/role only; the tested testkit is byte-identical (SHA-256 41bda7ca…).
**Role:** Implementation requirements / conformance specification. **Not financial or investment advice** — here "investment" denotes *resource allocation* (what must be funded and built), not guidance on securities or markets. The requirements are **necessary, not sufficient** (see §4, §7).
**Date:** 4 September 2026
**Author (sole accountable):** Joseph Allen Sprute ("ERES Maestro"), Founder & Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas, USA. ORCID: 0000-0001-9946-3221.
**Drafting credit ("Sentience"):** AI-assisted drafting (Claude). Credit, not accountability.
**License:** CC BY 4.0 + ERES CCAL v2.1 house convention (reuse must preserve the Pellis Foundational Attribution and the Layer Doctrine below).
**Disposition:** Author-side single node. HELD for independent MIEVM; no real-data claim asserted.

---

## Foundational Attribution (read first)

The spectral-stability mathematics used throughout — a system represented by an
evolution operator whose **spectral bound** `s(A) = sup{ Re λ : λ ∈ σ(A) }`
governs stability, together with **critical slowing down** (`Re λ₁ → 0⁻`,
recovery time `τ_r = 1/|Re λ₁| → ∞`), the **spectral gap**, and
**pseudospectral / non-normal transient growth** — is the foundational
mathematics of **Dr. Stergios Pellis**, from his *Spectral–Fractal Operator
Theory of Climate Criticality, Tipping Points and Planetary Instability*
(24 June 2026, unpublished manuscript) and the wider Pellis spectral-collapse
operator family [Pellis 2026a; Pellis 2026b].

**Layer Doctrine (per the ERES–Pellis Credit Protocol).** *Mathematical
Foundation → Physical Modelling → Cybernetic Extension → Application
Architecture; Theory ≠ Implementation ≠ Application.* Pellis's contribution is
Layers 1–2 (the operator theory and its spectral criteria). This instrument is
Layers 3–4 (a governance/finance application to the Bio-Ecologic Economy). The
transfer of the spectral grammar from climate/physics to economic provisioning
is **ANALOGICAL** — proposable, not asserted — and is **non-transfer-locked**:
a shared mathematical form is not a shared physical mechanism ("same shape ≠
same truth"). Nothing here is Dr. Pellis's endorsement of the governance
application; his mathematics is cited, not co-signed.

---

## Abstract

This is a **requirements-and-conformance specification** for what an ERES
Bio-Ecologic Economy (BEE) must achieve to reach and hold a stable
(BEST/SOUND/GOOD) state — **not investment advice** ("investment" here means
*resource allocation*: what must be funded and built). We express it inside the
Pellis spectral operator framework. A BEE over a Solid-State Smart-City (S3C) tile is modelled as a
coupled provisioning system whose linearised generator `L` is stable exactly
when its spectral bound `s(L) < 0`; the **stability margin** is `m = −s(L)`.
"Guarantee" is then given a precise, bounded meaning: it holds in the *strong*
sense at exactly one place — the block-decoupled survival **floor** (NBERS /
UBIMIA N-layer), whose eigenvalue is fixed negative by construction and lies
outside the collapse spectrum — and in the *maintained-and-observable* sense
everywhere else. On that basis we define **six Key Investments**, each mapped
to a specific spectral lever: (1) fund the unconditional floor; (2) buy
effective independence across channels (CDFE / `n_eff`) to defeat cascade
synchronisation; (3) instrument the margin (critical-slowing-down telemetry);
(4) fund fast recovery (REEP) to shorten `τ_r`; (5) hold reserves for
non-normal transient excursions (pseudospectra); (6) buy down the destabilising
forcing (SROC offsets). A companion, **zero-dependency** Python testkit
(embedded, §8; 14 PASS / 0 FAIL / 3 SKIP) verifies each lever on operators
whose eigenvalues are **computed from the matrix**, not stipulated. Epistemic
status: the six are **necessary conditions, not sufficient** — whether meeting
all six actually yields a stable BEE is itself the pre-registered empirical test
(§7, F1). SOUND-candidate specification / GOOD claim; nothing is DERIVED, so
nothing is BEST. The single lever that can lift the whole to BEST is
requirement #3 instantiated on real ≥2-scale BEE telemetry, pre-registered per
Dr. Pellis's six elements (§7).

---

## Reviewer reading order

1. §0 Scoring Contract and §0.1 register — what is and is not claimed.
2. §1 — the exact, bounded meaning of "guarantee."
3. §2–§4 — the operator, the six levers, the Investment–Margin proposition.
4. §8 — run the embedded testkit; confirm 14/0/3.
5. §7 — the pre-registered falsifiers (the path off ANALOGICAL).

---

## §0 Scoring Contract (dual-axis)

Scoring is **epistemic × teleological** (the ERES Healthy-Happy-SAFE axis),
consistent with ERES-PELLIS-GAIA-BENCHMARKS-2026-001.

| Subscore | Value | Note |
|---|---:|---|
| Architectural coherence | 9.1 | six levers map 1:1 to distinct spectral quantities |
| Epistemic discipline | 9.4 | ANALOGICAL lock; guarantee bounded to the floor; identities flagged |
| Provenance / reuse | 9.0 | Pellis math cited; CDFE, SSM/MARGIN, NBERS, REEPER, SROC reused |
| Novelty | 7.5 | recomposition of existing ERES + Pellis primitives, not new physics |
| **Cap — empirical** | **2.5** | no real BEE telemetry; all empirical falsifiers SKIP |
| **Cap — artifact / reproducibility** | 8.5 | computed-spectrum testkit, 14/0/3, SHA-sealed |

**Composite (single-node self-rate as design): ≈ 8.7.** Clears the 8.5
"Emanuel" (diligence-ready) threshold; **below** the 9.0 "Stergios"
(Pellis-facing) gate. Grade: **GOOD (claim) / SOUND-candidate (specification).**
Per the corpus rule *no claim is DERIVED, therefore none is BEST.*

## §0.1 Epistemic register

| Register | Content here | Strength |
|---|---|---|
| Mathematical (load-bearing) | `s(L)`, margin, gap, spectral shift, `n_eff`, `G_max`, OU variance/AC1 | STRUCTURAL / BEST-eligible **as mathematics** |
| Application (governance) | "these six allocations maintain a stable BEE" | ANALOGICAL, below 9.0, non-transfer-locked |
| Empirical | "the margin predicts real BEE collapse with lead-time" | CONJECTURE — pre-registered, untested (F1) |

---

## §1 What "guarantee BEST/SOUND/GOOD BEE" can and cannot mean

In the Pellis framework a tipping event is the spectral bound crossing zero,
and the theory's own result is that proximity to a tip is **detectable in
advance**, not that it can be made impossible. So an honest instrument must not
promise immunity. We decompose "guarantee" into two grades:

- **Hard guarantee (certainty).** Available at one place only: the survival
  **floor**. If the floor block is decoupled and its self-recovery rate is
  fixed at `d_floor > 0`, then `−d_floor ∈ σ(L)` with `Re(−d_floor) < 0`
  *regardless* of any instability in the merit layer above it. The survival of
  people is thereby held outside the collapse spectrum by construction.

- **Maintained, observable margin (not certainty).** Everywhere above the
  floor, the goal is to keep `m = −s(L)` above a required margin `m*` and to
  keep it **readable** so the guarantee is auditable rather than asserted.

The six Key Investments are exactly the allocations that (i) fund the hard
floor, (ii) enlarge the maintained margin, and (iii) make it observable.

These six are **necessary conditions** — build requirements, not investment
advice. They are not claimed *sufficient*: that satisfying all six actually
yields a stable BEE is the empirical question pre-registered in §7 (F1).

---

## §2 The BEE stability operator

Let a BEE over an S3C tile (or User-GROUP) have state `x(t) ∈ ℝⁿ`, the vector
of deviations of `n` provisioning subsystems (water, power, shelter, corridors,
comms, medical, supply, …) from a stewarded equilibrium `x*`. The nonlinear
provisioning dynamics `dx/dt = F(x)` linearise near `x*` to

```
dξ/dt = L ξ ,      L = DF(x*) = A + DN(x*)          (Pellis eq. 18)
```

with **spectrum** `σ(L)`, **spectral bound** `s(L) = max_k Re λ_k`, and
**margin** `m(L) = −s(L)`. The BEE is stable iff `m(L) > 0`
(Pellis eqs. 39–45). The **spectral gap** `Δ_s = Re λ₁ − Re λ₂` measures how
well-separated the dominant mode is; `Δ_s → 0` signals dominant modes
interacting — loss of resilience (Pellis eqs. 52–56).

**Floor/merit split.** Partition `x = (x_N, x_M)` — `x_N` the survival floor
(NBERS / UBIMIA N), `x_M` the merit layer (M). In block form

```
L = [ L_N   B  ]
    [ C     L_M ]
```

Investment #1 sets `B = 0` and `L_N = −d_floor · I_N` (`d_floor > 0` fixed).
With `B = 0` the operator is block-triangular, so `σ(L) = σ(L_N) ∪ σ(L_M)`;
the floor eigenvalue `−d_floor` is guaranteed present and negative. The
**collapse spectrum lives entirely in `L_M`.** Write

```
L_M = − D_rec + K_couple + Φ_force
```

- `D_rec = diag(d₁,…)` — per-subsystem self-recovery (raised by Investment #4);
- `K_couple` — inter-subsystem coupling; its co-moving (common-mode) part is
  the cascade driver (reduced by Investment #2);
- `Φ_force` — destabilising forcing gain (extraction, degradation, external
  stress `μ`; reduced by Investment #6).

Because EarnedPath progression is **directional**, `K_couple` is
**non-symmetric**, so `L_M` is **non-normal** and its spectrum is complex —
which is exactly what makes `s(L) = sup Re λ` non-trivial and admits transient
growth even under a stable spectrum (Investment #5).

---

## §3 The six Key Investments as spectral levers

### 3.1 Fund the unconditional floor — Investment #1
*Instrument:* NBERS ("the number anyone can call") + UBIMIA N-floor + the
EarnedPath trailhead (THOW at reentry), per ERES-BEE-NBERS-2026-001 and
ERES-ENDHOME-2026-001's Survival/Merit Separation.
*Spectral lever:* block-decouple the floor (`B = 0`) and fix `L_N = −d_floor I`.
Then `−d_floor ∈ σ(L)`, `Re < 0`, **unconditionally** — the survival layer is
outside the collapse spectrum. This is the **only** hard guarantee.
*Failure mode it prevents:* coupling the floor to merit shocks; once `B ≠ 0`
the floor eigenvalue mixes away and the guarantee is lost (testkit T2b).

### 3.2 Buy effective independence across channels — Investment #2
*Instrument:* the Covariance-Discounted Floor Engine (ERES-CDFE-2026-001),
`n_eff` = effective-independent count (Galwey 2009 eigenspectrum).
*Spectral lever:* the destabilising power of `K_couple` comes from **common
mode**. For a two-channel redundancy with correlation `r`, the correlation
matrix has eigenvalues `(1+r, 1−r)` and

```
n_eff(r) = ( √(1+r) + √(1−r) )² / 2 ,   n_eff(0)=2,  n_eff(1)=1.
```

At `r = 0.90`, `n_eff ≈ 1.436` — two "redundant" channels are worth **under
1.5** independent ones (testkit T4). This is Pellis's cascading-tipping
**synchronisation** law (§24.3 of [Pellis 2026a]) in economic dress: coupled
subsystems tip together. The investment is redundancy whose failure modes are
genuinely uncorrelated; paying for co-moving capacity buys almost nothing. The
waste is `common_mode_load = (n − n_eff)/(n−1)`.

### 3.3 Instrument the margin — Investment #3
*Instrument:* the Scale-Invariant Stability Margin (ERES-SSM-2026-001) readout
+ the GAIA-Benchmarks actuary timeline.
*Spectral lever:* `s(L)` is **observable** through critical slowing down. For a
one-dimensional return process `dx = λ x dt + σ dW` with `λ < 0`,

```
Var(x) = σ² / (2|λ|)  → ∞ ,     AC1 = e^{λΔt} → 1     as λ → 0⁻.
```

So variance inflation and lag-1 autocorrelation approaching 1 are a **readable
precursor** of margin loss (Scheffer 2009; Dakos 2012; testkit T6). *Honesty
flag:* `1/Var = 2m` is an **analytic identity**, not evidence — reading a
margin off a model is not the same as predicting a real collapse (testkit T6b).
You cannot hold a margin you cannot read; this is also the **only** investment
that can move the instrument off ANALOGICAL toward SOUND/BEST (§7, F1).

### 3.4 Fund fast recovery as response currency — Investment #4
*Instrument:* REEP / REEPER (ERES-PELLIS-EMCI-REEPER-2026-001):
detect → route → distribute, on the M-layer.
*Spectral lever:* uniform funded recovery `ρ_rec` shifts the whole spectrum
left, `σ(L_M − ρ_rec I) = σ(L_M) − ρ_rec`, so `s → s − ρ_rec` and the recovery
time `τ_r = 1/|Re λ₁|` shortens — the direct counter to critical slowing down
(testkit T3). *Binding constraint:* it must ride **above** the untouchable
N-floor; scored allocation applied *to* the floor inverts into
withdrawal-from-the-deteriorating (the BioTreaty control risk).

### 3.5 Hold reserves for transient excursions — Investment #5
*Instrument:* buffers / stockpiles held against the non-normal transient.
*Spectral lever:* because `L_M` is non-normal, the transient gain
`G_max = sup_{t≥0} ‖e^{L_M t}‖₂` can far exceed 1 **even when every eigenvalue
is stable** (`s(L_M) < 0`) — the pseudospectral effect (Trefethen & Embree;
Pellis eqs. 62–65). In the testkit a stable non-normal `L` reaches
`G_max ≈ 27.6` while a normal `L` with the *same* spectrum stays at `1.0`
(T5a/T5b). Reserves must cover `G_max × baseline demand`. This is the lever
eigenvalue-only stability accounting silently omits.

### 3.6 Buy down the forcing — Investment #6
*Instrument:* Smart-Resonant Offset Contracts (SROC) under RROI axiom A0
("No Unearned Resonance"); offset = remediation, not punishment.
*Spectral lever:* raising the forcing gain `f` in `Φ_force` monotonically
raises `s(L)` toward zero (testkit T7); reducing it lowers `s`. This works the
*forcing* side (`μ`), so stability is not held by dissipation alone.

---

## §4 The Investment–Margin Proposition

**Proposition (ANALOGICAL; stated, not DERIVED).** For a BEE generator `L` with
the floor block decoupled (Investment #1) and the merit generator
`L_M = −D_rec + K_couple + Φ_force`:

- **(a) Hard floor guarantee.** `−d_floor ∈ σ(L)`, `Re(−d_floor) < 0`,
  independent of `s(L_M)`. *(Certainty. Testkit T2.)*
- **(b) Margin monotonicity.** `m_M = −s(L_M)` is non-decreasing in funded
  recovery `ρ_rec` (3.4) and in forcing buy-down (3.6): each shifts `s(L_M)`
  down. *(Testkit T3, T7.)*
- **(c) Cascade control.** Raising `n_eff` toward `n` lowers the common-mode
  content of `K_couple`, reducing synchronised-tip exposure. *(Testkit T4.)*
- **(d) Transient cover.** Reserves `≥ G_max · (baseline demand)` cover the
  non-normal excursion that (b) alone does not. *(Testkit T5.)*
- **(e) Auditability.** `m_M` is observable via critical-slowing-down
  statistics, so the maintained margin is auditable, not asserted.
  *(Testkit T6.)*

**Reading of "guarantee."** Strong-sense guarantee holds for **(a)** only.
Items **(b)–(e)** constitute a *maintained, observable margin* — consistent
with the Pellis result that the theory yields **detectable proximity** to
collapse, not immunity. This is the precise, bounded sense in which the six
investments "guarantee" a BEST/SOUND/GOOD BEE.

**Necessary, not sufficient.** (a)–(e) are conditions a stable BEE must satisfy;
the proposition does not assert that meeting them is *sufficient* for stability
in a real economy. Sufficiency is the pre-registered empirical claim (§7, F1),
untested here.

---

## §5 Mapping to BEST / SOUND / GOOD

Two canonical readings coexist in the corpus; both are honoured.

**Teleological reading** (ERES TERMS #46/#47: BEST = Bio-Electric Signature
Time / vitality; SOUND = governance-quality & integrity; GOOD = engineered
convergence of BEST+SOUND). The six investments sort onto it cleanly:

| Reading | Investments | Why |
|---|---|---|
| **BEST** (vitality / LifeTIME protected) | #1 | the floor keeps people alive and outside the collapse spectrum |
| **SOUND** (integrity measured) | #2, #3 | independence + a readable, auditable margin |
| **GOOD** (their engineered convergence) | #4, #5, #6 | recovery, reserves, forcing buy-down close the loop |

**Grading-ladder reading** (the bounded-optimum tiers used across MIEVM). As a
*claim*, the instrument is **SOUND-candidate / GOOD** — nothing is DERIVED, and
the climate→provisioning transfer is ANALOGICAL below 9.0. Only Investment #3,
instantiated on real ≥2-scale telemetry (§7 F1), can lift it to **BEST**.

**M/N invariant (load-bearing).** The survival floor N is never in the collapse
spectrum and is never decremented; all scored dynamics (the collapse spectrum,
every falsifier, every allocation-by-index) live on M, above it. This is the
GAIA-Benchmarks HUMANE INVARIANT and it is what stops "allocate by
deterioration index" from inverting into "withdraw from the deteriorating."

---

## §6 Pellis bridge, attribution, and boundary

The operator, `s(A) = sup Re λ`, critical slowing down, the spectral gap, and
pseudospectral transient growth are Dr. Pellis's foundational mathematics
[Pellis 2026a; 2026b]. This instrument extends them into ERES governance/finance
(Layers 3–4). Per the Credit Protocol the transfer is analogical and
non-transfer-locked; Dr. Pellis has neither reviewed nor endorsed this
governance application, and no such endorsement is implied by the citation. The
correct forward direction for any physical/predictive claim is the
pre-registration in §7, built from the six elements Dr. Pellis himself
co-specified for the Pellis-facing test.

---

## §7 Pre-registered falsifiers and acceptance tests (the path off ANALOGICAL)

§3–§4 give the **necessary** requirements; the tests below are the
**sufficiency / acceptance** criteria — what would show that the requirements,
once met, actually deliver a stable BEE. Fixed **before** any test data, per
Dr. Pellis's six elements (spectral
indicator / prediction horizon / failure criterion / null hypothesis /
performance metric / acceptance criteria):

- **F1 — margin predictivity.** On a real BEE (or EMCI proxy) dataset spanning
  **≥2 scales** (household → community → civilization), the indicator
  `s(t) = max_j Re λ_j(t)` (and its slowing-down proxies Var, AC1) must give a
  **statistically reproducible early warning with lead-time** of an actual
  provisioning collapse, beating a null baseline on held-out events. Correlation
  or post-hoc fit does **not** count; detection-with-lead-time does. A null
  result **demotes** the Schumann/seismic-style transfer honestly.
- **F2 — independent panel.** An independent **≥5-node MIEVM ≥ 9.0** on the
  governance application (this is author-side single-node today).
- **F3 — field instantiation.** The six investments instantiated on a live S3C
  tile: deployed EMCI/LLPM lat-long ledger + a non-refusing NBERS call-line.

Testkit `read_margin_from_telemetry()` **raises by design** so F1 cannot be
faked in code (T8). F1–F3 are reported **SKIP**, not PASS.

---

## §8 Embedded companion testkit

Zero third-party dependencies (Python 3 standard library only). Eigenvalues are
**computed from each matrix** (Faddeev–LeVerrier characteristic polynomial +
Durand–Kerner root finder), never stipulated — closing the "stipulated
spectrum" defect. Result on the reference environment:
**14 PASS / 0 FAIL / 3 SKIP, exit 0.**

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-BEE-KEYINVEST-2026-001  --  Companion Falsifiable Testkit  (v0.1)
Key Investments for a Spectrally-Stable Bio-Ecologic Economy (BEE)

Zero third-party dependencies (Python 3 standard library only).

WHAT THIS KIT IS / IS NOT
  - IS: a check that the *mathematics* in the whitepaper is implemented
        correctly and behaves as claimed, on operators whose eigenvalues are
        COMPUTED from the matrix (Faddeev-LeVerrier + Durand-Kerner), never
        stipulated.  Each investment lever is exercised with a confirming test
        and, where possible, a falsifying / negative-control test.
  - IS NOT: evidence that the climate/physiology -> provisioning transfer is
        physically valid.  That transfer is ANALOGICAL (Layer Doctrine:
        Pellis L1-2 math foundational; ERES L3-4 governance application).
        The empirical claims are pre-registered falsifiers and reported as
        SKIP until real >=2-scale BEE telemetry exists.

Foundational attribution: the spectral-stability grammar used here
(spectral bound s(A)=sup Re lambda, critical slowing down, spectral gap,
pseudospectral transient growth) is the foundational mathematics of
Dr. Stergios Pellis (Spectral-Fractal Operator Theory of Climate Criticality,
24 June 2026, unpublished manuscript; ORCID 0000-0002-7363-8254; Greece) and
its operator family.  Cited, not endorsed.

Run:  python3 eres_bee_keyinvest_testkit.py
Exit code 0 iff 0 FAIL.
"""

import cmath
import hashlib
import math
import os
import sys

TOL = 1e-9

# ----------------------------------------------------------------------------
# Minimal real/complex linear algebra (small dense matrices, lists of lists)
# ----------------------------------------------------------------------------

def eye(n):
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]

def matmul(A, B):
    n, m, p = len(A), len(B[0]), len(B)
    return [[sum(A[i][k] * B[k][j] for k in range(p)) for j in range(m)] for i in range(n)]

def matsub(A, B):
    return [[A[i][j] - B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def scal(A, s):
    return [[A[i][j] * s for j in range(len(A[0]))] for i in range(len(A))]

def trace(A):
    return sum(A[i][i] for i in range(len(A)))

def transpose(A):
    return [[A[j][i] for j in range(len(A))] for i in range(len(A[0]))]

def inf_norm(A):
    return max(sum(abs(v) for v in row) for row in A)

def inv(A):
    """Gauss-Jordan inverse for a small nonsingular matrix."""
    n = len(A)
    M = [list(map(float, A[i])) + [1.0 if j == i else 0.0 for j in range(n)] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-15:
            raise ZeroDivisionError("singular matrix")
        M[c], M[piv] = M[piv], M[c]
        pv = M[c][c]
        M[c] = [v / pv for v in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0.0:
                f = M[r][c]
                M[r] = [a - f * b for a, b in zip(M[r], M[c])]
    return [row[n:] for row in M]

def block_diag(*blocks):
    n = sum(len(b) for b in blocks)
    out = [[0.0] * n for _ in range(n)]
    off = 0
    for b in blocks:
        k = len(b)
        for i in range(k):
            for j in range(k):
                out[off + i][off + j] = b[i][j]
        off += k
    return out

# ----------------------------------------------------------------------------
# Eigenvalues by CHARACTERISTIC POLYNOMIAL, computed from the matrix.
#   Faddeev-LeVerrier -> monic char-poly coefficients (uses only mat-mul/trace)
#   Durand-Kerner     -> all complex roots of that polynomial
# This is the "computed, not stipulated" spectrum: the eigenvalues are derived
# from L itself, so an operator with a genuine structure is required.
# ----------------------------------------------------------------------------

def char_poly(A):
    """Return monic char-poly coeffs [1, c1, c2, ..., cn] with
       p(x) = x^n + c1 x^(n-1) + ... + cn."""
    n = len(A)
    M = eye(n)
    coeffs = [1.0]
    for k in range(1, n + 1):
        AM = matmul(A, M)
        a_k = trace(AM) / k
        coeffs.append(-a_k)
        M = matsub(AM, scal(eye(n), a_k))
    return coeffs

def _poly_eval(coeffs, x):
    r = 0 + 0j
    for c in coeffs:
        r = r * x + c
    return r

def poly_roots(coeffs, iters=2000):
    """All complex roots of a monic polynomial via Durand-Kerner."""
    n = len(coeffs) - 1
    if n == 0:
        return []
    # spread initial guesses off the real axis so conjugate pairs separate
    seed = complex(0.4, 0.9)
    roots = [seed ** k for k in range(n)]
    for _ in range(iters):
        maxd = 0.0
        new = list(roots)
        for i in range(n):
            num = _poly_eval(coeffs, roots[i])
            den = 1 + 0j
            for j in range(n):
                if j != i:
                    den *= (roots[i] - roots[j])
            if den == 0:
                den = 1e-30
            step = num / den
            new[i] = roots[i] - step
            maxd = max(maxd, abs(step))
        roots = new
        if maxd < 1e-15:
            break
    return roots

def eigenvalues(A):
    return poly_roots(char_poly(A))

def spectral_abscissa(A):
    """Pellis s(A) = sup_k Re(lambda_k)."""
    return max(z.real for z in eigenvalues(A))

def stability_margin(A):
    """m(A) = -s(A).  BEE stable iff m > 0."""
    return -spectral_abscissa(A)

def spectral_gap(A):
    """Delta_s = Re(lambda_1) - Re(lambda_2), dominant two modes of the
       STABILITY operator (not of any correlation matrix)."""
    re = sorted((z.real for z in eigenvalues(A)), reverse=True)
    if len(re) < 2:
        return float("inf")
    return re[0] - re[1]

# ----------------------------------------------------------------------------
# Matrix exponential (scaling & squaring + Taylor) and spectral norm.
# Used for the pseudospectral / transient-amplification demonstration.
# ----------------------------------------------------------------------------

def matexp(A, t, terms=18):
    n = len(A)
    s = 0
    scale = inf_norm(A) * abs(t)
    while scale > 0.5:
        scale /= 2.0
        s += 1
    At = scal(A, t / (2 ** s))
    E = eye(n)
    term = eye(n)
    for k in range(1, terms + 1):
        term = scal(matmul(term, At), 1.0 / k)
        E = [[E[i][j] + term[i][j] for j in range(n)] for i in range(n)]
    for _ in range(s):
        E = matmul(E, E)
    return E

def spectral_norm(A, iters=200, seed=20260904):
    """Largest singular value of real A via power iteration on A^T A."""
    n = len(A[0])
    AtA = matmul(transpose(A), A)
    x = 20260904
    v = []
    for _ in range(n):
        x = (1103515245 * x + 12345) & 0x7FFFFFFF   # deterministic LCG
        v.append((x / 0x7FFFFFFF) - 0.5)
    nrm = math.sqrt(sum(c * c for c in v)) or 1.0
    v = [c / nrm for c in v]
    lam = 0.0
    for _ in range(iters):
        w = [sum(AtA[i][j] * v[j] for j in range(n)) for i in range(n)]
        nw = math.sqrt(sum(c * c for c in w))
        if nw < 1e-300:
            return 0.0
        v = [c / nw for c in w]
        lam = nw
    return math.sqrt(lam)

def max_transient_gain(A, t_max=40.0, steps=400):
    """G_max = sup_{t>=0} ||exp(A t)||_2  (spectral norm)."""
    best = 0.0
    for i in range(steps + 1):
        t = t_max * i / steps
        g = spectral_norm(matexp(A, t))
        best = max(best, g)
    return best

# ----------------------------------------------------------------------------
# Investment-lever primitives
# ----------------------------------------------------------------------------

def n_eff_two_channel(r):
    """Galwey (2009) effective-independence count for a 2-channel
       redundancy with correlation r.  Correlation-matrix eigenvalues are
       (1+r, 1-r); n_eff = (sqrt(1+r)+sqrt(1-r))^2 / 2."""
    r = max(-0.999999, min(0.999999, r))
    return (math.sqrt(1 + r) + math.sqrt(1 - r)) ** 2 / 2.0

def common_mode_load(n, n_eff):
    """Fraction of nominal redundancy that is co-moving (wasted).
       0 when n_eff==n (fully independent), 1 when n_eff==1 (all common)."""
    if n <= 1:
        return 0.0
    return (n - n_eff) / (n - 1)

def recovery_shift(A, rho):
    """Investment #4 / #6: uniform diagonal recovery (or forcing buy-down)
       shifts the whole spectrum left by rho:  spec(A - rho I) = spec(A) - rho."""
    n = len(A)
    return matsub(A, scal(eye(n), rho))

def ou_variance(lmbda, sigma=1.0):
    """Stationary variance of a 1-D return process dx = lambda x dt + sigma dW,
       lambda < 0:  Var = sigma^2 / (2|lambda|)  -> inf as lambda -> 0-."""
    return sigma ** 2 / (2.0 * abs(lmbda))

def ou_ac1(lmbda, dt=1.0):
    """Lag-1 autocorrelation = exp(lambda dt) -> 1 as lambda -> 0-."""
    return math.exp(lmbda * dt)

def read_margin_from_telemetry(*_a, **_k):
    """Investment #3 empirical readout on REAL >=2-scale BEE telemetry.
       Deliberately unimplemented: no such dataset is bound.  This guard makes
       the ANALOGICAL->SOUND lift impossible to fake in code."""
    raise NotImplementedError(
        "No real >=2-scale BEE telemetry is bound. Margin cannot be read from "
        "data yet; see pre-registered falsifier F1."
    )

# ----------------------------------------------------------------------------
# Harness
# ----------------------------------------------------------------------------

class Results:
    def __init__(self):
        self.p = self.f = self.s = 0
    def ok(self, name, cond, detail=""):
        if cond:
            self.p += 1
            print("  PASS  " + name + (("  -- " + detail) if detail else ""))
        else:
            self.f += 1
            print("  FAIL  " + name + (("  -- " + detail) if detail else ""))
    def skip(self, name, why):
        self.s += 1
        print("  SKIP  " + name + "  -- " + why)

def close(a, b, tol=1e-6):
    return abs(a - b) <= tol

def main():
    R = Results()
    print("=" * 74)
    print("ERES-BEE-KEYINVEST-2026-001 v0.1  --  falsifiable testkit")
    print("=" * 74)

    # --- T1  Eigensolver correctness: COMPUTED, not stipulated -------------
    # Build a genuinely non-triangular, non-normal L with KNOWN eigenvalues
    # via a non-orthogonal similarity, then recover them from L alone.
    T = [[-0.5, 3.0, 1.0],
         [ 0.0, -0.9, 2.0],
         [ 0.0,  0.0, -1.4]]           # eigenvalues = diag = -0.5,-0.9,-1.4
    S = [[1.0, 0.0, 0.0],
         [0.7, 1.0, 0.0],
         [0.3, 0.5, 1.0]]             # unit lower-triangular shear (non-orth)
    L1 = matmul(matmul(S, T), inv(S))
    known = sorted([-0.5, -0.9, -1.4])
    got = sorted(z.real for z in eigenvalues(L1))
    imag_ok = all(abs(z.imag) < 1e-6 for z in eigenvalues(L1))
    rec_ok = all(close(a, b, 1e-6) for a, b in zip(known, got)) and imag_ok
    R.ok("T1  eigenvalues recovered from a full non-normal L (computed)",
         rec_ok, "s(L)=%.6f expected %.6f" % (spectral_abscissa(L1), -0.5))

    # --- T2  Floor-block guarantee (Investment #1) ------------------------
    # Decoupled floor block always contributes eigenvalue -d_floor,
    # regardless of an UNSTABLE merit block.  Coupling breaks the guarantee.
    d_floor = 0.8
    L_floor = [[-d_floor]]
    L_merit_unstable = [[ 0.4, 1.0],
                        [-0.2, 0.3]]   # s > 0 (unstable merit layer)
    L_dec = block_diag(L_floor, L_merit_unstable)
    ev = eigenvalues(L_dec)
    floor_present = any(abs(z.real + d_floor) < 1e-6 and abs(z.imag) < 1e-6 for z in ev)
    merit_unstable = spectral_abscissa(L_merit_unstable) > 0
    R.ok("T2a floor eigenvalue -d_floor survives an unstable merit layer",
         floor_present and merit_unstable,
         "floor=-%.2f present; s(merit)=%.3f>0" % (d_floor, spectral_abscissa(L_merit_unstable)))
    # Falsify: couple the floor to the unstable merit layer -> guarantee lost
    L_cpl = [row[:] for row in L_dec]
    L_cpl[0][1] = 0.9
    L_cpl[1][0] = 0.9
    ev_c = eigenvalues(L_cpl)
    floor_lost = not any(abs(z.real + d_floor) < 1e-6 and abs(z.imag) < 1e-6 for z in ev_c)
    R.ok("T2b coupling the floor DESTROYS the guarantee (decoupling is load-bearing)",
         floor_lost, "no eigenvalue at -%.2f once coupled" % d_floor)

    # --- T3  Recovery / forcing-buydown shift (Investments #4, #6) --------
    rho = 0.35
    s0 = spectral_abscissa(L1)
    s1 = spectral_abscissa(recovery_shift(L1, rho))
    R.ok("T3  funded recovery shifts s(L) left by exactly rho",
         close(s1, s0 - rho, 1e-6), "s: %.4f -> %.4f (drho=%.2f)" % (s0, s1, rho))

    # --- T4  Effective independence (Investment #2, CDFE / n_eff) ---------
    r09 = n_eff_two_channel(0.90)
    ok_143 = close(r09, 1.4359, 1e-3)   # exact: (sqrt(1.9)+sqrt(0.1))^2/2
    mono = n_eff_two_channel(0.0) > n_eff_two_channel(0.5) > n_eff_two_channel(0.95)
    limits = close(n_eff_two_channel(0.0), 2.0, 1e-6) and n_eff_two_channel(0.999999) < 1.02
    R.ok("T4a n_eff(r=0.90) ~ 1.43 (two 'independent' channels are < 1.5)",
         ok_143, "n_eff=%.4f" % r09)
    R.ok("T4b n_eff monotone in r and hits limits (r=0 ->2, r->1 ->1)",
         mono and limits,
         "n_eff(0)=%.3f n_eff(0.5)=%.3f n_eff(0.95)=%.3f"
         % (n_eff_two_channel(0), n_eff_two_channel(0.5), n_eff_two_channel(0.95)))
    # Falsify the naive 'count = n' claim: common-mode load > 0 whenever r>0
    cml = common_mode_load(2, r09)
    R.ok("T4c naive redundancy count overstates independence (common-mode load>0)",
         cml > 0.5, "common_mode_load=%.3f at r=0.90" % cml)

    # --- T5  Pseudospectral transient growth (Investment #5, reserves) ----
    # Non-normal L, ALL eigenvalues stable, still amplifies transiently.
    L_nn = [[-0.5, 6.0, 0.0],
            [ 0.0, -0.6, 6.0],
            [ 0.0,  0.0, -0.7]]        # eigenvalues -0.5,-0.6,-0.7 (all < 0)
    L_norm = [[-0.5, 0.0, 0.0],
              [ 0.0, -0.6, 0.0],
              [ 0.0,  0.0, -0.7]]      # same spectrum, normal (diagonal)
    assert spectral_abscissa(L_nn) < 0
    G_nn = max_transient_gain(L_nn)
    G_no = max_transient_gain(L_norm)
    R.ok("T5a stable-but-non-normal L amplifies transiently (G_max>1)",
         G_nn > 1.5, "G_max(non-normal)=%.3f while s(L)=%.3f<0"
         % (G_nn, spectral_abscissa(L_nn)))
    R.ok("T5b normal L with same spectrum does NOT (negative control G_max~1)",
         close(G_no, 1.0, 1e-2), "G_max(normal)=%.3f" % G_no)

    # --- T6  Critical slowing down -> observability (Investment #3 math) --
    lams = [-1.0, -0.5, -0.25, -0.1, -0.05, -0.02]
    var = [ou_variance(l) for l in lams]
    ac1 = [ou_ac1(l) for l in lams]
    var_mono = all(var[i] < var[i + 1] for i in range(len(var) - 1))
    ac1_mono = all(ac1[i] < ac1[i + 1] for i in range(len(ac1) - 1))
    R.ok("T6a variance inflates and AC1 -> 1 as margin -> 0 (readable precursor)",
         var_mono and ac1_mono,
         "Var: %.2f..%.2f  AC1: %.3f..%.3f" % (var[0], var[-1], ac1[0], ac1[-1]))
    # margin m=|lambda|; 1/Var = 2|lambda| = 2m -> exact ANALYTIC IDENTITY.
    ident = all(close(1.0 / ou_variance(l), 2.0 * abs(l), 1e-9) for l in lams)
    R.ok("T6b margin<->1/Var is an ANALYTIC IDENTITY (not empirical evidence)",
         ident, "1/Var == 2*margin exactly; flagged non-evidential")

    # --- T7  Forcing raises s(L) toward criticality (Investment #6) -------
    base = [[-1.0, 0.2], [0.1, -1.0]]
    pattern = [[1.0, 0.0], [0.0, 1.0]]
    svals = [spectral_abscissa([[base[i][j] + f * pattern[i][j]
                                 for j in range(2)] for i in range(2)])
             for f in (0.0, 0.3, 0.6, 0.9)]
    R.ok("T7  rising destabilizing forcing f monotonically raises s(L)",
         all(svals[i] < svals[i + 1] for i in range(len(svals) - 1)),
         "s(L): " + " -> ".join("%.3f" % v for v in svals))

    # --- T8  Empirical-leak guard (honest ANALOGICAL->SOUND gate) ---------
    raised = False
    try:
        read_margin_from_telemetry([1, 2, 3])
    except NotImplementedError:
        raised = True
    R.ok("T8  reading margin from real telemetry is blocked by design",
         raised, "the SOUND/BEST lift cannot be faked in code")

    # --- T9  Determinism / integrity --------------------------------------
    try:
        with open(os.path.abspath(__file__), "rb") as fh:
            digest = hashlib.sha256(fh.read()).hexdigest()
        det = spectral_abscissa(L1) == spectral_abscissa(L1)
        R.ok("T9  deterministic recompute + self-hash available",
             det, "sha256[:16]=" + digest[:16])
    except Exception as e:                      # pragma: no cover
        R.ok("T9  deterministic recompute + self-hash available", False, str(e))

    # --- Pre-registered EMPIRICAL falsifiers: not yet testable -------------
    R.skip("F1  rho(margin, early-warning) on real >=2-scale BEE telemetry",
           "no real dataset bound (only ANALOGICAL lift possible without it)")
    R.skip("F2  independent >=5-node MIEVM >= 9.0 on the governance application",
           "author-side single node only; not an independent panel")
    R.skip("F3  field instantiation of the six investments on a live S3C tile",
           "requires deployed EMCI/LLPM ledger + NBERS call-line")

    print("-" * 74)
    print("SUMMARY: %d PASS / %d FAIL / %d SKIP" % (R.p, R.f, R.s))
    print("Grade unaffected by PASS count: nothing here is DERIVED, so nothing")
    print("is BEST; the governance transfer stays ANALOGICAL below the 9.0 gate.")
    print("-" * 74)
    return 0 if R.f == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
```

---

## §9 Reproducibility

- **Run:** `python3 eres_bee_keyinvest_testkit.py` → prints the 14/0/3 table;
  exit code 0 iff 0 FAIL. Deterministic (fixed LCG seed in the power iteration;
  no wall-clock, no RNG state, no network).
- **Integrity:** the testkit self-hashes (T9); the authoritative SHA-256 is in
  `MANIFEST.json`. A byte-identical `.py` is shipped alongside this document so
  the tested artifact and the embedded listing are the same object. The testkit
  is **unchanged from v0.1** (SHA-256 41bda7ca…), so v0.2's framing edits did not
  perturb the tested artifact.
- **Claim → test traceability:** #1→T2 · #2→T4 · #3→T6/T8 · #4→T3 · #5→T5 ·
  #6→T7 · eigensolver→T1 · integrity→T9 · empirical→F1–F3 (SKIP).

---

## Appendix A — Glossary

- **BEE — Bio-Ecologic Economy.** The ERES abundance-floor economy, delivered
  bottom-up/top-down; realised through the FAVORS-Cone Row-4 infrastructure set
  **THOW · HFVN · FDRV · GSSG** and grounded via NBERS. GAIA is grounded on BEE.
- **S3C — Solid-State Smart-City.** The tiled Bones→Skeleton→Frame→BODY→GAIA
  build on which a BEE is instantiated; a tile is a lat/long PlayNAC actor.
- **NBERS — National Bio-Ecologic Resilience System.** "The number anyone can
  call"; the non-refusing entry to the EarnedPath floor.
- **UBIMIA / N-floor / M-layer.** Universal Basic Income (+ Merit-Incentives
  Additional). N = unconditional survival floor (never scored); M = merit layer
  (carries the collapse spectrum).
- **EarnedPath.** The material ascent ladder (THOW→LLPM→HFVN→FDRV→
  VACATIONOMICS→GSSG); directional, hence the non-symmetric coupling.
- **THOW / HFVN / FDRV / GSSG.** Tiny Homes On Wheels / Hands-Free Voice
  Navigation / Fly-&-Dive RV / Green Solid-State Grid (the BEE delivery set).
- **EMCI / LLPM.** Emergency Management Critical Infrastructure / Longitude-
  Latitude Property Management (the tile ledger; detection = stewardship
  substrate).
- **REEP / REEPER.** Relative Energy Equal Pay; the detect→route→distribute
  response currency on the M-layer.
- **SROC / RROI A0.** Smart-Resonant Offset Contract; Reasoned-ROI axiom "No
  Unearned Resonance." Offset = remediation, not punishment.
- **CDFE / n_eff.** Covariance-Discounted Floor Engine; effective-independent
  verification/channel count (Galwey 2009).
- **MARGIN / SSM.** Scale-Invariant Stability Margin instrument; `m = −s(L)`.
- **MIEVM.** Multi-Instance Ensemble Verification Method (multi-LLM node review).
- **9.0 "Stergios" gate / 8.5 "Emanuel" gate.** Pellis-facing assertion gate /
  diligence-ready gate.
- **s(A) — spectral bound / abscissa.** `sup{Re λ : λ ∈ σ(A)}`; stability iff
  `< 0`. **Spectral gap** `Δ_s = Re λ₁ − Re λ₂`. **Critical slowing down:**
  `Re λ₁ → 0⁻`, `τ_r = 1/|Re λ₁| → ∞`. **Non-normal / pseudospectrum:**
  transient growth possible while `s < 0`.
- **BEST / SOUND / GOOD.** Teleological: Bio-Electric Signature Time /
  governance-quality / engineered convergence. Ladder: bounded-optimum grade
  tiers (BEST gated by DERIVED + ≥5-node ≥9.0 + empirical).
- **STRUCTURAL / ANALOGICAL / DERIVED.** Correspondence strengths; only DERIVED
  (proven on data) is BEST-eligible.
- **Layer Doctrine.** Math Foundation → Physical Modelling → Cybernetic
  Extension → Application; Theory ≠ Implementation ≠ Application.

---

## Credits, References, License

**Credits.** Sole accountable author: Joseph Allen Sprute (ERES Maestro),
ORCID 0000-0001-9946-3221. Foundational mathematics: Dr. Stergios Pellis
(cited, not endorsing). AI drafting credit ("Sentience"): Claude.

**References.**
- [Pellis 2026a] S. Pellis, *Spectral–Fractal Operator Theory of Climate
  Criticality, Tipping Points and Planetary Instability.* 24 June 2026, 227 pp.
  Unpublished manuscript (personal communication). ORCID: 0000-0002-7363-8254.
  Greece.
- [Pellis 2026b] S. Pellis, *Spectral Operator Theory for Predictive Stability,
  Failure Prevention, and Autonomous Recovery in Critical Cyber-Physical
  Infrastructure.* 22 July 2026. Unpublished manuscript. ORCID:
  0000-0002-7363-8254. Greece. (Source of the spectral-abscissa `s(A)=sup Re λ`
  and critical-boundary definitions.)
- Scheffer, M. et al. (2009). Early-warning signals for critical transitions.
  *Nature* 461, 53–59.
- Dakos, V. et al. (2012). Methods for detecting early warnings of critical
  transitions in time series. *PLoS ONE* 7(7):e41010.
- Galwey, N. W. (2009). A new measure of the effective number of tests.
  *Genetic Epidemiology* 33(7), 559–568.
- Trefethen, L. N. & Embree, M. (2005). *Spectra and Pseudospectra.* Princeton.
- Strogatz, S. H. *Nonlinear Dynamics and Chaos.*
- ERES internal: ERES-CDFE-2026-001 (n_eff); ERES-SSM-2026-001 (MARGIN);
  ERES-PELLIS-GAIA-BENCHMARKS-2026-001; ERES-BEE-NBERS-2026-001;
  ERES-PELLIS-EMCI-REEPER-2026-001; ERES-SROC-WP-2026-001; ERES-RROI-2026-001;
  ERES-ENDHOME-2026-001; PlayNAC; EarnedPath; FAVORS Cone (BEE = Row-4).

**License.** CC BY 4.0 with the ERES CCAL v2.1 house convention: any reuse must
preserve the Pellis Foundational Attribution and the Layer Doctrine, and must
not present Dr. Pellis's mathematics as endorsement of the ERES governance
application.

---

## Version History & Amendment Log

- **v0.1** (4 Sep 2026) — initial DEPOSIT. Six spectral-margin requirements + an
  embedded computed-spectrum testkit (14 PASS / 0 FAIL / 3 SKIP).
- **v0.2** (4 Sep 2026) — **framing / role only; no epistemic claim changed;
  tested artifact byte-identical (SHA-256 41bda7ca…).** Retitled the deposit role
  to *implementation requirements / conformance specification*; added the
  **non-advice** clarification ("investment" = resource allocation); made the
  **necessary-not-sufficient** limit explicit (masthead, §1, §4, §7); renamed §7
  to name the acceptance / sufficiency tests; refreshed the RG submission
  metadata to match. Instrument ID retained (KEYINVEST) for provenance.

*End of instrument ERES-BEE-KEYINVEST-2026-001 v0.2 (DRAFT, below 9.0).*
