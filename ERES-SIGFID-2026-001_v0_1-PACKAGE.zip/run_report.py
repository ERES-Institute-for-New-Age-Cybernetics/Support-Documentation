#!/usr/bin/env python3
"""Executes the signature-fidelity core on mapped simulation data and shows the math."""
import csv, importlib.util, statistics as st, math
spec = importlib.util.spec_from_file_location("h", "signature_fidelity_harness.py")
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)

N_SUBJ, N_SESS, DIM, SEED = 24, 6, 8, 1

def write_csv(kind, path):
    op1, op2 = h.make_world(kind, n_subjects=N_SUBJ, n_sessions=N_SESS, dim=DIM, seed=SEED)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["operator","sid","session","confound"] + [f"f{i+1}" for i in range(DIM)])
        for opname, rows in [("A", op1), ("B", op2)]:
            for r in rows:
                w.writerow([opname, r["sid"], r["session"], f"{r['confound']:.5f}"]
                           + [f"{x:.5f}" for x in r["feat"]])
    return op1, op2

print("="*72)
print("MAPPED SIMULATION DATA  —  %d subjects x %d sessions x 2 operators x %d features"
      % (N_SUBJ, N_SESS, DIM))
print("  chance identification accuracy = 1/%d = %.4f" % (N_SUBJ, 1/N_SUBJ))
print("="*72)

worlds = {}
for kind in ("natural", "confound", "idiosyncratic"):
    op1, op2 = write_csv(kind, f"readings_{kind}.csv")
    worlds[kind] = (op1, op2)
    print(f"  wrote readings_{kind}.csv  ({len(op1)+len(op2)} rows)")

# ---------------------------------------------------------------- MATH, shown
def show_icc_dim(readings, j):
    from collections import defaultdict
    by = defaultdict(list)
    for r in readings: by[r["sid"]].append(r["feat"][j])
    groups = list(by.values())
    allv = [x for g in groups for x in g]
    grand = sum(allv)/len(allv)
    k = sum(len(g) for g in groups)/len(groups)
    n = len(groups)
    ssb = sum(len(g)*(sum(g)/len(g)-grand)**2 for g in groups)
    ssw = sum(sum((x-sum(g)/len(g))**2 for x in g) for g in groups)
    msb = ssb/(n-1); msw = ssw/(len(allv)-n)
    icc = (msb-msw)/(msb+(k-1)*msw)
    return msb, msw, k, n, icc

print("\n" + "-"*72)
print("MATH — WORLD_NATURAL, operator A")
print("-"*72)
opA = worlds["natural"][0]
msb, msw, k, n, icc0 = show_icc_dim(opA, 0)
print("G1 ICC(1,1), dim f1:")
print(f"    MS_between={msb:.3f}  MS_within={msw:.3f}  k={k:.0f}  n={n}")
print(f"    ICC = (MS_b - MS_w)/(MS_b + (k-1)*MS_w)")
print(f"        = ({msb:.3f} - {msw:.3f})/({msb:.3f} + {k-1:.0f}*{msw:.3f}) = {icc0:.3f}")
print(f"    mean per-dimension ICC (all {DIM} dims) = {h.mean_dimension_icc(opA):.3f}")

acc = h.loso_identification(opA)
pm, plo, phi = h.permutation_chance(opA, seed=1)
print("\nG2 discriminability (leave-one-session-out nearest-centroid):")
print(f"    balanced acc = {acc:.3f}")
print(f"    permutation null (shuffled labels): mean={pm:.3f}  95%CI=[{plo:.3f},{phi:.3f}]")
print(f"    acc {acc:.3f} >> null-hi {phi:.3f}  ->  above chance")

conf = [r["confound"] for r in opA]
col0 = [r["feat"][0] for r in opA]
b = h.pearson(col0, conf); sd_f = st.pstdev(col0); sd_c = st.pstdev(conf)
slope = b*sd_f/sd_c; inter = sum(col0)/len(col0) - slope*(sum(conf)/len(conf))
print("\nG3 confound residualization, dim f1:")
print(f"    corr(f1, confound)={b:.3f}   slope=r*sd_f/sd_c={slope:.3f}   intercept={inter:.3f}")
print(f"    residual_i = f1_i - ({inter:.3f} + {slope:.3f}*confound_i)")
oA = h.evaluate_operator(opA, h.TH, seed=1)
print(f"    acc on residualized features = {oA['g3_acc_resid']:.3f}  (null-hi {oA['g3_chance_hi']:.3f})")

oA2 = h.evaluate_operator(worlds["natural"][1], h.TH, seed=8)
g4 = h.inter_operator_convergence(oA, oA2, h.TH, seed=1)
print("\nG4 inter-operator convergence (per-dim Pearson r of residual subject-means):")
print(f"    mean cross-operator r = {g4['convergence']:.3f}   shuffle-null-hi = {g4['baseline_hi']:.3f}")

# ---------------------------------------------------------- the two falsifiers
print("\n" + "-"*72)
print("THE TWO FALSIFIERS (discriminating numbers)")
print("-"*72)
oC = h.evaluate_operator(worlds["confound"][0], h.TH, seed=1)
print("WORLD_CONFOUND  (signal IS the confound):")
print(f"    G2 raw acc          = {oC['g2_acc']:.3f}   (looks like a signature)")
print(f"    G3 residualized acc = {oC['g3_acc_resid']:.3f}   null-hi={oC['g3_chance_hi']:.3f}  -> COLLAPSES -> G3 FAIL")
oI1 = h.evaluate_operator(worlds["idiosyncratic"][0], h.TH, seed=1)
oI2 = h.evaluate_operator(worlds["idiosyncratic"][1], h.TH, seed=8)
g4i = h.inter_operator_convergence(oI1, oI2, h.TH, seed=1)
print("WORLD_IDIOSYNCRATIC (each operator a private latent):")
print(f"    G3 residualized acc = {oI1['g3_acc_resid']:.3f}  (reliable & confound-clean per operator)")
print(f"    G4 convergence r    = {g4i['convergence']:.3f}   null-hi={g4i['baseline_hi']:.3f}  -> NO CONVERGENCE -> G4 FAIL")
