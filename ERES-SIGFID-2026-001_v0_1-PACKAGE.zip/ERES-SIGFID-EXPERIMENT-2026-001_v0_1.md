# The Signature-Fidelity Experiment
### Testing the natural-measurement root of ERES certification

**ID:** ERES-SIGFID-EXPERIMENT-2026-001 · **Version:** v0.1 PROPOSED (pre-canonical, not MIEVM-rated)
**Author:** Joseph A. Sprute, ERES Institute for New Age Cybernetics · **Date:** 6 Aug 2026
**License:** CCAL v2.1 / CC BY 4.0 · **Standing:** pre-registration draft for external execution

---

## 0. What this tests — and what it does not

The ERES certification chain terminates in a claim that the certifying authority is
**"parallel in Nature"**: a self carries a stable natural signature (bio-electric /
resonant), and legitimacy is not *conferred* by a body but *found* by measurement, so
recognition is **convergence** — independent measurers re-reading the same fact and
agreeing, the way a physical constant is agreed. Everything above this rung
(EarnedPath, GAIA benchmarks, UBIMIA standing, HPE) inherits its legitimacy from it.

That root reduces to one empirical question:

> Does the signature reading track a **real, self-distinctive natural fact** that
> **survives confound control** and on which **independent instruments converge** —
> or is the apparent signal a physiological/environmental **confound** (a "found"
> mimic) or a per-instrument **projection** (a "conferred" mimic in disguise)?

**In scope:** whether a stable, discriminable, confound-independent, inter-operator-convergent
signal exists at all.
**Explicitly out of scope:** what the signal *means*. Even a full pass does **not**
show the signature tracks merit, values, resonance-as-character, or HPE. That is a
separate construct-validity chain, only worth running *after* this one passes. This
experiment tests the root of the root — the precondition for the rest to be about anything.

---

## 1. Hypotheses

- **H1 (fidelity):** After confound control, signature readings are (a) reliable within
  a self, (b) discriminate selves above a permutation null, and (c) converge across two
  independent instruments/operators blind to each other.
- **H0 (null):** Apparent signature structure is fully explained by measured confounds
  (with them partialled, discriminability falls to the permutation null) **or** is
  instrument-private (per-operator reliable but non-convergent).

H0 is not a strawman: electrophotonic / bioelectric readings are historically driven by
skin moisture, contact pressure, temperature, humidity, and electrode placement. A
protocol that cannot separate signal from these establishes nothing.

---

## 2. The four nested gates (pre-registered)

A higher gate counts only if all lower gates pass. Thresholds are pre-registered here and
must be fixed *before* collection. Significance is set by a label-permutation null (2.5%
tail); the accuracy floors are an additional effect-size guard.

| Gate | Claim | Statistic | Pass rule (pre-registered) |
|---|---|---|---|
| **G1 Reliability** | same self reads the same | mean per-dimension ICC(1,1) | ICC ≥ 0.60 |
| **G2 Discriminability** | readings identify the self | leave-one-session-out nearest-centroid balanced accuracy | acc > permutation-97.5% **and** acc ≥ 0.15 (≈3× chance @24) |
| **G3 Confound-independence** | signal isn't the nuisance | G2 re-run on confound-**residualized** features | acc_resid > permutation-97.5% **and** ≥ 0.15 |
| **G4 Convergence** | it's a shared natural fact | cross-operator correlation of per-self residual means | r > shuffle-97.5% **and** r ≥ 0.35 |

**G3 is the confound falsifier. G4 is the fiat/projection falsifier.** They map one-to-one
onto the two ways "parallel in Nature" can be false.

---

## 3. Design

- **Subjects:** ≥ 24, pre-enrolled, no self-selection into conditions. (Run the harness
  power mode at your instrument's expected effect size to confirm N *before* collecting.)
- **Sessions:** ≥ 6 per subject, spread across ≥ 3 days (captures day-to-day state, not
  one sitting). Randomized subject order each session.
- **Operators/instruments:** ≥ 2, **independent** — different device unit (ideally
  different make/modality), different operator, physically separated, **blind to each
  other's readings and to subject identity** (subjects coded). This independence is the
  whole G4 test; do not let operators calibrate to each other.
- **Analyst blinding:** analysis is scripted and pre-registered (the harness). Condition
  labels revealed only after the gate vector is computed.

---

## 4. Confounds — measured every reading, not assumed away

Log, per reading, with independent instruments (not the signature device):

- skin hydration / conductance baseline (corneometer or equivalent)
- contact pressure (load cell) and contact area
- fingertip/skin temperature (thermistor)
- ambient temperature + relative humidity (logger)
- supply voltage / device self-calibration value
- time-of-day; hours since caffeine/food/exercise; hours slept (state covariates)

These become the columns G3 residualizes against. Unmeasured confounds cannot be
partialled — enumerate and measure them *first*.

---

## 5. Measurement standardization

Fixed hand/finger, cleaned contact, fixed acclimatization time, fixed capture duration,
fixed posture, identical settings across operators. Deviations logged as covariates.
Feature extraction (the `f1..fN` vector) is defined and frozen before collection.

---

## 6. Pre-registration, analysis, stopping

1. Freeze: feature definition, the four thresholds, N, session count, confound list, this document.
2. Collect to a CSV: `operator,sid,session,confound,f1..fN` (one row per reading).
3. Run `signature_fidelity_harness.py --data readings.csv`. It prints the gate vector and verdict.
4. **Stopping rule:** no peeking at the gate vector mid-collection; analyze once at target N.
   Report the full vector whatever it shows — a first-gate FAIL is a publishable result.

`confound` in the CSV is a single summary channel for the built-in partialling; for
multi-channel confound control, residualize on each channel before writing the column, or
extend the harness's `ols_residualize` step (documented inline).

---

## 7. Falsifiers (explicit)

- **F1 (G1):** ICC < 0.60 → readings aren't even repeatable; nothing to certify.
- **F2 (G2):** identification not above permutation null → no distinctive signal.
- **F3 (G3):** discriminability vanishes after confound partialling → **the "signature"
  was the confound.** This is the historically most likely failure and the one the whole
  design exists to catch.
- **F4 (G4):** operators don't converge → each instrument reads its own private fact;
  the authority is **conferred by the apparatus, not found in Nature** — legitimacy-by-fiat
  wearing a natural mask.

Any single failure falsifies the parallel-in-Nature root *at that gate*, and the ERES
certification chain above it loses its empirical floor until the gate is met.

---

## 8. Power (do this before spending on subjects)

The harness's synthetic mode is also a power tool: set your instrument's *expected*
effect size and dimensionality in `make_world`, sweep `n_subjects`/`n_sessions`, and read
off where G2/G3 clear the permutation band reliably. Only enroll once the synthetic run at
your realistic effect size passes at your planned N. If it doesn't, the experiment is
underpowered before it starts.

---

## 9. Interpretation matrix

| Gate vector | Reading |
|---|---|
| G1..G4 all pass | Signature is a real, self-distinctive, confound-independent, convergent natural fact. Root **earned**. Proceed to construct-validity (does it *mean* anything). |
| G1,G2 pass · G3 fail | It's a stable confound (e.g. hydration). Fix the instrument or the claim. |
| G1,G2,G3 pass · G4 fail | Reliable and confound-clean per operator, but not shared. Instrument-private projection — not a fact of Nature. |
| G1 fail | Not repeatable. Stop; nothing downstream is well-defined. |

---

## 10. Scope, ethics, honesty

- Human-subjects: informed consent, IRB/ethics review, data minimization, subject codes not names.
- Passing establishes **fidelity**, not **meaning**. It licenses the *next* question, not the whole ERES semantics.
- The value of running it is symmetric: a clean **fail** is as informative as a pass — it
  tells you precisely which rung the certification chain cannot yet stand on. Convergence
  can only be demonstrated by measurers who could have diverged; that is why independence
  and blinding are not decoration but the experiment itself.

---

### Companion artifact
`signature_fidelity_harness.py` — stdlib-only analysis + power + design-self-validation
(three synthetic worlds; PASSES only if the design detects a true signature and both fake
modes). Run with no `--data` to self-validate the design; run with `--data` on real readings.

*Credits: ERES Institute for New Age Cybernetics. Derived from the 6 Aug 2026
propagation→instantiation→certification→legitimacy→natural-measurement dialectic.
Standing read (unratified); pre-MIEVM. No third parties cited or implied.*
