#!/usr/bin/env python3
"""
ERES-SIGFID TEST INSTRUMENT  (MIEVM testkit)
============================================
Mechanically verifies the structural claims of ERES-SIGFID-EXPERIMENT-2026-001.
Each claim is tested by CONFIRM (holds when it should) and FALSIFY (fails when it
should) so a green run means the apparatus discriminates, not merely that it runs.

Empirical claims (real bio-data) are IMPOSSIBLE to satisfy in code and are reported
as SKIP, not PASS — the honest boundary between what is built and what is measured.

Zero third-party deps. Deterministic under fixed seeds. Exit 0 iff 0 FAIL.
Place next to signature_fidelity_harness.py and run:  python3 eres_sigfid_testkit.py
"""
import importlib.util, os, sys, hashlib, statistics as st
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
HPATH = os.path.join(HERE, "signature_fidelity_harness.py")
spec = importlib.util.spec_from_file_location("h", HPATH)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)

PASS, FAIL, SKIP = [], [], []
def ok(name):   PASS.append(name); print(f"  PASS  {name}")
def bad(name, why): FAIL.append((name, why)); print(f"  FAIL  {name}  <- {why}")
def skip(name, why): SKIP.append((name, why)); print(f"  SKIP  {name}  ({why})")

def approx(a, b, tol): return abs(a - b) <= tol

# ---- CLAIM->TEST MATRIX (printed) --------------------------------------------
MATRIX = [
 ("C1 ICC is a real reliability stat", "T1 identical->1 / T2 noise->0"),
 ("C2 permutation null centers at chance", "T3"),
 ("C3 signal separates above null", "T4"),
 ("C4 residualize removes a linear confound", "T5 / T6 preserves orthogonal signal"),
 ("C5 G3 confound falsifier fires", "T7 confound world collapses at G3"),
 ("C6 G4 projection falsifier fires", "T8 idiosyncratic world fails G4"),
 ("C7 G4 convergence confirms on shared fact", "T9 natural world passes G4"),
 ("C8 gates are nested / vector well-formed", "T10"),
 ("C9 deterministic under seed", "T11"),
 ("C10 scope firewall: no 'meaning' claim in code", "T12"),
 ("C11 self-integrity (SHA-256)", "T13"),
]

# ---- helpers to fabricate tiny controlled datasets ---------------------------
def const_world(n=10, sess=5, dim=4):
    rows = []
    for s in range(n):
        base = [float(s) + j for j in range(dim)]
        for t in range(sess):
            rows.append({"sid": s, "session": t, "feat": list(base), "confound": 0.0})
    return rows

def noise_world(n=24, sess=6, dim=8, seed=3):
    import random; rng = random.Random(seed)
    return [{"sid": s, "session": t,
             "feat": [rng.gauss(0,1) for _ in range(dim)], "confound": rng.gauss(0,1)}
            for s in range(n) for t in range(sess)]

# ================================ TESTS =======================================
def T1_icc_identical():
    by = {r["sid"]: [] for r in const_world()}
    for r in const_world(): by[r["sid"]].append(r["feat"][0])
    icc = h.icc_one_way(by)
    ok("T1 ICC(identical repeats)->1") if icc > 0.98 else bad("T1", f"icc={icc:.3f}")

def T2_icc_noise():
    icc = h.mean_dimension_icc(noise_world())
    ok("T2 ICC(pure noise)->~0") if icc < 0.20 else bad("T2", f"icc={icc:.3f}")

def T3_perm_centers_chance():
    nw = noise_world(n=24)
    m, lo, hi = h.permutation_chance(nw, n_perm=200, seed=5)
    chance = 1/24
    ok("T3 permutation null ~ chance") if approx(m, chance, 0.05) else bad("T3", f"mean={m:.3f} chance={chance:.3f}")

def T4_signal_separates():
    op, _ = h.make_world("natural", seed=2)
    acc = h.loso_identification(op); _,_,hi = h.permutation_chance(op, seed=2)
    ok("T4 signal acc > null-hi") if acc > hi else bad("T4", f"acc={acc:.3f} hi={hi:.3f}")

def T5_residualize_removes_confound():
    import random; rng = random.Random(1)
    conf = [rng.gauss(0,1) for _ in range(200)]
    feat = [3 + 2*c + rng.gauss(0,0.01) for c in conf]     # feature IS a+b*confound
    resid = h.ols_residualize(feat, conf)
    ratio = (st.pstdev(resid)+1e-9)/(st.pstdev(feat)+1e-9)
    ok("T5 residual removes linear confound") if ratio < 0.1 else bad("T5", f"ratio={ratio:.3f}")

def T6_residualize_preserves_orthogonal():
    import random; rng = random.Random(2)
    conf = [rng.gauss(0,1) for _ in range(200)]
    feat = [rng.gauss(0,1) for _ in range(200)]            # independent of confound
    resid = h.ols_residualize(feat, conf)
    ratio = st.pstdev(resid)/st.pstdev(feat)
    ok("T6 residual preserves orthogonal signal") if ratio > 0.8 else bad("T6", f"ratio={ratio:.3f}")

def T7_G3_confound_falsifier():
    op, _ = h.make_world("confound", seed=1)
    e = h.evaluate_operator(op, h.TH, seed=1)
    fires = (not e["g3_pass"]) and e["g2_acc"] > e["g2_chance_hi"]  # looked real, died at G3
    ok("T7 G3 catches stable confound") if fires else bad("T7", f"g2={e['g2_acc']:.3f} g3={e['g3_acc_resid']:.3f}")

def T8_G4_projection_falsifier():
    o1 = h.evaluate_operator(h.make_world("idiosyncratic", seed=1)[0], h.TH, seed=1)
    o2 = h.evaluate_operator(h.make_world("idiosyncratic", seed=1)[1], h.TH, seed=8)
    g4 = h.inter_operator_convergence(o1, o2, h.TH, seed=1)
    fires = (not g4["g4_pass"]) and o1["g3_pass"]           # clean per-op, but no convergence
    ok("T8 G4 catches private projection") if fires else bad("T8", f"r={g4['convergence']:.3f}")

def T9_G4_convergence_confirms():
    o1 = h.evaluate_operator(h.make_world("natural", seed=1)[0], h.TH, seed=1)
    o2 = h.evaluate_operator(h.make_world("natural", seed=1)[1], h.TH, seed=8)
    g4 = h.inter_operator_convergence(o1, o2, h.TH, seed=1)
    ok("T9 G4 converges on shared fact") if g4["g4_pass"] else bad("T9", f"r={g4['convergence']:.3f}")

def T10_vector_wellformed():
    e = h.evaluate_operator(h.make_world("natural", seed=1)[0], h.TH, seed=1)
    keys = {"g1_pass","g2_pass","g3_pass"}
    good = keys <= set(e) and all(isinstance(e[k], bool) for k in keys)
    ok("T10 gate vector well-formed") if good else bad("T10", "missing/!bool gate keys")

def T11_deterministic():
    a = h.run_world("natural", seed=1, verbose=False)
    b = h.run_world("natural", seed=1, verbose=False)
    ok("T11 deterministic under seed") if a == b else bad("T11", f"{a}!={b}")

def T12_scope_firewall():
    src = open(HPATH, encoding="utf-8").read().lower()
    banned = ["merit", "hpe", "virtue", "character", "worthiness", "values-tracking"]
    hit = [w for w in banned if w in src]
    ok("T12 no meaning-claim tokens in inference code") if not hit else bad("T12", f"found {hit}")

def T13_self_integrity():
    digest = hashlib.sha256(open(__file__, "rb").read()).hexdigest()
    print(f"        self SHA-256 = {digest}")
    ok("T13 self-hash computed (64 hex)") if len(digest) == 64 else bad("T13", "bad digest")

# ---- empirical claims that CANNOT be satisfied in code: honest SKIPs ----------
def empirical_skips():
    skip("E1 real >=24-subject test-retest ICC on instrument", "needs real bio-data")
    skip("E2 real confound-partialled discriminability", "needs real bio-data + confound logging")
    skip("E3 real two-instrument (modal) convergence", "needs 2 independent devices, blinded")
    skip("E4 CONSTRUCT VALIDITY (does the signal MEAN anything)", "out of scope: separate experiment, only after E1-E3")

TESTS = [T1_icc_identical, T2_icc_noise, T3_perm_centers_chance, T4_signal_separates,
         T5_residualize_removes_confound, T6_residualize_preserves_orthogonal,
         T7_G3_confound_falsifier, T8_G4_projection_falsifier, T9_G4_convergence_confirms,
         T10_vector_wellformed, T11_deterministic, T12_scope_firewall, T13_self_integrity]

if __name__ == "__main__":
    print("ERES-SIGFID TEST INSTRUMENT  —  claim -> test")
    for c, t in MATRIX: print(f"  {c:52s} {t}")
    print("\nRUNNING:")
    for t in TESTS:
        try: t()
        except Exception as e: bad(t.__name__, f"exception {e}")
    print("\nEMPIRICAL (held as SKIP — cannot be met in code):")
    empirical_skips()
    print(f"\n{len(PASS)} PASS / {len(FAIL)} FAIL / {len(SKIP)} SKIP")
    print("VERDICT:", "STRUCTURAL CLAIMS VERIFIED; empirical claims pending real data"
          if not FAIL else "STRUCTURAL FAILURE — fix before any data collection")
    sys.exit(0 if not FAIL else 1)
