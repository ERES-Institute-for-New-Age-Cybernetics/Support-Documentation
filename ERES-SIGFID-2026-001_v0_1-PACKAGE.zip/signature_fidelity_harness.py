#!/usr/bin/env python3
"""
ERES SIGNATURE-FIDELITY EXPERIMENT — analysis & power harness
=============================================================

Tests the terminal claim of the parallel-in-Nature dialectic:

  "The bio-electric / resonant signature is a stable, self-distinctive
   NATURAL fact that independent measurers CONVERGE on after confound
   control."  (i.e. legitimacy by convergence, not by fiat.)

The claim is decomposed into four NESTED GATES. A higher gate is only
meaningful if every lower gate passes.

  G1 RELIABILITY        same self read twice clusters tightly
                        (ICC across repeated readings)
  G2 DISCRIMINABILITY   readings identify which self they came from,
                        above chance, on held-out sessions
  G3 CONFOUND-INDEPENDENCE  discriminability SURVIVES after the measured
                        confounds (hydration/pressure/temp/humidity) are
                        regressed out. This is the crux: a pure confound
                        mimics a signature until you partial it.
  G4 INTER-OPERATOR CONVERGENCE  two independent instruments/operators,
                        blind to each other, agree on the per-self reading.
                        This is the "found, not conferred" test: reliability
                        alone does NOT imply a shared natural fact.

WHY THIS HARNESS EXISTS
-----------------------
Before any human subject is measured, we must show the DESIGN can tell a
real signature apart from the two ways it can be fake. So the harness
generates three synthetic worlds and checks the gate PATTERN in each:

  WORLD_NATURAL       shared latent + confound   -> expect G1..G4 all PASS
  WORLD_CONFOUND      "signature" IS the confound -> expect G1,G2 pass but
                                                     G3 FAIL (partialling
                                                     kills it)
  WORLD_IDIOSYNCRATIC each operator has a PRIVATE  -> expect G1..G3 pass but
                      latent, no shared fact          G4 FAIL (no convergence)

The harness PASSES only if it reproduces all three patterns — i.e. only if
the experiment can be falsified in the two ways that matter. Pure stdlib,
deterministic under --seed. Run on REAL data with --data <csv> once collected.
"""

import argparse, csv, math, random, statistics as st
from collections import defaultdict

# --------------------------------------------------------------------------
# small stats helpers (stdlib only)
# --------------------------------------------------------------------------

def mean(xs): return sum(xs) / len(xs)

def pearson(xs, ys):
    n = len(xs)
    if n < 2: return 0.0
    mx, my = mean(xs), mean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    return num / (dx * dy) if dx > 0 and dy > 0 else 0.0

def icc_one_way(by_subject):
    """ICC(1,1) one-way random effects from readings grouped by subject.
    by_subject: {sid: [scalar, scalar, ...]}  (equal-ish group sizes)."""
    groups = [v for v in by_subject.values() if len(v) >= 2]
    if len(groups) < 2: return 0.0
    all_vals = [x for g in groups for x in g]
    grand = mean(all_vals)
    k = mean([len(g) for g in groups])                       # avg readings/subject
    n = len(groups)
    ss_between = sum(len(g) * (mean(g) - grand) ** 2 for g in groups)
    ss_within = sum(sum((x - mean(g)) ** 2 for x in g) for g in groups)
    ms_b = ss_between / (n - 1)
    ms_w = ss_within / (len(all_vals) - n) if len(all_vals) > n else 1e-9
    denom = ms_b + (k - 1) * ms_w
    return (ms_b - ms_w) / denom if denom > 0 else 0.0

def ols_residualize(feature_vals, confound_vals):
    """Regress feature on a single measured confound; return residuals."""
    b = pearson(feature_vals, confound_vals)
    sd_f = st.pstdev(feature_vals) or 1e-9
    sd_c = st.pstdev(confound_vals) or 1e-9
    slope = b * sd_f / sd_c
    inter = mean(feature_vals) - slope * mean(confound_vals)
    return [f - (inter + slope * c) for f, c in zip(feature_vals, confound_vals)]

# --------------------------------------------------------------------------
# core: leave-one-session-out identification (nearest centroid)
# --------------------------------------------------------------------------

def dist(a, b): return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

def loso_identification(readings):
    """readings: list of dicts {sid, session, feat:[...]}.
    Leave-one-session-out nearest-centroid balanced accuracy."""
    sids = sorted({r["sid"] for r in readings})
    sessions = sorted({r["session"] for r in readings})
    per_subject_correct = defaultdict(lambda: [0, 0])
    for held in sessions:
        train = [r for r in readings if r["session"] != held]
        test = [r for r in readings if r["session"] == held]
        centroids = {}
        for sid in sids:
            fs = [r["feat"] for r in train if r["sid"] == sid]
            if fs:
                centroids[sid] = [mean(col) for col in zip(*fs)]
        for r in test:
            if not centroids: continue
            pred = min(centroids, key=lambda s: dist(r["feat"], centroids[s]))
            c = per_subject_correct[r["sid"]]
            c[1] += 1
            if pred == r["sid"]: c[0] += 1
    accs = [c[0] / c[1] for c in per_subject_correct.values() if c[1] > 0]
    return mean(accs) if accs else 0.0

def permutation_chance(readings, n_perm=200, seed=0):
    """Null band for identification: shuffle sid labels within the pool."""
    rng = random.Random(seed)
    sids = [r["sid"] for r in readings]
    accs = []
    for _ in range(n_perm):
        shuf = sids[:]; rng.shuffle(shuf)
        perm = [{**r, "sid": s} for r, s in zip(readings, shuf)]
        accs.append(loso_identification(perm))
    accs.sort()
    lo = accs[int(0.025 * len(accs))]
    hi = accs[int(0.975 * len(accs))]
    return mean(accs), lo, hi

# --------------------------------------------------------------------------
# gate evaluation on one operator's readings
# --------------------------------------------------------------------------

def mean_dimension_icc(readings):
    """Average ICC across feature dimensions (no sign cancellation)."""
    ncols = len(readings[0]["feat"])
    iccs = []
    for j in range(ncols):
        by_subj = defaultdict(list)
        for r in readings: by_subj[r["sid"]].append(r["feat"][j])
        iccs.append(icc_one_way(by_subj))
    return mean(iccs)

def evaluate_operator(readings, thresholds, seed=0, label=""):
    g1_icc = mean_dimension_icc(readings)

    acc = loso_identification(readings)
    _, _, chance_hi = permutation_chance(readings, seed=seed)
    g2_pass = acc > chance_hi and acc >= thresholds["ident_acc"]

    # G3: residualize every feature dim on the measured confound, re-identify
    conf = [r["confound"] for r in readings]
    ncols = len(readings[0]["feat"])
    resid_cols = []
    for j in range(ncols):
        col = [r["feat"][j] for r in readings]
        resid_cols.append(ols_residualize(col, conf))
    resid_readings = [
        {"sid": r["sid"], "session": r["session"],
         "feat": [resid_cols[j][i] for j in range(ncols)], "confound": r["confound"]}
        for i, r in enumerate(readings)
    ]
    acc_resid = loso_identification(resid_readings)
    _, _, chance_hi_r = permutation_chance(resid_readings, seed=seed + 1)
    g3_pass = acc_resid > chance_hi_r and acc_resid >= thresholds["ident_acc_resid"]

    return {
        "label": label,
        "g1_icc": g1_icc, "g1_pass": g1_icc >= thresholds["icc"],
        "g2_acc": acc, "g2_chance_hi": chance_hi, "g2_pass": g2_pass,
        "g3_acc_resid": acc_resid, "g3_chance_hi": chance_hi_r, "g3_pass": g3_pass,
        "resid_readings": resid_readings,
    }

def inter_operator_convergence(op1, op2, thresholds, seed=0):
    """G4: per-subject mean vectors from two operators must correlate,
    above a label-shuffled baseline. Uses confound-RESIDUAL readings so we
    test convergence on the signature, not on shared confounds."""
    sids = sorted({r["sid"] for r in op1["resid_readings"]})
    def subj_means(readings):
        m = {}
        for sid in sids:
            fs = [r["feat"] for r in readings if r["sid"] == sid]
            if fs: m[sid] = [mean(col) for col in zip(*fs)]
        return m
    m1, m2 = subj_means(op1["resid_readings"]), subj_means(op2["resid_readings"])
    common = [s for s in sids if s in m1 and s in m2]
    ncols = len(m1[common[0]])
    # mean per-dimension correlation across subjects
    rs = []
    for j in range(ncols):
        xs = [m1[s][j] for s in common]
        ys = [m2[s][j] for s in common]
        rs.append(pearson(xs, ys))
    conv = mean(rs)
    # shuffled baseline: permute op2 subject labels
    rng = random.Random(seed)
    null = []
    for _ in range(200):
        perm = common[:]; rng.shuffle(perm)
        m2p = {s: m2[p] for s, p in zip(common, perm)}
        rr = [pearson([m1[s][j] for s in common], [m2p[s][j] for s in common])
              for j in range(ncols)]
        null.append(mean(rr))
    null.sort()
    base_hi = null[int(0.975 * len(null))]
    return {"convergence": conv, "baseline_hi": base_hi,
            "g4_pass": conv > base_hi and conv >= thresholds["convergence"]}

# --------------------------------------------------------------------------
# synthetic worlds (for design self-validation only)
# --------------------------------------------------------------------------

def make_world(kind, n_subjects=24, n_sessions=6, dim=8, seed=1):
    rng = random.Random(seed)
    latent = {s: [rng.gauss(0, 1) for _ in range(dim)] for s in range(n_subjects)}
    latent2 = {s: [rng.gauss(0, 1) for _ in range(dim)] for s in range(n_subjects)}  # private op-2 latent
    base_conf = {s: rng.gauss(0, 1) for s in range(n_subjects)}   # stable per-subject confound (e.g. baseline hydration)
    conf_load = [abs(rng.gauss(0, 1)) + 0.5 for _ in range(dim)]  # COHERENT positive nuisance (raises all features)
    NOISE = 0.6

    def gen(operator):
        rows = []
        for s in range(n_subjects):
            for sess in range(n_sessions):
                # measured confound = generative confound (idealized; real data adds
                # measurement error, which only makes G3 more conservative)
                c = base_conf[s] + rng.gauss(0, 0.12)            # highly reliable per subject
                feat = []
                for j in range(dim):
                    v = NOISE * rng.gauss(0, 1)                  # measurement noise
                    v += 1.4 * c * conf_load[j]                  # confound contamination (both worlds)
                    if kind == "natural":
                        v += 1.4 * latent[s][j]                  # shared natural fact
                    elif kind == "confound":
                        pass                                     # signal IS the confound only
                    elif kind == "idiosyncratic":
                        src = latent if operator == 1 else latent2
                        v += 1.4 * src[s][j]                     # each operator's PRIVATE fact
                    feat.append(v)
                rows.append({"sid": s, "session": sess, "feat": feat, "confound": c})
        return rows
    return gen(1), gen(2)

# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------

# Significance is set by the permutation null (acc must exceed the shuffled-label
# 97.5th pct). The *_acc floors are an additional effect-size guard (~>=3x chance
# at 24 subjects); pre-register both per instrument before collecting data.
TH = {"icc": 0.60, "ident_acc": 0.15, "ident_acc_resid": 0.15, "convergence": 0.35}

def yn(b): return "PASS" if b else "FAIL"

def run_world(kind, seed=1, verbose=True):
    op1_raw, op2_raw = make_world(kind, seed=seed)
    chance = 1.0 / len({r["sid"] for r in op1_raw})
    o1 = evaluate_operator(op1_raw, TH, seed=seed, label="op1")
    o2 = evaluate_operator(op2_raw, TH, seed=seed + 7, label="op2")
    g4 = inter_operator_convergence(o1, o2, TH, seed=seed)
    if verbose:
        print(f"\n=== WORLD_{kind.upper()} (chance ident acc = {chance:.3f}) ===")
        print(f"  G1 reliability   ICC={o1['g1_icc']:.3f}                 [{yn(o1['g1_pass'])}]")
        print(f"  G2 discriminab.  acc={o1['g2_acc']:.3f}  chance_hi={o1['g2_chance_hi']:.3f} [{yn(o1['g2_pass'])}]")
        print(f"  G3 confound-indep acc_resid={o1['g3_acc_resid']:.3f} chance_hi={o1['g3_chance_hi']:.3f} [{yn(o1['g3_pass'])}]")
        print(f"  G4 convergence   r={g4['convergence']:.3f}  base_hi={g4['baseline_hi']:.3f}  [{yn(g4['g4_pass'])}]")
    return (o1["g1_pass"], o1["g2_pass"], o1["g3_pass"], g4["g4_pass"])

EXPECTED = {
    # (G1, G2, G3, G4)
    "natural":      (True,  True,  True,  True),
    "confound":     (True,  True,  False, False),   # G3 must catch the confound
    "idiosyncratic":(True,  True,  True,  False),    # G4 must catch the private-projection
}

def self_validate(seed=1):
    print("SIGNATURE-FIDELITY DESIGN SELF-VALIDATION")
    print("Thresholds:", TH)
    ok = True
    for kind, exp in EXPECTED.items():
        got = run_world(kind, seed=seed)
        match = (got == exp)
        # G3 for 'confound' and G4 for 'idiosyncratic' are the load-bearing falsifiers
        print(f"  -> pattern {got}  expected {exp}  [{'OK' if match else 'MISMATCH'}]")
        ok = ok and match
    print("\nRESULT:", "PASS — design can detect a real signature AND both fake modes"
          if ok else "FAIL — design does not discriminate; do NOT collect data yet")
    return ok

# --------------------------------------------------------------------------

def load_csv(path):
    """Real-data mode. Columns: operator,sid,session,confound,f1..fN"""
    ops = defaultdict(list)
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            feat = [float(v) for k, v in row.items()
                    if k.startswith("f") and k[1:].isdigit()]
            ops[row["operator"]].append({
                "sid": row["sid"], "session": row["session"],
                "feat": feat, "confound": float(row["confound"])})
    return ops

def run_real(path):
    ops = load_csv(path)
    keys = sorted(ops)
    print(f"Loaded operators: {keys}")
    evals = {k: evaluate_operator(ops[k], TH, label=k) for k in keys}
    for k in keys:
        e = evals[k]
        print(f"\n[{k}] G1 ICC={e['g1_icc']:.3f}[{yn(e['g1_pass'])}] "
              f"G2 acc={e['g2_acc']:.3f}[{yn(e['g2_pass'])}] "
              f"G3 resid={e['g3_acc_resid']:.3f}[{yn(e['g3_pass'])}]")
    if len(keys) >= 2:
        g4 = inter_operator_convergence(evals[keys[0]], evals[keys[1]], TH)
        print(f"\nG4 inter-operator convergence r={g4['convergence']:.3f} "
              f"base_hi={g4['baseline_hi']:.3f} [{yn(g4['g4_pass'])}]")
        gates = (evals[keys[0]]["g1_pass"], evals[keys[0]]["g2_pass"],
                 evals[keys[0]]["g3_pass"], g4["g4_pass"])
        print("\nGATE VECTOR (G1,G2,G3,G4):", gates)
        print("VERDICT:", "SIGNATURE SUPPORTED — natural fact, convergent, confound-independent"
              if all(gates) else
              "SIGNATURE NOT SUPPORTED at this gate — see first FAIL above")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--data", type=str, default=None,
                    help="CSV of real readings; omit to run design self-validation")
    a = ap.parse_args()
    if a.data:
        run_real(a.data)
    else:
        ok = self_validate(seed=a.seed)
        raise SystemExit(0 if ok else 1)
