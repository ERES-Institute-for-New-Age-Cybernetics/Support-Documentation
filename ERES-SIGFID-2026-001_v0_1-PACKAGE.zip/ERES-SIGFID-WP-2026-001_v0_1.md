# Signature Fidelity as the Natural-Measurement Root of ERES Certification

**ID:** ERES-SIGFID-WP-2026-001 · **Version:** v0.1 DRAFT (pre-MIEVM, single-node)
**Author:** Joseph A. Sprute, ERES Institute for New Age Cybernetics
**Companions:** ERES-SIGFID-EXPERIMENT-2026-001 (pre-registration protocol) · `signature_fidelity_harness.py` · `eres_sigfid_testkit.py`
**License:** CCAL v2.1 / CC BY 4.0 · **Date:** 6 Aug 2026

---

## Abstract

ERES certification grounds a self's standing in a **natural signature** (bio-electric /
resonant) rather than a conferred social status. This paper isolates the single empirical
claim on which that grounding stands — *signature fidelity* — and reduces it to a
falsifiable, pre-registered test with four nested gates. We show, on mapped simulation
data, that the test **discriminates**: it returns distinct verdicts for a true signature,
for a stable confound, and for an instrument-private projection, with the two failure
modes caught at different gates. A companion test instrument confirms and falsifies every
structural claim (13 PASS / 0 FAIL / 4 SKIP). We state plainly what this does and does not
establish: it validates the **instrument of inference**, not the signature. No real
bio-measurement is claimed. The contribution is to convert an unfalsifiable root into one
that is ready to be falsified by measurers who share none of ERES's priors.

---

## 1. Motivation — where the argument terminates

A separate line of reasoning (KEEN-Basis dialectic, 6 Aug 2026) walked the ERES stack down
through four relocations: propagation → instantiation → certification → legitimacy. Each
gap had a smaller internal unit to fall back on until legitimacy, where the question became
whether a self-founded authority can bind those who never adopted it. The resolution moved
the root from a **founded social authority** (which needs adoption) to one **"parallel in
Nature"** (which needs only measurement): a natural fact does not precede its readers in
time and is not conferred by assent — it is *found*, and recognition of it is **convergence**,
the way independent laboratories converge on a physical constant.

That move is sound as argument, but it is not free. It hands the entire remaining weight to
one thing: whether the instrument **faithfully reads the natural fact**. This is the ERES
corpus's recurring ANALOGICAL / instrument-fidelity gap, now standing alone as the whole
load. This paper tests it.

## 2. The claim

> **H1 (fidelity).** After confound control, signature readings are reliable within a self,
> discriminate selves above a permutation null, and converge across two independent
> instruments blind to each other.
>
> **H0 (null).** Apparent structure is fully explained by measured confounds (skin
> hydration, contact pressure, temperature, humidity, placement) **or** is instrument-private
> (per-device reliable but non-convergent).

H0 is the historically dominant outcome for electrophotonic/bioelectric measurement; a test
that cannot separate signal from these establishes nothing.

## 3. Operationalization — four nested gates

| Gate | Claim | Statistic | Pass rule |
|---|---|---|---|
| G1 | reliability | mean per-dimension ICC(1,1) | ≥ 0.60 |
| G2 | discriminability | leave-one-session-out nearest-centroid balanced accuracy | > permutation-97.5% and ≥ effect floor |
| G3 | confound-independence | G2 re-run on confound-**residualized** features | > permutation-97.5% and ≥ floor |
| G4 | inter-operator convergence | cross-operator Pearson r of per-self residual means | > shuffle-97.5% and ≥ 0.35 |

The design's decisive property is that **the two ways the claim can be false are caught by
two different gates**: a stable confound survives G1–G2 (it is reliable and discriminating)
and dies at **G3** when partialled out; an instrument-private projection survives G1–G3 (it
is reliable, discriminating, confound-clean per device) and dies at **G4** when two blind
instruments fail to converge. Convergence can only be *demonstrated* by operators that
**could have diverged** — so instrument independence and blinding are the test, not procedure.

## 4. Methods

The analysis harness (`signature_fidelity_harness.py`, stdlib-only, deterministic) computes
the four gates and includes a **design self-validation**: it generates three synthetic
worlds and passes only if it clears the true-signature world, fails the confound world at
G3, and fails the projection world at G4. This is verified across 8/8 seeds. Mapped
simulation data: 24 subjects × 6 sessions × 2 operators × 8 features (chance identification
= 0.0417).

## 5. Results (executed)

| World | G1 ICC | G2 acc | G3 resid-acc | G4 r | Vector |
|---|---|---|---|---|---|
| Natural (shared latent + confound) | 0.933 | 0.993 | 0.986 | 0.968 | (T,T,T,T) |
| Confound (signal *is* the confound) | 0.895 | 0.368 | **0.056** | −0.025 | (T,T,**F**,F) |
| Idiosyncratic (private per-operator latent) | 0.933 | 0.993 | 0.986 | **0.077** | (T,T,T,**F**) |

**Worked math (natural world, operator A).**
- **G1** f1: MS_between = 30.895, MS_within = 0.414, k = 6, n = 24 →
  ICC = (30.895 − 0.414)/(30.895 + 5·0.414) = 0.925; mean over 8 dims = 0.933.
- **G2** balanced acc = 0.993; permutation null mean 0.045, 95% CI [0.014, 0.083].
- **G3** f1 residual: corr(f1, confound) = 0.846, slope = r·sd_f/sd_c = 2.019, intercept =
  0.565; residualᵢ = f1ᵢ − (0.565 + 2.019·confoundᵢ); acc on residuals = 0.986.
- **G4** mean cross-operator r = 0.968 vs shuffle null-hi 0.138.

The confound world reproduces the classic trap: raw discriminability 0.368 (well above the
0.083 null) *looks* like a signature, and only the residualization step (→ 0.056, inside the
null) exposes it. The idiosyncratic world is reliable and confound-clean per operator yet
does not converge (r 0.077 < 0.169), separating *shared reality* from *private reliability*.

## 6. Significance

The finding is **structural, not substantive**: an apparatus now exists that will return a
clean, pre-registered verdict on real signature data and will fail loudly in exactly the two
ways the natural-root claim can be false. Most bioenergetic validation omits the confound
and projection controls and therefore cannot distinguish a signature from hydration or from
device artifact; this design can, provably, on synthetic ground truth.

Its honest limit is equally central: **simulation validates the instrument of inference, not
the signature.** No fingertip has been measured. A synthetic natural world passing shows only
that *if* a convergent, confound-independent signal exists in real selves, this test will
detect and grade it. The paper's result is therefore a **green light to collect**, not a
result about Nature — but that is precisely the missing rung the whole dialectic identified:
the root has moved from *unfalsifiable assertion* to *ready-to-be-falsified measurement*.

## 7. Scope firewall — fidelity is not meaning

Passing all four gates establishes that a stable, self-distinctive, confound-independent,
convergent signal **exists**. It does **not** establish what it *means* — that it tracks
merit, HPE, character, or value. Construct validity is a separate experiment, licensed only
**after** G4 clears. The inference code contains no meaning-claim vocabulary; the test
instrument enforces this as an invariant (T12).

## 8. Verification

The test instrument (`eres_sigfid_testkit.py`) confirms and falsifies each structural claim:
ICC behaves (identical → 1, noise → 0), the permutation null centers at chance, signal
separates, residualization removes a linear confound and preserves an orthogonal one, the G3
and G4 falsifiers fire in the right worlds, gate vectors are well-formed and deterministic,
and the scope firewall holds. Result: **13 PASS / 0 FAIL / 4 SKIP** (exit 0). The four SKIPs
are the empirical claims (E1 real test-retest, E2 real confound-partial, E3 real two-instrument
convergence, E4 construct validity) — impossible to satisfy in code, held as SKIP rather than
quietly passed.

## 9. Status and self-rating

Pre-MIEVM, single author node (author-node conflict; not an independent panel).
**As a design:** composite ≈ 8.4 — architectural coherence 9.0, epistemic discipline 9.4,
provenance/reuse 8.8, novelty 6.5 (methods standard; the novel move is the mimic-pair
self-validation and the ERES-root framing). **Binding caps:** empirical 1.0 (all synthetic),
artifact/reproducibility 9.0 (built, deterministic, self-validates 8/8, testkit 13/0/4). The
spread — design ~8.4, reality ~1.0 — *is* the rating. Grade **GOOD** as design/spec; at the
diligence-ready line, below the 9.0 canon gate; nothing empirically derived ⇒ not BEST;
single node ⇒ not SOUND-canonized. **Movers by leverage:** (1) real data on one instrument —
the only lever off the empirical floor; (2) an external ≥5-node MIEVM on the design; (3) a
genuinely second instrument *modality* for a non-simulated G4.

## 10. Reproduction

```
python3 signature_fidelity_harness.py            # design self-validation (3 worlds, 8/8 seeds)
python3 run_report.py                            # maps sim data, shows the math
python3 signature_fidelity_harness.py --data readings_natural.csv   # core code, real-data mode
python3 eres_sigfid_testkit.py                   # 13 PASS / 0 FAIL / 4 SKIP
```

---

### Credits / References / License
ERES Institute for New Age Cybernetics. Derived from the 6 Aug 2026 KEEN-Basis dialectic
(propagation → instantiation → certification → legitimacy → natural measurement). Methods are
standard and independently validated (intraclass correlation; leave-one-out identification;
permutation inference; confound residualization; inter-rater convergence). No third parties
are cited, implied, or associated. Standing read; unratified; pre-MIEVM. CCAL v2.1 /
CC BY 4.0.
