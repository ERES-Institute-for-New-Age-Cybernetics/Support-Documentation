# ERES Constitutional Provenance — Instrument Package

**Instrument:** ERES-CPROV-2026-001 · **Version:** v0.5 PROPOSED (pre-canonical)
**Home:** ERES Institute for New Age Cybernetics, Bella Vista, Arkansas
**Author (Sentience convention):** JAS (ERES Maestro). Claude Opus draft assistance — not co-authorship.
**License:** CC BY 4.0

---

## What this is

A **test case for the ERES Institute Constituency**: a governance doctrine stated as a whitepaper *and* made runnable as an executable conformance check, plus a diagram and this guide.

The doctrine in one line: **provenance — the record of who-did-what-and-why — must come first, because it is what converts governance from *advisory* to *binding*.** A ratification with no enforcement is a wish; enforcement with no provenance is force without a reason. Constitutional Provenance is the record that makes enforcement legitimate and legitimacy enforceable at the same time.

The mechanism is the standing ERES **H2C2H** (Human → Computer → Human) methodology. Its force is one structural fact: the computer never occupies an endpoint — every loop opens and closes on a human, so enforcement is *topological*, not bolted on. That topology holds if and only if three conditions hold, and all three are provenance conditions:

- **§5.1 — the middle must not coerce** (provenance on the C→H edge: *why these options, this order, now*)
- **§5.2 — intent must survive the crossing** (provenance in transit: the sending human's intent reaches the receiving human intact)
- **§5.3 — no output may escape the loop** (total closure: every output re-enters as the next H→C)

The practical payoff (V7) is **isolation**: a malformed loop fails *exactly one* of the three edges, so an open attack surface becomes a short, named, auditable list.

## Contents

| File | Role |
|---|---|
| `ERES-CPROV-2026-001_Constitutional-Provenance_v0.5.md` | The instrument. Full argument, value claims V1–V7 each fenced to its condition, honest limits, 5 OPEN items, changelog. |
| `eres_cprov_test_instrument.py` | Executable conformance check (v0.2, stdlib-only). Encodes the three edges, the isolation property, V1–V7 as edge dependencies, and 5 OPEN items as skipped tests. |
| `eres_cprov_provenance_loop.svg` | The topology diagram — three colour-coded edges, the blocked escape shown as a §5.3 violation, the central identity, the three-rule floor. |
| `README.md` | This file. |

## Run the test

Requires Python 3.8+ (standard library only — no installs).

```
python3 eres_cprov_test_instrument.py          # run the suite
python3 eres_cprov_test_instrument.py -v        # verbose (per-test)
python3 eres_cprov_test_instrument.py --demo    # worked example: four loops, one per failing edge
```

Expected: **31 tests — 26 pass, 5 skipped, exit 0.** The 5 skips **are** the 5 OPEN items (§9). The suite goes fully green only when those close — implementing the *necessary* checks does not close them, and a v0.2 guard test enforces that.

The `--demo` runs four loops (well-formed + one per failing edge) and prints which edge each fails and whether governance is binding or merely advisory.

## What it does and does not establish

- **Does:** check whether a given system *conforms* to the three provenance conditions, and name which edge it fails.
- **Does not:** claim the doctrine is *true or valuable in the world* (its P0), and does not claim a conformant system is *good*. Provenance guarantees outcomes carry their reasons — not that the reasons are good (§7). The instrument is **not MIEVM-rated**; nothing here is ensemble-verified.

## Status

Pre-canonical. **5 OPEN items** block canonization: provenance-sufficiency quantity; floor-minimality proof; coercion-degree metric (necessary condition mechanized, sufficiency open); closure-completeness audit for arbitrary real systems (model-level verified, general audit open); and the MIEVM ensemble round (≥5 independent nodes, Q5 bias-check retained). The two author-side items — the sufficiency quantity and the floor-minimality proof — are the ones only the author can close.

## Central identity

> **PROVENANCE === Epistemology × RATE + Conditioning**
> ( `===` = why-is / causal ground: how-you-know, scaled by how-much-you-measure, offset by what-conditioned-you )

## Floor (2012-02-04)

Don't hurt yourself · don't hurt others · don't hurt the future.
