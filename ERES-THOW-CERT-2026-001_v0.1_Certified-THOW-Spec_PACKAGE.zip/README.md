# ERES-THOW-CERT-2026-001_v0.1_Certified-THOW-Spec

**Certified Self-Sustaining Tiny Homes On Wheels (THOW)**
A specification that puts Human Quality of Life first and Human-Performance-Enhancement second, measured empirically as P³ at the User-GROUP level, with a builder pathway that holds even in the worst case.

Author: Joseph Allen Sprute (ERES Maestro), Founder and Director, ERES Institute for New Age Cybernetics, Bella Vista, Arkansas. ORCID 0000-0001-9946-3221
License: CCAL v2.1 / CC BY 4.0 | Date: 2026-10-09 | v0.1 PROPOSED: pre-canonical, not MIEVM-rated, canonical ID pending JAS confirmation

## Contents
| File | Role |
|---|---|
| ERES-THOW-CERT-2026-001_v0.1_Certified-THOW-Spec.pdf | Specification (PDF, figure embedded) |
| ERES-THOW-CERT-2026-001_v0.1_Certified-THOW-Spec.md | Specification (Markdown, same text) |
| ERES-THOW-CERT-2026-001_v0.1_Figure-1_QoL-First-Ladder.svg | Figure 1 (SVG) |
| eres_thow_cert_testkit.py | Test program (Python standard library only) |
| LICENSE.md | Full CCAL v2.1 text |
| META.txt | SEO title, abstract, keywords |
| README.md | This file |
| MANIFEST.json | sha256 for every file above |
| RUN.txt | Test run log from a fresh copy (written after the manifest) |

## Run the tests
    python3 eres_thow_cert_testkit.py
Expected: 25 tests, 20 pass, 5 skipped by design (E1-E5), exit 0.

## Boundary
A specification. Nothing has been built or measured in the field. Not a building, electrical or legal standard; follow local code and third-party inspection.

Attribution: Joseph Allen Sprute / ERES Institute for New Age Cybernetics. Licensed under CCAL v2.1.
