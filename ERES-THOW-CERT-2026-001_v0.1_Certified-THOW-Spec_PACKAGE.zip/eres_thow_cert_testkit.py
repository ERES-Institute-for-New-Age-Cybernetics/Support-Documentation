#!/usr/bin/env python3
"""
eres_thow_cert_testkit.py
ERES-THOW-CERT-2026-001 v0.1 PROPOSED | CCAL v2.1 / CC BY 4.0
Author: Joseph Allen Sprute (ERES Maestro), ERES Institute for New Age Cybernetics

Reference model + tests for the Certified Self-Sustaining THOW specification.
Run: python3 eres_thow_cert_testkit.py

GREEN means the SPECIFICATION behaves as written. It is not a field result.
Empirical items (E1-E5) are skipped by design until real User-GROUP data exist.
"""
import hashlib, json, math, os, sys, unittest

# ---------------------------------------------------------------- constants
GAL_PER_SQFT_INCH = 0.623      # gallons of rain per sq ft of catchment per inch of rain [VALIDATED physical constant]
LB_PER_GAL = 8.34              # weight of one US gallon of water
EMERGENCY_GAL_PER_PERSON_DAY = 1.0   # emergency drinking/sanitation minimum (preparedness guidance)

# ---------------------------------------------------------------- 1. water
def annual_rain_yield_gal(catch_sqft, rain_in_per_yr, efficiency=0.8):
    if catch_sqft <= 0 or rain_in_per_yr < 0 or not (0 < efficiency <= 1):
        raise ValueError("invalid catchment inputs")
    return catch_sqft * rain_in_per_yr * GAL_PER_SQFT_INCH * efficiency

def daily_yield_gal(catch_sqft, rain_in_per_yr, efficiency=0.8):
    return annual_rain_yield_gal(catch_sqft, rain_in_per_yr, efficiency) / 365.0

def storage_weight_lb(gallons):
    return gallons * LB_PER_GAL

def payload_ok(tank_gal, dry_weight_lb, gvwr_lb, other_load_lb=0.0):
    """Full tank + dry weight + other load must stay within GVWR."""
    return dry_weight_lb + storage_weight_lb(tank_gal) + other_load_lb <= gvwr_lb

# ---------------------------------------------------------------- 2. ordering: QoL first, HPE second
def lexicographic_rank(options):
    """options: list of dicts with 'qol' and 'hpe'. QoL strictly dominates;
    HPE only breaks ties. No amount of HPE can buy back a QoL loss."""
    return sorted(options, key=lambda o: (-o["qol"], -o["hpe"]))

def admissible_hpe_change(qol_before, qol_after):
    """An HPE intervention is admissible only if it does not lower QoL."""
    return qol_after >= qol_before

# ---------------------------------------------------------------- 3. N/M line
class Ledger:
    """N = unconditional floor (housing + water + food + safety). M = earned standing."""
    def __init__(self):
        self.N = {}; self.M = {}
    def admit(self, person):
        self.N[person] = True          # admission by present condition, unconditional
        self.M.setdefault(person, 0.0)
    def earn(self, person, amount):
        if amount < 0:
            raise ValueError("merit is additive only")
        self.M[person] += amount
    def penalise(self, person, *_):
        raise PermissionError("the N-floor is never decremented or withdrawn")

# ---------------------------------------------------------------- 4. pathway guardrails
def release_decision(court_or_parole_ruling, units_built=None, resonance_score=None):
    """Release is decided by the lawful authority on present condition.
    Production counts and resonance scores are NOT inputs. Passing them is refused."""
    if units_built is not None:
        raise PermissionError("G1: release may not depend on a production quota")
    if resonance_score is not None:
        raise PermissionError("G2: an unmeasured score may not gate release")
    return bool(court_or_parole_ruling)

def builder_certified(skills_passed, required=("carpentry", "electrical", "plumbing", "solar", "water", "growing", "safety")):
    """Builder track: every module verified by an assessor; credential is portable."""
    return all(s in skills_passed for s in required)

def home_certified(checks):
    """Home track: third-party structure/electrical + ERES systems checks, all required."""
    required = ("structure_third_party", "electrical_third_party", "water_quality", "water_yield_logged",
                "power_uptime_logged", "sanitation", "grow_system", "emergency_kit", "fire_co_alarms")
    return all(checks.get(k) is True for k in required)

# ---------------------------------------------------------------- 5. P^3 @ User-GROUP empirics
K_MIN = 10   # minimum group size for any published aggregate [PROPOSED; OPEN]

def publish_group_metric(values, k_min=K_MIN):
    """Public face: aggregate only, and only for groups of at least k_min.
    Private face: individual values are never returned."""
    if len(values) < k_min:
        return None
    n = len(values); mean = sum(values) / n
    return {"n": n, "mean": round(mean, 3)}

# ---------------------------------------------------------------- tests
class Water(unittest.TestCase):
    def test_constant_matches_geometry(self):
        # 1 inch over 1 sq ft = 144 cubic inches; 231 cubic inches per US gallon
        self.assertAlmostEqual(144 / 231, GAL_PER_SQFT_INCH, places=3)
    def test_reference_thow_yield(self):
        # 8.5 x 24 ft roof (204 sq ft), ~48 in/yr rain, 80% capture
        y = annual_rain_yield_gal(204, 48)
        self.assertAlmostEqual(y, 4880, delta=10)
        self.assertAlmostEqual(daily_yield_gal(204, 48), 13.4, delta=0.1)
    def test_yield_covers_emergency_minimum_for_one_household(self):
        self.assertGreater(daily_yield_gal(204, 48), 4 * EMERGENCY_GAL_PER_PERSON_DAY)
    def test_tank_weight(self):
        self.assertAlmostEqual(storage_weight_lb(200), 1668, delta=1)
    def test_payload_guard(self):
        self.assertTrue(payload_ok(200, 9000, 12000, 800))
        self.assertFalse(payload_ok(300, 10000, 12000, 800))
    def test_bad_inputs_rejected(self):
        with self.assertRaises(ValueError):
            annual_rain_yield_gal(0, 48)

class Ordering(unittest.TestCase):
    def test_qol_dominates_hpe(self):
        r = lexicographic_rank([{"id": "a", "qol": 7, "hpe": 9}, {"id": "b", "qol": 8, "hpe": 1}])
        self.assertEqual(r[0]["id"], "b")
    def test_hpe_breaks_ties_only(self):
        r = lexicographic_rank([{"id": "a", "qol": 8, "hpe": 2}, {"id": "b", "qol": 8, "hpe": 5}])
        self.assertEqual(r[0]["id"], "b")
    def test_hpe_cannot_lower_qol(self):
        self.assertFalse(admissible_hpe_change(8.0, 7.9))
        self.assertTrue(admissible_hpe_change(8.0, 8.0))

class Floor(unittest.TestCase):
    def test_admission_is_unconditional(self):
        L = Ledger(); L.admit("p1"); self.assertTrue(L.N["p1"])
    def test_merit_additive_only(self):
        L = Ledger(); L.admit("p1"); L.earn("p1", 3)
        with self.assertRaises(ValueError):
            L.earn("p1", -1)
    def test_floor_never_withdrawn(self):
        L = Ledger(); L.admit("p1")
        with self.assertRaises(PermissionError):
            L.penalise("p1", "breach")

class Pathway(unittest.TestCase):
    def test_release_refuses_quota(self):
        with self.assertRaises(PermissionError):
            release_decision(True, units_built=3)
    def test_release_refuses_score(self):
        with self.assertRaises(PermissionError):
            release_decision(True, resonance_score=0.1)
    def test_release_follows_lawful_ruling(self):
        self.assertTrue(release_decision(True)); self.assertFalse(release_decision(False))
    def test_builder_needs_all_modules(self):
        self.assertFalse(builder_certified({"carpentry", "electrical"}))
        self.assertTrue(builder_certified({"carpentry", "electrical", "plumbing", "solar", "water", "growing", "safety"}))
    def test_home_needs_all_checks(self):
        full = {k: True for k in ("structure_third_party", "electrical_third_party", "water_quality", "water_yield_logged",
                                  "power_uptime_logged", "sanitation", "grow_system", "emergency_kit", "fire_co_alarms")}
        self.assertTrue(home_certified(full))
        full["water_quality"] = False
        self.assertFalse(home_certified(full))

class P3Empirics(unittest.TestCase):
    def test_small_group_not_published(self):
        self.assertIsNone(publish_group_metric([7.0] * 9))
    def test_group_aggregate_only(self):
        out = publish_group_metric([6.0, 7.0, 8.0] * 4)
        self.assertEqual(set(out), {"n", "mean"}); self.assertEqual(out["n"], 12)

class Package(unittest.TestCase):
    def test_manifest(self):
        here = os.path.dirname(os.path.abspath(__file__)); mp = os.path.join(here, "MANIFEST.json")
        if not os.path.exists(mp):
            self.skipTest("no MANIFEST.json")
        for name, d in json.load(open(mp))["files"].items():
            self.assertEqual(hashlib.sha256(open(os.path.join(here, name), "rb").read()).hexdigest(), d, name)

class OPEN_Empirical(unittest.TestCase):
    @unittest.skip("E1 OPEN: measured QoL change (WHOQOL-BREF) at User-GROUP level vs comparison group")
    def test_E1(self): pass
    @unittest.skip("E2 OPEN: measured water yield and quality from a built unit over 12 months")
    def test_E2(self): pass
    @unittest.skip("E3 OPEN: measured grow-system yield and household food-security change")
    def test_E3(self): pass
    @unittest.skip("E4 OPEN: builder credential completion and post-program employment/housing stability")
    def test_E4(self): pass
    @unittest.skip("E5 OPEN: third-party certification of a prototype unit (structure, electrical)")
    def test_E5(self): pass

if __name__ == "__main__":
    r = unittest.main(exit=False, verbosity=1)
    print("\nBOUNDARY: green = specification behaves as written. Not a field result. E1-E5 skipped by design.")
    sys.exit(0 if r.result.wasSuccessful() else 1)
