#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ERES-BIOTREATY-2026-001 v0.2 -- structural validation suite (stdlib only).

v0.2 folds MIEVM Round-1 (ensemble) structural findings: T2 non-severability,
T13 held/veiled disposition, and T20 nesting are now behaviourally exercised
(confirm + falsify), and opens O2/O3 are explicitly enumerated as SKIPs so the
suite is a complete coverage map of the whole white paper.

Tests STRUCTURAL rules only. Nothing here measures a real physiological stream,
computes a real hazard density, or reads a real population order parameter; those
are the empirical claims and are SKIPPED by design until real telemetry exists.

Each testable rule is validated by confirm + falsify:
  - the compliant object is accepted, AND
  - a deliberately non-compliant object is REJECTED (raises).

A rule that could only be confirmed and never falsified is not a test.

Exit 0 iff 0 FAIL. Deterministic, import-guarded, no third-party deps.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple

# --------------------------------------------------------------------------- #
# Term registry: the 22 clauses that MUST be present in the instrument.
# --------------------------------------------------------------------------- #

REQUIRED_TERMS: Dict[str, str] = {
    "T1": "Scope: population-level provisioning; object = deficit distribution",
    "T2": "Signatory bound via Contact-of-Record; non-severable channel",
    "T3": "Proxy = App-Parent/AVATAR MIND surface (a surface of T2)",
    "T4": "Certifier = adjudicator (NOT a bound party); MIEVM-graded",
    "T5": "Band (reference): water/sugar/protein homeostasis",
    "T6": "Readout (current): h_phi three-band <1/=1/>1",
    "T7": "Continuity: Context Field per-cycle re-measurement (time axis)",
    "T8": "Deficit = computed function of the band (not an independent HHS target)",
    "T9": "Conditioning protocol: fires on measured state; Enable-Solidify-Contain",
    "T10": "Offset guarantee A0: discharge against deficit, never accrual to holder",
    "T11": "Firewall (two-sided): telos barred from BOTH evidence and target",
    "T12": "Floor: N-tier unconditional, never in hazard spectrum, never decremented",
    "T13": "Due process AUTH/SPRT: AUTH=no held/veiled, never turned away",
    "T14": "Revocable consent: per-cycle, revocation -> floor, no penalty",
    "T15": "Exit: voluntary withdrawal, no penalty, retains floor",
    "T16": "Denomination: SBEU",
    "T17": "Ledger & audit: GraceChain; audit band-owned or void",
    "T18": "Disposition set: token->recyclable / AUTH=no->held / no-token->retired",
    "T19": "Aggregation: rho_R >= 0.85 = population in-band certification",
    "T20": "Nesting: CONTROLs/S/$ per scale; no single-locus control",
    "T21": "Grade: BEST/SOUND/GOOD dual-axis; nothing DERIVED => none BEST",
    "T22": "Provenance/License: CCAL v2.1 / CC BY 4.0; scope-firewalled",
}


# --------------------------------------------------------------------------- #
# Minimal executable model of the load-bearing rules.
# --------------------------------------------------------------------------- #

MEASURABLE_STREAMS = frozenset({"water", "sugar", "protein"})


class TreatyViolation(Exception):
    """Raised when an object would violate a constitutional rule of the treaty."""


@dataclass(frozen=True)
class Target:
    """A provisioning target. `content` names what the deficit is measured against."""
    content: frozenset  # set of stream/attribute names


@dataclass(frozen=True)
class MeasurementCycle:
    """One re-measurement of a person under the Context Field."""
    consent_fresh: bool          # T14: consent granted THIS cycle?
    measured: bool               # was measurement actually taken?


@dataclass(frozen=True)
class Person:
    """A signatory's provisioning state for one cycle."""
    n_floor: float               # T12: unconditional basic provision
    m_reserve: float             # merit reserve (the only thing scored)
    admitted: bool               # T13: was the caller admitted?


def check_target_measurable(t: Target) -> Target:
    """T8 + T11: the target may contain ONLY measurable streams. Unmeasurable
    (telos) content in the target is the firewall back-door and must raise."""
    leak = set(t.content) - set(MEASURABLE_STREAMS)
    if leak:
        raise TreatyViolation(
            f"T11 firewall breach: unmeasurable content in target: {sorted(leak)}"
        )
    return t


def check_consent(cycle: MeasurementCycle) -> MeasurementCycle:
    """T14: measurement without fresh consent is surveillance and must raise."""
    if cycle.measured and not cycle.consent_fresh:
        raise TreatyViolation(
            "T14 breach: measurement taken without fresh per-cycle consent"
        )
    return cycle


def revoke_to_floor(before: Person) -> Person:
    """T14 + T12: revocation drops to floor with NO penalty to the floor."""
    after = Person(n_floor=before.n_floor, m_reserve=0.0, admitted=before.admitted)
    if after.n_floor < before.n_floor:
        raise TreatyViolation("T12 breach: floor decremented on revocation")
    return after


def score_person(p: Person) -> float:
    """T12: only M is scored; the N-floor is never on the spectrum."""
    if p.n_floor <= 0:
        raise TreatyViolation("T12 breach: N-floor is not unconditional (<=0)")
    return p.m_reserve  # floor deliberately not referenced in the score


def offset_transfer(deficit: float, to_holder: bool) -> float:
    """T10 (A0): value = discharge against a deficit; accrual to a holder must raise."""
    if to_holder:
        raise TreatyViolation("T10 breach: value accrued to a holder (unearned resonance)")
    if deficit <= 0:
        raise TreatyViolation("T10 breach: no shared deficit => nothing to discharge")
    return deficit  # the discharged amount


def population_certified(rho_r: float) -> bool:
    """T19: population in-band certification requires rho_R >= 0.85."""
    if not (0.0 <= rho_r <= 1.0):
        raise TreatyViolation("T19 breach: rho_R outside [0,1]")
    return rho_r >= 0.85


def admit_caller(admitted: bool, element_held: bool) -> bool:
    """T13: non-refusal is absolute. The caller is ALWAYS admitted; only the
    element may be held. A turned-away caller must raise."""
    if not admitted:
        raise TreatyViolation("T13 breach: caller turned away (non-refusal is absolute)")
    return element_held  # holding the element is allowed


def process_auth(auth_status: bool, element: str) -> str:
    """T13 (held/veiled disposition): AUTH=no shelves the element as HELD/VEILED
    pending review -- it is NEVER turned away and NEVER processed. AUTH=yes
    proceeds. Complements admit_caller (which tests the caller side)."""
    if not auth_status:
        return "HELD"                       # VEILED / under-investigation
    return f"PROCESSED:{element}"


@dataclass(frozen=True)
class ContactOfRecord:
    """T2: the Signatory's named, reachable, answerable channel."""
    is_alive: bool


def check_channel_alive(channel: ContactOfRecord) -> ContactOfRecord:
    """T2 (non-severability): a dead Contact-of-Record voids the treaty."""
    if not channel.is_alive:
        raise TreatyViolation("T2 breach: dead Contact-of-Record channel voids treaty")
    return channel


def check_nesting(control_loci: Dict[str, float]) -> bool:
    """T20 (no single-locus control): control must be distributed across >=2
    scale loci and may not concentrate (> 0.95 of total weight) in any one."""
    if len(control_loci) < 2:
        raise TreatyViolation("T20 breach: single-locus control (nesting failed)")
    total = sum(control_loci.values())
    if total <= 0:
        raise TreatyViolation("T20 breach: non-positive total control weight")
    for locus, w in control_loci.items():
        if w / total > 0.95:
            raise TreatyViolation(f"T20 breach: control concentrated in '{locus}'")
    return True


# --------------------------------------------------------------------------- #
# Test harness
# --------------------------------------------------------------------------- #

@dataclass
class Result:
    name: str
    status: str            # PASS | FAIL | SKIP
    detail: str = ""

@dataclass
class Suite:
    results: List[Result] = field(default_factory=list)

    def run(self, name: str, fn: Callable[[], None]) -> None:
        try:
            fn()
            self.results.append(Result(name, "PASS"))
        except AssertionError as e:
            self.results.append(Result(name, "FAIL", str(e)))
        except Exception as e:  # unexpected error is a failure, not a crash
            self.results.append(Result(name, "FAIL", f"{type(e).__name__}: {e}"))

    def skip(self, name: str, why: str) -> None:
        self.results.append(Result(name, "SKIP", why))

    def summary(self) -> Tuple[int, int, int]:
        p = sum(r.status == "PASS" for r in self.results)
        f = sum(r.status == "FAIL" for r in self.results)
        s = sum(r.status == "SKIP" for r in self.results)
        return p, f, s


def expect_raises(fn: Callable[[], object]) -> None:
    try:
        fn()
    except TreatyViolation:
        return
    raise AssertionError("expected TreatyViolation, none raised")


def build_suite() -> Suite:
    s = Suite()

    # -- structural: every required term present -------------------------- #
    def t_registry():
        assert len(REQUIRED_TERMS) == 22, f"expected 22 terms, got {len(REQUIRED_TERMS)}"
        for i in range(1, 23):
            key = f"T{i}"
            assert key in REQUIRED_TERMS, f"missing term {key}"
            assert REQUIRED_TERMS[key].strip(), f"empty term {key}"
    s.run("t01_all_22_terms_present", t_registry)

    # -- T11/T8 firewall: confirm + falsify ------------------------------- #
    def t_firewall_confirm():
        ok = Target(frozenset({"water", "sugar", "protein"}))
        assert check_target_measurable(ok) is ok
    s.run("t02_firewall_accepts_measurable_target", t_firewall_confirm)

    def t_firewall_falsify():
        bad = Target(frozenset({"water", "supernatural_grace"}))
        expect_raises(lambda: check_target_measurable(bad))
    s.run("t03_firewall_rejects_unmeasurable_target", t_firewall_falsify)

    # -- T14 consent: confirm + falsify ----------------------------------- #
    def t_consent_confirm():
        c = MeasurementCycle(consent_fresh=True, measured=True)
        assert check_consent(c) is c
    s.run("t04_consent_accepts_fresh_consent", t_consent_confirm)

    def t_consent_falsify():
        c = MeasurementCycle(consent_fresh=False, measured=True)
        expect_raises(lambda: check_consent(c))
    s.run("t05_consent_rejects_measurement_without_consent", t_consent_falsify)

    def t_consent_no_measure_ok():
        # no measurement taken => consent not required, must NOT raise
        c = MeasurementCycle(consent_fresh=False, measured=False)
        assert check_consent(c) is c
    s.run("t06_no_measurement_needs_no_consent", t_consent_no_measure_ok)

    # -- T12 + T14 revocation to floor ------------------------------------ #
    def t_revoke_floor():
        before = Person(n_floor=1.0, m_reserve=5.0, admitted=True)
        after = revoke_to_floor(before)
        assert after.n_floor == before.n_floor, "floor changed on revocation"
        assert after.m_reserve == 0.0, "merit not zeroed on revocation"
    s.run("t07_revocation_preserves_floor", t_revoke_floor)

    def t_floor_unconditional():
        expect_raises(lambda: score_person(Person(0.0, 5.0, True)))
    s.run("t08_score_rejects_nonpositive_floor", t_floor_unconditional)

    def t_floor_not_scored():
        # two people, same M different floor -> identical score (floor not scored)
        a = score_person(Person(1.0, 3.0, True))
        b = score_person(Person(99.0, 3.0, True))
        assert a == b, "floor leaked into the score"
    s.run("t09_floor_excluded_from_score", t_floor_not_scored)

    # -- T10 offset / A0: confirm + falsify ------------------------------- #
    def t_offset_confirm():
        assert offset_transfer(deficit=2.0, to_holder=False) == 2.0
    s.run("t10_offset_discharges_against_deficit", t_offset_confirm)

    def t_offset_falsify_holder():
        expect_raises(lambda: offset_transfer(2.0, to_holder=True))
    s.run("t11_offset_rejects_accrual_to_holder", t_offset_falsify_holder)

    def t_offset_falsify_nodeficit():
        expect_raises(lambda: offset_transfer(0.0, to_holder=False))
    s.run("t12_offset_rejects_zero_deficit", t_offset_falsify_nodeficit)

    # -- T13 non-refusal: confirm + falsify ------------------------------- #
    def t_admit_confirm():
        # caller admitted, element held -> allowed (returns True)
        assert admit_caller(admitted=True, element_held=True) is True
        assert admit_caller(admitted=True, element_held=False) is False
    s.run("t13_caller_admitted_element_may_be_held", t_admit_confirm)

    def t_admit_falsify():
        expect_raises(lambda: admit_caller(admitted=False, element_held=False))
    s.run("t14_turning_caller_away_raises", t_admit_falsify)

    # -- T19 aggregation threshold: confirm + falsify --------------------- #
    def t_agg_confirm():
        assert population_certified(0.85) is True
        assert population_certified(0.90) is True
        assert population_certified(0.84) is False
    s.run("t15_aggregation_threshold_at_0_85", t_agg_confirm)

    def t_agg_falsify():
        expect_raises(lambda: population_certified(1.5))
    s.run("t16_aggregation_rejects_out_of_range_rho", t_agg_falsify)

    # -- T21 grade cap: nothing derived => not BEST ----------------------- #
    def t_grade_cap():
        derived = False  # v0.2: still no real streams instantiated
        grade = "BEST" if derived else "SOUND-candidate"
        assert grade != "BEST", "graded BEST with nothing derived"
    s.run("t17_grade_cap_no_derived_no_best", t_grade_cap)

    # == v0.2 additions (MIEVM Round-1 structural findings) =============== #

    # -- T2 non-severability: confirm + falsify --------------------------- #
    def t_channel_alive():
        live = ContactOfRecord(is_alive=True)
        assert check_channel_alive(live) is live
    s.run("t18_channel_alive_accepts", t_channel_alive)

    def t_channel_dead():
        expect_raises(lambda: check_channel_alive(ContactOfRecord(is_alive=False)))
    s.run("t19_dead_channel_raises_void", t_channel_dead)

    # -- T20 nesting / no single-locus control: confirm + falsify --------- #
    def t_nesting_confirm():
        assert check_nesting({"local": 0.4, "regional": 0.3, "national": 0.3}) is True
    s.run("t20_nesting_accepts_distributed_control", t_nesting_confirm)

    def t_nesting_falsify_single():
        expect_raises(lambda: check_nesting({"global": 1.0}))
    s.run("t21_nesting_rejects_single_locus", t_nesting_falsify_single)

    def t_nesting_falsify_concentrated():
        expect_raises(lambda: check_nesting({"global": 0.99, "local": 0.01}))
    s.run("t22_nesting_rejects_concentrated_control", t_nesting_falsify_concentrated)

    # -- T13 held/veiled disposition (element side, complements t13/t14) -- #
    def t_auth_held():
        assert process_auth(False, "report") == "HELD"      # never processed
    s.run("t23_auth_no_returns_held", t_auth_held)

    def t_auth_yes_processes():
        assert process_auth(True, "report") == "PROCESSED:report"
    s.run("t24_auth_yes_processes_element", t_auth_yes_processes)

    # -- empirical claims: SKIP until real telemetry exists --------------- #
    s.skip("t25_real_hphi_from_water_sugar_protein_stream",
           "empirical: requires real physiological telemetry (T5/T6)")
    s.skip("t26_real_rho_R_over_population_ensemble",
           "empirical: requires an instantiated per-person certificate ensemble (T19)")
    s.skip("t27_context_field_percycle_readout_live",
           "empirical: requires a live Context Field wearable stream (T7)")

    # -- open items: enumerated so the suite maps the WHOLE paper --------- #
    s.skip("t28_breach_enforcement_mechanism",
           "open O1: GraceChain-internal enforcement mechanism not yet specified")
    s.skip("t29_inter_party_arbitration_mechanism",
           "open O2: Signatory<->Proxy disagreement procedure not yet specified")
    s.skip("t30_hhs_higher_layer_firewall_proof",
           "open O3: HHS at broader layers requires re-proving T11 against wider target")

    return s


def main() -> int:
    s = build_suite()
    width = max(len(r.name) for r in s.results)
    for r in s.results:
        line = f"{r.status:4}  {r.name:<{width}}"
        if r.detail:
            line += f"  -- {r.detail}"
        print(line)
    p, f, sk = s.summary()
    print("-" * (width + 12))
    print(f"{p} PASS / {f} FAIL / {sk} SKIP")
    return 0 if f == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
