**ERES Penalty Standard**

*The Veil-Detection Rule: the penalty for undeclared observation*

ERES-PENALTY-STANDARD-2026-001 · Version 1.1 · BEST/SOUND/GOOD
assimilation

*Companion to the Observation Legitimacy & Coordinate Restraint package*

**Précis.** This standard defines the single penalty the ERES
observation framework imposes: the consequence of observing *without
declaration* in the coordinate registry --- a "veiled" observation. The
rule is deliberately narrow and checkable: an undeclared observation
forfeits Authority, which under the binding-constraint (minimum) rule
forces the whole regime to FLOOR-FAIL, and a floor-failed observer
receives no comfort-gauge service ("lockout"). It grades on the same
BEST/SOUND/GOOD scale as the rest of the package and ships with an
executable test. This is Version 1.1 because it corrects two defects in
the material it distills; those corrections are stated openly in §4.

**1. What the standard governs**

The companion papers establish that observation earns legitimacy through
reciprocity and restraint, and that the coordinate is the registry at
which spatial rules are filed. This raises an obvious question the
papers left implicit: what happens to an observer who does not file? The
Penalty Standard answers only that question. It is not a general
enforcement regime; it governs one boundary --- the line between
*declared* and *undeclared* observation --- and states the consequence
of crossing it undeclared.

**2. The rule**

**\[DERIVED\] The Veil Gate.** An observation conducted without a
registry token for its source coordinate is "veiled." A veiled
observation forfeits the Authority dimension. Because the framework
composes by the binding-constraint rule --- a regime is only as
legitimate as its weakest necessary condition --- zero Authority forces
the entire regime to FLOOR-FAIL. Declaration is thus a *necessary*
condition of legitimacy: without it, no quantity of good bounds,
reciprocity, or remedy can lift the regime off the floor.

**\[DERIVED\] Declaration is necessary, not sufficient.** A registry
token alone does not confer legitimacy. A declared observation that does
not resolve to a real legal extent (no cadastral overlay) or that
carries no bound still FLOOR-FAILs. Declaration opens the door to the
ladder; it does not place the observer on a rung.

**\[DERIVED\] Lockout as withheld service, not retaliation.** A
floor-failed observer receives no output from the comfort-floor gauge
--- the gauge returns no value for a coordinate whose observer has no
standing. This is the withholding of a service, not an act against the
offender. The framework does not observe, expose, or strip a veiled
operator; it simply declines to serve one. This distinction is
load-bearing and is the subject of §4.

**3. The grades**

The standard grades an observation event on the package's common scale:

**FLOOR-FAIL ---** veiled (undeclared), or declared but
unresolved/unbounded. Receives lockout.

**GOOD ---** declared, resolved to a legal extent, and bounded, with
thin reciprocity. Tolerated.

**SOUND ---** the above plus thick reciprocity (mutual accountability)
and a remedy for breach. Protected.

**BEST ---** reserved for the full combined-test stack; not reachable
from the penalty gate alone. This standard governs the floor, not the
ceiling.

**4. What was corrected in v1.1**

This standard distills earlier veil-detection material, and intellectual
honesty requires stating what was changed and why. Two defects were
corrected; both were caught by the framework's own rules.

**\[CORRECTION 1\] Decimal drift removed.** The source material assigned
specific decimal scores (for example GOOD = 3.3, SOUND = 6.6) that were
not derived from anything and that changed between passes for identical
inputs --- the same regime rated 6.0, then 3.3, then a tier name, on
successive evaluations. That is precisely the failure the Non-Transfer
Rule forbids: interpretation moved the number. This standard grades in
*tiers only*. The executable test asserts that the grade is a tier enum,
never a decimal, and that grading is deterministic across passes.

**\[CORRECTION 2\] The "Symmetrical Exposure" penalty was cut.** The
source imposed, on a veiled operator, the stripping of that operator's
own bounds and their exposure to the community at maximum resolution.
That penalty is incoherent within this framework: it is one-directional,
unbounded, retaliatory observation --- exactly the conduct the companion
papers define as the illegitimate failure state (the Lop Nor case: power
exercised in a permissive vacuum). A penalty that *commits the very
violation it punishes* cannot be part of a legitimacy standard. It was
removed. The corrected consequence is the withholding of service
(lockout), which penalizes the offender without the framework itself
becoming an illegitimate observer. The test asserts that no retaliation
operation exists in the standard's surface.

**5. Verification**

The standard ships with an executable companion suite
(*test_penalty_standard.py*). It runs clean (10/10) and exits zero, and
it verifies the standard's claims directly: that veiled observation
floor-fails and triggers lockout; that a declared, protected event does
not; that declaration is necessary but not sufficient; that thin
reciprocity grades GOOD and thick grades SOUND; and --- encoding the two
v1.1 corrections --- that grading returns tiers not decimals, is
deterministic across passes, and exposes no retaliation operation.

**6. Scope of claims**

This standard makes a governance claim only. It defines the consequence
of undeclared observation within the ERES framework; it does not claim
that any real jurisdiction enforces such a rule, nor that any physical
instrument currently detects veiled observation in the field. Whether a
real registry-and-detection system can be built is an implementation
question outside this document. The standard's value is that its rule is
*checkable* --- a given observation event either resolves to a registry
token or it does not, and the grade follows deterministically. That is
the property that distinguishes this instrument from a rule whose terms
cannot be measured.

**Note on sources and status.** ERES Institute instrument, CC-BY 4.0 /
CCAL v2.1. Distilled and corrected from prior veil-detection material.
Claims tagged per the ERES Doctrine of Verifiable Claims: \[DERIVED\]
follows from the stated rule; \[CORRECTION\] marks a defect removed from
the source. The standard governs one boundary (declared vs. undeclared
observation) and defers the general enforcement regime, physical
detection, and real-jurisdiction binding as out of scope. Companion
test: test_penalty_standard.py (10/10, exit 0).
