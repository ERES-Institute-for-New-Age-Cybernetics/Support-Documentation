# ERES Penalty Standard v1.1 — Veil-Detection Rule

The penalty for undeclared ("veiled") observation, as a clean tier-graded
instrument. Companion to the Observation Legitimacy & Coordinate Restraint
package.

## Files
- `eres_penalty_standard_v1_1.md` / `.pdf` — the standard.
- `test_penalty_standard.py` — executable suite (10/10, exit 0).

## The rule
Undeclared observation forfeits Authority → FLOOR-FAIL (binding-constraint
rule) → gauge lockout (withheld service). Declaration is necessary, not
sufficient. Grades BEST/SOUND/GOOD like the rest of the package.

## Corrected from source (v1.1)
1. Decimal drift removed — grades in tiers only; the source's invented,
   drifting decimals (3.3/6.6) violated the Non-Transfer Rule.
2. "Symmetrical Exposure" cut — that penalty made the framework commit the
   one-directional unbounded surveillance its own thesis calls illegitimate.
   Replaced by non-retaliatory service-withholding (lockout).

## Run
    python3 test_penalty_standard.py

Stdlib-only, deterministic, exit 0.
