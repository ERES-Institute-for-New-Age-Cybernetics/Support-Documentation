#!/usr/bin/env python3
"""
ERES-PENALTY-STANDARD-2026-001 v1.1 -- Veil-Detection Standard, Test Suite
Stdlib only. Deterministic. Exit 0 iff all structural tests pass.

Distilled from the veil-detection material, corrected against the ERES
Doctrine of Verifiable Claims and the two companion papers' own thesis.

WHAT THIS STANDARD IS
    A single, checkable rule for the penalty a regime incurs when observation
    is conducted WITHOUT declaration in the coordinate registry ("veiled").
    It grades BEST/SOUND/GOOD like the rest of the v3 package, and composes
    by the binding-constraint (min) rule.

WHAT WAS CORRECTED FROM THE SOURCE TRANSCRIPT
    1. Decimal drift removed. The source assigned invented decimals
       (GOOD=3.3, SOUND=6.6) that do not derive from anything and that moved
       between passes for identical inputs -- the exact failure the
       Non-Transfer Rule forbids. This standard grades in TIERS only.
    2. "Symmetrical Exposure" penalty CUT. The source stripped a veiled
       operator's own bounds and exposed them to the community at max
       resolution. That is one-directional, unbounded, retaliatory
       observation -- i.e. the standard would COMMIT the exact violation the
       companion papers define as illegitimate (see Lop Nor). A penalty that
       perpetrates the offense it punishes is incoherent. Removed.
    3. What remains is only what is defensible: declaration is a necessary
       condition of legitimacy; its absence sets Authority to FLOOR-FAIL and
       (by min-composition) forces the whole regime to FLOOR-FAIL; the gauge
       returns no comfort value for a floor-failed regime (lockout), because
       an unlegitimated observer gets no service, NOT because we retaliate.
"""

from dataclasses import dataclass
from enum import IntEnum
import sys


class Tier(IntEnum):
    FLOOR_FAIL = 0
    GOOD = 1
    SOUND = 2
    BEST = 3


TIER_NAME = {t: t.name for t in Tier}


@dataclass
class ObservationEvent:
    name: str
    declared: bool          # is there a registry token for the source coordinate
    resolves_to_extent: bool  # cadastral overlay present (Paper 2)
    mutual_accountability: bool  # thick reciprocity (Paper 1)
    bounded: bool           # spatial/temporal/scope bound present
    remedy: bool            # consequence for breach exists


def grade(e: ObservationEvent) -> Tier:
    """
    The penalty standard, stated positively as a grade.

    Declaration is the gate. Undeclared (veiled) observation is power in a
    permissive vacuum -- the Lop Nor failure mode -- and floor-fails outright.
    A declared event then grades on the same reciprocity/restraint ladder as
    the rest of the package.
    """
    # THE VEIL GATE: undeclared observation forfeits Authority -> FLOOR-FAIL.
    if not e.declared:
        return Tier.FLOOR_FAIL
    # A declared event must still resolve to a legal extent and be bounded to
    # be even tolerated (GOOD). Registry token alone is not enough.
    if not (e.resolves_to_extent and e.bounded):
        return Tier.FLOOR_FAIL
    # Declared + resolved + bounded = tolerated (GOOD).
    # + thick reciprocity + remedy = protected (SOUND).
    # + both = SOUND; BEST is reserved for the combined-test full stack and is
    #   not reachable from the penalty gate alone (this standard governs the
    #   floor, not the ceiling).
    if e.mutual_accountability and e.remedy:
        return Tier.SOUND
    return Tier.GOOD


def gauge_lockout(e: ObservationEvent) -> bool:
    """
    Lockout is a CONSEQUENCE of floor-fail, not an independent retaliation.
    A floor-failed (e.g. veiled) observer receives no comfort-gauge service.
    This withholds a service; it does NOT observe, expose, or strip the
    offender -- the corrected, non-retaliatory reading.
    """
    return grade(e) == Tier.FLOOR_FAIL


FIXTURES = {
    # Veiled: the penalty case. No registry token -> floor-fail, lockout.
    "veiled": ObservationEvent("Veiled (undeclared) observation",
                               declared=False, resolves_to_extent=True,
                               mutual_accountability=True, bounded=True, remedy=True),
    # Declared but unresolved: a token with no cadastral extent -> floor-fail.
    "declared_unresolved": ObservationEvent("Declared but no cadastral extent",
                                            declared=True, resolves_to_extent=False,
                                            mutual_accountability=True, bounded=True, remedy=True),
    # Declared, resolved, bounded, thin reciprocity -> tolerated (GOOD).
    "declared_thin": ObservationEvent("Declared, bounded, thin reciprocity",
                                      declared=True, resolves_to_extent=True,
                                      mutual_accountability=False, bounded=True, remedy=False),
    # Declared, resolved, bounded, thick reciprocity + remedy -> protected (SOUND).
    "declared_thick": ObservationEvent("Declared, bounded, thick reciprocity + remedy",
                                       declared=True, resolves_to_extent=True,
                                       mutual_accountability=True, bounded=True, remedy=True),
}


def run_tests():
    results = []

    def check(desc, cond):
        results.append((desc, bool(cond)))

    g = {k: grade(v) for k, v in FIXTURES.items()}

    # P1 THE VEIL GATE: undeclared observation floor-fails, whatever else it has.
    check("P1 veiled observation FLOOR-FAILs (Authority forfeited)",
          g["veiled"] == Tier.FLOOR_FAIL)

    # P2 Lockout is the consequence of floor-fail, and ONLY of floor-fail.
    check("P2 veiled observation triggers gauge lockout", gauge_lockout(FIXTURES["veiled"]))
    check("P2b a SOUND (declared) event does NOT trigger lockout",
          not gauge_lockout(FIXTURES["declared_thick"]))

    # P3 NON-RETALIATION (the corrected behavior): the standard exposes a
    #    dataclass with no field that strips or observes the offender. We assert
    #    the API surface contains only a grade and a service-withholding lockout,
    #    never an "expose" or "strip" operation.
    ops = {"grade", "gauge_lockout"}
    module_ops = {n for n in globals() if callable(globals().get(n)) and n in ("grade", "gauge_lockout", "run_tests", "main")}
    check("P3 no retaliation op exists (only grade + service-withholding lockout)",
          "expose" not in globals() and "strip_bounds" not in globals())

    # P4 Declaration is necessary but not sufficient: declared-but-unresolved
    #    still floor-fails (a token without a real legal extent is not enough).
    check("P4 declaration alone insufficient (unresolved extent FLOOR-FAILs)",
          g["declared_unresolved"] == Tier.FLOOR_FAIL)

    # P5 Declared + bounded + thin reciprocity = tolerated (GOOD).
    check("P5 declared thin-reciprocity event is GOOD (tolerated)",
          g["declared_thin"] == Tier.GOOD)

    # P6 Declared + thick reciprocity + remedy = protected (SOUND).
    check("P6 declared thick-reciprocity event is SOUND (protected)",
          g["declared_thick"] == Tier.SOUND)

    # P7 TIERS ONLY (no decimal drift): grade() returns a Tier, never a float.
    check("P7 grade returns a Tier enum, never an invented decimal",
          all(isinstance(grade(v), Tier) for v in FIXTURES.values()))

    # P8 Determinism / non-transfer: grading the same event twice is identical
    #    (a re-run cannot move the result -- the corrected anti-drift guarantee).
    check("P8 grading is deterministic (no drift across passes)",
          grade(FIXTURES["declared_thick"]) == grade(FIXTURES["declared_thick"]))

    # P9 Monotonicity: strengthening an event never lowers its grade.
    weak = ObservationEvent("weak", True, True, False, True, False)
    strong = ObservationEvent("strong", True, True, True, True, True)
    check("P9 monotonicity: adding accountability+remedy never lowers grade",
          grade(strong) >= grade(weak))

    return results


def main():
    results = run_tests()
    width = max(len(d) for d, _ in results)
    print("=" * (width + 8))
    print("ERES PENALTY STANDARD v1.1 -- Veil-Detection Test Suite")
    print("(corrected: tiers-only, non-retaliatory lockout)")
    print("=" * (width + 8))
    for name, fx in FIXTURES.items():
        lk = "  [LOCKOUT]" if gauge_lockout(fx) else ""
        print(f"  [{TIER_NAME[grade(fx)]:>10}]  {fx.name}{lk}")
    print("-" * (width + 8))
    passed = 0
    for desc, ok in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {desc}")
        passed += ok
    print("-" * (width + 8))
    print(f"  {passed}/{len(results)} structural tests passed")
    print("=" * (width + 8))
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
